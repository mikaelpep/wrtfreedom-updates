#!/usr/bin/ucode
/* WrtFreedom: coda dei messaggi Telegram (2.42). Gli avvisi (tgsend con bg: Eventi, Watchdog, Pianificazioni…)
   vanno in /tmp/wf-tgq, un file per messaggio («<ora>-<n>»); «flush» li manda in ordine e toglie solo quelli
   arrivati. Senza linea o con Telegram che non risponde restano lì: notify.sh riprova ogni 30 secondi, così
   «Linea caduta» arriva quando la linea torna, con l'ora vera dell'evento.
   Prima riga «#kb:<mac>» (2.49, nuovo dispositivo): pulsanti «Lo Conosco / Blocca» se il bot risponde ai comandi
   (tgbot.uc riceve il tocco), altrimenti solo il testo.
   2.53: righe d'intestazione «#c:<categoria>» (event.sh) e «#to:<chat>» (un messaggio per una sola chat, per esempio il
   benvenuto di una chat aggiunta). Bot Per Più Persone: ogni avviso va alla chat collegata e poi alle chat in più
   (sezioni tgchat; i pulsanti solo a chi ha «tutto»); la coda va avanti solo se la chat collegata lo riceve.
   Ore Silenziose (wrtfreedom.ev.quiet, qfrom, qto HH:MM, qpass = categorie che passano lo stesso, di serie «net sys fw»,
   «none» = nessuna): gli avvisi restano in coda e partono alla fine della fascia; le categorie di qpass partono subito
   anche con gli Avvisi Raggruppati. Avvisi Raggruppati (ev.group secondi: 60, 300, 900): si aspetta che il più
   vecchio abbia quell'età, poi partono tutti insieme in un messaggio solo.
   uso: ucode tgq.uc flush */
import { readfile, writefile, unlink, mkdir, rmdir, lsdir, stat, popen } from "fs";

const Q = '/tmp/wf-tgq', LOCK = '/tmp/wf-tgq.lock', MAXAGE = 86400, MAXN = 100;

function sh(c) { let p = popen(c), o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
/* opzione di una sezione con nome di /etc/config/wrtfreedom letta dal file, senza processi (uci salva sempre col commit) */
function uo(sec, opt) {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
		let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m && m[1] == opt) return m[2];
	}
	return '';
}
function urlenc(s) {
	let o = '';
	for (let i = 0; i < length(s); i++) {
		let c = ord(s, i);
		o += ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 46 || c == 95 || c == 126) ? chr(c) : sprintf('%%%02X', c);
	}
	return o;
}

/* chat in più (2.53): sezioni «config tgchat» (id, role a = avvisi, s = comandi sicuri, t = tutto) */
function chats() {
	let R = [], cur = null;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { cur = match(l, /^config tgchat /) ? {} : null; if (cur) push(R, cur); continue; }
		let m = cur ? match(l, /^[[:blank:]]*option (id|role) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m) cur[m[1]] = m[2];
	}
	return filter(R, (x) => match(x.id ?? '', /^-?[0-9]{1,20}$/));
}
function hm(s) { let m = match(s, /^([0-9]{1,2}):([0-9]{2})$/); return m ? +m[1] * 60 + +m[2] : null; }
function hhmm(t) { let lt = localtime(t); return sprintf('%02d:%02d', lt.hour, lt.min); }

if (ARGV[0] != 'flush') { warn('uso: ucode tgq.uc flush\n'); exit(1); }
/* un solo invio alla volta; un blocco rimasto da un invio interrotto si toglie dopo 2 minuti */
if (!mkdir(LOCK)) {
	let s = stat(LOCK);
	if (s && time() - s.mtime < 120) exit(0);
	rmdir(LOCK); if (!mkdir(LOCK)) exit(0);
}
let tk = uo('tg', 'token'), chat = uo('tg', 'chat'), en = uo('ui', 'lang') == 'en', bot = uo('tg', 'cmd') == '1', CH = chats();
let L = sort(filter(lsdir(Q) ?? [], (f) => match(f, /^[0-9]+-/)));
/* troppi messaggi: restano i più recenti */
while (length(L) > MAXN) unlink(Q + '/' + shift(L));
/* 2.62: indirizzo con il token e testo in un file per curl -K (cartella 0700, come kfile di tgbot.uc), mai sulla riga di
   comando né nell'indirizzo; senza curl niente invio (i messaggi restano in coda) */
const KD = '/tmp/wf-tg.k', CURL = length(filter([ '/usr/bin/curl', '/usr/sbin/curl', '/bin/curl', '/sbin/curl' ], (f) => stat(f) != null)) > 0;
function kq(s) { return '"' + replace(replace('' + s, '\\', () => '\\\\'), '"', () => '\\"') + '"'; }
function send(ch, txt, kb) {
	if (!CURL) return null;
	let k = '';
	if (kb) {
		let id = replace(kb, /:/g, '');
		k = '&reply_markup=' + urlenc(sprintf('%J', { inline_keyboard: [[{ text: en ? '✅ I Know It' : '✅ Lo Conosco', callback_data: 'dk:' + id }, { text: en ? '⛔ Block' : '⛔ Blocca', callback_data: 'db:' + id }]] }));
	}
	mkdir(KD, 448);
	let f = KD + '/q-' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time()), /[^0-9a-f]/g, ''), 0, 10);
	writefile(f, 'url = ' + kq('https://api.telegram.org/bot' + tk + '/sendMessage') + '\ndata = ' + kq('chat_id=' + urlenc(ch) + '&text=' + urlenc(txt) + k) + '\n');
	let o = sh('curl -s -m 15 -K ' + f + ' 2>/dev/null');
	unlink(f);
	try { return json(o); } catch (e) {}
	return null;
}
/* consegna: la chat collegata decide (null = nessuna risposta, si riprova più tardi); le altre una prova sola */
function deliver(o, txt) {
	if (length(o.to)) {
		if (o.to != chat && !length(filter(CH, (x) => x.id == o.to))) return true;
		let r = send(o.to, txt, '');
		return r == null ? null : (r.ok || (+r.error_code >= 400 && +r.error_code < 429)) ? true : null;
	}
	let r = send(chat, txt, bot ? o.kb : '');
	if (r == null || !(r.ok || (+r.error_code >= 400 && +r.error_code < 429))) return null;
	for (let x in CH) if (x.id != chat) send(x.id, txt, bot && x.role == 't' ? o.kb : '');
	return true;
}
let M = [], lt = localtime(), nm = lt.hour * 60 + lt.min, qf = hm(uo('ev', 'qfrom') || '23:00'), qt = hm(uo('ev', 'qto') || '07:00');
let quiet = uo('ev', 'quiet') == '1' && qf != null && qt != null && qf != qt && (qf < qt ? (nm >= qf && nm < qt) : (nm >= qf || nm < qt));
let qpass = split(uo('ev', 'qpass') || 'net sys fw', ' '), grp = +(uo('ev', 'group') || '0');
for (let f in L) {
	let t0 = +split(f, '-')[0], txt = readfile(Q + '/' + f);
	if (!length(tk) || !length(chat) || txt == null || time() - t0 > MAXAGE) { unlink(Q + '/' + f); continue; }
	let o = { f: f, t0: t0, kb: '', c: '', to: '' };
	/* righe d'intestazione «#kb:», «#c:», «#to:» in testa (lette riga per riga, senza regex su più righe) */
	for (let nl = index(txt, '\n'); nl > 0 && substr(txt, 0, 1) == '#'; nl = index(txt, '\n')) {
		let h = match(substr(txt, 0, nl), /^#(kb|c|to):([^ ]*)$/);
		if (!h) break;
		o[h[1]] = h[2]; txt = substr(txt, nl + 1);
	}
	if (length(o.kb) && !match(o.kb, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/)) o.kb = '';
	o.txt = txt;
	/* Ore Silenziose: restano in coda (tranne le categorie scelte e i messaggi per una chat sola) */
	if (quiet && !length(o.to) && !(length(o.c) && index(qpass, o.c) >= 0)) continue;
	push(M, o);
}
let G = [], stop = false;
/* raggruppati: tranne pulsanti, messaggi per una chat sola e categorie che passano (qpass: partono subito).
   2.72 (R2 voce 17): senza Avvisi Raggruppati gli avvisi rimasti in coda più di 60 s (linea tornata, fine delle Ore
   Silenziose) partono uniti in un messaggio solo, prima di quelli freschi; i freschi uno alla volta come sempre */
let old = grp <= 0;
for (let o in M) if (!length(o.kb) && !length(o.to) && (old ? time() - o.t0 > 60 : !(length(o.c) && index(qpass, o.c) >= 0))) { o.g = true; push(G, o); }
/* in messaggi da al massimo 3800 caratteri; false = Telegram non ha risposto (si riprova più tardi, nello stesso ordine) */
function group(G) {
	if (length(G) == 1) { let o = G[0]; if (deliver(o, o.txt + (time() - o.t0 > 60 ? '\n🕒 ' + (en ? 'at ' : 'alle ') + hhmm(o.t0) : '')) == null) return false; unlink(Q + '/' + o.f); return true; }
	let part = [], size = 0;
	let flush = () => {
		if (!length(part)) return true;
		let txt = (en ? '🔔 ' + length(part) + ' alerts' : '🔔 ' + length(part) + ' avvisi') + '\n\n' + join('\n\n', map(part, (o) => '• ' + hhmm(o.t0) + ' · ' + substr(o.txt, 0, 3000)));
		if (deliver({ kb: '', to: '' }, txt) == null) return false;
		for (let o in part) unlink(Q + '/' + o.f);
		part = []; size = 0;
		return true;
	};
	for (let o in G) {
		let n = (length(o.txt) > 3000 ? 3000 : length(o.txt)) + 12;
		if (size + n > 3800 && !flush()) return false;
		push(part, o); size += n;
	}
	return flush();
}
/* vecchi senza raggruppamento: prima dei freschi */
if (old && length(G) && !group(G)) stop = true;
/* uno alla volta: con i pulsanti, per una chat sola, freschi o senza raggruppamento */
if (!stop) for (let o in M) {
	if (o.g) continue;
	let txt = o.txt;
	/* partito in ritardo: si aggiunge l'ora dell'evento */
	if (time() - o.t0 > 60) txt += '\n🕒 ' + (en ? 'at ' : 'alle ') + hhmm(o.t0);
	let r = deliver(o, txt);
	if (r == null) { stop = true; break; }	/* nessuna risposta: si riprova più tardi, nello stesso ordine */
	unlink(Q + '/' + o.f);
}
/* Avvisi Raggruppati: partono quando il più vecchio ha l'età scelta */
if (!old && !stop && length(G) && time() - G[0].t0 >= grp) group(G);
rmdir(LOCK);
