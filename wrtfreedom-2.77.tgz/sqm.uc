'use strict';
/* WrtFreedom 2.70: giro del Controllo Della Linea (docs/v2/sqm-api.md), fuori da rpcd.
   uso: ucode sqm.uc tick   una volta al minuto da notify.sh, solo con una regola accesa: limiti delle code adesso, traffico
                            della linea e un ping (3 pacchetti al primo Server Ping); ritardo in più a linea carica,
                            Storico Della Velocità Adattiva (un punto per ora, 24 ore) e Avviso Ritardo Alto
        ucode sqm.uc save   Storico in memoria permanente (allo spegnimento, dal servizio)
   Lo stato (regola, verso, rete, avviso) arriva dal metodo sqm: una sola regola, niente calcoli doppi qui.
   File: /tmp/wf-sqmlag.json {t, ms, base, rtt, loaded, high} · /tmp/wf-sqmh.json {t, list} · /tmp/wf-sqm.tick (giro) ·
   /etc/wrtfreedom/sqmh.json (copia ogni 3 ore e allo spegnimento). WF_SQMTMP, WF_EVSH, WF_SYSNET solo per le prove */
import { popen, readfile, writefile, rename, mkdir, stat, unlink } from 'fs';

const T = getenv('WF_SQMTMP') ?? '/tmp', LAG = T + '/wf-sqmlag.json', H = T + '/wf-sqmh.json', ST = T + '/wf-sqm.tick';
const HE = getenv('WF_SQMHE') ?? '/etc/wrtfreedom/sqmh.json', EVSH = getenv('WF_EVSH') ?? '/usr/share/wrtfreedom/event.sh';
const SYSNET = getenv('WF_SYSNET') ?? '/sys/class/net';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, /'/g, "'\\''") + "'"; }
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function num(f) { let v = trim(readfile(f) ?? ''); return match(v, /^[0-9]+$/) ? +v : null; }
function en() { return trim(sh('uci -q get wrtfreedom.ui.lang 2>/dev/null')) == 'en'; }

/* limite di una coda CAKE in kbit/s («bandwidth 62Mbit», «900Kbit») */
function kbit(n, u) { return int(+n * ({ K: 1, M: 1000, G: 1000000 }[u] ?? 0.001)); }

function save() {
	let o = rjs(H);
	if (!o) return;
	mkdir('/etc/wrtfreedom');
	wjs(HE, o);
}

function tick() {
	let S = null;
	try { S = json(sh('ubus -t 10 call wrtfreedom sqm 2>/dev/null') || 'null'); } catch (e) { S = null; }
	if (type(S) != 'object' || !S.on || S.slow) return;
	let now = time(), P = rjs(ST) ?? {}, X = S.tech ?? {}, sw = S.where?.swap === true;
	/* limiti delle code adesso (quelli che muove la Velocità Adattiva), nel verso della linea */
	let C = {};
	for (let l in split(sh('tc qdisc show 2>/dev/null'), '\n')) {
		let m = match(l, /^qdisc cake [0-9a-f]+: dev ([^ ]+) root.* bandwidth ([0-9.]+)([KMG]?)bit/);
		if (m) C[m[1]] = kbit(m[2], m[3]);
	}
	let eg = C[X.dev], ig = C[X.ifb], dl = sw ? eg : ig, ul = sw ? ig : eg;
	/* traffico della linea dall'ultimo giro (kbit/s) */
	let ld = X.line ?? '', rx = length(ld) ? num(SYSNET + '/' + ld + '/statistics/rx_bytes') : null, tx = length(ld) ? num(SYSNET + '/' + ld + '/statistics/tx_bytes') : null;
	let dt = now - +(P.t ?? 0), rd = null, rt = null;
	if (rx != null && P.rx != null && P.ld == ld && dt > 0 && dt < 300 && rx >= P.rx && tx >= P.tx) { rd = (rx - P.rx) * 8 / 1000 / dt; rt = (tx - P.tx) * 8 / 1000 / dt; }
	let lim = (k) => k ?? 0, loaded = rd != null && ((lim(dl) > 0 && rd >= lim(dl) * 0.5) || (lim(ul) > 0 && rt >= lim(ul) * 0.5) ||
		(!dl && !ul && S.dl > 0 && rd >= S.dl * 0.5));
	/* un ping (3 pacchetti) al primo Server Ping; base = ritardo a linea scarica, sale piano (0,5 ms al minuto) */
	let srv = S.srv?.list?.[0] ?? '1.1.1.1', pg = match(sh('ping -c 3 -W 1 -q ' + q(srv) + ' 2>/dev/null'), /= ([0-9.]+)\/([0-9.]+)\//), rtt = pg ? +pg[2] : null;
	let base = P.base;
	if (rtt != null && !loaded) base = base == null || rtt <= base ? rtt : (base + 0.5 < rtt ? base + 0.5 : rtt);
	let ms = rtt != null && base != null && loaded ? (rtt > base ? int(rtt - base + 0.5) : 0) : null;
	/* Avviso Ritardo Alto: dopo min minuti di fila sopra la soglia, una volta sola finché non torna sotto per 5 minuti,
	   al massimo uno all'ora */
	let A = S.alert ?? {}, hi = +(P.hi ?? 0), lo = +(P.lo ?? 0), al = P.al === true, alt = +(P.alt ?? 0);
	if (ms != null && ms >= +(A.ms ?? 30)) { hi++; lo = 0; }
	else { hi = 0; if (ms == null || ms < +(A.ms ?? 30) * 0.7) lo++; }
	if (al && lo >= 5) al = false;
	let high = A.on === true && hi >= +(A.min ?? 5);
	if (high && !al && now - alt >= 3600) {
		al = true; alt = now;
		let E = en(), tip = S.mode == 'auto' ? (S.prof != 'safe' ? (E ? 'try the Cautious profile' : 'prova il profilo Prudente') : (E ? 'the line is very busy' : 'la linea è molto carica')) :
			(E ? 'lower the limits a little or use Adaptive Speed' : 'abbassa un po\' i limiti o usa la Velocità Adattiva');
		let txt = E ? '🐢 High delay on the line: +' + ms + ' ms on a busy line for ' + hi + ' minutes · ' + tip : '🐢 Ritardo alto sulla linea: +' + ms + ' ms a linea carica da ' + hi + ' minuti · ' + tip;
		sh((A.tg === false ? 'WF_NOTG=1 ' : 'WF_TG=1 ') + 'sh ' + q(EVSH) + ' cron sqm_lag net ' + q(txt) + ' >/dev/null 2>&1 </dev/null &');
	}
	wjs(LAG, { t: now, ms: ms, base: base != null ? int(base * 10 + 0.5) / 10 : null, rtt: rtt, loaded: loaded, high: high });
	wjs(ST, { t: now, rx: rx, tx: tx, ld: ld, base: base, hi: hi, lo: lo, al: al, alt: alt });
	/* Storico: un punto per ora (limiti più basso e più alto, ritardo a carico medio e peggiore), 24 ore */
	let R = rjs(H) ?? rjs(HE) ?? { list: [] }, hk = now - now % 3600, L = filter(R.list ?? [], (x) => +x.h > now - 90000), b = L[length(L) - 1];
	let nb = !b || b.h != hk;
	if (nb) { b = { h: hk, dmin: null, dmax: null, umin: null, umax: null, lsum: 0, ln: 0, lmax: 0, n: 0 }; push(L, b); }
	let mm = (k, v, f) => { if (v != null && v > 0 && (b[k] == null || f(v, b[k]))) b[k] = v; };
	mm('dmin', dl, (x, y) => x < y); mm('dmax', dl, (x, y) => x > y); mm('umin', ul, (x, y) => x < y); mm('umax', ul, (x, y) => x > y);
	b.n++;
	if (ms != null) { b.lsum += ms; b.ln++; if (ms > b.lmax) b.lmax = ms; }
	b.lavg = b.ln ? int(b.lsum / b.ln + 0.5) : null;
	R = { t: now, list: L };
	wjs(H, R);
	/* memoria permanente solo ogni 3 ore (all'inizio dell'ora) e allo spegnimento: niente scritture continue */
	if (nb && localtime(now).hour % 3 == 0) { mkdir('/etc/wrtfreedom'); wjs(HE, R); }
}

let A0 = ARGV[0] ?? '';
if (A0 == 'tick') {
	/* un giro alla volta (blocco che scade dopo 2 minuti) */
	let lk = T + '/wf-sqm.lock', s = stat(lk);
	if (s && time() - s.mtime < 120) exit(0);
	writefile(lk, '' + time());
	tick();
	unlink(lk);
}
else if (A0 == 'save') save();
else print('uso: ucode sqm.uc tick|save\n');
