'use strict';
/* WrtFreedom: storico del segnale del modem (pacchetto 2.47).
   uso: ucode sighist.uc tick   un campione al minuto (notify.sh, solo se c'è un modem)
        ucode sighist.uc save   riassunti orari subito in /etc/wrtfreedom (spegnimento del servizio)
   Campione = lettura del modem già fatta in sottofondo per l'app (/tmp/wf-modem.*, modem.uc state()): se è più vecchia
   di 75 s se ne fa una, la stessa dell'app (readcmd), che serve anche all'app al giro dopo. Niente comandi in più.
   - ultime 24 ore in /tmp/wf-sighist.24h, una riga al minuto: «t tecnologia rsrp rsrq sinr nrrsrp nrrsrq nrsinr linea»
     ('-' = valore mancante; linea 1 = internet c'è, 0 = assente, '-' = non si sa);
   - cadute di internet (line.sh scrive l'ora in /tmp/wf-line.drops quando la linea si perde) in /tmp/wf-sighist.drops;
   - riassunto di ogni ora per 7 giorni in /tmp/wf-sighist.7d.json {h: [ore chiuse], cur: ora in corso, now: suo
     riassunto}; copia in /etc/wrtfreedom/sighist.json al massimo ogni 6 ore e allo spegnimento (poche scritture in flash).
   Riassunto: {h: inizio dell'ora, n: campioni, tech: tecnologia più usata, lr/nr: [media, minimo, massimo] di RSRP 4G/5G,
   lq/nq: media RSRQ, ls/ns: [media, minimo] SINR, drops: cadute, down: minuti senza internet, nosig: minuti senza segnale} */
import { readfile, writefile, popen, stat, mkdir, rmdir, rename, open } from 'fs';

const W = '/usr/share/wrtfreedom', D24 = '/tmp/wf-sighist.24h', DR = '/tmp/wf-sighist.drops', TMP = '/tmp/wf-sighist.7d.json',
	ETC = '/etc/wrtfreedom/sighist.json', LOCK = '/tmp/wf-sighist.lock', LDROPS = '/tmp/wf-line.drops';
const M = loadfile(getenv('WF_MODEMUC') ?? W + '/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function load(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
function num(x) { if (x == null || x === '') return null; let n = +x; return n != n ? null : n; }
function v(x) { return x == null ? '-' : sprintf('%.1f', x); }
/* accumulatore di un valore: [somma, conteggio, minimo, massimo] */
function acc(a, x) {
	if (x == null) return a;
	if (!a) return [ x, 1, x, x ];
	return [ a[0] + x, a[1] + 1, x < a[2] ? x : a[2], x > a[3] ? x : a[3] ];
}
function avg(a) { return a ? +sprintf('%.1f', a[0] / a[1]) : null; }
/* riassunto dell'ora dall'accumulatore */
function summary(c) {
	if (!c) return null;
	let best = '', bn = -1;
	for (let k in c.tc ?? {}) if (c.tc[k] > bn) { bn = c.tc[k]; best = k; }
	return { h: c.h, n: c.n, tech: best, lr: c.lr ? [ avg(c.lr), c.lr[2], c.lr[3] ] : null, lq: avg(c.lq), ls: c.ls ? [ avg(c.ls), c.ls[2] ] : null,
		nr: c.nr ? [ avg(c.nr), c.nr[2], c.nr[3] ] : null, nq: avg(c.nq), ns: c.ns ? [ avg(c.ns), c.ns[2] ] : null, drops: c.drops, down: c.down, nosig: c.nosig };
}
function persist(S) {
	S.st = time();
	mkdir('/etc/wrtfreedom');
	writefile(ETC + '.t', sprintf('%J', { h: S.h, cur: S.cur, st: S.st })); rename(ETC + '.t', ETC);
}

let cmd = ARGV[0];
if (cmd != 'tick' && cmd != 'save') { print('uso: sighist.uc tick|save\n'); exit(1); }
/* un giro alla volta; un blocco rimasto da più di 5 minuti si toglie. Il salvataggio (spegnimento) aspetta fino a
   20 s il giro in corso invece di uscire: il 26/10 una lettura del modem lenta ha fatto perdere lo storico (2.69) */
if (cmd == 'save') { let i = 0; while (!mkdir(LOCK) && ++i < 20) sleep(1000); if (i >= 20) { rmdir(LOCK); mkdir(LOCK); } }
else if (!mkdir(LOCK)) { let s = stat(LOCK); if (s && time() - s.mtime < 300) exit(0); rmdir(LOCK); if (!mkdir(LOCK)) exit(0); }
function done(c) { rmdir(LOCK); exit(c); }

let S = load(TMP) ?? load(ETC) ?? { h: [] }, now = time(), hr = now - now % 3600;
S.h = S.h ?? [];
if (cmd == 'save') { if (length(S.h) || S.cur) persist(S); done(0); }

/* lettura del modem: quella dell'app se recente, altrimenti la stessa lettura fatta qui */
let I = M.id();
if (!I.present) done(0);
let ts = stat('/tmp/wf-modem.ts');
if (!ts || now - ts.mtime > 75) sh('( ' + M.readcmd() + ' ) >/dev/null 2>&1');
let st = M.state(), n = st.n, tech = M.tech(n);
let lr = num(n.lte?.rsrp), lq = num(n.lte?.rsrq), ls = num(n.lte?.sinr), nr = num(n.nr?.rsrp), nq = num(n.nr?.rsrq), ns = num(n.nr?.sinr);
/* internet: dal controllo della linea (line.sh), solo se lo stato è fresco */
let L = load('/tmp/wf-line.json'), up = (L && now - +(L.t ?? 0) < 30) ? (L.ok ? 1 : 0) : null;
/* cadute nuove scritte da line.sh: si spostano nello storico delle 24 ore */
let drops = filter(map(split(readfile(LDROPS) ?? '', '\n'), (x) => +x), (x) => x > 0);
if (length(drops)) { writefile(LDROPS, ''); let f = open(DR, 'a'); if (f) { for (let d in drops) f.write(d + '\n'); f.close(); } }

/* ora finita: riassunto nello storico, ultimi 7 giorni; 24 ore e cadute ripuliti una volta l'ora */
if (S.cur && S.cur.h != hr) {
	push(S.h, summary(S.cur));
	S.h = filter(S.h, (x) => x && x.h > now - 7 * 86400);
	S.cur = null;
	let keep = (f) => { let o = ''; for (let l in split(readfile(f) ?? '', '\n')) if (length(l) && +split(l, ' ')[0] > now - 86400) o += l + '\n'; writefile(f + '.t', o); rename(f + '.t', f); };
	keep(D24); keep(DR);
	if (!S.st || now - S.st >= 6 * 3600) persist(S);
}
let c = S.cur ?? { h: hr, n: 0, tc: {}, drops: 0, down: 0, nosig: 0 };
c.n++;
if (length(tech)) c.tc[tech] = (c.tc[tech] ?? 0) + 1; else c.nosig++;
c.lr = acc(c.lr, lr); c.lq = acc(c.lq, lq); c.ls = acc(c.ls, ls); c.nr = acc(c.nr, nr); c.nq = acc(c.nq, nq); c.ns = acc(c.ns, ns);
c.drops += length(drops);
if (up === 0) c.down++;
S.cur = c;
S.now = summary(c);
S.t = now;
let f = open(D24, 'a');
if (f) { f.write(join(' ', [ now, length(tech) ? tech : '-', v(lr), v(lq), v(ls), v(nr), v(nq), v(ns), up == null ? '-' : up ]) + '\n'); f.close(); }
writefile(TMP + '.t', sprintf('%J', S)); rename(TMP + '.t', TMP);
done(0);
