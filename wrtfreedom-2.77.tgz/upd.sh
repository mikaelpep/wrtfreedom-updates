#!/bin/sh
# WrtFreedom: aggiornamenti dal server, firmati (usign, la stessa firma di OpenWrt)
# uso: upd.sh check            scarica latest.json e la firma, li verifica → /tmp/wf-upd.json (solo se la firma è giusta)
#      upd.sh safe [tg]        bot e Pianificazioni: controlli (firma, versione, app minima), poi aggiornamento con copia
#                              e ritorno (updsafe start kind wf), seguito da una copia staccata (tg = esito su Telegram)
#      upd.sh follow [tg] [job] copia staccata che segue il lavoro (job = righe «## » per /tmp/.wf-job, updpkg dell'app)
#      upd.sh install [tg] [force]  passo di installazione del lavoro con copia e ritorno (upgjob, WF_UPGJOB=1): scarica
#                              il Pacchetto Router, controlla sha256 e app minima, installa. Da solo rifiuta e rimanda a
#                              safe, tranne con force (comando manuale: upd.sh install "" force)
#      upd.sh local            passo di installazione del lavoro con copia e ritorno kind local (solo con WF_UPGJOB=1):
#                              il Pacchetto Router già copiato dall'app in /tmp/wfpkg, senza download
#      upd.sh notify           controllo periodico: evento «disponibile» una volta per versione
#      upd.sh status           versione installata, disponibile e app (testo per il bot)
# permessi normali per quello che si crea: lanciato dall'app passa da rpcd, che ha umask 077, e la web app in
# /www/wrtfreedom diventava leggibile solo da root (Forbidden)
umask 022
BASE=$(uci -q get wrtfreedom.upd.url); BASE=${BASE:-https://raw.githubusercontent.com/mikaelpep/wrtfreedom-updates/main}
W=/usr/share/wrtfreedom; PUB=$W/wrtfreedom-upd.pub; D=/tmp/wf-upd; OUT=/tmp/wf-upd.json; ERR=/tmp/wf-upd.err
mkdir -p $D
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
# a è più nuova di b? (versioni con i punti: 2.9 < 2.10)
newer() { [ -n "$1" ] && [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -t. -k1,1n -k2,2n -k3,3n | tail -n 1)" = "$1" ]; }
get() { # url file
	rm -f "$2"
	if command -v uclient-fetch >/dev/null 2>&1; then uclient-fetch -q -T 30 -O "$2" "$1" >/dev/null 2>&1
	elif command -v curl >/dev/null 2>&1; then curl -fsSL -m 300 -o "$2" "$1" >/dev/null 2>&1
	else wget -q -T 30 -O "$2" "$1" >/dev/null 2>&1; fi
	[ -s "$2" ]
}
fail() { echo "$1" > $ERR; return 1; }
check() {
	command -v usign >/dev/null 2>&1 || { fail nousign; return 1; }
	[ -f "$PUB" ] || { fail nokey; return 1; }
	get "$BASE/latest.json" $D/latest.json && get "$BASE/latest.json.sig" $D/latest.json.sig || { fail net; return 1; }
	usign -V -q -p "$PUB" -m $D/latest.json -x $D/latest.json.sig >/dev/null 2>&1 || { fail sig; return 1; }
	cp $D/latest.json $OUT.t && mv $OUT.t $OUT; rm -f $ERR
}
jf() { jsonfilter -i $OUT -e "$1" 2>/dev/null; }
tg() { [ "$TG" = 1 ] && ubus call wrtfreedom tgsend "{\"bg\":true,\"text\":\"$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g')\"}" >/dev/null 2>&1; }
cur() { cat $W/VERSION 2>/dev/null; }
# una sola regola dell'app minima (come Software › Pacchetto Router): il pacchetto del manifesto chiede un'app più nuova
# di quella che il telefono ha detto al router (/etc/wrtfreedom/appver)? Allora stampa il motivo ed esce con 1.
# Senza app conosciuta o senza minapp nel manifesto si installa (web app e app per Windows usano la web app del pacchetto)
# (la stessa regola è appchk in wrtfreedom.uc, per updsafe start)
appget() {
	# appver più vecchia di 30 giorni: il telefono di allora può essere già aggiornato o non esserci più, non conta
	m=$(jf '@.pkg.minapp'); a=
	[ -n "$(find /etc/wrtfreedom/appver -mtime +30 2>/dev/null)" ] || a=$(cat /etc/wrtfreedom/appver 2>/dev/null)
}
appmin() {
	appget
	[ -n "$m" ] && [ -n "$a" ] && newer "$m" "$a" || return 0
	t "la versione $(jf '@.pkg.v') ha bisogno dell'app $m o più nuova (sul telefono $a): aggiorna prima l'app" "version $(jf '@.pkg.v') needs app $m or newer (on the phone $a): update the app first"
	return 1
}
# causa 7: minapp nel manifesto e app sconosciuta = avviso (bot e Pianificazioni lo scrivono e vanno avanti con appok)
appunk() {
	appget
	[ -n "$m" ] && [ -z "$a" ] || return 0
	t "⚠️ il router non sa quale app usi: la $(jf '@.pkg.v') funziona con l'app $m o più nuova, se la tua è più vecchia aggiornala" "⚠️ the router does not know which app you use: $(jf '@.pkg.v') works with app $m or newer, if yours is older update it"
}
# messaggio dell'esito del controllo del server (check non riuscito)
ckmsg() {
	case "$(cat $ERR 2>/dev/null)" in
		nousign) t "manca usign (il programma che controlla la firma): installalo da Software" "usign is missing (it checks the signature): install it from Software";;
		sig) t "la firma dell'aggiornamento non è valida: niente è stato installato" "the update signature is not valid: nothing was installed";;
		*) t "server non raggiungibile: il router è collegato a internet?" "server not reachable: is the router online?";;
	esac
}
UPGF=/tmp/wf-upg.json
ug() { jsonfilter -i $UPGF -e "$1" 2>/dev/null; }
# causa 7: passo comune di install (dal server) e local (pacchetto copiato dall'app): il pacchetto è già estratto in
# /tmp/wfpkg; prima i passi per il ritorno a versioni vecchie, poi il suo install.sh; /tmp/wfpkg tolto alla fine in ogni caso.
# $1 = versione del pacchetto (install: quella del manifesto firmato, local: /tmp/wfpkg/VERSION)
inst() {
	v=$1
	case "$v" in [0-9]*.[0-9]*) ;; *) rm -rf /tmp/wfpkg; m=$(t "pacchetto senza versione" "package without version"); echo "## ERRORE $m"; tg "❌ $m"; return 1;; esac
	# ritorno a un pacchetto fino alla 2.67: una modifica delle Pianificazioni in attesa di conferma torna prima com'era (con
	# una in attesa vpnwd e ddnswd restore non cambiano niente, 2.68: una modifica alla volta)
	newer 2.68 "$v" && [ -f /etc/wrtfreedom/bak/cron/back.sh ] && sh /etc/wrtfreedom/bak/cron/back.sh >/dev/null 2>&1
	# ritorno a un pacchetto fino alla 2.66 (non conosce wrtfreedom.wgwd.susp): righe dell'utente spente dal Controllo Della VPN
	# Per Fuori Casa (2.67) riaccese prima (vpnwd restore)
	newer 2.67 "$v" && ubus -t 20 call wrtfreedom vpnwd '{"action":"restore"}' >/dev/null 2>&1
	# ritorno a un pacchetto fino alla 2.67 (non conosce wrtfreedom.ddnswd.susp): righe e ganci dell'utente spenti dal Controllo
	# Del Nome Di Casa (2.68) rimessi prima (ddnswd restore)
	newer 2.68 "$v" && ubus -t 20 call wrtfreedom ddnswd '{"action":"restore"}' >/dev/null 2>&1
	o=$(sh /tmp/wfpkg/install.sh 2>&1); echo "$o"; rm -rf /tmp/wfpkg
	if echo "$o" | grep -q '^## OK'; then
		# ritorno a un pacchetto fino alla 2.65 (non conosce il Rinnovo Dei Certificati, 2.66): il gancio 91 di acme e la sua
		# riga in sysupgrade.conf tolti, solo a installazione riuscita (se non riesce resta il pacchetto di adesso)
		newer 2.66 "$v" && { rm -f /etc/hotplug.d/acme/91-wrtfreedom; [ -f /etc/sysupgrade.conf ] && sed -i '\#^/etc/hotplug.d/acme/91-wrtfreedom$#d' /etc/sysupgrade.conf; }
		tg "✅ $(t "Pacchetto Router aggiornato alla" "Router Package updated to") $(cur)"
	else tg "❌ $(t "Aggiornamento non riuscito" "Update failed"): $(echo "$o" | sed -n 's/^## ERRORE //p' | tail -n 1)"; fi
}

case "$1" in
check)
	check ;;
safe)
	# Bot e Pianificazioni: lo stesso aggiornamento con copia e ritorno dell'app (updsafe start kind wf). Qui
	# solo i controlli (firma, versione, app minima) e l'avvio; segue il lavoro una copia staccata (follow), perché
	# l'installazione riavvia rpcd e il bot
	TG=0; [ "$2" = tg ] && TG=1
	check || { m=$(ckmsg); echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	v=$(jf '@.pkg.v')
	newer "$v" "$(cur)" || { m="$(t "Pacchetto Router già aggiornato" "Router Package already up to date") ($(cur))"; echo "## OK $(cur)"; echo "$m"; tg "✅ $m"; exit 0; }
	m=$(appmin) || { echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	w=$(appunk)
	r=$(ubus -t 30 call wrtfreedom updsafe '{"action":"start","kind":"wf","secs":900,"appok":true}' 2>/dev/null)
	if ! printf '%s' "$r" | grep -q '"started": *true'; then
		m=$(printf '%s' "$r" | jsonfilter -e '@.error' 2>/dev/null); m=${m:-$(t "aggiornamento non avviato" "update not started")}
		echo "## ERRORE $m"; tg "❌ $(t "Aggiornamento non avviato" "Update not started"): $m"; exit 1
	fi
	echo "## $(t "Copio le impostazioni e installo la" "Backing up the settings and installing") $v"
	[ -n "$w" ] && { echo "$w"; tg "$w"; }
	# copia in /tmp: l'installazione riscrive upd.sh mentre la copia staccata lo legge
	cp "$0" $D/follow.sh
	if command -v start-stop-daemon >/dev/null 2>&1; then start-stop-daemon -S -b -m -p $D/follow.pid -x /bin/sh -- $D/follow.sh follow "$2" </dev/null >/dev/null 2>&1
	elif command -v setsid >/dev/null 2>&1; then setsid sh $D/follow.sh follow "$2" </dev/null >/dev/null 2>&1 &
	else ( sh $D/follow.sh follow "$2" ) </dev/null >/dev/null 2>&1 & fi
	;;
follow)
	# segue il lavoro con copia e ritorno: router di nuovo raggiungibile dopo l'installazione (wait) = confermato subito,
	# come il riavvio dei servizi vitali dal bot; errore o ritorno = esito su Telegram. Se questa copia si ferma, senza
	# conferma il lavoro rimette da solo la versione di prima dopo 900 s.
	# job (updpkg dell'app): righe «## » del passo e alla fine «## OK versione» o «## ERRORE motivo», per le app che
	# seguono /tmp/.wf-job (updpkg ci aggiunge __FINE__)
	# causa 7: anche gli aggiornamenti dei pacchetti e i file di Software (pkgdo upgrade e addfile delle app vecchie): i
	# testi seguono il tipo (kind) del lavoro
	TG=0; [ "$2" = tg ] && TG=1; J=0; [ "$3" = job ] && J=1; i=0; p=copy
	while [ $i -lt 600 ]; do
		sleep 2; i=$((i+1)); s=$(ug '@.st'); K=$(ug '@.kind'); WK=0; case "$K" in wf|local|'') WK=1;; esac
		if [ $J = 1 ] && [ -n "$s" ] && [ "$s" != "$p" ]; then
			p=$s
			case "$s" in
			install) case "$K" in
				wf) echo "## $(t "Scarico, controllo la firma e installo la" "Downloading, checking the signature and installing") $(ug '@.to')" ;;
				local) echo "## $(t "Installo il pacchetto dell'app" "Installing the app package") $(ug '@.to')" ;;
				*) echo "## $(t "Provo senza installare, poi installo" "Trying without installing, then installing"): $(ug '@.name')" ;;
				esac ;;
			wait) if [ $WK = 1 ]; then echo "## $(t "Il router risponde con la versione nuova: confermo" "The router answers with the new version: confirming")"; else echo "## $(t "Il router risponde: confermo" "The router answers: confirming")"; fi ;;
			esac
		fi
		case "$s" in
		wait) ubus -t 20 call wrtfreedom updsafe '{"action":"confirm"}' >/dev/null 2>&1 ;;
		ok) if [ $WK = 1 ]; then [ $J = 1 ] && echo "## OK $(cur)"; tg "✅ $(t "Pacchetto Router aggiornato alla" "Router Package updated to") $(cur)"
			else [ $J = 1 ] && echo "## OK $(ug '@.name')"; tg "✅ $(t "Pacchetti aggiornati e confermati" "Packages updated and confirmed"): $(ug '@.name')"; fi; exit 0 ;;
		back) bp=$(cat /tmp/wf-bg.upg.pid 2>/dev/null); case "$bp" in ''|*[!0-9]*) ;; *) [ -d /proc/$bp ] && continue;; esac
			if [ $WK = 1 ]; then m="$(t "Aggiornamento non riuscito, rimessa la versione di prima" "Update failed, previous version restored"): $(ug '@.msg')"
			else m="$(t "Non riuscito, impostazioni rimesse com'erano" "Failed, settings restored"): $(ug '@.msg')"; fi
			[ $J = 1 ] && echo "## ERRORE $m"; tg "↩️ $m"; exit 0 ;;
		err) m="$(t "Aggiornamento non riuscito" "Update failed"): $(ug '@.msg')"; [ $J = 1 ] && echo "## ERRORE $m"; tg "❌ $m"; exit 0 ;;
		esac
	done
	[ $J = 1 ] && echo "## ERRORE $(t "nessun esito dall'aggiornamento entro 20 minuti: guarda Aggiornamenti con copia e ritorno" "no result from the update within 20 minutes: see Updates with backup and restore")"
	;;
install)
	TG=0; [ "$2" = tg ] && TG=1
	# causa 7: un solo percorso sicuro. Da solo (senza il lavoro con copia e ritorno, che mette WF_UPGJOB=1) rifiuta e
	# rimanda a safe; resta il comando manuale con force
	[ "$WF_UPGJOB" = 1 ] || [ "$3" = force ] || { echo "## ERRORE $(t "aggiorna con copia e ritorno: upd.sh safe (o dall'app)" "update with backup and rollback: upd.sh safe (or from the app)")"; exit 1; }
	echo "## $(t "Controllo il server degli aggiornamenti" "Checking the update server")"
	check || { m=$(ckmsg); echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	v=$(jf '@.pkg.v'); f=$(jf '@.pkg.file'); h=$(jf '@.pkg.sha256')
	case "$f" in ''|*[!A-Za-z0-9._-]*) echo "## ERRORE $(t "elenco degli aggiornamenti non valido" "invalid update list")"; exit 1;; esac
	newer "$v" "$(cur)" || [ "$3" = force ] || { m="$(t "Pacchetto Router già aggiornato" "Router Package already up to date") ($(cur))"; echo "## OK $(cur)"; echo "$m"; tg "✅ $m"; exit 0; }
	# app minima (G4): un pacchetto che l'app del telefono non sa usare non si installa, nemmeno con force
	m=$(appmin) || { echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	echo "## $(t "Scarico la versione" "Downloading version") $v"
	get "$BASE/$f" /tmp/wf-pkg.tgz || { m=$(t "download non riuscito" "download failed"); echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	[ "$(sha256sum /tmp/wf-pkg.tgz | cut -d' ' -f1)" = "$h" ] || { rm -f /tmp/wf-pkg.tgz; m=$(t "il file scaricato non corrisponde a quello firmato" "the downloaded file does not match the signed one"); echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	echo "## $(t "File verificato, installo" "File verified, installing")"
	rm -rf /tmp/wfpkg && mkdir -p /tmp/wfpkg && tar xzf /tmp/wf-pkg.tgz -C /tmp/wfpkg || { echo "## ERRORE $(t "archivio non valido" "invalid archive")"; exit 1; }
	inst "$v"
	;;
local)
	# causa 7: kind local di updsafe (pacchetto copiato dall'app, sha256 controllato dall'app); solo dal lavoro con copia e ritorno
	TG=0
	[ "$WF_UPGJOB" = 1 ] || { echo "## ERRORE $(t "aggiorna con copia e ritorno (dall'app)" "update with backup and rollback (from the app)")"; exit 1; }
	[ -f /tmp/wfpkg/install.sh ] || { echo "## ERRORE $(t "nessun Pacchetto Router copiato dall'app: copialo di nuovo" "no Router Package copied from the app: copy it again")"; exit 1; }
	v=$(cat /tmp/wfpkg/VERSION 2>/dev/null)
	echo "## $(t "Installo il pacchetto dell'app" "Installing the app package") $v"
	inst "$v"
	;;
notify)
	[ "$(uci -q get wrtfreedom.upd.check)" = 0 ] && exit 0
	check || exit 0
	S=/etc/wrtfreedom/upd.seen; touch $S
	v=$(jf '@.pkg.v')
	if newer "$v" "$(cur)" && ! grep -qx "pkg $v" $S; then
		echo "pkg $v" >> $S
		sh $W/event.sh upd pkg "📦 $(t "Pacchetto Router $v disponibile (installato $(cur))" "Router Package $v available (installed $(cur))")"
	fi
	# app Android: solo se il telefono ha detto al router la sua versione (Software › Pacchetto Router)
	a=$(jf '@.app.v'); have=$(cat /etc/wrtfreedom/appver 2>/dev/null)
	if [ -n "$have" ] && newer "$a" "$have" && ! grep -qx "app $a" $S; then
		echo "app $a" >> $S
		sh $W/event.sh upd app "📱 $(t "App WrtFreedom $a disponibile (sul telefono $have)" "WrtFreedom app $a available (on the phone $have)")"
	fi
	;;
status)
	check
	v=$(jf '@.pkg.v'); a=$(jf '@.app.v')
	echo "📦 $(t "Pacchetto Router" "Router Package"): $(cur)"
	if [ -f $ERR ] && [ ! -s $OUT ]; then case "$(cat $ERR)" in nousign) t "⚠️ Manca usign: non posso controllare gli aggiornamenti" "⚠️ usign is missing: cannot check for updates";; *) t "⚠️ Server degli aggiornamenti non raggiungibile" "⚠️ Update server not reachable";; esac; echo; exit 0; fi
	if newer "$v" "$(cur)"; then echo "🆕 $(t "Disponibile" "Available"): $v · /$(t aggiorna_pacchetto update_package)"; else t "✅ Aggiornato" "✅ Up to date"; echo; fi
	[ -n "$a" ] && echo "📱 $(t "App WrtFreedom" "WrtFreedom app"): $a"
	;;
*)
	echo "uso: upd.sh check|safe|follow|install|local|notify|status"; exit 1 ;;
esac
