#!/bin/sh
# WrtFreedom: azioni delle Pianificazioni (preset di «Cosa Fare» nell'app, pacchetto 2.40)
# uso: cron.sh <azione> [valore]
# Ogni azione trova da sola i percorsi di questo router (interfaccia della VPN, servizi DDNS, certificati, file di
# AdGuard Home, LED, ponte della rete di casa), così la riga del crontab resta breve e vale su qualsiasi OpenWrt.
# Gli avvisi vanno negli Eventi (event.sh cron): Telegram e telefono secondo le categorie scelte nell'app.
# I controlli avvisano una volta sola per problema (/tmp/wf-cron.<tipo>), non a ogni giro.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom
# WF_CRONTEST = cartella del router finto delle prove (tools/test/router/certadg.sh): prefisso dei percorsi del router e
# comandi finti in bin/; ignorata sul router vero (c'è /etc/openwrt_release), come WF_WDTEST di watchdog.sh
P0=; [ -n "$WF_CRONTEST" ] && [ ! -e /etc/openwrt_release ] && { P0=$WF_CRONTEST; PATH=$P0/bin:$PATH; }
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh "$P0$W/event.sh" cron "$1" "$2" "$3"; }	# tipo categoria testo
quick() { ubus call wrtfreedom quick "{\"act\":\"$1\"${2:+,\"mac\":\"$2\"}}" >/dev/null 2>&1; }
wgif() { wl_=$(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); for i in $wl_; do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; echo "$wl_" | head -n 1; }	# VPN Per Fuori Casa: con la porta in ascolto, senza il Servizio VPN (come wgiface)
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
mac() { echo "$1" | tr 'A-F' 'a-f' | grep -qE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'; }
# un avviso per problema: once <tipo> <secondi> → vero se è passato abbastanza dall'ultimo
once() { f=$P0/tmp/wf-cron.$1; n=$(date +%s); l=$(cat "$f" 2>/dev/null); [ -n "$l" ] && [ $((n - l)) -lt "$2" ] && return 1; echo "$n" > "$f"; }
unflag() { rm -f "$P0/tmp/wf-cron.$1"; }
# segni senza scadenza (2.66): raise <tipo> = vero solo se il segno nasce adesso, clear <tipo> = vero solo se c'era
# (/tmp/wf-cron.<tipo>.f: dopo un riavvio al massimo un avviso in più). once e unflag restano per le azioni di oggi
raise() { [ -f "$P0/tmp/wf-cron.$1.f" ] && return 1; : > "$P0/tmp/wf-cron.$1.f"; }
clear() { [ -f "$P0/tmp/wf-cron.$1.f" ] || return 1; rm -f "$P0/tmp/wf-cron.$1.f"; }
# esito nel Registro Delle Esecuzioni (2.66): reg <tag> <esito> [c|r|n] = riga di «wf:<tag>» (svc.uc log, id crhash('wf:<tag>'))
reg() { ucode "$P0$W/svc.uc" log "wf:$1" "$2" "${3:-c}" >/dev/null 2>&1; }
# ora dell'ultima riga del Registro di «wf:<tag>» con il tipo k (2.68; vuota se non c'è), dallo stesso file di crlog di
# wrtfreedom.uc (quello di /tmp, altrimenti la copia salvata). rlast <tag> <c|r|n>
rlast() { ucode -e 'let s = "wf:" + ARGV[0], h = 5381, fs = require("fs"), r = "";
	for (let i = 0; i < length(s); i++) h = ((h * 33) ^ ord(s, i)) & 0x7fffffff;
	for (let l in split(trim(fs.readfile("/tmp/wf-cronrun.log") ?? fs.readfile("/etc/wrtfreedom/cronrun.log") ?? ""), "\n")) {
		let m = match(l, /^([0-9]{1,12})\|([0-9a-f]{8})\|-?[0-9]{1,5}\|([crn])$/); if (m && m[2] == sprintf("%08x", h) && m[3] == ARGV[1]) r = m[1]; }
	print(r);' "$1" "$2" 2>/dev/null; }
# soglia di Salute Del Router (2.54): la sola fonte è hth di wrtfreedom.uc (campo th del metodo health); hth <temp|tempbad|disk|diskbad|mem>
hth() { ubus call wrtfreedom health 2>/dev/null | jsonfilter -e "@.th.$1" 2>/dev/null; }
# file al bot collegato nell'app (sendDocument): tgdoc <file> <didascalia>
tgdoc() {
	TK=$(uci -q get wrtfreedom.tg.token); CH=$(uci -q get wrtfreedom.tg.chat)
	[ -n "$TK" ] && [ -n "$CH" ] && command -v curl >/dev/null || return 1
	# 2.62: indirizzo con il token in un file per curl -K (cartella 0700, come tgbot.uc), mai sulla riga di comando
	mkdir -p /tmp/wf-tg.k && chmod 700 /tmp/wf-tg.k || return 1
	K=/tmp/wf-tg.k/c-$$
	( umask 077; printf 'url = "https://api.telegram.org/bot%s/sendDocument"\n' "$TK" > "$K" )
	curl -s -m 60 -F chat_id="$CH" -F "document=@$1" --form-string "caption=$2" -K "$K" >/dev/null; r=$?
	rm -f "$K"; return $r
}
# regole comuni (2.72, causa 8): homenet (rete di casa) e adgyaml (file di AdGuard Home) di lib.sh, la stessa regola di
# wrtfreedom.uc; lib.sh accanto agli altri file del pacchetto (con le prove sotto $P0, altrimenti accanto a questo file)
for lb_f in "$P0$W/lib.sh" "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
adginit() { for s in adguardhome AdGuardHome; do [ -x "$P0/etc/init.d/$s" ] && { echo $s; return; }; done; }
# dispositivo della rete di casa (homenet di lib.sh); vuoto = rete di casa non trovata
lanbr() { homenet >/dev/null; echo "$HN_DEV"; }
# certificato di AdGuard (2.65): riga di riserva accesa, gancio possibile (notify usato da /usr/lib/acme/hook, come acmenotify
# di wrtfreedom.uc) ma assente: si passa al gancio (certadg on). Una sola regola per certadg e align
adghook() { [ -f "$P0/usr/lib/acme/notify" ] && grep -q notify "$P0/usr/lib/acme/hook" 2>/dev/null && [ ! -f "$P0/etc/hotplug.d/acme/90-wrtfreedom" ] && grep -qE '^[^#].* # wf:certadg$' "$P0/etc/crontabs/root" 2>/dev/null; }
# Rinnovo Dei Certificati (2.66, docs/v2/rinnovo-certificati.md). Nome di un certificato (può avere «*»: sempre tra
# virgolette, con set -f nei cicli) e la sua forma nei nomi dei file dei segni
cname() { echo "$1" | grep -qE '^[A-Za-z0-9*][A-Za-z0-9.*-]{0,252}$'; }
ckey() { printf '%s' "$1" | tr -c 'A-Za-z0-9.-' '_'; }
# file del certificato: il primo che c'è, come certfile di wrtfreedom.uc
cfile() { for f in "$P0/etc/ssl/acme/$1.crt" "$P0/etc/ssl/acme/$1.fullchain.crt" "$P0/etc/acme/${1}_ecc/$1.cer" "$P0/etc/acme/$1/$1.cer"; do [ -f "$f" ] && { echo "$f"; return 0; }; done; return 1; }
# stato dalla sola regola (certrenew get di wrtfreedom.uc): cget = risposta in J; jv = un valore (- se manca); clist = una
# riga per certificato «nome acceso prova scadenza emissione rinnovo»
cget() { J=$(ubus call wrtfreedom certrenew '{"action":"get"}' 2>/dev/null); [ -n "$J" ]; }
jv() { v_=$(printf '%s' "$J" | jsonfilter -e "$1" 2>/dev/null | head -n 1); case "$v_" in ''|null|None) v_=- ;; esac; printf '%s' "$v_"; }
clist() { n_=$(printf '%s' "$J" | jsonfilter -e '@.certs[*].sec' 2>/dev/null | wc -l); i_=0
	while [ $i_ -lt $n_ ]; do echo "$(jv "@.certs[$i_].dom") $(jv "@.certs[$i_].on") $(jv "@.certs[$i_].test") $(jv "@.certs[$i_].na") $(jv "@.certs[$i_].nb") $(jv "@.certs[$i_].due")"; i_=$((i_ + 1)); done; }
# rinnovo riuscito di un nome (gancio 91 di acme a ogni rilascio o rinnovo; certcheck con l'evento perso): una volta per file
# (chiave nome + data del file in /etc/wrtfreedom/certok, scritta solo a ogni rinnovo: il secondo «renewed» di acme.sh non
# conta), evento (issued = «Certificato Emesso»), Registro (non con «check»: certcheck scrive il suo) e «Di Nuovo A Posto»
# solo se c'era il segno. certok <nome> [issued|check]
CK=$P0/etc/wrtfreedom/certok
certok() {
	cname "$1" && [ -d "$P0/tmp" ] || return 1
	exec 9>"$P0/tmp/wf-cron.certok.lock"; flock 9 2>/dev/null
	f=$(cfile "$1"); d=0; [ -n "$f" ] && d=$(date -r "$f" +%s 2>/dev/null); d=${d:-0}
	awk -v n="$1" -v d="$d" '$1 == n && $2 == d { f = 1 } END { exit !f }' "$CK" 2>/dev/null && { exec 9>&-; return 0; }
	mkdir -p "${CK%/*}"; { awk -v n="$1" '$1 != n' "$CK" 2>/dev/null; echo "$1 $d"; } > "$CK.t" && mv "$CK.t" "$CK"
	exec 9>&-
	k=$(ckey "$1"); rm -f "$P0/tmp/wf-cron.certmiss.$k"; clear "certstop.$k"
	if [ "$2" = issued ]; then ev cert sys "🔐 $(t "Certificato Emesso" "Certificate Issued") ($1)"
	else ev cert sys "🔐 $(t "Certificato Rinnovato" "Certificate Renewed") ($1)"; fi
	[ "$2" = check ] || reg certrenew 0
	# tipo proprio (cert_ok, stessa categoria): le regole e i filtri di «Certificato Rinnovato» non scattano per questo
	clear "certrenew.$k" && ev cert_ok sys "✅ $(t "Rinnovo Di Nuovo A Posto" "Renewal Working Again") ($1)"
	return 0
}
# giorno di oggi in ora locale, come notify.sh (il cambio dell'ora non sposta il giorno): lday <secondi> → giorni con il fuso
lday() { z_=$(date +%z 2>/dev/null); o_=0
	case "$z_" in [+-][0-9][0-9][0-9][0-9]) h_=${z_#?}; m_=${h_#??}; h_=${h_%??}; o_=$(( (${h_#0} * 60 + ${m_#0}) * 60 )); [ "${z_%????}" = - ] && o_=$((-o_)) ;; esac
	echo $(( ($1 + o_) / 86400 )); }
# D4 del Rinnovo Dei Certificati (scelta dall'utente il 26/10; la sola regola, solo qui): un rinnovo mancato (rinnovo
# previsto passato da più di un giorno, file non rinnovato) è un'informazione al primo controllo; è un errore se manca
# D4N controlli di fila o se resta meno di 1/D4F della finestra tra rinnovo previsto e scadenza (certificato di 90 giorni
# con rinnovo a 60: finestra di 30 giorni, errore con meno di 10). d4 <controlli mancati di fila> <secondi alla scadenza>
# <finestra in secondi> → vero = errore
D4N=2; D4F=3
d4() { w_=$3; [ "$w_" -lt 0 ] && w_=0; [ "$1" -ge $D4N ] || [ "$2" -lt $((w_ / D4F)) ]; }
# segno del rinnovo non riuscito di un certificato con il motivo dell'avviso (2.68): stop = rinnovo automatico fermo, vuoto =
# non riuscito; Stato Della Casa (casacalc di wrtfreedom.uc) dice lo stesso. Un motivo diverso da quello del segno è un
# problema nuovo (avviso di nuovo). craise <chiave> <stop|> → vero solo se il segno nasce adesso
craise() { f_=$P0/tmp/wf-cron.certrenew.$1.f; [ -f "$f_" ] && [ "$(cat "$f_")" != "$2" ] && rm -f "$f_"; raise "certrenew.$1" || return 1; [ -z "$2" ] || echo "$2" > "$f_"; }
# Controllo Della VPN Per Fuori Casa (2.67, docs/v2/controllo-vpn.md): avvisi di un intervento sulla VPN, una sola regola per il
# giro di wgx.uc (vpnwd), Controlla Ora (vpnwd now) e l'attività pronta vpncheck. vpnres 0 = riaccesa dal router («era spenta:
# riattivata», vpn_fix, anche dopo un «non si riaccende»: il segno si toglie senza un altro avviso), 1 = non riaccesa (un avviso
# per problema: raise vpn), ok = a posto da sola («di nuovo a posto» solo con il segno). «Di nuovo a posto» ha il suo tipo
# (vpn_ok, stessa categoria) e vale solo per ok: le regole di vpn_fix scattano solo quando la riaccende il router
vpnres() {
	case "$1" in
	1) raise vpn && ev vpn_fail net "⚠️ $(t "Server VPN spento e non riattivabile: controlla il router" "VPN Server down and cannot be restarted: check the router")" ;;
	0) clear vpn; ev vpn_fix net "🔐 $(t "Il Server VPN era spento: riattivato" "The VPN Server was down: restarted")" ;;
	ok) clear vpn && ev vpn_ok net "✅ $(t "Server VPN Di Nuovo A Posto" "VPN Server Working Again")" ;;
	esac
	return 0
}
# Controllo Del Nome Di Casa (2.68, docs/v2/controllo-nome.md). ddrun = cartella di ddns-scripts (ddns_rundir); ddsecs
# [interfaccia] = servizi accesi (enabled 1) di quell'interfaccia (option interface, di serie wan come ddns-scripts; senza:
# tutti), nell'ordine della configurazione e con il nome vero anche per le sezioni anonime (uci -X: cfgXXXXXX, come i file e -S
# di ddns-scripts); ddwant <sez> = IP che il servizio deve avere (fonte network: IP di ip_network, di serie wan o wan6;
# interface: del dispositivo ip_interface; web e script: vuoto, qui non si legge); ddnm <sez> = nome (lookup_host, domain)
ddrun() { r_=$(uci -q get ddns.global.ddns_rundir); echo "$P0${r_:-/var/run/ddns}"; }
ddsecs() { uci -q -X show ddns 2>/dev/null | awk -F= -v I="$1" -v q="'" '{ n = split($1, a, "."); v = substr($0, length($1) + 2); gsub(q, "", v) }
	n == 2 && v == "service" { s[a[2]] = 1; o[++m] = a[2]; f[a[2]] = "wan" } n == 3 && a[3] == "enabled" { e[a[2]] = v } n == 3 && a[3] == "interface" { f[a[2]] = v }
	END { for (i = 1; i <= m; i++) { k = o[i]; if (e[k] == "1" && (I == "" || f[k] == I)) print k } }'; }
ddwant() { s_=$(uci -q get "ddns.$1.ip_source"); v_=$(uci -q get "ddns.$1.use_ipv6")
	case "${s_:-network}" in
	network) n_=$(uci -q get "ddns.$1.ip_network"); k_=ipv4; [ "$v_" = 1 ] && k_=ipv6
		[ -n "$n_" ] || { n_=wan; [ "$v_" = 1 ] && n_=wan6; }
		ifstatus "$n_" 2>/dev/null | jsonfilter -e "@[\"$k_-address\"][0].address" 2>/dev/null ;;
	interface) d_=$(uci -q get "ddns.$1.ip_interface"); [ -n "$d_" ] || return 0
		if [ "$v_" = 1 ]; then ip -6 addr show dev "$d_" scope global 2>/dev/null | sed -n 's/.*inet6 \([0-9a-fA-F:]*\)\/.*/\1/p' | head -n 1
		else ip -4 addr show dev "$d_" 2>/dev/null | sed -n 's/.*inet \([0-9.]*\)\/.*/\1/p' | head -n 1; fi ;;
	esac; }
ddnm() { n_=$(uci -q get "ddns.$1.lookup_host"); [ -n "$n_" ] || n_=$(uci -q get "ddns.$1.domain"); printf '%s' "${n_:-$1}"; }
# aggiornatore di ddns-scripts per una sezione sola (come 95-ddns: un processo a parte, che ferma quello di prima della
# sezione); senza l'aggiornatore il servizio intero
DDUPD=$P0/usr/lib/ddns/dynamic_dns_updater.sh
ddup() { if [ -x "$DDUPD" ]; then ( "$DDUPD" -S "$1" -- start ) >/dev/null 2>&1 </dev/null & else "$P0/etc/init.d/ddns" restart >/dev/null 2>&1; fi; }
# esito vero di un aggiornamento (RD = ddrun): .update rifatto da ddns-scripts (lo scrive solo dopo un invio accettato) o, con
# l'IP voluto, l'IP registrato (.ip) uguale. dddone <sez> <.update di prima> <IP voluto>; ddwait «sez|update|ip …» = tutti
# entro un minuto (DDW giri di 2 s; WF_DDWAIT solo per il router finto delle prove)
DDW=30; [ -n "$P0" ] && [ -n "$WF_DDWAIT" ] && DDW=$WF_DDWAIT
dddone() { u_=$(cat "$RD/$1.update" 2>/dev/null); [ -n "$u_" ] && [ "$u_" != "$2" ] && return 0; [ -n "$3" ] && [ "$(cat "$RD/$1.ip" 2>/dev/null)" = "$3" ]; }
ddwait() { i_=0
	while :; do
		m_=0; for x_ in $1; do s_=${x_%%|*}; r_=${x_#*|}; dddone "$s_" "${r_%%|*}" "${r_#*|}" || m_=1; done
		[ $m_ = 0 ] && return 0; [ $i_ -ge $DDW ] && return 1; sleep 2; i_=$((i_ + 1))
	done; }
# aggiornamento forzato di una sezione (come «Aggiorna Ora»: senza .update ddns-scripts manda l'IP anche se lo crede giusto)
ddforce() { RD=$(ddrun); rm -f "$RD/$1.update"; ddup "$1"; ddwait "$1||"; }
# il controllo è acceso e lo fa il router (la sola regola: ddnswd get di wrtfreedom.uc, how svc)
ddhow() { [ "$(ubus call wrtfreedom ddnswd '{"action":"get"}' 2>/dev/null | jsonfilter -e '@.how' 2>/dev/null)" = svc ]; }
# 95-ddns di ddns-scripts sente ifupdate (le versioni nuove, con IFUPDATE_ADDRESSES): allora aggiorna lui al cambio di IP
ddhear() { grep -qE '^[^#]*ifupdate[^#]*\)' "$P0/etc/hotplug.d/iface/95-ddns" 2>/dev/null; }
# controllo del nome (svc.uc name, esito aspettato al massimo un minuto) e regola dei controlli «old» per sezione: con CGNAT
# niente conto; ok = conto e aggiornamento forzato rimessi, «di nuovo a posto» solo se c'era il segno; old = conto + 1; wait,
# none, nopub, off = conto a zero. Al terzo old di fila un aggiornamento forzato (una volta per problema: f, scritto prima del
# forzato), esito nel Registro (wf:ddnscheck 0 o 1); errore ddns_fail una volta (raise ddns.<sez>) se il forzato non riesce o
# se dopo un forzato riuscito (conto di nuovo a zero) il nome è ancora vecchio tre volte di fila. Un esito già contato (stessa
# ora t) non conta di nuovo. Mai due controlli insieme (due nomi cambiati nello stesso minuto: due chg): blocco
# /tmp/wf-cron.ddnschk.lock che scade dopo 5 minuti, il secondo non fa niente (il controllo legge tutti i nomi). Un nome old
# ancora senza errore = ricontrollo dopo DDRE secondi (ora in /tmp/wf-cron.ddnsre, la guarda il giro di notify.sh: cron.sh
# ddnswd re), così il forzato arriva in circa 30 minuti; nessun old da seguire (o CGNAT) = ricontrollo tolto. «Di nuovo a
# posto» ha il suo tipo (ddns_ok, stessa categoria). Sezioni anonime con il nome vero (id di svc.uc name, come ddns-scripts)
DDRE=600
ddchk() {
	LK=$P0/tmp/wf-cron.ddnschk.lock
	if ! mkdir "$LK" 2>/dev/null; then
		n=$(date +%s); m=$(date -r "$LK" +%s 2>/dev/null || echo "$n")
		[ $((n - m)) -lt 300 ] && return 0
		rm -rf "$LK"; mkdir "$LK" 2>/dev/null || return 0
	fi
	ddchk1; rmdir "$LK" 2>/dev/null
	return 0
}
ddchk1() {
	# 2.68: segni e conti dei nomi spenti o tolti via in silenzio (non sono più un problema da seguire; wddown di wrtfreedom.uc
	# conta già solo i nomi accesi)
	AS=" $(ddsecs | tr '\n' ' ') "
	for f in "$P0"/tmp/wf-cron.ddns.*.f "$P0"/tmp/wf-cron.ddnsold.*; do
		[ -f "$f" ] || continue
		b=${f##*/}; case "$b" in wf-cron.ddnsold.*) s=${b#wf-cron.ddnsold.} ;; *) s=${b#wf-cron.ddns.}; s=${s%.f} ;; esac
		case "$AS" in *" $s "*) ;; *) rm -f "$f" ;; esac
	done
	F=$P0/tmp/wf-ddnsname.json; t0=$(date +%s)
	ucode "$P0$W/svc.uc" name >/dev/null 2>&1
	i=0; while [ $i -lt 30 ]; do [ "$(jsonfilter -i "$F" -e '@.t' 2>/dev/null)" -ge "$t0" ] 2>/dev/null && break; sleep 2; i=$((i + 1)); done
	set -- $(ucode -e 'let j = json(require("fs").readfile(ARGV[0]) ?? "null"); if (type(j) == "object") { print(int(+(j.t ?? 0)), j.cgnat ? " 1\n" : " 0\n");
		for (let x in j.list ?? []) { let s = "" + (x.id ?? x.sec); if (match(s, /^[A-Za-z0-9_]{1,64}$/) && match("" + x.why, /^[a-z]{1,8}$/)) print(s, " ", x.why, "\n"); } }' "$F" 2>/dev/null)
	[ $# -ge 2 ] && [ "$1" -ge "$t0" ] 2>/dev/null || return 0
	TF=$P0/tmp/wf-cron.ddnst; [ "$1" = "$(cat "$TF" 2>/dev/null)" ] && return 0; echo "$1" > "$TF"
	RE=$P0/tmp/wf-cron.ddnsre; re=0
	[ "$2" = 1 ] && { rm -f "$RE"; return 0; }
	shift 2
	while [ $# -ge 2 ]; do
		s=$1; y=$2; shift 2
		OF=$P0/tmp/wf-cron.ddnsold.$s; n=0; f=0; [ -f "$OF" ] && read -r n f < "$OF"
		case "$n$f" in *[!0-9]*|'') n=0; f=0 ;; esac
		case "$y" in
		ok) rm -f "$OF"; clear "ddns.$s" && ev ddns_ok net "✅ $(t "Nome Di Nuovo A Posto" "Name Working Again") ($(ddnm "$s"))" ;;
		old) n=$((n + 1))
			if [ $n -ge 3 ] && [ "$f" != 1 ]; then
				f=1; echo "$n $f" > "$OF"; ddforce "$s"; r=$?; reg ddnscheck $r
				if [ $r = 0 ]; then n=0
				else raise "ddns.$s" && ev ddns_fail net "⚠️ $(t "Il Nome Non Si Aggiorna" "The Name Is Not Updating") ($(ddnm "$s"))"; fi
			elif [ $n -ge 3 ]; then raise "ddns.$s" && ev ddns_fail net "⚠️ $(t "Il Nome Non Si Aggiorna" "The Name Is Not Updating") ($(ddnm "$s"))"
			fi
			echo "$n $f" > "$OF"
			[ -f "$P0/tmp/wf-cron.ddns.$s.f" ] || re=1 ;;
		*) echo "0 $f" > "$OF" ;;
		esac
	done
	if [ $re = 1 ]; then echo $(( $(date +%s) + DDRE )) > "$RE"; else rm -f "$RE"; fi
	return 0
}

A="$1"; X="$2"
case "$A" in
# ---------- Router ----------
ledoff)	# salva lo stato di ogni spia (una volta) e le spegne; valore = spie da lasciare come sono, con la virgola (Spie Di Notte)
	# 5g-led-bars (quectel-5g-tools, servizio di terzi) riscrive ogni pochi secondi le spie *5g:led* del segnale: se è
	# acceso e almeno una di quelle spie va spenta, lo si mette solo in pausa (stop, mai file o configurazione) e il segno
	# dice a ledon di farlo ripartire; se l'utente l'aveva già fermato resta com'è
	# acceso = un'istanza viva per procd (2.72, causa 8: non il percorso del programma)
	B=5g-led-bars; S=$P0/tmp/wf-leds.save
	if [ -x "$P0/etc/init.d/$B" ] && ubus call service list "{\"name\":\"$B\"}" 2>/dev/null | jsonfilter -e '@[*].instances[*].running' 2>/dev/null | grep -q true; then
		for l in $P0/sys/class/leds/*5g:led*; do
			[ -d "$l" ] || continue
			case ",$X," in *",${l##*/},"*) continue ;; esac
			"$P0/etc/init.d/$B" stop >/dev/null 2>&1; : > $P0/tmp/wf-leds.5gbars; break
		done
	fi
	for l in $P0/sys/class/leds/*; do
		[ -d "$l" ] || continue
		case ",$X," in *",${l##*/},"*) continue ;; esac
		[ -f $S ] || echo "${l##*/}|$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$l/trigger")|$(cat "$l/brightness")" >> $S.t
		echo none > "$l/trigger" 2>/dev/null; echo 0 > "$l/brightness" 2>/dev/null
	done
	[ -f $S.t ] && mv $S.t $S ;;
ledon)	# rimette lo stato salvato e le impostazioni LED del router; 5g-led-bars riparte solo se l'ha fermato ledoff (segno)
	B=5g-led-bars; S=$P0/tmp/wf-leds.save
	if [ -f $S ]; then
		while IFS='|' read -r n tr b; do
			[ -d "$P0/sys/class/leds/$n" ] || continue
			echo "${tr:-none}" > "$P0/sys/class/leds/$n/trigger" 2>/dev/null
			[ "${tr:-none}" = none ] && echo "${b:-0}" > "$P0/sys/class/leds/$n/brightness" 2>/dev/null
		done < $S
		rm -f $S
	fi
	[ -x $P0/etc/init.d/led ] && $P0/etc/init.d/led restart >/dev/null 2>&1
	if [ -f $P0/tmp/wf-leds.5gbars ]; then
		[ -x "$P0/etc/init.d/$B" ] && "$P0/etc/init.d/$B" start >/dev/null 2>&1
		rm -f $P0/tmp/wf-leds.5gbars
	fi ;;
memfree) sync; echo 3 > /proc/sys/vm/drop_caches ;;
ntpsync) # client NTP del router: sysntpd (BusyBox), altrimenti chrony o ntpd
	for s in sysntpd chronyd ntpd; do [ -x /etc/init.d/$s ] && { /etc/init.d/$s restart >/dev/null 2>&1; exit 0; }; done ;;
svc)	# riavvia un servizio di /etc/init.d
	echo "$X" | grep -qE '^[A-Za-z0-9_.-]{1,40}$' && [ -x "/etc/init.d/$X" ] || { echo "servizio non valido"; exit 1; }
	/etc/init.d/$X restart >/dev/null 2>&1 ;;
ifrestart) # riavvia un'interfaccia di rete
	echo "$X" | grep -qE '^[A-Za-z0-9_]{1,32}$' && [ "$(uci -q get network.$X)" = interface ] || { echo "interfaccia non valida"; exit 1; }
	ifup "$X" ;;

# ---------- Linea e modem ----------
signalcheck) # avvisa se il segnale del modem è sotto la soglia (RSRP, di serie −110 dBm)
	r=$(ucode -e 'let M=loadfile("/usr/share/wrtfreedom/modem.uc")(),s=M.state().n;print(s.lte?.rsrp ?? s.nr?.rsrp ?? "")' 2>/dev/null)
	[ -n "$r" ] || exit 0; lim=${X:--110}
	r=${r%.*}
	if [ "$r" -lt "$lim" ]; then once signal 7200 && ev signal net "📶 $(t "Segnale scarso" "Weak signal"): $r dBm"; else unflag signal; fi ;;
modemreport) # Rapporto Modem come file al bot
	mkdir -p /tmp/wf-tgfile && chmod 700 /tmp/wf-tgfile
	f=/tmp/wf-tgfile/$(t Rapporto-Modem Modem-Report).txt
	ucode $W/modemctl.uc report > "$f" 2>/dev/null
	tgdoc "$f" "📡 $(t "Rapporto Modem" "Modem Report") · $(uci -q get system.@system[0].hostname)"; rm -f "$f" ;;

# ---------- VPN e DNS ----------
vpncheck) # riattiva la VPN se è giù (non se è spenta apposta); 2.67: avvisi con il segno senza scadenza (vpnres), come il
	# Controllo Della VPN Per Fuori Casa
	i=$(wgif); [ -n "$i" ] || exit 0
	[ "$(uci -q get network.$i.disabled)" = 1 ] && exit 0
	ok() { isup "$i" || return 1; command -v wg >/dev/null || return 0; wg show "$i" >/dev/null 2>&1; }
	ok && { vpnres ok; exit 0; }
	logger -t wrtfreedom-cron "VPN $i giù, la riattivo"
	ifup "$i"; sleep 15
	if ok; then vpnres 0; else vpnres 1; fi ;;
vpnwd)	# Controllo Della VPN Per Fuori Casa (2.67, dal giro di wgx.uc tick): up <interfaccia> = ifup in un processo a parte con il
	# blocco /tmp/wf-vpnwd.lock (scade dopo 2 minuti: mai due insieme); fix|fail = verifica al giro dopo l'ifup (Registro
	# wf:vpncheck 0 o 1, avvisi di vpnres); ok = a posto da sola («di nuovo a posto» solo con il segno); clr = segno tolto
	# senza avviso (controllo spento); now = Controlla Ora (2.68, dal metodo vpnwd run)
	case "$X" in
	up)	i=$3; echo "$i" | grep -qE '^[A-Za-z0-9_]{1,32}$' || exit 1
		# mai il Servizio VPN (wgout, wgoN)
		echo "$i" | grep -qE '^wgo(ut|[0-9]+)$' && exit 1
		LK=$P0/tmp/wf-vpnwd.lock
		if ! mkdir "$LK" 2>/dev/null; then
			n=$(date +%s); m=$(date -r "$LK" +%s 2>/dev/null || echo "$n")
			[ $((n - m)) -lt 120 ] && exit 0
			rm -rf "$LK"; mkdir "$LK" 2>/dev/null || exit 0
		fi
		# subito prima di ifup: spenta apposta nel frattempo (disabled, autostart falso) = niente
		if [ "$(uci -q get network.$i.disabled)" = 1 ] || [ "$(ifstatus "$i" 2>/dev/null | jsonfilter -e '@.autostart' 2>/dev/null)" = false ]; then
			rmdir "$LK"; exit 0
		fi
		logger -t wrtfreedom-cron "VPN $i giù, la riattivo"
		ifup "$i"; r=$?; rmdir "$LK"; exit $r ;;
	fix) reg vpncheck 0; vpnres 0 ;;
	fail) reg vpncheck 1; vpnres 1 ;;
	ok) vpnres ok ;;
	clr) clear vpn ;;
	now) # Controlla Ora (2.68, vpnwd run in sottofondo): come vpncheck (spenta apposta = niente), con il blocco dell'ifup del
		# giro (con un suo ifup in corso si aspetta, mai due insieme). Esito in /tmp/wf-vpnwdrun.json { t, state ok|err, fix
		# (riaccesa adesso), msg } per vpnwd get (run). Registro wf:vpncheck (k = n) e avvisi solo con un intervento: un controllo
		# senza niente da fare non è «riaccesa». Riaccesa da qui = stato del giro tolto (niente secondo «riattivata» dal giro)
		RF=$P0/tmp/wf-vpnwdrun.json
		rs() { printf '{"t":%s,"state":"%s","fix":%s,"msg":"%s"}\n' "$(date +%s)" "$1" "$2" "$3" > "$RF.t" && mv "$RF.t" "$RF"; exit 0; }
		i=$(wgif); [ -n "$i" ] || rs err false "$(t "Server VPN non configurato" "VPN Server not set up")"
		if [ "$(uci -q get network.$i.disabled)" = 1 ] || [ "$(ifstatus "$i" 2>/dev/null | jsonfilter -e '@.autostart' 2>/dev/null)" = false ]; then
			rs ok false "$(t "VPN spenta apposta: non la riaccendo" "VPN turned off on purpose: not restarting it")"
		fi
		vok() { isup "$i" || return 1; command -v wg >/dev/null || return 0; wg show "$i" >/dev/null 2>&1; }
		vok && { vpnres ok; rs ok false "$(t "VPN a posto" "VPN working")"; }
		LK=$P0/tmp/wf-vpnwd.lock; n=0
		until mkdir "$LK" 2>/dev/null; do
			m=$(date -r "$LK" +%s 2>/dev/null || echo 0)
			if [ $(( $(date +%s) - m )) -ge 120 ]; then rm -rf "$LK"
			elif [ $n -ge 10 ]; then rs err false "$(t "Il router la sta già riaccendendo" "The router is already restarting it")"
			else sleep 2; n=$((n + 1)); fi
		done
		# preso il blocco: già a posto (riaccesa dall'ifup di chi aveva il blocco, il giro o un altro Controlla Ora, che dà lui
		# l'esito e gli avvisi) = niente ifup né avvisi
		vok && { rmdir "$LK"; rs ok false "$(t "VPN a posto" "VPN working")"; }
		logger -t wrtfreedom-cron "VPN $i giù, la riattivo (Controlla Ora)"
		# attesa della verifica come vpncheck (WF_VPNWAIT solo per il router finto delle prove)
		w=15; [ -n "$P0" ] && [ -n "$WF_VPNWAIT" ] && w=$WF_VPNWAIT
		ifup "$i"; rmdir "$LK"; sleep "$w"
		if vok; then rm -f /tmp/wf-vpnwd.json; reg vpncheck 0 n; vpnres 0; rs ok true "$(t "VPN riaccesa" "VPN back on")"
		else reg vpncheck 1 n; vpnres 1; rs err false "$(t "La VPN non si riaccende" "The VPN does not come back on")"; fi ;;
	*) exit 1 ;;
	esac ;;
ddnscheck) # IP della linea cambiato: i servizi DDNS si aggiornano subito. 2.68 (docs/v2/controllo-nome.md): ddnscheck
	# [interfaccia] [q] = solo i servizi accesi di quell'interfaccia (senza: tutti); riavviato solo chi ha l'IP registrato
	# (<sez>.ip nella cartella di ddns-scripts) diverso da quello voluto (ddwant), una volta per IP voluto (l'ultimo mandato e
	# accettato è in /tmp/wf-cron.ddnsw.<sez>: <sez>.ip, letto dal DNS, può non arrivarci mai). Fonte web o script (IP voluto
	# non letto qui): con l'interfaccia sempre (è appena cambiata), senza come prima, una volta per IP della linea (rotta di
	# serie) cambiato. Esce con l'esito vero: 0 = a posto o aggiornati, 1 = almeno uno non aggiornato entro un minuto. q = dal
	# gancio del Controllo Del Nome Di Casa (cron.sh ddnswd if): niente avviso, lo dà il giro di notify.sh quando cambia <sez>.ip
	[ -x "$P0/etc/init.d/ddns" ] || exit 0
	[ -z "$X" ] || echo "$X" | grep -qE '^[A-Za-z0-9_.-]{1,32}$' || exit 1
	RD=$(ddrun); U=; IP=; LN=
	for s in $(ddsecs "$X"); do
		w=$(ddwant "$s")
		if [ -n "$w" ]; then
			[ "$(cat "$RD/$s.ip" 2>/dev/null)" = "$w" ] || [ "$(cat "$P0/tmp/wf-cron.ddnsw.$s" 2>/dev/null)" = "$w" ] && continue
			IP=${IP:-$w}
		elif [ -z "$X" ]; then
			[ -n "$LN" ] || { dev=$(ip -4 route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n 1)
				LN=$(ip -4 addr show dev "$dev" 2>/dev/null | sed -n 's/.*inet \([0-9.]*\).*/\1/p' | head -n 1); LN=${LN:--}; }
			[ "$LN" != - ] && [ "$(cat "$P0/tmp/wf-cron.ddnsip" 2>/dev/null)" != "$LN" ] || continue
			IP=${IP:-$LN}
		fi
		U="$U $s|$(cat "$RD/$s.update" 2>/dev/null)|$w"
		ddup "$s"
	done
	[ -n "$LN" ] && [ "$LN" != - ] && echo "$LN" > "$P0/tmp/wf-cron.ddnsip"
	[ -n "$U" ] || exit 0
	[ "$3" = q ] || ( ucode "$P0$W/svc.uc" ip ) >/dev/null 2>&1 </dev/null &	# storico dei cambi di IP (2.53)
	ddwait "$U"; r=$?
	# IP voluto accettato dal fornitore (.update rifatto): ricordato per sezione; non accettato = di nuovo alla volta dopo
	for x in $U; do s=${x%%|*}; y=${x#*|}; w=${y#*|}; [ -n "$w" ] && dddone "$s" "${y%%|*}" "" && echo "$w" > "$P0/tmp/wf-cron.ddnsw.$s"; done
	[ $r = 0 ] || exit 1
	[ "$3" = q ] || ev ddns net "🌐 $(t "Nuovo IP della linea" "New line IP")${IP:+ $IP}: $(t "nomi DDNS aggiornati" "DDNS names updated")" ;;
ddnsforce) # aggiornamento forzato di tutti i servizi DDNS accesi (2.68, docs/v2/controllo-nome.md: per un comando del bot
	# dell'utente). Come «Aggiorna Ora» (ddnsdo) ma per sezione e con l'esito vero: .update tolto e aggiornatore per ogni
	# servizio, poi un'attesa sola (al massimo 40 s). Una riga per nome «✅ nome → IP» o «⚠️ nome: non aggiornato (motivo)»;
	# Registro wf:ddnscheck con k = n; esce con 1 se un nome non si aggiorna. Mai il token né la configurazione nei messaggi
	[ -x "$P0/etc/init.d/ddns" ] || { echo "⚠️ $(t "DDNS non installato" "DDNS not installed")"; exit 1; }
	RD=$(ddrun); U=; SS=$(ddsecs)
	[ -n "$SS" ] || { echo "⚠️ $(t "Nessun nome DDNS acceso" "No DDNS name turned on")"; exit 1; }
	# 2.68: al massimo uno ogni 5 minuti (ultimo forzato nel Registro, wf:ddnscheck con k n): ripetuti di fila il fornitore
	# può bloccare il nome
	l=$(rlast ddnscheck n); n=$(date +%s)
	if [ -n "$l" ] && [ $((n - l)) -lt 300 ] && [ $((n - l)) -ge 0 ]; then
		m=$(( (300 - (n - l) + 59) / 60 )); w=$(t minuti minutes); [ $m = 1 ] && w=$(t minuto minute)
		echo "⚠️ $(t "Aggiornato da poco: riprova tra" "Updated recently: try again in") $m $w"; exit 1
	fi
	for s in $SS; do U="$U $s||"; rm -f "$RD/$s.update"; ddup "$s"; done
	[ -n "$P0" ] && [ -n "$WF_DDWAIT" ] || DDW=20
	ddwait "$U"; rc=0
	for x in $U; do
		s=${x%%|*}
		if dddone "$s" "" ""; then
			ip=$(cat "$RD/$s.ip" 2>/dev/null); [ -n "$ip" ] || ip=$(ddwant "$s")
			echo "✅ $(ddnm "$s") → ${ip:-?}"
		else
			rc=1; m=$(t "nessuna conferma in 40 s" "no confirmation in 40 s")
			case "$(uci -q get "ddns.$s.ip_source")" in ''|network|interface) [ -n "$(ddwant "$s")" ] || m=$(t "la linea non ha un IP" "the line has no IP") ;; esac
			echo "⚠️ $(ddnm "$s"): $(t "non aggiornato" "not updated") ($m)"
		fi
	done
	reg ddnscheck $rc n
	exit $rc ;;
ddnswd) # Controllo Del Nome Di Casa (2.68, docs/v2/controllo-nome.md): il nome lo aggiorna ddns-scripts; il pacchetto
	# interviene solo con how svc (ddhow), salvo d5 e clr
	case "$X" in
	if) # dal gancio iface/90-wrtfreedom (event.sh) con ifupdate e IFUPDATE_ADDRESSES: sull'interfaccia di un servizio DDNS
		# acceso lo Storico Degli IP e, solo dove 95-ddns non sente ifupdate, ddnscheck per quell'interfaccia
		i=$3; echo "$i" | grep -qE '^[A-Za-z0-9_.-]{1,32}$' || exit 1
		[ -x "$P0/etc/init.d/ddns" ] && [ -n "$(ddsecs "$i")" ] || exit 0
		( ucode "$P0$W/svc.uc" ip ) >/dev/null 2>&1 </dev/null &
		ddhear && exit 0
		ddhow || exit 0
		exec sh "$0" ddnscheck "$i" q ;;
	chg) # dal giro di notify.sh: <sez>.ip (IP registrato da ddns-scripts) cambiato, chiunque abbia aggiornato: «Nome
		# Aggiornato», poi il controllo del nome (ddchk)
		s=$3; echo "$s" | grep -qE '^[A-Za-z0-9_]{1,64}$' || exit 1
		ddhow || exit 0
		ip=$(cat "$(ddrun)/$s.ip" 2>/dev/null)
		[ -n "$ip" ] && ev ddns net "🌐 $(t "Nome Aggiornato" "Name Updated") ($(ddnm "$s")): $(t "nuovo IP" "new IP") $ip"
		ddchk ;;
	day) # controllo del giorno (dal giro di notify.sh; una volta al giorno anche se il giro riparte; force = di nuovo oggi)
		F=$P0/tmp/wf-cron.ddnsday; d=$(date +%Y%m%d)
		[ "$3" != force ] && [ "$(cat "$F" 2>/dev/null)" = "$d" ] && exit 0
		echo "$d" > "$F"
		ddhow || exit 0
		ddchk ;;
	re) # ricontrollo dopo un old (dal giro di notify.sh): passata l'ora scritta da ddchk1 in /tmp/wf-cron.ddnsre, una volta
		F=$P0/tmp/wf-cron.ddnsre; [ -f "$F" ] || exit 0
		read -r d < "$F"
		case "$d" in ''|*[!0-9]*) rm -f "$F"; exit 0 ;; esac
		[ "$(date +%s)" -ge "$d" ] || exit 0
		rm -f "$F"
		ddhow || exit 0
		ddchk ;;
	d5) # impostazione assente (D5, dal giro di notify.sh): ddnswd align; rpcd che non risponde = di nuovo al giro dopo
		ubus -t 10 call wrtfreedom ddnswd '{"action":"align"}' >/dev/null 2>&1 || rm -f "$P0/tmp/wf-ddnswd.d5" ;;
	clr) # controllo spento (dal giro di notify.sh): segni e conti tolti senza avviso
		rm -f "$P0"/tmp/wf-cron.ddns.*.f "$P0"/tmp/wf-cron.ddnsold.* "$P0/tmp/wf-cron.ddnst" "$P0/tmp/wf-cron.ddnsre" ;;
	*) exit 1 ;;
	esac ;;
certrenew) # Rinnovo Dei Certificati adesso (attività pronta; 2.66: n = Rinnova Ora di certrenew run, esito in
	# /tmp/wf-certrun.json e nel Registro con k = n). renew dove c'è (certrenew get), altrimenti start. Esito vero: uscita di
	# acme e delle sue istanze di procd (attesa fino a 15 minuti) e, per ogni certificato acceso già da rinnovare (rinnovo
	# previsto di certrenew get passato) o senza file, il file davvero rinnovato. Uscita 2 = «non ancora dovuto» (acme.sh):
	# non è un errore e i file non rinnovati non contano (lo ha deciso il client)
	R=$P0/tmp/wf-certrun.json
	st() { [ "$X" = n ] || return 0; printf '{"t":%s,"state":"%s","msg":"%s"}\n' "$(date +%s)" "$1" "$2" > "$R.t" && mv "$R.t" "$R"; }
	fin() { if [ "$1" = 0 ]; then st ok "$2"; else st err "$2"; fi; [ "$X" = n ] && reg certrenew "$1" n; echo "$2"; exit "$1"; }
	[ -x "$P0/etc/init.d/acme" ] || fin 1 "$(t "Certificati non installati" "Certificates not installed")"
	st run ""
	cget; c=start; [ "$(jv @.renew)" = true ] && c=renew
	now=$(date +%s); B=; E=; set -f; L=$(clist); OI=$IFS; IFS='
'
	for l in $L; do
		IFS=$OI; set -- $l
		[ "$2" = true ] && cname "$1" || continue
		f=$(cfile "$1"); m=0; [ -n "$f" ] && m=$(date -r "$f" +%s 2>/dev/null)
		B="$B $1|${m:-0}"
		case "$6" in *[!0-9]*) [ -z "$f" ] && E="$E $1" ;; *) { [ -z "$f" ] || [ "$now" -ge "$6" ]; } && E="$E $1" ;; esac
	done
	IFS=$OI
	"$P0/etc/init.d/acme" $c >/dev/null 2>&1; rc=$?
	i=0; while [ $i -lt 450 ]; do
		case "$(ubus call service list '{"name":"acme"}' 2>/dev/null | jsonfilter -e '@.acme.instances[*].running' 2>/dev/null)" in *true*) sleep 2; i=$((i + 1)) ;; *) break ;; esac
	done
	# uscita di acme e delle istanze (una per certificato): la prima diversa da 0 e da 2 è l'errore; nd = «non ancora dovuto»
	nd=0; er=0
	for e in $rc $(ubus call service list '{"name":"acme"}' 2>/dev/null | jsonfilter -e '@.acme.instances[*].exit_code' 2>/dev/null); do
		case "$e" in 0|''|*[!0-9]*) ;; 2) nd=1 ;; *) [ "$er" = 0 ] && er=$e ;; esac
	done
	rc=$er
	ok=; bad=
	for b in $B; do
		D=${b%|*}; f=$(cfile "$D"); m=0; [ -n "$f" ] && m=$(date -r "$f" +%s 2>/dev/null)
		if [ "${m:-0}" -gt "${b##*|}" ]; then ok="$ok $D"; else case " $E " in *" $D "*) bad="$bad $D" ;; esac; fi
	done
	set +f
	[ -n "$bad" ] && [ $nd = 0 ] && fin 1 "$(t "Rinnovo non riuscito" "Renewal failed"):$bad"
	[ "$rc" = 0 ] || fin "$rc" "$(t "Rinnovo non riuscito" "Renewal failed") ($(t errore error) $rc)"
	[ -n "$ok" ] && fin 0 "$(t "Certificati rinnovati" "Certificates renewed"):$ok"
	fin 0 "$(t "Nessun certificato da rinnovare" "No certificate to renew")" ;;
certok) # rinnovo riuscito (2.66, gancio /etc/hotplug.d/acme/91-wrtfreedom con il nome del certificato e ACTION)
	certok "$X" "$([ "$3" = issued ] && echo issued)" || exit 1 ;;
certcheck) # Rinnovo Dei Certificati (2.66): una volta al giorno dalle 01:30 (giro di notify.sh, niente riga nel crontab;
	# force = di nuovo oggi; giorno in ora locale, lday), per ogni certificato acceso con il file. Evento perso (file più
	# nuovo dell'ultimo: notify assente o senza «renewed») = come il gancio, più la copia per AdGuard se il suo gancio c'è.
	# Rinnovo mancato (rinnovo previsto di certrenew get passato da più di un giorno) = D4 (d4 sopra): informazione
	# «Rinnovo Rimandato» (tipo cert_wait, mai le regole di cert) o, con il rinnovo automatico fermo (how null: riga spenta
	# dall'utente o acme fermo), «Rinnovo Automatico Fermo» (cert_stop, una volta per problema); errore solo con d4 (con how
	# null senza «Rinnovo Non Riuscito»); mai errori con i certificati spenti, di prova o senza file. Esito nel Registro (1
	# solo con un errore)
	[ -x "$P0/etc/init.d/acme" ] || exit 0
	now=$(date +%s); dn=$(lday "$now"); F=$P0/tmp/wf-cron.certday
	[ "$X" != force ] && [ "$(cat "$F" 2>/dev/null)" = "$dn" ] && exit 0
	echo "$dn" > "$F"
	cget || exit 0
	how=$(jv @.how)
	rc=0; any=0; ON=' '; set -f; L=$(clist); OI=$IFS; IFS='
'
	for l in $L; do
		IFS=$OI; set -- $l; D=$1; NA=$4; NB=$5; DU=$6
		[ "$2" = true ] && cname "$D" || continue
		ON="$ON$(ckey "$D") "
		f=$(cfile "$D") || continue
		m=$(date -r "$f" +%s 2>/dev/null) || continue
		any=1; k=$(ckey "$D"); r=$(awk -v n="$D" '$1 == n { print $2 }' "$CK" 2>/dev/null)
		if [ -z "$r" ]; then
			# prima volta (pacchetto appena installato, nome nuovo): la data del file fa da base, nessun evento
			mkdir -p "${CK%/*}"; echo "$D $m" >> "$CK"
		elif [ "$m" -gt "$r" ]; then
			certok "$D" check
			[ -f "$P0/etc/hotplug.d/acme/90-wrtfreedom" ] && sh "$0" certadg "$D" >/dev/null 2>&1 </dev/null
			continue
		fi
		[ "$3" = true ] && continue
		case "$NA$NB$DU" in *[!0-9]*) continue ;; esac
		# controlli mancati di fila in certmiss («giorno quanti»: tolto da un controllo a posto e da certok; lo stesso giorno
		# con force non conta di nuovo)
		MF=$P0/tmp/wf-cron.certmiss.$k
		[ "$now" -gt $((DU + 86400)) ] || { rm -f "$MF"; clear "certstop.$k"; continue; }
		pd=; pn=0; [ -f "$MF" ] && read -r pd pn < "$MF"
		case "$pn" in ''|*[!0-9]*) pn=0 ;; esac
		if [ "$pd" = "$dn" ]; then n=$pn; else n=$((pn + 1)); echo "$dn $n" > "$MF"; fi
		[ "$how" = - ] || clear "certstop.$k"
		left=$((NA - now))
		if [ $left -gt 0 ]; then w="$(t "scade tra" "expires in") $(((left + 86399) / 86400)) $(t giorni days)"; else w=$(t "certificato scaduto" "certificate expired"); fi
		if d4 "$n" "$left" $((NA - DU)); then
			rc=1
			if [ "$how" = - ]; then craise "$k" stop && ev cert_fail sys "⚠️ $(t "Rinnovo Automatico Fermo" "Automatic Renewal Stopped") ($D): $w"
			else craise "$k" "" && ev cert_fail sys "⚠️ $(t "Rinnovo Non Riuscito" "Renewal Failed") ($D): $w"; fi
		elif [ "$how" = - ]; then
			raise "certstop.$k" && ev cert_stop sys "🔐 $(t "Rinnovo Automatico Fermo" "Automatic Renewal Stopped") ($D): $w"
		elif [ "$pd" != "$dn" ]; then
			ev cert_wait sys "🔐 $(t "Rinnovo Rimandato" "Renewal Postponed") ($D): $(t "il router riprova stanotte" "the router retries tonight")"
		fi
	done
	IFS=$OI; set +f
	# 2.68: segni e conti dei certificati spenti o tolti via in silenzio (wddown di wrtfreedom.uc conta già solo quelli accesi)
	for f in "$P0"/tmp/wf-cron.certrenew.*.f "$P0"/tmp/wf-cron.certstop.*.f "$P0"/tmp/wf-cron.certmiss.*; do
		[ -f "$f" ] || continue
		b=${f##*/}; case "$b" in wf-cron.certmiss.*) k=${b#wf-cron.certmiss.} ;; *) k=${b#wf-cron.cert*.}; k=${k%.f} ;; esac
		case "$ON" in *" $k "*) ;; *) rm -f "$f" ;; esac
	done
	[ $any = 1 ] && reg certrenew $rc
	exit $rc ;;
align) # riallineamento (2.66: fine di install.sh, svc.uc boot dopo l'orologio, certrenew on con «started»): riga di acme
	# sistemata (certrenew align di wrtfreedom.uc); senza nessuna riga, con il servizio abilitato e un certificato acceso,
	# acme start rimette la sua e, se manca ancora, la scrive il pacchetto. Poi il gancio del certificato di AdGuard (adghook)
	if [ -x "$P0/etc/init.d/acme" ]; then
		s=$(ubus call wrtfreedom certrenew '{"action":"align"}' 2>/dev/null | jsonfilter -e '@.start' 2>/dev/null)
		if [ "$s" = true ]; then
			[ "$X" = started ] || "$P0/etc/init.d/acme" start >/dev/null 2>&1
			ubus call wrtfreedom certrenew '{"action":"align","write":true}' >/dev/null 2>&1
		fi
	fi
	# Controllo Della VPN Per Fuori Casa (2.67): impostazione assente = D5 (vpnwd align: acceso con la VPN Per Fuori Casa e
	# nessuna riga accesa che fa lo stesso)
	ubus call wrtfreedom vpnwd '{"action":"align"}' >/dev/null 2>&1
	# Controllo Del Nome Di Casa (2.68): impostazione assente = D5 (ddnswd align: acceso con un servizio DDNS acceso e niente
	# acceso che fa lo stesso)
	ubus call wrtfreedom ddnswd '{"action":"align"}' >/dev/null 2>&1
	adghook && ubus call wrtfreedom certadg '{"action":"on"}' >/dev/null 2>&1 ;;
certadg) # certificato del nome di AdGuard Home (acme) nei percorsi di AdGuard, solo se è cambiato (2.65,
	# docs/v2/certificato-adguard.md). Lo lancia il gancio di acme a ogni rilascio o rinnovo con il nome del certificato (un
	# altro nome dello stesso router non tocca AdGuard; con acme.sh «renewed» arriva due volte: la seconda non trova
	# niente da copiare) o la riga di riserva delle 00:30, senza nome
	# riga di riserva accesa, gancio possibile (notify usato da /usr/lib/acme/hook, come acmenotify di wrtfreedom.uc) ma
	# assente (rpcd non pronto durante install.sh): passa al gancio, che copia subito da sé; un tentativo al giorno (se il
	# gancio non si scrive, on rimette la riga e la copia va avanti qui)
	if [ -z "$X" ] && adghook && once certadghook 86400; then
		ubus call wrtfreedom certadg '{"action":"on"}' >/dev/null 2>&1
		[ -f "$P0/etc/hotplug.d/acme/90-wrtfreedom" ] && exit 0
	fi
	# primo collegamento (cron.sh certadg <nome> primo, da certadg on con name, prima di tls/configure dell'app): il nome
	# è quello scelto nell'app, percorsi di serie nella cartella di AdGuard se il suo file non li ha ancora, proprietario e
	# permessi sistemati anche con i file già uguali, niente ricarica (la fa tls/configure); scrive cert= e key= o err=.
	# Percorsi del file di AdGuard solo se stanno nella sua cartella, senza «..» (mai sopra i file di acme di un altro nome);
	# con il file direttamente in /etc (/etc/adguardhome.yaml) la cartella è /etc/adguardhome/
	F=0; [ "$3" = primo ] && F=1
	Y=$(adgyaml); [ -n "$Y" ] || { [ $F = 1 ] && echo "err=file di AdGuard Home non trovato"; exit $F; }
	g() { sed -n "s/^ *$1: *['\"]\{0,1\}\([^'\"]*\)['\"]\{0,1\} *$/\1/p" "$Y" | head -n 1; }
	C=$(g certificate_path); K=$(g private_key_path); N=$(g server_name)
	[ $F = 1 ] && { N=$X; D=${Y%/*}/; [ "$D" = "$P0/etc/" ] && D=$P0/etc/adguardhome/
		case "$C$K" in *..*) C= ;; esac
		[ -n "$C" ] && [ "${C#"$D"}" != "$C" ] && [ "${K#"$D"}" != "$K" ] || { C=${D}tls/fullchain.crt; K=${D}tls/privkey.key; }; }
	# nome e percorsi assoluti di certificato e chiave
	[ -n "$N" ] && [ "${C#/}" != "$C" ] && [ "${K#/}" != "$K" ] || exit 0
	[ -z "$X" ] || [ "$X" = "$N" ] || exit 0
	for d in "$P0/etc/ssl/acme" "$P0/etc/acme/$N" "$P0/etc/acme/${N}_ecc"; do
		[ -f "$d/$N.fullchain.crt" ] && { SC=$d/$N.fullchain.crt; SK=$d/$N.key; break; }
		[ -f "$d/fullchain.cer" ] && { SC=$d/fullchain.cer; SK=$d/$N.key; break; }
	done
	[ -n "$SC" ] && [ -f "$SK" ] || { [ $F = 1 ] && echo "err=certificato di $N non trovato"; exit $F; }
	# proprietario e gruppo della cartella della configurazione di AdGuard (nella jail gira con il suo utente), letti qui
	O=$(ls -ldn "${Y%/*}" 2>/dev/null | awk '{ print $3 ":" $4 }')
	own() { [ -z "$O" ] || [ "$O" = : ] || chown -h "$O" "$1"; }
	if cmp -s "$SC" "$C" && cmp -s "$SK" "$K"; then
		# primo collegamento con i file già uguali (copiati da root): solo proprietario e permessi, mai attraverso un collegamento
		[ $F = 1 ] && { [ -L "$K" ] || [ -L "$C" ] || { own "$K" && chmod 600 "$K" && own "$C" && chmod 644 "$C"; } || { echo "err=permessi del certificato non sistemati"; exit 1; }; echo "cert=$C"; echo "key=$K"; }
		unflag certadg; exit 0
	fi
	# prep <sorgente> <temporaneo> <permessi>: file pronto accanto alla destinazione (cartella nuova leggibile da AdGuard);
	# niente se la cartella è un collegamento
	prep() { pd=${2%/*}; [ ! -L "$pd" ] && { [ -d "$pd" ] || { ( umask 022; mkdir -p "$pd" ) && own "$pd"; }; } && ( umask 077; cp -L "$1" "$2" ) && chmod "$3" "$2" && own "$2"; }
	# prima la chiave (0600) poi il certificato (0644): ognuno in un file temporaneo nella sua cartella e poi mv (AdGuard non
	# legge mai un file a metà); se qualcosa non va i temporanei si tolgono e AdGuard tiene il certificato di prima. Un
	# temporaneo che esiste già (anche come collegamento) non è nostro: niente copia e non si tocca
	TK=${K%/*}/.${K##*/}.wf$$; TC=${C%/*}/.${C##*/}.wf$$; nw=1
	{ [ -e "$TK" ] || [ -L "$TK" ] || [ -e "$TC" ] || [ -L "$TC" ]; } && nw=0
	if ! { [ $nw = 1 ] && prep "$SK" "$TK" 600 && prep "$SC" "$TC" 644 && mv -f "$TK" "$K" && mv -f "$TC" "$C"; }; then
		[ $nw = 1 ] && rm -f "$TK" "$TC"
		# primo collegamento: l'errore lo mostra l'app, niente evento
		[ $F = 1 ] && { echo "err=copia del certificato non riuscita"; exit 1; }
		once certadg 604800 && ev cert_fail sys "⚠️ $(t "Certificato non copiato in AdGuard Home" "Certificate not copied to AdGuard Home") ($N): $(t "usa ancora quello di prima" "it still uses the previous one")"
		# 2.68: esito nel Registro Delle Esecuzioni (wf:certadg) anche dal gancio di acme e dalla riga di riserva senza involucro
		reg certadg 1
		exit 1
	fi
	unflag certadg
	[ $F = 1 ] && { ev cert sys "🔐 $(t "Certificato aggiornato in AdGuard Home" "Certificate updated in AdGuard Home") ($N)" >/dev/null 2>&1; echo "cert=$C"; echo "key=$K"; exit 0; }
	# copia fatta (mai con i file già uguali: il secondo «renewed» di acme.sh non scrive una riga in più)
	reg certadg 0
	# ricarica senza riavvio: SIGHUP (dalla 0.102 AdGuard ricarica il certificato se è cambiata la data; nella jail ci arriva
	# da procd) al servizio di procd o, senza, al processo. Più vecchio della 0.102 (SIGHUP lo fermerebbe), versione non
	# letta o segnale non partito: riavvio come prima. AdGuard spento: niente, il certificato nuovo lo legge all'accensione
	s=$(adginit); J=; [ -n "$s" ] && J=$(ubus call service list "{\"name\":\"$s\"}" 2>/dev/null)
	B=$(echo "$J" | jsonfilter -e '@[*].instances[*].command[0]' 2>/dev/null | head -n 1)
	P=$(echo "$J" | jsonfilter -e '@[*].instances[*].pid' 2>/dev/null | head -n 1)
	[ -n "$P" ] || { J=; P=$(pidof AdGuardHome 2>/dev/null | cut -d ' ' -f 1); [ -n "$P" ] && B=$(readlink "/proc/$P/exe"); }
	v=; case "${B##*/}" in [Aa]d[Gg]uard[Hh]ome) v=$("$B" --version 2>/dev/null | sed -n 's/.*version v\{0,1\}\([0-9]\{1,9\}\)\.\([0-9]\{1,9\}\).*/\1 \2/p' | head -n 1) ;; esac
	set -- $v
	if [ -z "$P" ]; then :
	elif [ -n "$2" ] && { [ "$1" -gt 0 ] || [ "$2" -ge 102 ]; } && { { [ -n "$J" ] && ubus call service signal "{\"name\":\"$s\",\"signal\":1}" >/dev/null 2>&1; } || kill -HUP "$P" 2>/dev/null; }; then :
	elif [ -n "$s" ]; then "$P0/etc/init.d/$s" restart >/dev/null 2>&1
	fi
	ev cert sys "🔐 $(t "Certificato aggiornato in AdGuard Home" "Certificate updated in AdGuard Home") ($N)" ;;
adgrestart) s=$(adginit); [ -n "$s" ] && /etc/init.d/$s restart >/dev/null 2>&1 ;;
adgpause) quick adg_off ;;
adgon) quick adg_on ;;
vpnoff) sh $W/event.sh act vpn_off ;;
vpnon) sh $W/event.sh act vpn_on ;;
# Servizio VPN (2.42): stessa strada dell'app (ubus), così regole e blocco restano giusti
vpnsvcon) ubus call wrtfreedom vpnout '{"action":"onoff","on":true}' >/dev/null 2>&1 ;;
vpnsvcoff) ubus call wrtfreedom vpnout '{"action":"onoff","on":false}' >/dev/null 2>&1 ;;
vpnsvcnext) ucode $W/vpnctl.uc rotate ;;
vpnsvcresume) # fine della Pausa Del Servizio VPN (2.52, da notify.sh): tornano accesi i collegamenti accesi prima
	ubus call wrtfreedom vpnout '{"action":"resume"}' >/dev/null 2>&1 ;;
# VPN Per Fuori Casa (2.52): Dispositivi Con Scadenza e Orari Per Dispositivo (righe del crontab # wf:wgexp, # wf:wgp_…)
wgexp) ucode $W/wgx.uc exp >/dev/null 2>&1 ;;
wgpeeron|wgpeeroff)
	echo "$X" | grep -qE '^[A-Za-z0-9_]{1,40}$' || { echo "dispositivo non valido"; exit 1; }
	a=resume; [ "$A" = wgpeeroff ] && a=pause
	ubus call wrtfreedom wgpeer "{\"action\":\"$a\",\"id\":\"$X\"}" >/dev/null 2>&1 ;;
guestoff) quick guest_off ;;
gueston) quick guest_on ;;
# ---------- Wi-Fi (2.48) ----------
guestpwd) # password nuova della rete ospiti (subito se è spenta, altrimenti quando si spegne)
	ubus call wrtfreedom wifiguest '{"action":"rot"}' >/dev/null 2>&1 ;;
guestend) # ospiti a tempo scaduti (da notify.sh)
	ubus call wrtfreedom wifiguest '{"action":"end"}' >/dev/null 2>&1 ;;
wifichan) # Canale Automatico di notte per le radio scelte nell'app (mai canali DFS)
	ucode $W/wifi.uc night >/dev/null 2>&1 ;;
txlow|txnorm) # Potenza Di Notte: subito con iw (niente riavvio, niente scritture); txnorm senza valore = quella della configurazione
	command -v iw >/dev/null || exit 0
	if [ -n "$X" ] || [ "$A" = txlow ]; then
		echo "$X" | grep -qE '^[0-9]{1,2}$' && [ "$X" -ge 1 ] && [ "$X" -le 30 ] || { echo "potenza non valida (1…30 dBm)"; exit 1; }
	fi
	S=$(ubus call network.wireless status 2>/dev/null)
	for r in $(uci -q show wireless | sed -n "s/^wireless\.\([A-Za-z0-9_]*\)=wifi-device$/\1/p"); do
		i=$(echo "$S" | jsonfilter -e "@.$r.interfaces[0].ifname" 2>/dev/null); [ -n "$i" ] && [ -d "/sys/class/net/$i" ] || continue
		if [ "$A" = txlow ] || [ -n "$X" ]; then v="fixed ${X}00"
		else p=$(uci -q get wireless.$r.txpower); case "$p" in ''|*[!0-9]*) v=auto ;; *) v="fixed ${p}00" ;; esac; fi
		iw dev "$i" set txpower $v 2>/dev/null
	done ;;
txradio) # 2.64 una radio sola (wifinet, Assistente IA): la potenza della configurazione subito con iw, senza riavvio; radio
	# anonima (@wifi-device[0]), senza iw o senza la sua interfaccia accesa = wifi reload (la configurazione vale lo stesso)
	command -v iw >/dev/null && echo "$X" | grep -qE '^[A-Za-z0-9_]{1,32}$' || { wifi reload; exit 0; }
	i=$(ubus call network.wireless status 2>/dev/null | jsonfilter -e "@.$X.interfaces[0].ifname" 2>/dev/null); [ -n "$i" ] && [ -d "/sys/class/net/$i" ] || { wifi reload; exit 0; }
	p=$(uci -q get wireless.$X.txpower); case "$p" in ''|*[!0-9]*) v=auto ;; *) v="fixed ${p}00" ;; esac
	iw dev "$i" set txpower $v 2>/dev/null ;;
dnsflush) # DNS del router: dnsmasq, altrimenti unbound o smartdns
	for s in dnsmasq unbound smartdns; do [ -x /etc/init.d/$s ] && /etc/init.d/$s restart >/dev/null 2>&1; done ;;

# ---------- Dispositivi ----------
block|unblock) mac "$X" || { echo "dispositivo non valido"; exit 1; }; quick "$A" "$(echo "$X" | tr 'A-F' 'a-f')" ;;
wol)	# accende un dispositivo con Wake-on-LAN
	mac "$X" || { echo "dispositivo non valido"; exit 1; }
	I=$(lanbr); [ -n "$I" ] || { echo "rete di casa non trovata"; exit 1; }
	if command -v etherwake >/dev/null; then etherwake -i "$I" "$X"
	elif command -v ether-wake >/dev/null; then ether-wake -i "$I" "$X"
	else echo "manca etherwake"; exit 1; fi ;;

# ---------- Controlli ----------
spacecheck) # memoria del router quasi piena (di serie la soglia «Quasi Pieno» di Salute Del Router)
	[ "$(uci -q get wrtfreedom.health.al_disk)" = 0 ] || exit 0	# Avvisi Di Salute accesi: l'avviso lo manda già health.uc
	m=/overlay; grep -q " /overlay " /proc/mounts || m=/	# x86 o router con disco: niente overlay
	p=$(df "$m" 2>/dev/null | awk 'NR==2{gsub("%","",$5);print $5}'); [ -n "$p" ] || exit 0; lim=${X:-$(hth disk)}; [ -n "$lim" ] || exit 0
	if [ "$p" -ge "$lim" ]; then once space 43200 && ev space sys "💾 $(t "Memoria del router quasi piena" "Router storage almost full"): $p%"; else unflag space; fi ;;
tempcheck) # temperatura più alta dei sensori del router (di serie la soglia «Molto Alta» di Salute Del Router)
	[ "$(uci -q get wrtfreedom.health.al_temp)" = 0 ] || exit 0	# Avvisi Di Salute accesi: l'avviso lo manda già health.uc

	m=0; for z in /sys/class/thermal/thermal_zone*/temp; do [ -f "$z" ] || continue; v=$(( $(cat "$z") / 1000 )); [ $v -gt $m ] && m=$v; done
	[ $m -gt 0 ] || exit 0; lim=${X:-$(hth tempbad)}; [ -n "$lim" ] || exit 0
	if [ $m -ge "$lim" ]; then once temp 7200 && ev temp sys "🌡️ $(t "Router molto caldo" "Router very hot"): $m °C"; else unflag temp; fi ;;

# ---------- Manutenzione ----------
updcheck) sh $W/upd.sh notify >/dev/null 2>&1 ;;
pkgupd) sh $W/upd.sh safe tg >/dev/null 2>&1 ;;	# con copia e ritorno, come l'app
pkglist) if command -v apk >/dev/null; then apk update >/dev/null 2>&1; else opkg update >/dev/null 2>&1; fi ;;
trafficsave) command -v nlbw >/dev/null && nlbw -c commit >/dev/null 2>&1 ;;

# ---------- Controllo Della Linea (2.53) ----------
sqmon) sh $W/sqmctl.sh on >/dev/null ;;
sqmoff) sh $W/sqmctl.sh off >/dev/null ;;
sqmp)	# profilo per orario (righe # wf:sqmp_<id>, metodo sqmsched)
	echo "$X" | grep -qE '^[a-z0-9]{1,12}$' || { echo "profilo non valido"; exit 1; }
	sh $W/sqmctl.sh prof "$X" >/dev/null ;;
# ---------- Router Spento? (2.53) ----------
hb)	# richiesta all'indirizzo scelto (riga # wf:hb): l'indirizzo resta in uci, a curl arriva da stdin (mai nei processi)
	U=$(uci -q get wrtfreedom.hb.url); [ -n "$U" ] || exit 0
	echo "$U" | grep -qE "^https?://[^ '\"\]+$" || exit 1
	# solo curl: l'indirizzo arriva da stdin (printf è della shell); uclient-fetch lo vorrebbe nella riga di comando
	command -v curl >/dev/null || exit 1
	c=$(printf 'url = "%s"\n' "$U" | curl -s -o /dev/null -m 15 --retry 2 -w '%{http_code}' -K - 2>/dev/null)
	c=$(echo "$c" | tr -cd 0-9 | head -c 3 | sed 's/^0*//'); [ -n "$c" ] || c=0
	ok=false; case "$c" in 2??|3??) ok=true;; esac
	printf '{"t":%s,"ok":%s,"code":%s}\n' "$(date +%s)" "$ok" "$c" > /tmp/wf-hb.json.t && mv /tmp/wf-hb.json.t /tmp/wf-hb.json ;;

# ---------- Telegram ----------
bot)	# un Comando Pronto del bot, risultato su Telegram
	echo "$X" | grep -qE '^[a-z0-9_]{1,40}$' || { echo "comando non valido"; exit 1; }
	ucode $W/tgbot.uc run "$X" >/dev/null 2>&1 ;;
weekly) # Riepilogo Settimanale (2.50): consumo, bloccati da AdGuard, dispositivi nuovi, cadute della linea; 2.66: esito nel
	# Registro (wf:weekly, valore n = Manda Ora)
	ucode $W/netx.uc weekly >/dev/null 2>&1; r=$?; reg weekly $r "$X"; exit $r ;;
monthly) # Consumo Del Mese Su Telegram (2.59, riga # wf:monthly): i primi dispositivi del mese (valore = quanti, 1…10)
	echo "${X:-5}" | grep -qE '^([1-9]|10)$' || { echo "numero non valido (1…10)"; exit 1; }
	ucode $W/dev.uc monthly "${X:-5}" >/dev/null 2>&1 ;;
*)	echo "uso: cron.sh <azione> [valore]"; exit 1 ;;
esac
exit 0
