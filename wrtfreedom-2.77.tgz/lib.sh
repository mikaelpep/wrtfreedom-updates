#!/bin/sh
# WrtFreedom: regole comuni degli script del pacchetto (2.72, causa 8: nomi e percorsi letti dal router, mai fissi).
# uso: . /usr/share/wrtfreedom/lib.sh        (funzioni homenet, adgyaml, adgaddr)
#      sh /usr/share/wrtfreedom/lib.sh homenet | adgyaml | adgaddr [casa]
# Le stesse regole di homenet(), adgyaml() e adgaddr() di wrtfreedom.uc. Vuoto (e uscita 1) = non trovato: niente
# ripieghi come br-lan, lan o 192.168.1.1, che sono di un router «tipico» e non di questo.
# Variabili di lavoro con «lb_» davanti (letto con «.» non tocca quelle di chi lo usa); risultati in HN_* (homenet).
# P0 = cartella del router finto delle prove (come cron.sh: WF_CRONTEST, ignorata sul router vero)
[ -n "$P0" ] || { [ -n "$WF_CRONTEST" ] && [ ! -e /etc/openwrt_release ] && P0=$WF_CRONTEST; }

# zona di casa (come fwzones di wrtfreedom.uc): quella con la rete lan se c'è, altrimenti la prima senza NAT che accetta in
# ingresso (vpnout = zona del Servizio VPN, esclusa). Stampa «zona rete1 rete2…»
wf_homezone() {
	uci -q show firewall 2>/dev/null | awk '
	{ e = index($0, "="); if (!e) next; k = substr($0, 1, e - 1); v = substr($0, e + 1); gsub(/\047/, "", v)
	  n = split(k, p, ".")
	  if (n == 2) { if (v == "zone") z[++c] = k; next }
	  if (n == 3) o[p[1] "." p[2], p[3]] = v }
	END {
		for (i = 1; i <= c; i++) {
			s = z[i]; nm = o[s, "name"]; if (nm == "") continue
			nets = " " o[s, "network"] " "; m = o[s, "masq"] == "1" || o[s, "masq"] == "true"
			if (h == "" && index(nets, " lan ")) h = s
			if (a == "" && !m && nm != "vpnout" && o[s, "input"] == "ACCEPT") a = s
		}
		if (h == "") h = a
		if (h != "") print o[h, "name"], o[h, "network"]
	}'
}
# maschera a.b.c.d → bit (255.255.255.0 → 24); vuota = 24, come vpnnet di wrtfreedom.uc
wf_maskbits() {
	echo "${1:-255.255.255.0}" | awk -F. '{ b = 0; for (i = 1; i <= 4; i++) { o = $i + 0; while (o >= 128) { b++; o = (o * 2) % 256 } } print b }'
}
# rete di casa: prima rete accesa della zona di casa con un indirizzo IPv4 → dispositivo (l3_device) e indirizzo; con le reti
# spente la prima rete statica della zona con l'indirizzo della configurazione. Stampa «rete dispositivo indirizzo»
# (dispositivo «-» se non si sa) e lascia HN_NET, HN_DEV, HN_IP, HN_PFX (bit della rete) a chi la usa con «.»
homenet() {
	HN_NET=; HN_DEV=; HN_IP=; HN_PFX=
	set -- $(wf_homezone)
	[ $# -gt 1 ] || return 1
	shift
	for lb_n in "$@"; do
		lb_s=$(ifstatus "$lb_n" 2>/dev/null) || continue
		[ "$(echo "$lb_s" | jsonfilter -e '@.up' 2>/dev/null)" = true ] || continue
		lb_i=$(echo "$lb_s" | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null)
		[ -n "$lb_i" ] || continue
		HN_NET=$lb_n; HN_IP=$lb_i; HN_PFX=$(echo "$lb_s" | jsonfilter -e '@["ipv4-address"][0].mask' 2>/dev/null)
		HN_DEV=$(echo "$lb_s" | jsonfilter -e '@.l3_device' 2>/dev/null); [ -n "$HN_DEV" ] || HN_DEV=$(echo "$lb_s" | jsonfilter -e '@.device' 2>/dev/null)
		break
	done
	if [ -z "$HN_NET" ]; then
		for lb_n in "$@"; do
			[ "$(uci -q get "network.$lb_n.proto")" = static ] || continue
			lb_a=$(uci -q get "network.$lb_n.ipaddr" | awk '{ print $1 }'); [ -n "$lb_a" ] || continue
			HN_NET=$lb_n; HN_IP=${lb_a%%/*}
			case "$lb_a" in */*) HN_PFX=${lb_a#*/} ;; *) HN_PFX=$(wf_maskbits "$(uci -q get "network.$lb_n.netmask")") ;; esac
			HN_DEV=$(ifstatus "$lb_n" 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null); [ -n "$HN_DEV" ] || HN_DEV=$(uci -q get "network.$lb_n.device")
			break
		done
	fi
	[ -n "$HN_NET" ] || return 1
	echo "$HN_NET ${HN_DEV:--} $HN_IP"
}
# file di configurazione dal comando del servizio: argomento dopo -c / --config (procd, poi i processi AdGuardHome vivi,
# poi un percorso scritto per intero nel file di avvio); solo percorsi assoluti che esistono
wf_adgcmd() {
	lb_a=
	for lb_s in adguardhome AdGuardHome; do
		lb_a=$(ubus call service list "{\"name\":\"$lb_s\"}" 2>/dev/null | jsonfilter -e '@[*].instances[*].command[*]' 2>/dev/null)
		[ -n "$lb_a" ] && break
	done
	if [ -z "$lb_a" ]; then for lb_p in $(pidof AdGuardHome 2>/dev/null); do lb_a=$(tr '\0' '\n' < "/proc/$lb_p/cmdline" 2>/dev/null); [ -n "$lb_a" ] && break; done; fi
	[ -n "$lb_a" ] || lb_a=$(grep -oE -- "(-c|--config)[ =]+[\"']?/[A-Za-z0-9._/-]+" /etc/init.d/adguardhome 2>/dev/null | head -n 1 | sed 's#^[^/]*#--config=#')
	echo "$lb_a" | awk 'p { print; exit } $0 == "-c" || $0 == "--config" { p = 1; next } /^--config=/ { sub(/^--config=/, ""); print; exit }' |
		while read -r lb_f; do case "$lb_f" in /*) [ -f "$lb_f" ] && echo "$lb_f" ;; esac; done
}
# file di AdGuard Home: uci adguardhome.config.config_file o config (OpenWrt 24.10+), poi il -c del comando del servizio,
# poi i percorsi di serie. Scritto anche in /tmp/wf-adgyaml («-» = non trovato): la cache che leggono i file ucode
adgyaml() {
	lb_y=
	for lb_c in $(uci -q get adguardhome.config.config_file) $(uci -q get adguardhome.config.config); do [ -f "$lb_c" ] && { lb_y=$lb_c; break; }; done
	[ -n "$lb_y" ] || lb_y=$(wf_adgcmd | head -n 1)
	# percorsi di serie: provati sotto $P0 (router finto delle prove), il risultato è il percorso sul router (senza $P0)
	if [ -z "$lb_y" ]; then for lb_c in /etc/adguardhome/adguardhome.yaml /etc/adguardhome.yaml /opt/AdGuardHome/AdGuardHome.yaml; do [ -f "$P0$lb_c" ] && { lb_y=$lb_c; break; }; done; fi
	printf '%s\n' "${lb_y:--}" > "$P0/tmp/wf-adgyaml" 2>/dev/null
	[ -n "$lb_y" ] || return 1
	echo "$lb_y"
}
# indirizzo dell'interfaccia web di AdGuard Home (host:porta; una regola sola, la stessa di adgaddr di wrtfreedom.uc,
# ricopiata in netx.uc e dev.uc): address del blocco http: del suo file (vecchie versioni: bind_host e bind_port).
# 0.0.0.0, :: o vuoto = in ascolto ovunque:
#   adgaddr        per le chiamate dal router stesso (curl verso l'API) → 127.0.0.1
#   adgaddr casa   per l'indirizzo mostrato all'utente → indirizzo della rete di casa (homenet; senza = vuoto)
# IPv6 tra quadre ([fd00::1]:3000). Vuoto (uscita 1) = AdGuard Home non trovato
adgaddr() {
	lb_y=$(adgyaml) || return 1
	lb_a=$(awk '/^http:/ { f = 1; next } f && /^[^ \t#]/ { f = 0 } f && /^[ \t]+address:/ { print $2; exit }' "$lb_y" 2>/dev/null | tr -d "\"'")
	if [ -n "$lb_a" ]; then
		case "$lb_a" in
			\[*\]:[0-9]*) lb_h=${lb_a%%]*}; lb_h=${lb_h#?}; lb_p=${lb_a##*]:} ;;
			*:[0-9]*) lb_h=${lb_a%:*}; lb_p=${lb_a##*:} ;;
			*) return 1 ;;
		esac
	else
		lb_p=$(awk '/^bind_port:/ { print $2; exit }' "$lb_y" 2>/dev/null | tr -d "\"'")
		lb_h=$(awk '/^bind_host:/ { print $2; exit }' "$lb_y" 2>/dev/null | tr -d "\"'[]")
	fi
	case "$lb_p" in ''|*[!0-9]*) return 1 ;; esac
	case "$lb_h" in ''|0.0.0.0|::)
		if [ "$1" = casa ]; then homenet >/dev/null; lb_h=$HN_IP; [ -n "$lb_h" ] || return 1; else lb_h=127.0.0.1; fi ;;
	esac
	case "$lb_h" in *:*) lb_h="[$lb_h]" ;; esac
	echo "$lb_h:$lb_p"
}

# «sh lib.sh <comando>»: solo quando è il programma avviato (non letto con «.» da un altro script)
case "${0##*/}" in lib.sh) case "$1" in homenet|adgyaml|adgaddr) lb_c=$1; shift; "$lb_c" "$@" ;; *) echo "uso: lib.sh homenet | adgyaml | adgaddr [casa]" >&2; exit 2 ;; esac ;; esac
