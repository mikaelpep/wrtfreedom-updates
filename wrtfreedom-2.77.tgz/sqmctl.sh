#!/bin/sh
# WrtFreedom 2.53: Controllo Della Linea (SQM) dal bot, dalle Pianificazioni e dalle regole degli Eventi
# uso: sqmctl.sh on                    acceso con la modalità di prima (Adattivo se c'è cake-autorate, altrimenti Fisso)
#      sqmctl.sh off                   spento (la modalità si ricorda in wrtfreedom.sqm.last)
#      sqmctl.sh state                 stato in parole (bot)
#      sqmctl.sh mode fixed <down> <up>   limiti fissi in kbit/s nel verso della linea
#      sqmctl.sh mode fixed            limiti fissi già salvati (2.70: li scrive il metodo sqm, nel verso giusto)
#      sqmctl.sh mode auto <safe|bal|fast> velocità adattiva con il profilo (custom o senza: i 6 valori di adesso; senza e nessun profilo salvato: Bilanciato)
#      sqmctl.sh prof <id>             profilo per orario wrtfreedom.sqmp_<id> (cron.sh sqmp)
#      sqmctl.sh pick <parola>         profilo dal bot: prudente|bilanciato|veloce|spento o il nome di un profilo per orario
# Regola: la prima accesa, altrimenti la prima (mai quella provvisoria dei giga finiti). 2.70: il verso (rete di casa o
# ospiti = «download» di SQM è l'upload della linea) e lo stato in parole li dà il metodo sqm del router (una sola
# regola); senza risposta (all'avvio, prima di rpcd) vale il nome br-… come prima. Con il limite dei giga finiti
# (slow.sh) non si cambia niente. Eventi cron_sqm_on / cron_sqm_off.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1; }
num() { case "$1" in ''|*[!0-9]*) echo 0;; *) echo "$1";; esac; }
mb() { awk -v k="$1" 'BEGIN { v = k / 1000; s = sprintf(v < 10 ? "%.1f" : "%.0f", v); sub(/\.0$/, "", s); print s }'; }
[ -x /etc/init.d/sqm ] || { t "SQM non installato: si aggiunge da Software" "SQM not installed: add it from Software"; echo; exit 1; }
S=
for s in $(uci -q show sqm | sed -n "s/^sqm\.\([^.]*\)=queue$/\1/p"); do
	[ "$s" = wfslow ] && continue
	[ -z "$S" ] && S=$s
	[ "$(uci -q get sqm.$s.enabled)" = 1 ] && { S=$s; break; }
done
[ -n "$S" ] || { t "Nessuna regola dello SQM: configurala nell'app" "No SQM rule: set it up in the app"; echo; exit 1; }
I=$(uci -q get sqm.$S.interface)
# configurazione di cake-autorate: cartella letta dal suo servizio (/etc/init.d/cake-autorate), poi i posti soliti
arconf() { for d in $(grep -o "/[A-Za-z0-9._/-]*cake-autorate/" /etc/init.d/cake-autorate 2>/dev/null) /root/cake-autorate/ /usr/share/cake-autorate/ /opt/cake-autorate/; do
	[ -f "${d}config.primary.sh" ] && { echo "${d}config.primary.sh"; return; }; done; }
F=$(arconf)
AR=0; [ -x /etc/init.d/cake-autorate ] && [ -n "$F" ] && AR=1
arrun() { [ $AR = 1 ] && /etc/init.d/cake-autorate running >/dev/null 2>&1; }
ison() { [ "$(uci -q get sqm.$S.enabled)" = 1 ]; }
pname() { case "$1" in safe) t Prudente Cautious;; fast) t Veloce Fast;; *) t Bilanciato Balanced;; esac; }
# profili della velocità adattiva (come l'app: minimo, base, massimo in Mbit/s, download poi upload)
prof() { case "$1" in safe) echo "5 30 60 2 6 12";; fast) echo "20 60 150 5 10 25";; *) echo "10 40 90 3 8 15";; esac; }
slowchk() { [ -f /etc/wrtfreedom/slow ] && { t "Limite dei giga finiti attivo: lo SQM torna libero con il nuovo periodo" "Data cap limit active: SQM is free again with the new period"; echo; exit 1; }; }
start() { /etc/init.d/sqm enable; /etc/init.d/sqm restart >/dev/null 2>&1; }
# limiti nel verso della linea: sulla rete di casa download e upload di SQM sono al contrario
SW=
swp() {
	[ -n "$SW" ] || SW=$(ubus -t 5 call wrtfreedom sqm 2>/dev/null | jsonfilter -e '@.where.swap' 2>/dev/null)
	[ -n "$SW" ] || case "$I" in br-*) SW=true;; *) SW=false;; esac
	[ "$SW" = true ]
}
setlim() { d=$1; u=$2; swp && { d=$2; u=$1; }; uci set sqm.$S.download="$d"; uci set sqm.$S.upload="$u"; }
fixed() {
	new=1
	if [ -n "$1$2" ]; then d=$(num "$1"); u=$(num "$2")
	else new=0; d=$(uci -q get sqm.$S.download); u=$(uci -q get sqm.$S.upload); swp && { x=$d; d=$u; u=$x; }; d=$(num "$d"); u=$(num "$u"); fi
	[ "$d" -ge 100 ] && [ "$u" -ge 100 ] || { t "Limiti non validi" "Invalid limits"; echo; exit 1; }
	was=0; ison && was=1
	arrun && { /etc/init.d/cake-autorate stop >/dev/null 2>&1; /etc/init.d/cake-autorate disable; }
	uci set sqm.$S.enabled=1; [ $new = 1 ] && setlim "$d" "$u"; uci commit sqm; start
	uci set wrtfreedom.sqm=sqm; uci set wrtfreedom.sqm.last=fixed; uci commit wrtfreedom
	msg="🎚 $(t "SQM · Fisso" "SQM · Fixed") ↓ $(mb "$d") ↑ $(mb "$u") Mbit/s"
	[ $was = 0 ] && ev sqm_on "$msg"; echo "$msg"
}
auto() {
	[ $AR = 1 ] || { t "Velocità Adattiva non installata: si aggiunge da Software" "Adaptive Speed not installed: add it from Software"; echo; exit 1; }
	# regola unica del profilo (anche per on): custom (Personalizzato) = i 6 valori che ci sono, mai riscritti (G12);
	# senza profilo: Bilanciato solo se wrtfreedom.sqm.prof non è mai stato salvato, altrimenti i valori che ci sono
	p=$1; case "$p" in ''|safe|bal|fast|custom) ;; *) p=bal;; esac
	[ -z "$p" ] && [ -z "$(uci -q get wrtfreedom.sqm.prof)" ] && p=bal
	sp=$p; [ "$p" = custom ] && p=
	was=0; ison && was=1
	if [ -n "$p" ]; then
		set -- $(prof "$p")
		i=0; for k in min_dl base_dl max_dl min_ul base_ul max_ul; do
			i=$((i + 1)); eval v=\$$i
			sed -i "s/^${k}_shaper_rate_kbps=.*/${k}_shaper_rate_kbps=$((v * 1000))/" $F
		done
	fi
	uci set sqm.$S.enabled=1; uci commit sqm; start
	/etc/init.d/cake-autorate enable; /etc/init.d/cake-autorate restart >/dev/null 2>&1
	uci set wrtfreedom.sqm=sqm; uci set wrtfreedom.sqm.last=auto; [ -n "$sp" ] && uci set wrtfreedom.sqm.prof="$sp"; uci commit wrtfreedom
	msg="🎚 $(t "SQM · Adattivo" "SQM · Adaptive")${p:+ $(pname "$p")}"
	[ $was = 0 ] && ev sqm_on "$msg"; echo "$msg"
}
off() {
	ison || { t "SQM già spento" "SQM already off"; echo; return 0; }
	l=fixed; arrun && l=auto
	uci set wrtfreedom.sqm=sqm; uci set wrtfreedom.sqm.last=$l; uci commit wrtfreedom
	[ $AR = 1 ] && { /etc/init.d/cake-autorate stop >/dev/null 2>&1; /etc/init.d/cake-autorate disable; }
	uci set sqm.$S.enabled=0; uci commit sqm
	# solo la nostra coda: con un'altra coda accesa (anche dell'utente) sqm riparte senza la nostra e resta all'avvio
	if uci -q show sqm 2>/dev/null | grep -qE "\.enabled='?1'?$"; then /etc/init.d/sqm restart >/dev/null 2>&1
	else /etc/init.d/sqm stop >/dev/null 2>&1; /etc/init.d/sqm disable; fi
	msg="🎚 $(t "SQM spento" "SQM off")"
	ev sqm_off "$msg"; echo "$msg"
}
on() {
	ison && { arrun || [ $AR = 0 ] || [ "$(uci -q get wrtfreedom.sqm.last)" != auto ]; } && { t "SQM già acceso" "SQM already on"; echo; return 0; }
	# riacceso: la regola del profilo di auto() (i valori che ci sono; Bilanciato solo se nessun profilo salvato)
	if [ $AR = 1 ] && [ "$(uci -q get wrtfreedom.sqm.last)" != fixed ]; then auto
	else fixed
	fi
}
# stato (2.70): la frase del router (metodo sqm, la stessa di app, widget e IA) e i limiti di adesso
state() {
	J=$(ubus -t 5 call wrtfreedom sqm 2>/dev/null); L1=$(echo "$J" | jsonfilter -e '@.st.line' 2>/dev/null)
	if [ -n "$L1" ]; then
		echo "🎚 SQM: $L1"; echo "$J" | jsonfilter -e '@.st.d' 2>/dev/null
		SW=$(echo "$J" | jsonfilter -e '@.where.swap' 2>/dev/null)
	else
		if ! ison; then t "🎚 SQM: spento" "🎚 SQM: off"; echo; return; fi
		if arrun; then echo "🎚 $(t "SQM: Adattivo" "SQM: Adaptive") $(pname "$(uci -q get wrtfreedom.sqm.prof)")"
		else echo "🎚 $(t "SQM: Fisso" "SQM: Fixed")"; fi
	fi
	ison || return 0
	b=$(printf 'ifb4%s' "$I" | head -c 15)
	o=$(tc qdisc show dev "$I" 2>/dev/null | sed -n 's/.* bandwidth \([^ ]*\)bit.*/\1/p' | head -n 1)
	n=$(tc qdisc show dev "$b" 2>/dev/null | sed -n 's/.* bandwidth \([^ ]*\)bit.*/\1/p' | head -n 1)
	swp && { x=$o; o=$n; n=$x; }
	[ -n "$o$n" ] && echo "$(t "Limiti adesso" "Limits now"): ↓ ${n:-?}bit/s · ↑ ${o:-?}bit/s" || t "Code ferme: il controllo non lavora" "Queues stopped: the control is not working"
}
case "$1" in
	state) state ;;
	on) slowchk; on ;;
	off) slowchk; off ;;
	mode) slowchk
		case "$2" in off) off ;; fixed) fixed "$3" "$4" ;; auto) auto "$3" ;; *) t "Modalità non valida" "Invalid mode"; echo; exit 1 ;; esac ;;
	prof)
		echo "$2" | grep -qE '^[a-z0-9]{1,12}$' && [ "$(uci -q get wrtfreedom.sqmp_$2)" = sqmp ] || { t "Profilo non trovato" "Profile not found"; echo; exit 1; }
		slowchk; P=wrtfreedom.sqmp_$2
		case "$(uci -q get $P.mode)" in off) off ;; fixed) fixed "$(uci -q get $P.dl)" "$(uci -q get $P.ul)" ;; *) auto "$(uci -q get $P.prof)" ;; esac ;;
	pick)
		w=$(echo "$2" | tr 'A-Z' 'a-z' | sed 's/^ *//; s/ *$//')
		case "$w" in
			prudente|cautious|safe) slowchk; auto safe ;;
			bilanciato|balanced|bal) slowchk; auto bal ;;
			veloce|fast) slowchk; auto fast ;;
			spento|off) slowchk; off ;;
			acceso|on) slowchk; on ;;
			*) id=$(uci -q show wrtfreedom | sed -n "s/^wrtfreedom\.sqmp_\([a-z0-9]*\)\.name='\(.*\)'$/\1 \2/p" | awk -v w="$w" 'tolower(substr($0, index($0, " ") + 1)) == w { print $1; exit }')
				[ -n "$id" ] && exec sh "$0" prof "$id"
				t "Profilo non trovato: scrivi prudente, bilanciato, veloce, spento o il nome di un profilo per orario" "Profile not found: type cautious, balanced, fast, off or the name of a scheduled profile"; echo ;;
		esac ;;
	*) echo "uso: sqmctl.sh on|off|state|mode <off|fixed <down> <up>|auto <safe|bal|fast>>|prof <id>|pick <parola>"; exit 1 ;;
esac
exit 0
