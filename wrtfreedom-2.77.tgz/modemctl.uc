'use strict';
/* WrtFreedom: lavori del modem fuori da rpcd (possono aspettare il modem senza fermare l'app).
   uso: ucode modemctl.uc restart  riavvia il modem (ModemManager se c'è, altrimenti AT+CFUN=1,1)
        ucode modemctl.uc tg <cmd> testo per i Comandi Pronti del bot (segnale, cella, bande, celle, …)
        ucode modemctl.uc guard    3 minuti dopo un cambio di bande o di blocco cella: se la linea non è tornata
                                   rimette il modem com'era (/etc/wrtfreedom/modem.prev) e lo scrive negli Eventi
        ucode modemctl.uc boot     all'accensione: rimette bande e blocco cella se il modem li ha dimenticati
        ucode modemctl.uc report   Rapporto Modem (testo senza IMEI né numeri della SIM)
        ucode modemctl.uc nrmode <nsa|auto|sa>   5G (2.47): 4G + 5G NSA, NSA e SA, solo 5G SA. Con la linea accesa, dopo 3
                                   minuti senza internet torna alla modalità di prima (come il ripristino delle bande).
                                   Comandi della marca (Quectel), altrimenti ModemManager (sa = solo 5g, gli altri 5g|4g).
                                   Esito in /tmp/wf-nrmode.json {t, mode, ok, err, restored} */
import { popen, readfile, writefile, unlink, stat } from 'fs';

const M = loadfile(getenv('WF_MODEMUC') ?? '/usr/share/wrtfreedom/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function ug(k) { return trim(sh('uci -q get ' + k)); }
const EN = ug('wrtfreedom.ui.lang') == 'en';
function t(it, en) { return EN ? en : it; }
function ev(kind, text) { sh('sh /usr/share/wrtfreedom/event.sh wd ' + q(kind) + ' ' + q(text) + ' >/dev/null 2>&1'); sh('logger -t wrtfreedom-modem ' + q(text)); }
function online() {
	/* rotta predefinita in /proc/net/route: M.lineup() di modem.uc */
	if (!M.lineup()) return false;
	for (let h in [ '1.1.1.1', '8.8.8.8', '9.9.9.9' ]) if (length(sh('ping -c 1 -W 3 ' + h + ' >/dev/null 2>&1 && echo ok'))) return true;
	/* alcuni operatori bloccano il ping: prova anche una pagina web */
	return length(sh('wget -q -T 6 -O /dev/null http://connectivitycheck.gstatic.com/generate_204 >/dev/null 2>&1 && echo ok')) > 0;
}
function words(s) { return filter(split(trim(s ?? ''), /\s+/), length); }
function lockapply(L, N) {
	let D = M.drv(M.id());
	if (!D || !D.lock) return;
	for (let c in M.lockcmds(D, L, N)) M.at(c);
}

/* testi per i Comandi Pronti del bot (tgpresets.sh): stessi dati dell'app per tutte le marche */
function tgtext(c) {
	/* lettura nuova; al primo giro il modem non è ancora riconosciuto: si rilegge con il modulo giusto */
	let known = M.id().mm || M.id().vendor;
	sh(M.readcmd());
	if (!known) sh(M.readcmd());
	let St = M.state(), n = St.n, I = St.id, D = St.D, L = [], v = (x, u) => (x == null || x == '') ? '?' : x + (u ?? '');
	let lte = n.lte, nr = n.nr, nrname = nr?.sa ? '5G SA' : '5G NSA';
	if (c == 'segnale') {
		push(L, '📶 ' + t('Segnale', 'Signal'));
		if (lte) push(L, '4G' + (lte.band ? ' B' + lte.band : '') + ' · RSRP ' + v(lte.rsrp, ' dBm') + ' · RSRQ ' + v(lte.rsrq, ' dB') + ' · SINR ' + v(lte.sinr));
		if (nr) push(L, nrname + (nr.band ? ' n' + nr.band : '') + ' · RSRP ' + v(nr.rsrp, ' dBm') + ' · RSRQ ' + v(nr.rsrq, ' dB') + ' · SINR ' + v(nr.sinr));
		if (!lte && !nr) { let m = match(M.at('AT+CSQ'), /\+CSQ: *([0-9]+)/); push(L, m && m[1] != '99' ? 'RSSI ' + (-113 + 2 * +m[1]) + ' dBm' : t('Segnale non disponibile', 'Signal not available')); }
	}
	else if (c == 'cella') {
		if (lte) push(L, '🗼 4G · PCI ' + v(lte.pci) + ' · TAC ' + v(lte.tac) + ' · EARFCN ' + v(lte.earfcn) + (lte.band ? ' · B' + lte.band : '') + (lte.cid && match(lte.cid, /^[0-9A-Fa-f]+$/) ? ' · Cell ID ' + lte.cid + ' (eNB ' + (hex(lte.cid) >> 8) + ')' : ''));
		if (nr) push(L, '🗼 ' + nrname + ' · PCI ' + v(nr.pci) + ' · ARFCN ' + v(nr.arfcn) + (nr.band ? ' · n' + nr.band : ''));
		if (!length(L)) push(L, t('Cella non disponibile', 'Cell not available'));
	}
	else if (c == 'bande') {
		let B = M.bands();
		push(L, '📡 ' + t('In uso', 'In use') + ': ' + (length(n.ca) ? join(' + ', n.ca) : '?'));
		if (B) {
			push(L, '', t('Abilitate', 'Enabled'), '• 4G: ' + join(' ', map(B.cur.lte, (x) => 'B' + x)));
			if (length(B.sup.nr)) push(L, '• 5G NSA: ' + (length(B.cur.nr) ? join(' ', map(B.cur.nr, (x) => 'n' + x)) : t('nessuna', 'none')));
			push(L, '• ' + t('Modalità', 'Mode') + ': ' + (B.mode == 'lte' ? t('solo 4G', '4G only') : '4G + 5G NSA'));
		}
	}
	else if (c == 'operatore' || c == 'rete_mobile') {
		let tech = nr ? (lte ? '5G NSA' : nrname) : lte ? (length(filter(n.ca, (x) => substr(x, 0, 1) == 'B')) > 1 ? '4G LTE-A' : '4G LTE') : ('5gnr' in n.at ? '5G' : length(n.at) ? '3G' : '?');
		if (c == 'operatore') { push(L, '🏢 ' + (n.op || '?')); push(L, '• ' + tech); }
		else push(L, '📡 ' + tech + (length(n.ca) ? ' · ' + join(' + ', n.ca) : '') + (lte?.earfcn ? ' · ' + t('canale', 'channel') + ' ' + lte.earfcn : ''));
	}
	else if (c == 'celle') {
		/* af = comandi AT delle celle vicine mandati e nessuno riuscito (niente OK o un ERROR): il modem non ha risposto,
		   non è «nessuna cella» */
		let o = '', sent = 0, okn = 0;
		if (D && D.neigh) for (let x in D.neigh) { let r = M.at(x); sent++; if (M.atok(r)) okn++; o += r + '\n'; }
		let nb = D && D.parse ? (D.parse(o).nb ?? []) : [];
		if (!length(nb)) nb = n.nb ?? [];
		if (!length(nb) && sent > 0 && okn == 0) return t('Il modem non ha risposto: riprova tra poco', 'The modem did not respond: try again shortly');
		if (!length(nb)) return t('Nessuna cella vicina letta dal modem', 'No nearby cells read from the modem');
		push(L, '🗼 ' + t('Celle vicine', 'Nearby cells'));
		for (let x in slice(nb, 0, 15)) push(L, '• ' + (x.band ? 'B' + x.band : 'LTE') + ' · EARFCN ' + x.earfcn + ' · PCI ' + x.pci + ' · RSRP ' + v(x.rsrp, ' dBm'));
	}
	else if (c == 'temp_modem') {
		if (!length(n.temp ?? [])) return t('Il modem non dà la temperatura', 'The modem does not report its temperature');
		let mx = n.temp[0]; for (let x in n.temp) if (x > mx) mx = x;
		push(L, '🌡 Modem: ' + mx + ' °C');
	}
	else if (c == 'sim') {
		let sj = json(sh('mmcli -i any -J 2>/dev/null') || 'null')?.sim?.properties;
		if (sj) { push(L, '💳 SIM: ' + (sj.active == 'yes' ? t('attiva', 'active') : v(sj.active)) + (sj['operator-name'] ? ' · ' + sj['operator-name'] : '')); if (sj.iccid) push(L, 'ICCID …' + substr(sj.iccid, -4)); }
		else {
			let p = match(M.at('AT+CPIN?'), /\+CPIN: *([^\r\n]+)/); push(L, '💳 SIM: ' + (p ? p[1] : '?'));
			let i = match(M.at('AT+CCID'), /([0-9]{18,20})/) ?? match(M.at('AT+ICCID'), /([0-9]{18,20})/); if (i) push(L, 'ICCID …' + substr(i[1], -4));
		}
	}
	else if (c == 'solo4g' || c == 'standard') {
		let r = M.setmode(c == 'solo4g' ? 'lte' : 'nr');
		if (r.ok) push(L, '✅ ' + (c == 'solo4g' ? t('Modem in solo 4G', 'Modem in 4G only') : t('Modem in 4G + 5G NSA', 'Modem in 4G + 5G NSA')),
			t('Se la linea non torna entro 3 minuti, il router rimette le bande di prima.', 'If the line does not come back within 3 minutes, the router restores the previous bands.'));
		else push(L, t('Il modem non ha accettato il comando:', 'The modem did not accept the command:'), ...r.errors);
	}
	else return t('comando sconosciuto', 'unknown command');
	return join('\n', L);
}

let cmd = ARGV[0];
if (cmd == 'guard') {
	let P = json(readfile('/etc/wrtfreedom/modem.prev') ?? 'null');
	if (!P || time() - P.t > 900) exit(0);
	/* una seconda possibilità: il modem può metterci un po' a riagganciarsi */
	let ok = online();
	if (!ok) { sh('sleep 30'); ok = online(); }
	if (ok) { unlink('/etc/wrtfreedom/modem.prev'); exit(0); }
	ev('restore', '↩️ ' + t('Linea non tornata dopo il cambio: impostazioni del modem ripristinate', 'Line did not come back after the change: modem settings restored'));
	M.bandsset(P.lte, P.nr, P.mode);
	lockapply(P.locklte, P.locknr);
	sh('uci set wrtfreedom.lock=celllock; ' + (length(P.locklte) ? 'uci set wrtfreedom.lock.lte=' + q(P.locklte) + '; ' : 'uci -q delete wrtfreedom.lock.lte; ') +
		(length(P.locknr) ? 'uci set wrtfreedom.lock.nr=' + q(P.locknr) + '; ' : 'uci -q delete wrtfreedom.lock.nr; ') + 'uci commit wrtfreedom; rm -f /tmp/wf-q5g.*');
	unlink('/etc/wrtfreedom/modem.prev');
	exit(0);
}
if (cmd == 'boot') {
	/* aspetta che il modem ci sia e risponda (al massimo 5 minuti) */
	let I = null;
	for (let i = 0; i < 60; i++) {
		sh('o=$(mmcli -m any -J 2>/dev/null); [ -n "$o" ] && echo "$o" > /tmp/wf-modem.mm');
		I = M.id(true);
		if (I.mm || M.atok(M.at('AT'))) break;
		sh('sleep 5');
	}
	if (!I || !I.present) exit(0);
	if (!M.id().vendor && !stat('/tmp/wf-modem.ati')) { sh('sh /usr/share/wrtfreedom/at.sh ATI > /tmp/wf-modem.ati 2>/dev/null'); I = M.id(true); }
	/* bande scelte nell'app: se il modem le ha dimenticate, le rimette */
	let L = words(ug('wrtfreedom.modem.lte')), N = words(ug('wrtfreedom.modem.nr')), mode = ug('wrtfreedom.modem.mode');
	if (length(L)) {
		let B = M.bands();
		if (B && (join(' ', B.cur.lte) != join(' ', sort(L, (a, b) => +a - +b)) || (mode != 'lte' && length(B.sup.nr) && join(' ', B.cur.nr) != join(' ', sort(N, (a, b) => +a - +b))))) {
			let r = M.bandsset(L, N, mode || 'nr');
			ev('bands', '📶 ' + t('Bande del modem rimesse dopo l\'accensione', 'Modem bands restored after power on') + (r.ok ? '' : ' · ' + join(' · ', r.errors)));
		}
	}
	/* blocco cella (senza quectel-5g-tools, che lo rimette da solo) */
	if (ug('wrtfreedom.lock.boot') == '1' && !length(sh('command -v 5g-lock'))) {
		let LL = ug('wrtfreedom.lock.lte'), NN = ug('wrtfreedom.lock.nr');
		if (length(LL)) { lockapply(LL, NN); ev('lock', '🔒 ' + t('Blocco cella rimesso dopo l\'accensione', 'Cell lock restored after power on')); }
	}
	exit(0);
}
/* 5G: nsa, auto o sa; restituisce l'errore o '' */
function nrset(m) {
	let I = M.id(), D = M.drv(I), err = '';
	if (D && D.nrmode) { for (let c in D.nrmode(m)) { let o = M.at(c); if (!M.atok(o)) { sh('sleep 2'); o = M.at(c); } if (!M.atok(o)) err = c + ' → ' + (trim(o) || 'nessuna risposta'); } }
	else if (I.mm) {
		let am = m == 'sa' ? '5g' : '5g|4g', o = M.mmcli('--set-allowed-modes=' + q(am) + (m == 'sa' ? '' : ' --set-preferred-mode=5g'));
		M.cmdlog('mmcli --set-allowed-modes=' + am, o);
		if (match(o, /error/i) && !match(o, /already|unchanged|same/i)) err = 'ModemManager: ' + trim(o);
		/* OpenWrt rimette la modalità dell'interfaccia a ogni collegamento */
		let mi = M.mobif();
		if (!length(err) && mi && mi[1] == 'modemmanager') sh('uci set network.' + mi[0] + '.allowedmode=' + q(am) + '; ' + (m == 'sa' ? 'uci -q delete network.' + mi[0] + '.preferredmode; ' : 'uci set network.' + mi[0] + '.preferredmode=5g; ') + 'uci commit network');
	}
	else err = t('questo modem non permette di scegliere il 5G da qui', 'this modem does not allow choosing 5G from here');
	if (!length(err)) sh('uci set wrtfreedom.modem=modem; uci set wrtfreedom.modem.nrmode=' + m + '; uci commit wrtfreedom');
	return err;
}
if (cmd == 'nrmode') {
	let m = ARGV[1] ?? '', F = '/tmp/wf-nrmode.json';
	if (index([ 'nsa', 'auto', 'sa' ], m) < 0) { print('uso: modemctl.uc nrmode nsa|auto|sa\n'); exit(1); }
	let prev = ug('wrtfreedom.modem.nrmode') || 'nsa', was = M.lineup();
	writefile(F, sprintf('%J', { t: time(), mode: m, busy: true }));
	let err = nrset(m);
	if (length(err) || !was || m == prev) { writefile(F, sprintf('%J', { t: time(), mode: m, ok: !length(err), err: err })); exit(length(err) ? 1 : 0); }
	/* ritorno automatico: 3 minuti (più 30 s di seconda prova) per tornare su internet */
	writefile(F, sprintf('%J', { t: time(), mode: m, ok: true, err: '', wait: true }));
	sh('sleep 180');
	let ok = online();
	if (!ok) { sh('sleep 30'); ok = online(); }
	let restored = false;
	if (!ok) {
		nrset(prev); restored = true;
		ev('restore', '↩️ ' + t('Linea non tornata dopo il cambio del 5G: modalità di prima ripristinata', 'Line did not come back after the 5G change: previous mode restored'));
	}
	writefile(F, sprintf('%J', { t: time(), mode: restored ? prev : m, ok: ok, err: '', restored: restored }));
	exit(0);
}
if (cmd == 'tg') { print(tgtext(ARGV[1] ?? ''), '\n'); exit(0); }
if (cmd == 'restart') { let w = M.restart(); print(length(w) ? 'ok ' + w + '\n' : 'ERRORE il modem non ha accettato il riavvio\n'); exit(length(w) ? 0 : 1); }
if (cmd == 'report') { print(M.report(), '\n'); exit(0); }
print('uso: modemctl.uc guard|boot|restart|report|nrmode <modo>|tg <comando>\n');
