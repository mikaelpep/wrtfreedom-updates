'use strict';
/* WrtFreedom: allerte IT-Alert / EU-Alert con il Cell Broadcast del modem (pacchetto 2.47).
   uso: ucode cbs.uc detect       solo lettura: il modem e ModemManager sanno ricevere il Cell Broadcast?
        ucode cbs.uc setup on|off  accende (canali 4370–4383 sul modem) o spegne la ricezione (wrtfreedom.cbs.enabled)
        ucode cbs.uc boot          all'accensione: aspetta il modem (al massimo 5 minuti) e rimette i canali se acceso
        ucode cbs.uc refresh       ModemManager: messaggi nuovi (notify.sh ogni 30 s, solo se acceso)
        ucode cbs.uc listen        comandi AT: legge i messaggi «+CBM» dalla porta scelta (processo a parte, pid in
                                   /tmp/wf-cbs.pid: lo avviano setup e boot, lo ferma setup off)
   Strade:
   - ModemManager ≥ 1.24 con l'interfaccia Cell Broadcast del modem: --cell-broadcast-set-channels,
     --cell-broadcast-list-cbm e --cbm=<percorso> per il testo;
   - altrimenti i comandi AT standard (3GPP 27.005): AT+CSCB=0,"4370,…,4383" e AT+CNMI con il solo <bm>=2 (gli altri
     valori restano), così il modem manda i messaggi come «+CBM:» non richiesti. CSCB e CNMI di prima si salvano in
     /etc/wrtfreedom/cbs.at e si rimettono spegnendo. Serve una porta del modem libera da leggere (wrtfreedom.cbs.port:
     diversa da quella di at.sh e da quelle usate da ModemManager): senza, supported:false con il motivo.
   Spegnendo: ModemManager canali vuoti; AT valori di prima. enabled=1 solo se il modem lo supporta.
   Canali (wrtfreedom.cbs.channels, di serie 4370-4383): 4370 Presidenziale, 4371–4372 Estremo, 4373–4378 Grave, 4379
   Amber, 4380 Test mensile, 4381 Esercitazione, 4382 Operatore, 4383 EU-Alert/Info.
   File: /tmp/wf-cbs.sup {t, supported, via, reason, mmver, channels, enabled}; /tmp/wf-cbs.json {t, list}; ultimi 20
   messaggi e chiavi già viste in /etc/wrtfreedom/cbs.json (scritto solo quando arriva un messaggio nuovo).
   Messaggio nuovo → evento «cron_cbs» categoria Linea (notifiche del telefono e Telegram come gli altri eventi). */
import { readfile, writefile, popen, stat, mkdir, rmdir, rename, open, unlink } from 'fs';

const W = '/usr/share/wrtfreedom', SUP = '/tmp/wf-cbs.sup', OUT = '/tmp/wf-cbs.json', ETC = '/etc/wrtfreedom/cbs.json',
	FLAG = '/tmp/wf-cbs.mm', LOCK = '/tmp/wf-cbs.lock', DEFCH = '4370-4383', PID = '/tmp/wf-cbs.pid', ATS = '/etc/wrtfreedom/cbs.at';
const M = loadfile(getenv('WF_MODEMUC') ?? W + '/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function js(c) { try { return json(sh(c)); } catch (e) { return null; } }
function load(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
function uo(sec, opt) {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
		let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m && m[1] == opt) return m[2];
	}
	return '';
}
const EN = uo('ui', 'lang') == 'en';
function t(it, en) { return EN ? en : it; }
/* canali: «4370-4383,4396» → controllati; elenco esteso per AT+CSCB (alcuni modem non accettano gli intervalli) */
function channels() { let c = uo('cbs', 'channels'); return match(c, /^[0-9]{1,5}(-[0-9]{1,5})?(,[0-9]{1,5}(-[0-9]{1,5})?){0,30}$/) ? c : DEFCH; }
function chlist(c) {
	let L = [];
	for (let p in split(c, ',')) { let r = split(p, '-'), a = +r[0], b = +(r[1] ?? r[0]); for (let i = a; i <= b && length(L) < 64; i++) push(L, '' + i); }
	return join(',', L);
}
function sev(ch) {
	ch = +ch;
	if (ch == 4370) return 'presidential';
	if (ch == 4371 || ch == 4372) return 'extreme';
	if (ch >= 4373 && ch <= 4378) return 'severe';
	if (ch == 4379) return 'amber';
	if (ch == 4380) return 'test';
	if (ch == 4381) return 'exercise';
	return 'info';
}
/* porta AT di at.sh (una regola sola: scelta, dichiarata da ModemManager, elenco solito) */
function atport() { return trim(sh('sh ' + W + '/at.sh --port 2>/dev/null')); }
/* porte che ModemManager usa (generic.ports: «ttyUSB2 (at)», «wwan0 (net)»…) */
function mmports() {
	let P = {};
	for (let x in (js('mmcli -m any -J 2>/dev/null')?.modem?.generic?.ports ?? [])) { let n = split('' + x, ' ')[0]; if (length(n)) P['/dev/' + n] = 1; }
	return P;
}
/* porta per i messaggi non richiesti (solo comandi AT): scelta, esistente, diversa da quella di at.sh e da quelle di
   ModemManager (leggerle ruberebbe le risposte ai comandi) */
function urcport() {
	let p = uo('cbs', 'port');
	if (!match(p, /^\/dev\/[A-Za-z0-9_]{1,30}$/) || !stat(p) || p == atport() || mmports()[p]) return '';
	return p;
}
/* testo per eventi e Telegram: niente a capo, «|» (separatore del registro) e caratteri di controllo */
function clean(s) {
	let o = '';
	for (let i = 0; i < length(s); i++) { let c = ord(s, i); o += (c < 32 || c == 127) ? ' ' : (c == 124 ? '/' : chr(c)); }
	return trim(replace(o, / +/g, ' '));
}

/* ---------------- rilevamento (solo lettura) ---------------- */
function detect() {
	let I = M.id(true), r = { t: time(), supported: false, via: '', reason: '', mmver: I.mmver ?? '', channels: channels(), enabled: uo('cbs', 'enabled') == '1' };
	if (!I.present) { r.reason = 'nomodem'; return r; }
	if (I.mm) {
		if (!M.mmge(I.mmver, '1.24')) r.reason = 'mmold';
		else {
			let o = sh('mmcli -m any --cell-broadcast-status -J 2>&1');
			/* ModemManager 1.24 risponde {"modem":{"cellbroadcast":{"channels":…}}} */
			if (match(o, /cellbroadcast|cell-broadcast/) && !match(o, /^error/)) { r.supported = true; r.via = 'mm'; return r; }
			r.reason = 'nocb';
		}
	}
	/* comandi AT: il modem conosce AT+CSCB e c'è una porta libera per i messaggi */
	let o = M.at('AT+CSCB=?');
	if (M.atok(o)) {
		if (length(urcport())) { r.supported = true; r.via = 'at'; r.reason = ''; }
		else if (!length(r.reason)) r.reason = 'noport';
	}
	else if (!length(r.reason)) r.reason = 'nocb';
	return r;
}

/* ---------------- messaggi ---------------- */
function store() { return load(ETC) ?? { seen: [], list: [] }; }
/* un messaggio ricevuto: salvato ed evento, una volta per chiave (canale + numero di serie + inizio del testo) */
function got(D, m, quiet) {
	m.text = clean(m.text ?? '');
	if (!length(m.text)) return false;
	let k = m.ch + ':' + (m.sn ?? '') + ':' + substr(replace(m.text, /\s+/g, ' '), 0, 80);
	if (index(D.seen, k) >= 0) return false;
	push(D.seen, k); if (length(D.seen) > 60) D.seen = slice(D.seen, length(D.seen) - 60);
	m.sev = sev(m.ch); m.test = m.sev == 'test' || m.sev == 'exercise';
	unshift(D.list, m); D.list = slice(D.list, 0, 20);
	if (!quiet) {
		let head = m.test ? '🧪 IT-Alert (' + t('prova', 'test') + ')' : '🚨 IT-Alert';
		sh('sh ' + W + '/event.sh cron cbs net ' + q(head + ': ' + substr(m.text, 0, 600)) + ' >/dev/null 2>&1');
	}
	return true;
}
function save(D) {
	mkdir('/etc/wrtfreedom');
	writefile(ETC + '.t', sprintf('%J', D)); rename(ETC + '.t', ETC);
	writefile(OUT, sprintf('%J', { t: time(), list: D.list }));
}
/* ModemManager: elenco dei messaggi, dettaglio solo dei percorsi nuovi (cache in /tmp/wf-cbs.paths) */
function mmrefresh() {
	/* ModemManager 1.24: chiave piatta "modem.cell-broadcast.cbm" (come "modem.messaging.sms") */
	let J = js('mmcli -m any --cell-broadcast-list-cbm -J 2>/dev/null');
	let L = J?.['modem.cell-broadcast.cbm'] ?? J?.modem?.['cell-broadcast']?.cbm ?? [];
	let known = {}, D = store(), first = !stat(ETC), news = 0;
	for (let p in split(readfile('/tmp/wf-cbs.paths') ?? '', '\n')) if (length(p)) known[p] = 1;
	let paths = '';
	for (let p in L) {
		p = '' + p; paths += p + '\n';
		if (known[p]) continue;
		let c = js('mmcli --cbm=' + q(p) + ' -J 2>/dev/null')?.cbm ?? {};
		let ct = c.content ?? {}, pr = c.properties ?? {};
		let txt = ct.text ?? c.text ?? '';
		if (!length(txt)) continue;
		if (got(D, { t: time(), ch: '' + (pr.channel ?? c.channel ?? ''), sn: '' + (pr['message-code'] ?? '') + '/' + (pr.update ?? ''), text: txt, via: 'mm' }, first)) news++;
	}
	writefile('/tmp/wf-cbs.paths', paths);
	if (news || first) save(D);
	else if (!stat(OUT)) writefile(OUT, sprintf('%J', { t: time(), list: D.list }));
}

/* ---------------- accensione e spegnimento ---------------- */
function lrun() { let p = trim(readfile(PID) ?? ''); return length(p) && index(readfile('/proc/' + p + '/cmdline') ?? '', 'cbs.uc') >= 0 ? p : ''; }
function lstop() { let p = lrun(); if (length(p)) sh('kill ' + p + ' 2>/dev/null'); unlink(PID); }
function lstart() { if (!length(lrun())) sh('ucode ' + W + '/cbs.uc listen >/dev/null 2>&1 </dev/null &'); }
function setup(on) {
	let r = detect(), ch = channels(), A = load(ATS);
	if (on && r.supported) {
		if (r.via == 'mm') {
			let o = M.mmcli('--cell-broadcast-set-channels=' + ch);
			M.cmdlog('mmcli --cell-broadcast-set-channels=' + ch, o);
			if (match(o, /error/i)) { r.supported = false; r.reason = 'setfail'; r.err = trim(o); }
			else writefile(FLAG, '1');
		} else {
			/* valori di prima, una volta sola (se si riaccende non si sovrascrivono con i nostri) */
			if (!A) {
				A = { cscb: match(M.at('AT+CSCB?'), /\+CSCB: *([^\r\n]+)/)?.[1] ?? '', cnmi: match(M.at('AT+CNMI?'), /\+CNMI: *([0-9,]+)/)?.[1] ?? '' };
				mkdir('/etc/wrtfreedom'); writefile(ATS, sprintf('%J', A));
			}
			let o = M.at('AT+CSCB=0,"' + chlist(ch) + '"');
			if (!M.atok(o)) o = M.at('AT+CSCB=0,"' + ch + '"');
			/* CNMI: solo il terzo valore (<bm>) diventa 2 */
			let f = split(A.cnmi, ','); while (length(f) < 5) push(f, '0'); f[2] = '2';
			if (M.atok(o)) o = M.at('AT+CNMI=' + join(',', slice(f, 0, 5)));
			if (!M.atok(o)) { r.supported = false; r.reason = 'setfail'; r.err = trim(o); }
		}
	}
	if (!on) {
		/* spegnimento: l'inverso di quello che si era messo */
		if (r.via == 'mm' || stat(FLAG)) { let o = M.mmcli('--cell-broadcast-set-channels='); M.cmdlog('mmcli --cell-broadcast-set-channels=', o); }
		lstop();
		if (A) {
			if (length(A.cscb)) M.at('AT+CSCB=' + A.cscb);
			if (match(A.cnmi, /^[0-9]+(,[0-9]+){0,4}$/)) M.at('AT+CNMI=' + A.cnmi);
			unlink(ATS);
		}
	}
	if (!on || r.via != 'mm' || !r.supported) unlink(FLAG);
	/* acceso solo se il modem lo supporta davvero */
	r.enabled = on && r.supported;
	sh('uci -q get wrtfreedom.cbs >/dev/null || uci set wrtfreedom.cbs=cbs; uci set wrtfreedom.cbs.enabled=' + (r.enabled ? 1 : 0) + '; uci commit wrtfreedom');
	writefile(SUP, sprintf('%J', r));
	/* ascolto dei messaggi con i comandi AT: dopo «enabled», che il processo controlla */
	if (r.enabled && r.via == 'at') lstart();
	return r;
}

/* ---------------- ascolto dei «+CBM:» (comandi AT) ----------------
   modo testo: «+CBM: <sn>,<mid>,<dcs>,<pagina>,<pagine>» e poi il testo, anche su più righe, fino a una riga vuota, a un
   altro messaggio non richiesto («+…», OK, RING) o a 93 caratteri (una pagina); in esadecimale UCS2 con dcs 0x48/0x11 */
function page(st, parts) {
	let h = st.hdr, dcs = +h[3], txt = M.ucs2(trim(join('\n', st.lines)), (dcs & 0x0C) == 0x08 || dcs == 0x11), key = h[1] + ':' + h[2];
	st.hdr = null; st.lines = [];
	parts[key] = parts[key] ?? {};
	parts[key][h[4]] = txt;
	if (length(keys(parts[key])) < +h[5]) return;
	let all = '';
	for (let i = 1; i <= +h[5]; i++) all += parts[key]['' + i] ?? '';
	delete parts[key];
	let D = store();
	if (got(D, { t: time(), ch: h[2], sn: h[1], text: all, via: 'at' }, false)) save(D);
}
function listen() {
	let me = split(trim(readfile('/proc/self/stat') ?? ''), ' ')[0], op = lrun();
	if (length(op) && op != me) exit(0);
	writefile(PID, me);
	/* il modem può ripartire: si riapre la porta, finché la ricezione è accesa */
	while (uo('cbs', 'enabled') == '1') {
		let p = urcport();
		if (!length(p)) break;
		sh('stty -F ' + q(p) + ' raw -echo 2>/dev/null');
		let f = open(p, 'r');
		if (!f) { sh('sleep 10'); continue; }
		let st = { hdr: null, lines: [] }, parts = {};
		while (true) {
			let l = f.read('line');
			if (l == null) break;
			l = trim(l);
			let m = match(l, /^\+CBM: *([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+)/);
			if (st.hdr && (m || !length(l) || match(l, /^(\+[A-Z]+:|OK$|RING$|ERROR)/))) page(st, parts);
			if (m) { st.hdr = m; continue; }
			if (!st.hdr || !length(l)) continue;
			push(st.lines, l);
			let dcs = +st.hdr[3];
			/* UCS2 in esadecimale: una riga sola; testo: una pagina ha al massimo 93 caratteri */
			if ((dcs & 0x0C) == 0x08 || dcs == 0x11 || length(join(' ', st.lines)) >= 93) page(st, parts);
		}
		f.close();
		sh('sleep 10');
	}
	unlink(PID);
	exit(0);
}

let cmd = ARGV[0] ?? '';
if (cmd == 'detect') { let r = detect(); writefile(SUP, sprintf('%J', r)); exit(0); }
if (cmd == 'setup') {
	if (!mkdir(LOCK)) { let s = stat(LOCK); if (s && time() - s.mtime < 120) exit(0); rmdir(LOCK); mkdir(LOCK); }
	setup(ARGV[1] != 'off');
	rmdir(LOCK);
	exit(0);
}
if (cmd == 'boot') {
	if (uo('cbs', 'enabled') != '1') exit(0);
	for (let i = 0; i < 30 && !M.id(true).present; i++) sh('sleep 10');
	/* ModemManager trova il modem qualche secondo dopo /dev */
	sh('sleep 30');
	setup(true);
	exit(0);
}
if (cmd == 'refresh') {
	if (!mkdir(LOCK)) { let s = stat(LOCK); if (s && time() - s.mtime < 120) exit(0); rmdir(LOCK); if (!mkdir(LOCK)) exit(0); }
	mmrefresh();
	rmdir(LOCK);
	exit(0);
}
if (cmd == 'listen') listen();
print('uso: cbs.uc detect | setup on|off | boot | refresh | listen\n');
exit(1);
