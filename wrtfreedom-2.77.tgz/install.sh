#!/bin/sh
# WrtFreedom: installa il pacchetto sul router (lanciato dall'app via SSH)
# permessi normali per quello che si crea: lanciato dall'app passa da rpcd, che ha umask 077, e la web app in
# /www/wrtfreedom diventava leggibile solo da root (Forbidden)
umask 022
D=$(cd "$(dirname "$0")" && pwd)
say() { echo "## $*"; }
[ -f /etc/openwrt_release ] || { say "ERRORE questo non è un router OpenWrt"; exit 1; }
PM=
command -v apk >/dev/null 2>&1 && PM=apk
[ -z "$PM" ] && command -v opkg >/dev/null 2>&1 && PM=opkg

need=
[ -e /usr/lib/rpcd/ucode.so ] || need="$need rpcd-mod-ucode"
[ -e /usr/lib/rpcd/file.so ] || need="$need rpcd-mod-file"
[ -e /usr/lib/uhttpd_ubus.so ] || need="$need uhttpd-mod-ubus"
[ -x /usr/libexec/cgi-io ] || need="$need cgi-io"
[ -x /usr/bin/ucode ] || need="$need ucode"
if [ -n "$need" ]; then
	say "Installo i componenti mancanti:$need"
	case "$PM" in
		apk) apk update >/dev/null 2>&1; apk add $need ;;
		opkg) opkg update >/dev/null 2>&1; opkg install $need ;;
		*) say "ERRORE nessun gestore pacchetti (apk o opkg)"; exit 2 ;;
	esac || { say "ERRORE componenti non installati: il router è collegato a internet?"; exit 3; }
fi

# usign controlla la firma degli aggiornamenti dal server (di solito c'è già; se manca si prova ad aggiungerlo)
if ! command -v usign >/dev/null 2>&1; then
	case "$PM" in apk) apk add usign >/dev/null 2>&1 ;; opkg) opkg install usign >/dev/null 2>&1 || { opkg update >/dev/null 2>&1; opkg install usign >/dev/null 2>&1; } ;; esac
fi

say "Copio i file"
mkdir -p /usr/share/rpcd/ucode /usr/share/rpcd/acl.d /usr/share/wrtfreedom /etc/wrtfreedom || exit 4
cp "$D/wrtfreedom.uc" /usr/share/rpcd/ucode/wrtfreedom.uc &&
cp "$D/wrtfreedom.json" /usr/share/rpcd/acl.d/wrtfreedom.json &&
cp "$D/uninstall.sh" "$D/adgsetup.sh" "$D/cakeinst.sh" "$D/cakedel.sh" "$D/sqmline.sh" "$D/sqmlive.sh" "$D/at.sh" "$D/notify.sh" "$D/event.sh" "$D/tgbot.uc" "$D/tgpresets.sh" "$D/watchdog.sh" "$D/cron.sh" "$D/lib.sh" "$D/backup.sh" "$D/sms.uc" "$D/usage.uc" "$D/ussd.uc" "$D/sighist.uc" "$D/sigfast.uc" "$D/slow.sh" "$D/sim.uc" "$D/cbs.uc" "$D/fwstat.uc" "$D/wifi.uc" "$D/dev.uc" "$D/netx.uc" "$D/adgmode.sh" "$D/oui.txt" "$D/line.sh" "$D/bb.sh" "$D/tgq.uc" "$D/vpnctl.uc" "$D/wgx.uc" "$D/svc.uc" "$D/health.uc" "$D/speed.uc" "$D/assist.uc" "$D/ai.uc" "$D/sqmctl.sh" "$D/sqm.uc" "$D/pia-ca.crt" "$D/modem.uc" "$D/modemctl.uc" "$D/fwupd.uc" "$D/upd.sh" "$D/wrtfreedom-upd.pub" "$D/VERSION" "$D/MINAPP" /usr/share/wrtfreedom/ && rm -f /usr/share/wrtfreedom/tgbot.sh /usr/share/wrtfreedom/failover.sh /tmp/wf-tg.needs || { say "ERRORE copia non riuscita (spazio pieno?)"; exit 4; }
# avvisi in tempo reale per il telefono: attesa degli eventi in un processo a parte (plugin exec di rpcd)
mkdir -p /usr/libexec/rpcd && cp "$D/wrtfreedom.wait" /usr/libexec/rpcd/wrtfreedom.wait && chmod 755 /usr/libexec/rpcd/wrtfreedom.wait
# lettura in diretta del Test Di Velocità (2.39): /cgi-bin/wf-live, solo con una sessione valida
mkdir -p /www/cgi-bin && cp "$D/wf-live.cgi" /www/cgi-bin/wf-live && chmod 755 /www/cgi-bin/wf-live
# Giro Della Casa (2.48): /cgi-bin/wf-me, MAC di chi chiama e segnale al secondo, solo con una sessione valida
cp "$D/wf-me.cgi" /www/cgi-bin/wf-me && chmod 755 /www/cgi-bin/wf-me
# Assistente IA (2.60): /cgi-bin/wf-ai, risposta mentre la scrive, solo con una sessione valida
cp "$D/wf-ai.cgi" /www/cgi-bin/wf-ai && chmod 755 /www/cgi-bin/wf-ai
chmod 700 /etc/wrtfreedom
# web app per il browser (Safari: Condividi › Aggiungi alla schermata Home) su http(s)://<router>/wrtfreedom/
if [ -d "$D/www" ]; then rm -rf /www/wrtfreedom && mkdir -p /www/wrtfreedom && cp -r "$D/www/." /www/wrtfreedom/ && chmod -R a+rX /www/wrtfreedom; fi
# tema di LuCI «WrtFreedom»: aprendo l'indirizzo del router si apre l'app (/wrtfreedom/). Si installa senza attivarlo:
# si sceglie in LuCI (Sistema › Lingua e stile) o dall'app. LuCI classica: /cgi-bin/luci/?luci=1 (aspetto Bootstrap)
T=/usr/share/ucode/luci/template/themes
if [ -f $T/bootstrap/header.ut ] && [ -d /www/luci-static/bootstrap ]; then
	mkdir -p $T/wrtfreedom && cp "$D/luci-header.ut" $T/wrtfreedom/header.ut && cp "$D/luci-footer.ut" $T/wrtfreedom/footer.ut && cp "$D/luci-sysauth.ut" $T/wrtfreedom/sysauth.ut && chmod 644 $T/wrtfreedom/*.ut
	ln -sfn bootstrap /www/luci-static/wrtfreedom; uci set luci.themes.WrtFreedom=/luci-static/wrtfreedom; uci commit luci
fi
cp "$D/wrtfreedom.init" /etc/init.d/wrtfreedom && chmod 755 /etc/init.d/wrtfreedom
# configurazione dell'app (avvisi, VPN, Telegram, eventi)
[ -f /etc/config/wrtfreedom ] || touch /etc/config/wrtfreedom
chmod 600 /etc/config/wrtfreedom
# sezioni usate dalle impostazioni dell'app: Watchdog Della Linea e blocco cella (senza quectel-5g-tools)
uci -q get wrtfreedom.wd >/dev/null || { uci set wrtfreedom.wd=watchdog; uci set wrtfreedom.wd.enabled=0; }
# Ripristino Automatico insieme agli Strumenti Modem 5G (2.65): Controllo Di Internet spento, Riavvio Come Ultima Risorsa acceso
uci -q get wrtfreedom.wd.inet >/dev/null || uci set wrtfreedom.wd.inet=0
uci -q get wrtfreedom.wd.lastres >/dev/null || uci set wrtfreedom.wd.lastres=1
uci -q get wrtfreedom.lock >/dev/null || uci set wrtfreedom.lock=celllock
uci -q get wrtfreedom.modem >/dev/null || uci set wrtfreedom.modem=modem
uci -q get wrtfreedom.upd >/dev/null || { uci set wrtfreedom.upd=update; uci set wrtfreedom.upd.check=1; }
# Wi-Fi (2.48): Ospiti A Tempo e password che cambia (until, every, pend), Canale Automatico di notte (auto)
uci -q get wrtfreedom.guest >/dev/null || uci set wrtfreedom.guest=guest
uci -q get wrtfreedom.wifichan >/dev/null || uci set wrtfreedom.wifichan=wifichan
# categoria «fw» degli avvisi (2.75, Firewall): una volta sola (segno ev.fwcat), chi riceveva gli avvisi del Firewall su
# Telegram (fw.tg acceso o assente, il vecchio «di serie») la trova accesa in Eventi › Avvisi (ev.notify): nessuno li perde
if [ "$(uci -q get wrtfreedom.ev.fwcat)" != 1 ]; then
	uci -q get wrtfreedom.ev >/dev/null || uci set wrtfreedom.ev=ev
	nc_=$(uci -q get wrtfreedom.ev.notify)
	[ "$(uci -q get wrtfreedom.fw.tg)" = 0 ] || case " $nc_ " in *" fw "*) ;; *) uci set wrtfreedom.ev.notify="${nc_:+$nc_ }fw" ;; esac
	# Ore Silenziose: «fw» passa come prima (quando era «net»), solo per chi ha un qpass salvato con «net»
	qp_=$(uci -q get wrtfreedom.ev.qpass)
	case " $qp_ " in *" fw "*) ;; *" net "*) uci set wrtfreedom.ev.qpass="$qp_ fw" ;; esac
	uci set wrtfreedom.ev.fwcat=1
fi
uci commit wrtfreedom
# eventi: un piccolo aggancio per ogni tipo di hotplug (lavora in sottofondo). Avvia event.sh solo per gli eventi che
# finiscono nel registro (stesse condizioni dell'inizio di event.sh): per gli altri non parte nemmeno la shell
# dispositivi: collegati da notify.sh (collegamento vero, non l'assegnazione DHCP). Con dnsmasq (2.49) l'aggancio dhcp
# tiene solo la classe del fornitore (vendor class) per il tipo del dispositivo, in /tmp/wf-dhcpvc «mac classe»
H=/etc/hotplug.d/dhcp/90-wrtfreedom
if [ -x /etc/init.d/dnsmasq ] && command -v dnsmasq >/dev/null 2>&1; then
	new=0; [ -f $H ] && grep -q wf-dhcpvc $H || new=1
	mkdir -p /etc/hotplug.d/dhcp
	cat > $H <<'EOF'
#!/bin/sh
# WrtFreedom: classe del fornitore DHCP (tipo del dispositivo, 2.49)
case "$ACTION" in add|old) ;; *) exit 0 ;; esac
[ -n "$DNSMASQ_VENDOR_CLASS" ] && [ -n "$MACADDR" ] || exit 0
F=/tmp/wf-dhcpvc; m=$(echo "$MACADDR" | tr 'A-F' 'a-f'); v=$(printf '%s' "$DNSMASQ_VENDOR_CLASS" | tr -cd 'A-Za-z0-9 ._:+-' | cut -c1-60)
grep -qxF "$m $v" $F 2>/dev/null && exit 0
{ grep -v "^$m " $F 2>/dev/null | tail -n 300; echo "$m $v"; } > $F.t && mv $F.t $F
EOF
	# dnsmasq passa le assegnazioni agli agganci solo se all'avvio ne trova: riavviato solo la prima volta
	[ $new = 1 ] && /etc/init.d/dnsmasq restart >/dev/null 2>&1
else
	rm -f $H
fi
for s in iface usb block button ntp; do
	case $s in
		# Servizio VPN: niente evento; 2.68 Controllo Del Nome Di Casa: anche ifupdate con indirizzi nuovi (ramo a parte di event.sh)
		iface) c='[ "$INTERFACE" != loopback ] && case "$INTERFACE" in wgout|wgo[0-9]|wgo[0-9][0-9]) false;; *) true;; esac && { [ "$ACTION" = ifup ] || [ "$ACTION" = ifdown ] || { [ "$ACTION" = ifupdate ] && [ "$IFUPDATE_ADDRESSES" = 1 ]; }; }' ;;
		usb) c='[ "$DEVTYPE" = usb_device ] && { [ "$ACTION" = add ] || [ "$ACTION" = remove ]; }' ;;
		block) c='case "$DEVNAME" in sd*[0-9]|mmcblk*p[0-9]*|nvme*p[0-9]*) true;; *) false;; esac && { [ "$ACTION" = add ] || [ "$ACTION" = remove ]; }' ;;
		button) c='[ -n "$BUTTON" ] && { [ "$ACTION" = pressed ] || [ "$ACTION" = released ]; }' ;;
		ntp) c='[ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ]' ;;
	esac
	mkdir -p /etc/hotplug.d/$s
	printf '#!/bin/sh\n# WrtFreedom: registro eventi\nif %s && [ -f /usr/share/wrtfreedom/event.sh ]; then sh /usr/share/wrtfreedom/event.sh %s >/dev/null 2>&1 & fi\n' "$c" $s > /etc/hotplug.d/$s/90-wrtfreedom
done
# Rinnovo Dei Certificati (2.66, docs/v2/rinnovo-certificati.md): a ogni rilascio o rinnovo riuscito di acme (notify chiama
# hotplug-call acme) evento e Registro, in sottofondo (cron.sh certok, che scarta il doppio «renewed»); il 90 resta del
# certificato di AdGuard Home
mkdir -p /etc/hotplug.d/acme
cat > /etc/hotplug.d/acme/91-wrtfreedom <<'EOF'
#!/bin/sh
# WrtFreedom: Rinnovo Dei Certificati (2.66), evento e Registro a ogni rilascio o rinnovo di acme
case "$ACTION" in issued|renewed) [ -f /usr/share/wrtfreedom/cron.sh ] && sh /usr/share/wrtfreedom/cron.sh certok "$main_domain" "$ACTION" >/dev/null 2>&1 </dev/null & ;; esac
EOF
# file da conservare negli aggiornamenti del firmware: si aggiungono in un solo passaggio quelli che mancano (righe intere)
L="/www/wrtfreedom/ /usr/share/ucode/luci/template/themes/wrtfreedom/ /www/luci-static/wrtfreedom /usr/share/rpcd/ucode/wrtfreedom.uc /usr/libexec/rpcd/wrtfreedom.wait /www/cgi-bin/wf-live /www/cgi-bin/wf-me /www/cgi-bin/wf-ai /usr/share/rpcd/acl.d/wrtfreedom.json /usr/share/wrtfreedom/ /etc/wrtfreedom/ /etc/config/wrtfreedom /etc/init.d/wrtfreedom /etc/init.d/wrtfreedom-ai /etc/hotplug.d/iface/90-wrtfreedom /etc/hotplug.d/dhcp/90-wrtfreedom /etc/hotplug.d/usb/90-wrtfreedom /etc/hotplug.d/block/90-wrtfreedom /etc/hotplug.d/button/90-wrtfreedom /etc/hotplug.d/ntp/90-wrtfreedom /etc/hotplug.d/acme/90-wrtfreedom /etc/hotplug.d/acme/91-wrtfreedom"
# (">>" crea il file vuoto prima che awk lo legga; awk scrive solo alla fine, dopo averlo letto tutto)
awk -v L="$L" '{ s[$0] = 1 } END { n = split(L, a, " "); for (i = 1; i <= n; i++) if (!(a[i] in s)) print a[i] }' /etc/sysupgrade.conf >> /etc/sysupgrade.conf

# uhttpd deve rispondere alle chiamate ubus
if [ -z "$(uci -q get uhttpd.main.ubus_prefix)" ]; then
	say "Attivo ubus sul server web"
	uci set uhttpd.main.ubus_prefix='/ubus' && uci commit uhttpd && /etc/init.d/uhttpd restart
fi

# riavvio di rpcd senza lasciarne due copie: se il vecchio, occupato da richieste lunghe, non si chiude in tempo, procd
# ne avvia un altro e quello vecchio resta appeso con i suoi oggetti ubus (LuCI e app non rispondono più)
rpcd_restart() { /etc/init.d/rpcd stop; i=0; while pidof rpcd >/dev/null && [ $i -lt 5 ]; do sleep 1; i=$((i+1)); done
	for p in $(pidof rpcd); do kill -9 $p 2>/dev/null; done; /etc/init.d/rpcd start; }
say "Riavvio rpcd"
rpcd_restart
i=0; while [ $i -lt 10 ]; do ubus list wrtfreedom >/dev/null 2>&1 && break; sleep 1; i=$((i+1)); done
/etc/init.d/wrtfreedom enable; /etc/init.d/wrtfreedom restart
# Assistente IA sempre acceso (2.64): ai.uc caricato in un processo (uloop e ubus di ucode) a cui rpcd passa domande e
# lavori lunghi; abilitato e avviato solo con l'Assistente acceso, riavviato a ogni aggiornamento (ai.uc nuovo)
cat > /etc/init.d/wrtfreedom-ai <<'EOF'
#!/bin/sh /etc/rc.common
# WrtFreedom: Assistente IA sempre acceso (2.64), solo con l'Assistente acceso; senza, i lavori partono come processi a parte
START=99
STOP=10
USE_PROCD=1
start_service() {
	[ "$(uci -q get wrtfreedom.ai.on)" = 1 ] && [ -f /usr/share/wrtfreedom/ai.uc ] || return 0
	# moduli di ucode per l'attesa degli eventi e le chiamate dirette
	[ -e /usr/lib/ucode/uloop.so ] && [ -e /usr/lib/ucode/ubus.so ] || return 0
	procd_open_instance
	# umask 077 come i lavori lanciati da rpcd (file propri leggibili solo da root)
	procd_set_param command /bin/sh -c 'umask 077; exec /usr/bin/ucode /usr/share/wrtfreedom/ai.uc serve'
	# riavvio dopo 5 s senza un tetto di tentativi: le uscite volute (memoria oltre 24 MB, Ferma, servizio bloccato) non lo
	# fermano mai; niente ricarica a ogni cambio di configurazione (ucciderebbe le risposte in corso: lo spegnimento lo fa tick)
	procd_set_param respawn 300 5 0
	procd_close_instance
}
EOF
chmod 755 /etc/init.d/wrtfreedom-ai
if [ "$(uci -q get wrtfreedom.ai.on)" = 1 ]; then /etc/init.d/wrtfreedom-ai enable; /etc/init.d/wrtfreedom-ai restart
else /etc/init.d/wrtfreedom-ai stop >/dev/null 2>&1; /etc/init.d/wrtfreedom-ai disable; fi
# Servizio VPN (2.53): dispositivi riconosciuti dal MAC; i collegamenti con le regole per IP si ricostruiscono da soli
# passaggio dei dispositivi del Servizio VPN dall'IP al MAC (2.53): ha il ritorno automatico; si conferma da solo
# dopo 25 s solo se internet risponde, altrimenti dopo 120 s torna tutto com'era
if uci -q show wrtfreedom | grep -q '=vpntun$' && ubus call wrtfreedom vpnout '{"action":"migrate"}' 2>/dev/null | grep -q '"confirm"'; then
	( sleep 25; ping -c 2 -W 3 1.1.1.1 >/dev/null 2>&1 || ping -c 2 -W 3 8.8.8.8 >/dev/null 2>&1 && ubus call wrtfreedom vpnout '{"action":"confirm"}' >/dev/null 2>&1 ) </dev/null >/dev/null 2>&1 &
fi
# Riallineamento (2.66, cron.sh align, in sottofondo: può avviare acme): riga di acme senza involucro con il comando giusto
# (D1) e, per il Certificato di AdGuard Home (2.65), la riga di riserva «# wf:certadg» accesa (pacchetti 2.53–2.64) che passa
# al gancio di acme (/usr/lib/acme/notify usato da /usr/lib/acme/hook) con certadg on, la sola strada che lo scrive (se rpcd
# non è pronto, lo fanno svc.uc boot e la riga delle 00:30); 2.67: impostazione del Controllo Della VPN Per Fuori Casa se manca
# (D5, vpnwd align); 2.68: anche quella del Controllo Del Nome Di Casa (ddnswd align)
( sh /usr/share/wrtfreedom/cron.sh align ) >/dev/null 2>&1 </dev/null &
# elenco dei pacchetti aggiunti (per reinstallarli dopo un aggiornamento del firmware)
[ -f /etc/wrtfreedom/pkgs.txt ] || { if command -v apk >/dev/null 2>&1; then cat /etc/apk/world; else awk '/^Package:/{p=$2} /^Status:.*user installed/{print p}' /usr/lib/opkg/status; fi 2>/dev/null | sort -u > /etc/wrtfreedom/pkgs.txt; }
if ubus list wrtfreedom >/dev/null 2>&1; then say "OK $(cat /usr/share/wrtfreedom/VERSION)"; else say "ERRORE il servizio wrtfreedom non si avvia"; logread | grep -iE 'rpcd|ucode' | tail -n 5; exit 5; fi
rm -rf "$D" /tmp/wf-pkg.tgz
