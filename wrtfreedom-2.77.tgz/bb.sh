#!/bin/sh
# WrtFreedom: scatola nera (2.69). Fotografia in sola lettura del router quando internet manca, per capire dopo il
# perché anche se nel frattempo il router si è riavviato (registro di sistema ed eventi stanno in RAM).
# uso: bb.sh net    internet assente sulla linea (line.sh, dopo 10 s)
#      bb.sh dns    AdGuard non risponde mentre internet c'è (adgmode.sh, primo controllo fallito)
#      bb.sh wd     prima di ricollegare o riavviare (watchdog.sh)
#      bb.sh down   spegnimento del router (wrtfreedom.init): solo copie veloci, niente modem né ping
# Una fotografia in /etc/wrtfreedom/bb/<ora>-<motivo>.txt (al massimo 32 KB, tenute le ultime 8): poche scritture in
# flash, solo durante i guasti. Mai segreti: dal modem tolti IMEI, ICCID, IMSI e numero; dal registro solo le righe di
# linea, modem, DNS e pacchetto. Ogni comando ha un tempo massimo (un modem piantato non deve fermare niente).
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom; BB=/etc/wrtfreedom/bb; WHY=${1:-net}
TO=; command -v timeout >/dev/null 2>&1 && TO="timeout"
t() { if [ -n "$TO" ]; then $TO "$@"; else shift; "$@"; fi; }
# una fotografia ogni 2 minuti al massimo (lo spegnimento sempre)
L=/tmp/wf-bb.last; now=$(date +%s)
[ "$WHY" != down ] && [ -f $L ] && [ $((now - $(cat $L 2>/dev/null || echo 0))) -lt 120 ] && exit 0
echo $now > $L
mkdir -p $BB; F=$BB/$(date +%Y%m%d-%H%M%S)-$WHY.txt; T=$F.t
sec() { echo; echo "=== $1"; }
# dispositivo e interfaccia della linea come li vede line.sh (mai un nome fisso)
D=$(jsonfilter -i /tmp/wf-line.json -e '@.dev' 2>/dev/null)
[ -n "$D" ] || D=$(ip -4 route show default 2>/dev/null | sed -n '1s/.* dev \([^ ]*\).*/\1/p')
I=; [ -n "$D" ] && I=$(ubus call network.interface dump 2>/dev/null | jsonfilter -e "@.interface[@.l3_device=\"$D\"].interface" 2>/dev/null | head -n 1)
cnt() { [ -n "$D" ] && echo "rx $(cat /sys/class/net/$D/statistics/rx_bytes 2>/dev/null) tx $(cat /sys/class/net/$D/statistics/tx_bytes 2>/dev/null)"; }
{
	echo "WrtFreedom scatola nera · $WHY · $(date) · up $(cut -d' ' -f1 /proc/uptime) s · pacchetto $(cat $W/VERSION 2>/dev/null)"
	sec "stato della linea (line.sh)"; cat /tmp/wf-line.json 2>/dev/null
	sec "linea $I ($D)"; [ -n "$I" ] && ifstatus "$I" 2>/dev/null | head -c 1500
	sec "indirizzi e rotte"; ip -4 addr show 2>/dev/null | grep -E "^[0-9]|inet "; ip -4 route 2>/dev/null; ip rule 2>/dev/null | head -n 20
	sec "contatori di $D"; cnt
	if [ "$WHY" != down ]; then
		sleep 5; cnt
		sec "prove"
		for h in 1.1.1.1 8.8.8.8; do echo "ping $h via $D: $(t 5 ping -c 2 -W 2 ${D:+-I $D} $h 2>&1 | tail -n 1)"; done
		for s in 127.0.0.1 1.1.1.1; do echo "nome via $s: $(t 6 nslookup example.com $s 2>&1 | grep -c -E '^Address.*[0-9]\.[0-9]|^Address: [0-9a-f:]+$') risposte"; done
		echo "pagina web: $(t 8 wget -q -T 6 -O /dev/null http://connectivitycheck.gstatic.com/generate_204 2>&1 && echo ok || echo no)"
		if command -v mmcli >/dev/null 2>&1; then
			sec "ModemManager"; t 10 mmcli -L 2>&1
			t 10 mmcli -m any 2>&1 | grep -v -i -E "imei|iccid|imsi|own|equipment id|device identifier|serial|allowed:|eutran|ngran|utran"
			for b in $(t 10 mmcli -m any 2>/dev/null | grep -o 'Bearer/[0-9]*' | cut -d/ -f2 | sort -u); do t 10 mmcli -b $b 2>&1; done
		fi
		sec "modem (AT)"
		for c in 'AT+CGACT?' 'AT+CGPADDR' 'AT+CEREG?' 'AT+C5GREG?' 'AT+QENG="servingcell"' 'AT+QCAINFO' 'AT+CEER'; do echo "> $c"; t 12 sh $W/at.sh "$c" 2>&1 | grep -v -E '^\s*$' | head -n 12; done
	fi
	sec "eventi"; tail -n 30 /tmp/wf-events.log 2>/dev/null
	sec "carico"; cat /proc/loadavg; free 2>/dev/null | head -n 2; echo "connessioni: $(cat /proc/sys/net/netfilter/nf_conntrack_count 2>/dev/null)/$(cat /proc/sys/net/netfilter/nf_conntrack_max 2>/dev/null)"
	top -b -n 1 2>/dev/null | head -n 15
	sec "processi"; pgrep -af "watchdog.sh|line.sh|ModemManager|AdGuardHome|5g-|mmcli|at.sh|quectel-at|sighist" 2>/dev/null | cut -c1-120
	sec "segnale, ultime righe al minuto"; tail -n 15 /tmp/wf-sighist.24h 2>/dev/null
	sec "kernel (modem e PCIe)"; dmesg 2>/dev/null | grep -i -E "mhi|wwan|mbim|pcie|qmi|oom|error" | tail -n 25
	# il registro per ultimo: è la parte più lunga, se serve si taglia lei
	sec "registro (linea, modem, DNS, pacchetto)"
	logread 2>/dev/null | grep -i -E "modemmanager|netifd|wwan|mhi|5g-|quectel|adguard.*(error|warn)|dnsmasq.*(fail|error)|wrtfreedom|kernel.*(oom|error)" | grep -v "degraded sample" | tail -n 100 | cut -c1-220
} 2>&1 | head -c 32000 > $T
mv $T $F
# tenute le ultime 8
n=$(ls -1 $BB/*.txt 2>/dev/null | wc -l)
ls -1 $BB/*.txt 2>/dev/null | sort | awk -v n="$n" 'NR <= n - 8' | while read -r o; do rm -f "$o"; done
exit 0
