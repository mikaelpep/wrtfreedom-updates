#!/bin/sh
# WrtFreedom: controllo della linea (pacchetto 2.42; istanza «line» del servizio, sempre accesa). Un solo controllo di
# internet per tutto il pacchetto, al posto dei ping separati di Linea Di Riserva e Watchdog:
# - ogni secondo guarda i contatori della linea: se arrivano dati (più di 1500 byte) è viva e non serve nessun ping.
#   Ping di controllo a un solo indirizzo ogni 30 s (circa 17 MB al mese); subito, a tutti gli indirizzi insieme, se
#   escono dati e non ne arrivano o dopo una prova fallita. 3 prove fallite di fila = internet assente (circa 3 s);
#   interfaccia spenta o sparita = assente subito (anche l'hotplug lo segnala: KICK). Con dati in arrivo una prova
#   fallita non conta (linea piena: il ping può tardare)
# - Linea Di Riserva (wrtfreedom.fo.enabled=1): con la principale senza internet la rotta predefinita prioritaria
#   (metric 1, protocol 99 = solo nostra) va sulla riserva, già accesa e pronta; le connessioni rimaste sulla linea vecchia si chiudono (conntrack)
#   così le app si ricollegano subito. Si torna alla principale dopo 30 s di fila in cui risponde (niente salti)
# - eventi: fo_backup / fo_main / fo_none, oppure senza riserva net_down («Internet assente», dopo 10 s, solo se
#   l'interfaccia resta accesa: se cade lo dice già l'evento della linea) e net_up con la durata
# - cadute di internet (2.47): ora scritta in /tmp/wf-line.drops per lo storico del segnale (solo se è acceso)
# - cambio SIM automatico (2.47, wrtfreedom.sim.auto=1): sim.uc auto una volta al minuto decide con questo stato
# - stato in /tmp/wf-line.json: lo leggono l'app (Linea Di Riserva) e watchdog.sh (niente ping doppi); scritto solo se
#   cambia o ogni 5 s. Tempi interni da /proc/uptime (niente fork, niente salti dell'orologio); since e t nel file in
#   secondi dal 1970 (BT = ora dell'accensione, riletta con la configurazione)
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom; ST=/tmp/wf-line.json; KICK=/tmp/wf-line.kick
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1 & }
ifdev() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null; }
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
gw() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.route[@.target="0.0.0.0"].nexthop' 2>/dev/null | head -n 1; }
up() { read now _ </proc/uptime; now=${now%.*}; }
dur() { s=$1; if [ $s -ge 3600 ]; then echo "$((s / 3600)) h $((s % 3600 / 60)) min"; elif [ $s -ge 60 ]; then echo "$((s / 60)) min"; else echo "$s s"; fi; }
# internet attraverso il dispositivo $1 (sempre legato: mai dalle regole del Servizio VPN); $2 = tutti gli indirizzi
# insieme, altrimenti il primo
probe() {
	T=/tmp/wf-line.p.$$; rm -f $T; L=$HOSTS; [ -n "$2" ] || L=${HOSTS%% *}
	# si aspettano solo questi ping (un «wait» senza pid aspetterebbe anche event.sh e gli altri lavori in sottofondo)
	P=; for h in $L; do ( ping -c 1 -W 1 -I "$1" "$h" >/dev/null 2>&1 && touch $T ) & P="$P $!"; done; wait $P
	[ -f $T ] && rm -f $T
}
cfg() {
	FO=$(uci -q get wrtfreedom.fo.enabled); M=$(uci -q get wrtfreedom.fo.main); B=$(uci -q get wrtfreedom.fo.backup)
	HOSTS=$(uci -q get wrtfreedom.fo.hosts); HOSTS=${HOSTS:-1.1.1.1 8.8.8.8 9.9.9.9}
	{ [ "$FO" = 1 ] && [ -n "$M" ] && [ -n "$B" ] && [ "$M" != "$B" ]; } || FO=0
	EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
	SA=$(uci -q get wrtfreedom.sim.auto)
	SF=$(uci -q get wrtfreedom.sqm.fo)	# Segue La Linea Di Riserva (Controllo Della Linea, 2.70)
	up; BT=$(($(date +%s) - now))
}
on() { d=$(ifdev "$B"); [ -n "$d" ] && isup "$B" || return 1; g=$(gw "$B"); [ "$g" = 0.0.0.0 ] && g=
	ip route replace default ${g:+via $g} dev "$d" metric 1 protocol 99 2>/dev/null || return 1
	command -v conntrack >/dev/null && conntrack -F >/dev/null 2>&1; return 0; }
rtdel() { ip route del default metric 1 protocol 99 2>/dev/null; }	# solo la nostra, mai una rotta dell'utente
# Controllo Della Linea che segue la linea in uso (2.70): regolazioni della riserva (solo con «Segue La Linea Di Riserva»
# acceso) o di nuovo quelle di prima (metodo sqm): il ritorno quando ci sono quelle salvate (fprev), anche se nel frattempo
# l'utente ha spento la scelta o la Linea Di Riserva
sqmfo() {
	if [ "$1" = main ]; then [ -n "$(uci -q get wrtfreedom.sqm.fprev)" ] || return 0; else [ "$SF" = 1 ] || return 0; fi
	( ubus -t 20 call wrtfreedom sqm "{\"action\":\"follow\",\"go\":\"$1\"}" >/dev/null 2>&1 & )
}
off() { rtdel; command -v conntrack >/dev/null && conntrack -F >/dev/null 2>&1; }
state() {
	js="{\"ok\":$ok,\"active\":\"$act\",\"since\":$((since + BT)),\"fails\":$n,\"main\":\"$M\",\"dev\":\"$D\""
	[ "$js" = "$pjs" ] && [ $((now - pt)) -lt 5 ] && return
	pjs=$js; pt=$now
	printf '%s,"t":%s}\n' "$js" $((now + BT)) > $ST.t && mv $ST.t $ST
}
trap 'rtdel; rm -f $ST; exit 0' INT TERM
up; cfg; rtdel
# si riparte sulla principale: regolazioni della riserva rimaste da un giro di prima tornate com'erano (2.70)
sqmfo main
act=main; ok=true; n=0; nd=0; good=0; since=$now; down=0; said=0; lastp=-99; tick=0; D=; prx=0; ptx=0; pjs=; pt=0
while true; do
	up; tick=$((tick + 1))
	# configurazione riletta; regolazioni della riserva rimaste senza la riserva in uso o con la scelta spenta: tornano
	if [ $((tick % 30)) = 0 ]; then cfg; { [ "$act" = main ] || [ "$SF" != 1 ] || [ $FO = 0 ]; } && sqmfo main; fi
	# dispositivo della linea da controllare: la principale scelta, altrimenti quello della rotta predefinita
	kick=0; [ -f $KICK ] && { rm -f $KICK; kick=1; }
	if [ $((tick % 5)) = 1 ] || [ $kick = 1 ] || [ -z "$D" ]; then
		if [ $FO = 1 ]; then D=$(ifdev "$M"); isup "$M" || D=
		else D=$(ip -4 route show default 2>/dev/null | sed -n '1s/.* dev \([^ ]*\).*/\1/p'); fi
	fi
	rx=0; tx=0; [ -n "$D" ] && { { read rx </sys/class/net/$D/statistics/rx_bytes; read tx </sys/class/net/$D/statistics/tx_bytes; } 2>/dev/null; rx=${rx:-0}; tx=${tx:-0}; }
	live=0; [ $((rx - prx)) -gt 1500 ] && live=1	# dati veri in arrivo (non solo ARP e simili)
	if [ -z "$D" ] || [ ! -e "/sys/class/net/$D" ]; then
		r=1; n=3	# linea spenta o sparita: assente subito
	elif [ "$act" = backup ]; then
		r=2; [ $((tick % 2)) = 1 ] && [ $kick = 0 ] || { lastp=$now; if probe "$D" all; then r=0; else r=1; fi; }	# principale ogni 2 s
	elif [ $n = 0 ] && [ $kick = 0 ] && [ $((now - lastp)) -lt 30 ] && { [ $live = 1 ] || [ "$tx" = "$ptx" ]; }; then
		r=0	# dati in arrivo, oppure linea ferma: basta il ping dei 30 s
	else
		lastp=$now; all=; { [ $n -gt 0 ] || [ $kick = 1 ] || [ "$ok" = false ]; } && all=1
		if probe "$D" $all; then r=0; elif [ $live = 1 ]; then r=0; else r=1; fi
	fi
	prx=$rx; ptx=$tx
	if [ $r = 0 ]; then
		n=0; good=$((good + 1))
		if [ "$act" = backup ] && [ $good -ge 15 ]; then	# 15 risposte ogni 2 s = 30 s di fila
			off; act=main; ok=true; sqmfo main; ev fo_main "✅ $(t "Linea principale tornata" "Main line back") ($M) · $(t "riserva usata per" "backup used for") $(dur $((now - since)))"; since=$now
		elif [ "$act" = main ] && [ "$ok" = false ]; then
			ok=true; [ $said = 1 ] && ev net_up "🌐 $(t "Internet tornato" "Internet back") · $(t "assente per" "down for") $(dur $((now - down)))"; said=0; since=$now
		fi
	elif [ $r = 1 ]; then
		n=$((n + 1)); good=0
		if [ "$act" = main ] && [ $n -ge 3 ]; then
			[ "$ok" = true ] && { ok=false; down=$now; since=$now; [ -e /tmp/wf-sighist.24h ] && { echo $((now + BT)) >> /tmp/wf-line.drops; nd=$((nd + 1)); [ $nd -ge 200 ] && { nd=0; tail -n 100 /tmp/wf-line.drops > /tmp/wf-line.drops.t; mv /tmp/wf-line.drops.t /tmp/wf-line.drops; }; }; }
			if [ $FO = 1 ] && on; then act=backup; since=$now; said=0; sqmfo backup
				ev fo_backup "🔀 $(t "Linea principale senza internet: in uso la linea di riserva" "Main line without internet: using the backup line") ($M → $B)"
			elif [ $said = 0 ] && [ $((now - down)) -ge 10 ]; then said=1
				sh $W/bb.sh net >/dev/null 2>&1 &	# scatola nera (2.69): fotografia del guasto
				if [ $FO = 1 ]; then ev fo_none "⚠️ $(t "Linea principale senza internet e linea di riserva non disponibile" "Main line without internet and backup line not available") ($B)"
				elif [ -n "$D" ]; then ev net_down "🌐 $(t "Internet assente: la linea è accesa ma non risponde" "No Internet: the line is up but not answering") ($D)"; fi
			fi
		fi
		# riserva in uso ma caduta anche lei: niente rotta prioritaria verso il nulla
		[ "$act" = backup ] && ! isup "$B" && { off; act=main; since=$now; sqmfo main; }
	fi
	state
	# cambio SIM automatico (con «if»: niente processo in più a ogni secondo)
	if [ "$SA" = 1 ] && [ $((tick % 60)) = 30 ]; then ucode $W/sim.uc auto >/dev/null 2>&1 & fi
	# dopo una prova fallita (ognuna aspetta 1 s) la successiva parte subito: assenza confermata in circa 3 s
	[ $r = 1 ] && [ "$act" = main ] && [ "$ok" = true ] && continue
	sleep 1 & wait $!	# così la chiusura (procd) toglie subito la rotta, senza aspettare la fine dell'attesa
done
