#!/bin/sh
# WrtFreedom: velocità limitata quando i giga dell'offerta sono finiti (pacchetto 2.47; lo lancia usage.uc in sottofondo)
# uso: slow.sh on <download> <upload> <dispositivo della linea> <1 = linea mobile>   (kbit/s, 0 = quel verso libero)
#      slow.sh off [renew|app|cfg]                                                  toglie il limite (motivo per l'evento)
# Limite con CAKE:
# - con sqm-scripts: la regola di SQM accesa dell'utente sull'interfaccia giusta prende il limite (il valore più basso tra
#   il suo e il nostro) e i suoi valori di prima si ricordano e si rimettono alla fine, solo se nel frattempo non li ha
#   cambiati lui; senza una regola accesa se ne aggiunge una nostra (sqm.wfslow) tolta alla fine. cake-autorate, che
#   cambierebbe il limite da solo, si ferma durante il limite e si riaccende dopo se era acceso;
# - senza sqm-scripts: tc diretto (CAKE in uscita, ifb «wfslow0» per l'entrata), solo se l'interfaccia non ha già code
#   di qualcun altro.
# Interfaccia come sqmline.sh: linea mobile = rete di casa (sul modem la ifb del download può bloccare il router; sulla
# rete di casa l'uscita è il download della linea), via cavo = il dispositivo della linea.
# Stato in /etc/wrtfreedom/slow (resta dopo un riavvio, come la regola di SQM); /tmp/wf-slow.on = limite messo
# («ok» o «err»): dopo un riavvio manca e usage.uc rilancia «on», che con tc rimette le code.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom; ST=/etc/wrtfreedom/slow; ON=/tmp/wf-slow.on; LK=/tmp/wf-slow.lock; IFB=wfslow0
# rete di casa: homenet di lib.sh (2.72, causa 8), la stessa regola di wrtfreedom.uc
for lb_f in "$W/lib.sh" "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1; }
num() { case "$1" in ''|*[!0-9]*) echo 0;; *) echo "$1";; esac; }
mb() { awk -v k="$1" 'BEGIN { v = k / 1000; s = sprintf(v < 10 ? "%.1f" : "%.0f", v); sub(/\.0$/, "", s); print s }'; }
# «↓ 1 / ↑ 0,5 Mbit/s» (un verso a 0 non compare)
lim() { o=; [ "$1" -gt 0 ] && o="↓ $(mb "$1")"; [ "$2" -gt 0 ] && o="${o:+$o / }↑ $(mb "$2")"; [ $EN = 0 ] && o=$(echo "$o" | tr . ,); echo "$o Mbit/s"; }
# blocco: un giro alla volta (sqm restart può durare qualche secondo). Si prende quello di un altro giro solo se il suo
# processo non c'è più (pid nel blocco); al massimo 2 minuti di attesa
i=0
until mkdir $LK 2>/dev/null; do
	read op < $LK/pid 2>/dev/null
	if [ -n "$op" ] && ! kill -0 "$op" 2>/dev/null; then rm -rf $LK; continue; fi
	i=$((i + 1)); [ $i -ge 60 ] && exit 0; sleep 2
done
echo $$ > $LK/pid
trap 'rm -rf $LK' EXIT
trap 'exit 1' INT TERM
# MODE sqm|tc, SEC regola di SQM, OWN 1 = regola nostra, PDL/PUL valori di prima dell'utente, AR cake-autorate era acceso,
# SEN SQM era acceso all'avvio, DEV interfaccia, SDL/SUL valori messi da noi
MODE=; SEC=; OWN=0; PDL=; PUL=; AR=0; SEN=1; DEV=; SDL=; SUL=
# stato letto riga per riga, mai eseguito: nomi con lettere e numeri, valori numerici dove servono
if [ -f $ST ]; then while IFS='=' read -r k v; do v=${v#\"}; v=${v%\"}
	case "$k" in
		MODE) case "$v" in sqm|tc) MODE=$v;; esac ;;
		SEC|DEV) case "$v" in *[!A-Za-z0-9_.@-]*|'') ;; *) eval "$k=\$v";; esac ;;
		OWN|AR|SEN|PDL|PUL|SDL|SUL) case "$v" in *[!0-9]*) ;; *) eval "$k=\$v";; esac ;;
	esac
done < $ST; fi
save() { mkdir -p /etc/wrtfreedom; for k in MODE SEC OWN PDL PUL AR SEN DEV SDL SUL; do eval "echo $k=\\\"\$$k\\\""; done > $ST.t && mv $ST.t $ST; }
# il più basso tra due limiti (0 = nessun limite)
low() { a=$(num "$1"); b=$(num "$2"); if [ "$a" = 0 ]; then echo "$b"; elif [ "$b" = 0 ] || [ "$a" -lt "$b" ]; then echo "$a"; else echo "$b"; fi; }
ar_running() { [ -x /etc/init.d/cake-autorate ] && { /etc/init.d/cake-autorate running >/dev/null 2>&1 || pgrep -f cake-autorate >/dev/null 2>&1; }; }
tcoff() { tc qdisc del dev "$1" root 2>/dev/null; tc qdisc del dev "$1" ingress 2>/dev/null; ip link del $IFB 2>/dev/null; }
# tc diretto: $1 dispositivo, $2 limite in uscita, $3 limite in entrata (kbit/s, 0 = libero)
tcon() {
	[ -d "/sys/class/net/$1" ] || return 1
	tc qdisc del dev "$1" root 2>/dev/null; tc qdisc del dev "$1" ingress 2>/dev/null
	if [ "$2" -gt 0 ]; then tc qdisc replace dev "$1" root cake bandwidth "${2}kbit" besteffort || return 1; fi
	if [ "$3" -gt 0 ]; then
		ip link show $IFB >/dev/null 2>&1 || ip link add $IFB type ifb || return 1
		ip link set $IFB up && tc qdisc add dev "$1" handle ffff: ingress &&
			tc filter add dev "$1" parent ffff: matchall action mirred egress redirect dev $IFB &&
			tc qdisc replace dev $IFB root cake bandwidth "${3}kbit" besteffort ingress || return 1
	fi
	return 0
}
sqmrestart() { /etc/init.d/sqm enable >/dev/null 2>&1; /etc/init.d/sqm restart >/dev/null 2>&1; }

case "$1" in
on)
	DL=$(num "$2"); UL=$(num "$3"); LD=$4; MOB=$5
	[ "$DL" -gt 0 ] || [ "$UL" -gt 0 ] || exit 0
	first=0; [ -z "$MODE" ] && first=1
	# interfaccia giusta (come sqmline.sh): rete di casa con la linea mobile, altrimenti il dispositivo della linea
	homenet >/dev/null; H=$HN_DEV	# vuoto = rete di casa non trovata: con la linea mobile il limite non si mette (evento d'errore)
	T=$LD; [ "$MOB" = 1 ] && T=$H
	[ -n "$MODE" ] && T=${DEV:-$T}	# limite già messo: stessa interfaccia di prima
	# interfaccia non trovata: niente regole su un'interfaccia vuota, avviso una volta sola
	if [ -z "$T" ]; then
		[ "$(cat $ON 2>/dev/null)" = err ] || ev usage_slowerr "⚠️ $(t "Giga finiti: limite di velocità non applicato (rete di casa non trovata)" "Data plan used up: speed limit not applied (home network not found)")"
		echo err > $ON; exit 0
	fi
	# versi: sulla rete di casa l'uscita è il download della linea
	# casa = il dispositivo di homenet (non ogni ponte br-…)
	if [ -n "$H" ] && [ "$T" = "$H" ]; then EG=$DL; IN=$UL; else EG=$UL; IN=$DL; fi
	ok=0
	# già messo con gli stessi valori: niente da fare
	if [ -n "$MODE" ] && [ "$(cat $ON 2>/dev/null)" = ok ]; then
		if [ "$MODE" = tc ] && [ "$SDL" = "$IN" ] && [ "$SUL" = "$EG" ] && tc qdisc show dev "$T" 2>/dev/null | grep -q '^qdisc cake'; then exit 0; fi
		if [ "$MODE" = sqm ] && [ "$SDL" = "$(low "$PDL" "$IN")" ] && [ "$SUL" = "$(low "$PUL" "$EG")" ]; then exit 0; fi
	fi
	if [ -x /etc/init.d/sqm ] && [ "$MODE" != tc ]; then
		if [ -z "$MODE" ]; then
			# regola accesa dell'utente sull'interfaccia giusta, altrimenti una nostra
			SEC=; for s in $(uci -q show sqm | sed -n "s/^sqm\.\([^.]*\)=queue$/\1/p"); do
				[ "$s" != wfslow ] && [ "$(uci -q get sqm.$s.enabled)" = 1 ] && [ "$(uci -q get sqm.$s.interface)" = "$T" ] && { SEC=$s; break; }
			done
			if [ -n "$SEC" ]; then OWN=0; PDL=$(uci -q get sqm.$SEC.download); PUL=$(uci -q get sqm.$SEC.upload)
			else SEC=wfslow; OWN=1; PDL=; PUL=; fi
			AR=0; ar_running && AR=1
			# SQM acceso all'avvio: serve durante il limite (anche dopo un riavvio); alla fine torna com'era
			SEN=0; /etc/init.d/sqm enabled && SEN=1
			MODE=sqm; DEV=$T
		fi
		# SQM: download = entrata dell'interfaccia, upload = uscita (sulla rete di casa vale lo scambio di sopra)
		SDL=$(low "$PDL" "$IN"); SUL=$(low "$PUL" "$EG")
		if [ "$OWN" = 1 ]; then
			uci set sqm.wfslow=queue; uci set sqm.wfslow.enabled=1; uci set sqm.wfslow.interface="$T"
			uci set sqm.wfslow.qdisc=cake; uci set sqm.wfslow.script=piece_of_cake.qos; uci set sqm.wfslow.linklayer=none
		fi
		uci set sqm.$SEC.download="$SDL"; uci set sqm.$SEC.upload="$SUL"; uci commit sqm
		save
		[ "$AR" = 1 ] && /etc/init.d/cake-autorate stop >/dev/null 2>&1
		sqmrestart && ok=1
	else
		# senza sqm-scripts: solo se l'interfaccia non ha già code di qualcun altro (la prima volta)
		if [ -z "$MODE" ] && tc qdisc show dev "$T" 2>/dev/null | grep -qE '^qdisc (cake|htb|hfsc|tbf|ingress)'; then
			echo "ERROR: $T ha già delle code: limite non messo" >&2
		else
			MODE=tc; DEV=$T; SDL=$IN; SUL=$EG; save
			tcon "$T" "$EG" "$IN" && ok=1
		fi
	fi
	if [ $ok = 1 ]; then echo ok > $ON
		[ $first = 1 ] && ev usage_slow "🐢 $(t "Giga finiti: velocità limitata a" "Data plan used up: speed limited to") $(lim "$DL" "$UL")"
	else echo err > $ON
		[ $first = 1 ] && ev usage_slowerr "⚠️ $(t "Giga finiti: limite di velocità non applicato" "Data plan used up: speed limit not applied")${T:+ ($T)}"
	fi ;;
off)
	[ -n "$MODE" ] || { rm -f $ON; exit 0; }
	if [ "$MODE" = sqm ]; then
		if [ "$OWN" = 1 ]; then uci -q delete sqm.wfslow
		else
						# ogni verso per conto suo: quello che l'utente ha cambiato nel frattempo resta com'è
			if [ "$(uci -q get sqm.$SEC.download)" = "$SDL" ]; then
				if [ -n "$PDL" ]; then uci set sqm.$SEC.download="$PDL"; else uci -q delete sqm.$SEC.download; fi
			fi
			if [ "$(uci -q get sqm.$SEC.upload)" = "$SUL" ]; then
				if [ -n "$PUL" ]; then uci set sqm.$SEC.upload="$PUL"; else uci -q delete sqm.$SEC.upload; fi
			fi
		fi
		uci commit sqm
		if [ "$SEN" = 0 ]; then /etc/init.d/sqm stop >/dev/null 2>&1; /etc/init.d/sqm disable >/dev/null 2>&1; else /etc/init.d/sqm restart >/dev/null 2>&1; fi
		[ "$AR" = 1 ] && /etc/init.d/cake-autorate start >/dev/null 2>&1
	else tcoff "$DEV"; fi
	rm -f $ST $ON
	case "$2" in
		renew) w=$(t "nuovo periodo dell'offerta" "new plan period") ;;
		app) w=$(t "tolto dall'app" "removed from the app") ;;
		*) w=$(t "impostazioni cambiate" "settings changed") ;;
	esac
	ev usage_fast "🚀 $(t "Limite di velocità tolto" "Speed limit removed") · $w" ;;
*) echo "uso: slow.sh on <download> <upload> <dispositivo> <mobile> | off [motivo]"; exit 1 ;;
esac
exit 0
