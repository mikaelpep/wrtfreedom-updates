'use strict';
/* WrtFreedom 2.54: lavori in sottofondo della Salute Del Router (mai dentro rpcd; i metodi health* leggono i file in /tmp)
   uso: ucode health.uc tick       ogni minuto da notify.sh: stato da «ubus call wrtfreedom health» (una sola regola di
                                   stato, calcolata nel router da healthcalc), picchi del minuto nel blocco di 5 minuti
                                   (/tmp/wf-health.acc), storico 24 ore in /tmp/wf-health.hist («t cpu mem temp», «-» =
                                   dato che manca, al massimo 288 righe), Avvisi Di Salute negli Eventi (event.sh cron
                                   health_<tipo> sys: una volta quando si supera la soglia, una quando torna normale), segno
                                   di vita in /etc/wrtfreedom/health.alive ogni 6 ore (per capire quanto è stato spento)
        ucode health.uc boot       all'accensione: Spie Di Notte rimesse subito se è notte, storico rimesso da /etc, motivo
                                   dell'ultimo riavvio (segno di spegnimento pulito, pstore, versione del firmware) in
                                   /etc/wrtfreedom/boots.json (al massimo 20, dopo la sincronizzazione dell'ora) e
                                   /tmp/wf-health.boot.json, avviso «riavvio inatteso»
        ucode health.uc down       allo spegnimento (shutdown di wrtfreedom.init): storico in /etc e segno di spegnimento
                                   pulito /etc/wrtfreedom/health.down {t, why: sched|watchdog|asked}
        ucode health.uc space      Cosa Occupa Lo Spazio → /tmp/wf-space.json {t, mnt, total, used, items [{id, name, b}],
                                   clean [{id, name, desc, b, ram}]}
        ucode health.uc clean <id,…>  Pulizia Sicura (solo pkg, tmp, logs, adg: mai configurazione, programmi o copie di
                                   sicurezza) → /tmp/wf-clean.json {t, ids, freed}; con un'altra lettura o pulizia in corso
                                   {t, ids: [], freed: 0, busy: true} */
import { popen, readfile, writefile, unlink, stat, rename, mkdir, rmdir, lsdir } from 'fs';
import * as FS from 'fs';

const HIST = '/tmp/wf-health.hist', HISTE = '/etc/wrtfreedom/health.hist', ACC = '/tmp/wf-health.acc', ALS = '/tmp/wf-health.al';
const ALIVE = '/etc/wrtfreedom/health.alive', DOWNF = '/etc/wrtfreedom/health.down', BOOTS = '/etc/wrtfreedom/boots.json', BOOTT = '/tmp/wf-health.boot.json';
const SPACE = '/tmp/wf-space.json', CLEAN = '/tmp/wf-clean.json', W = '/usr/share/wrtfreedom';
/* orologio plausibile (dopo il 2025): prima della sincronizzazione l'ora può essere quella dell'ultimo spegnimento */
const TOK = 1735689600;
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
/* stato del file senza seguire i collegamenti (lstat, se il modulo fs di ucode lo offre) */
const lst = FS.lstat ?? stat;
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function upsec() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
/* opzione di una sezione con nome di /etc/config/wrtfreedom letta dal file, senza processi (come svc.uc) */
function uo(sec, opt) {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
		let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m && m[1] == opt) return m[2];
	}
	return '';
}
const EN = uo('ui', 'lang') == 'en';
function L(it, en) { return EN ? en : it; }
/* un lavoro per tipo alla volta; un blocco rimasto da un lavoro interrotto si toglie dopo max secondi */
function lock(n, max) {
	let d = '/tmp/wf-health.' + n + '.lock';
	if (mkdir(d)) return d;
	let s = stat(d);
	if (s && time() - s.mtime > max) { rmdir(d); if (mkdir(d)) return d; }
	return null;
}
let UB = null;
function ub(o, m, a) {
	if (UB == null) { try { UB = require('ubus').connect() ?? false; } catch (e) { UB = false; } }
	let r = UB ? UB.call(o, m, a ?? {}) : null;
	if (r == null) { try { r = json(sh('ubus call ' + o + ' ' + m + (a ? ' ' + q(sprintf('%J', a)) : '') + ' 2>/dev/null')); } catch (e) { r = null; } }
	return r;
}
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' sys ' + q(txt) + ' >/dev/null 2>&1'); }
function fwrev() { return match(readfile('/etc/openwrt_release') ?? '', /DISTRIB_REVISION='?([^'\n]{1,80})'?/)?.[1] ?? ''; }

/* ---------------- storico 24 ore ---------------- */
/* stessa lettura delle righe di hhist in wrtfreedom.uc: se cambia il formato, cambiarle insieme */
function histread() {
	let R = [];
	for (let l in split(readfile(HIST) ?? '', '\n')) {
		let m = match(l, /^([0-9]{9,11}) (-|[0-9]{1,3}) (-|[0-9]{1,3}) (-|[0-9]{1,3})$/);
		if (m) push(R, l);
	}
	return R;
}
function histadd(A) {
	let now = time(), R = filter(histread(), (l) => { let t = +split(l, ' ')[0]; return t > now - 86400 - 300 && t <= now; });
	let f = (v) => v == null || v < 0 ? '-' : '' + int(v);
	push(R, A.b + ' ' + f(A.cpu) + ' ' + f(A.mem) + ' ' + f(A.temp));
	if (length(R) > 288) R = slice(R, length(R) - 288);
	writefile(HIST + '.t', join('\n', R) + '\n'); rename(HIST + '.t', HIST);
}

/* ---------------- Avvisi Di Salute ---------------- */
const RANK = { ok: 0, warn: 1, bad: 2 };
function altext(k, lvl, H) {
	let tc = H.temp?.c, dp = H.disk?.pct, mp = H.mem?.pct, cp = H.cpu?.pct;
	if (lvl == 'ok') {
		if (k == 'temp') return '✅ ' + L('Temperatura del router tornata normale', 'Router temperature back to normal') + (tc != null ? ': ' + tc + ' °C' : '');
		if (k == 'disk') return '✅ ' + L('Spazio del router di nuovo libero', 'Router storage free again') + (dp != null ? ': ' + (100 - dp) + '% ' + L('libero', 'free') : '');
		if (k == 'mem') return '✅ ' + L('Memoria del router tornata normale', 'Router memory back to normal') + (mp != null ? ': ' + mp + '% ' + L('usata', 'used') : '');
		return '✅ ' + L('Processore del router tornato tranquillo', 'Router processor calm again') + (cp != null ? ': ' + cp + '%' : '');
	}
	if (k == 'temp') return (lvl == 'bad' ? '🔥 ' + L('Router molto caldo', 'Router very hot') : '🌡️ ' + L('Router caldo', 'Router hot')) + ': ' + tc + ' °C';
	if (k == 'disk') return '💾 ' + (lvl == 'bad' ? L('Spazio del router pieno', 'Router storage full') : L('Spazio del router quasi pieno', 'Router storage almost full')) + ': ' + (100 - dp) + '% ' + L('libero', 'free');
	if (k == 'mem') return '🧠 ' + L('Memoria del router quasi finita da 5 minuti', 'Router memory almost full for 5 minutes') + ': ' + mp + '% ' + L('usata', 'used');
	return '⚙️ ' + L('Processore del router sotto sforzo da 10 minuti', 'Router processor under strain for 10 minutes') + ': ' + cp + '%';
}
/* livello con il rientro: torna «ok» solo un po' sotto la soglia (niente avvisi a ripetizione sul confine) */
function hyst(k, lvl, prev, H) {
	if (lvl != 'ok' || (prev ?? 'ok') == 'ok') return lvl;
	let T = H.th ?? {};
	if (k == 'temp' && H.temp?.c != null && H.temp.c > (T.temp ?? 75) - 3) return prev;
	if (k == 'disk' && H.disk?.pct != null && H.disk.pct > (T.disk ?? 85) - 2) return prev;
	if (k == 'mem' && H.mem?.pct != null && H.mem.pct > (T.mem ?? 90) - 5) return prev;
	if (k == 'cpu' && H.cpu?.pct != null && H.cpu.pct >= (T.cpu ?? 90) - 10) return prev;
	return lvl;
}
function alerts(H, A) {
	let S = rjs(ALS) ?? {}, al = H.al ?? {}, ch = false;
	let lv = { temp: H.temp?.lvl ?? 'ok', disk: H.disk?.lvl ?? 'ok',
		/* memoria e processore: solo se durano (5 e 10 minuti di fila) */
		mem: (A.mc ?? 0) >= 5 ? 'warn' : 'ok', cpu: (A.cc ?? 0) >= 10 ? 'warn' : 'ok' };
	for (let k in ['temp', 'disk', 'mem', 'cpu']) {
		let prev = S[k] ?? 'ok', n = hyst(k, lv[k], prev, H);
		if (n == prev) continue;
		S[k] = n; ch = true;
		/* avviso quando sale e quando torna normale (da «molto» a «poco» niente: è ancora da controllare) */
		if (al[k] && (RANK[n] > RANK[prev] || n == 'ok')) ev('health_' + k + (n == 'ok' ? '_ok' : ''), altext(k, n, H));
	}
	if (ch) wjs(ALS, S);
}

function tick() {
	let lk = lock('tick', 120);
	if (!lk) return;
	let H = ub('wrtfreedom', 'health', { tick: true }), now = time();
	if (type(H) == 'object' && !H.error) {
		let b = now - now % 300, A = rjs(ACC);
		/* blocco di 5 minuti finito: una riga nello storico con i picchi dei minuti (orologio indietro = si riparte) */
		if (A && A.b != b) { if (A.b < b && A.b >= TOK) histadd(A); A = null; }
		A = A ?? { b: b, mc: 0, cc: 0 };
		let mx = (o, v) => v == null ? o : (o == null || v > o ? v : o);
		A.cpu = mx(A.cpu, H.cpu?.pct); A.mem = mx(A.mem, H.mem?.pct); A.temp = mx(A.temp, H.temp?.c);
		/* minuti di fila sopra la soglia (memoria quasi finita, processore sotto sforzo) */
		let a0 = rjs(ACC) ?? {};
		A.mc = H.mem?.pct != null && H.mem.pct >= (H.th?.mem ?? 90) ? (a0.mc ?? 0) + 1 : 0;
		A.cc = H.cpu?.pct != null && H.cpu.pct >= (H.th?.cpu ?? 90) ? (a0.cc ?? 0) + 1 : 0;
		wjs(ACC, A);
		alerts(H, A);
	}
	/* segno di vita ogni 6 ore (scrittura rada in /etc): all'accensione dice da quando è spento, insieme agli altri
	   salvataggi in /etc/wrtfreedom */
	let s = stat(ALIVE);
	if (now >= TOK && (!s || now - s.mtime >= 21600)) { mkdir('/etc/wrtfreedom'); writefile(ALIVE + '.t', now + ' ' + fwrev() + '\n'); rename(ALIVE + '.t', ALIVE); }
	rmdir(lk);
}

/* ---------------- perché si è riavviato ---------------- */
function fmatch(f, v, lo, hi) {
	for (let p in split(f, ',')) {
		let m = match(p, /^(\*|([0-9]{1,2})(-([0-9]{1,2}))?)(\/([0-9]{1,2}))?$/);
		if (!m) continue;
		let a = lo, b = hi, st = +(m[6] ?? 1) || 1;
		if (m[1] != '*') { a = +m[2]; b = m[4] != null ? +m[4] : (m[6] != null ? hi : a); }
		if (v >= a && v <= b && (v - a) % st == 0) return true;
	}
	return false;
}
/* 2.75: giorno della settimana 0…6 (0 = domenica, come crontab, fw4 e i giorni salvati) da un localtime/gmtime: in ucode
   wday va da 1 a 7 con la domenica = 7. L'unica regola del file: chi vuole il giorno lo chiede qui */
function wd0(lt) { return lt.wday % 7; }
function cmatch(w, t) {
	let lt = localtime(t), dw = wd0(lt);
	let dm = fmatch(w[2], lt.mday, 1, 31), dd = fmatch(w[4], dw, 0, 7) || (dw == 0 && fmatch(w[4], 7, 0, 7));
	let day = (w[2] != '*' && w[4] != '*') ? (dm || dd) : (dm && dd);
	return day && fmatch(w[0], lt.min, 0, 59) && fmatch(w[1], lt.hour, 0, 23) && fmatch(w[3], lt.mon, 1, 12);
}
/* chi ha chiesto lo spegnimento: una riga accesa del crontab con «reboot» nell'orario di adesso (o del minuto prima) =
   riavvio programmato; il Watchdog Della Linea lo scrive negli Eventi (wd_reboot) poco prima; altrimenti chiesto.
   La regola «reboot» è la stessa di healthboot in wrtfreedom.uc: se cambia, cambiarle insieme */
function downwhy(now) {
	for (let l in split(readfile('/etc/crontabs/root') ?? '', '\n')) {
		if (substr(ltrim(l), 0, 1) == '#') continue;
		let f = match(l, /^[ \t]*([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+(.*)$/);
		if (!f || !match(f[6], /(^|[ ;&|({])(\/sbin\/)?reboot([ ;&|)}]|$)/)) continue;
		let w = slice(f, 1, 6);
		if (cmatch(w, now) || cmatch(w, now - 60) || cmatch(w, now - 120)) return 'sched';
	}
	let evf = uo('ev', 'persist') == '1' ? '/etc/wrtfreedom/events.log' : '/tmp/wf-events.log';
	for (let l in split(readfile(evf) ?? '', '\n')) {
		let p = split(l, '|', 4);
		if (length(p) == 4 && p[1] == 'wd_reboot' && now - +p[0] < 180) return 'watchdog';
	}
	return 'asked';
}
function down() {
	let now = time();
	mkdir('/etc/wrtfreedom');
	if (has(HIST)) { writefile(HISTE + '.t', readfile(HIST)); rename(HISTE + '.t', HISTE); }
	wjs(DOWNF, { t: now >= TOK ? now : null, why: downwhy(now), rev: fwrev() });
}
/* Spie Di Notte (wrtfreedom.ledn): adesso è dentro la fascia? (giorni del crontab: 0 = domenica) */
function nightnow() {
	if (uo('ledn', 'on') != '1') return false;
	let hm = (s) => { let m = match(s ?? '', /^([0-9]{2}):([0-9]{2})$/); return m ? +m[1] * 60 + +m[2] : null; };
	let f = hm(uo('ledn', 'from')), t = hm(uo('ledn', 'to')), lt = localtime(time()), n = lt.hour * 60 + lt.min;
	if (f == null || t == null || f == t) return false;
	let inw = f < t ? (n >= f && n < t) : (n >= f || n < t), dw = (f > t && n < t) ? (wd0(lt) + 6) % 7 : wd0(lt);
	let days = split(trim(uo('ledn', 'days')), ' ');
	return inw && (!length(days[0]) || index(days, '' + dw) >= 0);
}
function boot() {
	if (!has(HIST) && has(HISTE)) writefile(HIST, readfile(HISTE));
	/* Spie Di Notte subito se è notte (l'ora è già quella dell'ultimo file scritto in /etc, poi la corregge il crontab) */
	if (nightnow()) sh('sh ' + W + '/cron.sh ledoff ' + q(replace(trim(uo('ledn', 'keep')), / +/g, ',')) + ' >/dev/null 2>&1');
	/* segni letti e tolti subito: un blocco più avanti non deve trovare quello di questo spegnimento */
	let D = rjs(DOWNF), al = split(trim(readfile(ALIVE) ?? ''), ' '), at = +(al[0] ?? 0) || null, rev = fwrev();
	unlink(DOWNF);
	/* spento senza preavviso: ultima ora sicura = il salvataggio più recente in /etc/wrtfreedom (segno di vita ogni 6 ore,
	   gli altri salvataggi anche ogni 30 minuti), letto prima di scrivere qualcosa in questa accensione */
	let lw = at;
	if (at) for (let f in lsdir('/etc/wrtfreedom') ?? []) { let s = lst('/etc/wrtfreedom/' + f); if (s && s.mtime > lw) lw = s.mtime; }
	let pst = length(filter(lsdir('/sys/fs/pstore') ?? [], (f) => substr(f, 0, 6) == 'dmesg-')) > 0;
	let why = null, last = null;
	if (D) { why = (D.rev && length(rev) && D.rev != rev) ? 'upgrade' : (D.why ?? 'asked'); last = D.t; }
	else if (at) { why = (length(al[1] ?? '') && length(rev) && al[1] != rev) ? 'upgrade' : pst ? 'crash' : 'power'; last = lw; }
	/* orologio sincronizzato prima di scrivere le ore (al massimo 10 minuti: all'accensione l'ora è quella dell'ultimo
	   file scritto in /etc) */
	for (let i = 0; i < 60 && !has('/tmp/.wf-ntp'); i++) sh('sleep 10');
	let now = time(), bt = has('/tmp/.wf-ntp') && now >= TOK ? now - upsec() : null;
	let E = { t: bt, why: why, off: (bt && last && bt >= last) ? bt - last : null, approx: !D };
	wjs(BOOTT, E);
	if (why == null) return;
	let B = rjs(BOOTS);
	B = type(B) == 'array' ? B : [];
	push(B, E);
	if (length(B) > 20) B = slice(B, length(B) - 20);
	mkdir('/etc/wrtfreedom'); wjs(BOOTS, B);
	/* riavvio inatteso: avviso negli Eventi (e su Telegram con la categoria Riavvio E Sistema) */
	if ((why == 'power' || why == 'crash') && uo('health', 'al_boot') != '0') {
		let m = E.off != null ? int((E.off + 59) / 60) : null;
		ev('health_boot', '⚡ ' + (why == 'crash' ? L('Il router si era bloccato e si è riavviato da solo', 'The router had frozen and restarted by itself') :
			L('Il router si è riavviato da solo: mancanza di corrente', 'The router restarted by itself: power cut')) +
			(m != null && why == 'power' ? ' · ' + L('spento per circa ', 'off for about ') + (m < 120 ? m + ' min' : int(m / 60) + ' h') : ''));
	}
}

/* ---------------- spazio e Pulizia Sicura ---------------- */
function kb(p) { return +(match(sh('du -sk ' + q(p) + ' 2>/dev/null'), /^([0-9]{1,15})/)?.[1] ?? 0) * 1024; }
/* file di AdGuard Home (una regola sola, la stessa di adgyaml di lib.sh e di wrtfreedom.uc, ricopiata identica in netx.uc,
   dev.uc, health.uc e vpnctl.uc): uci adguardhome.config.config_file o config (letti dal file, senza processi), poi la
   cache /tmp/wf-adgyaml scritta da lib.sh (un file trovato vale 10 minuti, «-» = non trovato 1 minuto), poi
   sh lib.sh adgyaml (-c del comando del servizio, poi i percorsi di serie; riscrive la cache). null = non trovato */
function adgyaml() {
	let s = false, u = {};
	for (let l in split(readfile('/etc/config/adguardhome') ?? '', '\n')) {
		if (match(l, /^[ \t]*config[ \t]/)) { s = match(l, /^[ \t]*config[ \t]+[^ \t]+[ \t]+['"]?config['"]?[ \t]*$/) != null; continue; }
		let m = s ? match(l, /^[ \t]*option[ \t]+(config_file|config)[ \t]+['"]?([^'"]{1,255})/) : null;
		if (m) u[m[1]] = trim(m[2]);
	}
	for (let f in [ u.config_file, u.config ]) if (length(f) && stat(f)) return f;
	let c = stat('/tmp/wf-adgyaml'), y = c ? trim(readfile('/tmp/wf-adgyaml') ?? '') : '';
	if (y == '-' && time() - c.mtime < 60) return null;
	if (length(y) && y != '-' && time() - c.mtime < 600 && stat(y)) return y;
	y = trim(sh('sh /usr/share/wrtfreedom/lib.sh adgyaml 2>/dev/null'));
	return length(y) && stat(y) ? y : null;
}
/* cartella dei dati di AdGuard Home: workdir della sua configurazione, poi la cartella del suo file (adgyaml), poi i
   percorsi di serie */
function adgdir() {
	let wd = '', y = adgyaml();
	let yd = y ? replace(y, /\/[^\/]*$/, '') : '';
	for (let l in split(readfile('/etc/config/adguardhome') ?? '', '\n')) { let m = match(l, /^[[:blank:]]*option workdir '?([^' ]{1,200})'?/); if (m) wd = m[1]; }
	for (let d in [wd, yd, '/var/lib/adguardhome', '/etc/adguardhome', '/opt/AdGuardHome', '/opt/adguardhome'])
		if (length(d) && has(d + '/data')) return d + '/data';
	return null;
}
/* file della Pulizia Sicura, per gruppo: solo copie scaricate, file temporanei vecchi e registri già ruotati */
function cleanfiles() {
	let now = time(), old = (f) => { let s = lst(f); return s && s.type == 'file' && now - s.mtime > 1800 ? s.size : 0; }, G = { pkg: [], tmp: [], logs: [], adg: [] };
	let add = (g, f, b) => { if (b > 0) push(G[g], [f, b]); };
	/* pacchetti scaricati: cache di apk (anche in /etc se è stata spostata lì) e pacchetti caricati in /tmp */
	for (let d in ['/etc/apk/cache', '/var/cache/apk', '/var/cache/opkg'])
		for (let f in lsdir(d) ?? []) if (match(f, /\.(apk|ipk)$/)) add('pkg', d + '/' + f, old(d + '/' + f));
	for (let f in lsdir('/tmp') ?? []) if (match(f, /\.(apk|ipk)$/)) add('pkg', '/tmp/' + f, old('/tmp/' + f));
	/* firmware e copie caricati e mai usati (più vecchi di 30 minuti; una copia in attesa di conferma resta) */
	let bakwait = length(filter(lsdir('/etc/wrtfreedom/bak') ?? [], (d) => has('/etc/wrtfreedom/bak/' + d + '/id'))) > 0;
	for (let f in ['/tmp/firmware.bin', '/tmp/sysupgrade.img', '/tmp/wf-pkg.tgz']) add('tmp', f, old(f));
	if (!bakwait) add('tmp', '/tmp/backup.tar.gz', old('/tmp/backup.tar.gz'));
	/* registri già ruotati (quelli in uso restano), solo file veri e mai collegamenti; /var/log di solito è /tmp/log */
	for (let f in lsdir('/var/log') ?? []) if (match(f, /\.([0-9]{1,2}|old|gz)$/)) add('logs', '/var/log/' + f, old('/var/log/' + f));
	/* AdGuard Home: registro delle richieste già ruotato (quello di adesso e le statistiche restano) */
	let ad = adgdir();
	if (ad) for (let f in lsdir(ad) ?? []) if (match(f, /^querylog\.json\.[0-9]{1,2}$/)) add('adg', ad + '/' + f, old(ad + '/' + f));
	return G;
}
const CLN = {
	pkg: [ 'Pacchetti Scaricati', 'Packages Downloaded', 'Si riscaricano se servono', 'Downloaded again if needed' ],
	tmp: [ 'File Caricati Non Usati', 'Unused Uploaded Files', 'Firmware e copie caricati da più di 30 minuti', 'Firmware and copies uploaded over 30 minutes ago' ],
	logs: [ 'Registri Vecchi', 'Old Logs', 'Solo quelli già archiviati', 'Only the archived ones' ],
	adg: [ 'Registro Vecchio Di AdGuard Home', 'Old AdGuard Home Log', 'Le statistiche restano', 'Statistics stay' ]
};
function space() {
	let lk = lock('space', 300);
	if (!lk) return;
	let ov = has('/overlay/upper'), base = ov ? '/overlay/upper' : '/', I = {}, ad = adgdir();
	let G = { usr: 'apps', lib: 'apps', bin: 'apps', sbin: 'apps', opt: 'apps', www: 'web', etc: 'cfg', root: 'home', home: 'home' };
	/* cartelle di primo livello (con overlay = solo quello aggiunto dopo il firmware), in gruppi con nomi semplici; senza
	   overlay solo programmi, impostazioni e amministratore (mai tutto il disco), al massimo 60 secondi */
	let du = ov ? 'du -x -k -d 1 ' + q(base) + ' 2>/dev/null' : 'du -x -k -s /usr /lib /etc /root 2>/dev/null';
	if (!ov) du = (has('/usr/bin/timeout') || has('/bin/timeout')) ? 'timeout 60 ' + du :
		du + ' & p=$!; ( sleep 60; kill $p ) >/dev/null 2>&1 & w=$!; wait $p; kill $w 2>/dev/null';
	for (let l in split(sh(du), '\n')) {
		let m = match(l, /^([0-9]{1,15})[ \t]+(.+)$/);
		if (!m || m[2] == base || m[2] == '/') continue;
		let n = replace(m[2], /^.*\//, ''), g = G[n] ?? 'other';
		if (!ov && index(['proc', 'sys', 'dev', 'tmp', 'var', 'overlay', 'rom', 'mnt'], n) >= 0) continue;
		I[g] = (I[g] ?? 0) + +m[1] * 1024;
	}
	/* AdGuard Home sulla memoria interna: conta a parte (statistiche e registro possono crescere molto) */
	if (ad && (ov ? has(base + ad) : index(ad, '/var/') != 0 && index(ad, '/tmp/') != 0)) {
		let b = kb(ov ? base + ad : ad);
		if (b > 0) { I.adg = b; let g = G[split(substr(ad, 1), '/')[0]] ?? 'other'; I[g] = (I[g] ?? 0) - b; if (I[g] < 0) I[g] = 0; }
	}
	let NM = { apps: L('Programmi Aggiunti', 'Added Programs'), cfg: L('Impostazioni', 'Settings'), adg: 'AdGuard Home', web: L('Pagine Web', 'Web Pages'),
		home: L('File Dell\'Amministratore', 'Administrator Files'), other: L('Altro', 'Other') };
	let items = sort(map(filter(keys(I), (k) => I[k] > 0), (k) => ({ id: k, name: NM[k], b: I[k] })), (a, b) => b.b - a.b);
	let C = cleanfiles(), cl = [];
	for (let k in ['pkg', 'tmp', 'logs', 'adg']) {
		let b = 0;
		for (let x in C[k]) b += x[1];
		if (b > 0) push(cl, { id: k, name: L(CLN[k][0], CLN[k][1]), desc: L(CLN[k][2], CLN[k][3]), b: b,
			/* ram = libera memoria del router, non spazio della memoria interna */
			ram: length(filter(C[k], (x) => match(x[0], /^\/(tmp|var)\//))) == length(C[k]) });
	}
	let si = ub('system', 'info', {})?.root ?? {};
	wjs(SPACE, { t: time(), mnt: ov ? '/overlay' : '/', total: +(si.total ?? 0) * 1024, used: +(si.used ?? 0) * 1024, items: slice(items, 0, 6), clean: cl });
	rmdir(lk);
}
function clean(ids) {
	let lk = lock('space', 300);
	if (!lk) { wjs(CLEAN, { t: time(), ids: [], freed: 0, busy: true }); return; }
	let C = cleanfiles(), fr = 0, done = [];

	for (let k in split(ids, ',')) {
		if (!C[k]) continue;
		push(done, k);
		for (let x in C[k]) if (unlink(x[0])) fr += x[1];
	}
	wjs(CLEAN, { t: time(), ids: done, freed: fr });
	rmdir(lk);
	space();
}

const A = ARGV[0] ?? '';
if (A == 'tick') tick();
else if (A == 'boot') boot();
else if (A == 'down') down();
else if (A == 'space') space();
else if (A == 'clean') clean('' + (ARGV[1] ?? ''));
else print('uso: ucode health.uc tick|boot|down|space|clean <pkg,tmp,logs,adg>\n');
