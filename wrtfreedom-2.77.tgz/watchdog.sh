#!/bin/sh
# WrtFreedom: Ripristino Automatico, controllo continuo (istanza "wd" del servizio wrtfreedom, la sceglie wrtfreedom.init)
# uso: watchdog.sh           Watchdog Della Linea, senza quectel-5g-tools (acceso da wrtfreedom.wd.enabled)
#      watchdog.sh insieme   Controllo Di Internet insieme al 5g-watchdog di quectel-5g-tools (acceso da wrtfreedom.wd.inet,
#                            2.65): il 5G e il modem restano suoi, qui solo se internet risponde sulla linea principale
# Impostazioni (uci wrtfreedom.wd): interval (secondi), hosts (indirizzi da provare), fails (prove fallite di fila),
# action (solo senza quectel-5g-tools: reconnect = riconnetti la linea, modem = riavvia il modem, reboot = riavvia il
# router), lastres (solo «insieme»: riavvio del router come ultima risorsa, di serie acceso).
# Gli interventi finiscono negli Eventi (categoria Linea): avvisi su telefono e Telegram come gli altri eventi.
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh /usr/share/wrtfreedom/event.sh wd "$1" "$2" >/dev/null 2>&1; logger -t wrtfreedom-wd "$2"; }
# MIN = secondi di un minuto; stato di line.sh, ora dall'accensione, ultimo riavvio fatto da qui (in /etc: resta dopo il
# riavvio ed è l'unica scrittura in flash, solo quando riavvia), segno dell'orologio sincronizzato (event.sh, evento ntp).
# WF_WDTEST = cartella del router finto delle prove (tools/test/router/all.sh): un minuto dura WF_WDMIN secondi (di serie
# 1) e i file sono lì; ignorata sul router vero (c'è /etc/openwrt_release)
MODE=$1; MIN=60; LS=/tmp/wf-line.json; UPF=/proc/uptime; LAST=/etc/wrtfreedom/wd-last.json; NTP=/tmp/.wf-ntp
[ -n "$WF_WDTEST" ] && [ ! -e /etc/openwrt_release ] && { MIN=${WF_WDMIN:-1}; case "$MIN" in ''|*[!0-9]*|0) MIN=1;; esac; LS=$WF_WDTEST/line.json; UPF=$WF_WDTEST/uptime; LAST=$WF_WDTEST/wd-last.json; NTP=$WF_WDTEST/ntp; }
nap() { sleep $(( $1 * MIN / 60 )); }
# secondi dall'accensione in up (senza processi in più)
upt() { up=; read up _ < "$UPF"; up=${up%.*}; case "$up" in ''|*[!0-9]*) up=0;; esac; }
# zona internet vera (con il NAT, mai il nome «wan» fisso), come wanifs() di event.sh
wanifs() { for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do [ "$(uci -q get firewall.$z.name)" = vpnout ] || uci -q get "firewall.$z.network"; done; }
# stato della linea $1 per il modo «insieme» (una sola regola, sola lettura): off = spenta apposta (disabled nella rete o
# ifdown dell'utente: autostart false), wait = in collegamento (pending) o accesa da meno di 3 minuti (qualcuno la sta già
# ricollegando, anche il 5g-watchdog), go = si può intervenire
lstate() {
	case "$(uci -q get "network.$1.disabled")" in 1|true|yes|on) echo off; return;; esac
	j=$(ifstatus "$1" 2>/dev/null)
	[ "$(printf '%s' "$j" | jsonfilter -e '@.autostart' 2>/dev/null)" = false ] && { echo off; return; }
	[ "$(printf '%s' "$j" | jsonfilter -e '@.pending' 2>/dev/null)" = true ] && { echo wait; return; }
	u=$(printf '%s' "$j" | jsonfilter -e '@.uptime' 2>/dev/null)
	case "$u" in ''|*[!0-9]*) ;; *) [ "$u" -lt $((3 * MIN)) ] && [ "$(printf '%s' "$j" | jsonfilter -e '@.up' 2>/dev/null)" = true ] && { echo wait; return; };; esac
	echo go
}
# interfaccia della linea, quella che usa il router come in line.sh: la principale della Linea Di Riserva se è impostata,
# altrimenti quella del dispositivo della prima rotta predefinita IPv4 (fra le interfacce dello stesso dispositivo quella
# con la rotta: wan e non wan6; wwan_4 o wwan_6 diventano wwan). Senza rotta una della zona internet (non le sole IPv6);
# nel modo «insieme» (c'è un modem 5G) prima la linea mobile, riconosciuta dal protocollo: la prima della zona può essere
# il cavo (25/10: wan prima di wwan)
lineif() {
	f=$(uci -q get wrtfreedom.fo.main); m=$(uci -q get wrtfreedom.fo.backup)
	[ "$(uci -q get wrtfreedom.fo.enabled)" = 1 ] && [ -n "$f" ] && [ -n "$m" ] && [ "$f" != "$m" ] && { echo "$f"; return; }
	# rotta predefinita: la prima che non passa da una WireGuard (VPN dell'utente o del pacchetto: ricollegarla non serve)
	f=
	for d in $(ip -4 route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p'); do
		g=
		for c in $(ubus call network.interface dump 2>/dev/null | jsonfilter -e "@.interface[@.l3_device=\"$d\"].interface" 2>/dev/null); do
			[ "$(uci -q get "network.$c.proto")" = wireguard ] && { g=; break; }
			[ -n "$g" ] || g=$c
			[ -n "$(ifstatus "$c" 2>/dev/null | jsonfilter -e '@.route[@.target="0.0.0.0"].target' 2>/dev/null)" ] && { g=$c; break; }
		done
		[ -n "$g" ] && { f=$g; break; }
	done
	[ -n "$f" ] && { f=${f%_4}; echo "${f%_6}"; return; }
	# senza rotta salta le reti spente apposta (lstate off: una wan disattivata non deve fermare il controllo della
	# wwan caduta); se sono spente apposta tutte, la prima spenta (lstate off: niente intervento)
	m=; o=
	for n in $(wanifs); do
		p=$(uci -q get "network.$n.proto")
		case "$p" in none|dhcpv6) continue;; esac
		[ "$(lstate "$n")" = off ] && { [ -n "$o" ] || o=$n; continue; }
		[ -n "$f" ] || f=$n
		case "$p" in modemmanager|qmi|mbim|ncm|3g|wwan) [ -n "$m" ] || m=$n;; esac
	done
	[ -n "$f" ] || f=$o
	if [ "$MODE" = insieme ] && [ -n "$m" ]; then echo "$m"; else echo "$f"; fi
}
# impostazioni, rilette a ogni giro
cfg() {
	IV=$(uci -q get wrtfreedom.wd.interval); case "$IV" in ''|*[!0-9]*) IV=60;; esac; [ "$IV" -lt 10 ] && IV=10
	H=$(uci -q get wrtfreedom.wd.hosts); [ -n "$H" ] || H="1.1.1.1 8.8.8.8"
	F=$(uci -q get wrtfreedom.wd.fails); case "$F" in ''|*[!0-9]*) F=5;; esac; [ "$F" -ge 1 ] || F=5
	A=$(uci -q get wrtfreedom.wd.action); [ -n "$A" ] || A=reconnect
}
# internet risponde? ok=1; bk=1 = Linea Di Riserva in uso. Stato del controllo della linea (line.sh, 2.42): niente ping
# doppi; se manca o è vecchio, ping come prima. Una sola lettura: st (secondi dal 1970), sa (linea in uso), so (internet)
check() {
	ok=0; bk=0; fr=0
	st=; sa=; so=; eval "$(jsonfilter -i "$LS" -e 'st=@.t' -e 'sa=@.active' -e 'so=@.ok' 2>/dev/null)"
	case "$st" in ''|*[!0-9]*) st=;; esac
	[ -n "$st" ] && [ $(( $(date +%s) - st )) -lt 10 ] && { fr=1; [ "$sa" = main ] || bk=1; }
	# modo «insieme»: con la Linea Di Riserva in uso internet c'è già, niente da fare
	[ $bk = 1 ] && [ "$MODE" = insieme ] && return
	if [ $fr = 1 ] && [ $bk = 0 ]; then
		# jsonfilter con «so=@.ok» scrive 1/0, non true/false (2.69)
		case "$so" in true|1) ok=1;; esac
	else
		for h in $H; do ping -c 1 -W 3 "$h" >/dev/null 2>&1 && { ok=1; break; }; done
	fi
	# alcuni operatori bloccano il ping: prova anche una pagina web
	[ $ok = 0 ] && wget -q -T 6 -O /dev/null http://connectivitycheck.gstatic.com/generate_204 >/dev/null 2>&1 && ok=1
}
# durata detta negli eventi: $1 secondi → «5 minuti», «1 minuto», «40 s»
dur() {
	if [ "$1" -lt 60 ]; then echo "$1 s"
	elif [ "$1" -lt 90 ]; then t "1 minuto" "1 minute"
	else m=$(( ($1 + 30) / 60 )); t "$m minuti" "$m minutes"; fi
}
# riavvio del router permesso adesso dal tempo (una sola regola per i due modi; up = secondi dall'accensione, now = ora,
# $1 = minuti minimi fra due riavvii)? Mai nei primi 10 minuti dall'accensione, l'ultimo almeno $1 minuti fa
# (wd-last.json: t = ora del riavvio, ntp = orologio sincronizzato in quel momento; resta dopo il riavvio). File presente
# ma illeggibile = no; ora salvata con l'orologio non sincronizzato o nel futuro = solo dopo $1 minuti di accensione (ogni
# riavvio la azzera)
bootok() {
	[ "$up" -ge $((10 * MIN)) ] || return 1
	[ -e "$LAST" ] || return 0
	l=$(jsonfilter -i "$LAST" -e '@.t' 2>/dev/null); case "$l" in ''|*[!0-9]*) return 1;; esac
	d=$((now - l))
	if [ $d -lt 0 ] || [ "$(jsonfilter -i "$LAST" -e '@.ntp' 2>/dev/null)" = false ]; then [ "$up" -ge $(($1 * MIN)) ]
	else [ $d -ge $(($1 * MIN)) ]; fi
}
# salva l'ora del riavvio che sta per partire (unica scrittura in flash, solo quando riavvia davvero); sy = orologio
# sincronizzato. Senza salvataggio niente riavvio (altrimenti dopo il riavvio il limite non si saprebbe)
bootsave() {
	sy=false; [ -f "$NTP" ] && sy=true
	mkdir -p "${LAST%/*}" && printf '{"t":%s,"ntp":%s}\n' "$now" "$sy" > "$LAST.t" && mv "$LAST.t" "$LAST" && return 0
	rm -f "$LAST.t"; return 1
}
# modo «insieme»: Riavvio Come Ultima Risorsa acceso (lastres, di serie sì) e l'ultimo riavvio almeno 6 ore fa
canboot() {
	L=$(uci -q get wrtfreedom.wd.lastres); [ "${L:-1}" = 1 ] || return 1
	bootok 360
}
fail=0
# Modo «insieme» (2.65): stesso controllo; interviene solo se internet manca sulla linea principale e la linea non è
# spenta apposta. Tempo contato dal primo controllo fallito (f0, secondi dall'accensione: non i giri), a gradini di
# fails × interval (di serie 5 × 60 s = 5 minuti): al 1° e al 2° ricollega la linea (ifdown/ifup, la stessa leva del
# 5g-watchdog); al 3° (15 minuti) riavvio del router se canboot e se l'ora del riavvio è salvata, altrimenti e oltre
# solo nuove riconnessioni ogni 3 gradini (15 minuti). Gradino saltato con la linea in collegamento o accesa da poco
# (ci lavora già qualcuno); senza linea trovata un solo avviso e niente altro. Mai «riavvia il modem»: è del
# 5g-watchdog. nx = prossimo gradino da fare, said = avviso dato in questo guasto, nl = «linea non trovata» già detto
if [ "$MODE" = insieme ]; then
	f0=; nx=1; said=0; nl=0
	while true; do
		cfg; check; upt; T=$((F * IV)); i=; ln=go
		if [ $bk = 0 ] && [ $ok = 0 ]; then i=$(lineif); [ -n "$i" ] && { nl=0; ln=$(lstate "$i"); }; fi
		if [ $bk = 1 ] || [ $ok = 1 ] || [ "$ln" = off ]; then
			[ $ok = 1 ] && [ $said = 1 ] && ev back "✅ $(t "Ripristino Automatico: internet è tornato dopo" "Automatic Recovery: internet is back after") $(dur $(( (up - f0) * 60 / MIN )))"
			f0=; nx=1; said=0
		else
			[ -n "$f0" ] || f0=$up
			k=$(( (up - f0) * 60 / MIN / T )); [ $k -gt 3 ] && k=$((k - k % 3))
			if [ $k -ge $nx ]; then
				nx=$((k + 1)); [ $k -ge 3 ] && nx=$((k + 3)); s=$(dur $((k * T)))
				if [ -z "$i" ]; then
					[ $nl = 1 ] || { nl=1; said=1; ev noline "⚠️ $(t "Ripristino Automatico: internet non risponde da $s, linea non trovata" "Automatic Recovery: no internet for $s, line not found")"; }
				elif [ "$ln" = go ]; then
					now=$(date +%s)
					# riavvio solo con l'ora salvata (resta dopo il riavvio: è il limite delle 6 ore)
					# scatola nera (2.69) prima di ogni intervento: dopo il riavvio resta la fotografia del guasto
					TO=; command -v timeout >/dev/null 2>&1 && TO="timeout 40"; $TO sh /usr/share/wrtfreedom/bb.sh wd >/dev/null 2>&1
					if [ $((k % 3)) = 0 ] && canboot && bootsave; then
						said=1; ev reboot "🔄 $(t "Ripristino Automatico: internet non risponde da $s, riavvio il router" "Automatic Recovery: no internet for $s, restarting the router")"
						nap 5; reboot; nap 120; continue
					fi
					said=1
					ev reconnect "🔁 $(t "Ripristino Automatico: internet non risponde da $s, ricollego la linea" "Automatic Recovery: no internet for $s, reconnecting the line")"
					ifdown "$i"; nap 3; ifup "$i"
				fi
			fi
		fi
		nap "$IV"
	done
fi
while true; do
	cfg; check
	if [ $ok = 1 ]; then
		[ $fail -ge $F ] && ev back "✅ $(t "Watchdog: linea tornata" "Watchdog: line is back")"
		fail=0
	else
		fail=$((fail + 1))
		# linea spenta apposta (disabled o autostart spento, come il modo «insieme»): niente interventi e niente conto
		if [ $fail -ge $F ]; then i=$(lineif); [ -n "$i" ] && [ "$(lstate "$i")" = off ] && { fail=0; nap "$IV"; continue; }; fi
		if [ $fail -eq $F ] || { [ $fail -gt $F ] && [ $(( (fail - F) % (F * 3) )) -eq 0 ]; }; then
			now=$(date +%s); upt
			# riavvio del router al massimo ogni 6 ore (come «insieme») e mai nei primi 10 minuti dall'accensione: l'ora
			# dell'ultimo riavvio è in wd-last.json (resta dopo il riavvio: senza, a operatore giù riavviava ogni 11 minuti)
			[ "$A" = reboot ] && { bootok 360 && bootsave || A=reconnect; }
			case "$A" in
				modem) ev modem "📡 $(t "Watchdog: Internet non risponde, riavvio il modem" "Watchdog: no Internet, restarting the modem")"
					ucode /usr/share/wrtfreedom/modemctl.uc restart >/dev/null 2>&1 ;;
				reboot) ev reboot "🔄 $(t "Watchdog: Internet non risponde, riavvio il router" "Watchdog: no Internet, rebooting the router")"
					nap 5; reboot ;;
				*) i=$(lineif); ev reconnect "🔁 $(t "Watchdog: Internet non risponde, riconnetto la linea" "Watchdog: no Internet, reconnecting the line")${i:+ ($i)}"
					[ -n "$i" ] && { ifdown "$i"; nap 3; ifup "$i"; } ;;
			esac
			nap 120; continue
		fi
	fi
	nap "$IV"
done
