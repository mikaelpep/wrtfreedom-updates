#!/bin/sh
# WrtFreedom: riceve gli eventi hotplug, li scrive nel registro, manda gli avvisi e lancia le azioni scelte nell'app
# uso: event.sh <sottosistema> (le variabili ACTION, INTERFACE, ... arrivano dall'hotplug)
S="$1"
# eventi hotplug che non finiscono nel registro: si esce subito, prima di leggere data e configurazione
# (stesse condizioni degli agganci in /etc/hotplug.d, scritti da install.sh)
case "$S" in
	iface) [ "$INTERFACE" != loopback ] && case "$INTERFACE" in wgout|wgo[0-9]|wgo[0-9][0-9]) false;; *) true;; esac && {	# wgout, wgo1…: gli avvisi del Servizio VPN li dà vpnctl.uc
		 [ "$ACTION" = ifup ] || [ "$ACTION" = ifdown ] || { [ "$ACTION" = ifupdate ] && [ "$IFUPDATE_ADDRESSES" = 1 ]; }; } || exit 0 ;;
	dhcp) exit 0 ;;	# vecchio aggancio (fino alla 2.41): i dispositivi ora li segue notify.sh (evento «dev»)
	usb) [ "$DEVTYPE" = usb_device ] && { [ "$ACTION" = add ] || [ "$ACTION" = remove ]; } || exit 0 ;;
	block) case "$DEVNAME" in sd*[0-9]|mmcblk*p[0-9]*|nvme*p[0-9]*) ;; *) exit 0;; esac
		[ "$ACTION" = add ] || [ "$ACTION" = remove ] || exit 0 ;;
	button) [ -n "$BUTTON" ] && { [ "$ACTION" = pressed ] || [ "$ACTION" = released ]; } || exit 0 ;;
	ntp) [ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ] || exit 0 ;;
esac
# Controllo Del Nome Di Casa (2.68): ifupdate con indirizzi nuovi (IFUPDATE_ADDRESSES), ramo a parte senza registro, regole né
# controllo della linea: sull'interfaccia di un servizio DDNS acceso Storico Degli IP e, dove 95-ddns non lo sente,
# aggiornamento del nome (cron.sh ddnswd if)
[ "$S" = iface ] && [ "$ACTION" = ifupdate ] && { sh /usr/share/wrtfreedom/cron.sh ddnswd if "$INTERFACE" >/dev/null 2>&1; exit 0; }
now=$(date +%s)
# configurazione letta una volta (un solo uci export al posto di un uci get per opzione e per regola)
. /lib/functions.sh; config_load wrtfreedom
config_get P ev persist; config_get NC ev notify; config_get L ui lang; config_get AO ai on; config_get AW ai why
# Telegram come destinazione degli avvisi (2.75, ev.tg; assente = acceso): «0» = nessun avviso al bot (il bot risponde
# comunque ai comandi; le regole «Allora manda un messaggio» restano azioni scelte dall'utente)
config_get ETG ev tg
LOG=/tmp/wf-events.log; [ "$P" = 1 ] && LOG=/etc/wrtfreedom/events.log
mkdir -p /etc/wrtfreedom
# lingua scelta nell'app: t "italiano" "inglese"
EN=0; [ "$L" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
# Telegram: il messaggio va nella coda (tgq.uc), che lo manda subito o, senza linea, appena torna (2.42).
# Scritto qui e non con ubus: all'accensione rpcd potrebbe non essere ancora pronto
# KB=<mac> (nuovo dispositivo, 2.49): prima riga «#kb:<mac>» = pulsanti «Lo Conosco / Blocca» (tgq.uc)
# $2 = categoria (2.53): riga «#c:<categoria>» per le Ore Silenziose (le categorie scelte passano lo stesso)
tq() { mkdir -p /tmp/wf-tgq; f="/tmp/wf-tgq/$(date +%s)-$$$RANDOM"; { [ -n "$KB" ] && printf '#kb:%s\n' "$KB"; [ -n "$2" ] && printf '#c:%s\n' "$2"; printf '%s' "$1"; } > "$f"; ( ucode /usr/share/wrtfreedom/tgq.uc flush ) </dev/null >/dev/null 2>&1 & }
log() { # tipo|categoria|testo
	echo "$now|$1|$2|$3" >> "$LOG"
	n=$(wc -l < "$LOG"); [ "$n" -gt 550 ] && { tail -n 500 "$LOG" > "$LOG.t" && mv "$LOG.t" "$LOG"; }
	# WF_NOTG=1 (ritorno di una copia con l'esito già scritto dall'Assistente IA nel bot, 2.64): niente Telegram
	# WF_TG=1 (Avviso Ritardo Alto del Controllo Della Linea con «Telegram» scelto, sqm.uc): Telegram anche fuori dalle
	# categorie. Gli avvisi del Firewall (2.75) hanno la loro categoria «fw» e seguono solo le categorie scelte
	[ "$WF_NOTG" = 1 ] || [ "$ETG" = 0 ] || case " $NC " in *" $2 "*) tq "$3" "$2" ;; *) [ "$WF_TG" = 1 ] && tq "$3" "$2" ;; esac
	rules "$1"
	# 2.68: senza Telegram (ifup del Controllo Della VPN da verificare, ritorno già scritto dall'IA) niente spiegazione dell'IA
	[ "$WF_NOTG" = 1 ] || aiwhy "$1"
}
# Avvisi Spiegati Dall'IA (2.61): per i tipi di avviso, con l'Assistente IA e gli Avvisi Spiegati accesi, ai.uc aggiunge
# due righe a questo evento (in sottofondo: l'avviso parte subito come sempre; tetto, stato e coda li controlla ai.uc)
aiwhy() {
	[ "$AO" = 1 ] && [ "$AW" = 1 ] || return 0
	case "$1" in
		cron_health_*_ok) return 0 ;;
		wan_down|lan_down|vpn_down|cron_net_down|cron_fo_backup|cron_fo_none|cron_signal|cron_vpn_fail|cron_ddns_fail|cron_cert_fail|cron_space|cron_temp|cron_adg_down|cron_usage_full|cron_usage_slowerr|cron_sim|cron_simerr|cron_vpnsvc_down|cron_vpnacc|cron_wifi_radar|cron_dev_nft|cron_fw_attack|cron_sqm_lag|cron_health_*|wd_modem|wd_reboot|wd_reconnect) ;;
		*) return 0 ;;
	esac
	# un avviso alla volta (2.62): con un altro già in corso (why.lock di meno di 2 minuti) niente processo in attesa
	wl_=$(date -r /tmp/wf-ai/why.lock +%s 2>/dev/null) && [ $((now - wl_)) -le 120 ] && return 0
	( ucode /usr/share/wrtfreedom/ai.uc why "$now" "$1" ) </dev/null >/dev/null 2>&1 &
}
wanifs() { for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do [ "$(uci -q get firewall.$z.name)" = vpnout ] || uci -q get "firewall.$z.network"; done; }	# zona internet vera (con il NAT, mai il nome «wan» fisso)
wgif() { wl_=$(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); for i in $wl_; do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; echo "$wl_" | head -n 1; }	# VPN Per Fuori Casa: con la porta in ascolto, senza il Servizio VPN (come wgiface)
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
act() { # esegue un'azione
	case "$1" in
		modem_restart) ucode /usr/share/wrtfreedom/modemctl.uc restart >/dev/null 2>&1 ;;
		wan_reconnect) for i in $(wanifs); do ifdown "$i"; sleep 3; ifup "$i"; done ;;
		vpn_restart) i=$(wgif); [ -n "$i" ] && ifup "$i" ;;
		vpn_on) i=$(wgif); [ -n "$i" ] && { uci set network.$i.disabled=0; uci commit network; ifup "$i"; } ;;
		vpn_off) i=$(wgif); [ -n "$i" ] && { uci set network.$i.disabled=1; uci commit network; ifdown "$i"; } ;;
		wifi_on) wifi up ;;
		wifi_off) wifi down ;;
		wifi_toggle) if ubus call network.wireless status 2>/dev/null | grep -q '"up": true'; then wifi down; else wifi up; fi ;;
		mount) block mount ;;
		tg) tq "$2" ;;
		cmd) sh -c "$2" >/dev/null 2>&1 ;;
		sqm_on) sh /usr/share/wrtfreedom/sqmctl.sh on >/dev/null 2>&1 ;;	# Controllo Della Linea (2.53)
		sqm_off) sh /usr/share/wrtfreedom/sqmctl.sh off >/dev/null 2>&1 ;;
	esac
}
rule1() { # una regola "Quando … Allora …": $1 = sezione, $2 = evento
	local r=$1 e=$2 on ev a x d lb rm rp pm
	config_get on $r enabled; [ "$on" = 0 ] && return
	config_get ev $r event; [ "$ev" = "$e" ] || return
	# 2.64: regola solo per un dispositivo (mac) o una Persona (person, i suoi dispositivi di adesso): EM = MAC dell'evento
	case "$e" in dev_join|dev_leave)
		config_get rm $r mac; config_get rp $r person; pm=; [ -n "$rp" ] && config_get pm "$rp" mac
		[ -n "$rm$rp" ] && { [ -n "$EM" ] || return; case " $rm $pm " in *" $EM "*) ;; *) return ;; esac; } ;;
	esac
	config_get a $r action; config_get x $r arg; config_get d $r delay 0; config_get lb $r label
	if [ "$d" -gt 0 ]; then
		# azione solo se dopo l'attesa la situazione è ancora quella
		( sleep "$d"; case "$e" in
			wan_down) for i in $(wanifs); do isup "$i" && exit 0; done ;;
			cron_vpnsvc_down) grep -q '"down": *true' /tmp/wf-vpn.json 2>/dev/null || exit 0 ;;
			cron_net_down) [ "$(jsonfilter -i /tmp/wf-line.json -e '@.ok' 2>/dev/null)" = true ] && exit 0 ;;
			vpn_down) i=$(wgif); [ -n "$i" ] && isup "$i" && exit 0 ;;
			if_*_down) i=${e#if_}; isup "${i%_down}" && exit 0 ;;
			if_*_up) i=${e#if_}; isup "${i%_up}" || exit 0 ;;
		  esac
		  echo "$(date +%s)|rule|sys|⚙️ $(t "Azione automatica" "Automatic action"): $lb" >> "$LOG"; act "$a" "$x" ) >/dev/null 2>&1 &
	else
		echo "$now|rule|sys|⚙️ $(t "Azione automatica" "Automatic action"): $lb" >> "$LOG"; act "$a" "$x" &
	fi
}
rules() { config_foreach rule1 rule "$1"; }	# regole per questo evento
case "$S" in
	send)
		act tg "$2" ;;
	act)
		act "$2" "$3" ;;
	test)
		echo "$now|rule|sys|🧪 $(t "Prova azione" "Action test"): $2" >> "$LOG"; act "$2" "$3" ;;
	iface)
		touch /tmp/wf-line.kick	# controllo della linea (line.sh): guarda subito, senza aspettare
		# rete madre: quella delle reti dinamiche (wwan_4 e wwan_6 di wwan) o quella indicata con «@» (wan6 con device @wan)
		MN=${INTERFACE%_[46]}; mn_=$(uci -q get "network.$MN.device"); case "$mn_" in @?*) MN=${mn_#@} ;; esac
		WI=$(wanifs)
		kind=lan; case " $WI " in *" $INTERFACE "*|*" $MN "*) kind=wan;; esac; [ "$INTERFACE" = "$(wgif)" ] && kind=vpn
		case "$ACTION" in ifup) rules "if_${INTERFACE}_up";; ifdown) rules "if_${INTERFACE}_down";; esac
		# Limite Di Velocità della rete ospiti (2.48): la rete ripartita perde le code, si rimettono (solo se mancano)
		[ "$ACTION" = ifup ] && { config_get gd guest dl; config_get gu guest ul; [ -n "$gd$gu" ] && ucode /usr/share/wrtfreedom/wifi.uc glimit check >/dev/null 2>&1 & }
		# AdGuard sulla 53 (2.50): una rete di casa accesa può avere un indirizzo nuovo, il bind di AdGuard si rifà se serve
		[ "$ACTION" = ifup ] && [ $kind != wan ] && [ -f /etc/wrtfreedom/adgmode/orig ] && sh /usr/share/wrtfreedom/adgmode.sh rebind >/dev/null 2>&1 &
		# Controllo Della VPN Per Fuori Casa (2.67): durante il suo ifup da verificare (p in /tmp/wf-vpnwd.json, scritto da
		# wgx.uc) il «down up» di ifup resta negli Eventi e nelle regole ma non va su Telegram: lì arriva solo l'esito (vpnres).
		# 2.68: lo stesso durante Controlla Ora (state run in /tmp/wf-vpnwdrun.json, scritto da meno di 2 minuti)
		[ $kind = vpn ] && { grep -qE '"p": *[1-9]' /tmp/wf-vpnwd.json 2>/dev/null || { grep -qE '"state": *"run"' /tmp/wf-vpnwdrun.json 2>/dev/null &&
			[ $((now - $(date -r /tmp/wf-vpnwdrun.json +%s 2>/dev/null || echo 0))) -lt 120 ]; }; } && WF_NOTG=1
		# una linea, un evento: IPv4 e IPv6 dello stesso dispositivo (wan e wan6, wwan_4 e wwan_6) danno un solo «Linea
		# caduta» o «Linea tornata». Chiave = dispositivo della rete madre (ifstatus: l3_device, poi device), un segno per
		# dispositivo in /tmp/wf-evl-<dispositivo> («ora azione», «noip» = tornata senza IPv4)
		if [ $kind = wan ]; then
			ms_=$(ifstatus "$MN" 2>/dev/null); KD=$(echo "$ms_" | jsonfilter -e '@.l3_device' 2>/dev/null)
			[ -n "$KD" ] || KD=$(echo "$ms_" | jsonfilter -e '@.device' 2>/dev/null); [ -n "$KD" ] || KD=${DEVICE:-$MN}
			# nome della linea: «Linea Di Riserva» se è la riserva scelta in Linea Di Riserva (wrtfreedom.fo.backup, come
			# il metodo fo), altrimenti «Linea»
			config_get FOB fo backup; config_get FOM fo main
			LIT=Linea; LEN=Line
			[ -n "$FOB" ] && [ "$FOB" != "$FOM" ] && { [ "$FOB" = "$INTERFACE" ] || [ "$FOB" = "$MN" ]; } && { LIT="Linea Di Riserva"; LEN="Backup Line"; }
		fi
		# indirizzo IPv4 della stessa linea su un'altra rete accesa (wan accanto a wan6, wwan_4 accanto a wwan_6): stessa
		# rete madre o stesso dispositivo. Vuoto (uscita 1) = nessuna
		v4up() {
			for i in $WI $MN; do for j in "$i" "${i}_4"; do
				[ "$j" = "$INTERFACE" ] && continue
				s_=$(ifstatus "$j" 2>/dev/null) || continue
				[ "$(echo "$s_" | jsonfilter -e '@.up' 2>/dev/null)" = true ] || continue
				a_=$(echo "$s_" | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null); [ -n "$a_" ] || continue
				[ "$j" = "$MN" ] || [ "$j" = "${MN}_4" ] || [ "$(echo "$s_" | jsonfilter -e '@.l3_device' 2>/dev/null)" = "$KD" ] || continue
				echo "$a_"; return 0
			done; done; return 1
		}
		# 0 = l'evento passa. ifdown: si scarta con l'IPv4 della stessa linea ancora su (è caduto solo l'IPv6) o con un altro
		# ifdown entro 20 s. ifup: si scarta un altro ifup entro 20 s, salvo il primo con l'IP dopo un ritorno senza IP
		# (linea accesa prima in IPv6: così l'IP non si perde)
		lfirst() {
			lf_=/tmp/wf-evl-$(printf '%s' "$KD" | tr -c 'A-Za-z0-9_.-' _); lo_=$(cat "$lf_" 2>/dev/null)
			lt_=${lo_%% *}; case "$lt_" in ''|*[!0-9]*) lt_=0;; esac; la_=${lo_#* }; [ $((now - lt_)) -lt 20 ] || la_=
			if [ "$ACTION" = ifdown ]; then
				v4up >/dev/null && return 1
				echo "$now ifdown" > "$lf_"; [ "$la_" = ifdown ] && return 1; return 0
			fi
			case "$la_" in
				ifup) return 1 ;;
				"ifup noip") [ -n "$ip" ] || return 1 ;;
			esac
			if [ -n "$ip" ]; then echo "$now ifup" > "$lf_"; else echo "$now ifup noip" > "$lf_"; fi; return 0
		}
		case "$ACTION" in
			ifup)
				ip=$(ifstatus "$INTERFACE" 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null)
				# linea accesa prima in IPv6: l'IPv4 dalla rete della linea accanto, se c'è già
				[ $kind = wan ] && [ -z "$ip" ] && ip=$(v4up)
				# storico dei cambi di IP pubblico (2.53, svc.uc: IP della linea o chiesto fuori casa dalla linea)
				[ $kind = wan ] && ( sleep 5; ucode /usr/share/wrtfreedom/svc.uc ip ) </dev/null >/dev/null 2>&1 &
				case $kind in wan) lfirst && log wan_up net "$(t "🟢 $LIT tornata" "🟢 $LEN back")${ip:+ · IP $ip}";; vpn) log vpn_up net "$(t "🔐 Server VPN attivo" "🔐 VPN Server up")";; *) log lan_up net "$(t "🟢 Rete $INTERFACE attiva" "🟢 Network $INTERFACE up")";; esac ;;
			ifdown)
				case $kind in wan) lfirst && log wan_down net "$(t "🔴 $LIT caduta" "🔴 $LEN down")";; vpn) log vpn_down net "$(t "🔓 Server VPN spento o caduto" "🔓 VPN Server off or down")";; *) log lan_down net "$(t "🔴 Rete $INTERFACE spenta" "🔴 Network $INTERFACE down")";; esac ;;
		esac ;;
	dev)	# da notify.sh: $2 = join, leave o tg (solo Telegram), $3 = MAC, $4 = come è collegato (Wi-Fi 5 GHz, cavo)
		m=$3; EM=$m; w=$(echo "$4" | tr _ " "); [ $EN = 1 ] && { [ "$w" = cavo ] && w=cable; w=$(echo "$w" | tr , .); }
		LF=$(uci -q get dhcp.@dnsmasq[0].leasefile); LF=${LF:-/tmp/dhcp.leases}	# file delle assegnazioni scelto in dnsmasq
		# nome e indirizzo: assegnazione DHCP, poi indirizzo fisso (dhcp host), poi tabella dei vicini
		dname() { ip=; h=
			l=$(awk -v m="$m" 'tolower($2)==m{print $3" "$4; exit}' "$LF" 2>/dev/null)
			[ -n "$l" ] && { ip=${l%% *}; h=${l#* }; [ "$h" = "*" ] && h=; }
			[ -n "$h" ] || { s=$(uci -q show dhcp | awk -F= -v m="$m" '$1 ~ /\.mac$/ && index(tolower($2), m) {split($1, a, "."); print a[2]; exit}'); [ -n "$s" ] && { h=$(uci -q get dhcp.$s.name); [ -n "$ip" ] || ip=$(uci -q get dhcp.$s.ip); }; }
			[ -n "$ip" ] || ip=$(ip -4 neigh show 2>/dev/null | awk -v m="$m" 'tolower($5)==m{print $1; exit}')
		}
		# senza nome (2.72): MAC privato (secondo carattere 2, 6, A, E, come vpnmacpriv) = «Con Indirizzo Privato», altrimenti
		# la marca dal MAC (oui.txt, come ouiget); il MAC nudo solo senza marca
		dalt() {
			case "$m" in ?[2367abefABEF]*) t "Dispositivo Con Indirizzo Privato" "Device With Private Address"; return ;; esac
			v=$(awk -F'|' -v p="$(echo "$m" | cut -c1-8 | tr -d : | tr a-f A-F)" '!/^#/ && index(" " $3 " ", " " p " ") {print $1; exit}' /usr/share/wrtfreedom/oui.txt 2>/dev/null)
			if [ -n "$v" ]; then t "Dispositivo $v" "$v Device"; else printf '%s' "$m"; fi
		}
		# aggancio al Wi-Fi prima del DHCP (2.72): senza nome si rilegge ogni 2 s, al massimo 20 s. notify.sh lancia event.sh
		# in sottofondo e non aspetta
		dwait() { i=0; while [ -z "$h" ] && [ $i -lt 10 ]; do sleep 2; i=$((i + 1)); dname; done; h=${h:-$(dalt)}; }
		dname
		case "$2" in
			join)
				# /etc/wrtfreedom/seen: «mac» = conosciuto, «mac ?» = nuovo da confermare (Lo Conosco dall'app o da Telegram)
				if grep -qE "^$m( |\$)" /etc/wrtfreedom/seen 2>/dev/null; then dwait; log dev_join dev "📱 $h $(t "si è collegato" "connected")${w:+ · $w}${ip:+ · $ip}"
				else echo "$m ?" >> /etc/wrtfreedom/seen
					dwait; KB=$m; log dev_new new "🆕 $(t "Nuovo dispositivo" "New device"): $h${w:+ · $w}${ip:+ · $ip}"; KB=
					# Servizio VPN con «solo alcuni dispositivi» e Nuovi Dispositivi Protetti: entra nella VPN, dopo l'attesa del
					# DHCP (2.72: vpnctl.uc vuole l'IPv4; senza, come prima, non fa niente)
					config_get nd vpnout newdev; [ "$nd" = 1 ] && ucode /usr/share/wrtfreedom/vpnctl.uc newdev "$m" "$ip" "$h" >/dev/null 2>&1 &
				fi ;;
			leave) h=${h:-$(dalt)}; log dev_leave dev "📴 $h $(t "ha lasciato la rete" "left the network")" ;;
			tg) [ "$ETG" = 0 ] && exit 0; dwait; act tg "📶 $h $(t "si è collegato" "connected")${w:+ ($w)}" ;;
		esac ;;
	usb)
		case "$ACTION" in add) log usb_add usb "🔌 $(t "Dispositivo USB collegato" "USB device connected")${PRODUCT:+ ($PRODUCT)}";; remove) log usb_remove usb "⏏️ $(t "Dispositivo USB scollegato" "USB device disconnected")";; esac ;;
	block)
		case "$ACTION" in add) log disk_add usb "💾 $(t "Chiavetta o disco inserito" "USB stick or drive inserted") ($DEVNAME)";; remove) log disk_remove usb "💾 $(t "Chiavetta o disco tolto" "USB stick or drive removed") ($DEVNAME)";; esac ;;
	button)
		case "$ACTION" in pressed) log "button_${BUTTON}_pressed" button "🔘 $(t "Pulsante $BUTTON premuto" "Button $BUTTON pressed")";; released) log "button_${BUTTON}_released" button "🔘 $(t "Pulsante $BUTTON rilasciato" "Button $BUTTON released")";; esac ;;
	boot)
		log boot sys "🔄 $(t "Router acceso" "Router powered on")" ;;
	upd)	# aggiornamenti dal server (upd.sh): $2 = pkg o app, $3 = testo già nella lingua scelta
		log "upd_$2" sys "$3" ;;
	wd)	# Watchdog Della Linea (watchdog.sh): $2 = tipo di evento, $3 = testo già nella lingua scelta
		log "wd_$2" net "$3" ;;
	cron)	# Pianificazioni (cron.sh): $2 = tipo, $3 = categoria (net, sys, fw…), $4 = testo già nella lingua scelta
		log "cron_$2" "${3:-sys}" "$4" ;;
	ntp)
		[ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ] && { touch /tmp/.wf-ntp; log ntp sys "🕒 $(t "Orologio sincronizzato" "Clock synced")"; } ;;
esac
exit 0
