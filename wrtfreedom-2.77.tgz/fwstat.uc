'use strict';
/* WrtFreedom: tentativi bloccati dal firewall (pacchetto 2.45, pagina Firewall in Freedom Style; 2.70 Ultimi Tentativi,
   il solito, Quante Volte È Scattata e il giro degli avvisi).
   uso: ucode fwstat.uc setup   contatori nel firewall (fw4) per le zone internet; ricarica il firewall solo se cambiano
        ucode fwstat.uc tick    una lettura al minuto (notify.sh): ultima ora, oggi, porte più cercate, ultimi tentativi
        ucode fwstat.uc remove  toglie i contatori (uninstall.sh)
   Zone internet = zone con il mascheramento (masq), come fwZWan nell'app: niente nomi fissi. Le regole stanno in coda alle
   catene input_<zona> e forward_<zona> di fw4 (chain-post), cioè dopo tutte le regole che accettano: contano solo le
   connessioni nuove che il firewall sta per rifiutare. Contatore totale «wf_blocked», porte in «wf_bport» (con i
   pacchetti), mittenti per porta in «wf_bsrc» (solo IPv4, del giorno), mittenti degli ultimi 2 minuti in «wf_brec»
   (2.70, si cancellano da soli). A mezzanotte porte e mittenti si azzerano: sono quelli di oggi. Nessun registro e
   nessuna scrittura in flash.
   Stato in /tmp/wf-fwstat.json: { day, today, min: [60 minuti], top: [{ p, n, src }], ports, t, log: [{ t, p, n, src }]
   (ultimi 20, raggruppati al minuto), avg (il solito al minuto prima di questo minuto), pk: { n, t }, hits: { nome
   della regola: pacchetti } (ogni 5 minuti, hitT), conti interni last, pc, dmin, yavg, setupAt }.
   Dopo ogni giro chiede a WrtFreedom fwalert {action: 'tick'} (Porta A Tempo, Avviso Porta Nuova, Attacco In Corso).
   WF_FWSTATF e WF_CFGDIR solo per il router finto delle prove. */
import { readfile, writefile, popen, stat, mkdir, rmdir, unlink, lsdir, rename } from 'fs';

const D = '/usr/share/nftables.d', F = '90-wrtfreedom.nft', TMP = getenv('WF_FWSTATF') ?? '/tmp/wf-fwstat.json';
const LOCK = getenv('WF_FWSTATF') ? TMP + '.lock' : '/tmp/wf-fwstat.lock', CFG = getenv('WF_CFGDIR') ?? '/etc/config/';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function load(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
function today() { let n = localtime(time()); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
function nj(c) { try { return json(sh('nft -j ' + c + ' 2>/dev/null') || 'null'); } catch (e) { return null; } }

/* zone internet: sezioni zone di /etc/config/firewall con masq '1' */
function wanzones() {
	let Z = [], name = null, masq = false, zone = false;
	let end = () => { if (zone && masq && name && match(name, /^[A-Za-z0-9_]{1,20}$/)) push(Z, name); };
	for (let l in split(readfile(CFG + 'firewall') ?? '', '\n')) {
		if (match(l, /^config[[:blank:]]/)) { end(); zone = !!match(l, /^config[[:blank:]]+'?zone'?/); name = null; masq = false; continue; }
		let m = match(l, /^[[:blank:]]*option[[:blank:]]+([a-z_]+)[[:blank:]]+'?([^']*)'?/);
		if (!m) continue;
		if (m[1] == 'name') name = m[2];
		else if (m[1] == 'masq') masq = m[2] == '1';
	}
	end();
	return Z;
}
const SETS = 'counter wf_blocked { }\n' +
	'set wf_bport { type inet_service; flags dynamic; size 2048; counter; }\n' +
	'set wf_bsrc { type ipv4_addr . inet_service; flags dynamic; size 4096; }\n' +
	'set wf_brec { type ipv4_addr . inet_service; flags dynamic, timeout; timeout 2m; size 4096; }\n';
const RULES = 'ct state new counter name "wf_blocked"\n' +
	'ct state new meta l4proto { tcp, udp } add @wf_bport { th dport }\n' +
	'ct state new meta nfproto ipv4 meta l4proto { tcp, udp } add @wf_bsrc { ip saddr . th dport }\n' +
	'ct state new meta nfproto ipv4 meta l4proto { tcp, udp } update @wf_brec { ip saddr . th dport }\n';
/* file voluti → contenuto */
function wanted() {
	let W = {}, Z = wanzones();
	if (!length(Z)) return W;
	W[D + '/table-pre/' + F] = SETS;
	for (let z in Z) for (let c in ['input_', 'forward_']) W[D + '/chain-post/' + c + z + '/' + F] = RULES;
	return W;
}
/* i nostri file presenti adesso */
function present() {
	let P = {}, t = D + '/table-pre/' + F;
	if (stat(t)) P[t] = readfile(t);
	for (let c in lsdir(D + '/chain-post') ?? []) { let f = D + '/chain-post/' + c + '/' + F; if (stat(f)) P[f] = readfile(f); }
	return P;
}
function reload() { sh('/etc/init.d/firewall reload >/dev/null 2>&1'); }
/* ricariche del firewall una alla volta (stesso blocco di dev.uc setup e della prova delle Regole Scritte A Mano);
   blocco rimasto da un processo interrotto tolto dopo 2 minuti */
const FWL = '/tmp/wf-fw.lock';
function fwlock() {
	for (let i = 0; i < 60; i++) {
		if (mkdir(FWL)) return true;
		let s = stat(FWL);
		if (s && time() - s.mtime > 120) rmdir(FWL); else sh('sleep 1');
	}
	return false;
}
function setup1() {
	let W = wanted(), P = present(), ch = false;
	for (let f in P) if (!(f in W)) { unlink(f); ch = true; }
	for (let f in W) if (P[f] != W[f]) {
		let d = substr(f, 0, rindex(f, '/'));
		sh("mkdir -p '" + d + "'");
		writefile(f, W[f]); ch = true;
	}
	if (!ch) return { ok: true, changed: false };
	/* controllo prima di ricaricare: se fw4 non accetta le regole, si tolgono e il firewall resta com'era */
	if (system('fw4 check >/dev/null 2>&1') != 0) {
		for (let f in W) unlink(f);
		return { error: 'fw4 check' };
	}
	reload();
	return { ok: true, changed: true };
}
function setup() {
	if (!fwlock()) return { error: 'firewall occupato' };
	let r = setup1();
	rmdir(FWL);
	return r;
}
function remove() {
	let P = present(), ch = false;
	if (!length(P)) return { ok: true };
	if (!fwlock()) return { error: 'firewall occupato' };
	for (let f in P) { unlink(f); ch = true; }
	if (ch) reload();
	rmdir(FWL);
	return { ok: true };
}
/* stato scritto (prima il file nuovo, poi la rinomina), poi il giro degli avvisi di WrtFreedom (fuori da rpcd: il
   metodo torna subito) */
function save(S) {
	writefile(TMP + '.n', sprintf('%J', S)); rename(TMP + '.n', TMP);
	sh("ubus -t 20 call wrtfreedom fwalert '{\"action\":\"tick\"}' >/dev/null 2>&1");
}

let cmd = ARGV[0];
if (cmd == 'setup') { print(setup(), '\n'); exit(0); }
if (cmd == 'remove') { print(remove(), '\n'); exit(0); }
if (cmd != 'tick') { print('uso: fwstat.uc setup | tick | remove\n'); exit(1); }

/* tick: uno alla volta; blocco di un giro interrotto tolto dopo 5 minuti */
let lk = mkdir(LOCK);
if (!lk) { let s = stat(LOCK); if (s && time() - s.mtime < 300) exit(0); rmdir(LOCK); lk = mkdir(LOCK); if (!lk) exit(0); }
let S = load(TMP) ?? { day: today(), today: 0, min: [], top: [], last: -1 };
let c = nj('list counter inet fw4 wf_blocked'), pk = -1;
for (let x in c?.nftables ?? []) if (x.counter) pk = +x.counter.packets;
if (pk < 0) {
	/* contatori assenti (firewall ricaricato senza i nostri file, zone cambiate, primo avvio): setup al massimo ogni ora */
	if (time() - (S.setupAt ?? 0) > 3600) { S.setupAt = time(); setup(); }
	S.t = time(); save(S); rmdir(LOCK); exit(0);
}
/* secondi dall'ultimo giro (di solito 60): gli indirizzi «di questo minuto» sono quelli visti da allora */
let now = time(), el = S.t ? now - +S.t : 60;
if (el < 30) el = 30;
if (el > 300) el = 300;
/* nuovo giorno: porte e mittenti azzerati, oggi riparte da zero; il solito di ieri serve nella prima ora */
let d = today();
if (S.day != d) {
	sh('nft flush set inet fw4 wf_bport 2>/dev/null; nft flush set inet fw4 wf_bsrc 2>/dev/null');
	if (+(S.dmin ?? 0) >= 60) S.yavg = S.today / S.dmin;
	S.day = d; S.today = 0; S.dmin = 0; S.top = []; S.pc = {}; S.pk = null;
}
/* minuti dall'ultimo giro (di solito 1): il contatore si azzera quando fw4 ricarica */
let dl = S.last < 0 ? 0 : (pk >= S.last ? pk - S.last : pk);
/* il solito al minuto prima di questo minuto: media di oggi (dopo un'ora), prima quella di ieri o di almeno 10 minuti */
let dm = +(S.dmin ?? 0), base = dm >= 60 ? S.today / dm : (S.yavg ?? (dm >= 10 ? S.today / dm : null));
S.avg = base == null ? null : int(base * 10 + 0.5) / 10;
S.last = pk; S.today += dl; S.dmin = dm + 1;
push(S.min, dl);
while (length(S.min) > 60) shift(S.min);
if (dl > 0 && (!S.pk || dl > +S.pk.n)) S.pk = { n: dl, t: now };
/* porte più cercate e quanti indirizzi diversi per porta (oggi); indirizzi di questo minuto (wf_brec: secondi passati
   dall'ultima volta = timeout - expires); tentativi di questo minuto per porta = differenza dei contatori di wf_bport */
let src = {}, rec = {}, top = [], pc = S.pc, npc = {}, mins = [];
for (let x in nj('list set inet fw4 wf_bsrc')?.nftables ?? []) for (let e in x.set?.elem ?? []) { let p = e?.concat?.[1]; if (p != null) src[p] = (src[p] ?? 0) + 1; }
for (let x in nj('list set inet fw4 wf_brec')?.nftables ?? []) for (let e in x.set?.elem ?? []) {
	let v = e?.elem ?? e, k = v?.val ?? v, p = k?.concat?.[1], tmo = +(v?.timeout ?? x.set?.timeout ?? 120), ex = v?.expires;
	if (p != null && (ex == null || tmo - +ex <= el + 5)) rec[p] = (rec[p] ?? 0) + 1;
}
for (let x in nj('list set inet fw4 wf_bport')?.nftables ?? []) for (let e in x.set?.elem ?? []) {
	let v = e?.elem ?? e, p = v?.val ?? v, n = +(v?.counter?.packets ?? 0);
	if (type(p) != 'int') continue;
	push(top, { p, n, src: src[p] ?? 0 });
	npc[p] = n;
	/* primo giro (pc assente): niente Ultimi Tentativi, i contatori di oggi non sono di questo minuto */
	let o = pc ? +(pc[p] ?? 0) : n, dp = n >= o ? n - o : n;
	if (dp > 0) push(mins, { t: now, p, n: dp, src: rec[p] || 1 });
}
top = sort(top, (a, b) => b.n - a.n);
S.top = slice(top, 0, 5); S.ports = length(top); S.pc = npc;
S.log = slice([ ...sort(mins, (a, b) => b.n - a.n), ...(S.log ?? []) ], 0, 20);
/* Quante Volte È Scattata: contatori delle regole di fw4 (commento «!fw4: <nome>»), ogni 5 minuti, senza gli elementi
   degli insiemi (-t); al massimo 200 nomi */
if (now - +(S.hitT ?? 0) >= 290) {
	let H = {}, k = 0;
	for (let l in split(sh('nft -t list table inet fw4 2>/dev/null'), '\n')) {
		let i = index(l, 'comment "!fw4: ');
		if (i < 0) continue;
		let m = match(l, /counter packets ([0-9]+) /), nm = match(substr(l, i + 15), /^([^"]+)"/);
		if (!m || !nm) continue;
		if (!(nm[1] in H)) { if (k >= 200) continue; k++; }
		H[nm[1]] = (H[nm[1]] ?? 0) + +m[1];
	}
	S.hits = H; S.hitT = now;
}
S.t = now;
save(S);
rmdir(LOCK);
