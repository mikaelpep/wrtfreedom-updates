#!/bin/sh
# WrtFreedom: controlli in sottofondo ogni 10 secondi (istanza principale del servizio wrtfreedom)
# - dispositivi collegati DAVVERO (2.42): Wi-Fi dal router (iwinfo assoclist di ogni radio), via cavo dalla tabella
#   dei vicini (ip neigh); prima si usavano le assegnazioni DHCP, che scadono dopo ore (12 h in casa, 2 h ospiti)
#   e davano gli avvisi «uscito» con ore di ritardo. Uscito = assente da 3 minuti (passaggi 2,4/5 GHz, telefono che
#   dorme). Eventi dev_join / dev_leave / dev_new negli Eventi (avvisi su telefono e Telegram come gli altri)
# - «Avvisami quando si collega» (wrtfreedom.notify.mac): Telegram anche se gli avvisi dei dispositivi sono spenti
# - consumo della SIM, SMS del modem, aggiornamenti dal server, messaggi Telegram in coda
# - storico del segnale e allerte IT-Alert con ModemManager (2.47)
# - DNS di riserva se AdGuard non risponde (2.50, adgmode.sh check)
# - Dispositivi (2.49): /tmp/wf-pres/<mac> = «on|off <secondi dall'accensione> <come>» (Collegato unico per app, bot e
#   notifiche); entrate e uscite in /tmp/wf-presl («ora mac 1|0», ora vera di quando è stato visto l'ultima volta),
#   scaricate ogni ora da dev.uc in /etc/wrtfreedom/pres.log; dev.uc tick ogni minuto (consumo, pause, quote, persone)
W=/usr/share/wrtfreedom
P=/tmp/wf-pres; PL=/tmp/wf-presl; PLMAX=2000; pl=0; first=0; [ -d $P ] || { mkdir -p $P; first=1; }
GONE=180   # assente da 3 minuti = uscito
c=0
cm=; ct=0   # data di modifica della configurazione già letta e ora (secondi) della lettura
VT=0; BC=   # banda Wi-Fi di ogni interfaccia (" phy0-ap0=Wi-Fi_5_GHz …"), riletta con la configurazione e ogni 10 minuti
any() { for f; do [ -e "$f" ] && return 0; done; return 1; }	# almeno un file (glob senza fork)
hm() { local h=${1%%:*} m=${1#*:}; echo $(( (${h#0}+0) * 60 + ${m#0}+0 )); }	# HH:MM → minuti
# Ore Silenziose (2.53): coda Telegram da mandare adesso? Fuori dalla fascia sì; dentro solo se c'è un messaggio che passa
# (per una chat sola «#to:» o con una categoria di qpass «#c:»), righe d'intestazione lette con read (niente processi)
tgqgo() {
	local f l n
	[ "$QU" = 1 ] || return 0
	set -- $(date '+%H %M'); n=$(( ${1#0} * 60 + ${2#0} ))
	if [ $QF -lt $QT ]; then { [ $n -ge $QF ] && [ $n -lt $QT ]; } || return 0
	else { [ $n -ge $QF ] || [ $n -lt $QT ]; } || return 0; fi
	for f in /tmp/wf-tgq/[0-9]*; do
		[ -f "$f" ] || continue
		while IFS= read -r l; do case "$l" in
			'#to:'*) return 0 ;;
			'#c:'*) case " $QP " in *" ${l#??:} "*) return 0 ;; esac ;;
			'#kb:'*) ;;
			*) break ;;
		esac; done < "$f"
	done
	return 1
}
# Controllo Del Nome Di Casa (2.68, docs/v2/controllo-nome.md), una volta al minuto con il controllo acceso: IP registrato da
# ddns-scripts per ogni nome (<sez>.ip nella cartella DR) confrontato con l'ultimo visto (DM/<sez>), solo letture di file
# piccoli; cambiato (chiunque abbia aggiornato) → ultimo cambio in DM/.chg («sez IP», la data del file è l'ora: ddnswd get,
# chg) e cron.sh ddnswd chg (la prima volta solo ricordato; un .ip letto vuoto mentre ddns-scripts lo riscrive non conta).
# Controllo spento: ultimi visti, segni e conti tolti (cron.sh ddnswd clr); impostazione assente → D5 (cron.sh ddnswd d5, di
# nuovo quando cambia /etc/config/ddns o se rpcd non ha risposto). Ricontrollo dopo un nome vecchio (old): passata l'ora che
# cron.sh scrive in DRE, cron.sh ddnswd re (lo toglie lui, così parte una volta)
DM=/tmp/wf-ddnswd DRE=/tmp/wf-cron.ddnsre
ddnsip() {
	local f s v o
	if [ "$DW" = 1 ]; then
		if [ -f "$DRE" ] && read -r v < "$DRE" && [ "$(date +%s)" -ge "$v" ] 2>/dev/null; then sh $W/cron.sh ddnswd re >/dev/null 2>&1 & fi
		for f in "$DR"/*.ip; do
			[ -f "$f" ] || continue
			s=${f##*/}; s=${s%.ip}; v=; o=
			read -r v < "$f"; [ -n "$v" ] || continue
			[ -f "$DM/$s" ] && read -r o < "$DM/$s"
			[ "$v" = "$o" ] && continue
			[ -d "$DM" ] || mkdir -p "$DM"
			echo "$v" > "$DM/$s"
			[ -n "$o" ] || continue
			echo "$s $v" > "$DM/.chg"; sh $W/cron.sh ddnswd chg "$s" >/dev/null 2>&1 &
		done
	elif [ -d "$DM" ]; then
		rm -rf "$DM"; sh $W/cron.sh ddnswd clr >/dev/null 2>&1 &
	fi
	if [ -z "$DW" ] && { [ ! -f $DM.d5 ] || [ /etc/config/ddns -nt $DM.d5 ]; }; then : > $DM.d5; sh $W/cron.sh ddnswd d5 >/dev/null 2>&1 & fi
}
while true; do
	# configurazione riletta solo se è cambiata: data di modifica diversa, oppure uguale o successiva all'ora della lettura
	# (la data ha i secondi: una modifica nello stesso secondo della lettura sarebbe sfuggita). Se date -r non risponde
	# o ci sono modifiche di uci non ancora salvate (/tmp/.uci) si rilegge a ogni giro
	mt=$(date -r /etc/config/wrtfreedom +%s 2>/dev/null)
	if [ -z "$mt" ] || [ -e /tmp/.uci/wrtfreedom ] || [ "$mt" != "$cm" ] || [ "$mt" -ge "$ct" ]; then
		ct=$(date +%s); cm=$mt; BC=
		WM=$(uci -q get wrtfreedom.notify.mac | tr 'A-F' 'a-f'); NC=" $(uci -q get wrtfreedom.ev.notify) "
		VT=0; grep -q "^config vpntun" /etc/config/wrtfreedom 2>/dev/null && VT=1	# Servizio VPN configurato
		GU=$(uci -q get wrtfreedom.guest.until)	# Ospiti A Tempo (2.48): ora di spegnimento della rete ospiti
		GL=$(uci -q get wrtfreedom.guest.dl)$(uci -q get wrtfreedom.guest.ul)	# Limite Di Velocità della rete ospiti (2.48)
		DF=$(uci -q get wrtfreedom.dnsfb.on)	# DNS di riserva (2.50)
		VP=$(uci -q get wrtfreedom.vpnout.pause_until)	# Pausa Del Servizio VPN (2.52): ora della ripresa
		WG=	# riletto qui sotto insieme alla configurazione
		QU=$(uci -q get wrtfreedom.ev.quiet); QP=$(uci -q get wrtfreedom.ev.qpass); [ -n "$QP" ] || QP="net sys fw"	# Ore Silenziose (2.53)
		x=$(uci -q get wrtfreedom.ev.qfrom); QF=$(hm "${x:-23:00}"); x=$(uci -q get wrtfreedom.ev.qto); QT=$(hm "${x:-07:00}")
		case "$QF$QT" in *[!0-9]*|'') QU=0 ;; esac; [ "$QF" = "$QT" ] && QU=0
		DW=$(uci -q get wrtfreedom.ddnswd.on)	# Controllo Del Nome Di Casa (2.68): '1', '0' o assente (D5)
	fi
	# cartella di ddns-scripts (- senza ddns-scripts), riletta ogni 10 minuti (Controllo Del Nome Di Casa, 2.68)
	{ [ -z "$DR" ] || [ $((c % 60)) = 0 ]; } && { DR=-; [ -x /etc/init.d/ddns ] && { DR=$(uci -q get ddns.global.ddns_rundir); DR=${DR:-/var/run/ddns}; }; }
	# VPN Per Fuori Casa (2.52): c'è una WireGuard con la porta in ascolto? Riletto con la configurazione del pacchetto,
	# quando /etc/config/network è più nuovo dell'ultima lettura (test -nt, senza processi) e ogni 10 minuti
	{ [ -z "$WG" ] || [ /etc/config/network -nt /tmp/wf-wgnet ] || [ $((c % 60)) = 0 ]; } && { WG=0; grep -q "listen_port" /etc/config/network 2>/dev/null && WG=1; : > /tmp/wf-wgnet; }
	# ora dall'accensione (senza fork): basta per le assenze, /tmp/wf-pres si svuota anche lui a ogni riavvio
	read now x </proc/uptime; now=${now%.*}; ON=""
	[ $((c % 60)) = 0 ] && BC=
	# Wi-Fi: dispositivi associati a ogni radio, con la banda
	for p in /sys/class/net/*; do
		i=${p##*/}; [ -d "$p/phy80211" ] || continue
		case "$BC" in
			*" $i="*) b=${BC#*" $i="}; b=${b%% *} ;;
			*) ch=$(iwinfo "$i" info 2>/dev/null | sed -n 's/.*Channel: \([0-9]*\).*/\1/p' | head -n 1)
				b="Wi-Fi_2,4_GHz"; [ -n "$ch" ] && [ "$ch" -gt 14 ] && b="Wi-Fi_5_GHz"	# senza spazi: ON è un elenco di parole
				[ -n "$ch" ] && BC="$BC $i=$b " ;;
		esac
		for m in $(iwinfo "$i" assoclist 2>/dev/null | grep -oE '^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}' | tr 'A-F' 'a-f'); do ON="$ON $m|$b"; done
	done
	# via cavo: vicini IPv4 delle reti di casa (non le linee verso internet). Quelli «STALE» (nessun traffico da poco)
	# si provano con un ping: al giro dopo risultano raggiungibili, oppure spariscono se il dispositivo non c'è più
	WD=" $(ip -4 route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | tr '\n' ' ') "
	# porte dei bridge: « mac=interfaccia » per ogni dispositivo visto (brctl showmacs dà il numero della porta)
	FD=" "
	for b in /sys/class/net/*/bridge; do b=${b%/bridge}; b=${b##*/}; PN=
		for q in /sys/class/net/$b/brif/*; do [ -f "$q/port_no" ] && read n < "$q/port_no" && PN="$PN $((n))=${q##*/}"; done
		FD="$FD$(brctl showmacs "$b" 2>/dev/null | awk -v pn="$PN" 'BEGIN{k=split(pn,a," ");for(i=1;i<=k;i++){split(a[i],x,"=");P[x[1]]=x[2]}} $3=="no"&&P[$1]!=""{printf "%s=%s ",tolower($2),P[$1]}')"
	done
	for l in $(ip -4 neigh show 2>/dev/null | awk '$4=="lladdr"{print $1"|"$3"|"tolower($5)"|"$NF}'); do
		ip=${l%%|*}; r=${l#*|}; d=${r%%|*}; r=${r#*|}; m=${r%%|*}; st=${r#*|}
		case "$WD" in *" $d "*) continue;; esac
		case "$st" in REACHABLE|DELAY|PROBE) ;; STALE) ping -c 1 -W 1 -I "$d" "$ip" >/dev/null 2>&1 & ;; *) continue;; esac
		# come è collegato (2.57): dalla porta del bridge da cui arriva, subito; da una radio = Wi-Fi con la sua banda
		# (appena uscito dal Wi-Fi, o dietro un ripetitore), mai «cavo»; senza bridge resta «cavo»
		case "$ON" in *" $m|"*) ;; *) v=cavo
			case "$FD" in *" $m="*) pi=${FD#*" $m="}; pi=${pi%% *}
				[ -d "/sys/class/net/$pi/phy80211" ] && { v=Wi-Fi; case "$BC" in *" $pi="*) v=${BC#*" $pi="}; v=${v%% *};; esac; };; esac
			ON="$ON $m|$v";; esac
	done
	# collegati: entrati se prima non c'erano; usciti se mancano da GONE secondi
	for e in $ON; do
		m=${e%%|*}; f=$P/${m//:/}; s=; [ -f "$f" ] && read s x y < "$f"
		echo "on $now ${e#*|}" > "$f"
		[ "$s" = on ] && continue
		echo "$(date +%s) $m 1" >> $PL; pl=1
		[ $first = 1 ] && continue
		sh $W/event.sh dev join "$m" "${e#*|}" >/dev/null 2>&1 &
		# dispositivo scelto in «Avvisami quando si collega»: Telegram anche con gli avvisi dei dispositivi spenti
		case " $WM " in *" $m "*) case "$NC" in *" dev "*) ;; *) sh $W/event.sh dev tg "$m" "${e#*|}" >/dev/null 2>&1 & ;; esac ;; esac
	done
	for f in $P/*; do
		[ -f "$f" ] || continue; read s x y < "$f"; [ "$s" = on ] || continue
		[ $((now - x)) -ge $GONE ] || [ "$x" -gt "$now" ] || continue	# x > now: data del pacchetto di prima
		echo "off $x $y" > "$f"; m=$(echo "${f##*/}" | sed 's/../&:/g; s/:$//')
		[ "$x" -gt "$now" ] || { echo "$(( $(date +%s) - now + x )) $m 0" >> $PL; pl=1; }	# uscito: ora dell'ultima volta visto
		sh $W/event.sh dev leave "$m" >/dev/null 2>&1 &
	done
	# presenza in /tmp al massimo PLMAX righe (dev.uc la scarica ogni ora; tetto se i giri di dev.uc si fermano)
	[ "$pl" = 1 ] && [ -f $PL ] && [ "$(wc -l < $PL)" -gt $PLMAX ] && tail -n $PLMAX $PL > $PL.t && mv $PL.t $PL
	pl=0; first=0
	c=$((c+1))
	# DNS di riserva (2.50): una volta al minuto, solo se acceso, se la riserva è in corso o se un cambio di AdGuard è
	# rimasto a metà (adgmode.sh check: cambio interrotto → copia rimessa; AdGuard fermo → server dell'operatore, AdGuard di
	# nuovo pronto → si torna); negli altri giri nessun processo
	if [ $((c % 6)) = 5 ] && { [ "$DF" = 1 ] || [ -f /etc/wrtfreedom/dnsfb.state ] || [ -d /etc/wrtfreedom/adgmode.new ]; }; then sh $W/adgmode.sh check >/dev/null 2>&1 & fi
	# messaggi Telegram non partiti (linea assente, Telegram lento): nuovo tentativo ogni 30 secondi; nelle Ore Silenziose
	# solo per i messaggi che passano (alla fine della fascia partono tutti)
	[ $((c % 3)) = 0 ] && any /tmp/wf-tgq/* && tgqgo && ucode $W/tgq.uc flush >/dev/null 2>&1 &
	# Servizio VPN (2.42): collegamento, ricollegamento automatico, IP pubblico, DNS; solo se configurato
	[ $((c % 3)) = 0 ] && [ $VT = 1 ] && ucode $W/vpnctl.uc tick >/dev/null 2>&1 &
	# Pausa Del Servizio VPN (2.52): passata l'ora, i collegamenti tornano accesi (cron.sh vpnsvcresume → vpnout resume)
	if [ -n "$VP" ] && [ $((c % 3)) = 1 ] && [ "$(date +%s)" -ge "$VP" ] 2>/dev/null; then VP=; sh $W/cron.sh vpnsvcresume >/dev/null 2>&1 & fi
	# VPN Per Fuori Casa (2.52): ultimo contatto e avvisi per dispositivo, byte al giorno, Prova Da Fuori Casa; ogni 30 s
	[ $((c % 3)) = 2 ] && [ "$WG" = 1 ] && ucode $W/wgx.uc tick >/dev/null 2>&1 &
	# consumo della SIM nel periodo dell'offerta (2.41): byte dell'interfaccia del modem, ogni 30 s
	[ $((c % 3)) = 0 ] && ucode $W/usage.uc tick >/dev/null 2>&1 &
	# tentativi bloccati dal firewall (2.45): una lettura al minuto per la pagina Firewall
	[ $((c % 6)) = 0 ] && ucode $W/fwstat.uc tick >/dev/null 2>&1 &
	# Dispositivi (2.49): consumo per dispositivo, Tempo Con Traffico, quote, persone, Pausa Per Tutti; una volta al minuto
	[ $((c % 6)) = 4 ] && ucode $W/dev.uc tick >/dev/null 2>&1 &
	# Salute Del Router (2.54): stato, storico 24 ore (un punto ogni 5 minuti con i picchi dei minuti) e Avvisi Di Salute;
	# una volta al minuto, sfasato dagli altri giri
	[ $((c % 6)) = 2 ] && ucode $W/health.uc tick >/dev/null 2>&1 &
	# Controllo Della Linea (2.70): ritardo a linea carica, Storico Della Velocità Adattiva e Avviso Ritardo Alto; una volta
	# al minuto, solo con una regola accesa (negli altri casi nessun processo oltre al controllo del file)
	if [ $((c % 6)) = 5 ] && [ -x /etc/init.d/sqm ] && grep -qs "enabled '1'" /etc/config/sqm; then ucode $W/sqm.uc tick >/dev/null 2>&1 & fi
	# SMS del modem (2.41): una lettura al minuto, solo se c'è un modem; i ricevuti nuovi vanno negli Eventi
	[ $((c % 6)) = 0 ] && any /dev/cdc-wdm* /dev/wwan* /dev/ttyUSB* /dev/ttyACM* /dev/mhi_* && ucode $W/sms.uc refresh >/dev/null 2>&1 &
	# storico del segnale (2.47): un campione al minuto dalla lettura del modem, sfasato di 30 s dagli SMS
	if [ $((c % 6)) = 3 ] && any /dev/cdc-wdm* /dev/wwan* /dev/ttyUSB* /dev/ttyACM* /dev/mhi_*; then ucode $W/sighist.uc tick >/dev/null 2>&1 & fi
	# IT-Alert con ModemManager (2.47): messaggi nuovi ogni 30 s, solo con la ricezione accesa (/tmp/wf-cbs.mm)
	if [ $((c % 3)) = 1 ] && [ -f /tmp/wf-cbs.mm ]; then ucode $W/cbs.uc refresh >/dev/null 2>&1 & fi
	# Salute Del Wi-Fi (2.48, wifi.uc tick): ogni 30 s se l'app l'ha chiesta da meno di 10 minuti, ogni 5 minuti fino a
	# 24 ore dall'ultima richiesta (storico della giornata), poi niente (/tmp/wf-wifi.want = secondi dall'accensione)
	if [ $((c % 3)) = 2 ] && [ -f /tmp/wf-wifi.want ]; then
		read ww x < /tmp/wf-wifi.want; ww=$((now - ${ww:-0}))
		if [ $ww -lt 600 ] || { [ $((c % 30)) = 2 ] && [ $ww -lt 86400 ]; }; then ucode $W/wifi.uc tick >/dev/null 2>&1 & fi
	fi
	# radar sui canali DFS (2.48): registro di hostapd ogni 5 minuti, solo con una radio a 5 GHz accesa
	case "$BC" in *Wi-Fi_5_GHz*) [ $((c % 30)) = 17 ] && ucode $W/wifi.uc radar >/dev/null 2>&1 & ;; esac
	# Limite Di Velocità della rete ospiti (2.48): ogni 5 minuti si rimettono le code se un riavvio del Wi-Fi le ha tolte
	[ -n "$GL" ] && [ $((c % 30)) = 7 ] && ucode $W/wifi.uc glimit check >/dev/null 2>&1 &
	# Ospiti A Tempo (2.48): scaduto il tempo la rete ospiti si spegne (cron.sh guestend → wifiguest end, con l'evento)
	if [ -n "$GU" ] && [ $((c % 3)) = 0 ] && [ "$(date +%s)" -ge "$GU" ] 2>/dev/null; then sh $W/cron.sh guestend >/dev/null 2>&1 & fi
	# Controllo Del Nome Di Casa (2.68): confronto una volta al minuto (ddnsip) e controllo del giorno dalle 10:00 (cron.sh
	# ddnswd day, una volta al giorno anche se questo giro riparte), con l'orologio sincronizzato; una lettura dell'ora ogni 5 minuti
	if [ $((c % 6)) = 1 ] && [ "$DR" != - ]; then
		ddnsip
		if [ "$DW" = 1 ] && [ $((c % 30)) = 13 ] && [ -f /tmp/.wf-ntp ]; then
			dd_=$(date +%Y%m%d%H%M)
			if [ "${dd_%????}" != "$DD" ] && [ "${dd_#????????}" -ge 1000 ] 2>/dev/null; then DD=${dd_%????}; sh $W/cron.sh ddnswd day >/dev/null 2>&1 & fi
		fi
	fi
	# aggiornamenti dal server: la prima volta dopo 10 minuti, poi ogni 12 ore
	[ $((c % 4320)) = 60 ] && sh $W/upd.sh notify >/dev/null 2>&1 &
	# Rinnovo Dei Certificati (2.66): controllo del giorno dalle 01:30 (cron.sh certcheck, una volta al giorno anche se questo
	# giro riparte), solo con acme e l'orologio sincronizzato; una lettura dell'ora ogni 5 minuti
	if [ $((c % 30)) = 23 ] && [ -x /etc/init.d/acme ] && [ -f /tmp/.wf-ntp ]; then
		cd_=$(date +%Y%m%d%H%M)
		if [ "${cd_%????}" != "$CK" ] && [ "${cd_#????????}" -ge 130 ] 2>/dev/null; then CK=${cd_%????}; sh $W/cron.sh certcheck >/dev/null 2>&1 & fi
	fi
	sleep 10
done
