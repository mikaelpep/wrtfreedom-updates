'use strict';
/* WrtFreedom: VPN Per Fuori Casa in sottofondo (pacchetto 2.52). I metodi di rpcd leggono solo i file di stato.
   uso: ucode wgx.uc tick     ogni 30 s da notify.sh (solo con una WireGuard con la porta in ascolto): ultimo contatto di
                              ogni dispositivo (eventi cron_wgpeer_on/off per chi ha l'Avviso acceso), byte per dispositivo
                              e per giorno (/tmp/wf-wguse.json, copia in /etc/wrtfreedom/wguse.json ogni 6 ore, prima se
                              i byte nuovi superano SAVEB, e allo spegnimento; 60 giorni), Prova Da Fuori Casa armata
                              (contatto arrivato: decide wgprobe, che controlla anche che venga da fuori casa); 2.67
                              Controllo Della VPN Per Fuori Casa (wdcheck, impostazione assente: wdd5)
        ucode wgx.uc probe   parte lenta della Prova Da Fuori Casa: IP pubblico e nome DDNS risolto da un DNS pubblico
                              (/tmp/wf-wgprobe.chk.json)
        ucode wgx.uc exp      Dispositivi Con Scadenza (cron.sh wgexp ogni 5 minuti): scaduti tolti con wgpeer del, evento
                              cron_wgpeer_exp
        ucode wgx.uc save     copia subito in /etc/wrtfreedom (spegnimento del servizio) */
import { readfile, writefile, popen, rename, mkdir, stat, unlink } from 'fs';

const W = '/usr/share/wrtfreedom', TMP = '/tmp/wf-wguse.json', ETC = '/etc/wrtfreedom/wguse.json', ST = '/tmp/wf-wgx.json';
const PRB = '/tmp/wf-wgprobe.json', PRBC = '/tmp/wf-wgprobe.chk.json', KEEP = 60, ON = 180, SAVET = 21600, SAVEB = 536870912;

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rj(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function day(t) { let n = localtime(t); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
function arr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }
/* /etc/config/<nome> letto dal file: stesso lettore di ucfile in wrtfreedom.uc (uval, uopen; sezioni con .type, liste
   come array, anonime @tipo[n], valori su più righe, WF_CFGDIR per le prove) */
function uval(v) {
	v = trim(v ?? '');
	let c = substr(v, 0, 1), o = '', i = 1, n = length(v);
	if (c == "'") {
		while (i < n) {
			let ch = substr(v, i, 1);
			if (ch == "'") { if (substr(v, i, 4) == "'\\''") { o += "'"; i += 4; continue; } break; }
			o += ch; i++;
		}
		return o;
	}
	if (c == '"') {
		while (i < n) {
			let ch = substr(v, i, 1);
			if (ch == '\\') { o += substr(v, i + 1, 1); i += 2; continue; }
			if (ch == '"') break;
			o += ch; i++;
		}
		return o;
	}
	return split(v, /[ \t]+/)[0] ?? '';
}
function uopen(l) {
	if (index(l, "'") < 0 && index(l, '"') < 0) return false;
	let sq = false, dq = false;
	for (let i = 0; i < length(l); i++) {
		let ch = substr(l, i, 1);
		if (sq) { if (ch == "'") sq = false; }
		else if (dq) { if (ch == '\\') i++; else if (ch == '"') dq = false; }
		else if (ch == '\\') i++;
		else if (ch == "'") sq = true;
		else if (ch == '"') dq = true;
		else if (ch == '#') break;
	}
	return sq || dq;
}
function ucfile(name) {
	let r = {}, cur = null, cnt = {}, buf = null;
	for (let l in split(readfile((getenv('WF_CFGDIR') ?? '/etc/config/') + name) ?? '', '\n')) {
		if (buf != null) { l = buf + '\n' + l; buf = null; }
		if (uopen(l)) { buf = l; continue; }
		let m = match(l, /^[ \t]*(config|option|list)[ \t]+([^ \t]+)/);
		if (!m) continue;
		let rest = trim(substr(l, length(m[0])));
		if (m[1] == 'config') {
			let t = uval(m[2]), n = length(rest) ? uval(rest) : '';
			cnt[t] = (cnt[t] ?? -1) + 1;
			if (!length(n)) n = '@' + t + '[' + cnt[t] + ']';
			cur = r[n] = r[n] ?? { '.type': t };
		}
		else if (cur) {
			let k = uval(m[2]), v = uval(rest);
			if (m[1] == 'list') { if (type(cur[k]) != 'array') cur[k] = []; push(cur[k], v); }
			else cur[k] = v;
		}
	}
	return r;
}
const WC = ucfile('wrtfreedom');
const EN = (WC.ui?.lang ?? '') == 'en';
function t(it, en) { return EN ? en : it; }
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' net ' + q(txt) + ' >/dev/null 2>&1 </dev/null &'); }
/* WireGuard di casa: quella con la porta in ascolto, mai il Servizio VPN (wgout, wgo1…): uguale a wgiface di wrtfreedom.uc */
function wgiface(N) {
	let L = filter(keys(N), (k) => N[k]['.type'] == 'interface' && N[k].proto == 'wireguard' && !match(k, /^wgo(ut|[0-9]+)$/));
	for (let i in L) if (length(N[i].listen_port ?? '')) return i;
	return L[0];
}
/* dispositivi: chiave pubblica → { id, name, al (avviso acceso) } */
function peers(N, ifc) {
	let P = {};
	for (let k in N) if (N[k]['.type'] == 'wireguard_' + ifc && length(N[k].public_key ?? ''))
		P[N[k].public_key] = { id: k, name: N[k].description ?? k, al: (WC['peer_' + k] ?? {}).alert == '1' };
	return P;
}
/* righe dei dispositivi di «wg show <if> dump» (la prima riga è l'interfaccia) in r; 2.67: ok = wg show riuscito (senza il
   comando wg vero, come cron.sh vpncheck) */
function dump(ifc) {
	let r = [], o = sh('wg show ' + q(ifc) + ' dump 2>/dev/null; echo "@rc=$?"'), m = match(o, /@rc=([0-9]+)[ \t\n]*$/);
	let L = split(trim(replace(o, /@rc=[0-9]+[ \t\n]*$/, '')), '\n');
	for (let i = 1; i < length(L); i++) {
		let f = split(L[i], '\t');
		if (length(f) >= 7) push(r, { pub: f[0], ep: f[2], hs: +f[4], rx: +f[5], tx: +f[6] });
	}
	return { r: r, ok: m != null && (m[1] == '0' || m[1] == '127') };
}
/* 2.67 Controllo Della VPN Per Fuori Casa (docs/v2/controllo-vpn.md), solo con wrtfreedom.wgwd.on '1', a ogni giro: guasto =
   up falso o «wg show» che fallisce per 2 giri di fila; allora ifup in un processo a parte (cron.sh vpnwd up, con il blocco in
   /tmp) e verifica al giro dopo (cron.sh vpnwd fix|fail: Registro wf:vpncheck e avvisi). Tentativi distanziati WDD (30 s,
   2 min, 10 min, poi ogni ora); tutto riparte quando la VPN è a posto. Salta la VPN spenta apposta (disabled, autostart
   falso), in collegamento (pending) o accesa da meno di WDUP secondi (dopo un ifup al massimo WDP, poi conta come guasto).
   Interviene solo con how loop (la sola regola: vpnwd get, letta solo prima di un ifup). Stato in /tmp/wf-vpnwd.json { f:
   giri guasti di fila, a: tentativi, nx: prossimo tentativo possibile, p: ora dell'ifup da verificare, r: avviso mandato } */
const WDF = '/tmp/wf-vpnwd.json', WDLK = '/tmp/wf-vpnwd.lock', WDD = [ 30, 120, 600, 3600 ], WDUP = 60, WDP = 90;
/* cron.sh (WF_CRONSH solo per il router finto delle prove, come in wrtfreedom.uc) */
const CRONSH = getenv('WF_CRONSH') ?? W + '/cron.sh';
function wdsh(a) { sh('( sh ' + CRONSH + ' vpnwd ' + a + ' ) >/dev/null 2>&1 </dev/null &'); }
/* stato dell'interfaccia da netifd: modulo ubus di ucode se c'è, altrimenti ifstatus */
function ifst(ifc) {
	let r = null;
	try { let c = require('ubus').connect(); if (c) r = c.call('network.interface.' + ifc, 'status'); } catch (e) {}
	if (r == null) { try { r = json(sh('ifstatus ' + q(ifc) + ' 2>/dev/null') || 'null'); } catch (e) {} }
	return type(r) == 'object' ? r : null;
}
/* D5 (impostazione assente e VPN Per Fuori Casa con la porta in ascolto): vpnwd align in un processo a parte, una volta (segno
   WDD5 in /tmp, tolto se rpcd non risponde: si riprova al giro dopo); decide align, così non dipende da rpcd pronto alla fine
   di install.sh */
const WDD5 = '/tmp/wf-vpnwd.d5';
function wdd5(N, ifc) {
	if (length(WC.wgwd?.on ?? '') || !length(N[ifc]?.listen_port ?? '') || stat(WDD5)) return;
	writefile(WDD5, '');
	sh('( ubus -t 10 call wrtfreedom vpnwd ' + q('{"action":"align"}') + ' >/dev/null 2>&1 || rm -f ' + WDD5 + ' ) >/dev/null 2>&1 </dev/null &');
}
/* segno «non si riaccende» di cron.sh (raise vpn): nasce anche da Controlla Ora (vpnwd now) e dall'attività pronta vpncheck,
   senza r nello stato del giro (WF_CRONTEST solo per il router finto delle prove, come ACP di wrtfreedom.uc) */
const WDFLG = (length(getenv('WF_CRONTEST') ?? '') && !stat('/etc/openwrt_release') ? getenv('WF_CRONTEST') : '') + '/tmp/wf-cron.vpn.f';
function wdcheck(N, ifc, wok) {
	let S = rj(WDF), now = time();
	wdd5(N, ifc);
	if ((WC.wgwd?.on ?? '') != '1') {
		/* controllo spento: stato tolto, il segno dell'avviso anche (senza avviso). Solo al passaggio (stato del giro presente):
		   con il controllo spento il segno può essere dell'attività pronta vpncheck, che lo tiene per avvisare una volta */
		if (S) { if (S.r || stat(WDFLG)) wdsh('clr'); unlink(WDF); }
		return;
	}
	S = S ?? {};
	let st = ifst(ifc);
	if (!st) return;
	/* spenta apposta: niente controllo, tutto riparte (resta il segno: «di nuovo a posto» quando torna) */
	if (N[ifc]?.disabled == '1' || st.autostart === false) { if (S.f || S.a || S.p) wj(WDF, S.r ? { r: 1 } : {}); return; }
	if (st.up === true && wok) {
		if (S.p) wdsh('fix');
		else if (S.r || stat(WDFLG)) wdsh('ok');
		if (length(keys(S))) unlink(WDF);
		return;
	}
	if ((st.pending === true || (st.up === true && +(st.uptime ?? 0) < WDUP)) && !(S.p && now - S.p >= WDP)) return;
	if (S.p) { wdsh('fail'); S.p = 0; S.r = 1; }
	S.f = (S.f ?? 0) + 1;
	let lk = stat(WDLK);
	if (S.f >= 2 && now >= +(S.nx ?? 0) && !(lk && now - lk.mtime < 120)) {
		let G = null;
		try { G = json(sh('ubus -t 10 call wrtfreedom vpnwd ' + q('{"action":"get"}') + ' 2>/dev/null') || 'null'); } catch (e) {}
		if (G?.how == 'loop' && G.ifc == ifc) {
			sh('( sh ' + CRONSH + ' vpnwd up ' + q(ifc) + ' ) >/dev/null 2>&1 </dev/null &');
			S.a = (S.a ?? 0) + 1; S.p = now; S.nx = now + WDD[S.a < length(WDD) ? S.a - 1 : length(WDD) - 1] - 5;
		}
		/* lo fa lo script dell'utente (how null) o rpcd non risponde: si richiede tra 5 minuti */
		else S.nx = now + 300;
	}
	wj(WDF, S);
}
/* copia in memoria interna (scritture rade: dal giro ogni 6 ore o dopo 512 MB nuovi, sempre allo spegnimento) */
function save(U) {
	U = U ?? rj(TMP);
	if (!U) return;
	U.st = time(); U.ch = 0; U.cb = 0;
	mkdir('/etc/wrtfreedom');
	wj(ETC, U); wj(TMP, U);
}
function tick() {
	let N = ucfile('network'), ifc = wgiface(N);
	if (!ifc) return;
	let now = time(), d = day(now), P = peers(N, ifc), S = rj(ST) ?? {}, U = rj(TMP) ?? rj(ETC) ?? {}, seen = {}, D = dump(ifc);
	S.p = S.p ?? {}; U.d = U.d ?? {};
	for (let x in D.r) {
		let p = P[x.pub];
		if (!p) continue;	/* dispositivo senza sezione in network: niente nome, non si conta */
		seen[p.id] = true;
		let o = S.p[p.id] ?? {}, on = x.hs > 0 && now - x.hs < ON;
		/* byte: differenza dalla lettura di prima (contatori più bassi = interfaccia ripartita: si conta da zero) */
		if (o.rx != null) {
			let dr = x.rx >= o.rx ? x.rx - o.rx : x.rx, dt = x.tx >= o.tx ? x.tx - o.tx : x.tx;
			if (dr || dt) { let g = U.d[d] = U.d[d] ?? {}, v = g[p.id] ?? [0, 0]; g[p.id] = [v[0] + dr, v[1] + dt]; U.ch = 1; U.cb = (U.cb ?? 0) + dr + dt; }
		}
		if (o.on != null && on != o.on && p.al) {
			let ip = match(x.ep, /^[0-9.]+:[0-9]+$/) ? ' · ' + replace(x.ep, /:[0-9]+$/, '') : '';
			if (on) ev('wgpeer_on', '📲 ' + p.name + ' ' + t('si è collegato al Server VPN', 'connected to the VPN Server') + ip);
			else ev('wgpeer_off', '📴 ' + p.name + ' ' + t('si è scollegato dal Server VPN', 'disconnected from the VPN Server'));
		}
		S.p[p.id] = { rx: x.rx, tx: x.tx, hs: x.hs, on: on };
	}
	for (let k in keys(S.p)) if (!seen[k]) delete S.p[k];
	let ks = sort(keys(U.d));
	while (length(ks) > KEEP) delete U.d[shift(ks)];
	wj(ST, S);
	if (U.ch && (now - (U.st ?? 0) >= SAVET || (U.cb ?? 0) >= SAVEB)) save(U);
	else wj(TMP, U);
	/* Prova Da Fuori Casa: contatto arrivato dopo l'inizio = lo decide wgprobe get (stesso controllo «fuori casa»:
	   indirizzo fuori dalla rete di casa e dalla rete della VPN), che segna ok nel file anche se l'app non guarda */
	let R = rj(PRB);
	if (R && R.id && !R.ok && now < (R.until ?? 0)) {
		let x = S.p[R.id];
		if (x && x.hs >= (R.t ?? 0)) sh('ubus -t 5 call wrtfreedom wgprobe ' + q('{"action":"get"}') + ' >/dev/null 2>&1');
	}
	wdcheck(N, ifc, D.ok);
}
function probe() {
	let R = rj(PRB);
	if (!R) return;
	let C = { run: false, t: time() };
	/* IP pubblico visto da internet */
	let pub = trim(sh('(curl -s -m 8 https://api.ipify.org || uclient-fetch -q -T 8 -O - https://api.ipify.org) 2>/dev/null'));
	C.pub = match(pub, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) ? pub : '';
	/* nome DDNS: indirizzi dati da un DNS pubblico (quello di casa può rispondere con l'IP del router) */
	let host = '' + (R.host ?? '');
	if (length(host) && match(host, /[A-Za-z]/) && match(host, /^[A-Za-z0-9.-]{1,253}$/)) {
		let ips = [], after = false;
		for (let l in split(sh('nslookup ' + q(host) + ' 1.1.1.1 2>/dev/null'), '\n')) {
			if (match(l, /^Name:/)) after = true;
			else if (after) { let m = match(l, /^Address( [0-9]+)?:[ \t]*([0-9]{1,3}(\.[0-9]{1,3}){3})[ \t]*$/); if (m) push(ips, m[2]); }
		}
		C.ddns = { host: host, ips: ips, ok: length(C.pub) && length(ips) ? index(ips, C.pub) >= 0 : null };
	}
	wj(PRBC, C);
}
/* scaduti: tolti con lo stesso metodo dell'app (wg, network, impostazioni, orari, riga del crontab) */
function expire() {
	let N = ucfile('network'), ifc = wgiface(N), now = time();
	if (!ifc) return;
	for (let k in N) {
		if (N[k]['.type'] != 'wireguard_' + ifc) continue;
		let e = +((WC['peer_' + k] ?? {}).exp ?? 0);
		if (e <= 0 || e > now) continue;
		sh('ubus call wrtfreedom wgpeer ' + q(sprintf('%J', { action: 'del', id: k })) + ' >/dev/null 2>&1');
		ev('wgpeer_exp', '⌛ ' + (N[k].description ?? k) + ': ' + t('accesso al Server VPN scaduto, dispositivo tolto', 'VPN Server access expired, device removed'));
	}
}

let cmd = ARGV[0] ?? '';
if (cmd == 'tick') tick();
else if (cmd == 'probe') probe();
else if (cmd == 'exp') expire();
else if (cmd == 'save') save(null);
else { print('uso: wgx.uc tick|probe|exp|save\n'); exit(1); }
