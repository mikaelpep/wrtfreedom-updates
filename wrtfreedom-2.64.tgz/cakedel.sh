# WrtFreedom: rimuove cake-autorate con il suo script ufficiale
LOG() { echo "## $*"; }
/etc/init.d/cake-autorate stop 2>/dev/null; /etc/init.d/cake-autorate disable 2>/dev/null
rm -rf /var/run/cake-autorate
if [ -f /root/cake-autorate/uninstall.sh ]; then printf 'n\n' | sh /root/cake-autorate/uninstall.sh; fi
rm -rf /root/cake-autorate /etc/init.d/cake-autorate /etc/rc.d/*cake-autorate
sed -i '\#^/root/cake-autorate/$#d;\#^/etc/init.d/cake-autorate$#d' /etc/sysupgrade.conf 2>/dev/null
LOG "OK cake-autorate rimosso"
