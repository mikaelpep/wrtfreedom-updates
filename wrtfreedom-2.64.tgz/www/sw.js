/* WrtFreedom web app: tiene in memoria i file dell'app (non i dati del router).
   Prima prova il router (così dopo un aggiornamento del Pacchetto Router arriva subito la versione nuova),
   se non risponde usa la copia salvata. Le chiamate al router (/ubus, /cgi-bin) non passano di qui. */
var C = 'wrtfreedom-v1';
self.addEventListener('install', function (e) { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', function (e) {
  var u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.indexOf('/wrtfreedom/') !== 0) return;
  e.respondWith(fetch(e.request).then(function (r) {
    if (r.ok) { var c2 = r.clone(); caches.open(C).then(function (c) { c.put(e.request, c2); }); }
    return r;
  }).catch(function () { return caches.match(e.request); }));
});
