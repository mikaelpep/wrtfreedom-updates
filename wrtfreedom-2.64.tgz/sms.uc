'use strict';
/* WrtFreedom: SMS del modem (pacchetto 2.41), fuori da rpcd perché il modem può rispondere lento.
   uso: ucode sms.uc refresh [wait]   legge gli SMS e li salva in /tmp/wf-sms.json; i ricevuti nuovi vanno negli Eventi.
                                      Una lettura alla volta (/tmp/wf-sms.lock, scade in 5 min): un'altra esce subito,
                                      con «wait» (dopo invio e cancellazione) aspetta fino a 30 s
        ucode sms.uc send <num> <file> manda il testo del file al numero
        ucode sms.uc delete <id>        cancella un SMS (id dell'elenco)
   Strada: ModemManager (mmcli, qualsiasi modem che gestisce), altrimenti i comandi AT standard (AT+CMGL / AT+CMGD con lo
   strumento AT del router, at.sh); l'invio senza ModemManager con sms_tool. Gli SMS letti da ModemManager non cambiano:
   si legge solo il dettaglio di quelli nuovi. Elenco: {t, via, send, list:[{id, num, text, time, dir, state}]} */
import { readfile, writefile, popen, stat, mkdir, rmdir } from 'fs';

const OUT = '/tmp/wf-sms.json', SEEN = '/etc/wrtfreedom/sms.seen', W = '/usr/share/wrtfreedom', LOCK = '/tmp/wf-sms.lock';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
/* opzione di una sezione con nome di /etc/config/wrtfreedom letta dal file, senza processi (uci salva sempre col commit) */
function uo(sec, opt) {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
		let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m && m[1] == opt) return m[2];
	}
	return '';
}
function js(c) { try { return json(sh(c)); } catch (e) { return null; } }
const EN = uo('ui', 'lang') == 'en';
function t(it, en) { return EN ? en : it; }
function has(c) { return length(trim(sh('command -v ' + c + ' 2>/dev/null'))) > 0; }
function mmok() { return has('mmcli') && match(sh('mmcli -L 2>/dev/null'), /\/Modem\/[0-9]+/) != null; }
function at(c) { return sh('sh ' + W + '/at.sh ' + q(c) + ' 2>/dev/null'); }
/* blocco con scadenza (come tgq.uc): vero se preso; uno rimasto da più di 5 minuti si toglie */
function lock() {
	if (mkdir(LOCK)) return true;
	let s = stat(LOCK);
	if (s && time() - s.mtime < 300) return false;
	rmdir(LOCK); return !!mkdir(LOCK);
}
function prev() { try { return json(readfile(OUT) ?? 'null'); } catch (e) { return null; } }

/* ModemManager: percorso /org/freedesktop/ModemManager1/SMS/<n>, id = n */
function mmread() {
	let P = js('mmcli -m any --messaging-list-sms -J 2>/dev/null')?.['modem.messaging.sms'] ?? [], old = {}, L = [];
	for (let s in (prev()?.list ?? [])) old[s.id] = s;
	for (let p in P) {
		let id = '' + split(p, '/')[-1];
		if (old[id] && old[id].via == 'mm' && old[id].state != 'receiving') { push(L, old[id]); continue; }
		let s = js('mmcli -s ' + q(p) + ' -J 2>/dev/null')?.sms;
		if (!s) continue;
		let c = s.content ?? {}, pr = s.properties ?? {};
		push(L, { id: id, via: 'mm', num: c.number ?? '', text: c.text ?? '', time: pr.timestamp ?? '', state: pr.state ?? '',
			dir: (pr['pdu-type'] == 'submit') ? 'out' : 'in' });
	}
	return L;
}
/* comandi AT standard, modo testo: +CMGL: <i>,"<stato>","<numero>",,"<aa/mm/gg,hh:mm:ss±zz>" poi il testo */
function atread() {
	at('AT+CMGF=1');
	let o = at('AT+CMGL="ALL"'), L = [], cur = null;
	for (let l in split(o, '\n')) {
		l = trim(l);
		let m = match(l, /^\+CMGL: *([0-9]+),"([^"]*)","([^"]*)",[^,]*,"([^"]*)"/);
		if (m) { cur = { id: m[1], via: 'at', num: m[3], text: '', time: m[4], state: m[2], dir: index(m[2], 'STO') >= 0 ? 'out' : 'in' }; push(L, cur); continue; }
		if (cur && length(l) && l != 'OK' && !match(l, /^\+CM[GS] ERROR/)) cur.text += (length(cur.text) ? '\n' : '') + l;
	}
	return L;
}
function via() { return mmok() ? 'mm' : (length(trim(at('AT'))) ? 'at' : ''); }

let cmd = ARGV[0];
if (cmd == 'refresh') {
	let ok = lock();
	for (let i = 0; !ok && ARGV[1] == 'wait' && i < 30; i++) { sh('sleep 1'); ok = lock(); }
	if (!ok) exit(0);
	let v = via(), L = v == 'mm' ? mmread() : v == 'at' ? atread() : [];
	writefile(OUT, sprintf('%J', { t: time(), via: v, send: v == 'mm' || has('sms_tool'), list: L }));
	/* ricevuti nuovi: un evento ciascuno (la prima volta si segnano tutti senza avvisare, solo con una lettura riuscita:
	   senza modem pronto il file non nasce e gli SMS già presenti non diventano «nuovi» al giro dopo) */
	let first = stat(SEEN) == null, seen = {}, add = '';
	if (first && v == '') { rmdir(LOCK); exit(0); }
	for (let x in split(readfile(SEEN) ?? '', '\n')) if (length(x)) seen[x] = 1;
	for (let s in L) {
		let k = s.via + ':' + s.id + ':' + s.time;
		if (s.dir != 'in' || seen[k]) continue;
		add += k + '\n';
		if (!first) sh('sh ' + W + '/event.sh cron sms net ' + q('📩 SMS ' + t('da', 'from') + ' ' + s.num + ': ' + substr(s.text, 0, 300)) + ' >/dev/null 2>&1');
	}
	if (first || length(add)) writefile(SEEN, (readfile(SEEN) ?? '') + add);
	rmdir(LOCK);
	exit(0);
}
if (cmd == 'send') {
	let num = ARGV[1] ?? '', text = trim(readfile(ARGV[2] ?? '') ?? '');
	if (!match(num, /^\+?[0-9]{3,20}$/) || !length(text)) { print('## ERRORE ' + t('numero o testo non validi', 'invalid number or text') + '\n'); exit(1); }
	if (mmok()) {
		/* ModemManager: il testo va tra apici singoli, quindi gli apostrofi diventano tipografici */
		let p = trim(match(sh('mmcli -m any ' + q("--messaging-create-sms=text='" + replace(text, "'", '’') + "',number='" + num + "'") + ' 2>&1'), /\/org\/freedesktop\/ModemManager1\/SMS\/[0-9]+/)?.[0] ?? '');
		if (!length(p)) { print('## ERRORE ' + t('il modem non ha creato il messaggio', 'the modem did not create the message') + '\n'); exit(1); }
		let o = sh('mmcli -s ' + q(p) + ' --send 2>&1');
		if (index(o, 'successfully') < 0) { print('## ERRORE ' + trim(o) + '\n'); exit(1); }
	} else if (has('sms_tool')) {
		/* stessa porta di at.sh: quella scelta in wrtfreedom.modem.atport, altrimenti la prima delle solite */
		let port = trim(sh('for d in $(uci -q get wrtfreedom.modem.atport) /dev/ttyUSB2 /dev/ttyUSB3 /dev/wwan0at0 /dev/wwan0at1 /dev/ttyACM0 /dev/ttyUSB1; do [ -c "$d" ] && { echo $d; break; }; done'));
		let o = sh('sms_tool -d ' + q(port) + ' send ' + q(num) + ' ' + q(text) + ' 2>&1');
		if (match(o, /error|fail/i)) { print('## ERRORE ' + trim(o) + '\n'); exit(1); }
	} else { print('## ERRORE ' + t('per inviare serve ModemManager o sms_tool (da Software)', 'sending needs ModemManager or sms_tool (from Software)') + '\n'); exit(1); }
	print('## OK ' + t('SMS inviato a', 'SMS sent to') + ' ' + num + '\n');
	sh('ucode ' + W + '/sms.uc refresh wait >/dev/null 2>&1');
	exit(0);
}
if (cmd == 'delete') {
	let id = '' + (ARGV[1] ?? '');
	if (!match(id, /^[0-9]{1,6}$/)) { print('## ERRORE id\n'); exit(1); }
	if (mmok()) sh('mmcli -m any --messaging-delete-sms=' + id + ' >/dev/null 2>&1');
	else at('AT+CMGD=' + id);
	sh('ucode ' + W + '/sms.uc refresh wait >/dev/null 2>&1');
	print('## OK\n');
	exit(0);
}
print('uso: sms.uc refresh|send <numero> <file>|delete <id>\n');
exit(1);
