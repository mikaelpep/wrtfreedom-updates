'use strict';
/* WrtFreedom 2.55: Pacchetto Per L'Assistenza (metodo assist, in sottofondo: mai dentro rpcd)
   uso: ucode assist.uc   → /tmp/wf-assist.tar.gz (cartella «assistenza»: registro, kernel, versioni, stato, configurazione)
                            e /tmp/wf-assist.json {t, files, skip [{f, n}], size, err}
   Senza segreti: valori delle opzioni segrete tolti (password, chiavi, token, PIN, IMEI/ICCID, utenti, chat), poi gli
   stessi controlli della fotografia (tools/v2/fotografia.py): chiavi WireGuard, token di Telegram, credenziali negli
   indirizzi, parametri segreti, numeri lunghi. Le righe che dopo la pulizia sembrano ancora un segreto si tolgono (skip).
   Il file si toglie da solo dopo 30 minuti (anche il metodo lo toglie quando lo legge scaduto). */
import { popen, readfile, writefile, unlink, stat, rename, mkdir, rmdir, lsdir } from 'fs';

const ASF = '/tmp/wf-assist.tar.gz', ASJ = '/tmp/wf-assist.json', ASLK = '/tmp/wf-assist.lock', ASID = '/tmp/wf-assist.id', ASD = '/tmp/wf-assist.d';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }

/* nomi di campo segreti (uci, JSON, chiave=valore): come Pulizia.SEGRETI, IDENT, UTENTI e TELEFONI di fotografia.py */
const SECRET = /^(pass(word|wd|phrase)?|pwd|key|keys?[0-9]|secret|token|psk|sae_password|private_key|preshared_key|public_key|priv|privkey|pub|pubkey|presharedkey|auth_secret|password_[a-z0-9_]+|[a-z0-9_]*_password|[a-z0-9_]*_secret|[a-z0-9_]*_token|api_?key|apikey|pin|newpin|puk|creds?|cred_[a-z0-9_]+|wpa_passphrase|wep_key[0-9]?|acct_secret|auth_pass|dhcp_secret|lookup_key|cert_key|credentials|iccid|imei|imsi|meid|eid|msisdn|own[-_]?numbers?|equipment[-_]identifier|sim[-_]id|operator[-_]?number|user|username|login|account_email|email|mail|chat|chat_?id|chats|number|numbers|phone|smsc|recipient|pincode|[a-z0-9_]*token|account|[a-z0-9_]*pass|[a-z0-9_]*pwd|identity|anonymous_identity)$/i;
const HID = '***';

let SEC = '';
function cleanline(l) {
	/* sezione uci in corso (config tipo 'nome'): option url della sezione hb (indirizzo del battito) tolta tutta */
	let cs = match(l, /^config[ \t]+([A-Za-z0-9_-]+)([ \t]+'?([A-Za-z0-9_-]+)'?)?/);
	if (cs) SEC = cs[3] ?? cs[1];
	/* uci: option/list nome valore */
	/* il nome dell'opzione può essere tra apici («option 'password' '…'») */
	let m = match(l, /^([ \t]*(option|list)[ \t]+)(['"]?)([A-Za-z0-9_-]+)(['"]?)([ \t]+)(.*)$/);
	if (m && (match(m[4], SECRET) || (SEC == 'hb' && m[4] == 'url'))) return m[1] + m[3] + m[4] + m[5] + m[6] + "'" + HID + "'";
	/* JSON: "nome": "valore" o numero */
	l = replace(l, /"([A-Za-z0-9_-]+)"([ \t]*:[ \t]*)("[^"]*"|-?[0-9]+)/g, (all, k, sep, v) => match(k, SECRET) ? '"' + k + '"' + sep + '"' + HID + '"' : all);
	/* credenziali negli indirizzi e parametri segreti (token=, password=, key=…) */
	l = replace(l, /:\/\/[^\/@ \t'"]+@/g, '://' + HID + '@');
	/* indirizzi (upd.url e simili): resta il dominio, il percorso dopo si toglie (può contenere chiavi o nomi) */
	l = replace(l, /([A-Za-z][A-Za-z0-9+.-]{0,15}:\/\/[A-Za-z0-9.*@:\[\]-]+)\/[^ \t'"]+/g, (all, a) => a + '/' + HID);
	l = replace(l, /([?&;, \t.]|^)([A-Za-z0-9_]*_)?(token|password|passwd|pass|pw|key|apikey|api_key|secret|auth|sig|psk|pin|chat_?id)([=:][ \t]?)('[^']*'|"[^"]*"|[^ \t&'"]+)/gi, (all, a, p, k, s, v) => a + (p ?? '') + k + s + HID);
	/* intestazioni e opzioni di curl con le credenziali */
	l = replace(l, /((authorization|x-api-key|x-auth-token|private-token)[ \t]*:[ \t]*(bearer[ \t]+|basic[ \t]+|token[ \t]+)?)[^ \t'"]+/gi, (all, a) => a + HID);
	l = replace(l, /((^|[ \t])(-u|--user|--proxy-user)[ \t]*)('[^']*'|"[^"]*"|[^ \t]+)/g, (all, a) => a + HID);
	/* chiavi: SSH, WireGuard (44 caratteri), token di Telegram, hash delle password */
	l = replace(l, /(ssh-(ed25519|rsa|dss)|ecdsa-sha2-nistp[0-9]{3}) [A-Za-z0-9+\/=]{20}[A-Za-z0-9+\/=]*/g, (all, a) => a + ' ' + HID);
	l = replace(l, /[A-Za-z0-9+\/]{42}[A-Za-z0-9+\/]*=/g, HID);
	l = replace(l, /[0-9]{8,10}:[A-Za-z0-9_-]{30}[A-Za-z0-9_-]*/g, HID);
	l = replace(l, /\$[0-9a-z]{1,2}\$[^ \t:'"]{8}[^ \t:'"]*/g, HID);
	/* indirizzi email e numeri lunghi (IMEI, ICCID, IMSI, telefoni) */
	l = replace(l, /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2}[A-Za-z]*/g, HID + '@example.com');
	l = replace(l, /(^|[^0-9.:])\+?[0-9]{11,22}([^0-9.:]|$)/g, (all, a, b) => a + HID + b);
	return l;
}
/* controllo dopo la pulizia (come sospetti() di fotografia.py): parole lunghe con cifre, minuscole e maiuscole, o numeri
   di 15–22 cifre. Vero = la riga sembra ancora un segreto */
function suspect(l) {
	for (let t in match(l, /[A-Za-z0-9+\/_=-]{32}[A-Za-z0-9+\/_=-]*/g) ?? []) {
		let x = t[0];
		if (length(split(x, '/')) > 3) continue;
		if (match(x, /[0-9]/) && match(x, /[a-z]/) && match(x, /[A-Z]/)) return true;
	}
	return match(l, /(^|[^0-9.:])[0-9]{15,22}([^0-9.:]|$)/) != null;
}
let FILES = [], SKIP = [];
function put(name, text) {
	let o = [], n = 0;
	SEC = '';
	for (let l in split(text ?? '', '\n')) {
		let c = cleanline(l);
		if (suspect(c)) { n++; c = '[riga tolta: possibile segreto]'; }
		push(o, c);
	}
	writefile(ASD + '/assistenza/' + name, join('\n', o));
	push(FILES, name);
	if (n) push(SKIP, { f: name, n: n });
}

mkdir(ASLK, 448);
sh('rm -rf ' + ASD + ' && mkdir -p ' + ASD + '/assistenza/configurazione && chmod -R 700 ' + ASD);
let err = null;
if (!has(ASD + '/assistenza/configurazione')) err = 'cartella non creata';
else {
	put('registro.txt', sh('logread 2>/dev/null'));
	put('kernel.txt', sh('dmesg 2>/dev/null'));
	put('versioni.txt', sh('cat /etc/openwrt_release 2>/dev/null; echo; echo "WrtFreedom $(cat /usr/share/wrtfreedom/VERSION 2>/dev/null)"; uname -a; echo; ' +
		'ubus call system board 2>/dev/null; echo; echo "## pacchetti"; if command -v apk >/dev/null 2>&1; then apk list --installed 2>/dev/null; ' +
		'else opkg list-installed 2>/dev/null; fi'));
	put('stato.txt', sh('echo "## acceso da"; uptime; echo; echo "## memoria"; free; echo; echo "## spazio"; df -h; echo; ' +
		'echo "## sistema"; ubus call system info 2>/dev/null; echo; echo "## reti"; ubus call network.interface dump 2>/dev/null; echo; ' +
		'echo "## indirizzi"; ip addr 2>/dev/null; echo; echo "## percorsi"; ip route 2>/dev/null; ip -6 route 2>/dev/null; echo; ' +
		'echo "## servizi"; ubus call service list 2>/dev/null; echo; echo "## linea"; cat /tmp/wf-line.json 2>/dev/null; echo; ' +
		'echo "## processi"; top -b -n 1 2>/dev/null | head -n 40'));
	for (let f in lsdir('/etc/config') ?? [])
		if (match(f, /^[A-Za-z0-9_.-]+$/) && stat('/etc/config/' + f)?.type == 'file') put('configurazione/' + f, readfile('/etc/config/' + f));
	put('pianificazioni.txt', readfile('/etc/crontabs/root') ?? '');
	put('comandi-all-avvio.txt', readfile('/etc/rc.local') ?? '');
	unlink(ASF);
	sh('tar -czf ' + ASF + '.t -C ' + ASD + ' assistenza 2>/dev/null && chmod 600 ' + ASF + '.t && mv ' + ASF + '.t ' + ASF);
	if (!has(ASF)) err = 'archivio non creato (spazio pieno?)';
}
sh('rm -rf ' + ASD);
let id = '' + time() + '-' + (stat(ASF)?.size ?? 0);
writefile(ASID, id);
wjs(ASJ, { t: time(), files: FILES, skip: SKIP, size: stat(ASF)?.size ?? 0, err: err });
rmdir(ASLK);
/* si toglie da solo dopo 30 minuti (se nel frattempo non ne è stato fatto un altro) */
if (!err) sh('( sleep 1800; [ "$(cat ' + ASID + ' 2>/dev/null)" = ' + q(id) + ' ] && rm -f ' + ASF + ' ' + ASJ + ' ' + ASID + ' ) >/dev/null 2>&1 </dev/null &');
