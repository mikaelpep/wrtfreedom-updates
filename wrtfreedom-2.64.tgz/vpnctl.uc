#!/usr/bin/ucode
'use strict';
/* WrtFreedom: Servizio VPN, parti lente fuori da rpcd (pacchetto 2.42). La configurazione la cambia sempre il metodo
   ubus wrtfreedom.vpnout (vpnbuild in wrtfreedom.uc); qui si parla con i servizi e si controllano i collegamenti.
   uso: ucode vpnctl.uc login <servizio>    controlla le credenziali (nord: token → chiave NordLynx; mullvad: numero
                                            di account → chiave registrata; pia: utente e password → token)
        ucode vpnctl.uc places <servizio>   paesi o località → /tmp/wf-vpnplaces-<servizio>.json
        ucode vpnctl.uc acccheck            accessi dei servizi: validi, scadenza dell'abbonamento → /tmp/wf-vpnacc.json
        ucode vpnctl.uc connect [file]      richiesta in /tmp/wf-vpnreq.json (rpcd) o nel file dato (tick, rotate, boot:
                                            /tmp/wf-vpnreq.<n>.json, tolto alla fine): server più veloce → setprof
        ucode vpnctl.uc ipcheck             IP pubblico di ogni collegamento → /tmp/wf-vpnip.json
        ucode vpnctl.uc leak <collegamento> controllo delle perdite DNS (bash.ws) → /tmp/wf-vpnleak.json
        ucode vpnctl.uc rotate              un altro server per ogni collegamento automatico (Pianificazioni)
        ucode vpnctl.uc srvlist <servizio> <paese>  server del paese → /tmp/wf-vpnsrv-<servizio>-<paese>.json
        ucode vpnctl.uc boot                all'accensione: Collega All'Avvio e Paese All'Avvio
        ucode vpnctl.uc newdev <mac> <ip> <nome>  dispositivo nuovo nella VPN (con «solo alcuni» e Nuovi Dispositivi Protetti)
        ucode vpnctl.uc tick                ogni 30 s da notify.sh: collegamenti, ricollegamento, cambio automatico,
                                            orari, nuovo IP del giorno, eventi, dati, disponibilità, DNS; uno alla
                                            volta (/tmp/wf-vpntick.lock, scade in 5 min) */
import { readfile, writefile, unlink, popen, stat, rename, mkdir, rmdir } from 'fs';

const W = '/usr/share/wrtfreedom', IPF = '/tmp/wf-vpnip.json', STF = '/tmp/wf-vpn.json', USEF = '/tmp/wf-vpnuse.json', USEP = '/etc/wrtfreedom/vpnuse.json';
const REQ = '/tmp/wf-vpnreq.json', REQRX = /^\/tmp\/wf-vpnreq\.[0-9a-f]{1,16}\.json$/, LEAKF = '/tmp/wf-vpnleak.json', KEY = /^[A-Za-z0-9+\/]{42,43}=$/;
const NORD = 'https://api.nordvpn.com/v1/', MULL = 'https://api.mullvad.net/', PIACA = W + '/pia-ca.crt', AZIRE = 'https://api.azirevpn.com/v3/', IVPN = 'https://api.ivpn.net/';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function ug(k) { return trim(sh('uci -q get ' + k + ' 2>/dev/null')); }
function rd(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
let EN = null;	/* lingua: la imposta cfg() (ui.lang), niente uci get a parte */
function say(s) { print(s + '\n'); }
const CURL = stat('/usr/bin/curl') != null;
/* richiesta HTTPS con risposta JSON (o testo con raw); opz: auth «utente:password», via = interfaccia di uscita,
   data = campi POST, extra = opzioni di curl in più */
function get(url, o) {
	o = o ?? {};
	let c;
	if (CURL) {
		c = 'curl -s -m 15 ' + (o.auth ? '-u ' + q(o.auth) + ' ' : '') + (o.via ? '--interface ' + q(o.via) + ' ' : '') + (o.extra ?? '');
		for (let k, v in (o.data ?? {})) c += '--data-urlencode ' + q(k + '=' + v) + ' ';
		c += q(url);
	}
	else c = 'uclient-fetch -q -T 15 -O - ' + (o.auth ? '--user=' + q(split(o.auth, ':')[0]) + ' --password=' + q(substr(o.auth, index(o.auth, ':') + 1)) + ' ' : '') +
		(o.data ? '--post-data=' + q(join('&', map(keys(o.data), (k) => k + '=' + o.data[k]))) + ' ' : '') + q(url);
	let r = sh(c + ' 2>/dev/null');
	if (o.raw) return r;
	try { return json(r); } catch (e) { return null; }
}
function urlenc(s) {
	let o = '';
	for (let i = 0; i < length(s); i++) { let c = ord(s, i); o += ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 46 || c == 95 || c == 126) ? chr(c) : sprintf('%%%02X', c); }
	return o;
}
function call(o) { try { return json(sh('ubus -t 30 call wrtfreedom vpnout ' + q(sprintf('%J', o)) + ' 2>/dev/null')); } catch (e) { return null; } }
/* evento negli Eventi; con l'avviso spento (al = false) solo nel registro: categoria senza notifiche */
function ev(type, txt, al) { sh('sh ' + W + '/event.sh cron ' + type + ' ' + (al === false ? 'info' : 'net') + ' ' + q(txt) + ' >/dev/null 2>&1'); }
/* opzione sì/no di wrtfreedom.vpnout con il suo valore di serie */
function ob(C, k, d) { let v = (C.vpnout ?? {})[k]; return v == null || v == '' ? d : v == '1'; }
/* data di oggi AAAA-MM-GG senza date (localtime: mese da 1, anno intero) */
function today() { let n = localtime(time()); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
/* ultimi eventi del servizio per le Statistiche (cadute, ritorni, cambi di server): /etc/wrtfreedom/vpnev.json */
const EVF = '/etc/wrtfreedom/vpnev.json';
function evrec(k, x) {
	let L = rd(EVF) ?? [];
	push(L, { t: time(), d: today(), k: k, x: x });
	while (length(L) > 40) shift(L);
	writefile(EVF + '.t', sprintf('%J', L)); rename(EVF + '.t', EVF);
}
/* chiavi mai nella riga di comando (visibile in /proc): file in /tmp/.wf-k (0700) letto da stdin e tolto subito, come
   kfile/ukey di wrtfreedom.uc */
function kfile(s) {
	let r = readfile('/dev/urandom', 8) ?? '', n = '';
	for (let i = 0; i < 8; i++) n += sprintf('%02x', ord(r, i) ?? (time() + i) % 256);
	mkdir('/tmp/.wf-k', 448);
	let f = '/tmp/.wf-k/' + n;
	writefile(f, s);
	return f;
}
/* comando uci batch che imposta wrtfreedom.<sez>.<opz> = chiave dal file e lo toglie */
function ukey(sec, o, v) { let f = kfile('set wrtfreedom.' + sec + '.' + o + '=' + q(v) + '\n'); return 'uci -q batch < ' + f + '; rm -f ' + f + '; '; }
function pubkey(priv) { let f = kfile(priv + '\n'); return trim(sh('wg pubkey < ' + f + ' 2>/dev/null; rm -f ' + f)); }
function newkey() { return trim(sh('wg genkey 2>/dev/null')); }
/* sezioni di wrtfreedom lette da uci show: { nome: { .type, opzione: valore o [lista] } } */
function cfg() {
	let C = {};
	for (let l in split(sh('uci -q show wrtfreedom'), '\n')) {
		let m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)=([A-Za-z0-9_]+)$/);
		if (m) { C[m[1]] = C[m[1]] ?? {}; C[m[1]]['.type'] = m[2]; continue; }
		m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)=(.*)$/);
		if (!m) continue;
		let vals = [], s = m[3], v = match(s, /'([^']*)'/g);
		for (let x in (v ?? [])) push(vals, x[1]);
		C[m[1]] = C[m[1]] ?? {};
		C[m[1]][m[2]] = length(vals) > 1 ? vals : (vals[0] ?? '');
	}
	EN = (C.ui ?? {}).lang == 'en';
	return C;
}
function t(it, en) { if (EN == null) cfg(); return EN ? en : it; }
function arr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }
function tuns(C) {
	let r = [];
	for (let k, s in C) if (s['.type'] == 'vpntun') push(r, { id: k, n: +(s.n ?? 0), prof: s.prof ?? '', on: s.on != '0', fb: s.fb == '1', mode: s.mode ?? '' });
	return sort(r, (a, b) => a.n - b.n);
}
function ifn(n) { return n == 0 ? 'wgout' : 'wgo' + n; }
/* richiesta di cambio server in un file tutto suo (/tmp/wf-vpnreq.<n>.json): tick, rotate e boot non si pestano i piedi
   tra loro né con la richiesta di rpcd (/tmp/wf-vpnreq.json); bg = in sottofondo. connect lo toglie alla fine */
function reqrun(R, bg) {
	let f = '/tmp/wf-vpnreq.' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '' + time(), /[^0-9a-f]/g, ''), 0, 12) + '.json';
	wj(f, R);
	sh(bg ? '( ucode ' + W + '/vpnctl.uc connect ' + f + ' ) >/dev/null 2>&1 &' : 'ucode ' + W + '/vpnctl.uc connect ' + f + ' >/dev/null 2>&1');
}
/* paese della linea (senza VPN), per il collegamento rapido dei servizi che non scelgono da soli: tenuto un giorno */
function linecc() {
	let f = '/tmp/wf-linecc', s = stat(f);
	if (s && time() - s.mtime < 86400) return trim(readfile(f) ?? '');
	let y = get(NORD + 'helpers/ips/insights') ?? {}, cc = match('' + (y.country_code ?? ''), /^[A-Z]{2}$/) ? y.country_code : '';
	if (length(cc)) writefile(f, cc);
	return cc;
}

/* ---------------- server più veloce: un ping a testa (3 prove), tutti insieme ---------------- */
function fastest(L) {
	if (length(L) <= 1) return L[0];
	let f = '/tmp/wf-vpnping.' + time(), c = '';
	for (let i = 0; i < length(L); i++) c += '( ping -c 3 -W 1 -q ' + q(L[i].ip) + " 2>/dev/null | sed -n 's|.*= [0-9.]*/\\([0-9.]*\\)/.*|" + i + " \\1|p' >> " + f + ' ) & ';
	sh(c + 'wait');
	let best = null, bt = 1e9;
	for (let l in split(readfile(f) ?? '', '\n')) { let x = split(trim(l), ' '); if (length(x) == 2 && +x[1] < bt) { bt = +x[1]; best = +x[0]; } }
	unlink(f);
	if (best != null) { L[best].ms = bt; return L[best]; }
	return L[0];
}

/* ---------------- servizi automatici ----------------
   ognuno: login(C) → testo d'errore o null; places() → [{id, name, cc, city?, n}]; servers(C, place, skip) → server
   possibili [{ip, pub, host, city, cc, name, load}] ; conf(C, s) → testo .conf (PIA registra la chiave sul server) */
const P = {
	nord: {
		login: function(C) {
			let r = get(NORD + 'users/services/credentials', { auth: 'token:' + ((C.va_nord ?? {}).token ?? '') });
			if (r && match('' + (r.nordlynx_private_key ?? ''), KEY)) { sh(ukey('va_nord', 'key', r.nordlynx_private_key) + 'uci commit wrtfreedom'); return null; }
			if (r) { sh('uci -q delete wrtfreedom.va_nord; uci commit wrtfreedom'); return t('NordVPN ha rifiutato il token (non valido, scaduto o revocato): generane uno nuovo e controlla che l\'abbonamento sia attivo', 'NordVPN rejected the token (invalid, expired or revoked): generate a new one and check the subscription is active'); }
			return t('NordVPN non risponde: controlla la connessione e riprova', 'NordVPN is not responding: check the connection and try again');
		},
		places: function() {
			let out = [];
			for (let c in arr(get(NORD + 'servers/countries'))) if (+c.serverCount > 0 && match(c.code ?? '', /^[A-Z]{2}$/)) push(out, { id: '' + c.id, name: c.name, cc: c.code, n: c.serverCount });
			return out;
		},
		servers: function(C, place, skip, n) {
			let out = [];
			let cf = place == 'auto' ? '' : '&filters%5Bcountry_id%5D=' + int(+place);
			for (let s in arr(get(NORD + 'servers/recommendations?filters%5Bservers_technologies%5D%5Bidentifier%5D=wireguard_udp' + cf + '&limit=' + (n ?? 8)))) {
				let pub = null;
				for (let tc in (s.technologies ?? [])) if (tc.identifier == 'wireguard_udp') for (let m in (tc.metadata ?? [])) if (m.name == 'public_key') pub = m.value;
				let loc = ((s.locations ?? [])[0] ?? {}).country ?? {};
				if (s.status == 'online' && s.hostname != skip && s.station != skip && match(pub ?? '', KEY) && match(s.station ?? '', /^[0-9.]+$/))
					push(out, { ip: s.station, pub: pub, host: s.hostname, name: s.name ?? s.hostname, cc: loc.code ?? '', city: (loc.city ?? {}).name ?? '', load: s.load, id: s.id });
			}
			return out;
		},
		conf: function(C, s) {
			return '[Interface]\nPrivateKey = ' + (C.va_nord ?? {}).key + '\nAddress = 10.5.0.2/32\nDNS = 103.86.96.100, 103.86.99.100\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.ip + ':51820\n';
		}
	},
	mullvad: {
		/* numero di account: la chiave del router si registra una volta (al massimo 5 per account) */
		login: function(C) {
			let A = C.va_mullvad ?? {}, priv = match(A.priv ?? '', KEY) ? A.priv : newkey();
			let r = trim(get(MULL + 'wg', { data: { account: A.account ?? '', pubkey: pubkey(priv) }, raw: true }));
			let m = match(r, /^([0-9.]+\/[0-9]+)/);
			if (m) { sh(ukey('va_mullvad', 'priv', priv) + 'uci set wrtfreedom.va_mullvad.addr=' + q(m[1]) + '; uci commit wrtfreedom'); return null; }
			if (length(r)) {
				sh('uci -q delete wrtfreedom.va_mullvad; uci commit wrtfreedom');
				return match(r, /[Tt]oo many/) ? t('Account Mullvad con già 5 chiavi: togline una dal sito mullvad.net e riprova', 'Mullvad account already has 5 keys: remove one on mullvad.net and try again')
					: t('Account Mullvad non valido o scaduto', 'Mullvad account not valid or expired') + ' (' + substr(r, 0, 80) + ')';
			}
			return t('Mullvad non risponde: controlla la connessione e riprova', 'Mullvad is not responding: check the connection and try again');
		},
		places: function() {
			let d = get(MULL + 'public/relays/wireguard/v2'), L = {}, out = [];
			for (let r in arr(((d ?? {}).wireguard ?? {}).relays)) if (r.active) { let loc = r.location; L[loc] = (L[loc] ?? 0) + 1; }
			for (let k, n in L) { let x = ((d ?? {}).locations ?? {})[k] ?? {}; push(out, { id: k, name: x.country ?? k, cc: uc(split(k, '-')[0]), city: x.city ?? '', n: n }); }
			return out;
		},
		servers: function(C, place, skip, n) {
			let d = get(MULL + 'public/relays/wireguard/v2'), LOC = (d ?? {}).locations ?? {}, out = [], R = arr(((d ?? {}).wireguard ?? {}).relays);
			let want = place == 'auto' ? lc(linecc()) + '-' : place, okp = (l) => place == 'auto' ? substr(l, 0, 3) == want : l == place;
			if (place == 'auto' && !length(filter(R, (r) => r.active && okp(r.location)))) { want = 'se-'; }
			for (let r in R)
				if (r.active && okp(r.location) && r.ipv4_addr_in != skip && match(r.public_key ?? '', KEY))
					push(out, { ip: r.ipv4_addr_in, pub: r.public_key, host: r.hostname, name: r.hostname, cc: uc(split(r.location, '-')[0]), city: (LOC[r.location] ?? {}).city ?? '' });
			return slice(out, 0, n ?? 8);
		},
		conf: function(C, s) {
			let A = C.va_mullvad ?? {};
			return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + A.addr + '\nDNS = 10.64.0.1\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.ip + ':51820\n';
		}
	},
	pia: {
		/* utente e password → token (valido un giorno: si rinnova a ogni collegamento) */
		token: function(C) {
			let A = C.va_pia ?? {}, r = get('https://www.privateinternetaccess.com/api/client/v2/token', { data: { username: A.user ?? '', password: A.pass ?? '' } });
			return r && r.token ? r.token : null;
		},
		login: function(C) {
			if (this.token(C)) {
				let A = C.va_pia ?? {};
				if (!match(A.priv ?? '', KEY)) sh(ukey('va_pia', 'priv', newkey()) + 'uci commit wrtfreedom');
				return null;
			}
			sh('uci -q delete wrtfreedom.va_pia; uci commit wrtfreedom');
			return t('Utente o password di PIA non validi, o abbonamento scaduto', 'PIA username or password not valid, or subscription expired');
		},
		list: function() {
			/* elenco dei server: prima riga JSON, poi la firma */
			let r = get('https://serverlist.piaservers.net/vpninfo/servers/v6', { raw: true });
			try { return json(split(r, '\n')[0]); } catch (e) { return null; }
		},
		places: function() {
			let out = [];
			for (let g in arr((this.list() ?? {}).regions)) if (!g.offline && length(arr((g.servers ?? {}).wg)))
				push(out, { id: g.id, name: g.name, cc: uc(g.country ?? ''), n: length(g.servers.wg) });
			return out;
		},
		servers: function(C, place, skip, n) {
			let out = [];
			let G = arr((this.list() ?? {}).regions), cc = place == 'auto' ? linecc() : '';
			if (place == 'auto' && !length(filter(G, (g) => uc(g.country ?? '') == cc && !g.offline))) cc = 'CH';
			for (let g in G) if (place == 'auto' ? uc(g.country ?? '') == cc && !g.offline : g.id == place)
				for (let s in arr((g.servers ?? {}).wg)) if (s.ip != skip) push(out, { ip: s.ip, host: s.cn, name: g.name, cc: uc(g.country ?? ''), city: '' });
			return slice(out, 0, n ?? 8);
		},
		conf: function(C, s) {
			let tk = this.token(C), A = C.va_pia ?? {};
			if (!tk) return null;
			/* la chiave si registra sul server scelto (certificato di PIA: router/pia-ca.crt, dal loro progetto pubblico) */
			let r = get('https://' + s.host + ':1337/addKey?pt=' + urlenc(tk) + '&pubkey=' + urlenc(pubkey(A.priv)),
				{ extra: '--connect-to ' + q(s.host + '::' + s.ip + ':') + ' --cacert ' + q(PIACA) + ' ' });
			if (!r || r.status != 'OK') return null;
			return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + r.peer_ip + '/32\nDNS = ' + ((r.dns_servers ?? [])[0] ?? '10.0.0.243') + '\n\n[Peer]\nPublicKey = ' + r.server_key + '\nEndpoint = ' + r.server_ip + ':' + r.server_port + '\n';
		}
	},
	azire: {
		/* token del Manager di AzireVPN (API v3 ufficiale): il router registra una sua chiave con POST /ips, una volta */
		login: function(C) {
			if (!CURL) return t('Serve curl: installalo da Software', 'curl is needed: install it from Software');
			let A = C.va_azire ?? {}, priv = match(A.priv ?? '', KEY) ? A.priv : newkey();
			let r = get(AZIRE + 'ips', { extra: '-X POST -H ' + q('Authorization: Bearer ' + (A.token ?? '')) + ' -H ' + q('Content-Type: application/json') + ' -d ' + q(sprintf('%J', { key: pubkey(priv) })) + ' ' });
			let x = (r ?? {}).data ?? r ?? {}, a = '' + (x.ipv4_address ?? '');
			if (match(a, /^[0-9.]+(\/[0-9]+)?$/)) {
				if (index(a, '/') < 0) a += '/32';
				sh(ukey('va_azire', 'priv', priv) + 'uci set wrtfreedom.va_azire.addr=' + q(a) + '; uci set wrtfreedom.va_azire.dns=' + q(arr(x.dns)[0] ?? '91.231.153.2') + '; uci set wrtfreedom.va_azire.ipid=' + q('' + (x.id ?? '')) + '; uci commit wrtfreedom');
				return null;
			}
			if (r) { sh('uci -q delete wrtfreedom.va_azire; uci commit wrtfreedom'); return t('AzireVPN ha rifiutato il token: creane uno nuovo nel Manager', 'AzireVPN rejected the token: create a new one in the Manager') + (r.message ? ' (' + substr(r.message, 0, 80) + ')' : ''); }
			return t('AzireVPN non risponde: controlla la connessione e riprova', 'AzireVPN is not responding: check the connection and try again');
		},
		list: function() { return arr((get(AZIRE + 'locations') ?? {}).locations); },
		places: function() {
			let out = [];
			for (let l in this.list()) if (match(l.name ?? '', /^[a-z0-9-]{2,20}$/)) push(out, { id: l.name, name: l.country ?? l.name, cc: uc(l.iso ?? ''), city: l.city ?? '', n: 1 });
			return out;
		},
		servers: function(C, place, skip, n) {
			let L = this.list(), cc = place == 'auto' ? lc(linecc()) : '';
			if (place == 'auto' && !length(filter(L, (l) => l.iso == cc))) cc = 'se';
			let out = [];
			for (let l in L) if ((place == 'auto' ? l.iso == cc : l.name == place) && l.pool != skip && match(l.pubkey ?? '', KEY))
				push(out, { ip: l.pool, host: l.pool, pub: l.pubkey, name: l.city ?? l.name, cc: uc(l.iso ?? ''), city: l.city ?? '' });
			return slice(out, 0, n ?? 8);
		},
		conf: function(C, s) {
			let A = C.va_azire ?? {};
			return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + A.addr + '\nDNS = ' + (A.dns || '91.231.153.2') + '\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.host + ':51820\n';
		}
	},
	ivpn: {
		/* numero di account IVPN (i-XXXX-XXXX-XXXX): una sessione con la chiave del router (conta come un dispositivo) */
		login: function(C) {
			if (!CURL) return t('Serve curl: installalo da Software', 'curl is needed: install it from Software');
			let A = C.va_ivpn ?? {}, priv = match(A.priv ?? '', KEY) ? A.priv : newkey();
			let r = get(IVPN + 'v4/session/new', { extra: '-H ' + q('Content-Type: application/json') + ' -d ' + q(sprintf('%J', { username: A.account ?? '', wg_public_key: pubkey(priv), force: false })) + ' ' });
			let ip = '' + (((r ?? {}).wireguard ?? {}).ip_address ?? '');
			if (r && r.status == 200 && r.token && match(ip, /^[0-9.]+$/)) {
				sh(ukey('va_ivpn', 'priv', priv) + 'uci set wrtfreedom.va_ivpn.addr=' + q(ip + '/32') + '; uci set wrtfreedom.va_ivpn.stoken=' + q(r.token) + '; uci commit wrtfreedom');
				return null;
			}
			if (r && r.status) {
				sh('uci -q delete wrtfreedom.va_ivpn; uci commit wrtfreedom');
				return r.status == 602 ? t('Account IVPN con troppi dispositivi collegati: esci da uno dal sito ivpn.net e riprova', 'IVPN account has too many devices: sign out one on ivpn.net and try again')
					: t('Numero di account IVPN non valido o abbonamento scaduto', 'IVPN account ID not valid or subscription expired') + (r.message ? ' (' + substr(r.message, 0, 80) + ')' : '');
			}
			return t('IVPN non risponde: controlla la connessione e riprova', 'IVPN is not responding: check the connection and try again');
		},
		list: function() { return arr((get(IVPN + 'v5/servers.json') ?? {}).wireguard); },
		pid: function(g) { return replace('' + (g.gateway ?? ''), /\.wg\.ivpn\.net$/, ''); },
		places: function() {
			let out = [];
			for (let g in this.list()) { let id = this.pid(g); if (match(id, /^[a-z0-9-]{2,20}$/)) push(out, { id: id, name: g.country ?? id, cc: uc(g.country_code ?? ''), city: g.city ?? '', n: length(arr(g.hosts)) }); }
			return out;
		},
		servers: function(C, place, skip, n) {
			let G = this.list(), cc = place == 'auto' ? linecc() : '';
			if (place == 'auto' && !length(filter(G, (g) => uc(g.country_code ?? '') == cc))) cc = 'CH';
			let out = [];
			for (let g in G) if (place == 'auto' ? uc(g.country_code ?? '') == cc : this.pid(g) == place)
				for (let h in arr(g.hosts)) if (h.host != skip && match(h.public_key ?? '', KEY))
					push(out, { ip: h.host, host: h.hostname, pub: h.public_key, name: h.hostname, cc: uc(g.country_code ?? ''), city: g.city ?? '', load: h.load != null ? int(h.load + 0.5) : null });
			return slice(out, 0, n ?? 8);
		},
		conf: function(C, s) {
			let A = C.va_ivpn ?? {};
			return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + A.addr + '\nDNS = 172.16.0.1\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.ip + ':2049\n';
		}
	}
};

const ACCF = '/tmp/wf-vpnacc.json', PN = { nord: 'NordVPN', mullvad: 'Mullvad', pia: 'Private Internet Access', azire: 'AzireVPN', ivpn: 'IVPN' };
function acccheck() {
	let C = cfg(), out = rd(ACCF) ?? {}, now = time();
	for (let p in keys(PN)) {
		let A = C['va_' + p];
		if (!A) { delete out[p]; continue; }
		let r = { t: now, ok: null, exp: '' };
		if (p == 'nord') {
			let L = get(NORD + 'users/services', { auth: 'token:' + (A.token ?? '') });
			if (type(L) == 'array') { r.ok = true; for (let s in L) if ((s.service ?? {}).identifier == 'vpn') r.exp = substr(s.expires_at ?? '', 0, 10); }
			else if (L && L.errors) r.ok = false;
		}
		else if (p == 'mullvad') {
			let tk = get(MULL + 'auth/v1/token', { extra: '-H ' + q('Content-Type: application/json') + ' -d ' + q(sprintf('%J', { account_number: A.account ?? '' })) + ' ' });
			if (tk && tk.access_token) {
				let me = get(MULL + 'accounts/v1/accounts/me', { extra: '-H ' + q('Authorization: Bearer ' + tk.access_token) + ' ' });
				r.ok = true; r.exp = substr((me ?? {}).expiry ?? '', 0, 10);
			}
			else if (tk && tk.code) r.ok = false;
		}
		else if (p == 'pia') r.ok = P.pia.token(C) ? true : false;
		else if (p == 'azire' && CURL) {
			let L = get(AZIRE + 'ips', { extra: '-H ' + q('Authorization: Bearer ' + (A.token ?? '')) + ' ' });
			if (L && L.message) r.ok = false; else if (L) r.ok = true;
		}
		else if (p == 'ivpn' && CURL) {
			let x = get(IVPN + 'v4/session/status', { extra: '-H ' + q('Content-Type: application/json') + ' -d ' + q(sprintf('%J', { session_token: A.stoken ?? '' })) + ' ' });
			if (x && x.status == 200) { r.ok = true; let u = +((x.service_status ?? {}).active_until ?? 0); if (u > 0) r.exp = trim(sh('date -d @' + int(u) + ' +%Y-%m-%d 2>/dev/null')); }
			else if (x && x.status) r.ok = false;
		}
		/* avvisi una volta: accesso rifiutato, abbonamento che scade entro 7 giorni */
		let o = out[p] ?? {}, al = ob(C, 'al_exp', true);
		if (r.ok === false && o.ok !== false) ev('vpnacc', '⚠️ ' + PN[p] + ': ' + t('accesso rifiutato, rifai l\'accesso nell\'app (Servizio VPN)', 'access rejected, sign in again in the app (VPN Service)'), al);
		if (length(r.exp)) {
			let d = trim(sh('date -d ' + q(r.exp + ' 00:00') + ' +%s 2>/dev/null')), left = length(d) ? int((+d - now) / 86400) : 999;
			if (left <= 7 && o.warn != r.exp) { r.warn = r.exp; ev('vpnacc', '⏳ ' + PN[p] + ': ' + t('l\'abbonamento scade il ', 'the subscription expires on ') + r.exp, al); }
			else r.warn = o.warn;
		}
		if (r.ok == null) { r.ok = o.ok; r.exp = r.exp || o.exp; r.err = 'net'; }
		out[p] = r;
	}
	wj(ACCF, out);
}
let cmd = ARGV[0] ?? '';

if (cmd == 'login') {
	let p = ARGV[1] ?? '', S = P[p];
	if (!S) { say('❌ ' + t('Servizio non valido', 'Invalid service')); exit(1); }
	say('🔐 ' + t('Controllo l\'accesso…', 'Checking access…'));
	let e = S.login(cfg());
	if (e) { say('❌ ' + e); exit(1); }
	acccheck();
	say('✅ ' + t('Accesso riuscito', 'Signed in'));
	exit(0);
}

if (cmd == 'acccheck') { acccheck(); exit(0); }

if (cmd == 'places') {
	let p = ARGV[1] ?? '', S = P[p];
	if (!S) exit(1);
	let L = S.places();
	if (length(L)) wj('/tmp/wf-vpnplaces-' + p + '.json', sort(L, (a, b) => a.name + a.city < b.name + b.city ? -1 : 1));
	exit(0);
}

if (cmd == 'rotate') {
	/* Pianificazioni › Cambia Server Del Servizio VPN: ogni collegamento automatico passa a un altro server del suo
	   paese (IP pubblico nuovo); uno alla volta con la stessa strada di «connect» */
	let C = cfg();
	for (let x in tuns(C)) {
		let pr = C[x.prof] ?? {};
		if (!x.on || !P[pr.prov] || !length(pr.place ?? '')) continue;
		reqrun({ tid: x.id, n: x.n, prov: pr.prov, place: pr.place, skip: pr.prov == 'pia' ? '' : (pr.host ?? '') });
	}
	exit(0);
}

if (cmd == 'connect') {
	let RF = match(ARGV[1] ?? '', REQRX) ? ARGV[1] : REQ, R = rd(RF) ?? {}, S = P[R.prov], C = cfg();
	/* fine: il file di richiesta proprio (non quello di rpcd) si toglie */
	let fin = (c) => { if (RF != REQ) unlink(RF); exit(c); };
	if (!S) { say('❌ ' + t('Richiesta non valida', 'Invalid request')); fin(1); }
	say('🌍 ' + t('Cerco i server…', 'Looking for servers…'));
	/* server esatto scelto dall'utente, oppure il migliore: più veloce (ping) o meno carico (dove il servizio lo dice) */
	let L = S.servers(C, R.place, R.skip ?? '', length(R.host ?? '') ? 20 : 8), s = null;
	if (length(R.host ?? '')) L = filter(L, (y) => y.host == R.host || y.ip == R.host);
	if (!length(L)) { say('❌ ' + t(length(R.host ?? '') ? 'Server non disponibile: scegline un altro' : 'Nessun server disponibile in questo paese', length(R.host ?? '') ? 'Server not available: choose another one' : 'No server available in this country')); fin(1); }
	let LD = filter(L, (y) => y.load != null);
	if ((C.vpnout ?? {}).pick == 'load' && length(LD) && length(L) > 1) { s = sort(LD, (a, b) => a.load - b.load)[0]; say('📉 ' + t('Server meno carico', 'Least loaded server') + ': ' + s.load + '%'); }
	else {
		if (length(L) > 1) say('⏱️ ' + t('Misuro la velocità di risposta di ' + length(L) + ' server…', 'Measuring the response time of ' + length(L) + ' servers…'));
		s = fastest(L);
	}
	let conf = S.conf(C, s);
	if (!conf) { say('❌ ' + t('Il server non ha accettato il collegamento: riprova', 'The server did not accept the connection: try again')); fin(1); }
	let r = call({ action: 'setprof', req: RF, conf: conf, cc: s.cc, city: s.city, sname: s.host, name: R.prov == 'pia' ? s.name : '', pname: R.pname ?? '', srvid: s.id != null ? '' + s.id : '' });
	if (!r || r.error) { say('❌ ' + (r ? r.error : t('configurazione non riuscita', 'configuration failed'))); fin(1); }
	say('✅ ' + s.name + (length(s.city) ? ' · ' + s.city : '') + (s.ms != null ? ' · ' + int(s.ms) + ' ms' : '') + (s.load != null ? ' · ' + t('carico', 'load') + ' ' + s.load + '%' : ''));
	/* cambi fatti dal router (carico, ping, server che non risponde, nuovo IP, orari): nelle Statistiche e negli Eventi */
	let why = { load: t('carico alto', 'high load'), ping: t('ping alto', 'high ping'), down: t('non rispondeva', 'not responding'), ip: t('nuovo IP', 'new IP'), sched: t('orario', 'schedule') }[R.why ?? ''];
	if (why) {
		let nm = s.name + (length(s.city) ? ' · ' + s.city : '');
		evrec('sw', nm + ' · ' + why);
		ev('vpnsvc_sw', '🔀 ' + t('Servizio VPN: nuovo server', 'VPN Service: new server') + ' · ' + nm + ' · ' + why, ob(C, 'al_sw', false));
	}
	fin(0);
}

if (cmd == 'srvlist') {
	let p = ARGV[1] ?? '', pl = ARGV[2] ?? '', S = P[p];
	if (!S || !match(pl, /^[A-Za-z0-9_-]{1,40}$/)) exit(1);
	let L = S.servers(cfg(), pl, '', 20);
	if (length(L)) wj('/tmp/wf-vpnsrv-' + p + '-' + pl + '.json', map(L, (y) => ({ host: y.host, name: y.name, city: y.city, cc: y.cc, load: y.load })));
	exit(0);
}

if (cmd == 'boot') {
	/* all'accensione: Collega All'Avvio spento = la casa resta sulla linea; acceso = collegata, nel paese scelto */
	let C = cfg(), m0 = filter(tuns(C), (x) => x.n == 0)[0], V = C.vpnout ?? {};
	if (!m0) exit(0);
	for (let i = 0; i < 60 && !length(trim(sh('ubus list wrtfreedom 2>/dev/null'))); i++) sh('sleep 2');
	if (V.boot == '0') { if (m0.on) call({ action: 'topts', tid: m0.id, on: false }); exit(0); }
	if (!m0.on) call({ action: 'topts', tid: m0.id, on: true });
	let pr = C[m0.prof] ?? {};
	if (match(V.bootpl ?? '', /^[A-Za-z0-9_-]{1,40}$/) && P[pr.prov] && V.bootpl != pr.place) {
		for (let i = 0; i < 45 && !match(sh('ping -c 1 -W 2 1.1.1.1 2>/dev/null'), /time=/); i++) sh('sleep 2');
		reqrun({ tid: m0.id, n: 0, prov: pr.prov, place: V.bootpl, pname: V.bootpn ?? '', skip: '' });
	}
	exit(0);
}

if (cmd == 'newdev') {
	/* Nuovi Dispositivi Protetti: con «solo alcuni dispositivi» chi si collega la prima volta entra nel principale */
	let C = cfg(), m0 = filter(tuns(C), (x) => x.n == 0)[0], s = m0 ? C[m0.id] : null, mac = lc(ARGV[1] ?? ''), ip = ARGV[2] ?? '';
	if (!s || s.mode != 'dev' || !ob(C, 'newdev', false) || !match(mac, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) || !match(ip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) exit(0);
	let D = arr(s.devs);
	if (length(filter(D, (d) => index(lc(d), mac) == 0))) exit(0);
	push(D, mac + '|' + ip + '|' + replace(substr(ARGV[3] ?? '', 0, 40), /[^A-Za-z0-9 ._-]/g, ''));
	call({ action: 'topts', tid: m0.id, devs: D });
	exit(0);
}

/* indirizzo del router dentro un collegamento */
function vaddr(I) { return trim(sh('ip -4 -o addr show dev ' + I + " 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n 1")); }

function ipcheck() {
	let out = {}, C = cfg();
	for (let x in tuns(C)) {
		let I = ifn(x.n), r = { t: time() };
		if (!x.on || !length(vaddr(I))) r.err = 'down';
		else if (!CURL) r.err = 'curl';
		else {
			/* l'API di NordVPN dice anche se l'indirizzo è di NordVPN («protetto»); poi ifconfig.co */
			let y = get(NORD + 'helpers/ips/insights', { via: I });
			if (y && y.ip) { r.ip = y.ip; r.cc = y.country_code ?? ''; r.country = y.country ?? ''; r.city = y.city ?? ''; r.org = y.isp ?? ''; r.prot = !!y.protected; }
			else {
				y = get('https://ifconfig.co/json', { via: I });
				if (y && y.ip) { r.ip = y.ip; r.cc = y.country_iso ?? ''; r.country = y.country ?? ''; r.city = y.city ?? ''; r.org = y.asn_org ?? ''; }
				else r.err = 'noanswer';
			}
		}
		out[x.id] = r;
	}
	wj(IPF, out);
	return out;
}
if (cmd == 'ipcheck') { ipcheck(); exit(0); }

if (cmd == 'leak') {
	/* perdite DNS: nomi a caso di bash.ws risolti come li risolvono i dispositivi del collegamento (AdGuard del router,
	   oppure il DNS del servizio), poi bash.ws dice quali server DNS li hanno chiesti e di chi sono */
	let C = cfg(), id = ARGV[1] ?? '', x = filter(tuns(C), (y) => y.id == id)[0];
	if (!x) { say('❌ ' + t('Collegamento non trovato', 'Connection not found')); exit(1); }
	let I = ifn(x.n), pr = C[x.prof] ?? {}, dm = (C.vpnout ?? {}).dns, vdns = dm == 'vpn' ? arr(pr.dns)[0] : dm == 'own' ? arr((C.vpnout ?? {}).dnsc)[0] : null;
	if (!length(vaddr(I))) { say('❌ ' + t('Il collegamento non è attivo', 'The connection is not active')); exit(1); }
	say('🧪 ' + t('Controllo in corso (circa 15 secondi)…', 'Checking (about 15 seconds)…'));
	let key = trim(get('https://bash.ws/id', { via: I, raw: true }));
	if (!match(key, /^[a-z0-9]{8,40}$/)) { say('❌ ' + t('Il servizio di controllo non risponde: riprova più tardi', 'The test service is not responding: try again later')); exit(1); }
	let srv = vdns ?? '127.0.0.1', c = '';
	for (let i = 1; i <= 10; i++) c += '( nslookup ' + i + '.' + key + '.bash.ws ' + srv + ' >/dev/null 2>&1 ) & ';
	sh(c + 'wait; sleep 2');
	let R = arr(get('https://bash.ws/dnsleak/test/' + key + '?json', { via: I })), line = get(NORD + 'helpers/ips/insights') ?? {};
	let dns = filter(R, (y) => y.type == 'dns'), mine = filter(R, (y) => y.type == 'ip')[0] ?? {}, isp = lc(line.isp ?? '');
	let leak = length(isp) && length(filter(dns, (y) => index(lc(y.asn ?? ''), split(isp, ' ')[0]) >= 0)) > 0;
	let res = { t: time(), tid: id, ok: length(dns) > 0 && !leak, leak: leak, ip: mine.ip ?? '', dns: map(dns, (y) => ({ ip: y.ip, country: y.country_name ?? '', asn: y.asn ?? '' })), line: line.isp ?? '' };
	wj(LEAKF, res);
	if (!length(dns)) say('⚠️ ' + t('Nessuna risposta DNS letta: riprova', 'No DNS answer seen: try again'));
	else {
		for (let y in dns) say('• ' + y.ip + ' · ' + (y.country_name ?? '') + ' · ' + (y.asn ?? ''));
		say(leak ? '⚠️ ' + t('Perdita: il DNS dell\'operatore (' + line.isp + ') vede i siti che visiti', 'Leak: your provider\'s DNS (' + line.isp + ') sees the sites you visit')
			: '✅ ' + t('Nessuna perdita: il tuo operatore non vede i nomi dei siti', 'No leak: your provider does not see the site names'));
	}
	exit(0);
}

/* server DNS usati dal router (AdGuard Home, altrimenti dnsmasq): con «DNS del router» passano dal principale */
function dnsips() {
	let H = [], add = (h) => { h = trim('' + h); if (length(h) && index(H, h) < 0) push(H, h); };
	for (let y in [ug('adguardhome.config.config'), '/etc/adguardhome/adguardhome.yaml', '/etc/adguardhome.yaml', '/opt/AdGuardHome/AdGuardHome.yaml']) {
		if (!length(y) || !stat(y)) continue;
		let sec = false;
		for (let l in split(readfile(y) ?? '', '\n')) {
			if (match(l, /^ *(upstream_dns|bootstrap_dns|fallback_dns):/)) { sec = true; continue; }
			if (sec && !match(l, /^ *- /)) { sec = false; continue; }
			if (!sec) continue;
			let v = replace(replace(trim(substr(trim(l), 2)), /^["']|["']$/g, ''), /^\[\/[^]]*\/\]/, '');
			let m = match(v, /^[a-z0-9]+:\/\/\[?([^]\/:]+)/) ?? match(v, /^([0-9.]+)(:[0-9]+)?$/);
			if (m) add(m[1]);
		}
		break;
	}
	/* senza AdGuard: i server scelti in dnsmasq (non quelli dell'operatore, che spesso rispondono solo ai suoi clienti) */
	if (!length(H)) for (let x in split(trim(sh('uci -q get dhcp.@dnsmasq[0].server')), ' ')) { let m = match(x, /^([0-9]{1,3}(\.[0-9]{1,3}){3})(#[0-9]+)?$/); if (m) add(m[1]); }
	let ips = [], pub = (ip) => !match(ip, /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.)/);
	for (let h in H) {
		let L = match(h, /^[0-9.]+$/) ? [h] : map(filter(split(sh('nslookup ' + q(h) + ' 127.0.0.1 2>/dev/null'), '\n'), (l) => match(l, /^Address[ 0-9:]*: *[0-9.]+$/)), (l) => trim(split(l, ':')[1]));
		for (let ip in L) if (match(ip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) && pub(ip) && index(ips, ip) < 0) push(ips, ip);
	}
	return slice(ips, 0, 16);
}

if (cmd == 'tick') {
	/* un giro alla volta (notify.sh lo lancia ogni 30 s in sottofondo): un altro esce subito; blocco vecchio di 5 minuti
	   (giro interrotto) tolto */
	const LK = '/tmp/wf-vpntick.lock';
	if (!mkdir(LK)) { let ls = stat(LK); if (ls && time() - ls.mtime < 300) exit(0); rmdir(LK); if (!mkdir(LK)) exit(0); }
	let now = time(), C = cfg(), V = C.vpnout ?? {}, S = rd(STF) ?? {}, kill = ob(C, 'kill', true), auto = ob(C, 'auto', true), T = tuns(C), ipnow = false;
	let lt = localtime(now), day = today(), hm = sprintf('%02d:%02d', lt.hour, lt.min), dow = '' + (lt.wday == 0 ? 7 : lt.wday), swd = false;	/* dow 1 = lunedì … 7 = domenica */
	let WAIT = +(V.wait ?? 0) || 120;
	/* cambio di server in sottofondo (uno per giro) */
	let sw = (x, pr, why, place, pname) => {
		swd = true;
		reqrun({ tid: x.id, n: x.n, prov: pr.prov, place: place ?? pr.place, pname: pname ?? '', skip: pr.prov == 'pia' || place ? '' : (pr.host ?? ''), why: why }, true);
	};
	/* stato di WireGuard: handshake, byte, indirizzo IP del server (ep, dall'endpoint «ip:porta») */
	let wg = {};
	for (let l in split(trim(sh('wg show all dump 2>/dev/null')), '\n')) { let f = split(l, '\t'); if (length(f) >= 8) wg[f[0]] = { hs: +f[5], rx: +f[6], tx: +f[7], ep: match(f[3], /^([0-9]{1,3}(\.[0-9]{1,3}){3}):[0-9]+$/)?.[1] }; }
	/* senza keepalive un collegamento fermo ha l'handshake vecchio: un ping attraverso il collegamento (DNS del server o
	   1.1.1.1) lo rinnova se il server risponde; vivo solo con l'handshake di nuovo recente */
	let fresh = (I, w, pr) => {
		if (w.hs > 0 && now - w.hs < 180) return true;
		let ip = filter(arr(pr.dns), (y) => match(y, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/))[0] ?? '1.1.1.1';
		sh('ping -c 1 -W 2 -I ' + q(I) + ' ' + q(ip) + ' >/dev/null 2>&1');
		let hs = 0;
		for (let l in split(trim(sh('wg show ' + q(I) + ' latest-handshakes 2>/dev/null')), '\n')) { let f = split(trim(l), '\t'); if (+f[1] > hs) hs = +f[1]; }
		w.hs = hs || w.hs;
		return hs > 0 && time() - hs < 180;
	};
	/* dati usati per giorno (ultimi 62 giorni), salvati in /etc ogni 30 minuti; disponibilità del principale [collegato, acceso] in secondi */
	let U = rd(USEF) ?? rd(USEP) ?? { t: {} }, dt = now - (S._at ?? now);
	U.av = U.av ?? {};
	for (let x in T) {
		let I = ifn(x.n), w = wg[I], s = S[x.id] ?? {}, pr = C[x.prof] ?? {}, name = (pr.city || pr.name || pr.host || 'VPN') + (pr.cc ? ' (' + pr.cc + ')' : '');
		let alive = w && (x.on ? fresh(I, w, pr) : w.hs > 0 && now - w.hs < 180);
		if (w) {
			let u = U.t[x.id] ?? { d: {} }, l = u.l ?? [0, 0], drx = w.rx >= l[0] ? w.rx - l[0] : w.rx, dtx = w.tx >= l[1] ? w.tx - l[1] : w.tx, d = u.d[day] ?? [0, 0];
			u.d[day] = [d[0] + drx, d[1] + dtx]; u.l = [w.rx, w.tx];
			let ks = sort(keys(u.d)); while (length(ks) > 62) delete u.d[shift(ks)];
			U.t[x.id] = u;
		}
		if (x.n == 0 && x.on && dt > 0 && dt <= 120) { let a = U.av[day] ?? [0, 0]; U.av[day] = [a[0] + (alive ? dt : 0), a[1] + dt]; }
		if (!x.on || !w) { delete S[x.id]; continue; }
		/* tempo di risposta del server (ping verso l'indirizzo del server, dalla linea) e da quando è collegato */
		if (alive) {
			s.since = s.since || now;
			let pm = match(sh('ping -c 1 -W 1 ' + q(w.ep ?? pr.host ?? '') + ' 2>/dev/null'), /time=([0-9.]+)/);
			s.ping = pm ? int(+pm[1] + 0.5) : null;
			if (pr.prov == 'nord' && match(pr.srvid ?? '', /^[0-9]+$/) && now - (s.lt ?? 0) >= 600) {
				s.lt = now;
				let L = get(NORD + 'servers?filters%5Bservers.id%5D=' + pr.srvid + '&limit=1');
				if (type(L) == 'array' && L[0] && '' + L[0].id == pr.srvid) s.load = L[0].load;
			}
			/* cambio automatico: server troppo carico (NordVPN) o ping alto per 5 minuti; al massimo ogni 15 minuti */
			let can = P[pr.prov] && length(pr.place ?? '') && now - (s.sw ?? 0) >= 900;
			if (ob(C, 'swping', false) && s.ping != null && s.ping > (+V.pingmax || 150)) s.hp = s.hp || now; else s.hp = 0;
			let hl = ob(C, 'swload', false) && s.load != null && s.load > (+V.loadmax || 70), hp = s.hp && now - s.hp >= 300;
			if (can && !swd && (hl || hp)) { s.sw = now; s.hp = 0; s.load = null; s.lt = 0; sw(x, pr, hl ? 'load' : 'ping'); }
		}
		else s.since = 0;
		if (alive) {
			if (x.fb) call({ action: 'fallback', tid: x.id, on: false });
			if (s.down) {
				let mins = int((now - (s.bad || now)) / 60);
				ev('vpnsvc_up', '🔐 ' + t('Servizio VPN di nuovo collegato', 'VPN Service connected again') + ' · ' + name, ob(C, 'al_up', true));
				evrec('up', name + (mins > 0 ? ' · ' + mins + ' min' : ''));
				s.ipt = 0;
			}
			s.down = false; s.bad = 0; s.rt = 0;
			if (now - (s.ipt ?? 0) >= 900) { s.ipt = now; ipnow = true; }
		}
		else {
			s.bad = s.bad || now;
			/* nessuna risposta dal server per il tempo scelto (Attesa Prima Del Cambio; dopo l'accensione si aspetta il primo contatto) */
			if (!s.down && now - s.bad >= WAIT) {
				s.down = true;
				ev('vpnsvc_down', '🔓 ' + t('Servizio VPN non risponde', 'VPN Service not responding') + ' · ' + name + (kill ? ' · ' + t('dispositivi bloccati finché non torna', 'devices blocked until it is back') : ''), ob(C, 'al_down', true));
				evrec('down', name);
			}
			if (s.down && !kill && !x.fb) {
				call({ action: 'fallback', tid: x.id, on: true });
				ev('vpnsvc_fb', '⚠️ ' + t('Dispositivi sulla linea senza VPN finché il server non torna', 'Devices on the line without VPN until the server is back') + ' · ' + name, ob(C, 'al_fb', true));
			}
			if (s.down && auto) {
				let p = pr.prov ?? '';
				if (!s.rt) { s.rt = now; sh('ifup ' + I + ' >/dev/null 2>&1'); }	/* primo tentativo: ricollega */
				else if (P[p] && length(pr.place ?? '') && !swd && now - s.rt >= WAIT && now - (s.sw ?? 0) >= 600) {
					/* servizi automatici: un altro server dello stesso paese (PIA: anche lo stesso, la chiave va registrata di nuovo) */
					s.sw = now; s.rt = now;
					sw(x, pr, 'down');
				}
			}
		}
		S[x.id] = s;
	}
	S._at = now;
	/* collegamenti tolti: niente stato; i loro dati restano nelle Statistiche in «_gone» (ultimi 62 giorni) */
	let ids = {}; for (let x in T) ids[x.id] = 1;
	for (let k in keys(S)) if (substr(k, 0, 1) != '_' && !ids[k]) delete S[k]; else if (substr(k, 0, 2) == '_s' && !C[substr(k, 2)]) delete S[k];
	for (let k in keys(U.t)) if (k != '_gone' && !ids[k]) {
		let g = U.t._gone ?? { d: {} };
		for (let dd, v in (U.t[k].d ?? {})) { let o = g.d[dd] ?? [0, 0]; g.d[dd] = [o[0] + (v[0] ?? 0), o[1] + (v[1] ?? 0)]; }
		let gs = sort(keys(g.d)); while (length(gs) > 62) delete g.d[shift(gs)];
		U.t._gone = g; delete U.t[k];
	}
	let ak = sort(keys(U.av)); while (length(ak) > 62) delete U.av[shift(ak)];
	wj(USEF, U);
	if (now - (+(readfile('/tmp/wf-vpnuse.saved') ?? 0)) >= 1800) { wj(USEP, U); writefile('/tmp/wf-vpnuse.saved', '' + now); }
	/* orari (Automazioni): nei giorni scelti, a «from» scollega o passa al paese, a «to» torna come prima */
	let m0 = filter(T, (x) => x.n == 0)[0], p0 = m0 ? (C[m0.prof] ?? {}) : {};
	if (m0) for (let k, s in C) {
		if (s['.type'] != 'vpnsched' || s.on == '0' || index('' + (s.days ?? ''), dow) < 0) continue;
		let st = hm == s.from ? 'a' : hm == s.to ? 'b' : null;
		if (!st || S['_s' + k] == st + day) continue;
		S['_s' + k] = st + day;
		if (s.act == 'place') {
			let qa = C['va_' + s.prov] ?? {};
			if (P[s.prov] && !swd) sw(m0, { prov: s.prov, place: '', host: '' }, 'sched', st == 'a' ? s.place : (length(qa.qplace ?? '') ? qa.qplace : 'auto'), st == 'a' ? s.pname : (qa.qname ?? ''));
		}
		else call({ action: 'topts', tid: m0.id, on: st == 'b' });
	}
	/* nuovo IP ogni giorno all'ora scelta: un altro server dello stesso paese */
	if (m0 && m0.on && ob(C, 'ipday', false) && hm == (V.ipat || '04:00') && S._ipd != day && P[p0.prov] && length(p0.place ?? '') && !swd) { S._ipd = day; sw(m0, p0, 'ip'); }
	if (ipnow) ipcheck();
	/* accessi dei servizi: una volta al giorno */
	if (now - (S._acct ?? 0) >= 86400) { S._acct = now; acccheck(); }
	/* DNS del router attraverso il principale: indirizzi dei server ogni 10 minuti, solo se la casa ci passa (principale
	   acceso, non in fallback, non «solo alcuni dispositivi»): altrimenti le regole non servono */
	if ((!V.dns || V.dns == 'adg') && m0 && m0.on && !m0.fb && m0.mode != 'dev' && now - (S._dnst ?? 0) >= 600) { S._dnst = now; call({ action: 'dnsips', ips: dnsips() }); }
	wj(STF, S);
	rmdir(LK);
	exit(0);
}

if (cmd == 'save') { let U = rd(USEF); if (U) wj(USEP, U); exit(0); }

warn('uso: ucode vpnctl.uc login|places <servizio> | connect | ipcheck | leak <collegamento> | srvlist <servizio> <paese> | boot | newdev <mac> <ip> <nome> | tick | save\n');
exit(1);
