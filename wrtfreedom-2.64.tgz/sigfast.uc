'use strict';
/* WrtFreedom: lettura veloce del segnale per «Trova Il Punto Migliore» (pacchetto 2.47). La avvia il metodo sigfast
   {on: true}; una lettura ogni 1–2 secondi per al massimo 5 minuti dall'avvio, e si ferma prima se l'app non la chiede più
   da 15 s (/tmp/wf-sigfast.want = secondi dall'accensione dell'ultima richiesta, come sqmlive.sh) o con {on: false}.
   Strada: modem con i comandi della marca e il segnale per antenna (Quectel: servingcell + AT+QRSRP), altrimenti
   ModemManager (--signal-get con aggiornamento ogni 2 s, rimesso a 10 s alla fine), altrimenti i comandi della marca.
   Risultato in /tmp/wf-sigfast.json: {on, t, start, end, via, tech, lte {rsrp, rsrq, sinr, pci, band}, nr {…},
   ant {lte: [4], nr: [4]} (null = antenna non usata; manca se la marca non lo permette), best {lte, nr: {rsrp, sinr, t}},
   h: [[t, rsrp 4G, sinr 4G, rsrp 5G, sinr 5G]] ultimi 5 minuti} */
import { readfile, writefile, popen, stat, unlink, rename, mkdir, rmdir } from 'fs';

const W = '/usr/share/wrtfreedom', P = '/tmp/wf-sigfast', AT = W + '/at.sh', MAXT = 300, IDLE = 15;
const M = loadfile(getenv('WF_MODEMUC') ?? W + '/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function up() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
function num(x) { if (x == null || x === '' || x === '--') return null; let n = +x; return n != n ? null : n; }
/* comando AT senza il registro dei comandi del Rapporto Modem (sarebbero centinaia) */
function at(c) { return sh('sh ' + AT + ' ' + q(c) + ' 2>/dev/null'); }
function cell(c) { return c ? { rsrp: num(c.rsrp), rsrq: num(c.rsrq), sinr: num(c.sinr), pci: c.pci ?? '', band: c.band ?? '' } : null; }

/* un processo solo: blocco con mkdir; si prende quello rimasto solo se il suo processo (pid nel file, riconosciuto dalla
   riga di comando) non c'è più. /proc/self letto da ucode = questo processo */
let me = split(trim(readfile('/proc/self/stat') ?? ''), ' ')[0];
if (!mkdir(P + '.lock')) {
	let op = trim(readfile(P + '.pid') ?? '');
	if (length(op) && index(readfile('/proc/' + op + '/cmdline') ?? '', 'sigfast') >= 0) exit(0);
	rmdir(P + '.lock');
	if (!mkdir(P + '.lock')) exit(0);
}
writefile(P + '.pid', me);
function bye(c) { unlink(P + '.pid'); rmdir(P + '.lock'); exit(c); }

let I = M.id(), D = M.drv(I), via = '';
if (D && D.ant && length(D.read ?? [])) via = 'at';
else if (I.mm) via = 'mm';
else if (D && length(D.read ?? [])) via = 'at';
let u0 = up(), t0 = time();
let S = { on: true, t: t0, start: t0, end: t0 + MAXT, via: via, tech: '', lte: null, nr: null, h: [], best: {} };
if (!length(via)) { S.on = false; S.err = 'modem non disponibile'; writefile(P + '.json', sprintf('%J', S)); bye(0); }
if (via == 'mm') sh('mmcli -m any --signal-setup=2 >/dev/null 2>&1');

while (true) {
	let u = up(), w = +(trim(readfile(P + '.want') ?? '0'));
	if (u - w > IDLE || u - u0 >= MAXT) break;
	let n = { at: [] };
	if (via == 'at') {
		n = D.parse(at(D.read[0])) ?? { nb: [] };
		if (D.ant) S.ant = D.antparse(at(D.ant));
	} else {
		let sg = null; try { sg = json(sh('mmcli -m any --signal-get -J 2>/dev/null'))?.modem?.signal; } catch (e) {}
		if (sg?.lte && num(sg.lte.rsrp) != null) n.lte = { rsrp: sg.lte.rsrp, rsrq: sg.lte.rsrq, sinr: sg.lte.snr };
		if (sg?.['5g'] && num(sg['5g'].rsrp) != null) n.nr = { rsrp: sg['5g'].rsrp, rsrq: sg['5g'].rsrq, sinr: sg['5g'].snr };
	}
	let now = time();
	S.t = now; S.tech = M.tech(n); S.lte = cell(n.lte); S.nr = cell(n.nr);
	for (let k in [ 'lte', 'nr' ]) {
		let c = S[k], b = S.best[k];
		if (c?.rsrp != null && (!b || c.rsrp > b.rsrp || (c.rsrp == b.rsrp && (c.sinr ?? -99) > (b.sinr ?? -99)))) S.best[k] = { rsrp: c.rsrp, sinr: c.sinr, t: now };
	}
	push(S.h, [ now, S.lte?.rsrp, S.lte?.sinr, S.nr?.rsrp, S.nr?.sinr ]);
	if (length(S.h) > 300) S.h = slice(S.h, length(S.h) - 300);
	writefile(P + '.json.t', sprintf('%J', S)); rename(P + '.json.t', P + '.json');
	sh('sleep 1');
}
S.on = false; S.t = time();
writefile(P + '.json.t', sprintf('%J', S)); rename(P + '.json.t', P + '.json');
/* ModemManager: aggiornamento del segnale come lo vuole la lettura normale (readcmd) */
if (via == 'mm') sh('mmcli -m any --signal-setup=10 >/dev/null 2>&1');
bye(0);
