'use strict';
/* WrtFreedom: VPN Per Fuori Casa in sottofondo (pacchetto 2.52). I metodi di rpcd leggono solo i file di stato.
   uso: ucode wgx.uc tick     ogni 30 s da notify.sh (solo con una WireGuard con la porta in ascolto): ultimo contatto di
                              ogni dispositivo (eventi cron_wgpeer_on/off per chi ha l'Avviso acceso), byte per dispositivo
                              e per giorno (/tmp/wf-wguse.json, copia in /etc/wrtfreedom/wguse.json ogni 6 ore, prima se
                              i byte nuovi superano SAVEB, e allo spegnimento; 60 giorni), Prova Da Fuori Casa armata
                              (contatto arrivato: decide wgprobe, che controlla anche che venga da fuori casa)
        ucode wgx.uc probe    parte lenta della Prova Da Fuori Casa: IP pubblico e nome DDNS risolto da un DNS pubblico
                              (/tmp/wf-wgprobe.chk.json)
        ucode wgx.uc exp      Dispositivi Con Scadenza (cron.sh wgexp ogni 5 minuti): scaduti tolti con wgpeer del, evento
                              cron_wgpeer_exp
        ucode wgx.uc save     copia subito in /etc/wrtfreedom (spegnimento del servizio) */
import { readfile, writefile, popen, rename, mkdir } from 'fs';

const W = '/usr/share/wrtfreedom', TMP = '/tmp/wf-wguse.json', ETC = '/etc/wrtfreedom/wguse.json', ST = '/tmp/wf-wgx.json';
const PRB = '/tmp/wf-wgprobe.json', PRBC = '/tmp/wf-wgprobe.chk.json', KEEP = 60, ON = 180, SAVET = 21600, SAVEB = 536870912;

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rj(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function day(t) { let n = localtime(t); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
function arr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }
/* /etc/config/<nome> letto dal file: stesso lettore di ucfile in wrtfreedom.uc (uval, uopen; sezioni con .type, liste
   come array, anonime @tipo[n], valori su più righe, WF_CFGDIR per le prove) */
function uval(v) {
	v = trim(v ?? '');
	let c = substr(v, 0, 1), o = '', i = 1, n = length(v);
	if (c == "'") {
		while (i < n) {
			let ch = substr(v, i, 1);
			if (ch == "'") { if (substr(v, i, 4) == "'\\''") { o += "'"; i += 4; continue; } break; }
			o += ch; i++;
		}
		return o;
	}
	if (c == '"') {
		while (i < n) {
			let ch = substr(v, i, 1);
			if (ch == '\\') { o += substr(v, i + 1, 1); i += 2; continue; }
			if (ch == '"') break;
			o += ch; i++;
		}
		return o;
	}
	return split(v, /[ \t]+/)[0] ?? '';
}
function uopen(l) {
	if (index(l, "'") < 0 && index(l, '"') < 0) return false;
	let sq = false, dq = false;
	for (let i = 0; i < length(l); i++) {
		let ch = substr(l, i, 1);
		if (sq) { if (ch == "'") sq = false; }
		else if (dq) { if (ch == '\\') i++; else if (ch == '"') dq = false; }
		else if (ch == '\\') i++;
		else if (ch == "'") sq = true;
		else if (ch == '"') dq = true;
		else if (ch == '#') break;
	}
	return sq || dq;
}
function ucfile(name) {
	let r = {}, cur = null, cnt = {}, buf = null;
	for (let l in split(readfile((getenv('WF_CFGDIR') ?? '/etc/config/') + name) ?? '', '\n')) {
		if (buf != null) { l = buf + '\n' + l; buf = null; }
		if (uopen(l)) { buf = l; continue; }
		let m = match(l, /^[ \t]*(config|option|list)[ \t]+([^ \t]+)/);
		if (!m) continue;
		let rest = trim(substr(l, length(m[0])));
		if (m[1] == 'config') {
			let t = uval(m[2]), n = length(rest) ? uval(rest) : '';
			cnt[t] = (cnt[t] ?? -1) + 1;
			if (!length(n)) n = '@' + t + '[' + cnt[t] + ']';
			cur = r[n] = r[n] ?? { '.type': t };
		}
		else if (cur) {
			let k = uval(m[2]), v = uval(rest);
			if (m[1] == 'list') { if (type(cur[k]) != 'array') cur[k] = []; push(cur[k], v); }
			else cur[k] = v;
		}
	}
	return r;
}
const WC = ucfile('wrtfreedom');
const EN = (WC.ui?.lang ?? '') == 'en';
function t(it, en) { return EN ? en : it; }
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' net ' + q(txt) + ' >/dev/null 2>&1 </dev/null &'); }
/* WireGuard di casa: quella con la porta in ascolto, mai il Servizio VPN (wgout, wgo1…): uguale a wgiface di wrtfreedom.uc */
function wgiface(N) {
	let L = filter(keys(N), (k) => N[k]['.type'] == 'interface' && N[k].proto == 'wireguard' && !match(k, /^wgo(ut|[0-9]+)$/));
	for (let i in L) if (length(N[i].listen_port ?? '')) return i;
	return L[0];
}
/* dispositivi: chiave pubblica → { id, name, al (avviso acceso) } */
function peers(N, ifc) {
	let P = {};
	for (let k in N) if (N[k]['.type'] == 'wireguard_' + ifc && length(N[k].public_key ?? ''))
		P[N[k].public_key] = { id: k, name: N[k].description ?? k, al: (WC['peer_' + k] ?? {}).alert == '1' };
	return P;
}
/* righe dei dispositivi di «wg show <if> dump» (la prima riga è l'interfaccia) */
function dump(ifc) {
	let r = [], L = split(trim(sh('wg show ' + q(ifc) + ' dump 2>/dev/null')), '\n');
	for (let i = 1; i < length(L); i++) {
		let f = split(L[i], '\t');
		if (length(f) >= 7) push(r, { pub: f[0], ep: f[2], hs: +f[4], rx: +f[5], tx: +f[6] });
	}
	return r;
}
/* copia in memoria interna (scritture rade: dal giro ogni 6 ore o dopo 512 MB nuovi, sempre allo spegnimento) */
function save(U) {
	U = U ?? rj(TMP);
	if (!U) return;
	U.st = time(); U.ch = 0; U.cb = 0;
	mkdir('/etc/wrtfreedom');
	wj(ETC, U); wj(TMP, U);
}
function tick() {
	let N = ucfile('network'), ifc = wgiface(N);
	if (!ifc) return;
	let now = time(), d = day(now), P = peers(N, ifc), S = rj(ST) ?? {}, U = rj(TMP) ?? rj(ETC) ?? {}, seen = {};
	S.p = S.p ?? {}; U.d = U.d ?? {};
	for (let x in dump(ifc)) {
		let p = P[x.pub];
		if (!p) continue;	/* dispositivo senza sezione in network: niente nome, non si conta */
		seen[p.id] = true;
		let o = S.p[p.id] ?? {}, on = x.hs > 0 && now - x.hs < ON;
		/* byte: differenza dalla lettura di prima (contatori più bassi = interfaccia ripartita: si conta da zero) */
		if (o.rx != null) {
			let dr = x.rx >= o.rx ? x.rx - o.rx : x.rx, dt = x.tx >= o.tx ? x.tx - o.tx : x.tx;
			if (dr || dt) { let g = U.d[d] = U.d[d] ?? {}, v = g[p.id] ?? [0, 0]; g[p.id] = [v[0] + dr, v[1] + dt]; U.ch = 1; U.cb = (U.cb ?? 0) + dr + dt; }
		}
		if (o.on != null && on != o.on && p.al) {
			let ip = match(x.ep, /^[0-9.]+:[0-9]+$/) ? ' · ' + replace(x.ep, /:[0-9]+$/, '') : '';
			if (on) ev('wgpeer_on', '📲 ' + p.name + ' ' + t('si è collegato alla VPN Per Fuori Casa', 'connected to the Away From Home VPN') + ip);
			else ev('wgpeer_off', '📴 ' + p.name + ' ' + t('si è scollegato dalla VPN Per Fuori Casa', 'disconnected from the Away From Home VPN'));
		}
		S.p[p.id] = { rx: x.rx, tx: x.tx, hs: x.hs, on: on };
	}
	for (let k in keys(S.p)) if (!seen[k]) delete S.p[k];
	let ks = sort(keys(U.d));
	while (length(ks) > KEEP) delete U.d[shift(ks)];
	wj(ST, S);
	if (U.ch && (now - (U.st ?? 0) >= SAVET || (U.cb ?? 0) >= SAVEB)) save(U);
	else wj(TMP, U);
	/* Prova Da Fuori Casa: contatto arrivato dopo l'inizio = lo decide wgprobe get (stesso controllo «fuori casa»:
	   indirizzo fuori dalla rete di casa e dalla rete della VPN), che segna ok nel file anche se l'app non guarda */
	let R = rj(PRB);
	if (R && R.id && !R.ok && now < (R.until ?? 0)) {
		let x = S.p[R.id];
		if (x && x.hs >= (R.t ?? 0)) sh('ubus -t 5 call wrtfreedom wgprobe ' + q('{"action":"get"}') + ' >/dev/null 2>&1');
	}
}
function probe() {
	let R = rj(PRB);
	if (!R) return;
	let C = { run: false, t: time() };
	/* IP pubblico visto da internet */
	let pub = trim(sh('(curl -s -m 8 https://api.ipify.org || uclient-fetch -q -T 8 -O - https://api.ipify.org) 2>/dev/null'));
	C.pub = match(pub, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) ? pub : '';
	/* nome DDNS: indirizzi dati da un DNS pubblico (quello di casa può rispondere con l'IP del router) */
	let host = '' + (R.host ?? '');
	if (length(host) && match(host, /[A-Za-z]/) && match(host, /^[A-Za-z0-9.-]{1,253}$/)) {
		let ips = [], after = false;
		for (let l in split(sh('nslookup ' + q(host) + ' 1.1.1.1 2>/dev/null'), '\n')) {
			if (match(l, /^Name:/)) after = true;
			else if (after) { let m = match(l, /^Address( [0-9]+)?:[ \t]*([0-9]{1,3}(\.[0-9]{1,3}){3})[ \t]*$/); if (m) push(ips, m[2]); }
		}
		C.ddns = { host: host, ips: ips, ok: length(C.pub) && length(ips) ? index(ips, C.pub) >= 0 : null };
	}
	wj(PRBC, C);
}
/* scaduti: tolti con lo stesso metodo dell'app (wg, network, impostazioni, orari, riga del crontab) */
function expire() {
	let N = ucfile('network'), ifc = wgiface(N), now = time();
	if (!ifc) return;
	for (let k in N) {
		if (N[k]['.type'] != 'wireguard_' + ifc) continue;
		let e = +((WC['peer_' + k] ?? {}).exp ?? 0);
		if (e <= 0 || e > now) continue;
		sh('ubus call wrtfreedom wgpeer ' + q(sprintf('%J', { action: 'del', id: k })) + ' >/dev/null 2>&1');
		ev('wgpeer_exp', '⌛ ' + (N[k].description ?? k) + ': ' + t('accesso alla VPN Per Fuori Casa scaduto, dispositivo tolto', 'Away From Home VPN access expired, device removed'));
	}
}

let cmd = ARGV[0] ?? '';
if (cmd == 'tick') tick();
else if (cmd == 'probe') probe();
else if (cmd == 'exp') expire();
else if (cmd == 'save') save(null);
else { print('uso: wgx.uc tick|probe|exp|save\n'); exit(1); }
