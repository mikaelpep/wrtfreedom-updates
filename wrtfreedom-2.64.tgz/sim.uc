'use strict';
/* WrtFreedom: seconda SIM e PIN (pacchetto 2.47), fuori da rpcd perché il modem si riavvia quando cambia slot (30–60 s).
   uso: ucode sim.uc read             legge slot e SIM e li scrive in /tmp/wf-sim.json
        ucode sim.uc set <n> [motivo]  passa allo slot n (motivo: manual, noline, quota, back, renew)
        ucode sim.uc auto             cambio automatico (lo lancia line.sh una volta al minuto con wrtfreedom.sim.auto=1)
        ucode sim.uc pin get|enable|disable|change [file]   PIN della SIM; il file (tolto subito) contiene
                                      «pin» oppure «pin nuovo»: il PIN non passa mai sulla riga di comando né nei registri
   Strada: ModemManager (slot da modem.generic.sim-slots, cambio con --set-primary-sim-slot; PIN con mmcli -i <sim>),
   altrimenti per Quectel i comandi AT (AT+QUIMSLOT? / =? / =n) e per il PIN i comandi standard (AT+CLCK, AT+CPWD).
   Numero di slot letto dal modem, mai fisso.
   Cambio automatico (wrtfreedom.sim): auto 0/1; after = minuti senza internet prima di cambiare (5); onquota 0/1 = cambia
   quando i giga dell'offerta sono finiti; back = ritorno alla SIM principale (main, di serie 1): 0 mai, 1 dopo backwait
   minuti (360) se si era cambiato per linea assente, al rinnovo se per giga finiti, «renew» solo al rinnovo del periodo;
   il ritorno si prova: se in 3 minuti internet non torna si rimette la SIM di riserva. minwait = minuti minimi tra due
   tentativi (30), riusciti o no. Mai nei primi 15 minuti dall'accensione e solo verso uno slot con la SIM presente.
   Profilo dati per slot: apn1, apn2 (nell'interfaccia del modem prima di riconnettere; vuoto = quello di prima).
   Ultimo tentativo in /etc/wrtfreedom/sim.last (una scrittura per cambio); eventi «cron_sim» e «cron_simerr».
   /tmp/wf-sim.json: {t, via, slots, active, sims: [{slot, present, iccid (ultime 4 cifre), op}], err}
   /tmp/wf-simpin.json: {t, via, enabled, retries, puk, state, last: {act, ok, err, t}} */
import { readfile, writefile, popen, stat, mkdir, rmdir, unlink } from 'fs';

const W = '/usr/share/wrtfreedom', OUT = '/tmp/wf-sim.json', LAST = '/etc/wrtfreedom/sim.last', LOCK = '/tmp/wf-sim.lock',
	PINF = '/tmp/wf-simpin.json', AT = W + '/at.sh';
const M = loadfile(getenv('WF_MODEMUC') ?? W + '/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function js(c) { try { return json(sh(c)); } catch (e) { return null; } }
function load(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
/* opzione di una sezione con nome di /etc/config/wrtfreedom letta dal file, senza processi */
function uo(sec, opt) {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
		let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m && m[1] == opt) return m[2];
	}
	return '';
}
const EN = uo('ui', 'lang') == 'en';
function t(it, en) { return EN ? en : it; }
function ev(k, txt) { sh('sh ' + W + '/event.sh cron ' + k + ' net ' + q(txt) + ' >/dev/null 2>&1'); }
function uptime() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
/* blocco: un lavoro alla volta (un cambio con la prova del ritorno può durare 6 minuti); uno rimasto da 10 minuti si toglie */
function lock(wait) {
	for (let i = 0; i <= wait; i++) {
		if (mkdir(LOCK)) return true;
		let s = stat(LOCK);
		if (s && time() - s.mtime > 600) { rmdir(LOCK); continue; }
		if (i < wait) sh('sleep 1');
	}
	return false;
}
function tail4(x) { x = '' + (x ?? ''); return length(x) > 4 ? '…' + substr(x, -4) : x; }
/* comando AT senza registro dei comandi (serve per quelli con il PIN) */
function atq(c) { return sh('sh ' + AT + ' ' + q(c) + ' 2>/dev/null'); }

/* ---------------- lettura ---------------- */
function mmread() {
	let g = js('mmcli -m any -J 2>/dev/null')?.modem?.generic;
	if (!g) return null;
	/* slot: percorsi delle SIM ("/" o "--" = vuoto); ModemManager < 1.16 non li ha → un solo slot */
	let L = g['sim-slots'] ?? [], prim = '' + (g.sim ?? ''), act = +(g['primary-sim-slot'] ?? 0), sims = [];
	if (type(L) != 'array' || !length(L)) return { via: 'mm', slots: 1, active: 1, sims: [ { slot: 1, present: match(prim, /SIM\/[0-9]+/) != null } ] };
	for (let i = 0; i < length(L); i++) {
		let p = match('' + L[i], /\/org\/freedesktop\/ModemManager1\/SIM\/[0-9]+/)?.[0];
		let s = { slot: i + 1, present: p != null };
		if (p) {
			let d = js('mmcli -i ' + q(p) + ' -J 2>/dev/null')?.sim?.properties ?? {};
			s.iccid = tail4(d.iccid); s.op = d['operator-name'] ?? '';
			if (!act && (p == prim || d.active == 'yes')) act = i + 1;
		}
		push(sims, s);
	}
	return { via: 'mm', slots: length(L), active: act || 1, sims: sims };
}
function atread() {
	let I = M.id();
	if (I.vendor != 'quectel') return { via: '', slots: 1, active: 1, sims: [], err: t('questo modem non permette di scegliere lo slot da qui', 'this modem does not allow choosing the slot from here') };
	let r = M.at('AT+QUIMSLOT=?'), c = M.at('AT+QUIMSLOT?'), m = match(r, /\+QUIMSLOT: *\(([0-9]+)[-,]([0-9]+)\)/), a = match(c, /\+QUIMSLOT: *([0-9]+)/);
	if (!a) return { via: '', slots: 1, active: 1, sims: [], err: t('il modem non risponde ad AT+QUIMSLOT', 'the modem does not answer AT+QUIMSLOT') };
	/* con i comandi AT si sa solo se c'è la SIM dello slot attivo (AT+QSIMSTAT: <avviso>,<inserita>): le altre restano
	   «non si sa» (null) e il cambio automatico non le sceglie */
	let n = m ? +m[2] : 1, sims = [];
	for (let i = 1; i <= n; i++) push(sims, { slot: i, present: null });
	let ss = match(M.at('AT+QSIMSTAT?'), /\+QSIMSTAT: *[0-9]+,([0-9])/);
	if (ss && sims[+a[1] - 1]) sims[+a[1] - 1].present = ss[1] == '1';
	return { via: 'at', slots: n, active: +a[1], sims: sims };
}
function read() {
	let I = M.id(), r = (I.mm ? mmread() : null) ?? atread();
	r.t = time();
	writefile(OUT, sprintf('%J', r));
	return r;
}

/* ---------------- cambio ---------------- */
function mobif() { let m = M.mobif(); return m ? m[0] : ''; }
/* internet tornato (controllo della linea, line.sh) entro sec secondi */
function lineok(sec) {
	for (let i = 0; i < sec; i += 10) {
		let L = load('/tmp/wf-line.json');
		if (L && L.ok && time() - +(L.t ?? 0) < 15) return true;
		sh('sleep 10');
	}
	return false;
}
function setslot(n, why) {
	/* lettura fresca: lo slot attivo può essere cambiato da fuori (riavvio del modem, LuCI) */
	let r = read();
	if (n == r.active) return { ok: true, same: true };
	if (n < 1 || n > (r.slots ?? 1)) return { ok: false, err: t('slot non disponibile', 'slot not available') };
	let o = '', oldslot = r.active, ok = true, err = '';
	if (r.via == 'mm') { o = M.mmcli('--set-primary-sim-slot=' + n); M.cmdlog('mmcli --set-primary-sim-slot=' + n, o); }
	if (r.via != 'mm' || match(o, /error/i)) {
		if (M.id().vendor != 'quectel') { ok = false; err = trim(o) || t('cambio di slot non disponibile', 'slot change not available'); }
		else { o = M.at('AT+QUIMSLOT=' + n); if (!M.atok(o)) { ok = false; err = trim(o) || t('il modem non ha cambiato slot', 'the modem did not change slot'); } }
	}
	/* ultimo tentativo, anche se fallito: minwait vale per tutti e due */
	mkdir('/etc/wrtfreedom');
	writefile(LAST, sprintf('%J', { t: time(), from: oldslot, to: n, why: why, ok: ok, err: err, cyc: load('/tmp/wf-usage.json')?.cyc ?? '' }));
	if (!ok) return { ok: false, err: err, from: oldslot };
	/* profilo dati dello slot (se scelto) e riconnessione: con ModemManager il modem riparte e va ricollegato */
	let i = mobif(), apn = uo('sim', 'apn' + n);
	if (length(i)) {
		if (match(apn, /^[A-Za-z0-9._-]{1,64}$/)) sh('uci set network.' + i + '.apn=' + q(apn) + '; uci commit network');
		sh('sleep 20; ifup ' + q(i) + ' >/dev/null 2>&1');
	}
	/* modem pronto di nuovo: rilettura (fino a 90 s) */
	for (let k = 0; k < 9; k++) { sh('sleep 10; rm -f /tmp/wf-modem.id'); let x = read(); if (x.active == n) break; }
	return { ok: true, from: oldslot };
}
function why_t(w) {
	return { manual: t('scelta dall\'app', 'chosen in the app'), noline: t('linea assente', 'line down'), quota: t('giga finiti', 'data plan used up'),
		back: t('ritorno alla SIM principale', 'back to the main SIM'), renew: t('nuovo periodo dell\'offerta', 'new plan period'),
		backfail: t('la SIM principale non ha linea', 'the main SIM has no line') }[w] ?? w;
}
function doset(n, why) {
	let prev = load(LAST), r = setslot(n, why);
	if (r.same) return r;
	if (r.ok) ev('sim', '🔁 ' + t('SIM cambiata', 'SIM switched') + ': slot ' + r.from + ' → ' + n + ' · ' + why_t(why));
	/* errore: un evento solo, non a ogni tentativo uguale */
	else if (!(prev && prev.ok === false && prev.to == n)) ev('simerr', '⚠️ ' + t('Cambio SIM non riuscito', 'SIM switch failed') + ' (slot ' + n + '): ' + r.err);
	/* ritorno alla principale provato: senza internet entro 3 minuti si rimette la riserva */
	if (r.ok && (why == 'back' || why == 'renew') && !lineok(180)) {
		let b = setslot(r.from, 'backfail');
		if (b.ok) ev('sim', '↩️ ' + t('SIM principale senza linea: di nuovo sulla SIM di riserva', 'Main SIM without line: back on the backup SIM') + ' (slot ' + r.from + ')');
	}
	return r;
}

/* ---------------- cambio automatico ---------------- */
function auto() {
	if (uo('sim', 'auto') != '1' || uptime() < 900) return;
	let r = load(OUT);
	if (!r || time() - +(r.t ?? 0) > 60) r = read();
	if ((r.slots ?? 1) < 2) return;
	let now = time(), last = load(LAST), minw = (+uo('sim', 'minwait') || 30) * 60, main = +uo('sim', 'main') || 1;
	if (last && now - +last.t < minw) return;
	/* stato della linea fresco e linea principale = quella del modem (con un'altra linea principale non si cambia SIM) */
	let L = load('/tmp/wf-line.json');
	if (!L || now - +(L.t ?? 0) > 15) return;
	let i = mobif(), dev = length(i) ? trim(sh('ifstatus ' + q(i) + ' 2>/dev/null | jsonfilter -e "@.l3_device" 2>/dev/null')) : '';
	if (!length(i) || (length(L.dev ?? '') && L.dev != dev && L.main != i)) return;
	/* prossimo slot con la SIM sicuramente presente (con i comandi AT gli altri slot non si conoscono: niente cambio) */
	let next = 0;
	for (let k = 1; k < r.slots && !next; k++) { let s = (r.active - 1 + k) % r.slots + 1; if (r.sims?.[s - 1]?.present === true) next = s; }
	let U = load('/tmp/wf-usage.json'), back = uo('sim', 'back'), mainok = r.sims?.[main - 1]?.present === true;
	/* 1. niente internet da «after» minuti */
	if (next && !L.ok && now - +L.since >= (+uo('sim', 'after') || 5) * 60) { doset(next, 'noline'); return; }
	/* 2. giga finiti sulla SIM principale (una volta per periodo dell'offerta) */
	if (next && uo('sim', 'onquota') == '1' && r.active == main && +(U?.al ?? 0) >= 2 && !(last?.why == 'quota' && last?.cyc == U?.cyc)) { doset(next, 'quota'); return; }
	/* 3. ritorno alla principale (mai dopo una scelta fatta a mano dall'app) */
	if (r.active == main || !mainok || !L.ok || !last || last.why == 'manual' || !(back == '1' || back == 'renew')) return;
	let renewed = length(U?.cyc ?? '') && length(last.cyc ?? '') && U.cyc != last.cyc;
	if (renewed) { doset(main, 'renew'); return; }
	if (back == '1' && (last.why == 'noline' || last.why == 'backfail') && now - +last.t >= (+uo('sim', 'backwait') || 360) * 60) doset(main, 'back');
}

/* ---------------- PIN ---------------- */
function simpath() { let g = js('mmcli -m any -J 2>/dev/null')?.modem?.generic; let p = '' + (g?.sim ?? ''); return match(p, /SIM\/[0-9]+/) ? p : ''; }
/* stato: richiesta del PIN attiva (AT+CLCK="SC",2), tentativi rimasti (ModemManager «unlock-retries» o Quectel AT+QPINC) */
function pinstate() {
	let I = M.id(), r = { t: time(), via: I.mm ? 'mm' : 'at', enabled: null, retries: null, puk: null, state: '' };
	let c = match(atq('AT+CLCK="SC",2'), /\+CLCK: *([01])/);
	if (c) r.enabled = c[1] == '1';
	let p = match(atq('AT+CPIN?'), /\+CPIN: *([A-Z ]+)/);
	if (p) r.state = trim(p[1]);
	if (I.mm) {
		let g = js('mmcli -m any -J 2>/dev/null')?.modem?.generic ?? {};
		for (let x in (type(g['unlock-retries']) == 'array' ? g['unlock-retries'] : [])) {
			let m = match('' + x, /^(sim-pin|sim-puk) \(([0-9]+)\)/);
			if (m) { if (m[1] == 'sim-pin') r.retries = +m[2]; else r.puk = +m[2]; }
		}
		if (!length(r.state)) r.state = g['unlock-required'] ?? '';
	}
	if (r.retries == null) { let q2 = match(atq('AT+QPINC="SC"'), /\+QPINC: *"SC",([0-9]+),([0-9]+)/); if (q2) { r.retries = +q2[1]; r.puk = +q2[2]; } }
	return r;
}
function pinop(act, file) {
	let w = split(trim(readfile(file ?? '') ?? ''), /\s+/);
	if (file) unlink(file);
	let pin = w[0] ?? '', np = w[1] ?? '', o = '', ok = false;
	if (!match(pin, /^[0-9]{4,8}$/) || (act == 'change' && !match(np, /^[0-9]{4,8}$/))) return { ok: false, err: t('PIN non valido (4–8 cifre)', 'invalid PIN (4–8 digits)') };
	let S = M.id().mm ? simpath() : '';
	if (length(S)) {
		/* ModemManager: --pin con --enable-pin / --disable-pin / --change-pin */
		let opt = act == 'enable' ? ' --enable-pin' : act == 'disable' ? ' --disable-pin' : ' --change-pin=' + np;
		o = sh('mmcli -i ' + q(S) + ' --pin=' + pin + opt + ' 2>&1');
		ok = !match(o, /error/i);
	} else {
		o = act == 'change' ? atq('AT+CPWD="SC","' + pin + '","' + np + '"') : atq('AT+CLCK="SC",' + (act == 'enable' ? 1 : 0) + ',"' + pin + '"');
		ok = M.atok(o);
	}
	/* niente PIN nell'errore restituito */
	let err = ok ? '' : trim(replace(o, pin, '****'));
	if (length(np)) err = replace(err, np, '****');
	if (!ok && match(err, /incorrect|wrong|16|password/i)) err = t('PIN sbagliato', 'wrong PIN');
	return { ok: ok, err: err };
}

let cmd = ARGV[0] ?? '';
if (cmd == 'read') { if (lock(0)) { read(); rmdir(LOCK); } exit(0); }
if (cmd == 'set') {
	let n = +(ARGV[1] ?? 0), why = ARGV[2] ?? 'manual';
	if (!match('' + ARGV[1], /^[1-8]$/) || index([ 'manual', 'noline', 'quota', 'back', 'renew' ], why) < 0) { print('uso: sim.uc set <slot 1-8> [manual|noline|quota|back|renew]\n'); exit(1); }
	if (!lock(30)) exit(0);
	unlink('/tmp/wf-sim.pend');
	let r = doset(n, why);
	rmdir(LOCK);
	print(r.ok ? '## OK\n' : '## ERRORE ' + r.err + '\n');
	exit(r.ok ? 0 : 1);
}
if (cmd == 'auto') { if (lock(0)) { auto(); rmdir(LOCK); } exit(0); }
if (cmd == 'pin') {
	let act = ARGV[1] ?? 'get';
	if (index([ 'get', 'enable', 'disable', 'change' ], act) < 0) { print('uso: sim.uc pin get|enable|disable|change <file>\n'); exit(1); }
	if (!lock(30)) { if (ARGV[2]) unlink(ARGV[2]); exit(0); }
	let last = load(PINF)?.last;
	if (act != 'get') { last = pinop(act, ARGV[2]); last.act = act; last.t = time(); }
	let S = pinstate(); S.last = last;
	writefile(PINF, sprintf('%J', S));
	unlink('/tmp/wf-simpin.pend');
	rmdir(LOCK);
	if (act != 'get' && S.retries != null && S.retries <= 1) ev('simerr', '⚠️ ' + t('PIN della SIM: resta un solo tentativo, poi serve il PUK', 'SIM PIN: one attempt left, then the PUK is needed'));
	exit(0);
}
print('uso: sim.uc read | set <slot> [motivo] | auto | pin get|enable|disable|change <file>\n');
exit(1);
