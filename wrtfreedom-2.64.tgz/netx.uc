'use strict';
/* WrtFreedom 2.50: lavori in sottofondo di Rete e AdGuard (mai dentro rpcd; risultati in /tmp)
   uso: ucode netx.uc test    test «La Mia Rete È A Posto?» → /tmp/wf-nettest.json {run, t, end, ok, items [{id, ok, text, act}]}
                              ok: true = a posto, false = da sistemare, null = informazione; linea = interfaccia vera
                              (mai i tunnel), id vpn / vpnN = collegamenti accesi del Servizio VPN
        ucode netx.uc top     «Chi Usa Il DNS»: client e domini bloccati dalla API di AdGuard → /tmp/wf-adgtop.json
        ucode netx.uc level   Livelli di protezione: richiesta in /tmp/wf-adglevel.req (preparata dal metodo adglevel)
                              → liste del catalogo e filtri di tutta la casa, oppure il client AdGuard di una persona;
                              esito in /tmp/wf-adglevel.json {st, msg, t, level, person}
        ucode netx.uc weekly  Riepilogo Settimanale su Telegram (consumo, bloccati, dispositivi nuovi, cadute della linea)
        ucode netx.uc eth <porte>  velocità massima delle porte e del dispositivo collegato (ethtool) → /tmp/wf-ports.json
        ucode netx.uc nlbw    Mesi Precedenti (2.59): consumo per MAC di ogni periodo di nlbwmon → /tmp/wf-nlbwm.json
   Tutto letto dal router: interfacce e rotte da netifd, porte e indirizzi dal file di AdGuard, DHCP dalla configurazione. */
import { popen, readfile, writefile, unlink, stat, rename, mkdir } from 'fs';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function uget(p) { return trim(sh('uci -q get ' + q(p) + ' 2>/dev/null')); }
const EN = uget('wrtfreedom.ui.lang') == 'en';
function L(it, en) { return EN ? en : it; }
function num(n) { let s = sprintf('%d', n), o = ''; while (length(s) > 3) { o = (EN ? ',' : '.') + substr(s, -3) + o; s = substr(s, 0, length(s) - 3); } return s + o; }
function gb(b) { let s = sprintf('%.1f', b / 1e9); return (EN ? s : replace(s, '.', ',')) + ' GB'; }
let UB = null;
function ub(o, m, a) {
	if (UB == null) { try { UB = require('ubus').connect() ?? false; } catch (e) { UB = false; } }
	let r = UB ? UB.call(o, m, a ?? {}) : null;
	if (r == null) { let x = sh('ubus call ' + o + ' ' + m + (a ? ' ' + q(sprintf('%J', a)) : '') + ' 2>/dev/null'); try { r = json(x); } catch (e) { r = null; } }
	return r;
}
const TMO = length(trim(sh('command -v timeout 2>/dev/null'))) ? 'timeout 8 ' : '';
/* il server DNS risponde? (anche «non trovato» o SERVFAIL sono risposte) */
function ans(srv) {
	let o = sh(TMO + 'nslookup openwrt.org ' + q(srv) + ' 2>&1; echo "@rc=$?"');
	return match(o, /@rc=0/) != null || match(o, /can't find|NXDOMAIN|SERVFAIL|REFUSED/) != null;
}
/* ping: tempo medio in ms, null se non risponde; dev = esce da quel dispositivo (la linea) */
function ping(ip, v6, dev) {
	let I = dev ? '-I ' + q(dev) + ' ' : '';
	let o = sh('ping ' + (v6 ? '-6 ' : '') + I + '-c 2 -W 2 -q ' + q(ip) + ' 2>/dev/null || { [ -n "' + (v6 ? '1' : '') + '" ] && ping6 ' + I + '-c 2 -W 2 -q ' + q(ip) + ' 2>/dev/null; }');
	let m = match(o, /= [0-9.]+\/([0-9.]+)\//);
	return m ? int(+m[1] + 0.5) : (match(o, / [1-9][0-9]* (packets )?received/) ? 0 : null);
}
function iplong(s) { let p = split('' + s, '.'); if (length(p) != 4) return null; return (+p[0]) * 16777216 + (+p[1]) * 65536 + (+p[2]) * 256 + (+p[3]); }
function privip(s) {
	let p = map(split('' + s, '.'), (x) => +x);
	return p[0] == 10 || (p[0] == 172 && p[1] >= 16 && p[1] <= 31) || (p[0] == 192 && p[1] == 168) || (p[0] == 100 && p[1] >= 64 && p[1] <= 127);
}
/* file di AdGuard e chiavi del blocco dns: */
function adgyaml() {
	for (let f in [ uget('adguardhome.config.config_file'), uget('adguardhome.config.config'), '/etc/adguardhome/adguardhome.yaml', '/etc/adguardhome.yaml', '/opt/AdGuardHome/AdGuardHome.yaml' ])
		if (length(f) && has(f)) return f;
	return null;
}
function adgdns(y) {
	let r = {}, d = false, k = null;
	for (let l in split(readfile(y ?? '') ?? '', '\n')) {
		if (match(l, /^[^ #]/)) { d = substr(l, 0, 4) == 'dns:'; k = null; continue; }
		if (!d) continue;
		let m = match(l, /^  ([a-z_]+):[ \t]*(.*)$/);
		if (m) { k = m[1]; let v = trim(m[2]); r[k] = (v == '' || v == '[]') ? [] : replace(v, /^['"]|['"]$/g, ''); continue; }
		m = match(l, /^(    |  )- (.*)$/);
		if (m && k && type(r[k]) == 'array') push(r[k], replace(trim(m[2]), /^['"]|['"]$/g, ''));
	}
	return r;
}
/* indirizzo del pannello di AdGuard (sezione http:) e chiamata alla sua API con le credenziali salvate dall'app */
function adgaddr(y) {
	let f = false;
	for (let l in split(readfile(y ?? '') ?? '', '\n')) {
		if (substr(l, 0, 5) == 'http:') f = true;
		if (f && index(l, 'address:') >= 0) return trim(split(trim(l), /[ \t]+/)[1] ?? '') || '127.0.0.1:8080';
	}
	return '127.0.0.1:8080';
}
let ADGK = null;
function api(m, p, body) {
	let cred = trim(readfile('/etc/wrtfreedom/adguard') ?? '');
	if (!length(cred) || !has('/usr/bin/curl')) return { code: 0 };
	ADGK = ADGK ?? ('/tmp/.wf-adgx-' + (ARGV[0] ?? 'x'));
	if (!has(ADGK)) sh('umask 077; printf \'user = "%s"\\n\' ' + q(cred) + ' > ' + ADGK);
	if (body != null) writefile(ADGK + 'b', type(body) == 'string' ? body : sprintf('%J', body));
	let o = sh('curl -s -m 20 -K ' + ADGK + ' -w "\\n%{http_code}" -X ' + m + ' -H "Content-Type: application/json"' + (body != null ? ' --data-binary @' + ADGK + 'b' : '') +
		' ' + q('http://' + adgaddr(adgyaml()) + '/control/' + p) + ' 2>/dev/null');
	if (body != null) unlink(ADGK + 'b');
	let nl = rindex(o, '\n'), r = { code: +substr(o, nl + 1) }, b = substr(o, 0, nl);
	try { r.body = json(b); } catch (e) { r.body = null; }
	return r;
}
function apiend() { if (ADGK) { unlink(ADGK); unlink(ADGK + 'b'); } }
/* nomi e MAC dei dispositivi: assegnazioni DHCP e tabella ARP (senza processi) */
function devmap() {
	let H = {}, lf = '/tmp/dhcp.leases';
	for (let l in split(readfile(lf) ?? '', '\n')) { let p = split(l, ' '); if (length(p) >= 4) H[p[2]] = { mac: lc(p[1]), name: p[3] == '*' ? '' : p[3] }; }
	for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) {
		let p = split(trim(l), /[ \t]+/);
		if (length(p) >= 4 && match(p[3], /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) && p[3] != '00:00:00:00:00:00') H[p[0]] = H[p[0]] ?? { mac: p[3], name: '' };
	}
	return H;
}

/* configurazione uci letta una volta: { sezione: { '.type', opzione: valore o lista } } */
function ushow(cfg) {
	let C = {};
	for (let l in split(sh('uci -q show ' + q(cfg) + ' 2>/dev/null'), '\n')) {
		let m = match(l, /^[^.]+\.([^.=]+)=(.*)$/);
		if (m) { C[m[1]] = { '.type': m[2] }; continue; }
		m = match(l, /^[^.]+\.([^.=]+)\.([^=]+)=(.*)$/);
		if (!m || !C[m[1]]) continue;
		let v = map(match(m[3], /'[^']*'|[^ ]+/g) ?? [], (x) => replace(x[0], /^'|'$/g, ''));
		C[m[1]][m[2]] = length(v) > 1 ? v : (v[0] ?? '');
	}
	return C;
}
/* tunnel e VPN (Servizio VPN wgout/wgoN, WireGuard, OpenVPN, GRE…): mai la linea */
function istun(i) {
	return match(i.interface ?? '', /^wgo(ut|[0-9]+)$/) != null ||
		match(i.proto ?? '', /^(wireguard|openvpn|gre|gretap|grev6|grev6tap|vti|vtiv6|xfrm|vxlan|vxlan6|ipip|zerotier|tailscale)$/) != null ||
		match(i.l3_device ?? i.device ?? '', /^(tun|tap|wg|tailscale|zt)[0-9a-z]*$/) != null;
}
/* tipo di linea in una parola: SIM, Fibra/DSL, Wi-Fi di un altro router, USB, Cavo */
function linekind(i) {
	let p = i.proto ?? '', d = i.l3_device ?? i.device ?? '';
	if (match(p, /^(modemmanager|qmi|mbim|ncm|3g|wwan|qcm)$/)) return ['SIM', 'SIM'];
	if (match(p, /^ppp(oe|oa)$/)) return ['Fibra/DSL', 'Fiber/DSL'];
	if (length(d) && (has('/sys/class/net/' + d + '/wireless') || has('/sys/class/net/' + d + '/phy80211'))) return ['Wi-Fi Di Un Altro Router', 'Wi-Fi Of Another Router'];
	if (match(d, /^usb[0-9]/)) return ['USB', 'USB'];
	return ['Cavo', 'Cable'];
}
/* rotta predefinita della tabella principale (le tabelle del Servizio VPN e delle regole non contano) */
function defrt(i, t) {
	let m = null;
	for (let r in i.route ?? [])
		if (r.target == t && r.mask == 0 && (r.table == null || r.table == 'main' || +r.table == 254) && (m == null || (r.metric ?? 0) < m)) m = r.metric ?? 0;
	return m;
}
/* linea vera verso internet: interfaccia accesa, non tunnel, con la rotta predefinita; prima quelle nelle zone con
   mascheramento, poi la metrica più bassa */
function linepick(D, t, Z) {
	let b = null;
	for (let i in D) {
		if (!i.up || istun(i)) continue;
		let m = defrt(i, t); if (m == null) continue;
		let z = Z[i.interface] ? 0 : 1;
		if (!b || z < b.z || (z == b.z && m < b.m)) b = { i: i, m: m, z: z };
	}
	return b;
}
/* luogo del server VPN in italiano («Zurigo, Svizzera»): nomi più comuni delle città e paesi dal codice; un nome che
   non è in tabella resta com'è, un paese che manca resta col codice («Città (XX)»). Stessa tabella in wrtfreedom.uc (processo a parte) */
const VPNCITY = { zurich: 'Zurigo', geneva: 'Ginevra', london: 'Londra', paris: 'Parigi', brussels: 'Bruxelles', frankfurt: 'Francoforte',
	munich: 'Monaco Di Baviera', berlin: 'Berlino', hamburg: 'Amburgo', cologne: 'Colonia', prague: 'Praga', warsaw: 'Varsavia', lisbon: 'Lisbona',
	barcelona: 'Barcellona', copenhagen: 'Copenaghen', stockholm: 'Stoccolma', athens: 'Atene', bucharest: 'Bucarest', belgrade: 'Belgrado',
	dublin: 'Dublino', edinburgh: 'Edimburgo', rome: 'Roma', milan: 'Milano', turin: 'Torino', naples: 'Napoli', florence: 'Firenze',
	venice: 'Venezia', moscow: 'Mosca', kyiv: 'Kiev', marseille: 'Marsiglia', lyon: 'Lione', strasbourg: 'Strasburgo', luxembourg: 'Lussemburgo',
	ljubljana: 'Lubiana', zagreb: 'Zagabria', 'mexico city': 'Città Del Messico', 'sao paulo': 'San Paolo', 'são paulo': 'San Paolo',
	'cape town': 'Città Del Capo', philadelphia: 'Filadelfia', 'new york': 'New York', 'tel aviv': 'Tel Aviv',
	antwerp: 'Anversa', seville: 'Siviglia', nuremberg: 'Norimberga', basel: 'Basilea', bern: 'Berna', lucerne: 'Lucerna',
	krakow: 'Cracovia', gdansk: 'Danzica', thessaloniki: 'Salonicco', valletta: 'La Valletta', gothenburg: 'Göteborg', kiev: 'Kiev',
	'saint petersburg': 'San Pietroburgo', 'st petersburg': 'San Pietroburgo', seoul: 'Seul', beijing: 'Pechino', 'new delhi': 'Nuova Delhi',
	cairo: 'Il Cairo', jerusalem: 'Gerusalemme', bogota: 'Bogotà', montreal: 'Montréal' };
const VPNCC = { CH: 'Svizzera', IT: 'Italia', DE: 'Germania', FR: 'Francia', GB: 'Regno Unito', UK: 'Regno Unito', US: 'Stati Uniti',
	NL: 'Paesi Bassi', BE: 'Belgio', AT: 'Austria', ES: 'Spagna', PT: 'Portogallo', SE: 'Svezia', NO: 'Norvegia', DK: 'Danimarca',
	FI: 'Finlandia', PL: 'Polonia', CZ: 'Repubblica Ceca', SK: 'Slovacchia', HU: 'Ungheria', RO: 'Romania', BG: 'Bulgaria', GR: 'Grecia',
	IE: 'Irlanda', LU: 'Lussemburgo', SI: 'Slovenia', HR: 'Croazia', RS: 'Serbia', AL: 'Albania', EE: 'Estonia', LV: 'Lettonia',
	LT: 'Lituania', IS: 'Islanda', CY: 'Cipro', MT: 'Malta', MD: 'Moldavia', UA: 'Ucraina', TR: 'Turchia', RU: 'Russia', CA: 'Canada',
	MX: 'Messico', BR: 'Brasile', AR: 'Argentina', CL: 'Cile', JP: 'Giappone', KR: 'Corea Del Sud', SG: 'Singapore', HK: 'Hong Kong',
	IN: 'India', AU: 'Australia', NZ: 'Nuova Zelanda', ZA: 'Sudafrica', IL: 'Israele', AE: 'Emirati Arabi Uniti' };
function vpnplace(city, cc) {
	cc = uc('' + (cc ?? ''));
	let c = VPNCITY[lc(trim('' + (city ?? '')))] ?? city ?? '', p = VPNCC[cc];
	return length(c) ? c + (p ? ', ' + p : length(cc) ? ' (' + cc + ')' : '') : (p ?? cc);
}
/* collegamenti accesi del Servizio VPN: { n, main, mode, ndev, label, labeli } (label = luogo o nome del profilo, labeli = luogo in italiano) */
function vpnact(D, W) {
	let up = {}, R = [], ip = rjs('/tmp/wf-vpnip.json') ?? {};
	for (let i in D) if (i.up) up[i.interface] = true;
	for (let k, s in W) {
		if (s['.type'] != 'vpntun' || s.on == '0') continue;
		let n = +(s.n ?? 0), ifn = n ? 'wgo' + n : 'wgout';
		if (!up[ifn]) continue;
		let p = W[s.prof ?? ''] ?? {}, x = ip[k] ?? {}, cc = x.cc ?? p.cc ?? '';
		let lb = p.pname || x.city || p.city || p.name || p.sname || p.host || 'VPN';
		let ci = !p.pname && length(x.city || p.city);
		let dv = s.devs == null ? [] : type(s.devs) == 'array' ? s.devs : [s.devs];
		push(R, { n: n, main: !n, mode: s.mode ?? '', ndev: length(filter(dv, length)), label: lb + (length(cc) ? ' (' + uc(cc) + ')' : ''),
			labeli: ci ? vpnplace(lb, cc) : lb + (length(cc) ? ' (' + uc(cc) + ')' : '') });
	}
	return R;
}

/* ---------------- test «La Mia Rete È A Posto?» ---------------- */
function nettest() {
	const OUT = '/tmp/wf-nettest.json', t0 = time();
	let I = [], add = (id, ok, it, en, act) => push(I, { id: id, ok: ok, text: L(it, en), act: act });
	let D = ub('network.interface', 'dump')?.interface ?? [], F = ushow('firewall'), Z = {};
	for (let k, s in F) if (s['.type'] == 'zone' && s.masq == '1') for (let n in (type(s.network) == 'array' ? s.network : split(s.network ?? '', ' '))) if (length(n)) Z[n] = true;
	let w4 = linepick(D, '0.0.0.0', Z), w6 = linepick(D, '::', Z), wl = w4 ?? w6;
	/* linea e IPv4: il ping esce dalla linea (con la VPN accesa si misura la linea vera) */
	let d4 = w4 ? (w4.i.l3_device ?? w4.i.device) : null;
	let p4 = w4 ? (ping('1.1.1.1', false, d4) ?? ping('9.9.9.9', false, d4)) : null;
	if (!wl) add('line', false, 'Nessuna linea: manca la strada verso internet', 'No line: no route to the internet', 'line');
	else { let k = linekind(wl.i); add('line', true, 'Linea collegata · ' + k[0], 'Line connected · ' + k[1], 'line'); }
	if (w4) add('ipv4', p4 != null, p4 != null ? 'Internet IPv4 risponde · ' + p4 + ' ms' : 'Internet IPv4 non risponde', p4 != null ? 'IPv4 internet answers · ' + p4 + ' ms' : 'IPv4 internet not answering', 'line');
	/* Servizio VPN acceso: solo un'informazione */
	for (let v in vpnact(D, ushow('wrtfreedom'))) {
		let who = v.main ? (v.mode == 'all' ? ['tutta la casa', 'whole home'] : ['alcuni dispositivi', 'some devices']) :
			[v.ndev == 1 ? '1 dispositivo' : v.ndev + ' dispositivi', v.ndev == 1 ? '1 device' : v.ndev + ' devices'];
		add(v.main ? 'vpn' : 'vpn' + v.n, null, v.labeli + ' · ' + who[0], v.label + ' · ' + who[1], 'vpn');
	}
	/* IPv6: senza rotta è solo un'informazione (molte linee non lo danno) */
	if (!w6) add('ipv6', null, 'IPv6 assente: la linea non lo dà (non è un problema)', 'No IPv6: the line does not provide it (not a problem)', 'ipv6');
	else { let d6 = w6.i.l3_device ?? w6.i.device, p6 = ping('2606:4700:4700::1111', true, d6) ?? ping('2620:fe::fe', true, d6); add('ipv6', p6 != null, p6 != null ? 'IPv6 risponde · ' + p6 + ' ms' : 'IPv6 presente ma non risponde', p6 != null ? 'IPv6 answers · ' + p6 + ' ms' : 'IPv6 present but not answering', 'ipv6'); }
	/* DNS di casa (porta 53 del router) e AdGuard */
	let dh = ans('127.0.0.1');
	add('dns', dh, dh ? 'DNS di casa risponde' : 'DNS di casa non risponde: i siti non si aprono', dh ? 'Home DNS answers' : 'Home DNS not answering: websites will not open', 'dns');
	let y = adgyaml();
	if (y && (has('/etc/init.d/adguardhome') || has('/etc/init.d/AdGuardHome'))) {
		let Y = adgdns(y), ap = '' + (Y.port ?? ''), fb = has('/etc/wrtfreedom/dnsfb.state');
		let a = length(ap) && ans(ap == '53' ? '127.0.0.1' : '127.0.0.1:' + ap);
		if (fb) add('adg', false, 'AdGuard non risponde: DNS di riserva in uso', 'AdGuard not answering: backup DNS in use', 'adg');
		else add('adg', a, a ? 'AdGuard risponde' : 'AdGuard non risponde', a ? 'AdGuard answers' : 'AdGuard not answering', 'adg');
		if (a && ap != '53') add('adgsee', null, 'AdGuard vede solo il router: i dispositivi non si distinguono', 'AdGuard only sees the router: devices are not told apart', 'adgmode');
	}
	/* indirizzo condiviso dell'operatore: IP della linea privato o 100.64/10. Solo in quel caso si chiede l'IP pubblico
	   ad api.ipify.org (per mostrarlo); con un IP pubblico sulla linea nessuna richiesta fuori casa */
	let wip = w4 ? (w4.i['ipv4-address'] ?? [])[0]?.address : null;
	if (wip) {
		let pv = privip(wip);
		let pub = pv && p4 != null ? trim(sh('(uclient-fetch -q -T 6 -O - https://api.ipify.org || curl -s -m 6 https://api.ipify.org) 2>/dev/null')) : '';
		if (!match(pub, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) pub = '';
		/* con un server WireGuard di casa l'indirizzo condiviso è un problema vero (da fuori non si entra) */
		let wg = length(trim(sh("uci -q show network | grep -E \"^network\\.[A-Za-z0-9_]+\\.listen_port=\" | grep -vE '^network\\.wgo(ut|[0-9]+)\\.'")));
		let cg = iplong(wip) >= iplong('100.64.0.0') && iplong(wip) <= iplong('100.127.255.255');
		if (pv)
			add('cgnat', wg ? false : null, (cg ? 'Indirizzo condiviso dall\'operatore (CGNAT)' : 'Indirizzo della linea privato (operatore o altro router)') + ': da fuori il router non si raggiunge' + (length(pub) ? ' · pubblico ' + pub : ''),
				(cg ? 'Address shared by the provider (CGNAT)' : 'Private line address (provider or another router)') + ': the router cannot be reached from outside' + (length(pub) ? ' · public ' + pub : ''), 'cgnat');
		else add('cgnat', true, 'IP pubblico tuo: ' + wip, 'Your own public IP: ' + wip, 'cgnat');
	}
	/* DHCP quasi pieno: indirizzi assegnati nell'intervallo di ogni rete con DHCP acceso */
	let leases = filter(map(split(readfile('/tmp/dhcp.leases') ?? '', '\n'), (l) => split(l, ' ')[2]), length);
	for (let s in filter(split(sh("uci -q show dhcp | sed -n \"s/^dhcp\\.\\([^.=]*\\)=dhcp$/\\1/p\""), '\n'), length)) {
		let ifn = uget('dhcp.' + s + '.interface'); if (!length(ifn) || uget('dhcp.' + s + '.ignore') == '1') continue;
		let i = filter(D, (x) => x.interface == ifn)[0], a4 = (i?.['ipv4-address'] ?? [])[0]; if (!a4) continue;
		let mk = a4.mask ?? 24, base = iplong(a4.address) - (iplong(a4.address) % (1 << (32 - mk)));
		let st = +(uget('dhcp.' + s + '.start') || 100), lim = +(uget('dhcp.' + s + '.limit') || 150);
		let used = length(filter(leases, (ip) => { let n = iplong(ip); return n != null && n >= base + st && n < base + st + lim; }));
		let pc = lim > 0 ? int(used * 100 / lim) : 0;
		add('dhcp_' + ifn, pc < 90, (pc < 90 ? 'DHCP ' : 'DHCP quasi pieno ') + ifn + ': ' + used + ' di ' + lim + ' indirizzi', (pc < 90 ? 'DHCP ' : 'DHCP almost full ') + ifn + ': ' + used + ' of ' + lim + ' addresses', 'dhcp');
	}
	/* orologio: anno plausibile e sincronizzazione vista (hotplug ntp) */
	let yr = localtime().year, sync = has('/tmp/.wf-ntp');
	add('clock', yr >= 2025 ? (sync ? true : null) : false, yr < 2025 ? 'Orologio sbagliato: certificati e orari non funzionano' : sync ? 'Orologio sincronizzato' : 'Orologio plausibile, sincronizzazione non ancora vista',
		yr < 2025 ? 'Wrong clock: certificates and schedules will fail' : sync ? 'Clock synced' : 'Clock plausible, sync not seen yet', 'ntp');
	/* spazio del router */
	let m = has('/overlay') && match(readfile('/proc/mounts') ?? '', / \/overlay /) ? '/overlay' : '/';
	let pc = +(match(sh('df ' + m + ' 2>/dev/null'), /([0-9]+)% /)?.[1] ?? -1);
	if (pc >= 0) add('space', pc < 90, 'Spazio usato ' + pc + '%', 'Storage used ' + pc + '%', 'space');
	wjs(OUT, { run: false, t: t0, end: time(), ok: length(filter(I, (x) => x.ok === false)) == 0, items: I });
}

/* ---------------- Chi Usa Il DNS ---------------- */
function adgtop() {
	const OUT = '/tmp/wf-adgtop.json';
	let S = api('GET', 'stats'), H = devmap(), now = time();
	apiend(); unlink('/tmp/wf-adgtop.run');
	if (S.code != 200 || type(S.body) != 'object') { wjs(OUT, { t: now, err: L('AdGuard non risponde o credenziali mancanti', 'AdGuard not answering or missing credentials') }); return; }
	let C = [], B = [];
	for (let o in S.body.top_clients ?? []) for (let ip in o) push(C, { ip: ip, n: o[ip], name: H[ip]?.name ?? '', mac: H[ip]?.mac ?? '' });
	for (let o in S.body.top_blocked_domains ?? []) for (let d in o) push(B, { d: d, n: o[d] });
	let same = length(C) > 0 && length(filter(C, (c) => !match(c.ip, /^(127\.|::1$|localhost)/))) == 0;
	wjs(OUT, { t: now, same: same, clients: C, blocked: B, total: S.body.num_dns_queries ?? 0, blockedn: S.body.num_blocked_filtering ?? 0, unit: S.body.time_units ?? '' });
}

/* ---------------- Livelli di protezione ---------------- */
function adglevel() {
	const OUT = '/tmp/wf-adglevel.json';
	let R = rjs('/tmp/wf-adglevel.req'), now = time(), err = null;
	unlink('/tmp/wf-adglevel.req');
	if (!R) return;
	let st = (s, msg) => wjs(OUT, { st: s, msg: msg, t: time(), level: R.level, person: R.person?.id ?? null });
	st('run', '');
	if (!R.person) {
		/* tutta la casa: liste del livello accese (aggiunte se mancano), le altre del catalogo spente; filtri */
		let F = api('GET', 'filtering/status');
		if (F.code != 200) { st('err', L('AdGuard non risponde', 'AdGuard not answering')); apiend(); return; }
		let have = {};
		for (let f in F.body?.filters ?? []) have[f.url] = f;
		for (let x in R.lists ?? []) {
			let f = have[x.u], r = null;
			if (!f) r = api('POST', 'filtering/add_url', { name: x.n, url: x.u, whitelist: false });
			else if (!f.enabled) r = api('POST', 'filtering/set_url', { url: x.u, whitelist: false, data: { name: f.name ?? x.n, url: x.u, enabled: true } });
			if (r && r.code != 200) err = x.n;
		}
		let want = {};
		for (let x in R.lists ?? []) want[x.u] = true;
		for (let u in have) if (have[u].enabled && !want[u] && match(u, /HostlistsRegistry\/assets\/filter_[0-9]+\.txt$/))
			api('POST', 'filtering/set_url', { url: u, whitelist: false, data: { name: have[u].name ?? u, url: u, enabled: false } });
		api('POST', 'safebrowsing/' + (R.sb ? 'enable' : 'disable'));
		api('POST', 'parental/' + (R.par ? 'enable' : 'disable'));
		api('PUT', 'safesearch/settings', { enabled: !!R.ss, bing: true, duckduckgo: true, google: true, pixabay: true, yandex: true, youtube: true });
	}
	else {
		/* una persona: client AdGuard con i MAC della persona e i filtri del livello (le liste valgono per tutta la casa) */
		let C = api('GET', 'clients'), old = null;
		if (C.code != 200) { st('err', L('AdGuard non risponde', 'AdGuard not answering')); apiend(); return; }
		for (let c in C.body?.clients ?? []) if (c.name == R.person.name || length(filter(c.ids ?? [], (i) => index(R.person.macs, lc(i)) >= 0))) { old = c; break; }
		let d = { name: R.person.name, ids: R.person.macs, use_global_settings: false, filtering_enabled: true, safebrowsing_enabled: !!R.sb, parental_enabled: !!R.par,
			safesearch_enabled: !!R.ss, safe_search: { enabled: !!R.ss, bing: true, duckduckgo: true, google: true, pixabay: true, yandex: true, youtube: true },
			use_global_blocked_services: old ? (old.use_global_blocked_services ?? true) : true, blocked_services: old?.blocked_services ?? [], upstreams: old?.upstreams ?? [], tags: old?.tags ?? [],
			ignore_querylog: old?.ignore_querylog ?? false, ignore_statistics: old?.ignore_statistics ?? false };
		let r = old ? api('POST', 'clients/update', { name: old.name, data: d }) : api('POST', 'clients/add', d);
		if (r.code != 200) err = R.person.name;
	}
	apiend();
	if (err) st('err', L('Non applicato: ', 'Not applied: ') + err);
	else st('ok', L('Livello applicato', 'Level applied'));
}

/* ---------------- Riepilogo Settimanale ----------------
   2.60: anche senza bot. Una riga negli Eventi (cron_weekly, categoria sys: la notifica del telefono la vede come le
   altre); con il bot collegato il messaggio intero va su Telegram, salvo quando gli Eventi mandano già la categoria sys
   su Telegram (la riga basta: niente doppioni) */
function weekly() {
	let tk = uget('wrtfreedom.tg.token'), ch = uget('wrtfreedom.tg.chat'), now = time(), wk = now - 7 * 86400, T = [];
	push(T, '📊 ' + L('Riepilogo Settimanale', 'Weekly Summary') + ' · ' + (uget('system.@system[0].hostname') || 'OpenWrt'));
	/* consumo della linea dall'ultimo riepilogo (contatori del Consumo, anche a cavallo del rinnovo) */
	let U = rjs('/tmp/wf-usage.json') ?? rjs('/etc/wrtfreedom/usage.json'), P = rjs('/etc/wrtfreedom/weekly.json') ?? {};
	if (U && U.cyc != null) {
		let cur = (U.rx ?? 0) + (U.tx ?? 0), b = null;
		if (P.cyc == U.cyc && cur >= P.b) b = cur - P.b;
		else if (P.cyc != null && U.hist?.[0]?.from == P.cyc) b = (U.hist[0].rx ?? 0) + (U.hist[0].tx ?? 0) - P.b + cur;
		if (b != null && b >= 0) push(T, '📶 ' + L('Consumo', 'Data used') + ': ' + gb(b));
		mkdir('/etc/wrtfreedom');
		wjs('/etc/wrtfreedom/weekly.json', { cyc: U.cyc, b: cur, t: now });
	}
	/* AdGuard: richieste e bloccate degli ultimi 7 giorni (o delle ultime 24 ore se le statistiche sono di un giorno) */
	let S = has('/etc/wrtfreedom/adguard') ? api('GET', 'stats') : { code: 0 };
	apiend();
	if (S.code == 200 && type(S.body) == 'object') {
		let d = S.body.time_units == 'days', sum = (a) => { let n = 0, x = d ? slice(a ?? [], -7) : (a ?? []); for (let v in x) n += +v; return n; };
		let qn = sum(S.body.dns_queries), bn = sum(S.body.blocked_filtering);
		if (qn > 0) push(T, '🛡️ AdGuard: ' + num(bn) + ' ' + L('bloccati su', 'blocked of') + ' ' + num(qn) + ' (' + int(bn * 100 / qn) + '%)' + (d ? '' : ' · ' + L('ultime 24 ore', 'last 24 hours')));
	}
	/* registro degli eventi: dispositivi nuovi e cadute della linea della settimana */
	let lf = uget('wrtfreedom.ev.persist') == '1' ? '/etc/wrtfreedom/events.log' : '/tmp/wf-events.log', nd = [], down = 0;
	for (let l in split(readfile(lf) ?? '', '\n')) {
		let p = split(l, '|'); if (length(p) < 4 || +p[0] < wk) continue;
		let tx = join('|', slice(p, 3)), c = index(tx, ': ');
		if (p[1] == 'dev_new') push(nd, trim(split(c >= 0 ? substr(tx, c + 2) : '', ' · ')[0]));
		else if (p[1] == 'wan_down' || p[1] == 'cron_net_down') down++;
	}
	push(T, '🆕 ' + L('Dispositivi nuovi', 'New devices') + ': ' + length(nd) + (length(nd) ? ' (' + join(', ', slice(nd, 0, 5)) + (length(nd) > 5 ? '…' : '') + ')' : ''));
	push(T, (down ? '🔴 ' : '🟢 ') + L('Cadute della linea', 'Line drops') + ': ' + down);
	let up = int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]));
	if (lf == '/tmp/wf-events.log' && up < 7 * 86400) push(T, '⏱️ ' + L('Registro dall\'accensione', 'Log since power-on') + ' (' + int(up / 86400) + ' ' + L('giorni', 'days') + ')');
	/* Con Il Consiglio Dell'IA (2.62, wrtfreedom.ai.weekly): una sola chiamata di ai.uc tip (aspetta una chat in corso fino
	   a 5 minuti), mai un secondo tentativo; senza internet o col limite «Consiglio non disponibile» con il motivo */
	if (uget('wrtfreedom.ai.weekly') == '1' && uget('wrtfreedom.ai.on') == '1' && has('/usr/share/wrtfreedom/ai.uc')) {
		let r = readfile('/dev/urandom', 4) ?? '', id = '', d = '/tmp/wf-ai';
		for (let i = 0; i < 4; i++) id += sprintf('%02x', ord(r, i) ?? (now + i * 7) % 256);
		mkdir(d, 448);
		wjs(d + '/p-' + id + '.json', { lines: slice(T, 1), lang: EN ? 'en' : 'it' });
		sh('ucode /usr/share/wrtfreedom/ai.uc tip ' + id + ' </dev/null >/dev/null 2>&1');
		let R = rjs(d + '/job-' + id + '.json');
		unlink(d + '/job-' + id + '.json');
		push(T, R?.ok && length(R.msg ?? '') ? '💡 ' + L('Consiglio: ', 'Tip: ') + R.msg : '💡 ' + L('Consiglio non disponibile', 'Tip not available') + (length(R?.msg ?? '') ? ': ' + R.msg : ''));
	}
	sh('sh /usr/share/wrtfreedom/event.sh cron weekly sys ' + q('📊 ' + L('Riepilogo Settimanale', 'Weekly Summary') + ': ' + join(' · ', slice(T, 1))) + ' >/dev/null 2>&1');
	if (!length(tk) || !length(ch) || index(split(uget('wrtfreedom.ev.notify'), /[ \t]+/), 'sys') >= 0) return;
	mkdir('/tmp/wf-tgq');
	writefile('/tmp/wf-tgq/' + now + '-wk', join('\n', T));
	sh('( ucode /usr/share/wrtfreedom/tgq.uc flush ) </dev/null >/dev/null 2>&1 &');
}

/* velocità massima delle porte e del dispositivo collegato (ethtool, 2.50) per il metodo ports, che legge solo
   /tmp/wf-ports.json {t, eth, ports {dev: {sp, max, lp}}}. Cache: il massimo della porta non cambia (ethtool solo la
   prima volta); lp (dispositivo collegato) serve solo alle porte lente e resta finché la velocità è la stessa */
function eth(devs) {
	let F = '/tmp/wf-ports.json', P = rjs(F)?.ports ?? {};
	let bin = filter([ '/usr/sbin/ethtool', '/sbin/ethtool', '/usr/bin/ethtool' ], has)[0];
	for (let d in devs) {
		let b = '/sys/class/net/' + d;
		if (!match(d, /^[A-Za-z0-9_.@-]{1,32}$/) || !has(b)) continue;
		let sp = +trim(readfile(b + '/speed') ?? '0') || 0, o = P[d] ?? {}, slow = sp > 0 && sp < 1000;
		let r = { sp: sp, max: o.max ?? null, lp: (slow && o.sp == sp) ? (o.lp ?? null) : null };
		if (bin && (!r.max || (slow && o.sp != sp))) {
			let sec = '', mx = 0, lp = 0;
			for (let l in split(sh(bin + ' ' + q(d) + ' 2>/dev/null'), '\n')) {
				let m = match(l, /^\t([A-Za-z ]+):/);
				if (m) sec = m[1];
				for (let x in match(l, /([0-9]+)base/g) ?? []) {
					let v = +x[1];
					if (sec == 'Supported link modes' && v > mx) mx = v;
					if (sec == 'Link partner advertised link modes' && v > lp) lp = v;
				}
			}
			r.max = mx || null; r.lp = slow ? (lp || null) : null;
		}
		P[d] = r;
	}
	wjs(F, { t: time(), eth: bin != null, ports: P });
	unlink('/tmp/wf-ports.run');
}

/* Mesi Precedenti (2.59) per il metodo months, che legge solo /tmp/wf-nlbwm.json {t, ok, list [{p, cur, rx, tx,
   devs [[mac, rx, tx]] dal più alto, al massimo 60]}}: periodi da «nlbw -c list» (il più recente = in corso), poi dai file
   della cartella; i periodi finiti non cambiano e si rileggono solo se manca il dato */
function nlbwget(p) {
	let J = null;
	try { J = json(sh('nlbw -c json -g mac' + (p ? ' -t ' + q(p) : '') + ' 2>/dev/null') || 'null'); } catch (e) {}
	let c = J?.columns ?? [], im = index(c, 'mac'), ir = index(c, 'rx_bytes'), it = index(c, 'tx_bytes'), D = {}, rx = 0, tx = 0;
	if (im < 0 || ir < 0 || it < 0) return null;
	for (let r in J.data ?? []) {
		let m = lc('' + r[im]), x = D[m] = D[m] ?? [0, 0];
		x[0] += +r[ir]; x[1] += +r[it]; rx += +r[ir]; tx += +r[it];
	}
	let L = sort(map(keys(D), (m) => [m, D[m][0], D[m][1]]), (a, b) => (b[1] + b[2]) - (a[1] + a[2]));
	return { rx: rx, tx: tx, devs: slice(L, 0, 60) };
}
function nlbwm() {
	let F = '/tmp/wf-nlbwm.json', O = rjs(F) ?? {}, C = {}, P = [], gens = +(uget('nlbwmon.@nlbwmon[0].database_generations') || 10), out = [], ok = true;
	for (let x in O.list ?? []) if (!x.cur) C[x.p] = x;
	for (let l in split(sh('nlbw -c list 2>/dev/null'), '\n')) { let m = match(trim(l), /^([0-9]{4})-?([0-9]{2})-?([0-9]{2})$/); if (m) push(P, m[1] + '-' + m[2] + '-' + m[3]); }
	if (!length(P)) {
		let dir = uget('nlbwmon.@nlbwmon[0].database_directory') || '/var/lib/nlbwmon';
		for (let f in split(sh('ls ' + q(dir) + ' 2>/dev/null'), '\n')) { let m = match(f, /^([0-9]{4})([0-9]{2})([0-9]{2})\.db/); if (m) push(P, m[1] + '-' + m[2] + '-' + m[3]); }
	}
	P = slice(sort(uniq(P), (a, b) => a < b ? 1 : a > b ? -1 : 0), 0, gens > 0 && gens <= 120 ? gens : 10);
	for (let i = 0; i < length(P); i++) {
		let x = i > 0 && C[P[i]] ? C[P[i]] : nlbwget(i > 0 ? P[i] : null);
		if (!x) { if (!i) ok = false; continue; }
		push(out, { p: P[i], cur: i == 0, rx: x.rx, tx: x.tx, devs: x.devs });
	}
	wjs(F, { t: time(), ok: ok && length(P) > 0, list: out });
	unlink('/tmp/wf-nlbwm.run');
}

const A = ARGV[0] ?? '';
if (A == 'test') nettest();
else if (A == 'top') adgtop();
else if (A == 'level') adglevel();
else if (A == 'weekly') weekly();
else if (A == 'eth') eth(slice(ARGV, 1));
else if (A == 'nlbw') nlbwm();
else print('uso: ucode netx.uc test|top|level|weekly|eth <porte>|nlbw\n');
