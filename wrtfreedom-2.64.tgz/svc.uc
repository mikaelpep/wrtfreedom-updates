'use strict';
/* WrtFreedom 2.53: lavori in sottofondo di Altro · Servizi (mai dentro rpcd; i metodi leggono i risultati in /tmp)
   uso: ucode svc.uc pubip           IP pubblico chiesto dalla linea vera (curl --interface, mai dalla VPN in uscita)
                                     → /tmp/wf-pubip.json {t, ip, line, ifc}
        ucode svc.uc name            Il Nome Funziona? → /tmp/wf-ddnsname.json {t, line, pub, cgnat, list [{sec, name, a,
                                     aaaa, reg, ok, why}]}; why: ok, wait (aggiornato, il DNS risponde ancora il vecchio),
                                     old (nome con un altro IP), none (nome non trovato), off (servizio spento), nopub
        ucode svc.uc ip              storico dei cambi di IP pubblico (/tmp/wf-iphist.json; in /etc al massimo ogni 12 ore;
                                     con CGNAT la richiesta fuori casa al massimo ogni 10 minuti)
        ucode svc.uc log <id> <rc> [k]  esito di un'attività delle Pianificazioni nel registro /tmp/wf-cronrun.log
                                     («ora|id|esito|tipo», k: c orario, r recuperata, n Esegui Ora; copia rada in /etc)
        ucode svc.uc run <id>        Esegui Ora di un'attività dell'app, scritta nel registro (2.64: una riga «una volta
                                     sola» dell'IA, meta.once, resta: il comando parte senza il suo «cron del»)
        ucode svc.uc boot            all'accensione: registro e storico da /etc, poi (con l'orologio sincronizzato) recupero
                                     delle attività sicure con «recupera» (meta r:1, CRREC) saltate mentre il router era
                                     spento; ultime esecuzioni in /tmp/wf-cronlast.json, in /etc al massimo ogni ora;
                                     2.64: righe «una volta sola» scadute tolte (anche a ogni esito nel registro)
        ucode svc.uc save            allo spegnimento: registro e storico in /etc
        ucode svc.uc abtest          Prova Prima E Dopo → /tmp/wf-abtest.json (al massimo 250 MB)
        ucode svc.uc keep <id>       attività All'Avvio (dal crontab ogni minuto): riparte se si è fermata; dopo 3 ripartenze
                                     in 10 minuti si ferma (/tmp/wf-svc.<id>.st) e lo scrive nel registro
   Righe del crontab come wrtfreedom.uc (crparse): «[#off# ]m h g M s comando #wrtfreedom {json}», comando avvolto in
   «{ comando; } ; ucode svc.uc log <id> $?», id = meta.i oppure lo stesso calcolo (crhash). */
import { popen, readfile, writefile, unlink, stat, rename, mkdir, rmdir, open } from 'fs';

const CRONF = '/etc/crontabs/root', RLOG = '/tmp/wf-cronrun.log', RLOGE = '/etc/wrtfreedom/cronrun.log', RLAST = '/etc/wrtfreedom/cronlast.json', RLASTT = '/tmp/wf-cronlast.json';
const IPH = '/tmp/wf-iphist.json', IPHE = '/etc/wrtfreedom/iphist.json';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
/* opzione di una sezione con nome di /etc/config/wrtfreedom letta dal file, senza processi */
function uo(sec, opt) {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
		let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m && m[1] == opt) return m[2];
	}
	return '';
}
const EN = uo('ui', 'lang') == 'en';
function L(it, en) { return EN ? en : it; }
/* un lavoro per tipo alla volta; un blocco rimasto da un lavoro interrotto si toglie dopo max secondi */
function lock(n, max) {
	let d = '/tmp/wf-svc.' + n + '.lock';
	if (mkdir(d)) return d;
	let s = stat(d);
	if (s && time() - s.mtime > max) { rmdir(d); if (mkdir(d)) return d; }
	return null;
}
let UB = null;
function ub(o, m, a) {
	if (UB == null) { try { UB = require('ubus').connect() ?? false; } catch (e) { UB = false; } }
	let r = UB ? UB.call(o, m, a ?? {}) : null;
	if (r == null) { try { r = json(sh('ubus call ' + o + ' ' + m + (a ? ' ' + q(sprintf('%J', a)) : '') + ' 2>/dev/null')); } catch (e) { r = null; } }
	return r;
}
/* configurazione uci letta una volta: { sezione: { '.type', opzione: valore o lista } } */
function ushow(cfg) {
	let C = {};
	for (let l in split(sh('uci -q show ' + q(cfg) + ' 2>/dev/null'), '\n')) {
		let m = match(l, /^[^.]+\.([^.=]+)=(.*)$/);
		if (m) { C[m[1]] = { '.type': m[2] }; continue; }
		m = match(l, /^[^.]+\.([^.=]+)\.([^=]+)=(.*)$/);
		if (!m || !C[m[1]]) continue;
		let v = map(match(m[3], /'[^']*'|[^ ]+/g) ?? [], (x) => replace(x[0], /^'|'$/g, ''));
		C[m[1]][m[2]] = length(v) > 1 ? v : (v[0] ?? '');
	}
	return C;
}
function privip(s) {
	let p = map(split('' + s, '.'), (x) => +x);
	return p[0] == 10 || (p[0] == 172 && p[1] >= 16 && p[1] <= 31) || (p[0] == 192 && p[1] == 168) || (p[0] == 100 && p[1] >= 64 && p[1] <= 127);
}

/* ---------------- linea vera (come netx.uc e lineinfo di wrtfreedom.uc) ---------------- */
function istun(i) {
	return match(i.interface ?? '', /^wgo(ut|[0-9]+)$/) != null ||
		match(i.proto ?? '', /^(wireguard|openvpn|gre|gretap|grev6|grev6tap|vti|vtiv6|xfrm|vxlan|vxlan6|ipip|zerotier|tailscale)$/) != null ||
		match(i.l3_device ?? i.device ?? '', /^(tun|tap|wg|tailscale|zt)[0-9a-z]*$/) != null;
}
function line() {
	let D = ub('network.interface', 'dump')?.interface ?? [], F = ushow('firewall'), Z = {}, b = null;
	for (let k, s in F) if (s['.type'] == 'zone' && (s.masq == '1' || s.masq == 'true') && s.name != 'vpnout')
		for (let n in (type(s.network) == 'array' ? s.network : split(s.network ?? '', ' '))) if (length(n)) Z[n] = true;
	for (let i in D) {
		if (!i.up || istun(i)) continue;
		let m = null;
		for (let r in i.route ?? [])
			if (r.target == '0.0.0.0' && r.mask == 0 && (r.table == null || r.table == 'main' || +r.table == 254) && (m == null || (r.metric ?? 0) < m)) m = r.metric ?? 0;
		if (m == null) continue;
		let z = Z[i.interface] ? 0 : 1;
		if (!b || z < b.z || (z == b.z && m < b.m)) b = { i: i, m: m, z: z };
	}
	if (!b) return null;
	let i = b.i, ip = (i['ipv4-address'] ?? [])[0]?.address ?? '', ip6 = '';
	for (let a in i['ipv6-address'] ?? []) if (!match(a.address ?? '', /^f[c-f]/i)) { ip6 = a.address; break; }
	return { ifc: i.interface, dev: i.l3_device ?? i.device ?? '', proto: i.proto ?? '', ip: ip, ip6: ip6, priv: length(ip) > 0 && privip(ip), tun: length(filter(D, (x) => x.up && istun(x))) > 0 };
}
const CURL = has('/usr/bin/curl');
/* IP pubblico: quello della linea se è pubblico; altrimenti chiesto fuori casa con la richiesta legata alla linea
   (curl --interface: con il Servizio VPN acceso esce comunque dalla linea). Senza curl solo se nessun tunnel è acceso */
function pubget(Ln, maxage) {
	if (!Ln || !length(Ln.ip)) return '';
	if (!Ln.priv) return Ln.ip;
	/* linea privata (CGNAT): con maxage si riusa l'ultima risposta della stessa linea (svc.uc ip: al massimo ogni 10 minuti) */
	let P = maxage ? rjs('/tmp/wf-pubip.json') : null;
	if (P && P.line == Ln.ip && length(P.ip ?? '') && time() - (P.t ?? 0) < maxage) return P.ip;
	let o = '';
	if (CURL) o = sh('curl -4 -s -m 8 --interface ' + q(Ln.dev) + ' https://api.ipify.org 2>/dev/null || curl -4 -s -m 8 --interface ' + q(Ln.dev) + ' https://ipv4.icanhazip.com 2>/dev/null');
	else if (!Ln.tun) o = sh('uclient-fetch -4 -q -T 8 -O - https://api.ipify.org 2>/dev/null');
	o = trim(o);
	return match(o, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) ? o : '';
}
/* storico dei cambi di IP pubblico: una voce quando cambia (ultimi 100); in /etc al massimo ogni 12 ore e allo spegnimento */
function iprec(pub, Ln) {
	if (!length(pub)) return;
	let H = rjs(IPH) ?? rjs(IPHE) ?? { list: [], saved: 0 }, last = H.list[length(H.list) - 1];
	if (last && last.ip == pub) return;
	push(H.list, { t: time(), ip: pub, line: Ln?.ip ?? '', ifc: Ln?.ifc ?? '' });
	if (length(H.list) > 100) H.list = slice(H.list, length(H.list) - 100);
	if (time() - (H.saved ?? 0) > 43200) { H.saved = time(); mkdir('/etc/wrtfreedom'); wjs(IPHE, H); }
	wjs(IPH, H);
}
function pubip(maxage) {
	let Ln = line(), P = maxage ? rjs('/tmp/wf-pubip.json') : null, pub = pubget(Ln, maxage);
	/* risposta riusata: il file resta con la sua ora (così dopo 10 minuti si richiede davvero) */
	let same = P && Ln && P.line == Ln.ip && P.ip == pub && time() - (P.t ?? 0) < (maxage ?? 0);
	if (Ln && length(Ln.ip) && !same) wjs('/tmp/wf-pubip.json', { t: time(), ip: pub, line: Ln.ip, ifc: Ln.ifc });
	iprec(pub, Ln);
	return { Ln: Ln, pub: pub };
}

/* ---------------- Il Nome Funziona? ---------------- */
const TMO = length(trim(sh('command -v timeout 2>/dev/null'))) ? 'timeout 8 ' : '';
/* indirizzi di un nome da un server DNS (le righe dopo «Name:»; prima ci sono quelle del server) */
function nslook(name, aaaa, srv) {
	let o = sh(TMO + 'nslookup ' + (aaaa ? '-type=AAAA ' : '') + q(name) + ' ' + q(srv) + ' 2>/dev/null'), R = [], ans = false;
	for (let l in split(o, '\n')) {
		if (match(l, /^Name:/)) { ans = true; continue; }
		let m = ans ? match(l, /^Address( [0-9]+)?:[[:space:]]*([0-9a-fA-F.:]+)/) : null;
		if (m && (index(m[2], ':') >= 0) == aaaa && index(R, m[2]) < 0) push(R, m[2]);
	}
	return R;
}
function namecheck() {
	const OUT = '/tmp/wf-ddnsname.json';
	let P = pubip(), Ln = P.Ln, pub = P.pub, D = ushow('ddns'), out = [];
	for (let k, s in D) {
		if (s['.type'] != 'service') continue;
		let n = s.lookup_host ?? s.domain ?? '', r = { sec: k, name: n, a: [], aaaa: [], reg: trim(readfile('/var/run/ddns/' + k + '.ip') ?? '') };
		if (!match(n, /^[A-Za-z0-9.-]{1,253}$/) || index(n, '.') < 0) { r.ok = null; r.why = 'none'; push(out, r); continue; }
		let srv = match(s.dns_server ?? '', /^[0-9a-fA-F.:]{3,45}$/) ? s.dns_server : '1.1.1.1';
		r.a = nslook(n, false, srv);
		if (s.use_ipv6 == '1') r.aaaa = nslook(n, true, srv);
		let v6 = s.use_ipv6 == '1', want = v6 ? (Ln?.ip6 ?? '') : pub, got = v6 ? r.aaaa : r.a;
		if (s.enabled != '1') { r.ok = null; r.why = 'off'; }
		else if (!length(got)) { r.ok = false; r.why = 'none'; }
		else if (!length(want)) { r.ok = null; r.why = 'nopub'; }
		else if (index(got, want) >= 0) { r.ok = true; r.why = 'ok'; }
		else if (r.reg == want) { r.ok = null; r.why = 'wait'; }
		else { r.ok = false; r.why = 'old'; }
		push(out, r);
	}
	wjs(OUT, { t: time(), line: Ln ? { ifc: Ln.ifc, ip: Ln.ip, ip6: Ln.ip6 } : null, pub: pub, cgnat: Ln?.priv ?? false, list: out });
}

/* ---------------- Pianificazioni: registro e recupero ---------------- */
function crhash(s) { let h = 5381; for (let i = 0; i < length(s); i++) h = ((h * 33) ^ ord(s, i)) & 0x7fffffff; return sprintf('%08x', h); }
function crunwrap(c) {
	let m = match(c, /^\{ (.*) \} ; ucode \/usr\/share\/wrtfreedom\/svc\.uc log [0-9a-f]{8} \$\?$/s);
	if (!m) return c;
	let x = m[1];
	return substr(x, length(x) - 1) == ';' ? rtrim(substr(x, 0, length(x) - 1)) : x;
}
function crapp() {
	let out = [];
	for (let l in split(readfile(CRONF) ?? '', '\n')) {
		l = rtrim(l);
		let off = substr(l, 0, 6) == '#off# ', s = off ? substr(l, 6) : l, mm = match(s, / #(wrtfreedom|x3000) /);
		if (!mm || match(s, / # wf:[a-z0-9_]{1,40}$/)) continue;
		let mi = index(s, mm[0]), meta = null;
		try { meta = json(replace(substr(s, mi + length(mm[0])), /\\%/g, '%')); } catch (e) {}
		let f = type(meta) == 'object' ? match(substr(s, 0, mi), /^[ \t]*([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+(.*)$/s) : null;
		if (!f) continue;
		let cmd = crunwrap(f[6]), a = '' + (meta.a ?? ''), lg = cmd != f[6];
		let id = match('' + (meta.i ?? ''), /^[0-9a-f]{8}$/) ? meta.i : crhash(a + '|' + (meta.x ?? '') + '|' + (meta.n ?? '') + '|' + (meta.w ?? '') + (a == 'custom' || a == '' ? '|' + cmd : ''));
		push(out, { on: !off, when: slice(f, 1, 6), cmd: replace(cmd, /\\%/g, '%'), meta: meta, id: id, lg: lg });
	}
	return out;
}
/* copia rada del registro in /etc: al massimo ogni 6 ore (e allo spegnimento) */
function logsave(force) {
	let s = stat(RLOGE);
	if (!has(RLOG) || (!force && s && time() - s.mtime < 21600)) return;
	mkdir('/etc/wrtfreedom');
	writefile(RLOGE + '.t', readfile(RLOG) ?? '');
	rename(RLOGE + '.t', RLOGE);
}
/* ultime esecuzioni delle attività con «recupera»: /etc (anche le ore di partenza scritte dall'app) unito a /tmp */
function lastget() {
	let R = rjs(RLAST) ?? {}, T = rjs(RLASTT) ?? {};
	for (let k, v in T) if (+v > +(R[k] ?? 0)) R[k] = v;
	return R;
}
function lastsave(force) {
	let s = stat(RLAST);
	if (!has(RLASTT) || (!force && s && time() - s.mtime < 3600)) return;
	mkdir('/etc/wrtfreedom'); wjs(RLAST, lastget());
}
/* 2.64: righe «una volta sola» dell'IA (meta.once, «m h giorno mese *») con l'ora già passata da più di 2 minuti (router
   spento in quel minuto): tolte con «cron del», altrimenti ripartirebbero tra un anno. La riga vale al massimo qualche
   giorno dopo la conferma: una data di quest'anno passata da più di 300 giorni è quella dell'anno prossimo. Solo con
   l'orologio sincronizzato */
function oncegc(J) {
	if (!has('/tmp/.wf-ntp')) return;
	let now = time(), n = localtime(now), ids = [];
	for (let p in J ?? crapp()) {
		if (!(p.meta.once == 1 || p.meta.once === true) || !match(join(' ', slice(p.when, 0, 4)), /^[0-9]{1,2} [0-9]{1,2} [0-9]{1,2} [0-9]{1,2}$/)) continue;
		let t = timelocal({ year: n.year, mon: +p.when[3], mday: +p.when[2], hour: +p.when[1], min: +p.when[0], sec: 0 }), d = now - t;
		if (d > 120 && d < 300 * 86400) push(ids, p.id);
	}
	if (length(ids)) ub('wrtfreedom', 'cron', { action: 'del', ids: ids });
}
function logadd(id, rc, k) {
	if (!match(id, /^[0-9a-f]{8}$/) || !match('' + rc, /^-?[0-9]{1,5}$/)) return;
	let f = open(RLOG, 'a');
	if (f) { f.write(time() + '|' + id + '|' + int(+rc) + '|' + k + '\n'); f.close(); }
	let s = stat(RLOG);
	if (s && s.size > 24000) { let Ls = split(trim(readfile(RLOG) ?? ''), '\n'); writefile(RLOG + '.t', join('\n', slice(Ls, length(Ls) - 300)) + '\n'); rename(RLOG + '.t', RLOG); }
	/* attività con «recupera»: ultima esecuzione in /tmp, in /etc al massimo ogni ora (e allo spegnimento) */
	let J = crapp(), p = filter(J, (x) => x.id == id)[0];
	if (p && (p.meta.r == 1 || p.meta.r === true)) { let T = rjs(RLASTT) ?? {}; T[id] = time(); wjs(RLASTT, T); lastsave(false); }
	logsave(false);
	oncegc(J);
}
/* 2.64: Esegui Ora di una riga «una volta sola» (meta.once): il comando senza la coda «; ubus call wrtfreedom cron del»,
   così la riga resta per il suo orario */
function oncecmd(p) {
	return p.meta.once == 1 || p.meta.once === true ? replace(p.cmd, /[ \t]*;[ \t]*ubus call wrtfreedom cron '\{"action":"del","ids":\["[0-9a-f]{8}"\]\}' >\/dev\/null 2>&1[ \t]*$/, '') : p.cmd;
}
function runone(p, k) {
	let rc = +(match(sh('( ' + (k == 'n' ? oncecmd(p) : p.cmd) + ' ) </dev/null >/dev/null 2>&1; echo "@rc=$?"'), /@rc=(-?[0-9]+)/)?.[1] ?? 1);
	logadd(p.id, rc, k);
	return rc;
}
/* campo del crontab: asterisco, n, a-b, passo «/n», a-b/n, liste con la virgola (nomi come «mon» = nessuna corrispondenza) */
function fmatch(f, v, lo, hi) {
	for (let p in split(f, ',')) {
		let m = match(p, /^(\*|([0-9]{1,2})(-([0-9]{1,2}))?)(\/([0-9]{1,2}))?$/);
		if (!m) continue;
		let a = lo, b = hi, st = +(m[6] ?? 1) || 1;
		if (m[1] != '*') { a = +m[2]; b = m[4] != null ? +m[4] : (m[6] != null ? hi : a); }
		if (v >= a && v <= b && (v - a) % st == 0) return true;
	}
	return false;
}
function cmatch(w, t) {
	let lt = localtime(t), dw = lt.wday;
	let dm = fmatch(w[2], lt.mday, 1, 31), dd = fmatch(w[4], dw, 0, 7) || (dw == 0 && fmatch(w[4], 7, 0, 7));
	let day = (w[2] != '*' && w[4] != '*') ? (dm || dd) : (dm && dd);
	return day && fmatch(w[0], lt.min, 0, 59) && fmatch(w[1], lt.hour, 0, 23) && fmatch(w[3], lt.mon, 1, 12);
}
/* recupero all'avvio solo per attività sicure con il registro: mai riavvii, linea, modem, Wi-Fi, VPN, servizi, Comandi del
   bot o comandi propri (un'attività che toglie la rete recuperata a ogni accensione darebbe un ciclo di riavvii) */
const CRREC = [ 'ledoff', 'ledon', 'adgupd', 'adgon', 'dnsflush', 'block', 'unblock', 'wol', 'ddnscheck', 'signalcheck', 'spacecheck',
	'tempcheck', 'report', 'backup', 'certrenew', 'certadg', 'updcheck', 'pkglist', 'ntpsync', 'memfree', 'trafficsave' ];
function boot() {
	if (!has(RLOG) && has(RLOGE)) writefile(RLOG, readfile(RLOGE));
	if (!has(IPH) && has(IPHE)) writefile(IPH, readfile(IPHE));
	let J0 = crapp(), J = filter(J0, (p) => p.on && p.lg && (p.meta.r == 1 || p.meta.r === true) && p.meta.w == null && index(CRREC, '' + (p.meta.a ?? '')) >= 0 &&
		match(p.when[0], /^[0-9,]{1,60}$/) && match(p.when[1], /^[0-9,-]{1,60}$/));
	let O = filter(J0, (p) => p.meta.once == 1 || p.meta.once === true);
	if (!length(J) && !length(O)) return;
	/* orologio vero prima di decidere (all'accensione può essere quello dell'ultimo spegnimento): al massimo 10 minuti */
	for (let i = 0; i < 60 && !has('/tmp/.wf-ntp'); i++) sh('sleep 10');
	if (!has('/tmp/.wf-ntp')) return;
	/* 2.64: righe «una volta sola» saltate mentre il router era spento */
	if (length(O)) oncegc(J0);
	if (!length(J)) return;
	sh('sleep 60');	/* la linea e i servizi partono */
	let R = lastget(), now = time(), bt = now - int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])), go = [], ran = [];
	for (let p in J) {
		let last = R[p.id];
		if (!last) continue;
		/* orari saltati tra l'ultima esecuzione (o la creazione) e l'accensione, al massimo negli ultimi 7 giorni */
		let tstart = last + 60 - (last % 60), lo = bt - 7 * 86400, hit = false;
		if (tstart < lo) tstart = lo - (lo % 60);
		for (let t = tstart; t <= bt && !hit; t += 60) hit = cmatch(p.when, t);
		if (hit) push(go, p);
	}
	if (!length(go)) return;
	/* ora segnata in /etc PRIMA di eseguire: se l'attività si blocca o il router si spegne, all'accensione dopo non si ripete */
	for (let p in go) R[p.id] = now;
	mkdir('/etc/wrtfreedom'); wjs(RLAST, R);
	for (let p in go) { runone(p, 'r'); push(ran, p.meta.n ?? p.meta.a ?? p.id); }
	sh('sh /usr/share/wrtfreedom/event.sh cron recover sys ' + q('⏰ ' + L('Attività recuperate dopo l\'accensione', 'Tasks recovered after power on') + ': ' + join(', ', ran)) + ' >/dev/null 2>&1');
}

/* ---------------- attività All'Avvio ---------------- */
/* riga «ucode svc.uc keep <id> # comando» (wrtfreedom.uc crwrap): pid in /tmp/wf-svc.<id> (vivo solo se la sua riga di
   comando contiene wf-svc.<id>: niente pid riusati), esito in .rc, partenze degli ultimi 10 minuti in .st */
function keep(id) {
	if (!match(id, /^[0-9a-f]{8}$/)) return;
	let p = filter(crapp(), (x) => x.id == id)[0], c = p?.on ? match(p.cmd, /^ucode \/usr\/share\/wrtfreedom\/svc\.uc keep [0-9a-f]{8} # (.*)$/s)?.[1] : null;
	if (!c) return;
	let F = '/tmp/wf-svc.' + id, pid = '' + int(+trim(readfile(F) ?? '0')), cl = +pid > 1 ? readfile('/proc/' + pid + '/cmdline') : null;
	if (cl != null && index(cl, 'wf-svc.' + id) >= 0) return;
	let S = rjs(F + '.st') ?? {}, now = time();
	if (S.stop) return;
	S.s = filter(S.s ?? [], (t) => now - t < 600);
	/* partita 4 volte in 10 minuti (la prima più 3 ripartenze) e di nuovo ferma: resta ferma fino al prossimo salvataggio
	   dell'attività o al riavvio; nel registro l'ultimo esito (0 = finita da sola, scritto come 1) */
	if (length(S.s) >= 4) {
		let rc = +(trim(readfile(F + '.rc') ?? '1')) || 1;
		S.stop = now; wjs(F + '.st', S);
		logadd(id, rc, 'c');
		return;
	}
	push(S.s, now); wjs(F + '.st', S);
	unlink(F + '.rc');
	let n = trim(sh('( ( ' + c + ' ) </dev/null >/dev/null 2>&1; echo $? >' + F + '.rc ) >/dev/null 2>&1 </dev/null & echo $!'));
	if (match(n, /^[0-9]{1,10}$/)) writefile(F, n);
}

/* ---------------- Prova Prima E Dopo ---------------- */
const ABF = '/tmp/wf-abtest.json';
function abst(o) { o.t = o.t ?? time(); wjs(ABF, o); }
function pavg(o) { let m = match(o, /= [0-9.]+\/([0-9.]+)\//); return m ? int(+m[1] + 0.5) : null; }
function nbytes(dev, k) { return +(trim(readfile('/sys/class/net/' + dev + '/statistics/' + k + '_bytes') ?? '0')); }
/* voto dal ritardo in più a linea carica (ms): A < 30, B < 60, C < 120, D < 200, E < 400, F oltre */
function grade(ms) { return ms == null ? null : ms < 30 ? 'A' : ms < 60 ? 'B' : ms < 120 ? 'C' : ms < 200 ? 'D' : ms < 400 ? 'E' : 'F'; }
/* una fase: ping a riposo, poi a linea carica in download e in upload (cap = byte al massimo per verso) */
function abphase(Ln, cap, upOnly) {
	let I = q(Ln.dev), P = '1.1.1.1', r = {};
	r.idle = pavg(sh('ping -I ' + I + ' -c 5 -W 1 -q ' + P + ' 2>/dev/null'));
	if (!upOnly) {
		let b0 = nbytes(Ln.dev, 'rx'), t0 = time(), per = int(cap / 3);
		let o = sh('P=; for i in 1 2 3; do curl -4 -s -o /dev/null -m 13 --interface ' + I + ' "https://speed.cloudflare.com/__down?bytes=' + per + '" & P="$P $!"; done; sleep 2; ' +
			'ping -I ' + I + ' -c 10 -W 1 -q ' + P + ' 2>/dev/null; kill $P 2>/dev/null; wait');
		let s = time() - t0 || 1;
		r.dl = { ms: pavg(o), mbit: int((nbytes(Ln.dev, 'rx') - b0) * 8 / s / 1e5) / 10 };
	}
	let b1 = nbytes(Ln.dev, 'tx'), t1 = time();
	let o = sh('P=; for i in 1 2; do head -c ' + int(cap / 2) + ' /dev/zero | curl -4 -s -o /dev/null -m 13 --interface ' + I + ' -X POST -T - https://speed.cloudflare.com/__up & P="$P $!"; done; sleep 2; ' +
		'ping -I ' + I + ' -c 10 -W 1 -q ' + P + ' 2>/dev/null; kill $P 2>/dev/null; wait');
	let s = time() - t1 || 1;
	r.ul = { ms: pavg(o), mbit: int((nbytes(Ln.dev, 'tx') - b1) * 8 / s / 1e5) / 10 };
	let inc = null;
	for (let d in [r.dl, r.ul]) if (d && d.ms != null && r.idle != null) { let x = d.ms - r.idle; if (inc == null || x > inc) inc = x < 0 ? 0 : x; }
	r.inc = inc; r.grade = grade(inc);
	return r;
}
/* rete di sicurezza: prima di toccare sqm o tc i comandi che rimettono lo stato di prima vanno in un file legato a questa
   prova (/tmp/wf-abtest.held.<n>); un ripristino in sottofondo li esegue dopo 200 s (o subito se la sua shell viene
   fermata: trap) se la prova non l'ha già fatto. Chi lo esegue lo sposta prima (mv: uno solo) */
function abguard(cmds) {
	let F = '/tmp/wf-abtest.held.' + time();
	writefile(F, cmds + '\n');
	let R = 'R() { mv ' + F + ' ' + F + '.r 2>/dev/null && { sh ' + F + '.r; rm -f ' + F + '.r; }; }; trap \'R; exit 0\' TERM INT HUP; sleep 200 & wait $!; R';
	sh('( sh -c ' + q(R) + ' ) >/dev/null 2>&1 </dev/null &');
	return F;
}
function abrestore(F) { if (F) sh('mv ' + F + ' ' + F + '.r 2>/dev/null && { sh ' + F + '.r; rm -f ' + F + '.r; } >/dev/null 2>&1'); }
function abtest() {
	let lk = lock('abtest', 300);
	if (!lk) return;
	let Ln = line(), Q = ushow('sqm'), on = filter(keys(Q), (k) => Q[k]['.type'] == 'queue' && Q[k].enabled == '1'), R = { st: 'run', step: 'check', t: time() };
	let fail = (m) => { R.st = 'err'; R.msg = m; R.end = time(); abst(R); rmdir(lk); };
	if (!Ln || !length(Ln.dev)) return fail(L('nessuna linea verso internet', 'no internet line'));
	if (!length(on)) return fail(L('Controllo Della Linea spento: accendilo prima della prova', 'Line Control off: turn it on before the test'));
	/* consumo massimo 250 MB (come dice l'app), diviso tra le 4 misure a carico (senza e con: download e upload, un quarto
	   ciascuna); con il Consumo Della SIM al massimo metà di quello che resta prima della soglia d'avviso, consumo
	   sconosciuto = niente prova */
	let U = rjs('/tmp/wf-usage.json'), quota = +(uo('usage', 'quota') || '0') * 1e9, warn = +(uo('usage', 'warn') || '80'), budget = 250e6;
	if (quota > 0) {
		if (!U) return fail(L('consumo della SIM non ancora letto: riprova tra qualche minuto', 'SIM usage not read yet: try again in a few minutes'));
		let room = quota * warn / 100 - ((U.rx ?? 0) + (U.tx ?? 0));
		if (room < 100e6) return fail(L('soglia del Consumo Della SIM vicina: prova non fatta', 'SIM usage threshold close: test not run'));
		if (room / 2 < budget) budget = int(room / 2);
	}
	/* tre casi, mai una coda provvisoria sul modem (con alcuni driver il router si riavvia):
	   line = regola sulla linea: si ferma e si riaccende quella che c'è;
	   lan  = regola sulla rete di casa con la linea su un modem: si cambia solo lo stato di quella che c'è (il traffico del
	          router non passa dalle code della casa: la prova misura la linea);
	   tmp  = regola sulla rete di casa con una linea che non è un modem (cavo, PPPoE): coda CAKE provvisoria in uscita sulla
	          linea alla velocità di upload della regola, solo upload, tolta subito */
	let S = Q[on[0]], ifc = S.interface ?? '', rx0 = nbytes(Ln.dev, 'rx') + nbytes(Ln.dev, 'tx');
	let modem = match(Ln.proto ?? '', /^(modemmanager|qmi|mbim|ncm|3g|wwan|qcm)$/) != null || match(Ln.dev, /^(wwan|rmnet|mhi|usb)/) != null;
	let mode = ifc == Ln.dev ? 'line' : modem ? 'lan' : 'tmp';
	let arOn = mode != 'tmp' && has('/etc/init.d/cake-autorate') && length(trim(sh('/etc/init.d/cake-autorate running >/dev/null 2>&1 && echo 1'))) > 0;
	/* stato di prima: code CAKE già presenti sull'interfaccia della regola = Controllo Della Linea in funzione */
	let was = match(sh('tc qdisc show dev ' + q(ifc) + ' 2>/dev/null'), /qdisc cake /) != null;
	let ulk = 0, back = '';
	if (mode == 'tmp') {
		let root = match(sh('tc qdisc show dev ' + q(Ln.dev) + ' root 2>/dev/null'), /^qdisc ([a-z_]+)/)?.[1] ?? '';
		if (!match(root, /^(noqueue|fq_codel|mq|pfifo_fast|noop)?$/)) return fail(L('la linea ha già una coda di un altro programma', 'the line already has a queue from another program'));
		let b = match(sh('tc qdisc show dev ' + q(substr('ifb4' + ifc, 0, 15)) + ' 2>/dev/null'), /bandwidth ([0-9]+)([KMG]?)bit/);
		ulk = b ? +b[1] * ({ K: 1, M: 1000, G: 1000000 }[b[2]] ?? 0.001) : +(S.download ?? 0);
		if (!(ulk >= 100)) return fail(L('velocità di upload della regola non trovata', 'rule upload speed not found'));
		back = 'tc qdisc del dev ' + q(Ln.dev) + ' root 2>/dev/null';
	}
	else back = was ? '/etc/init.d/sqm start >/dev/null 2>&1' + (arOn ? '; /etc/init.d/cake-autorate start >/dev/null 2>&1' : '') :
		(arOn ? '/etc/init.d/cake-autorate stop >/dev/null 2>&1; ' : '') + '/etc/init.d/sqm stop >/dev/null 2>&1';
	R.scope = mode == 'tmp' ? 'up' : mode == 'lan' ? 'lan' : 'all';
	let F = null;
	try {
		R.step = 'off'; abst(R);
		F = abguard(back);
		if (mode != 'tmp') sh((arOn ? '/etc/init.d/cake-autorate stop >/dev/null 2>&1; ' : '') + '/etc/init.d/sqm stop >/dev/null 2>&1');
		R.off = abphase(Ln, budget / 4, mode == 'tmp');
		R.step = 'on'; abst(R);
		if (mode == 'tmp') sh('tc qdisc replace dev ' + q(Ln.dev) + ' root cake bandwidth ' + int(ulk) + 'kbit besteffort 2>/dev/null');
		else { sh('/etc/init.d/sqm start >/dev/null 2>&1' + (arOn ? '; /etc/init.d/cake-autorate start >/dev/null 2>&1' : '')); sh('sleep 5'); }
		R.on = abphase(Ln, budget / 4, mode == 'tmp');
	}
	catch (e) { abrestore(F); return fail('' + e); }
	abrestore(F);
	R.st = 'ok'; R.step = 'end'; R.end = time(); R.mb = int((nbytes(Ln.dev, 'rx') + nbytes(Ln.dev, 'tx') - rx0) / 1e6);
	abst(R);
	rmdir(lk);
}

const A = ARGV[0] ?? '';
if (A == 'pubip' || A == 'ip') { let lk = lock('pubip', 60); if (lk) { pubip(A == 'ip' ? 600 : null); rmdir(lk); } }
else if (A == 'name') { let lk = lock('name', 120); if (lk) { namecheck(); rmdir(lk); } }
else if (A == 'log') logadd('' + (ARGV[1] ?? ''), '' + (ARGV[2] ?? ''), match(ARGV[3] ?? '', /^[crn]$/) ? ARGV[3] : 'c');
else if (A == 'run') { let p = filter(crapp(), (x) => x.id == ARGV[1])[0]; if (p) runone(p, 'n'); }
else if (A == 'boot') boot();
else if (A == 'save') { logsave(true); lastsave(true); let H = rjs(IPH); if (H) { H.saved = time(); mkdir('/etc/wrtfreedom'); wjs(IPHE, H); wjs(IPH, H); } }
else if (A == 'abtest') abtest();
else if (A == 'keep') keep('' + (ARGV[1] ?? ''));
else print('uso: ucode svc.uc pubip|name|ip|log <id> <esito> [c|r|n]|run <id>|boot|save|abtest|keep <id>\n');
