#!/bin/sh
# WrtFreedom: Watchdog Della Linea, usato quando sul router non c'è quectel-5g-tools (che ha il suo 5g-watchdog).
# uso: watchdog.sh   controllo continuo (istanza "wd" del servizio wrtfreedom, accesa da wrtfreedom.wd.enabled)
# Impostazioni (uci wrtfreedom.wd): interval (secondi), hosts (indirizzi da provare), fails (prove fallite di fila),
# action (reconnect = riconnetti la linea, modem = riavvia il modem, reboot = riavvia il router).
# Gli interventi finiscono negli Eventi (categoria Linea): avvisi su telefono e Telegram come gli altri eventi.
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh /usr/share/wrtfreedom/event.sh wd "$1" "$2" >/dev/null 2>&1; logger -t wrtfreedom-wd "$2"; }


# interfaccia della linea: quella con la rotta predefinita, altrimenti la prima della zona wan
lineif() {
	i=$(ucode -e 'import { popen } from "fs"; let p = popen("ubus call network.interface dump"), d = json(p.read("all") || "{}"); p.close();
		for (let x in d.interface ?? []) if (x.up) for (let r in x.route ?? []) if (r.target == "0.0.0.0" && r.mask == 0) { print(x.interface); exit(0); }' 2>/dev/null)
	[ -n "$i" ] && { echo "$i"; return; }
	for z in $(uci -q show firewall | sed -n "s/^firewall\.\([^.]*\)\.name='wan'$/\1/p"); do
		for n in $(uci -q get "firewall.$z.network"); do [ "$n" = wan6 ] || { echo "$n"; return; }; done
	done
}
fail=0; last=0
while true; do
	IV=$(uci -q get wrtfreedom.wd.interval); case "$IV" in ''|*[!0-9]*) IV=60;; esac; [ "$IV" -lt 10 ] && IV=10
	H=$(uci -q get wrtfreedom.wd.hosts); [ -n "$H" ] || H="1.1.1.1 8.8.8.8"
	F=$(uci -q get wrtfreedom.wd.fails); case "$F" in ''|*[!0-9]*) F=5;; esac
	A=$(uci -q get wrtfreedom.wd.action); [ -n "$A" ] || A=reconnect
	ok=0
	# stato del controllo della linea (line.sh, 2.42): niente ping doppi; se manca o è vecchio, ping come prima
	# una sola lettura: st (secondi dal 1970), sa (linea in uso), so (internet)
	st=; sa=; so=; eval "$(jsonfilter -i /tmp/wf-line.json -e 'st=@.t' -e 'sa=@.active' -e 'so=@.ok' 2>/dev/null)"
	case "$st" in ''|*[!0-9]*) st=;; esac
	if [ -n "$st" ] && [ $(( $(date +%s) - st )) -lt 10 ] && [ "$sa" = main ]; then
		[ "$so" = true ] && ok=1
	else
		for h in $H; do ping -c 1 -W 3 "$h" >/dev/null 2>&1 && { ok=1; break; }; done
	fi
	# alcuni operatori bloccano il ping: prova anche una pagina web
	[ $ok = 0 ] && wget -q -T 6 -O /dev/null http://connectivitycheck.gstatic.com/generate_204 >/dev/null 2>&1 && ok=1
	if [ $ok = 1 ]; then
		[ $fail -ge $F ] && ev back "✅ $(t "Watchdog: linea tornata" "Watchdog: line is back")"
		fail=0
	else
		fail=$((fail + 1))
		if [ $fail -eq $F ] || { [ $fail -gt $F ] && [ $(( (fail - F) % (F * 3) )) -eq 0 ]; }; then
			now=$(date +%s); up=$(cut -d. -f1 /proc/uptime)
			# riavvio del router al massimo una volta l'ora e mai nei primi 10 minuti dall'accensione
			[ "$A" = reboot ] && { [ "$up" -lt 600 ] || [ $((now - last)) -lt 3600 ]; } && A=reconnect
			last=$now
			case "$A" in
				modem) ev modem "📡 $(t "Watchdog: Internet non risponde, riavvio il modem" "Watchdog: no Internet, restarting the modem")"
					ucode /usr/share/wrtfreedom/modemctl.uc restart >/dev/null 2>&1 ;;
				reboot) ev reboot "🔄 $(t "Watchdog: Internet non risponde, riavvio il router" "Watchdog: no Internet, rebooting the router")"
					sleep 5; reboot ;;
				*) i=$(lineif); ev reconnect "🔁 $(t "Watchdog: Internet non risponde, riconnetto la linea" "Watchdog: no Internet, reconnecting the line")${i:+ ($i)}"
					[ -n "$i" ] && { ifdown "$i"; sleep 3; ifup "$i"; } ;;
			esac
			sleep 120; continue
		fi
	fi
	sleep "$IV"
done
