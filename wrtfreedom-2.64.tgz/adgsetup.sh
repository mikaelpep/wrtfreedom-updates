# WrtFreedom: prima configurazione di AdGuard Home (lavoro in background): dnsmasq sulla 53 inoltra ad AdGuard (2.50)
J=/tmp/.wf-adgset.json; N=/tmp/.wf-adgnew; C=/etc/wrtfreedom/adguard
LOG() { echo "## $*"; }
fail() { LOG "ERRORE $*"; rm -f "$J" "$N"; exit 1; }
if ! command -v curl >/dev/null 2>&1; then
	LOG "Installo curl"
	{ command -v apk >/dev/null && apk add curl; } >/dev/null 2>&1 || { opkg update && opkg install curl; } >/dev/null 2>&1 || fail "curl non disponibile: il router è collegato a internet?"
fi
/etc/init.d/adguardhome enabled 2>/dev/null || /etc/init.d/adguardhome enable
pidof AdGuardHome >/dev/null || { LOG "Avvio AdGuard"; /etc/init.d/adguardhome start; sleep 5; }
WIZ=
for p in 3000 80 8080; do
	[ "$(curl -s -m 4 -o /dev/null -w '%{http_code}' http://127.0.0.1:$p/control/install/get_addresses)" = 200 ] && { WIZ=$p; break; }
done
[ -n "$WIZ" ] || fail "la configurazione iniziale di AdGuard non risponde (è già configurato?)"
WEB=8080
for p in 8080 8081 8088 3001; do netstat -tln 2>/dev/null | grep -q ":$p " || { WEB=$p; break; }; done
# schema di OpenWrt (2.50): dnsmasq resta sulla 53 (DHCP, nomi di casa) e inoltra ad AdGuard su 127.0.0.1 e una porta
# libera; «AdGuard risponde ai dispositivi» (AdGuard sulla 53) si sceglie poi dall'app (metodo adgmode)
DNS=
for p in 3053 5335 15353; do h=$(printf '%04X' $p); grep -qi ":$h " /proc/net/udp /proc/net/udp6 /proc/net/tcp /proc/net/tcp6 2>/dev/null || { DNS=$p; break; }; done
[ -n "$DNS" ] || fail "nessuna porta libera per il DNS di AdGuard"
LAN=$(uci -q get network.lan.ipaddr | cut -d/ -f1); [ -n "$LAN" ] || LAN=192.168.1.1
D=$(uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=dnsmasq$/\1/p" | head -n 1); [ -n "$D" ] || fail "dnsmasq non trovato"
cp /etc/config/dhcp /tmp/.wf-dhcp.bak
LOG "Configuro AdGuard: pannello sulla porta $WEB, DNS su 127.0.0.1:$DNS"
sed -i "s/\"__WEB__\"/$WEB/; s/\"__DNS__\"/$DNS/" "$J"
R=$(curl -s -m 25 -w '\n%{http_code}' -X POST -H 'Content-Type: application/json' --data-binary @"$J" http://127.0.0.1:$WIZ/control/install/configure)
rm -f "$J"
rollback() { /etc/init.d/adguardhome stop; cp /tmp/.wf-dhcp.bak /etc/config/dhcp; /etc/init.d/dnsmasq restart; }
case "$R" in *200) ;; *) rm -f /tmp/.wf-dhcp.bak; fail "AdGuard ha rifiutato la configurazione: $(echo "$R" | head -n 1)" ;; esac
sleep 4
LOG "Server DNS di AdGuard e nomi inversi da dnsmasq"
printf 'user = "%s"\n' "$(cat "$N")" > /tmp/.wf-adgc
curl -s -m 15 -K /tmp/.wf-adgc -X POST -H 'Content-Type: application/json' \
	--data '{"upstream_dns":["https://dns10.quad9.net/dns-query"],"bootstrap_dns":["9.9.9.10","149.112.112.10"],"local_ptr_upstreams":["127.0.0.1:53"],"use_private_ptr_resolvers":true}' \
	http://127.0.0.1:$WEB/control/dns_config >/dev/null
rm -f /tmp/.wf-adgc
LOG "dnsmasq inoltra ad AdGuard (127.0.0.1#$DNS)"
uci -q delete dhcp.$D.port
for s in $(uci -q get dhcp.$D.server); do case "$s" in 127.0.0.1#*|::1#*) uci -q del_list dhcp.$D.server="$s" ;; esac; done
uci add_list dhcp.$D.server="127.0.0.1#$DNS"; uci set dhcp.$D.noresolv=1
uci commit dhcp; /etc/init.d/dnsmasq restart; sleep 2
LOG "Verifico che il DNS risponda"
ok=0; for i in 1 2 3 4 5; do nslookup openwrt.org 127.0.0.1 >/dev/null 2>&1 && { ok=1; break; }; sleep 2; done
if [ $ok = 1 ]; then mkdir -p /etc/wrtfreedom; mv "$N" "$C"; chmod 600 "$C"; LOG "OK pannello $LAN:$WEB"; rm -f /tmp/.wf-dhcp.bak
else rollback; fail "il DNS di AdGuard non risponde: ho rimesso tutto com'era"; fi
