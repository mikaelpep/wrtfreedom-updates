'use strict';

import { popen, readfile, writefile, unlink, stat, lsdir, readlink, mkdir, rename, rmdir } from 'fs';

function sh(cmd) {
	let p = popen(cmd, 'r');
	if (!p)
		return '';
	let out = p.read('all');
	p.close();
	return out ?? '';
}

function js(cmd) {
	let out = sh(cmd);
	if (!length(out))
		return null;
	try {
		return json(out);
	}
	catch (e) {
		return null;
	}
}

function at(c) {
	return sh("sh /usr/share/wrtfreedom/at.sh '" + c + "' 2>/dev/null");
}

function lines(o, key) {
	let r = [];
	for (let l in split(o, '\n'))
		if (index(l, key) >= 0)
			push(r, trim(l));
	return join('\n', r);
}

function okhost(t) {
	return match(t, /^[A-Za-z0-9.:-]{1,253}$/) != null;
}

/* lavoro in background: l'uscita va in /tmp/.wf-job e finisce con __FINE__ */
function job(cmd) {
	writefile('/tmp/.wf-job', '');
	sh('( ( ' + cmd + ' ) > /tmp/.wf-job 2>&1; echo __FINE__ >> /tmp/.wf-job ) >/dev/null 2>&1 </dev/null &');
	return { started: true };
}

function q(s) {
	return "'" + replace('' + s, "'", "'\\''") + "'";
}

/* chiavi (2.52) mai nella riga di comando (visibile in /proc a tutti i processi): file in /tmp/.wf-k (solo root, 0700),
   letto da stdin e tolto subito dal comando che lo usa. kfile = file con il testo; ukey = comando uci batch che imposta
   (o aggiunge, add) l'opzione dal file e lo toglie */
const KD = '/tmp/.wf-k';
function kfile(s) {
	let r = readfile('/dev/urandom', 8) ?? '', n = '';
	for (let i = 0; i < 8; i++) n += sprintf('%02x', ord(r, i) ?? (time() + i) % 256);
	mkdir(KD, 448);
	let f = KD + '/' + n;
	writefile(f, s);
	return f;
}
function ukey(c, s, o, v, add) {
	let f = kfile((add ? 'add_list ' : 'set ') + c + '.' + s + '.' + o + '=' + q(v) + '\n');
	return 'uci -q batch < ' + f + '; rm -f ' + f + '; ';
}

/* modem universale (marche, ModemManager, bande, celle): router/modem.uc */
const M = loadfile(getenv('WF_MODEMUC') ?? '/usr/share/wrtfreedom/modem.uc')();
/* c'è un modem (una sola regola, 2.62: info.modem, la usa anche ai.uc): visto da ModemManager (ultima lettura in
   sottofondo) o dai dispositivi del modem (modem.uc present: cdc-wdm, wwan, ttyUSB, ttyACM, mhi_) */
function hasmodem() { return !!M.id().present; }


const ADGCONF = '/etc/wrtfreedom/adguard';
/* indirizzo dell'interfaccia web di AdGuard Home: secondo campo della prima riga con "address:" dalla riga "http:" in poi
   (come awk '/^http:/{f=1} f&&/address:/{print $2; exit}', senza avviare processi) */
function adgaddr() {
	let f = false;
	for (let l in split(readfile('/etc/adguardhome/adguardhome.yaml') ?? '', '\n')) {
		if (substr(l, 0, 5) == 'http:') f = true;
		if (f && index(l, 'address:') >= 0) return trim(split(trim(l), /[ \t]+/)[1] ?? '') || '192.168.1.1:8080';
	}
	return '192.168.1.1:8080';
}
/* elenco dei pacchetti aggiunti a mano: sopravvive agli aggiornamenti del firmware (/etc/wrtfreedom è conservata).
   pkgs.fw = firmware su cui è stato preso l'elenco: se il firmware è cambiato e mancano pacchetti, l'elenco resta
   com'era finché non sono stati reinstallati (così una modifica nel frattempo non lo perde) */
const FWVER = '. /etc/openwrt_release 2>/dev/null; echo "$DISTRIB_RELEASE $DISTRIB_REVISION"';
/* i file in /etc/wrtfreedom (memoria interna) si riscrivono solo se cambiano: pkgs.fw dentro l'if c'è già uguale a $V */
const PKGSNAP = "mkdir -p /etc/wrtfreedom; V=$(" + FWVER + "); if [ ! -f /etc/wrtfreedom/pkgs.fw ] || [ \"$(cat /etc/wrtfreedom/pkgs.fw)\" = \"$V\" ]; then T=/tmp/.wf-pkgs.$$; { if command -v apk >/dev/null 2>&1; then cat /etc/apk/world; else awk '/^Package:/{p=$2} /^Status:.*user installed/{print p}' /usr/lib/opkg/status; fi; } 2>/dev/null | sort -u > $T; cmp -s $T /etc/wrtfreedom/pkgs.txt || cat $T > /etc/wrtfreedom/pkgs.txt; rm -f $T; [ -f /etc/wrtfreedom/pkgs.fw ] || echo \"$V\" > /etc/wrtfreedom/pkgs.fw; fi";
/* come FWVER ma senza avviare la shell: solo se /etc/openwrt_release ha righe semplici NOME='valore' (com'è di serie),
   altrimenti (virgolette doppie, variabili…) lo legge la shell come prima */
function fwver() {
	let o = readfile('/etc/openwrt_release'), V = {};
	if (o == null) return '';
	for (let l in split(o, '\n')) {
		if (match(l, /^[ \t]*(#.*)?$/)) continue;
		let m = match(l, /^([A-Za-z_][A-Za-z0-9_]*)='([^']*)'[ \t]*$/);
		if (!m) return trim(sh(FWVER));
		V[m[1]] = m[2];
	}
	return (V.DISTRIB_RELEASE ?? '') + ' ' + (V.DISTRIB_REVISION ?? '');
}
/* pacchetti installati, compresi quelli che un altro fornisce (dnsmasq-full fornisce dnsmasq) */
/* comando dell'installazione (pkgdo add e, 2.64 B7, updsafe install: lì UPGNO rifiuta dnsmasq.*, quindi dnsmasq-full passa
   solo da pkgdo add): apk (OpenWrt 25) o opkg, poi l'elenco dei pacchetti aggiunti; SQM appena installato: la sua regola
   sulla linea verso internet (sqmline.sh, 2.44), non su eth1 di serie */
/* 2.64 B8: dnsmasq-full prende il posto di dnsmasq (in conflitto). Senza dnsmasq il router non trova più i nomi e la casa
   resta senza DNS e DHCP: prima si salva la configurazione (/etc/config/dhcp). opkg: i due pacchetti scaricati, le
   dipendenze, poi in un solo comando via dnsmasq e dentro dnsmasq-full dal file; se non riesce torna dnsmasq dal suo file.
   apk: lo scambio è un solo giro di apk (dnsmasq-full con il divieto «!dnsmasq»: o riesce tutto o non cambia niente), poi il
   divieto si toglie da /etc/apk/world; senza nessuno dei due si rimette dnsmasq. Alla fine la configurazione di prima */
const DMQ = '/tmp/wf-dnsmasq';
function dmqfull(apk) {
	if (apk)
		return 'if grep -qx "P:dnsmasq" /lib/apk/db/installed 2>/dev/null; then rm -rf ' + DMQ + '; mkdir -p ' + DMQ + ' && cp /etc/config/dhcp ' + DMQ + '/dhcp && ' +
			'{ apk add dnsmasq-full "!dnsmasq" || echo "dnsmasq-full non installato: dnsmasq resta"; sed -i "/^!dnsmasq$/d" /etc/apk/world 2>/dev/null; ' +
			'grep -qx "P:dnsmasq-full" /lib/apk/db/installed || grep -qx "P:dnsmasq" /lib/apk/db/installed || { echo "rimetto dnsmasq"; apk add dnsmasq; }; ' +
			'cp ' + DMQ + '/dhcp /etc/config/dhcp; /etc/init.d/dnsmasq enable; /etc/init.d/dnsmasq restart; }; rm -rf ' + DMQ + '; ' +
			'else apk add dnsmasq-full; fi';
	return 'if opkg list-installed | grep -q "^dnsmasq "; then rm -rf ' + DMQ + '; mkdir -p ' + DMQ + ' && cp /etc/config/dhcp ' + DMQ + '/dhcp && ( cd ' + DMQ + ' && opkg download dnsmasq-full && opkg download dnsmasq ) && ' +
		'{ DEP=$(opkg info dnsmasq-full | sed -n "s/^Depends: //p" | head -n 1 | tr "," "\\n" | sed "s/^ *//; s/ .*//" | grep -v "^dnsmasq"); [ -z "$DEP" ] || opkg install $DEP; } && ' +
		'{ { opkg remove dnsmasq && opkg install ' + DMQ + '/dnsmasq-full_*.ipk; } || { echo "dnsmasq-full non installato: rimetto dnsmasq"; opkg install ' + DMQ + '/dnsmasq_*.ipk; }; ' +
		'cp ' + DMQ + '/dhcp /etc/config/dhcp; /etc/init.d/dnsmasq enable; /etc/init.d/dnsmasq restart; } || echo "dnsmasq-full non scaricato: dnsmasq resta"; rm -rf ' + DMQ + '; ' +
		'else opkg install dnsmasq-full; fi';
}
function pkgaddc(n, apk) {
	let full = match(n, /(^| )dnsmasq-full( |$)/) != null, rest = full ? trim(replace(n, /(^| )dnsmasq-full( |$)/g, ' ')) : n;
	let c = apk ? 'apk update >/dev/null 2>&1' + (full ? '; ' + dmqfull(true) : '') + (length(rest) ? '; apk add ' + rest : '') :
		'opkg update >/dev/null 2>&1' + (full ? '; ' + dmqfull(false) : '') + (length(rest) ? '; opkg install ' + rest : '');
	return c + '; ' + PKGSNAP + (match(n, /(^| )sqm-scripts( |$)/) ? '; sh /usr/share/wrtfreedom/sqmline.sh sqm' : '');
}
function pkgHave() {
	let H = {}, apk = stat('/lib/apk/db/installed') != null;
	for (let l in split(readfile(apk ? '/lib/apk/db/installed' : '/usr/lib/opkg/status') ?? '', '\n')) {
		if (apk && substr(l, 0, 2) == 'P:') H[trim(substr(l, 2))] = true;
		else if (apk && substr(l, 0, 2) == 'p:') { for (let t in split(trim(substr(l, 2)), ' ')) if (length(t)) H[replace(t, /[<>=~].*$/, '')] = true; }
		else if (!apk && substr(l, 0, 9) == 'Package: ') H[trim(substr(l, 9))] = true;
		else if (!apk && substr(l, 0, 10) == 'Provides: ') { for (let t in split(substr(l, 10), ',')) H[replace(trim(t), /[ (].*$/, '')] = true; }
	}
	if (!length(keys(H)))
		for (let l in split(sh("if command -v apk >/dev/null 2>&1; then apk info 2>/dev/null; else opkg list-installed 2>/dev/null | cut -d' ' -f1; fi"), '\n'))
			if (length(l)) H[trim(l)] = true;
	return H;
}

/* ---------- Telegram ---------- */
function urlenc(s) {
	s = '' + s;
	let o = '';
	for (let i = 0; i < length(s); i++) {
		let c = ord(s, i);
		if ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 46 || c == 95 || c == 126)
			o += chr(c);
		else
			o += sprintf('%%%02X', c);
	}
	return o;
}
/* configurazione letta direttamente dal file /etc/config/<nome>, senza avviare processi (prima: un "uci get" per ogni
   opzione, fino a 700 processi per una richiesta). Restituisce { sezione: { '.type': tipo, opzione: valore } }; le liste
   sono array; le sezioni senza nome si chiamano @tipo[n] come in uci. Le modifiche non ancora salvate non ci sono,
   come per i servizi del router. */
function uval(v) {
	v = trim(v ?? '');
	let c = substr(v, 0, 1), o = '', i = 1, n = length(v);
	if (c == "'") {
		/* 'testo' con eventuali apici scritti come '\'' */
		while (i < n) {
			let ch = substr(v, i, 1);
			if (ch == "'") { if (substr(v, i, 4) == "'\\''") { o += "'"; i += 4; continue; } break; }
			o += ch; i++;
		}
		return o;
	}
	if (c == '"') {
		while (i < n) {
			let ch = substr(v, i, 1);
			if (ch == '\\') { o += substr(v, i + 1, 1); i += 2; continue; }
			if (ch == '"') break;
			o += ch; i++;
		}
		return o;
	}
	return split(v, /[ \t]+/)[0] ?? '';
}
/* la riga finisce dentro un testo tra apici? (un valore può andare a capo, es. un comando di più righe) */
function uopen(l) {
	/* senza apici non può restare aperto niente: si salta il controllo carattere per carattere (quasi tutte le righe) */
	if (index(l, "'") < 0 && index(l, '"') < 0) return false;
	let sq = false, dq = false;
	for (let i = 0; i < length(l); i++) {
		let ch = substr(l, i, 1);
		if (sq) { if (ch == "'") sq = false; }
		else if (dq) { if (ch == '\\') i++; else if (ch == '"') dq = false; }
		else if (ch == '\\') i++;
		else if (ch == "'") sq = true;
		else if (ch == '"') dq = true;
		else if (ch == '#') break;
	}
	return sq || dq;
}
/* ultima lettura di ogni file: si riusa finché il file è lo stesso (inode, data, dimensione) e se è stato letto in un
   secondo successivo all'ultima modifica (la data dei file ha i secondi: una modifica nello stesso secondo della lettura
   non si vedrebbe). Chi chiama ucfile() non deve modificare l'oggetto restituito. */
let UCF = {};
function ucfile(name) {
	let cf = (getenv('WF_CFGDIR') ?? '/etc/config/') + name, cst = stat(cf), ct = time();
	let ck = cst ? cst.inode + ':' + cst.mtime + ':' + cst.size : '', cc = UCF[cf];
	if (cc && length(ck) && cc.k == ck && cst.mtime < cc.t) return cc.r;
	let r = {}, cur = null, cnt = {}, buf = null;
	for (let l in split(readfile(cf) ?? '', '\n')) {
		if (buf != null) { l = buf + '\n' + l; buf = null; }
		if (uopen(l)) { buf = l; continue; }
		let m = match(l, /^[ \t]*(config|option|list)[ \t]+([^ \t]+)/);
		if (!m) continue;
		m[4] = trim(substr(l, length(m[0])));
		if (m[1] == 'config') {
			let t = uval(m[2]), n = length(m[4]) ? uval(m[4]) : '';
			cnt[t] = (cnt[t] ?? -1) + 1;
			if (!length(n)) n = '@' + t + '[' + cnt[t] + ']';
			cur = r[n] = r[n] ?? { '.type': t };
		}
		else if (cur) {
			let k = uval(m[2]), v = uval(m[4]);
			if (m[1] == 'list') { if (type(cur[k]) != 'array') cur[k] = []; push(cur[k], v); }
			else cur[k] = v;
		}
	}
	if (length(ck)) UCF[cf] = { k: ck, t: ct, r: r };
	return r;
}
function ug(c, sec, opt) {
	let x = (type(c) == 'string' ? ucfile(c) : c)[sec];
	let v = x ? x[opt] : null;
	return v == null ? '' : (type(v) == 'array' ? join(' ', v) : '' + v);
}
/* chiamate ubus verso netifd, procd, hostapd (mai verso rpcd stesso): con il modulo ubus di ucode se c'è, altrimenti il comando */
let UBC = null;
function ubcall(obj, m, a) {
	if (UBC == null) { try { UBC = require('ubus').connect() ?? false; } catch (e) { UBC = false; } }
	if (UBC) {
		let r = UBC.call(obj, m, a ?? {});
		if (r != null) return r;
	}
	return js('ubus call ' + obj + ' ' + m + (a ? ' ' + q(sprintf('%J', a)) : '') + ' 2>/dev/null');
}
function has(p) { return stat(p) != null; }
/* zone del firewall: casa = quella che contiene la rete lan (altrimenti la prima senza NAT che accetta in ingresso),
   internet = quella con il mascheramento NAT (nomi veri) */
function fwzones() {
	let F = ucfile('firewall'), home = null, wan = null, alt = null;
	for (let k in F) {
		let z = F[k];
		if (z['.type'] != 'zone' || !z.name) continue;
		let nets = type(z.network) == 'array' ? z.network : split(z.network ?? '', ' '), masq = z.masq == '1' || z.masq == 'true';
		if (!home && index(nets, 'lan') >= 0) home = z.name;
		if (!alt && !masq && z.name != 'vpnout' && z.input == 'ACCEPT') alt = z.name;
		if (!wan && z.name != 'vpnout' && masq) wan = z.name;	/* vpnout: zona del Servizio VPN */
	}
	/* nowan/nohome: zona vera mancante (fwd non apre porte su nomi di ripiego) */
	return { home: home ?? alt ?? 'lan', wan: wan ?? 'wan', nowan: wan == null, nohome: (home ?? alt) == null };
}
/* lingua scelta nell'app: messaggi su Telegram in italiano o in inglese */
function L(it, en) {
	return ug('wrtfreedom', 'ui', 'lang') == 'en' ? en : it;
}
/* Telegram e Comandi Pronti: dopo ucfile/ug/has/L, che usano (ucode recente non accetta funzioni usate prima
   della loro definizione: «access to undeclared variable», ubus 9 su tgsend) */
function cfgensure() {
	if (stat('/etc/config/wrtfreedom') == null) writefile('/etc/config/wrtfreedom', '');
}
/* Telegram (2.62): indirizzo con il token e campi (testo compreso) in un file per curl -K (kfile, cartella 0700), mai
   sulla riga di comando né nell'indirizzo; senza curl niente invio. F = [[opzione di curl, valore]]: data, form, form-string */
const CURLE = 'serve il pacchetto curl: installalo da Software';
function curlok() { return has('/usr/bin/curl') || has('/usr/sbin/curl') || has('/bin/curl') || has('/sbin/curl'); }
function curlq(s) { return '"' + replace(replace(replace(replace('' + s, /\\/g, () => '\\\\'), /"/g, () => '\\"'), /\n/g, () => '\\n'), /\r/g, () => '\\r') + '"'; }
function tgk(token, method, F) {
	let t = 'url = ' + curlq('https://api.telegram.org/bot' + token + '/' + method) + '\n';
	for (let x in F ?? []) t += x[0] + ' = ' + curlq(x[1]) + '\n';
	return kfile(t);
}
function tgreq(token, method, params) {
	if (!curlok()) return null;
	let qs = [];
	for (let k in (params ?? {}))
		push(qs, k + '=' + urlenc(params[k]));
	let f = tgk(token, method, length(qs) ? [ [ 'data', join('&', qs) ] ] : []);
	let r = js('curl -s -m 20 -K ' + f + ' 2>/dev/null');
	unlink(f);
	return r;
}
/* lavoro staccato da rpcd (2.62): nuova sessione (start-stop-daemon -b, altrimenti setsid), il metodo torna subito; pid in
   /tmp/wf-bg.<tag>.pid finché lavora. false = lo stesso lavoro è già in corso */
function detach(tag, c) {
	let pf = '/tmp/wf-bg.' + tag + '.pid', p = trim(readfile(pf) ?? '');
	if (match(p, /^[0-9]{1,10}$/) && has('/proc/' + p)) return false;
	c = 'echo $$ > ' + pf + '; ' + c + '; rm -f ' + pf;
	if (has('/sbin/start-stop-daemon')) sh('start-stop-daemon -S -b -m -p ' + pf + ' -x /bin/sh -- -c ' + q(c) + ' </dev/null >/dev/null 2>&1');
	else if (has('/usr/bin/setsid') || has('/bin/setsid')) sh('setsid sh -c ' + q(c) + ' </dev/null >/dev/null 2>&1 &');
	else sh('( sh -c ' + q(c) + ' ) </dev/null >/dev/null 2>&1 &');
	return true;
}
function tgsave(t, c, b) {
	if (!match(t, /^[0-9]{5,15}:[A-Za-z0-9_-]{20,60}$/) || !match(c, /^-?[0-9]{1,20}$/) || !match(b, /^[A-Za-z0-9_]{0,64}$/))
		return { error: 'dati non validi' };
	if (c == split(t, ':')[0]) return { error: 'bot_id' };
	if (!curlok()) return { error: CURLE };
	let r = tgreq(t, 'sendMessage', { chat_id: c, text: L('✅ WrtFreedom è collegato: da qui arriveranno gli avvisi del router.', '✅ WrtFreedom is connected: router alerts will arrive here.') });
	if (!r || !r.ok) return { error: (r && r.description) || 'Telegram non risponde: il router è collegato a internet?' };
	cfgensure();
	sh('uci set wrtfreedom.tg=tg; uci set wrtfreedom.tg.token=' + q(t) + '; uci set wrtfreedom.tg.chat=' + q(c) + '; uci set wrtfreedom.tg.bot=' + q(b) + '; uci commit wrtfreedom');
	return { ok: true, bot: b, chat: c };
}
/* Comandi Pronti: catalogo nelle righe "#%" (categorie) e "#@" (comandi) di tgpresets.sh */
const TGP = '/usr/share/wrtfreedom/tgpresets.sh';
function tgcatalog() {
	let cats = [], cmds = [];
	for (let l in split(readfile(TGP) ?? '', '\n')) {
		if (substr(l, 0, 3) == '#% ') { let f = split(substr(l, 3), '|'); push(cats, { id: f[0], it: f[1], en: f[2], icon: f[3] }); }
		else if (substr(l, 0, 3) == '#@ ') {
			let f = split(substr(l, 3), '|');
			push(cmds, { n: f[0], en: f[1], cat: f[2], fl: f[3], need: filter(split(f[4], ','), length), it: f[5], den: f[6], ait: f[7], aen: f[8] });
		}
		else if (length(cmds) && substr(l, 0, 1) != '#') break;
	}
	return { cats: cats, cmds: cmds };
}
/* nomi dei Comandi Utente: chi ha lo stesso nome di un Comando Pronto prende il suo posto */
function tgusernames(W) {
	let r = {};
	W = W ?? ucfile('wrtfreedom');
	for (let k in W) if (W[k]['.type'] == 'tgcmd' && match(W[k].name ?? '', /^[a-z0-9_]+$/)) r[W[k].name] = true;
	return r;
}
function tgconf() {
	let W = ucfile('wrtfreedom');
	return { token: ug(W, 'tg', 'token'), chat: ug(W, 'tg', 'chat') };
}

/* ---------- WireGuard ---------- */
/* WireGuard automatico: indirizzo da fuori, DNS, porta e rete libere */
/* indirizzo della linea: prima interfaccia accesa della zona internet vera (quella con il NAT, mai il nome «wan» fisso) */
function wanip() {
	let F = ucfile('firewall'), wz = fwzones().wan, nets = {};
	for (let z in F) if (F[z]['.type'] == 'zone' && F[z].name == wz) for (let n in (type(F[z].network) == 'array' ? F[z].network : split(F[z].network ?? '', ' '))) nets[n] = true;
	for (let i in ((ubcall('network.interface', 'dump') ?? {}).interface ?? []))
		if (nets[i.interface] && length(i['ipv4-address'] ?? [])) return i['ipv4-address'][0].address;
	return '';
}
/* IP privato o CGNAT (la VPN Per Fuori Casa non si raggiunge da fuori) */
function privip(ip) {
	return match('' + ip, /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.)/) != null;
}
/* indirizzo da fuori: primo nome DDNS di un servizio acceso, altrimenti l'IP della linea */
function wgautohost() {
	let d = '', Dd = ucfile('ddns');
	for (let k in Dd) if (!length(d) && Dd[k]['.type'] == 'service' && Dd[k].enabled != '0' && length(Dd[k].lookup_host ?? '')) d = Dd[k].lookup_host;
	if (length(d)) return { host: d, how: 'ddns' };
	let ip = wanip();
	return { host: ip, how: 'ip', cgnat: privip(ip) };
}
/* porta UDP libera: nessun socket in ascolto (letto da /proc, senza processi) */
function udpfree(p) {
	let h = ':' + sprintf('%04X', +p) + ' ';
	return index(uc((readfile('/proc/net/udp') ?? '') + (readfile('/proc/net/udp6') ?? '')), h) < 0;
}
function wgautonet() {
	let used = '', N = ucfile('network');
	for (let k in N) used += ' ' + join(' ', type(N[k].ipaddr) == 'array' ? N[k].ipaddr : [N[k].ipaddr ?? '']) + ' ' + join(' ', type(N[k].addresses) == 'array' ? N[k].addresses : [N[k].addresses ?? '']);
	for (let b = 8; b < 40; b++)
		if (index(used, ' 10.' + b + '.0.') < 0) return '10.' + b + '.0.1/24';
	return '10.99.0.1/24';
}

/* interfacce del Servizio VPN (wgout, wgo1…): non sono la WireGuard dell'utente (che può chiamarsi anche wgoffice) */
const VPNIFRX = /^wgo(ut|[0-9]+)$/;
function wgiface(N) {
	N = N ?? ucfile('network');
	let L = filter(keys(N), (k) => N[k]['.type'] == 'interface' && N[k].proto == 'wireguard' && !match(k, VPNIFRX));	/* senza il Servizio VPN */
	for (let i in L)
		if (length(N[i].listen_port ?? '')) return i;
	return L[0];
}

/* riavvio del modem: uno solo per tutti (modem.uc: ModemManager se c'è, altrimenti AT+CFUN=1,1) */
const MODEMRESET = "( ucode /usr/share/wrtfreedom/modemctl.uc restart ) >/dev/null 2>&1 </dev/null &";

/* AdGuard Home in sottofondo: stato e statistiche finiscono in /tmp/wf-adg.json (letto da snapshot senza attese);
   pre = comando da eseguire prima (es. accendere o spegnere la protezione) */
function adgbg(pre) {
	let cred = trim(readfile(ADGCONF) ?? '');
	if (!length(cred)) return false;
	writefile('/tmp/.wf-adgk', 'user = "' + cred + '"\n');
	sh('chmod 600 /tmp/.wf-adgk; touch /tmp/wf-adg.ts');
	let port = adgaddr();
	let c = 'curl -s -m 8 -K /tmp/.wf-adgk ', u = 'http://' + port + '/control/';
	let p = pre ? c + "-X POST -H 'Content-Type: application/json' --data '{\"enabled\":" + (pre == 'on' ? 'true' : 'false') + "}' " + u + 'protection >/dev/null; ' : '';
	sh('( ' + p + 's=$(' + c + u + 'status); t=$(' + c + u + 'stats); rm -f /tmp/.wf-adgk; [ -n "$s" ] && printf \'{"s":%s,"t":%s}\' "$s" "${t:-null}" > /tmp/wf-adg.json ) >/dev/null 2>&1 </dev/null &');
	return true;
}

function lc_(x) { return lc('' + x); }

/* registro degli eventi: in memoria, o sul disco se l'utente l'ha scelto */
function evlog() { return ug('wrtfreedom', 'ev', 'persist') == '1' ? '/etc/wrtfreedom/events.log' : '/tmp/wf-events.log'; }
/* ultime n righe di un file piccolo, senza "tail" */
function lastlines(f, n) {
	let L = filter(split(readfile(f) ?? '', '\n'), length);
	return slice(L, length(L) > n ? length(L) - n : 0);
}

/* modem letto in sottofondo (comandi AT e ModemManager sono lenti): chi chiede riceve subito l'ultima lettura
   e, se è più vecchia di 15 secondi, ne parte un'altra per la volta dopo */
function modembg(I) {
	/* modem non ancora riconosciuto (prima lettura): si riprova dopo 3 secondi invece di 15.
	   I = M.id() appena letto da chi chiama (è quello che c'è in /tmp/wf-modem.id), altrimenti si legge il file */
	let ts = stat('/tmp/wf-modem.ts'), I0 = I ?? json(readfile('/tmp/wf-modem.id') ?? 'null');
	if (ts && time() - ts.mtime < ((I0?.mm || I0?.vendor) ? 15 : 3)) return;
	/* comandi AT della marca riconosciuta (modem.uc); senza marca solo ModemManager. Le letture extra di ModemManager:
	   celle (--get-cell-info, dalla 1.20, modem QMI o MBIM) e segnale (--signal-get, va acceso una volta) */
	sh('( ' + M.readcmd() + ' ) >/dev/null 2>&1 </dev/null &');
}

/* quectel-5g-tools (5g-lock, 5g-info, 5g-watchdog): se c'è, blocco cella e watchdog usano i suoi strumenti;
   altrimenti il pacchetto fa lo stesso con i comandi AT (modem Quectel) e con watchdog.sh */
function q5gtools() {
	for (let d in [ '/usr/bin/', '/usr/sbin/', '/bin/', '/sbin/' ]) if (has(d + '5g-lock')) return true;
	return false;
}
/* ---------------- Servizio VPN (2.42) ----------------
   Il router come client WireGuard di uno o più servizi VPN (NordVPN, Mullvad, PIA con collegamento automatico;
   Proton, Surfshark e gli altri con il file .conf). Ogni «collegamento» (sezione vpntun) usa un server (sezione
   vpnprof) e ha la sua interfaccia e tabella: il principale (n 0) wgout / tabella 100 per tutta la casa, solo alcuni
   dispositivi o tutti tranne alcuni; gli altri (n 1…5) wgoN / tabella 100+N per dispositivi scelti, che così escono
   da un altro paese. Il router stesso resta sulla linea (accesso da fuori, VPN verso casa, DDNS, porte aperte).
   Account dei servizi automatici: sezioni vpnacc (va_nord token+key, va_mullvad account+priv+addr, va_pia user+pass+priv).
   Opzioni comuni in wrtfreedom.vpnout: kill (blocco se la VPN cade), auto (ricollegamento), dns adg|vpn, guest,
   dnsips (server DNS del router che passano dal principale). Priorità delle regole: 900 reti locali (main senza
   rotta predefinita), 940/941 dispositivi dei collegamenti in più (tabella, poi blocco), 950 esclusi dal principale
   (main), 1000/1001 origini del principale (tabella 100, poi blocco), 1000 server DNS del router, 1002 «oif»: il
   traffico del router legato all'interfaccia (curl --interface: IP pubblico, controllo DNS) esce dal collegamento.
   fb del collegamento = server che non risponde con il blocco spento: regole tolte finché torna (vpnctl.uc).
   Dispositivi riconosciuti dal MAC (2.53), non dall'IP: la catena wf_vpnmac (fw4, VPNMACF) marca i pacchetti IPv4 che
   entrano dalle reti di casa e ospiti con «ether saddr» e una marca per collegamento nei bit VPNMM (n + 1, esclusi di
   «Tutti Tranne» VPNMX), lontani da 0x00e10000 (Eccezioni Per Sito) e dalle marche di mwan3/pbr; le regole di
   instradamento e il blocco vanno per marca (fwmark/maschera). Senza fw4 (nftables.d) restano le regole per IP. */
const VPNKEY = /^[A-Za-z0-9+\/]{42,43}=$/, VPNDNSF = '/usr/share/nftables.d/chain-pre/dstnat/40-wrtfreedom-vpndns.nft';
const VPNMACF = '/usr/share/nftables.d/table-post/42-wrtfreedom-vpnmac.nft', VPNMM = 0x0f000000, VPNMX = 0x0f000000;
/* toglie tutto il Servizio VPN da network (solo i suoi nomi: wgout/wgoN con _peer e _rt, regole wgout_rN e wgout_main) e
   da firewall (wgout_*), più i file del DNS e dei MAC; usato da vpnbuild e da «del» (uguale in uninstall.sh) */
const VPNDEL = 'for s in $(uci -q show network | sed -nE "s/^network\\.(wgo(ut|[0-9]+)(_peer|_rt)?|wgout_(r[0-9]+|main))=.*/\\1/p"); do uci -q delete network.$s; done; ' +
	'for s in $(uci -q show firewall | sed -nE "s/^firewall\\.(wgout_[A-Za-z0-9_]+)=.*/\\1/p"); do uci -q delete firewall.$s; done; rm -f ' + VPNDNSF + ' ' + VPNMACF + '; ';
/* copia per il ritorno automatico del Servizio VPN (2.52): solo le sue sezioni (le stesse di VPNDEL, più collegamenti,
   server e opzioni in wrtfreedom); la VPN Per Fuori Casa, le Eccezioni Per Sito e il resto restano come sono */
const VPNBAK = { network: { n: 'wgo(ut|[0-9]+)(_peer|_rt)?|wgout_(r[0-9]+|main)' }, firewall: { n: 'wgout_[A-Za-z0-9_]+' }, wrtfreedom: { t: 'vpnout|vpntun|vpnprof' } };
function vpnparse(conf) {
	/* file .conf: [Interface] PrivateKey, Address, DNS, MTU · [Peer] PublicKey, PresharedKey, Endpoint */
	let sec = '', I = {}, P = {};
	for (let l in split('' + (conf ?? ''), '\n')) {
		l = trim(replace(l, /#.*$/, ''));
		let m = match(l, /^\[(.+)\]$/);
		if (m) { sec = lc(m[1]); continue; }
		let kv = match(l, /^([A-Za-z]+) *= *(.+)$/);
		if (!kv) continue;
		if (sec == 'interface') I[lc(kv[1])] = trim(kv[2]); else if (sec == 'peer' && !P[lc(kv[1])]) P[lc(kv[1])] = trim(kv[2]);
	}
	/* Endpoint «nome:porta» o «[IPv6]:porta», diviso all'ultimo «:» (le regex di ucode sono POSIX: niente +?) */
	let e0 = '' + (P.endpoint ?? ''), ei = rindex(e0, ':'), host = null, port = null;
	if (ei > 0) { host = replace(substr(e0, 0, ei), /^\[|\]$/g, ''); port = substr(e0, ei + 1); }
	let ok4 = (x) => match(x, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/);
	let addr = filter(map(split(I.address ?? '', ','), (x) => trim(x)), (x) => match(x, /^[0-9a-fA-F.:]+\/[0-9]{1,3}$/));
	let dns = filter(map(split(I.dns ?? '', ','), (x) => trim(x)), ok4);
	if (!match(I.privatekey ?? '', VPNKEY) || !match(P.publickey ?? '', VPNKEY) || !match(host ?? '', /^[A-Za-z0-9.:-]{1,253}$/) || !match(port ?? '', /^[0-9]{1,5}$/) || !length(addr))
		return { error: 'file .conf non valido: servono PrivateKey, Address, PublicKey ed Endpoint' };
	if (P.presharedkey && !match(P.presharedkey, VPNKEY)) return { error: 'PresharedKey non valida' };
	return { priv: I.privatekey, addr: addr, dns: dns, mtu: match(I.mtu ?? '', /^[0-9]{3,4}$/) ? I.mtu : '', pub: P.publickey, psk: P.presharedkey ?? '', host: host, port: port };
}
function vpnarr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }
function vpnprofs(W) {
	let r = {};
	for (let k in W) if (W[k]['.type'] == 'vpnprof') {
		let p = W[k];
		r[k] = { id: k, lib: p.lib == '1', name: p.name ?? '', prov: p.prov ?? (p.src == 'nord' ? 'nord' : 'other'), place: p.place ?? p.cid ?? '', cc: p.cc ?? '', city: p.city ?? '', sname: p.sname ?? '', srvid: p.srvid ?? '',
			priv: p.priv ?? '', addr: vpnarr(p.addr), dns: vpnarr(p.dns), mtu: p.mtu ?? '', pub: p.pub ?? '', psk: p.psk ?? '', host: p.host ?? '', port: p.port ?? '', added: +(p.added ?? 0) };
	}
	return r;
}
function vpntuns(W) {
	let r = [];
	for (let k in W) if (W[k]['.type'] == 'vpntun') {
		let t = W[k], n = +(t.n ?? 0);
		push(r, { id: k, n: n, prof: t.prof ?? '', on: t.on != '0', mode: n == 0 ? (t.mode == 'dev' || t.mode == 'except' ? t.mode : 'all') : 'dev', devs: vpnarr(t.devs), fb: t.fb == '1' });
	}
	return sort(r, (a, b) => a.n - b.n);
}
function vpnif(n) { return n == 0 ? 'wgout' : 'wgo' + n; }
/* luogo del server VPN in italiano («Zurigo, Svizzera»): nomi più comuni delle città e paesi dal codice; un nome che
   non è in tabella resta com'è, un paese che manca resta col codice («Città (XX)»). Stessa tabella in netx.uc (processo a parte) */
const VPNCITY = { zurich: 'Zurigo', geneva: 'Ginevra', london: 'Londra', paris: 'Parigi', brussels: 'Bruxelles', frankfurt: 'Francoforte',
	munich: 'Monaco Di Baviera', berlin: 'Berlino', hamburg: 'Amburgo', cologne: 'Colonia', prague: 'Praga', warsaw: 'Varsavia', lisbon: 'Lisbona',
	barcelona: 'Barcellona', copenhagen: 'Copenaghen', stockholm: 'Stoccolma', athens: 'Atene', bucharest: 'Bucarest', belgrade: 'Belgrado',
	dublin: 'Dublino', edinburgh: 'Edimburgo', rome: 'Roma', milan: 'Milano', turin: 'Torino', naples: 'Napoli', florence: 'Firenze',
	venice: 'Venezia', moscow: 'Mosca', kyiv: 'Kiev', marseille: 'Marsiglia', lyon: 'Lione', strasbourg: 'Strasburgo', luxembourg: 'Lussemburgo',
	ljubljana: 'Lubiana', zagreb: 'Zagabria', 'mexico city': 'Città Del Messico', 'sao paulo': 'San Paolo', 'são paulo': 'San Paolo',
	'cape town': 'Città Del Capo', philadelphia: 'Filadelfia', 'new york': 'New York', 'tel aviv': 'Tel Aviv',
	antwerp: 'Anversa', seville: 'Siviglia', nuremberg: 'Norimberga', basel: 'Basilea', bern: 'Berna', lucerne: 'Lucerna',
	krakow: 'Cracovia', gdansk: 'Danzica', thessaloniki: 'Salonicco', valletta: 'La Valletta', gothenburg: 'Göteborg', kiev: 'Kiev',
	'saint petersburg': 'San Pietroburgo', 'st petersburg': 'San Pietroburgo', seoul: 'Seul', beijing: 'Pechino', 'new delhi': 'Nuova Delhi',
	cairo: 'Il Cairo', jerusalem: 'Gerusalemme', bogota: 'Bogotà', montreal: 'Montréal' };
const VPNCC = { CH: 'Svizzera', IT: 'Italia', DE: 'Germania', FR: 'Francia', GB: 'Regno Unito', UK: 'Regno Unito', US: 'Stati Uniti',
	NL: 'Paesi Bassi', BE: 'Belgio', AT: 'Austria', ES: 'Spagna', PT: 'Portogallo', SE: 'Svezia', NO: 'Norvegia', DK: 'Danimarca',
	FI: 'Finlandia', PL: 'Polonia', CZ: 'Repubblica Ceca', SK: 'Slovacchia', HU: 'Ungheria', RO: 'Romania', BG: 'Bulgaria', GR: 'Grecia',
	IE: 'Irlanda', LU: 'Lussemburgo', SI: 'Slovenia', HR: 'Croazia', RS: 'Serbia', AL: 'Albania', EE: 'Estonia', LV: 'Lettonia',
	LT: 'Lituania', IS: 'Islanda', CY: 'Cipro', MT: 'Malta', MD: 'Moldavia', UA: 'Ucraina', TR: 'Turchia', RU: 'Russia', CA: 'Canada',
	MX: 'Messico', BR: 'Brasile', AR: 'Argentina', CL: 'Cile', JP: 'Giappone', KR: 'Corea Del Sud', SG: 'Singapore', HK: 'Hong Kong',
	IN: 'India', AU: 'Australia', NZ: 'Nuova Zelanda', ZA: 'Sudafrica', IL: 'Israele', AE: 'Emirati Arabi Uniti' };
function vpnplace(city, cc) {
	cc = uc('' + (cc ?? ''));
	let c = VPNCITY[lc(trim('' + (city ?? '')))] ?? city ?? '', p = VPNCC[cc];
	return length(c) ? c + (p ? ', ' + p : length(cc) ? ' (' + cc + ')' : '') : (p ?? cc);
}
/* opzioni comuni (wrtfreedom.vpnout): interruttori con il valore di serie, valori con il loro controllo.
   wait = attesa prima di dire «non risponde» e di cambiare server; pick = server del collegamento rapido (più veloce o
   meno carico); swload/swping = cambio automatico sopra loadmax % o pingmax ms (5 minuti); boot/bootpl = collegamento
   all'avvio e paese; ipday/ipat = nuovo IP ogni giorno; al_* = avvisi; v6 = IPv6 bloccato per chi usa la VPN;
   newdev = nuovi dispositivi nella VPN (con «solo alcuni»); dns own = dnsc; mtu ('' = quello del server), ka = keepalive */
const VPNB = { kill: 1, auto: 1, guest: 0, v6: 0, newdev: 0, swload: 0, swping: 0, boot: 1, ipday: 0, al_down: 1, al_up: 1, al_sw: 0, al_exp: 1, al_fb: 1 };
const VPNV = { dns: ['adg', /^(adg|vpn|own)$/], wait: ['120', /^(60|120|300|600)$/], pick: ['fast', /^(fast|load)$/], loadmax: ['70', /^(50|60|70|80|90)$/],
	pingmax: ['150', /^(100|150|200|300)$/], ipat: ['04:00', /^([01][0-9]|2[0-3]):[0-5][0-9]$/], mtu: ['', /^(1280|1320|1380|1420|1440)$/], ka: ['25', /^(0|15|25|60)$/],
	bootpl: ['', /^[A-Za-z0-9_-]{1,40}$/], bootpn: ['', /^[^'"\\`$]{1,60}$/], bootcc: ['', /^[A-Z]{2}$/] };
function vpnopts(W) {
	let v = W.vpnout ?? {}, O = { dnsips: vpnarr(v.dnsips), dnsc: vpnarr(v.dnsc) };
	for (let k, d in VPNB) O[k] = v[k] == null || v[k] == '' ? !!d : v[k] == '1';
	for (let k, d in VPNV) O[k] = v[k] != null && match('' + v[k], d[1]) ? '' + v[k] : d[0];
	return O;
}
function vpnprofcmd(p) {
	let id = p.id, c = 'uci set wrtfreedom.' + id + '=vpnprof; ';
	for (let k in ['name', 'prov', 'place', 'cc', 'city', 'sname', 'srvid', 'mtu', 'pub', 'host', 'port', 'added']) c += 'uci set wrtfreedom.' + id + '.' + k + '=' + q(p[k] ?? '') + '; ';
	for (let k in ['priv', 'psk']) c += ukey('wrtfreedom', id, k, p[k] ?? '');
	if (p.lib) c += 'uci set wrtfreedom.' + id + '.lib=1; ';
	for (let k in ['addr', 'dns']) { c += 'uci -q delete wrtfreedom.' + id + '.' + k + '; '; for (let x in (p[k] ?? [])) c += 'uci add_list wrtfreedom.' + id + '.' + k + '=' + q(x) + '; '; }
	return c;
}
function vpntuncmd(t) {
	let c = 'uci set wrtfreedom.' + t.id + '=vpntun; uci set wrtfreedom.' + t.id + '.n=' + int(t.n) + '; uci set wrtfreedom.' + t.id + '.prof=' + q(t.prof) +
		'; uci set wrtfreedom.' + t.id + '.on=' + (t.on ? 1 : 0) + '; uci set wrtfreedom.' + t.id + '.fb=' + (t.fb ? 1 : 0) + '; uci set wrtfreedom.' + t.id + '.mode=' + q(t.mode) +
		'; uci -q delete wrtfreedom.' + t.id + '.devs; ';
	for (let d in t.devs) c += 'uci add_list wrtfreedom.' + t.id + '.devs=' + q(d) + '; ';
	return c;
}
/* rete «a.b.c.d/n» di un'interfaccia statica */
function vpnnet(i) {
	if (!i || i.proto != 'static' || !i.ipaddr) return null;
	let ip = type(i.ipaddr) == 'array' ? i.ipaddr[0] : i.ipaddr, pfx = split(ip, '/')[1], bits = 0;
	if (!pfx) { for (let o in split(i.netmask ?? '255.255.255.0', '.')) { o = +o; while (o & 128) { bits++; o = (o << 1) & 255; } } } else bits = +pfx;
	let oc = map(split(split(ip, '/')[0], '.'), (x) => +x), net = [];
	for (let j = 0; j < 4; j++) { let b = bits - j * 8; push(net, b >= 8 ? oc[j] : b <= 0 ? 0 : oc[j] & (255 - ((1 << (8 - b)) - 1))); }
	return join('.', net) + '/' + bits;
}
/* reti di casa e reti ospiti (zone diverse da casa e internet che escono su internet); wdevs = interfacce della zona
   internet (per la catena dei MAC: tutto tranne quello che arriva da internet, così le reti ospiti spente o create dopo
   sono coperte) */
function vpnzones() {
	let N = ucfile('network'), F = ucfile('firewall'), Z = fwzones(), fwd = {}, home = [], guest = [], gz = [], wdevs = [];
	let D = (ubcall('network.interface', 'dump') ?? {}).interface ?? [];
	let adddev = (x) => { if (match(x ?? '', /^[A-Za-z0-9_.-]{1,15}$/) && index(wdevs, x) < 0) push(wdevs, x); };
	for (let k in F) if (F[k]['.type'] == 'forwarding' && F[k].dest == Z.wan) fwd[F[k].src] = 1;
	for (let k in F) if (F[k]['.type'] == 'zone' && F[k].name) {
		let z = F[k], nets = type(z.network) == 'array' ? z.network : split(z.network ?? '', ' ');
		if (z.name == Z.wan) {
			/* interfacce della linea: quelle della zona, quella della configurazione, il ponte br-<rete>, quella di netifd */
			for (let x in vpnarr(z.device)) adddev(x);
			for (let n in nets) {
				let i = N[n] ?? {};
				adddev(type(i.device) == 'string' ? i.device : null);
				if (i.type == 'bridge') adddev('br-' + n);
				for (let s in D) if (s.interface == n) { adddev(s.l3_device); adddev(s.device); }
			}
			continue;
		}
		let isg = z.name != Z.home && z.name != 'vpnout' && fwd[z.name];
		if (z.name != Z.home && !isg) continue;
		if (isg) push(gz, z.name);
		for (let n in nets) { let x = vpnnet(N[n]); if (x) push(isg ? guest : home, x); }
	}
	return { home: home, guest: guest, gz: gz, zh: Z.home, zw: Z.wan, wdevs: wdevs };
}
/* MAC di un indirizzo IPv4 (dispositivi salvati solo con l'IP, prima della 2.53): tabella ARP, assegnazioni DHCP
   (file di dnsmasq della configurazione), IP fissi (dhcp host); null = non trovato */
function vpnmacof(ip) {
	let okm = (m) => match(m ?? '', /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) && m != '00:00:00:00:00:00';
	for (let l in split(readfile('/proc/net/arp') ?? '', '
')) { let p = split(trim(l), /[ 	]+/); if (length(p) >= 4 && p[0] == ip && p[2] != '0x0' && okm(lc(p[3]))) return lc(p[3]); }
	let D = ucfile('dhcp'), lf = '/tmp/dhcp.leases';
	for (let k in D) if (D[k]['.type'] == 'dnsmasq' && length(D[k].leasefile ?? '')) { lf = D[k].leasefile; break; }
	for (let l in split(readfile(lf) ?? '', '
')) { let p = split(l, ' '); if (length(p) >= 3 && p[2] == ip && okm(lc(p[1]))) return lc(p[1]); }
	for (let k in D) if (D[k]['.type'] == 'host' && D[k].ip == ip) { let m = lc(split(trim(join(' ', vpnarr(D[k].mac))), /[ 	]+/)[0] ?? ''); if (okm(m)) return m; }
	return null;
}
/* MAC privato (bit «locally administered» del primo byte): iPhone e Android ne usano uno diverso per ogni Wi-Fi */
function vpnmacpriv(m) { return index('2367abef', substr(m, 1, 1)) >= 0; }
/* dispositivi «mac[,mac…]|ip|nome» (2.53: più MAC per lo stesso dispositivo, per i MAC privati; l'IP è solo informativo).
   Una voce senza MAC («ip» o «|ip|nome») prende il MAC da vpnmacof; se non si trova resta per IP (byip: regole per IP
   finché il MAC non si trova). Voce: { mac (il primo, '' = per IP), macs, ip, name, priv } */
function vpndevs(L) {
	let r = [], seen = {}, ip4 = /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/;
	for (let d in (L ?? [])) {
		let f = split('' + d, '|'), ip = f[1] ?? '', M = [], had = false;
		if (length(f) == 1 && match(f[0], ip4)) { ip = f[0]; f[0] = ''; }
		if (!match(ip, ip4)) ip = '';
		for (let m in split(lc(f[0] ?? ''), ',')) {
			m = trim(m);
			if (!match(m, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) || m == '00:00:00:00:00:00') continue;
			had = true;
			if (!seen[m] && index(M, m) < 0) push(M, m);
		}
		if (!had && length(ip)) { let m = vpnmacof(ip); if (m) { had = true; if (!seen[m]) push(M, m); } }
		if (had ? !length(M) : (!length(ip) || seen['ip:' + ip])) continue;
		if (length(M)) { for (let m in M) seen[m] = 1; } else seen['ip:' + ip] = 1;
		push(r, { mac: M[0] ?? '', macs: M, ip: ip, name: replace(substr(f[2] ?? '', 0, 40), /[^A-Za-z0-9 ._-]/g, ''), priv: length(filter(M, vpnmacpriv)) > 0 });
	}
	return r;
}
/* voce salvata di un dispositivo; chiavi = i suoi MAC, oppure «ip:<indirizzo>» per una voce senza MAC */
function vpndevstr(d) { return join(',', d.macs) + '|' + d.ip + '|' + d.name; }
function vpndevkeys(d) { return length(d.macs) ? d.macs : ['ip:' + d.ip]; }
/* tutta la configurazione: collegamenti T con i loro server Ps, opzioni O (comandi uci + file del DNS) */
function vpnbuild(T, Ps, O) {
	let Zs = vpnzones(), c = '', n = 0, nft = [], nets = [], taken = {}, mk = [], bydev = false, fw4 = has('/usr/share/nftables.d');
	let rule = (o) => { let s = 'wgout_r' + (n++), r = 'uci set network.' + s + '=rule; '; for (let k in o) r += 'uci set network.' + s + '.' + k + '=' + q(o[k]) + '; '; return r; };
	/* marca e maschera in esadecimale; riga della catena dei MAC (solo IPv4, con tutti i MAC delle voci; da ogni
	   interfaccia tranne quelle della zona internet) */
	let hx = (v) => sprintf('0x%08x', v), MM = hx(VPNMM), NM = hx(~VPNMM & 0xffffffff);
	let ifs = length(Zs.wdevs) ? 'iifname != { ' + join(', ', map(Zs.wdevs, (x) => '"' + x + '"')) + ' } ' : '';
	let allm = (Ds) => { let M = []; for (let d in Ds) push(M, ...d.macs); return M; };
	let mline = (Ds, v) => '\tmeta nfproto ipv4 ' + ifs + 'ether saddr { ' + join(', ', allm(Ds)) + ' } meta mark set meta mark & ' + NM + ' | ' + hx(v);
	let free = (d) => !length(filter(vpndevkeys(d), (k) => taken[k]));
	c += VPNDEL;
	c += 'uci set network.wgout_main=rule; uci set network.wgout_main.lookup=main; uci set network.wgout_main.suppress_prefixlength=0; uci set network.wgout_main.priority=900; ';
	/* prima i collegamenti in più: i loro dispositivi non passano dal principale */
	for (let t in T) if (t.n > 0) for (let d in vpndevs(t.devs)) for (let k in vpndevkeys(d)) taken[k] = 1;
	for (let t in T) {
		let P = Ps[t.prof], I = vpnif(t.n), tb = '' + (100 + t.n);
		if (!P) continue;
		push(nets, I);
		c += 'uci set network.' + I + '=interface; uci set network.' + I + '.proto=wireguard; ' + ukey('network', I, 'private_key', P.priv) + 'uci set network.' + I + '.disabled=' + (t.on ? 0 : 1) + '; ';
		for (let x in P.addr) c += 'uci add_list network.' + I + '.addresses=' + q(x) + '; ';
		let mtu = length(O.mtu) ? O.mtu : P.mtu;
		if (length(mtu)) c += 'uci set network.' + I + '.mtu=' + mtu + '; ';
		c += 'uci set network.' + I + '_peer=wireguard_' + I + '; uci set network.' + I + '_peer.description=' + q(P.name || P.host) + '; uci set network.' + I + '_peer.public_key=' + q(P.pub) +
			'; uci set network.' + I + '_peer.endpoint_host=' + q(P.host) + '; uci set network.' + I + '_peer.endpoint_port=' + q(P.port) + '; ' + (+O.ka > 0 ? 'uci set network.' + I + '_peer.persistent_keepalive=' + O.ka + '; ' : '') +
			'uci set network.' + I + '_peer.route_allowed_ips=0; uci add_list network.' + I + '_peer.allowed_ips=0.0.0.0/0; ' + (length(P.psk) ? ukey('network', I + '_peer', 'preshared_key', P.psk) : '') +
			'uci set network.' + I + '_rt=route; uci set network.' + I + '_rt.interface=' + I + '; uci set network.' + I + '_rt.target=0.0.0.0/0; uci set network.' + I + '_rt.table=' + tb + '; ';
		c += rule({ out: I, lookup: tb, priority: '1002' });
		if (!t.on || t.fb) continue;
		let srcs = [], excl = [], sels = [], p1 = t.n == 0 ? '1000' : '940', p2 = t.n == 0 ? '1001' : '941';
		/* voci con il MAC (con fw4: marca) e voci per IP (senza fw4, o MAC non ancora trovato: regole per IP, come prima della 2.53) */
		let byM = (Ds) => fw4 ? filter(Ds, (d) => length(d.macs)) : [], byI = (Ds) => filter(Ds, (d) => length(d.ip) && !(fw4 && length(d.macs)));
		if (t.n > 0 || t.mode == 'dev') {
			let Ds = filter(vpndevs(t.devs), (d) => t.n > 0 || free(d)), Dm = byM(Ds), mv = (t.n + 1) << 24, mm = hx(mv) + '/' + MM;
			if (length(Dm)) {
				push(mk, mline(Dm, mv)); bydev = true;
				c += rule({ mark: mm, lookup: tb, priority: p1 }); if (O.kill) c += rule({ mark: mm, action: 'prohibit', priority: p2 });
				push(sels, 'meta nfproto ipv4 meta mark & ' + MM + ' == ' + hx(mv) + ' ');
			}
			srcs = map(byI(Ds), (d) => d.ip + '/32');
		}
		else {
			srcs = [...Zs.home]; if (O.guest) push(srcs, ...Zs.guest);
			/* «Tutti Tranne»: gli esclusi, dal MAC con la loro marca (o dall'IP), restano sulla linea (main) */
			if (t.mode == 'except') {
				let Ds = vpndevs(t.devs), Dm = byM(Ds);
				if (length(Dm)) {
					push(mk, mline(Dm, VPNMX));
					c += rule({ mark: hx(VPNMX) + '/' + MM, lookup: 'main', priority: '950' });
					push(excl, 'meta mark & ' + MM + ' != ' + hx(VPNMX) + ' ');
				}
				for (let d in byI(Ds)) { c += rule({ src: d.ip + '/32', lookup: 'main', priority: '950' }); push(excl, 'ip saddr != ' + d.ip + ' '); }
			}
		}
		for (let s in srcs) { c += rule({ src: s, lookup: tb, priority: p1 }); if (O.kill) c += rule({ src: s, action: 'prohibit', priority: p2 }); }
		if (length(srcs)) push(sels, 'ip saddr { ' + join(', ', srcs) + ' } ' + join('', excl));
		/* DNS del servizio o personale: le richieste dei dispositivi vanno lì, attraverso il collegamento */
		let dip = O.dns == 'vpn' ? P.dns[0] : O.dns == 'own' ? O.dnsc[0] : null;
		if (dip && length(sels)) {
			for (let sel in sels) push(nft, sel + 'meta l4proto { tcp, udp } th dport 53 counter dnat ip to ' + dip + ' comment "!wrtfreedom: DNS del Servizio VPN"');
			c += rule({ dest: dip + '/32', lookup: tb, priority: p1 });
		}
		/* DNS del router attraverso il principale: solo se ci passa la casa (con «solo alcuni dispositivi» è di tutti) */
		if (t.n == 0 && t.mode != 'dev' && O.dns == 'adg') for (let ip in O.dnsips) if (match(ip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) c += rule({ dest: ip + '/32', lookup: tb, priority: '1000' });
	}
	if (length(nft) && fw4) c += 'mkdir -p ' + replace(VPNDNSF, /\/[^\/]*$/, '') + '; printf "%s\\n" ' + join(' ', map(nft, q)) + ' > ' + VPNDNSF + '; ';
	/* catena dei MAC: prima gli esclusi del principale, poi i collegamenti (l'ultima marca vince); priorità dopo le
	   Eccezioni Per Sito (mangle + 1), prima del dstnat del DNS */
	if (length(mk)) c += 'mkdir -p ' + replace(VPNMACF, /\/[^\/]*$/, '') + '; printf "%s\\n" ' + join(' ', map(['# WrtFreedom: dispositivi del Servizio VPN dal MAC (2.53)',
		'chain wf_vpnmac {', '\ttype filter hook prerouting priority mangle + 2; policy accept;', ...mk, '}'], q)) + ' > ' + VPNMACF + '; ';
	if (length(nets)) {
		c += 'uci set firewall.wgout_zone=zone; uci set firewall.wgout_zone.name=vpnout; uci set firewall.wgout_zone.input=REJECT; uci set firewall.wgout_zone.output=ACCEPT; ' +
			'uci set firewall.wgout_zone.forward=REJECT; uci set firewall.wgout_zone.masq=1; uci set firewall.wgout_zone.mtu_fix=1; ' +
			'uci set firewall.wgout_fwd=forwarding; uci set firewall.wgout_fwd.src=' + q(Zs.zh) + '; uci set firewall.wgout_fwd.dest=vpnout; ';
		for (let I in nets) c += 'uci add_list firewall.wgout_zone.network=' + I + '; ';
		/* reti ospiti verso la VPN: con l'opzione, o per i dispositivi scelti che si collegano agli ospiti */
		if (O.guest || bydev) for (let i = 0; i < length(Zs.gz); i++) c += 'uci set firewall.wgout_g' + i + '=forwarding; uci set firewall.wgout_g' + i + '.src=' + q(Zs.gz[i]) + '; uci set firewall.wgout_g' + i + '.dest=vpnout; ';
	}
	/* Blocca IPv6: chi esce dalla VPN della casa non esce scoperto con IPv6 (WireGuard del servizio solo IPv4) */
	let m0 = filter(T, (t) => t.n == 0 && t.on && !t.fb && Ps[t.prof])[0];
	if (O.v6 && m0 && Zs.zw) {
		let fr = (s, src, macs) => {
			let r = 'uci set firewall.' + s + '=rule; uci set firewall.' + s + '.name=' + q('WrtFreedom: IPv6 fuori dalla VPN') + '; uci set firewall.' + s + '.family=ipv6; uci set firewall.' + s + '.src=' + q(src) +
				'; uci set firewall.' + s + '.dest=' + q(Zs.zw) + '; uci set firewall.' + s + '.proto=all; uci set firewall.' + s + '.target=REJECT; ';
			for (let m in (macs ?? [])) r += 'uci add_list firewall.' + s + '.src_mac=' + m + '; ';
			return r;
		};
		if (m0.mode == 'dev') {
			let M = allm(filter(vpndevs(m0.devs), free));
			if (length(M)) { c += fr('wgout_v6', Zs.zh, M); for (let i = 0; i < length(Zs.gz); i++) c += fr('wgout_v6g' + i, Zs.gz[i], M); }
		}
		else { c += fr('wgout_v6', Zs.zh); if (O.guest) for (let i = 0; i < length(Zs.gz); i++) c += fr('wgout_v6g' + i, Zs.gz[i]); }
	}
	/* senza fw4 le regole vanno per IP: indirizzo fisso nel DHCP se non c'è, così continuano a valere (con fw4 basta il MAC) */
	if (!fw4) {
		let D = ucfile('dhcp'), hosts = '';
		for (let k in D) if (D[k]['.type'] == 'host') hosts += ' ' + lc(join(' ', vpnarr(D[k].mac)));
		for (let t in T) for (let d in vpndevs(t.devs)) if (length(d.ip) && length(d.mac) && index(hosts, d.mac) < 0) {
			hosts += ' ' + d.mac;
			c += 'H=$(uci add dhcp host); uci set dhcp.$H.mac=' + d.mac + '; uci set dhcp.$H.ip=' + d.ip + '; ' + (length(d.name) ? 'uci set dhcp.$H.name=' + q(replace(d.name, / /g, '-')) + '; ' : '');
		}
	}
	return c;
}
/* salva collegamenti e opzioni e ricostruisce tutto (network, firewall e dnsmasq ricaricati in sottofondo) */
function vpnapply(T, O, pre) {
	cfgensure();
	let W = ucfile('wrtfreedom'), Ps = vpnprofs(W), c = (pre ?? '') + 'uci -q get wrtfreedom.vpnout >/dev/null || uci set wrtfreedom.vpnout=vpnout; ';
	/* server appena scritti da «pre» (non ancora nel file): li passa chi chiama in T[i].P */
	for (let t in T) if (t.P) Ps[t.prof] = t.P;
	for (let k in keys(VPNB)) c += 'uci set wrtfreedom.vpnout.' + k + '=' + (O[k] ? 1 : 0) + '; ';
	for (let k in keys(VPNV)) c += 'uci set wrtfreedom.vpnout.' + k + '=' + q(O[k]) + '; ';
	for (let k in ['dnsips', 'dnsc']) { c += 'uci -q delete wrtfreedom.vpnout.' + k + '; '; for (let x in O[k]) c += 'uci add_list wrtfreedom.vpnout.' + k + '=' + q(x) + '; '; }
	/* voci dei dispositivi riscritte: i MAC trovati nel frattempo (voci per IP) restano salvati */
	for (let t in T) { t.devs = map(vpndevs(t.devs), vpndevstr); c += vpntuncmd(t); }
	/* prima il firewall (catena dei MAC caricata), poi la rete (regole per marca): i dispositivi non escono mai senza marca
	   né senza blocco */
	sh(c + vpnbuild(T, Ps, O) + 'uci commit wrtfreedom; uci commit network; uci commit firewall; uci commit dhcp; ' +
		'( /etc/init.d/firewall reload; /etc/init.d/network reload; /etc/init.d/dnsmasq reload; sleep 8; ucode /usr/share/wrtfreedom/vpnctl.uc ipcheck ) >/dev/null 2>&1 &');
}
/* configurazione della 2.41 (solo l'interfaccia wgout, senza collegamenti): diventa server vp_cur e collegamento vt_main */
function vpnlegacy(W, N) {
	if (length(vpntuns(W)) || !N.wgout || !N.wgout.private_key) return null;
	let pe = N.wgout_peer ?? {}, v = W.vpnout ?? {};
	let P = { id: 'vp_cur', name: v.name || pe.description || 'VPN', prov: 'other', place: '', cc: '', city: '', sname: '', priv: N.wgout.private_key, addr: vpnarr(N.wgout.addresses), dns: [],
		mtu: N.wgout.mtu ?? '', pub: pe.public_key ?? '', psk: pe.preshared_key ?? '', host: pe.endpoint_host ?? '', port: pe.endpoint_port ?? '51820' };
	return { P: P, T: { id: 'vt_main', n: 0, prof: 'vp_cur', on: N.wgout.disabled != '1', mode: v.mode == 'dev' ? 'dev' : 'all', devs: vpnarr(v.devs), fb: false } };
}

/* ---------------- Wi-Fi (2.48) ----------------
   Il lavoro con processi (iw, logread, wifi) lo fa wifi.uc in sottofondo con i risultati in /tmp/wf-wifi.*; qui solo
   letture di file, uci e chiamate a netifd/hostapd. Radio, bande e interfacce lette da netifd, mai fisse. */
const WIFIUC = '/usr/share/wrtfreedom/wifi.uc', WFP = '/tmp/wf-wifi';
/* Riavvia Wi-Fi: lavoro del router, risponde subito (il telefono sul Wi-Fi non perde la seconda metà come con giù/su
   chiesti dall'app). wifi.uc restart: «wifi» (giù e su di tutte le radio; «wifi reload» riavvierebbe solo le radio con
   la configurazione cambiata), dopo 30 s controllo e, se una radio non è ripartita, secondo «wifi up» ed evento */
const WIFIRESTART = 'ucode /usr/share/wrtfreedom/wifi.uc restart >/dev/null 2>&1 </dev/null &';
function upsec() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
/* comandi uci con il nome intero tra apici (le sezioni anonime si chiamano @wifi-iface[2]) */
function uset(c, s, o, v) { return 'uci set ' + q(c + '.' + s + '.' + o + '=' + v) + '; '; }
function udel(c, s, o) { return 'uci -q delete ' + q(c + '.' + s + (o ? '.' + o : '')) + '; '; }
function okmac(m) { return match(m, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) != null; }
/* banda di una radio: band, altrimenti hwmode, altrimenti la frequenza in uso (hostapd del primo punto di accesso),
   infine il canale */
function rband(d, ifn) {
	let b = d?.band ?? '';
	if (match(b, /^(2g|5g|6g|60g)$/)) return b;
	if (!d?.hwmode && ifn) { let f = +(ubcall('hostapd.' + ifn, 'get_status')?.freq ?? 0); if (f) return f < 2500 ? '2g' : f >= 5925 ? '6g' : '5g'; }
	return (d?.hwmode == '11a' || +(d?.channel ?? 0) > 14) ? '5g' : '2g';
}
/* radio e punti di accesso da netifd (nomi veri delle interfacce) */
function wradios() {
	let S = ubcall('network.wireless', 'status') ?? {}, R = {};
	for (let rn in S) {
		let v = S[rn], c = v.config ?? {}, ifs = [];
		for (let i in (v.interfaces ?? [])) {
			let ic = i.config ?? {};
			if (i.ifname && (ic.mode ?? 'ap') == 'ap') push(ifs, { ifname: i.ifname, sec: i.section ?? '', ssid: ic.ssid ?? '', enc: ic.encryption ?? 'none', hidden: ic.hidden == true || ic.hidden == '1',
				net: vpnarr(ic.network), pb: ic.wps_pushbutton == true || ic.wps_pushbutton == '1' });
		}
		R[rn] = { up: !!v.up, band: rband(c, ifs[0]?.ifname), cfg: '' + (c.channel ?? 'auto'), ifs: ifs };
	}
	return R;
}
/* reti ospiti: Wi-Fi sulla rete «guest» o su una rete di una zona del firewall con «guest» nel nome (stesso criterio per
   app, quick, snapshot, bot e Limite Di Velocità in wifi.uc) */
function guestifs(WL) {
	WL = WL ?? ucfile('wireless');
	let F = ucfile('firewall'), gn = { guest: true };
	for (let k in F) if (F[k]['.type'] == 'zone' && match(F[k].name ?? '', /guest/i)) for (let n in split(join(' ', vpnarr(F[k].network)), ' ')) if (length(n)) gn[n] = true;
	return filter(keys(WL), (k) => WL[k]['.type'] == 'wifi-iface' && length(filter(split(ug(WL, k, 'network'), ' '), (n) => gn[n])) > 0);
}
/* password casuale (senza lettere che si confondono) dai byte di /dev/urandom, senza processi */
function wkey(n) {
	let c = 'abcdefghjkmnpqrstuvwxyz23456789', r = readfile('/dev/urandom', n) ?? '', k = '';
	for (let i = 0; i < n; i++) k += substr(c, (ord(r, i) ?? (time() + i * 7)) % length(c), 1);
	return k;
}
function wevent(tp, txt) { sh('sh /usr/share/wrtfreedom/event.sh cron ' + q(tp) + ' net ' + q(txt) + ' >/dev/null 2>&1 </dev/null &'); }
/* riga del crontab del pacchetto per un'azione: riconosciuta dal commento di coda «# wf:<tag>», l'unica che si toglie o
   si cambia (righe dell'utente e righe vuote restano com'erano). Scrittura su un file a parte e poi rinomina; cron
   acceso all'avvio se non lo era, riavviato solo se il file cambia */
function cronline(tag, line) {
	let f = '/etc/crontabs/root', o = readfile(f) ?? '', mark = ' # wf:' + tag, Ls = split(o, '\n');
	if (length(Ls) && Ls[length(Ls) - 1] == '') pop(Ls);
	/* righe rovinate dalle app fino alla 0.33 («… # wf:<tag> #wrtfreedom {…}»): tolte anche loro, niente doppioni */
	Ls = filter(Ls, (l) => substr(l, -length(mark)) != mark && index(l, mark + ' #wrtfreedom ') < 0);
	if (line) push(Ls, line + mark);
	let n = length(Ls) ? join('\n', Ls) + '\n' : '';
	if (n == o) return;
	mkdir('/etc/crontabs');
	writefile(f + '.wf', n);
	rename(f + '.wf', f);
	sh('( /etc/init.d/cron enabled || /etc/init.d/cron enable; /etc/init.d/cron restart ) >/dev/null 2>&1 </dev/null &');
}
/* Ritorno automatico (2.52, come wifiiot e adgmode): prima di una modifica che può togliere l'accesso o internet si copiano
   le configurazioni (e i file in più) in /etc/wrtfreedom/bak/<tag> (resta anche dopo un riavvio: se il router riparte
   prima della conferma, start_service del servizio lancia back.sh); se entro secs l'app non manda confirm, back.sh
   rimette tutto com'era, ricarica i servizi e scrive l'evento cron_<tag>_back. Con una copia già in attesa si tiene
   quella (lo stato di prima di tutte le modifiche non confermate) e riparte solo il tempo. Copia scaduta (id più vecchio
   di secs + 30 s: timer perso) = non più in attesa, la prossima modifica la rifà. cfgs = elenco di configurazioni copiate
   intere oppure { config: parte } (bakpart: solo le sezioni di quella funzione, così il ritorno non tocca il resto,
   per esempio i dispositivi aggiunti nel frattempo). Una sola modifica alla volta in attesa tra i BAKTAGS: con un'altra
   in attesa la risposta è { error: 'conferma prima la modifica in attesa', pend: <tag> } */
const BAKTAGS = ['vpn', 'wg', 'vpnsites', 'cron', 'acc', 'svc', 'fwc', 'apn', 'fwd', 'sim', 'cell', 'upg', 'wifi', 'adg', 'dnsf', 'roam', 'ifc'];
function bakdir(tag) { return '/etc/wrtfreedom/bak/' + tag; }
function bakpend(tag) {
	let B = bakdir(tag), s = stat(B + '/id');
	if (!s) return false;
	return time() - s.mtime <= (+(readfile(B + '/secs') ?? '') || 120) + 30;
}
/* secondi che mancano al ritorno (0 = niente in attesa o ritorno in corso) */
function bakleft(tag) {
	let B = bakdir(tag), s = stat(B + '/id');
	if (!s) return 0;
	let l = (+(readfile(B + '/secs') ?? '') || 120) - (time() - s.mtime);
	return l > 0 ? l : 0;
}
/* 2.63 esito dell'ultimo ritorno in /tmp/wf-bak-<tag>.done «ok|back <ora>»: ok = confermato (bakconfirm), back = rimesso
   com'era da back.sh (a mano o da solo). BAKCM = metodo con {action:'confirm'} → tag. Una sola regola di stato: bakcf.
   adgmode ha il suo giro (adgmode.sh, /tmp/wf-adgmode.json st run|wait|ok|back|err): esito da lì */
const BAKCM = { vpnout: 'vpn', simslot: 'sim', q5gset: 'cell', apnset: 'apn', fwd: 'fwd', updsafe: 'upg', wifinet: 'wifi', adgups: 'adg', dnsforce: 'dnsf', modemset: 'roam', svc: 'svc', ifctl: 'ifc',
	cron: 'cron', wgset: 'wg', wgalt: 'wg' };
function bakdonef(tag) { return '/tmp/wf-bak-' + tag + '.done'; }
function bakdonesh(tag) { return 'echo "back $(date +%s)" > ' + bakdonef(tag) + '\n'; }
/* conferma della chat {method, secs, t?} con left (secondi che restano davvero) e done (ok, back o null = in attesa);
   t0 = ora del cambio se manca t: un esito più vecchio è di un'altra modifica. Senza copia in attesa né esito = già tornato */
function bakcf(c, t0) {
	if (type(c) == 'object' && c.method == 'adgmode') {
		/* stato dell'ultimo giro (10 s di margine: lo stato «run» si scrive appena prima della conferma nella chat) */
		let J = rjs('/tmp/wf-adgmode.json') ?? {}, now = time(), jt = +(J.t ?? 0), nw = jt >= +(c.t ?? t0 ?? 0) - 10, ul = +(J.until ?? 0) - now;
		if (nw && J.st == 'ok') return { ...c, left: 0, done: 'ok' };
		if (nw && (J.st == 'wait' || J.st == 'run') && now - jt < 300) return { ...c, left: J.st == 'wait' ? (ul > 0 ? ul : 0) : +(c.secs ?? 120), done: null };
		return { ...c, left: 0, done: 'back' };
	}
	let tag = type(c) == 'object' ? BAKCM[c.method] : null;
	if (!tag) return c;
	let m = match(readfile(bakdonef(tag)) ?? '', /^(ok|back) ([0-9]{1,12})/), t = +(c.t ?? t0 ?? 0);
	if (m && +m[2] >= t) return { ...c, left: 0, done: m[1] };
	if (bakpend(tag)) return { ...c, left: bakleft(tag), done: null };
	return { ...c, left: 0, done: 'back' };
}
/* parte di una configurazione: sezioni con il nome in P.n o il tipo in P.t (alternative di una regex) e sezioni anonime
   in P.a ('@rule[3]': rimesse solo se sono ancora la stessa, stesso tipo e stesso nome); P.o = solo queste opzioni
   (le altre della sezione restano come sono). I valori vanno in file per
   «uci batch» (mai le chiavi nella riga di comando); per back.sh: sezioni della parte nate dopo tolte, quelle salvate
   svuotate e riscritte (stessa posizione), quelle tolte rifatte */
function bakpart(B, cfg, P) {
	let C = ucfile(cfg), rn = P.n ? regexp('^(' + P.n + ')$') : null, rt = P.t ? regexp('^(' + P.t + ')$') : null, keep = [], r = '', i = 0;
	for (let k in C) {
		let s = C[k], an = substr(k, 0, 1) == '@';
		if (an ? index(P.a ?? [], k) < 0 : !((rn && match(k, rn)) || (rt && match(s['.type'], rt)))) continue;
		let A = cfg + '.' + k, b = '', f = B + '/' + cfg + '.' + (i++) + '.uci';
		for (let o in s) if (o != '.type' && (!P.o || index(P.o, o) >= 0)) {
			if (type(s[o]) == 'array') for (let x in s[o]) b += 'add_list ' + A + '.' + o + '=' + q(x) + '\n';
			else b += 'set ' + A + '.' + o + '=' + q(s[o]) + '\n';
		}
		writefile(f, b);
		let clr = P.o ? join('', map(P.o, (o) => 'uci -q delete ' + q(A + '.' + o) + '; ')) :
			'for o in $(uci -q show ' + q(A) + " | sed -nE 's/^[^.]+\\.[^.]+\\.([A-Za-z0-9_]+)=.*/\\1/p'); do uci -q delete " + q(A) + '.$o; done; ';
		if (an) r += 'if [ "$(uci -q get ' + q(A) + ')" = ' + q(s['.type']) + ' ] && [ "$(uci -q get ' + q(A + '.name') + ')" = ' + q(s.name ?? '') + ' ]; then ' + clr + 'uci -q batch < ' + f + '; fi\n';
		else { push(keep, k); r += 'if uci -q get ' + q(A) + ' >/dev/null; then ' + clr + 'else uci set ' + q(A + '=' + s['.type']) + '; fi; uci -q batch < ' + f + '\n'; }
	}
	let ex = [];
	if (P.n) push(ex, "-e 's/^" + cfg + "\\.(" + P.n + ")=[A-Za-z0-9_-]+$/\\1/p'");
	if (P.t) push(ex, "-e 's/^" + cfg + "\\.([A-Za-z0-9_]+)=(" + P.t + ")$/\\1/p'");
	let del = length(ex) ? 'for s in $(uci -q show ' + cfg + ' | sed -nE ' + join(' ', ex) + '); do case " ' + join(' ', keep) + ' " in *" $s "*) ;; *) uci -q delete ' + cfg + '.$s;; esac; done\n' : '';
	return del + r + 'uci commit ' + cfg + '\n';
}
function bakarm(tag, cfgs, files, reload, secs, why) {
	for (let t in BAKTAGS) if (t != tag && bakpend(t)) return { error: 'conferma prima la modifica in attesa', pend: t };
	let B = bakdir(tag), id = '' + time() + wkey(6);
	if (!bakpend(tag)) {
		let c = 'rm -rf ' + B + ' && mkdir -p ' + B + ' && chmod 700 ' + B + ' && ', r = '';
		if (type(cfgs) == 'array') for (let x in cfgs) { c += 'cp /etc/config/' + x + ' ' + B + '/ && '; r += 'cp ' + B + '/' + x + ' /etc/config/' + x + '\n'; }
		for (let i = 0; i < length(files); i++) {
			c += '{ [ ! -f ' + q(files[i]) + ' ] || cp ' + q(files[i]) + ' ' + B + '/f' + i + '; } && ';
			r += 'if [ -f ' + B + '/f' + i + ' ]; then cp ' + B + '/f' + i + ' ' + q(files[i]) + '; else rm -f ' + q(files[i]) + '; fi\n';
		}
		sh(c + 'echo new > ' + B + '/id');
		if (!has(B + '/id')) return { error: 'copia della configurazione non riuscita' };
		if (type(cfgs) == 'object') for (let x, P in cfgs) r += bakpart(B, x, P);
		writefile(B + '/back.sh', '[ -f ' + B + '/id ] || exit 0\n' + r + 'rm -rf ' + B + '\n' + bakdonesh(tag) + '( ' + reload + ' ) >/dev/null 2>&1\n' +
			'sh /usr/share/wrtfreedom/event.sh cron ' + q(tag + '_back') + ' net "${1:-' + replace(why, /["$`\\}]/g, '') + '}"\n');
	}
	writefile(B + '/secs', int(secs) + '\n');
	writefile(B + '/id', id + '\n');
	sh('( sleep ' + int(secs) + '; [ "$(cat ' + B + '/id 2>/dev/null)" = ' + id + ' ] && sh ' + B + '/back.sh ) >/dev/null 2>&1 </dev/null &');
	return true;
}
function bakconfirm(tag) {
	let p = bakpend(tag);
	sh('rm -rf ' + bakdir(tag));
	if (p) writefile(bakdonef(tag), 'ok ' + time() + '\n');
	return p ?{ ok: true } : { error: 'niente da confermare' };
}
function bakback(tag, why) {
	if (!bakpend(tag)) return { error: 'niente da annullare' };
	sh('( sh ' + bakdir(tag) + '/back.sh ' + q(why) + ' ) >/dev/null 2>&1 </dev/null &');
	return { ok: true };
}
/* ---------- Firewall · Regole Personalizzate (2.56) ----------
   regole nftables scritte dall'utente, in un file di /etc/nftables.d (fw4 lo include nella sua tabella). Non è il file
   del limitatore (SHNFT): quello lo riscrive shaperfile. FWCOLD = file del progetto di prima, letto finché non si salva;
   al primo salvataggio si sposta in FWCKEEP (mai cancellato). FWCPREV = copia del contenuto di prima a ogni salvataggio */
const FWCF = '/etc/nftables.d/90-wrtfreedom-custom.nft', FWCOLD = '/etc/nftables.d/90-x3000.nft';
const FWCPREV = '/etc/wrtfreedom/fwcustom.prev.nft', FWCKEEP = '/etc/wrtfreedom/fwcustom.old.nft', FWCTMP = '/tmp/wf-fwcustom.nft';
/* file in uso: il nuovo se c'è, altrimenti quello di prima se c'è */
function fwcfile() { return !has(FWCF) && has(FWCOLD) ? FWCOLD : FWCF; }
/* tabella in cui fw4 include /etc/nftables.d: l'ultima «table» prima della riga include nel modello di fw4 */
function fwctable() {
	let t = null;
	for (let l in split(readfile('/usr/share/firewall4/templates/ruleset.uc') ?? '', '\n')) {
		let m = match(l, /^[ \t]*table[ \t]+([a-z0-9]+)[ \t]+([A-Za-z0-9_]+)/);
		if (m) t = m[1] + ' ' + m[2];
		else if (t && index(l, 'include') >= 0 && index(l, '/etc/nftables.d') >= 0) return t;
	}
	return 'inet fw4';
}
/* stato: { file, table, text, lines, rules, mtime, pend } */
function fwcstate() {
	let f = fwcfile(), t = readfile(f) ?? '', s = stat(f), n = 0, r = 0;
	for (let l in split(t, '\n')) {
		l = trim(l);
		if (!length(l)) continue;
		n++;
		if (substr(l, 0, 1) != '#' && !match(l, /^(chain|type)([ \t{]|$)/) && !match(l, /^[{}; \t]+$/)) r++;
	}
	return { file: f, table: fwctable(), text: t, lines: n, rules: r, mtime: s ? s.mtime : 0, pend: bakleft('fwc') };
}
/* applica: prova con fw4 check (stato nuovo messo e poi tolto), copia con ritorno (bakarm 'fwc', 60 s), scrive di
   nuovo e ricarica fw4 in sottofondo. Testo vuoto = file tolto (con la stessa copia) */
function fwcapply(text) {
	if (type(text) != 'string' || length(text) > 65536 || index(text, chr(0)) >= 0) return { error: 'testo non valido' };
	let t = replace(text, /\r/g, ''), off = !length(trim(t));
	if (!off && substr(t, -1) != '\n') t += '\n';
	for (let x in BAKTAGS) if (x != 'fwc' && bakpend(x)) return { error: 'conferma prima la modifica in attesa', pend: x };
	let cur = readfile(FWCF), old = has(FWCOLD), oldA = FWCOLD + '.wf';
	mkdir('/etc/nftables.d');
	/* stato nuovo per la prova: il file di prima messo da parte (.wf: fw4 legge solo *.nft) */
	writefile(FWCTMP, t);
	if (old) rename(FWCOLD, oldA);
	if (off) unlink(FWCF); else writefile(FWCF, t);
	let out = sh('fw4 -q check 2>&1 && echo "#ok"'), ok = match(out, /#ok\n?$/) != null;
	/* com'era (bakarm copia lo stato di prima) */
	if (cur != null) writefile(FWCF, cur); else unlink(FWCF);
	if (old) rename(oldA, FWCOLD);
	unlink(FWCTMP);
	if (!ok) return { error: 'invalid', out: join('\n', slice(filter(split(trim(out), '\n'), length), 0, 6)) };
	let e = bakarm('fwc', [], [FWCF, FWCOLD], 'fw4 -q reload', 60,
		L('↩️ Regole Personalizzate: nessuna conferma entro 60 s, rimesse com\'erano', '↩️ Custom Rules: no confirmation within 60 s, restored'));
	if (e !== true) return e;
	/* copie che restano: il contenuto di prima e, una volta sola, il file del progetto di prima */
	let prev = cur ?? (old ? readfile(FWCOLD) : null);
	if (prev != null && length(trim(prev))) writefile(FWCPREV, prev);
	if (old) rename(FWCOLD, has(FWCKEEP) ? '/etc/wrtfreedom/fwcustom.old.' + time() + '.nft' : FWCKEEP);
	if (has(FWCOLD)) return { error: 'file di prima non spostato' };
	if (off) unlink(FWCF); else writefile(FWCF, t);
	sh('( fw4 -q reload ) >/dev/null 2>&1 </dev/null &');
	return { ok: true, pend: 60 };
}
/* ---------- Altro · Servizi (2.53) ----------
   svc.uc = lavori in sottofondo dei Servizi (IP pubblico dalla linea vera, Il Nome Funziona?, storico degli IP, registro
   delle esecuzioni con recupero all'avvio, Prova Prima E Dopo): i metodi leggono solo i suoi file in /tmp */
const SVC = '/usr/share/wrtfreedom/svc.uc', CRONF = '/etc/crontabs/root';
function svcbg(a) { sh('( ucode ' + SVC + ' ' + a + ' ) >/dev/null 2>&1 </dev/null &'); }
/* tunnel e VPN (Servizio VPN, WireGuard, OpenVPN, GRE…): mai la linea (come netx.uc) */
function linetun(i) {
	return match(i.interface ?? '', VPNIFRX) != null ||
		match(i.proto ?? '', /^(wireguard|openvpn|gre|gretap|grev6|grev6tap|vti|vtiv6|xfrm|vxlan|vxlan6|ipip|zerotier|tailscale)$/) != null ||
		match(i.l3_device ?? i.device ?? '', /^(tun|tap|wg|tailscale|zt)[0-9a-z]*$/) != null;
}
/* linea vera verso internet (come netx.uc 2.51): interfaccia accesa, non tunnel, con la rotta predefinita della tabella
   principale; prima quelle nelle zone con il NAT, poi la metrica più bassa. { ifc, dev, ip, ip6, proto, priv } o null */
function lineinfo() {
	let D = ubcall('network.interface', 'dump')?.interface ?? [], F = ucfile('firewall'), Z = {}, b = null;
	for (let k in F) if (F[k]['.type'] == 'zone' && (F[k].masq == '1' || F[k].masq == 'true') && F[k].name != 'vpnout')
		for (let n in split(join(' ', vpnarr(F[k].network)), ' ')) if (length(n)) Z[n] = true;
	for (let i in D) {
		if (!i.up || linetun(i)) continue;
		let m = null;
		for (let r in i.route ?? [])
			if (r.target == '0.0.0.0' && r.mask == 0 && (r.table == null || r.table == 'main' || +r.table == 254) && (m == null || (r.metric ?? 0) < m)) m = r.metric ?? 0;
		if (m == null) continue;
		let z = Z[i.interface] ? 0 : 1;
		if (!b || z < b.z || (z == b.z && m < b.m)) b = { i: i, m: m, z: z };
	}
	if (!b) return null;
	let i = b.i, ip = (i['ipv4-address'] ?? [])[0]?.address ?? '', ip6 = '';
	for (let a in i['ipv6-address'] ?? []) if (!match(a.address ?? '', /^f[c-f]/i)) { ip6 = a.address; break; }
	return { ifc: i.interface, dev: i.l3_device ?? i.device ?? '', ip: ip, ip6: ip6, proto: i.proto ?? '', priv: length(ip) > 0 && privip(ip) };
}

/* Pianificazioni (2.53): l'app salva solo le sue righe («[#off# ]m h g M s comando #wrtfreedom {json}») e, se lo
   chiede, quelle di sistema; le righe del pacchetto «… # wf:<tag>» restano sempre com'erano (una per tag: l'ultima).
   Ogni attività dell'app lascia esito e ora nel registro: comando avvolto in «{ comando; } ; ucode svc.uc log <id> $?»
   (tolto quando si rilegge). id = meta.i, altrimenti 8 cifre esadecimali dal contenuto (stesso calcolo in svc.uc) */
const CRWRAP = /^\{ (.*) \} ; ucode \/usr\/share\/wrtfreedom\/svc\.uc log [0-9a-f]{8} \$\?$/s;
const CRWF = / # wf:([a-z0-9_]{1,40})$/;
/* azioni che tolgono la rete: salvarle chiede conferma con ritorno; valore = comando che ridà la rete al ritorno */
const CRNET = { reboot: '', ifrestart: '', modem: '', woff: 'wifi up', vpnoff: 'sh /usr/share/wrtfreedom/event.sh act vpn_on' };
/* 2.64 B4: una sola regola per get, run, set e add: comando che ridà la rete di un'attività che la toglie ('' = nessuno),
   null = non la toglie. CRPAIR = attività che si salvano solo con la loro riaccensione (stesso nome meta.n) */
function crnet(p) { return CRNET[p.meta.a ?? ''] ?? (p.meta.w == 'off' ? 'wifi up' : null); }
const CRPAIR = { woff: 'won', vpnoff: 'vpnon' };
function crhash(s) { let h = 5381; for (let i = 0; i < length(s); i++) h = ((h * 33) ^ ord(s, i)) & 0x7fffffff; return sprintf('%08x', h); }
/* attività All'Avvio: l'app scrive «kill -0 $(cat /tmp/wf-svc.<id>…) || { ( comando ) … & echo $! >/tmp/wf-svc.<id>; } #»;
   nel crontab diventa «ucode svc.uc keep <id> # comando» (svc.uc keep: riparte se si è fermato, dopo 3 ripartenze in 10
   minuti si ferma e lo scrive nel registro) e si rilegge nella forma dell'app */
const CRSVC = /^kill -0 \$\(cat \/tmp\/wf-svc\.([0-9a-f]{8}) 2>\/dev\/null\) 2>\/dev\/null \|\| \{ \( (.*) \) >\/dev\/null 2>&1 & echo \$! >\/tmp\/wf-svc\.[0-9a-f]{8}; \} #$/s;
const CRKEEP = /^ucode \/usr\/share\/wrtfreedom\/svc\.uc keep ([0-9a-f]{8}) # (.*)$/s;
function crunwrap(c) {
	let k = match(c, CRKEEP);
	if (k) return 'kill -0 $(cat /tmp/wf-svc.' + k[1] + ' 2>/dev/null) 2>/dev/null || { ( ' + k[2] + ' ) >/dev/null 2>&1 & echo $! >/tmp/wf-svc.' + k[1] + '; } #';
	let m = match(c, CRWRAP);
	if (!m) return c;
	let x = m[1];
	return substr(x, length(x) - 1) == ';' ? rtrim(substr(x, 0, length(x) - 1)) : x;
}
function crwrap(c, id) {
	let v = match(c, CRSVC);
	if (v) return 'ucode ' + SVC + ' keep ' + id + ' # ' + v[2];
	if (!length(c) || index(c, '#') >= 0) return c;	/* un «#» nel comando chiuderebbe l'involucro: resta com'è */
	let e = substr(c, length(c) - 1);
	return '{ ' + c + ((e == '&' || e == ';') ? ' }' : '; }') + ' ; ucode ' + SVC + ' log ' + id + ' $?';
}
/* riga dell'app → { on, when, cmd (senza involucro), meta, mraw, id } o null */
function crparse(l) {
	let off = substr(l, 0, 6) == '#off# ', s = off ? substr(l, 6) : l, mm = match(s, / #(wrtfreedom|x3000) /);
	if (!mm || match(s, CRWF)) return null;
	let mi = index(s, mm[0]), mraw = substr(s, mi + length(mm[0])), meta = null;
	try { meta = json(replace(mraw, /\\%/g, '%')); } catch (e) {}
	if (type(meta) != 'object') return null;
	let f = match(substr(s, 0, mi), /^[ \t]*([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+(.*)$/s);
	if (!f) return null;
	let cmd = crunwrap(f[6]), a = '' + (meta.a ?? ''), id = match('' + (meta.i ?? ''), /^[0-9a-f]{8}$/) ? meta.i :
		crhash(a + '|' + (meta.x ?? '') + '|' + (meta.n ?? '') + '|' + (meta.w ?? '') + (a == 'custom' || a == '' ? '|' + cmd : ''));
	return { on: !off, when: join(' ', slice(f, 1, 6)), cmd: cmd, meta: meta, mraw: mraw, id: id, mk: mm[1] };
}
/* crontab diviso: sys (righe di sistema, commenti), wf (righe del pacchetto, riparate e senza doppioni), app (righe
   dell'app); fixed = righe del pacchetto riparate o doppie tolte */
function crsplit(txt) {
	let sys = [], app = [], W = {}, order = [], fixed = 0;
	for (let l in split(txt ?? '', '\n')) {
		l = rtrim(l);
		if (!length(l)) continue;
		/* riga del pacchetto rovinata dall'app: «… # wf:<tag> #wrtfreedom {…}» → «… # wf:<tag>» (spenta resta spenta) */
		let bad = match(l, /^(#off# )?(.* # wf:[a-z0-9_]{1,40}) #(wrtfreedom|x3000) .*$/);
		if (bad) { l = (bad[1] ?? '') + bad[2]; fixed++; }
		let w = match(l, CRWF);
		if (w) { if (W[w[1]] != null) fixed++; else push(order, w[1]); W[w[1]] = l; continue; }
		let p = crparse(l);
		if (p) push(app, p); else push(sys, l);
	}
	return { sys: sys, app: app, wf: map(order, (t) => ({ tag: t, line: W[t] })), fixed: fixed };
}
function crline(p) { return (p.on ? '' : '#off# ') + p.when + ' ' + crwrap(p.cmd, p.id) + ' #' + p.mk + ' ' + p.mraw; }
/* scrittura del crontab (file a parte e rinomina), cron riavviato solo se cambia */
function crwrite(n) {
	let o = readfile(CRONF) ?? '';
	if (n == o) return false;
	mkdir('/etc/crontabs');
	writefile(CRONF + '.wf', n);
	rename(CRONF + '.wf', CRONF);
	sh('( /etc/init.d/cron enabled || /etc/init.d/cron enable; /etc/init.d/cron restart ) >/dev/null 2>&1 </dev/null &');
	return true;
}
/* discendenti di un processo (figli, nipoti: i curl lanciati da «sh -c»), dalle righe /proc/<pid>/stat (solo letture) */
function pdesc(p) {
	let K = {}, o = [ '' + p ];
	for (let n in lsdir('/proc') ?? []) {
		if (!match(n, /^[0-9]{1,10}$/)) continue;
		let s = readfile('/proc/' + n + '/stat') ?? '', i = rindex(s, ')'), f = i >= 0 ? split(substr(s, i + 2), ' ') : [];
		if (match(f[1] ?? '', /^[0-9]{1,10}$/)) { if (!K[f[1]]) K[f[1]] = []; push(K[f[1]], n); }
	}
	for (let i = 0; i < length(o) && i < 200; i++) for (let c in K[o[i]] ?? []) push(o, c);
	return slice(o, 1);
}
/* attività All'Avvio tolta, spenta o cambiata: ferma il processo partito (pid in /tmp/wf-svc.<id>, solo se è ancora suo:
   la sua riga di comando contiene wf-svc.<id>) con tutti i suoi figli, poi toglie pid, esito e conto delle ripartenze */
function crsvcstop(id) {
	if (!match(id, /^[0-9a-f]{8}$/)) return;
	let F = '/tmp/wf-svc.' + id, pid = '' + int(+trim(readfile(F) ?? '0')), cl = readfile('/proc/' + pid + '/cmdline');
	if (+pid > 1 && cl != null && index(cl, 'wf-svc.' + id) >= 0) {
		sh('kill ' + join(' ', [ pid, ...pdesc(pid) ]) + ' 2>/dev/null');
	}
	for (let x in ['', '.rc', '.st']) unlink(F + x);
}
function crtext(C) {
	let L = [...C.sys, ...map(C.app, crline), ...map(C.wf, (w) => w.line)];
	return length(L) ? join('\n', L) + '\n' : '';
}
/* registro delle esecuzioni: righe «ora|id|esito|tipo» (c = orario, r = recuperata all'avvio, n = Esegui Ora) */
function crlog(n) {
	let out = [], L = split(trim(readfile('/tmp/wf-cronrun.log') ?? readfile('/etc/wrtfreedom/cronrun.log') ?? ''), '\n');
	for (let i = length(L) - 1; i >= 0 && length(out) < n; i--) {
		let p = match(L[i], /^([0-9]{1,12})\|([0-9a-f]{8})\|(-?[0-9]{1,5})\|([crn])$/);
		if (p) push(out, { t: +p[1], id: p[2], rc: +p[3], k: p[4] });
	}
	return out;
}

/* DDNS (2.53): impostazioni di un servizio con i nomi veri delle opzioni (ddns-scripts recente usa retry_max_count, le
   unità dei tempi sono check_unit, force_unit, retry_unit; con ip_source network conta ip_network) */
function ddretry() { return index(readfile('/usr/lib/ddns/dynamic_dns_functions.sh') ?? 'retry_max_count', 'retry_max_count') >= 0 ? 'retry_max_count' : 'retry_count'; }
function ddcfg(s, rk) {
	let n = (v, d) => (v != null && match('' + v, /^[0-9]{1,6}$/)) ? +v : d;
	return { src: s.ip_source ?? 'network', net: s.ip_network ?? '', dev: s.ip_interface ?? '', url: s.ip_url ?? '', ifc: s.interface ?? '',
		check: [ n(s.check_interval, 10), s.check_unit ?? 'minutes' ], force: [ n(s.force_interval, 72), s.force_unit ?? 'hours' ],
		retry: [ n(s.retry_max_count ?? s.retry_count, 0), s.retry_max_count != null ? 'retry_max_count' : s.retry_count != null ? 'retry_count' : rk ],
		rwait: [ n(s.retry_interval, 60), s.retry_unit ?? 'seconds' ], v6: s.use_ipv6 == '1', dns: s.dns_server ?? '',
		/* DuckDNS con il solo sottonome in «domain» (come lo vuole il provider): resta così */
		short: match(s.service_name ?? '', /duckdns/) != null && length(s.domain ?? '') > 0 && index(s.domain, '.') < 0 };
}
const DDUNIT = /^(seconds|minutes|hours|days)$/;

/* Controllo Della Linea (2.53): profili per orario in wrtfreedom.sqmp_<id> e righe «# wf:sqmp_<id>» (cron.sh sqmp) */
const SQMCTL = '/usr/share/wrtfreedom/sqmctl.sh';
function sqmprofs(W) {
	W = W ?? ucfile('wrtfreedom');
	let out = [];
	for (let k in W) {
		let s = W[k], m = match(k, /^sqmp_([a-z0-9]{1,12})$/);
		if (s['.type'] != 'sqmp' || !m) continue;
		push(out, { id: m[1], name: s.name ?? '', on: s.enabled == '1', hour: +(s.hour ?? 0), min: +(s.min ?? 0), days: s.days ?? '*',
			mode: s.mode ?? 'auto', prof: s.prof ?? 'bal', dl: +(s.dl ?? 0), ul: +(s.ul ?? 0) });
	}
	return out;
}

/* Bot Per Più Persone (2.53): chat in più in wrtfreedom.tgc_<id> (id, role a = solo avvisi, s = avvisi e comandi
   sicuri, t = tutto, name); la chat collegata con il bot ha sempre tutto */
function tgchatlist(W) {
	W = W ?? ucfile('wrtfreedom');
	return map(filter(keys(W), (k) => W[k]['.type'] == 'tgchat' && match(W[k].id ?? '', /^-?[0-9]{1,20}$/)), (k) => ({ sec: k, id: W[k].id, role: W[k].role ?? 'a', name: W[k].name ?? '' }));
}
/* messaggio in coda per una sola chat (tgq.uc, intestazione «#to:<chat>») */
function tgqto(chat, text) {
	mkdir('/tmp/wf-tgq');
	writefile('/tmp/wf-tgq/' + time() + '-' + wkey(8), '#to:' + chat + '\n' + text);
	sh('( ucode /usr/share/wrtfreedom/tgq.uc flush ) </dev/null >/dev/null 2>&1 &');
}
/* ospiti accesi o spenti; min > 0 = si spengono da soli dopo min minuti (wrtfreedom.guest.until, controllata da notify.sh).
   Allo spegnimento, se c'è un cambio di password in attesa (pend = ora della richiesta), si fa adesso */
function guestset(on, min, bands) {
	let G = guestifs();
	if (!length(G)) return { error: 'nessuna rete ospiti' };
	/* 2.64 B3: bands ('2g', '5g'…, separate da spazi) = accese solo le reti ospiti di quelle bande, le altre spente */
	let BW = on && length(bands ?? '') ? split(bands, ' ') : null, WL0 = ucfile('wireless'), GB = BW ? filter(G, (g) => index(BW, rband(WL0[ug(WL0, g, 'device')])) >= 0) : null;
	if (BW && !length(GB)) return { error: 'nessuna rete ospiti su questa banda' };
	cfgensure();
	let W = ucfile('wrtfreedom'), WL = ucfile('wireless'), c = 'uci -q get wrtfreedom.guest >/dev/null || uci set wrtfreedom.guest=guest; ', k = null;
	/* bande scelte dall'utente: allo spegnimento si ricordano le reti ospiti accese (wrtfreedom.guest.ifs), all'accensione
	   (anche dopo «Per Un Po'») si riaccendono solo quelle; nessuna scelta salvata = tutte */
	let now_on = filter(G, (g) => ug(WL, g, 'disabled') != '1'), sel = filter(split(ug(W, 'guest', 'ifs'), ' '), (x) => index(G, x) >= 0);
	if (!on && length(now_on)) { c += udel('wrtfreedom', 'guest', 'ifs'); for (let g in now_on) c += 'uci add_list ' + q('wrtfreedom.guest.ifs=' + g) + '; '; }
	if (GB) { for (let g in G) c += uset('wireless', g, 'disabled', index(GB, g) >= 0 ? '0' : '1'); }
	else if (on) { for (let g in (length(sel) ? sel : G)) c += uset('wireless', g, 'disabled', '0'); }
	else for (let g in G) c += uset('wireless', g, 'disabled', '1');
	c += (on && min > 0) ? uset('wrtfreedom', 'guest', 'until', '' + (time() + min * 60)) : udel('wrtfreedom', 'guest', 'until');
	if (!on && length(ug(W, 'guest', 'pend'))) {
		k = wkey(10);
		for (let g in G) c += uset('wireless', g, 'key', k);
		c += udel('wrtfreedom', 'guest', 'pend') + udel('wrtfreedom', 'guest', 'pendwarn');
	}
	sh(c + 'uci commit wireless; uci commit wrtfreedom; ( wifi reload ) >/dev/null 2>&1 </dev/null &');
	if (k) wevent('guest_pwd', L('🔑 Nuova password della rete ospiti: la trovi nell\'app', '🔑 New guest network password: see the app'));
	return { ok: true, until: (on && min > 0) ? time() + min * 60 : null };
}
/* Limite Di Velocità della rete ospiti: si può usare se ci sono tc e il modulo sch_cake */
function glimcan() {
	let tc = has('/sbin/tc') || has('/usr/sbin/tc') || has('/usr/bin/tc');
	let ck = has('/sys/module/sch_cake') || length(filter(lsdir('/lib/modules') ?? [], (v) => has('/lib/modules/' + v + '/sch_cake.ko'))) > 0;
	return !tc ? 'manca tc (pacchetto tc-tiny o tc-full)' : !ck ? 'manca il modulo kmod-sched-cake' : null;
}
/* testo del QR di una rete (formato WIFI: con l'escape di \ ; , : " e nopass per le reti aperte) */
function wqr(s) {
	let e = (x) => replace('' + x, /([\\;,:"])/g, '\\$1'), enc = '' + (s.encryption ?? 'none'), k = '' + (s.key ?? '');
	let open = enc == 'none' || match(enc, /^owe/) || !length(k);
	return 'WIFI:T:' + (open ? 'nopass' : 'WPA') + ';S:' + e(s.ssid ?? '') + ';' + (open ? '' : 'P:' + e(k) + ';') + (s.hidden == '1' ? 'H:true;' : '') + ';';
}
/* elemento Neighbor Report di un punto di accesso (se hostapd non lo dà con rrm_nr_get_own): BSSID, informazioni
   (raggiungibile, sicurezza, QoS, RRM, HT, VHT), classe operativa, canale, tipo PHY */
function wnr(ifn) {
	let own = ubcall('hostapd.' + ifn, 'rrm_nr_get_own');
	if (type(own?.value) == 'array' && length(own.value[2] ?? '')) return own.value[2];
	let st = ubcall('hostapd.' + ifn, 'get_status') ?? {}, b = replace(lc(trim(readfile('/sys/class/net/' + ifn + '/address') ?? '')), /:/g, '');
	let ch = +(st.channel ?? 0), oc = +(st.op_class ?? 0);
	if (!oc) oc = ch <= 14 ? 81 : ch >= 149 ? 125 : ch >= 100 ? 121 : ch >= 52 ? 118 : 115;
	return length(b) == 12 && ch ? b + 'af180000' + sprintf('%02x%02x%02x', oc, ch, ch <= 14 ? 7 : 9) : null;
}

/* ---------------- Dispositivi (2.49) ----------------
   Il lavoro con processi (nft, ip, AdGuard) lo fa dev.uc in sottofondo; qui letture di file e uci, scritture di uci solo
   alle modifiche. Collegato = presenza di notify.sh (/tmp/wf-pres), una sola definizione per app, bot e notifiche. */
const DEVUC = '/usr/share/wrtfreedom/dev.uc', DEVNFT = '/usr/share/nftables.d/table-pre/91-wrtfreedom-dev.nft';
const DTMP = '/tmp/wf-dev.json', DPZ = '/tmp/wf-dpause.json', PRESD = '/tmp/wf-pres', SEEN = '/etc/wrtfreedom/seen';
const DTYPE = '/etc/wrtfreedom/devtype.json', SHJSON = '/etc/wrtfreedom/shaper.json', SHNFT = '/etc/nftables.d/90-wrtfreedom.nft';
const DTYPES = ['phone', 'tablet', 'computer', 'tv', 'console', 'printer', 'speaker', 'smart', 'camera', 'nas', 'network', 'watch'];
/* pause delle persone e Pausa Per Tutti: in /tmp e, a ogni modifica, in /etc/wrtfreedom (dev.uc le ricarica dopo un
   riavvio); lette da /etc se /tmp non c'è ancora */
const DPZE = '/etc/wrtfreedom/dpause.json';
function dpzget() { return rjs(DPZ) ?? rjs(DPZE) ?? {}; }
function dpzset(P) { wjs(DPZ, P); mkdir('/etc/wrtfreedom'); writefile(DPZE + '.t', sprintf('%J', P)); rename(DPZE + '.t', DPZE); }
function devbg(a) { sh('( ucode ' + DEVUC + ' ' + a + ' ) >/dev/null 2>&1 </dev/null &'); }
function devev(tp, txt) { sh('sh /usr/share/wrtfreedom/event.sh cron ' + q(tp) + ' dev ' + q(txt) + ' >/dev/null 2>&1 </dev/null &'); }
function m12(m) { return replace(m, /:/g, ''); }
function dday(t) { let n = localtime(t); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
/* elenco di MAC da una stringa (spazi, virgole o punti e virgola), minuscoli, senza doppioni, al massimo n */
function maclist(s, n) {
	let R = [];
	for (let x in split(lc('' + (s ?? '')), /[ ,;]+/)) if (okmac(x) && index(R, x) < 0 && length(R) < n) push(R, x);
	return R;
}
/* presenza da notify.sh: /tmp/wf-pres/<mac senza :> = «on|off <secondi dall'accensione> [come: Wi-Fi_5_GHz, cavo]».
   «on» vale solo se riscritto da poco (notify.sh lo rinnova ogni 10 s): un servizio fermo non lascia collegati finti */
function presence() {
	let R = {}, up = upsec(), now = time();
	for (let f in lsdir(PRESD) ?? []) {
		if (!match(f, /^[0-9a-f]{12}$/)) continue;
		let p = split(trim(readfile(PRESD + '/' + f) ?? ''), ' '), x = +(p[1] ?? 0);
		let mac = join(':', map([0, 2, 4, 6, 8, 10], (i) => substr(f, i, 2)));
		R[mac] = { on: p[0] == 'on' && x <= up && up - x < 240, last: (x > 0 && x <= up) ? now - (up - x) : null, via: p[2] ?? '' };
	}
	return R;
}
/* dispositivi già visti (/etc/wrtfreedom/seen): «mac» = conosciuto, «mac ?» = nuovo da confermare */
function seenmap() {
	let K = {};
	for (let l in split(readfile(SEEN) ?? '', '\n')) { let p = split(trim(l), ' '); if (okmac(p[0])) K[p[0]] = p[1] != '?'; }
	return K;
}
function seenwrite(mac, known) {
	let L = filter(split(readfile(SEEN) ?? '', '\n'), (l) => length(trim(l)) && split(trim(l), ' ')[0] != mac);
	if (known) push(L, mac);
	mkdir('/etc/wrtfreedom');
	writefile(SEEN + '.t', length(L) ? join('\n', L) + '\n' : '');
	rename(SEEN + '.t', SEEN);
}
/* nomi e indirizzi: assegnazioni DHCP (file di dnsmasq della configurazione), poi gli IP fissi (dhcp host) */
function leases() {
	let D = ucfile('dhcp'), H = {}, lf = '/tmp/dhcp.leases';
	for (let k in D) if (D[k]['.type'] == 'dnsmasq' && length(D[k].leasefile ?? '')) { lf = D[k].leasefile; break; }
	for (let l in split(readfile(lf) ?? '', '\n')) {
		let p = split(l, ' ');
		if (length(p) >= 4 && okmac(lc(p[1]))) H[lc(p[1])] = { ip: p[2], name: p[3] == '*' ? '' : p[3] };
	}
	for (let k in D) if (D[k]['.type'] == 'host')
		for (let m in split(lc(join(' ', vpnarr(D[k].mac))), /[ \t]+/)) if (okmac(m)) {
			let h = H[m] = H[m] ?? { ip: '', name: '' };
			if (length(D[k].name ?? '')) h.name = D[k].name;
			if (!length(h.ip) && length(D[k].ip ?? '')) h.ip = D[k].ip;
		}
	return H;
}
/* Flow Offloading: il traffico accelerato salta la catena forward (contatori, limiti e pause per dispositivo) */
function devcan() {
	if (!has('/sbin/fw4')) return { can: false, why: 'serve firewall4 (nftables)' };
	let F = ucfile('firewall');
	for (let k in F) if (F[k]['.type'] == 'defaults' && (F[k].flow_offloading == '1' || F[k].flow_offloading_hw == '1'))
		return { can: false, why: 'Flow Offloading acceso: il traffico accelerato non passa dai contatori e dai limiti' };
	return { can: true, why: null };
}
/* tabella dei produttori (oui.txt: «nome|tipo|prefissi»), letta una volta */
let OUI = null;
function ouiget(mac) {
	if (OUI == null) {
		OUI = {};
		for (let l in split(readfile('/usr/share/wrtfreedom/oui.txt') ?? '', '\n')) {
			let p = split(l, '|');
			if (substr(l, 0, 1) == '#' || length(p) < 3) continue;
			for (let x in split(p[2], ' ')) if (length(x) == 6) OUI[x] = [p[0], p[1]];
		}
	}
	return OUI[uc(m12(substr(mac, 0, 8)))];
}
/* tipo dal nome del dispositivo (l'ordine conta: orologio e tablet prima del telefono) */
const DTNAME = [
	[/watch/i, 'watch'], [/ipad|tablet|galaxy-?tab|kindle|fire-?hd|mediapad|matepad/i, 'tablet'],
	[/xbox|playstation|ps[345]|nintendo|steam-?deck/i, 'console'],
	[/tv|bravia|webos|roku|chromecast|fire-?stick|shield|tizen|vidaa|televisore/i, 'tv'],
	[/echo|alexa|homepod|sonos|google-?home|nest-?(mini|audio|hub)|speaker|soundbar/i, 'speaker'],
	[/printer|stampante|epson|canon|brother|laserjet|officejet|deskjet|^hp[0-9a-f]{6}/i, 'printer'],
	[/camera|telecamera|cam-|ipcam|doorbell|ring-|nvr|dvr/i, 'camera'],
	[/nas|synology|diskstation|qnap|truenas/i, 'nas'],
	[/iphone|android|galaxy|pixel|redmi|oneplus|oppo|realme|vivo|nokia|moto|telefono|phone|huawei|honor|xiaomi|poco|sm-[a-z]/i, 'phone'],
	[/macbook|imac|mac-?mini|mac-?studio|desktop|laptop|portatile|notebook|thinkpad|pc|windows|linux|ubuntu|raspberry/i, 'computer'],
	[/esp|shelly|tasmota|tapo|tuya|hue|nest|termostato|thermostat|presa|plug|bulb|lampada|sensor|vacuum|roborock|robot|smart/i, 'smart'],
	[/router|repeater|extender|mesh|access-?point|fritz|deco|unifi/i, 'network']
];
function nametype(n) {
	if (!length(n)) return null;
	for (let x in DTNAME) if (match(n, x[0])) return x[1];
	return null;
}
/* classe del fornitore DHCP (aggancio hotplug di dnsmasq → /tmp/wf-dhcpvc «mac classe») */
function vctype(v) {
	if (match(v, /^android-dhcp/i)) return 'phone';
	if (match(v, /^MSFT/)) return 'computer';
	if (match(v, /^udhcp/)) return 'smart';
	if (match(v, /^ubnt/i)) return 'network';
	return null;
}
/* Limita Velocità, fasce e Rallenta Per Un Po' per dispositivo (shaper; fasce con giorni, persone, Tutta La Casa Insieme
   e scadenza dalla 2.59): solo nftables, mai tc né code (le regole SQM dell'utente restano come sono); solo il traffico
   che il router inoltra, mai la sua connessione (VPN, DDNS, bot). Ogni voce di shaper.json vale per un MAC (mac), per i
   dispositivi di una persona (macs: un limite per dispositivo) o per Tutta La Casa Insieme (casa: un solo limite in
   comune tra le interfacce di casa e il resto); un posto per bersaglio, al massimo SHMAX. Senza orari (Limita Velocità):
   download agli IP v4 e v6 del dispositivo negli insiemi wfl4_/wfl6_<mac> (riempiti da dev.uc dalla tabella dei vicini),
   upload per MAC esatto. Con fascia (from/to, days = cifre 0…6 con 0 = domenica) o scadenza (until, Rallenta Per Un
   Po'): insiemi wft*_<n> che dev.uc riempie solo mentre la voce vale, con l'ora di casa (giorni, mezzanotte e cambio
   dell'ora giusti senza ricaricare il firewall; se i giri si fermano gli elementi scadono dopo 3 minuti e il limite si
   toglie da solo), descritti nella riga «# wf:gates» del file. Ogni bersaglio ha il suo limite e i limiti si
   susseguono (limit … drop): se valgono più fasce, o anche Limita Velocità, passa la più bassa, in download e in upload.
   Voci con off: true salvate ma non applicate; voci scadute tolte al salvataggio. Regole vecchie con il solo IP come
   prima (meta hour) */
const SHMAX = 63, SHHM = /^([01][0-9]|2[0-3]):[0-5][0-9]$/, SHWHO = /^(casa|p:p_[a-z0-9]{1,16}|d:[0-9a-f]{12})$/;
/* bersagli di una voce: ['casa'], i MAC della persona (al massimo 16) o il MAC; [] = regola vecchia con il solo IP */
function shtargets(r) {
	if (r.casa === true) return ['casa'];
	let T = [];
	if (type(r.macs) == 'array') {
		for (let x in r.macs) { let m = lc('' + x); if (okmac(m) && index(T, m) < 0 && length(T) < 16) push(T, m); }
		return T;
	}
	let m = lc('' + (r.mac ?? ''));
	return okmac(m) ? [m] : [];
}
/* voce con orari, giorni o scadenza (vale solo in certi momenti) */
function shtimed(r) { return r.from != null || r.to != null || length('' + (r.days ?? '')) > 0 || r.until != null; }
/* orari e giorni validi (from e to insieme; days cifre 0…6 senza doppioni) */
function shwinok(r) {
	if ((r.from != null || r.to != null) && (!match('' + r.from, SHHM) || !match('' + r.to, SHHM))) return false;
	let d = '' + (r.days ?? '');
	if (length(d) && (!match(d, /^[0-6]{1,7}$/) || length(uniq(split(d, ''))) != length(d))) return false;
	return r.until == null || +r.until > 0;
}
/* voce che si applica adesso: valida, accesa, non scaduta, con almeno un limite o una priorità */
function shlive(r, now) {
	if (type(r) != 'object' || r.meta != null || r.off === true) return false;
	if (r.until != null && !(+r.until > now)) return false;
	let dl = +r.dl, ul = +r.ul;
	return ((dl > 0 && dl <= 10000) || (ul > 0 && ul <= 10000) || r.prio == 'high' || r.prio == 'low') && shwinok(r);
}
/* interfacce WireGuard di casa (server per i client VPN), lette dal router: proto wireguard, non nelle zone con il
   mascheramento (i tunnel verso internet, come il Servizio VPN, portano il download vero e restano contati) */
function shwgifs() {
	let N = ucfile('network'), F = ucfile('firewall'), wn = {}, L = [];
	for (let k in F) if (F[k]['.type'] == 'zone' && F[k].masq == '1') for (let x in split(ug(F, k, 'network'), /[ \t]+/)) if (length(x)) wn[x] = true;
	for (let k in N) if (N[k]['.type'] == 'interface' && N[k].proto == 'wireguard' && !wn[k] && match(k, /^[A-Za-z0-9_.@-]{1,15}$/)) push(L, k);
	return L;
}
/* file delle regole e posti usati: { nft (null = nessuna regola), need = posti chiesti }. Il file si scrive solo con
   need <= SHMAX (chi chiama lo controlla prima) */
function shapergen(R, named) {
	let ip4 = /^(\d{1,3}\.){3}\d{1,3}$/, L = [], top = [], G = [], seen = {}, cnt = {}, n = 0, need = 0, now = time();
	let rate = (v) => 'rate over ' + int(v * 125) + ' kbytes/second burst ' + int(v * 16 + 64) + ' kbytes', wg = null;
	for (let i = 0; i < length(R); i++) {
		let r = R[i];
		if (!shlive(r, now)) continue;
		let dl = +r.dl, ul = +r.ul, pr = r.prio == 'high' ? 'cs5' : r.prio == 'low' ? 'cs1' : null, T = shtargets(r), tmd = shtimed(r);
		if (!(dl > 0 && dl <= 10000)) dl = 0;
		if (!(ul > 0 && ul <= 10000)) ul = 0;
		if (!length(T)) {
			/* regola vecchia con il solo IP (1.1) */
			let ip = '' + (r.ip ?? ''), tm = '';
			if (!match(ip, ip4)) continue;
			need++;
			if (r.from != null) tm = ' meta hour "' + r.from + '"-"' + r.to + '"';
			if (dl) push(L, '\t\tip daddr ' + ip + tm + ' limit ' + rate(dl) + ' drop');
			if (ul) push(L, '\t\tip saddr ' + ip + tm + ' limit ' + rate(ul) + ' drop');
			if (pr) push(L, '\t\tip saddr ' + ip + tm + ' ip dscp set ' + pr);
			continue;
		}
		need += length(T);
		if (need > SHMAX) continue;
		let gw = { i: i, f: r.from ?? null, t: r.to ?? null, d: '' + (r.days ?? ''), u: r.until != null ? int(+r.until) : null };
		for (let x in T) {
			n++;
			if (x == 'casa') {
				/* Tutta La Casa Insieme: un limite in comune sul traffico tra le interfacce di casa e il resto; nel download
				   non conta quello che arriva dai client VPN di casa (WireGuard) */
				let s = 'wfti_' + n;
				push(top, 'set ' + s + ' { type ifname; flags timeout; }');
				push(G, { ...gw, n: n, c: 1 });
				wg = wg ?? shwgifs();
				if (dl) push(L, '\t\tiifname != @' + s + (length(wg) ? ' iifname != { ' + join(', ', map(wg, (x) => '"' + x + '"')) + ' }' : '') + ' oifname @' + s + ' limit ' + rate(dl) + ' drop');
				if (ul) push(L, '\t\tiifname @' + s + ' oifname != @' + s + ' limit ' + rate(ul) + ' drop');
				continue;
			}
			let id = m12(x), s4, s6, src, ln;
			if (tmd) {
				s4 = 'wft4_' + n; s6 = 'wft6_' + n; src = 'ether saddr @wftm_' + n; ln = 'wft_' + n;
				push(top, 'set ' + s4 + ' { type ipv4_addr; flags timeout; }', 'set ' + s6 + ' { type ipv6_addr; flags timeout; }', 'set wftm_' + n + ' { type ether_addr; flags timeout; }');
				push(G, { ...gw, n: n, m: x });
			}
			else {
				s4 = 'wfl4_' + id; s6 = 'wfl6_' + id; src = 'ether saddr ' + x;
				cnt[x] = (cnt[x] ?? 0) + 1;
				ln = 'wfl_' + id + (cnt[x] > 1 ? '_' + cnt[x] : '');
				if (!seen[x]) { seen[x] = true; push(top, 'set ' + s4 + ' { type ipv4_addr; }', 'set ' + s6 + ' { type ipv6_addr; }'); }
			}
			if (dl) {
				/* un limite per v4 e v6 insieme (limite con nome); senza, uno per famiglia */
				let lim = named ? 'limit name "' + ln + '"' : 'limit ' + rate(dl);
				if (named) push(top, 'limit ' + ln + ' { ' + rate(dl) + ' }');
				push(L, '\t\tip daddr @' + s4 + ' ' + lim + ' drop', '\t\tip6 daddr @' + s6 + ' ' + lim + ' drop');
			}
			if (ul) push(L, '\t\t' + src + ' limit ' + rate(ul) + ' drop');
			if (pr) push(L, '\t\t' + src + ' ip dscp set ' + pr, '\t\t' + src + ' ip6 dscp set ' + pr);
		}
	}
	if (!length(L) || need > SHMAX) return { nft: null, need: need };
	return { need: need, nft: '# WrtFreedom: limiti, fasce e priorità per dispositivo (non modificare a mano)\n# wf:gates ' + replace(sprintf('%J', G), /\n/g, ' ') + '\n' +
		(length(top) ? join('\n', top) + '\n' : '') + 'chain wrtfreedom_shaper {\n\ttype filter hook forward priority filter - 1; policy accept;\n' + join('\n', L) + '\n}\n' };
}
/* voci prima del salvataggio: scadute tolte, id a quelle con scadenza che non lo hanno */
function shnorm(R, now) {
	let O = [];
	for (let i = 0; i < length(R); i++) {
		let r = R[i];
		if (type(r) == 'object' && r.meta == null && r.until != null && !(+r.until > now)) continue;
		if (type(r) == 'object' && r.until != null && !match('' + (r.id ?? ''), /^[A-Za-z0-9_]{1,32}$/)) r = { ...r, id: 'slow_' + now + '_' + i };
		push(O, r);
	}
	return O;
}
/* una voce dal bot o dall'app senza rimandare tutto (shaper {add}): kind slow = Rallenta Per Un Po' (min 1…1440 o until
   entro 24 ore; id slow_<casa|persona|mac>, una per bersaglio), fix = Limita Velocità del MAC (off: true o dl 0 lo
   toglie; tiene la priorità e aggiorna meta.cl per l'app; 2.64: prio high|normal|low senza dl = solo la priorità, il
   limite resta), altre con id = sostituita o aggiunta. Errore = testo */
function shadd(R, x, now) {
	if (type(x) != 'object' || x.meta != null) return 'voce non valida';
	let k = '' + (x.kind ?? ''), T = shtargets(x), w = '' + (x.who ?? ''), dl = +(x.dl ?? 0), ul = +(x.ul ?? 0);
	if (length(w) && !match(w, SHWHO)) return 'voce non valida';
	if (k == 'fix') {
		let mac = lc('' + (x.mac ?? '')), id = m12(mac), pr = x.prio != null ? '' + x.prio : null, keep = pr != null && dl == 0 && x.off !== true;
		let off = !keep && (x.off === true || dl == 0), done = keep, pd = pr == null || pr == 'normal', O = [], M = null;
		if (!okmac(mac)) return 'dispositivo non valido';
		if (pr != null && index([ 'high', 'normal', 'low' ], pr) < 0) return 'priorità non valida';
		if (!off && !keep && !(dl > 0 && dl <= 10000 && ul >= 0 && ul <= 10000)) return 'velocità non valida (1…10000 Mbit/s)';
		for (let r in R) {
			if (type(r) == 'object' && r.meta != null) { M = r; push(O, r); continue; }
			if (type(r) != 'object' || lc('' + (r.mac ?? '')) != mac || r.casa === true || r.macs != null || shtimed(r)) { push(O, r); continue; }
			let y = { ...r };
			if (!keep) { delete y.dl; delete y.ul; }
			if (!off && !done) { y.dl = dl; y.ul = ul || dl; done = true; }
			if (pr != null) { delete y.prio; if (!pd) { y.prio = pr; pd = true; } }
			if (y.dl != null || y.prio == 'high' || y.prio == 'low') push(O, y);
		}
		if (!off && !done) { push(O, { id: 'fix_' + id, kind: 'fix', who: 'd:' + id, mac: mac, dl: dl, ul: ul || dl, ...(pd ? {} : { prio: pr }) }); pd = true; }
		if (!pd) push(O, { id: 'fix_' + id, kind: 'fix', who: 'd:' + id, mac: mac, prio: pr });
		if (!M) { M = { meta: {} }; push(O, M); }
		if (type(M.meta) != 'object') M.meta = {};
		if (type(M.meta.cl) != 'object') M.meta.cl = {};
		let c = M.meta.cl[id] ?? { prio: 'normal' };
		if (!keep) c = off ? { ...c, limit: false } : { ...c, limit: true, dl: dl, ul: ul || dl };
		M.meta.cl[id] = pr != null ? { ...c, prio: pr } : c;
		return O;
	}
	if (!length(T)) return 'dispositivo non valido';
	if (!(dl > 0 && dl <= 10000) || !(ul >= 0 && ul <= 10000)) return 'velocità non valida (1…10000 Mbit/s)';
	if (k == 'slow') {
		let mn = +(x.min ?? 0), u = mn > 0 ? now + int(mn * 60) : int(+(x.until ?? 0));
		if (mn > 1440 || !(u > now && u <= now + 86400)) return 'durata non valida (fino a 24 ore)';
		let key = T[0] == 'casa' ? 'casa' : substr(w, 0, 2) == 'p:' ? substr(w, 2) : m12(T[0]), id = 'slow_' + key;
		let y = { id: id, kind: 'slow', who: length(w) ? w : (T[0] == 'casa' ? 'casa' : 'd:' + m12(T[0])), dl: dl, ul: ul || dl, until: u };
		if (T[0] == 'casa') y.casa = true; else if (type(x.macs) == 'array') y.macs = T; else y.mac = T[0];
		return [ ...filter(R, (r) => type(r) != 'object' || r.id != id), y ];
	}
	let id = '' + (x.id ?? '');
	if (!match(id, /^[A-Za-z0-9_]{1,32}$/)) return 'voce senza id';
	if (!shwinok(x)) return 'orari o giorni non validi';
	let O = [], put = false;
	for (let r in R) { if (type(r) == 'object' && r.id == id) { if (!put) push(O, x); put = true; } else push(O, r); }
	if (!put) push(O, x);
	return O;
}
/* file delle regole con fw4 check (prima con i limiti con nome, poi uno per famiglia); rifiutate = file di prima.
   Copia di sicurezza (file delle regole e shaper.json) in /etc/wrtfreedom, fuori da /etc/nftables.d/*.nft: rimessa in
   caso di errore e, se il processo si interrompe, alla volta dopo (o dal giro di dev.uc). La ricarica del firewall la fa
   chi chiama, in sottofondo */
const SHBAK = '/etc/wrtfreedom/shaper.bak';
function shaperback() {
	let B = rjs(SHBAK);
	if (type(B) == 'object') {
		if (B.nft != null) writefile(SHNFT, B.nft); else unlink(SHNFT);
		if (B.json != null) writefile(SHJSON, B.json); else unlink(SHJSON);
	}
	unlink(SHBAK);
}
function shaperfile(R) {
	if (stat(SHBAK)) shaperback();
	let G = shapergen(R, true), old = readfile(SHNFT), n = G.nft, ok = true;
	if (G.need > SHMAX) return 'troppe regole: ' + G.need + ' posti su ' + SHMAX;
	mkdir('/etc/wrtfreedom');
	writefile(SHBAK + '.t', sprintf('%J', { nft: old, json: readfile(SHJSON) }));
	rename(SHBAK + '.t', SHBAK);
	try {
		if (n == null) unlink(SHNFT);
		else {
			mkdir('/etc/nftables.d');
			writefile(SHNFT, n);
			if (system('fw4 check >/dev/null 2>&1') != 0) { writefile(SHNFT, shapergen(R, false).nft); ok = system('fw4 check >/dev/null 2>&1') == 0; }
		}
		if (ok) { writefile(SHJSON + '.t', sprintf('%J', R)); rename(SHJSON + '.t', SHJSON); }
	} catch (e) { ok = false; }
	if (!ok) { shaperback(); return 'regole rifiutate dal firewall'; }
	unlink(SHBAK);
	return null;
}
/* interfacce con SQM acceso (solo per informazione: i limiti per dispositivo non le toccano) */
function sqmifs() {
	let Q = ucfile('sqm'), R = [];
	for (let k in Q) if (Q[k]['.type'] == 'queue' && Q[k].enabled == '1' && length(Q[k].interface ?? '')) push(R, Q[k].interface);
	return R;
}
/* shaper {} (2.59): si può usare, posti e voci salvate con lo stato. Lo stato delle voci con fascia o scadenza (on, next
   = prossimo cambio) lo calcola solo dev.uc a ogni giro (/tmp/wf-dev.json shp, legato alla versione del file delle
   regole); qui solo letto. on null = non ancora calcolato (subito dopo un salvataggio) o giro fermo (gate false) */
function shinfo(C, now) {
	let R = rjs(SHJSON), meta = null, L = [], H = leases(), W = ucfile('wrtfreedom'), P = (rjs(DTMP) ?? {}).shp ?? {}, st = stat(SHNFT);
	if (type(R) != 'array') R = [];
	let fresh = st != null && P.f == st.mtime && now - (P.t ?? 0) < 300, need = shapergen(R, false).need, tm = 0;
	for (let i = 0; i < length(R); i++) {
		let r = R[i];
		if (type(r) != 'object') continue;
		if (r.meta != null) { meta = r.meta; continue; }
		let T = shtargets(r), timed = shtimed(r), w = '' + (r.who ?? ''), dead = r.off === true || (r.until != null && !(+r.until > now));
		let nm = r.casa === true ? '' : substr(w, 0, 2) == 'p:' ? (W[substr(w, 2)]?.name ?? '') : length(T) ? (H[T[0]]?.name ?? '') : '';
		if (timed && !dead) tm++;
		push(L, { ...r, i: i, kind: r.kind ?? (r.until != null ? 'slow' : timed ? 'band' : 'fix'), name: nm, posti: length(T) || 1,
			on: dead ? false : !timed ? true : fresh ? P.on?.['' + i] === true : null, next: !dead && timed && fresh ? (P.next?.['' + i] ?? null) : null });
	}
	return { can: C.can, why: C.why, mac: true, v6: true, sqm: sqmifs(), now: now, max: SHMAX, used: need, left: need >= SHMAX ? 0 : SHMAX - need,
		gate: fresh || !tm, list: L, meta: meta };
}

/* ---------------- Mesi Precedenti (2.59) ----------------
   Storico dei mesi dalle Statistiche Del Traffico (nlbwmon): periodo e mesi tenuti letti da uci (database_interval,
   database_generations); i totali per MAC li prepara netx.uc nlbw in sottofondo (nlbw -c json -g mac -t <periodo>) in
   NLBWM, qui solo letti. «Conserva Dopo Il Riavvio»: database_directory su memoria permanente (NLBWDIR), con copia della
   configurazione e cartella di prima in wrtfreedom.nlbw.prev (rimessa da uninstall.sh); i file si copiano, mai si
   cancellano, e un file non sostituisce mai uno più grande */
const NLBWM = '/tmp/wf-nlbwm.json', NLBWRUN = '/tmp/wf-nlbwm.run', NLBWMV = '/tmp/wf-nlbwmv', NLBWDIR = '/etc/nlbwmon';
/* percorso vero (collegamenti seguiti, come /var → /tmp su OpenWrt) */
function rpath(p, depth) {
	let P = split(p, '/'), S = [];
	for (let i = 0; i < length(P); i++) {
		let x = P[i];
		if (!length(x) || x == '.') continue;
		if (x == '..') { pop(S); continue; }
		push(S, x);
		let l = depth < 8 ? readlink('/' + join('/', S)) : null;
		if (l != null) return rpath((substr(l, 0, 1) == '/' ? l : '/' + join('/', slice(S, 0, length(S) - 1)) + '/' + l) + '/' + join('/', slice(P, i + 1)), depth + 1);
	}
	return '/' + join('/', S);
}
/* la cartella sta in memoria temporanea (tmpfs o ramfs: si svuota a ogni riavvio)? Punto di montaggio più lungo */
function ramdir(p) {
	let r = rpath(p, 0), best = '', fs = '';
	for (let l in split(readfile('/proc/mounts') ?? '', '\n')) {
		let x = split(l, ' ');
		if (length(x) < 3) continue;
		let mp = x[1];
		if ((mp == '/' || r == mp || substr(r, 0, length(mp) + 1) == mp + '/') && length(mp) >= length(best)) { best = mp; fs = x[2]; }
	}
	return fs == 'tmpfs' || fs == 'ramfs';
}
/* configurazione di nlbwmon: sezione, cartella, periodo, mesi tenuti, salvataggio; in funzione secondo procd */
function nlbwconf() {
	let U = ucfile('nlbwmon'), k = null;
	for (let x in U) if (U[x]['.type'] == 'nlbwmon') { k = x; break; }
	let s = k ? U[k] : {}, dir = s.database_directory ?? '/var/lib/nlbwmon', sv = ubcall('service', 'list', { name: 'nlbwmon' }) ?? {}, on = false;
	for (let i in sv.nlbwmon?.instances ?? {}) if (sv.nlbwmon.instances[i].running) on = true;
	return { pkg: has('/usr/sbin/nlbw'), sec: k, on: on, dir: dir, interval: '' + (s.database_interval ?? '1'), gens: +(s.database_generations ?? 10),
		commit: '' + (s.commit_interval ?? '24h'), keep: !ramdir(dir) };
}
/* comando in sottofondo che sposta i dati di nlbwmon da una cartella all'altra (servizio fermato: salva prima di uscire) */
function nlbwmove(sec, fromdir, to) {
	return 'touch ' + NLBWMV + '; /etc/init.d/nlbwmon stop; mkdir -p ' + q(to) + '; for f in ' + q(fromdir) + '/*; do [ -f "$f" ] || continue; d=' + q(to) +
		'/"${f##*/}"; [ -f "$d" ] && [ "$(wc -c < "$d")" -ge "$(wc -c < "$f")" ] && continue; cp -p "$f" "$d"; done; ' +
		'uci set ' + q('nlbwmon.' + sec + '.database_directory=' + to) + '; uci commit nlbwmon; /etc/init.d/nlbwmon start; rm -f ' + NLBWM + ' ' + NLBWMV;
}
/* copia della configurazione di nlbwmon in /etc/wrtfreedom/bak (una volta, prima del primo cambio del pacchetto) */
const NLBWBAK = 'mkdir -p /etc/wrtfreedom/bak; [ -f /etc/wrtfreedom/bak/nlbwmon.conf ] || cp -p /etc/config/nlbwmon /etc/wrtfreedom/bak/nlbwmon.conf; ';
/* comando in sottofondo che cambia il giorno d'inizio dei periodi (database_interval, servizio fermato: salva prima) */
function nlbwstart(sec, d) {
	return 'touch ' + NLBWMV + '; ' + NLBWBAK + '/etc/init.d/nlbwmon stop; uci set ' + q('nlbwmon.' + sec + '.database_interval=' + d) +
		'; uci commit nlbwmon; /etc/init.d/nlbwmon start; rm -f ' + NLBWM + ' ' + NLBWMV;
}

/* ---------------- Stato Della Casa (2.49) ----------------
   Un solo calcolo per la Dashboard (casa), il bot (comando stato) e la notifica fissa (snapshot: casa_ok, casa_n).
   Sola lettura, nessun processo e nessuna attesa: file in /tmp dei lavori in sottofondo (line.sh, usage.uc, fwstat.uc,
   wifi.uc, vpnctl.uc, upd.sh, notify.sh, snapshot) e chiamate a netifd. Avvisi ignorati fino a mezzanotte in
   /tmp/wf-casa.ign ({day, ids}); la copia in /etc/wrtfreedom si scrive solo quando l'utente ignora o ripristina un
   avviso e dopo un riavvio vale ancora se è dello stesso giorno. */
const CASAIGN = '/tmp/wf-casa.ign', CASAIGNE = '/etc/wrtfreedom/casa.ign';
/* temperatura più alta dei sensori (°C), null = nessun sensore */
function thermc() {
	let tmax = 0;
	for (let z in (lsdir('/sys/class/thermal') ?? [])) {
		if (index(z, 'thermal_zone') != 0) continue;
		let t = +trim(readfile('/sys/class/thermal/' + z + '/temp') ?? '0');
		if (t > tmax) tmax = t;
	}
	return tmax > 0 ? int(tmax / 1000) : null;
}
/* linea: l'interfaccia che porta la rotta predefinita, qualunque sia il suo nome */
function wanpick(D) {
	for (let i in D)
		if (i.up && length(filter(i.route ?? [], function(x) { return x.target == '0.0.0.0' && +x.mask == 0; }))) return i;
	for (let i in D) if (match(i.interface, /^(wan|wwan|mob|modem|lte|5g)/)) return i;
	return null;
}
/* memoria interna usata (%): statvfs di ucode se c'è, altrimenti la radice di procd (system info, come df: usati su
   usati + disponibili, arrotondato in su), e solo se manca anche quella l'ultima lettura di snapshot (df, una volta al minuto) */
function diskpct(nofb) {
	let p = has('/overlay') ? '/overlay' : '/', f = null;
	try { f = require('fs').statvfs; } catch (e) {}
	if (type(f) == 'function') {
		let s = f(p), b = +(s?.blocks ?? s?.f_blocks ?? 0), a = +(s?.bavail ?? s?.f_bavail ?? 0);
		if (b > 0 && a >= 0 && a <= b) return int((b - a) * 100 / b + 0.5);
	}
	let rt = (ubcall('system', 'info') ?? {}).root ?? {}, u = +(rt.used ?? 0), av = +(rt.avail ?? 0);
	if (u >= 0 && av >= 0 && u + av > 0) return int((u * 100 + u + av - 1) / (u + av));
	if (nofb) return null;
	let c = rjs('/tmp/wf-snap.slow');
	/* valore di snapshot solo se recente (10 minuti): con snapshot fermo meglio «—» */
	return (type(c?.disk) == 'int' && type(c?.t) == 'int' && time() - c.t < 600) ? c.disk : null;
}
/* Salute Del Router (2.54): soglie uniche per Salute, Stato Della Casa, widget, bot, Avvisi Di Salute e controlli delle
   Pianificazioni (cron.sh spacecheck/tempcheck, dal campo th del metodo health) (wrtfreedom.health:
   temp 70|75|80 °C, disk 80|85|90 %, mem 85|90|95 %; «molto» = temperatura + 10 °C e spazio al 95%) */
function hth(W) {
	W = W ?? ucfile('wrtfreedom');
	let n = (o, ok, d) => { let v = +(ug(W, 'health', o) || d); return index(ok, v) >= 0 ? v : d; };
	let t = n('temp', [70, 75, 80], 75);
	return { temp: t, tempbad: t + 10, disk: n('disk', [80, 85, 90], 85), diskbad: 95, mem: n('mem', [85, 90, 95], 90), cpu: 90 };
}
/* livello di un valore: ok, warn (Da Controllare), bad (Problema); null = dato che manca, conta come ok */
function hlev(k, v, T) {
	if (v == null) return 'ok';
	if (k == 'temp') return v >= T.tempbad ? 'bad' : v >= T.temp ? 'warn' : 'ok';
	if (k == 'disk') return v >= T.diskbad ? 'bad' : v >= T.disk ? 'warn' : 'ok';
	if (k == 'mem') return v >= T.mem ? 'warn' : 'ok';
	return 'ok';
}
/* versione a più nuova di b (2.9 < 2.10) */
function vnewer(a, b) {
	let x = split('' + a, '.'), y = split('' + b, '.');
	for (let i = 0; i < 4; i++) { let u = +(x[i] ?? 0), v = +(y[i] ?? 0); if (u != v) return u > v; }
	return false;
}
function casaign() {
	let I = rjs(CASAIGN) ?? rjs(CASAIGNE);
	return (I?.day == dday(time()) && type(I.ids) == 'array') ? filter(I.ids, (x) => type(x) == 'string') : [];
}
function casaignset(ids) {
	let o = { day: dday(time()), ids: ids };
	wjs(CASAIGN, o);
	mkdir('/etc/wrtfreedom');
	writefile(CASAIGNE + '.t', sprintf('%J', o)); rename(CASAIGNE + '.t', CASAIGNE);
}
function bandl(b) { return b == '2g' ? '2.4 GHz' : b == '5g' ? '5 GHz' : b == '6g' ? '6 GHz' : b == '60g' ? '60 GHz' : b; }
/* Servizio VPN (2.52): un solo stato per app, Stato Della Casa, snapshot (notifica del telefono) e bot. null = non
   configurato; on = almeno un collegamento acceso; where/wherei = luogo del collegamento che conta (wherei in
   italiano); all = la casa intera passa dal principale; devs = dispositivi scelti nei collegamenti accesi (principale
   «solo alcuni» e collegamenti in più); pause = ora di ripresa della Pausa.
   Regola (la stessa dell'app, vxSvc in wf54): conta il collegamento di tutta la casa, o l'unico acceso; senza casa e con
   più collegamenti bad solo se non risponde nessuno. Gli altri che non rispondono non cambiano lo stato: badn = quanti,
   badl = elenco [{id, who, where}] da vedere (ok resta true). bad = quanti non rispondono in tutto (come prima).
   txt = collegamenti accesi in una riga nella lingua dell'app («Tutta La Casa · Roma + TV · Zurigo»; servizio tra
   parentesi solo con più servizi).
   2.64: list = tutti i collegamenti (accesi e spenti), nell'ordine di n: [{id, n, home, who (come kw), names (dispositivi),
   city, country, cc (nella lingua dell'app), prov, pv (servizio), placeid, auto (servizio automatico di VPNPROVS, non da
   file), on, state off|bad|wait|ok, v}] */
const VPNPROVS = ['nord', 'mullvad', 'pia', 'azire', 'ivpn'];
const VPNPN = { nord: 'NordVPN', mullvad: 'Mullvad', pia: 'Private Internet Access', ivpn: 'IVPN', azire: 'AzireVPN', proton: 'Proton VPN',
	surfshark: 'Surfshark', windscribe: 'Windscribe' };
function vpnstate(W) {
	W = W ?? ucfile('wrtfreedom');
	let T = vpntuns(W);
	if (!length(T)) return null;
	let MON = rjs('/tmp/wf-vpn.json') ?? {}, Ps = vpnprofs(W), on = filter(T, (x) => x.on), bad = 0, up = 0, all = false, devs = 0, Lk = [], pvs = [], Ka = [];
	/* ogni collegamento (2.64: anche gli spenti, per list); il conto dello stato solo con quelli accesi */
	for (let x in T) {
		let s = MON[x.id] ?? {}, p = Ps[x.prof] ?? {}, home = x.n == 0 && x.mode != 'dev', D = vpndevs(x.devs), nd = length(D);
		let c = length(p.city) ? p.city : '', ci = length(c) ? (VPNCITY[lc(trim(c))] ?? c) : (VPNCC[uc(p.cc ?? '')] ?? p.cc ?? p.name ?? ''), ce = length(c) ? c : (p.cc ?? p.name ?? '');
		let pv = VPNPN[p.prov] ?? p.prov ?? '';
		let k = { id: x.id, n: x.n, on: x.on, home: home, nd: nd, one: !home && nd == 1, name: nd ? (D[0].name || D[0].ip) : '', names: map(D, (d) => d.name || d.ip), wi: ci, we: ce, cc: p.cc ?? '', pv: pv,
			city: c, prov: p.prov ?? '', placeid: p.place ?? '', auto: !p.lib && index(VPNPROVS, p.prov) >= 0,
			down: !!s.down, up: !s.down && +(s.since ?? 0) > 0, place: p.city || p.name || p.host || '', placei: length(p.city) ? vpnplace(p.city, p.cc) : (p.city || p.name || p.host || '') };
		push(Ka, k);
		if (!x.on) continue;
		if (home) all = true; else devs += nd;
		if (k.down) bad++; else if (k.up) up++;
		if (index(pvs, pv) < 0) push(pvs, pv);
		push(Lk, k);
	}
	let pu = +(ug(W, 'vpnout', 'pause_until') || '0'), n = length(on), home = filter(Lk, (k) => k.home)[0], main = home ?? (n == 1 ? Lk[0] : null);
	let who = all ? L('Tutta La Casa', 'Whole Home') : devs == 1 ? L('1 Dispositivo', '1 Device') : devs + L(' Dispositivi', ' Devices');
	/* state, nello stesso ordine di v e degli avvisi della Dashboard: pause, off, bad, wait (si sta collegando), ok */
	let st = pu > time() ? 'pause' : !n ? 'off' : main ? (main.down ? 'bad' : main.up ? 'ok' : 'wait') : bad == n ? 'bad' : up && up + bad == n ? 'ok' : 'wait';
	let f = main ?? Lk[0], badl = [];
	let kw = (k) => k.home ? L('Tutta La Casa', 'Whole Home') : k.one ? k.name : k.nd + (k.nd == 1 ? L(' Dispositivo', ' Device') : L(' Dispositivi', ' Devices'));
	let kp = (k, pv) => kw(k) + (length(L(k.wi, k.we)) ? ' · ' + L(k.wi, k.we) : '') + (pv && length(pvs) > 1 ? ' (' + k.pv + ')' : '');
	if (st == 'ok') for (let k in Lk) if (k.down) push(badl, { id: k.id, who: kw(k), where: L(k.wi, k.we) });
	let O = filter(Lk, (k) => k != f), txt = '', C = [], nds = 0;
	for (let k in Lk) { let c = length(k.cc) ? k.cc : k.we; if (index(C, c) < 0) push(C, c); }
	for (let k in (home ? O : Lk)) nds += k.nd;
	if (n == 1) txt = kp(f, false);
	else if (n == 2) txt = kp(f, true) + ' + ' + kp(O[0], true);
	else if (n > 2 && home) txt = kp(f, true) + ' + ' + nds + L(' Dispositivi', ' Devices');
	else if (n > 2) txt = nds + L(' Dispositivi', ' Devices') + ' · ' + (length(C) > 1 ? length(C) + L(' Paesi', ' Countries') : L(f.wi, f.we));
	/* 2.64: tutti i collegamenti, con lo stato di ognuno (stesso ordine di v: off, bad, wait, ok) */
	let VT = { off: L('Spento', 'Off'), bad: L('Non Risponde', 'Not Responding'), ok: L('Collegato', 'Connected'), wait: L('Si Sta Collegando', 'Connecting') };
	let list = map(Ka, (k) => { let s = !k.on ? 'off' : k.down ? 'bad' : k.up ? 'ok' : 'wait';
		return { id: k.id, n: k.n, home: k.home, who: kw(k), names: k.names, city: length(k.city) ? L(VPNCITY[lc(trim(k.city))] ?? k.city, k.city) : '',
			country: L(VPNCC[uc(k.cc)] ?? k.cc, uc(k.cc)), cc: k.cc, prov: k.prov, pv: k.pv, placeid: k.placeid, auto: k.auto, on: k.on, state: s, v: VT[s] }; });
	return { on: n > 0, ok: n ? st == 'ok' : null, n: n, tot: length(T), up: up, bad: bad, badn: length(badl), badl: badl, txt: txt, list: list,
		where: f ? f.place : '', wherei: f ? f.placei : '', cc: f ? f.cc : '', all: all, devs: devs,
		who: n ? who : '', pause: pu > time() ? pu : null, state: st,
		v: { pause: L('In Pausa', 'Paused'), off: L('Spento', 'Off'), bad: L('Non Risponde', 'Not Responding'), ok: L('Collegato', 'Connected'), wait: L('Si Sta Collegando', 'Connecting') }[st] };
}
/* ---------- Altro · Manutenzione (2.55) ----------
   Un Solo Stato Dei Servizi: l'unico calcolo dei servizi principali e di quelli fermi (metodo svc, snapshot, casa,
   health, bot). Principali = script di /etc/init.d con un programma che resta acceso (procd_open_instance), più i
   servizi vitali; esclusi gli script di una volta (boot, done, sysfixtime…). Acceso = un'istanza di procd in corso (i
   vitali senza istanza, come il firewall, = registrati in procd); all'avvio = collegamento S??nome in /etc/rc.d.
   Vitali = accesso da terminale, pagine web, collegamento con l'app, rete, firewall, DNS (anche AdGuard Home) e linea
   mobile (ModemManager): fermarli, riavviarli o disattivarli passa dalla conferma con ritorno (bakarm, tag «svc») */
const SVCVIT = { dropbear: true, sshd: true, uhttpd: true, nginx: true, rpcd: true, network: true, firewall: true, wpad: true, dnsmasq: true, odhcpd: true,
	adguardhome: true, AdGuardHome: true, modemmanager: true };
const SVCD = '/tmp/wf-svcd.json', SVCONCE = { urandom_seed: true, acme: true };
/* tipo di ogni script (d = programma che resta acceso, v = vitale senza istanza, '' = di una volta): si rilegge solo
   quando cambia la cartella /etc/init.d (pacchetti aggiunti o tolti) */
function svckinds() {
	let s = stat('/etc/init.d'), m = s ? s.mtime : 0, C = rjs(SVCD);
	if (C && C.m == m && type(C.k) == 'object') return C.k;
	let K = {};
	for (let f in lsdir('/etc/init.d') ?? []) {
		if (!match(f, /^[A-Za-z0-9_.-]{1,64}$/)) continue;
		let t = readfile('/etc/init.d/' + f) ?? '';
		/* script con procd che girano una volta e finiscono (non sono mai «fermi») */
		K[f] = SVCONCE[f] ? '' : index(t, 'procd_open_instance') >= 0 ? 'd' : SVCVIT[f] ? 'v' : '';
	}
	wjs(SVCD, { m: m, k: K });
	return K;
}
/* configurazione /etc/config/<nome> che spegne il servizio (2.58): sezioni del servizio stesso (tipo o nome uguale al
   servizio, così le regole del firewall o simili non contano), almeno una con enabled/enable/disabled e tutte spente
   (enabled '0', enable '0', disabled '1'); niente nomi di servizi fissi */
function svccfgoff(nm) {
	let n = 0, off = 0, no = { '0': true, 'false': true, 'no': true, 'off': true };
	for (let sn, s in ucfile(nm)) {
		if (s['.type'] != nm && sn != nm) continue;
		let e = s.enabled ?? s.enable, d = s.disabled;
		if (type(e) == 'string') { n++; if (no[lc(e)]) off++; }
		else if (type(d) == 'string') { n++; if (!no[lc(d)]) off++; }
	}
	return n > 0 && off == n;
}
/* {t, list [{id, on, boot, vital, idle}] (principali, in ordine di nome), stopped [id fermi ma attivati all'avvio], n}.
   idle (2.58) = spento perché non ha niente da fare: registrato in procd senza istanze, oppure la sua configurazione lo
   spegne (svccfgoff); con istanze definite e nessuna accesa non è idle (si è fermato). Non cambia il conto dei fermi */
function svcstate() {
	let K = svckinds(), sv = ubcall('service', 'list') ?? {}, B = {}, R = [], st = [];
	for (let f in lsdir('/etc/rc.d') ?? []) { let m = match(f, /^S[0-9]{1,3}([A-Za-z0-9_.-]{1,64})$/); if (m) B[m[1]] = true; }
	for (let nm in sort(keys(K))) {
		if (!K[nm]) continue;
		let S = sv[nm], on = false, ni = length(keys(S?.instances ?? {}));
		if (K[nm] == 'd') { for (let ik in S?.instances ?? {}) if (S.instances[ik].running) on = true; }
		else on = S != null;
		let idle = !on && ni == 0 && (S != null || svccfgoff(nm));
		push(R, { id: nm, on: on, boot: !!B[nm], vital: !!SVCVIT[nm], idle: idle });
		/* fermo = attivato all'avvio e non registrato in procd, oppure con istanze e nessuna accesa (registrato senza
		   istanze = non configurato, per esempio senza interfacce: non è fermo) */
		if (B[nm] && (S == null || (ni > 0 && !on))) push(st, nm);
	}
	return { t: time(), list: R, stopped: st, n: length(st) };
}
/* stato della linea di line.sh (/tmp/wf-line.json): fresco = scritto da meno di 30 s; ok = internet c'è (anche sulla
   riserva); bk = sulla Linea Di Riserva. Unica regola per Stato Della Casa e Assistente IA (Senza Internet) */
function lnstate(now) {
	let LN = rjs('/tmp/wf-line.json'), fresh = LN != null && now - +(LN.t ?? 0) < 30, bk = fresh && LN.active == 'backup';
	return { fresh: fresh, bk: bk, ok: fresh ? (bk || LN.ok == true) : null, since: fresh ? +(LN.since ?? 0) : null };
}
/* B (facoltativo, da snapshot: niente letture doppie) = { wup, tech, ws (network.wireless status), pres (presence()) }.
   items: id stabile (si può ignorare), sev ok|info|warn|bad, text nella lingua dell'app, act = pagina dell'app.
   ok = nessun avviso warn/bad (Tutto Bene), n = quanti (Da Vedere) */
function casacalc(B) {
	B = B ?? {};
	let now = time(), d = dday(now), W = ucfile('wrtfreedom'), I = [];
	let add = (id, sev, it, en, act) => push(I, { id: id, sev: sev, text: L(it, en), act: act });
	let gbs = (b) => sprintf('%.1f GB', b / 1e9), dash = '—';
	/* linea: stato di line.sh (fresco = meno di 30 s; act backup = sulla riserva), altrimenti la rotta predefinita */
	let LS = lnstate(now), fresh = LS.fresh, wup = B.wup;
	if (wup == null) { let w = wanpick((ubcall('network.interface', 'dump') ?? {}).interface ?? []); wup = w ? !!w.up : null; }
	let bk = LS.bk, lok = fresh ? LS.ok : wup;
	let line = { ok: lok, backup: bk, tech: B.tech ?? '', since: LS.since,
		v: lok == null ? dash : !lok ? L('Assente', 'Down') : bk ? L('Su Riserva', 'On Backup') : L('Collegata', 'Connected') };
	if (lok == false) add('line', 'bad', 'Internet Assente', 'Internet Down', 'line');
	else if (bk) add('line', 'warn', 'Su Linea Di Riserva', 'On Backup Line', 'line');
	else if (lok) add('line', 'ok', 'Internet Collegato' + (length(line.tech) ? ' · ' + line.tech : ''), 'Internet Connected' + (length(line.tech) ? ' · ' + line.tech : ''), 'line');
	/* consumo: periodo dell'offerta e oggi (usage.uc: dd = giorno, db = byte di oggi) */
	let U = rjs('/tmp/wf-usage.json'), quota = +(ug(W, 'usage', 'quota') || '0') * 1e9, warn = +(ug(W, 'usage', 'warn') || '80');
	let tb = U?.dd == d ? +(U.db ?? 0) : (U?.dd ? 0 : null);
	if (U && quota > 0) {
		let used = +(U.rx ?? 0) + +(U.tx ?? 0), pc = int(used * 100 / quota), x = gbs(used) + ' / ' + gbs(quota) + ' (' + pc + '%)';
		if (U.slow) add('usage', 'warn', 'Velocità Limitata: Giga Finiti', 'Speed Limited: Data Used Up', 'usage');
		else add('usage', pc >= 100 ? 'bad' : pc >= warn ? 'warn' : 'ok', 'Giga Usati ' + x, 'Data Used ' + x, 'usage');
	}
	let today = { b: tb, v: tb == null ? dash : gbs(tb) };
	/* firewall: tentativi bloccati oggi (fwstat.uc) */
	let F = rjs('/tmp/wf-fwstat.json');
	if (F?.day == d) add('fw', 'ok', 'Firewall: ' + (+F.today || 0) + ' Tentativi Bloccati Oggi', 'Firewall: ' + (+F.today || 0) + ' Attempts Blocked Today', 'fw');
	/* Wi-Fi: radio da netifd (spente dall'utente = non contano), canale affollato dall'ultima lettura di wifi.uc */
	let WS = B.ws ?? ubcall('network.wireless', 'status') ?? {}, wifi = null;
	if (length(keys(WS))) {
		let n = 0, on = 0, off = [], gon = false, gs = 0, WL = ucfile('wireless');
		for (let rn in WS) {
			let r = WS[rn];
			if (r.disabled) continue;
			n++;
			if (r.up) on++; else push(off, bandl(rband(r.config, null)));
		}
		for (let k in guestifs(WL)) { gs++; if (ug(WL, k, 'disabled') != '1') gon = true; }
		wifi = { on: on > 0, radios: n, up: on, guest: gs > 0 ? gon : null, v: on > 0 ? L('Acceso', 'On') : L('Spento', 'Off') };
		if (!n) add('wifi', 'info', 'Wi-Fi Spento', 'Wi-Fi Off', 'wifi');
		else if (length(off)) add('wifi', 'warn', 'Wi-Fi ' + join(', ', off) + ' Fermo', 'Wi-Fi ' + join(', ', off) + ' Stopped', 'wifi');
		else add('wifi', 'ok', 'Wi-Fi Acceso', 'Wi-Fi On', 'wifi');
		let S = rjs(WFP + '.json');
		if (on && S && now - +(S.t ?? 0) < 900)
			for (let rn in S.radios ?? {}) {
				let x = S.radios[rn];
				if (x?.up && +(x.busy ?? 0) >= 80) { add('wifi_busy', 'info', 'Canale Affollato Sul ' + bandl(x.band), 'Busy Channel On ' + bandl(x.band), 'wifi'); break; }
			}
	}
	/* Servizio VPN: lo stato unico di vpnstate (B.vs da snapshot) */
	let VS = B.vs ?? vpnstate(W), vpn = null;
	if (VS) {
		vpn = { on: VS.on, ok: VS.ok, n: VS.n, where: VS.where, all: VS.all, devs: VS.devs, pause: VS.pause, state: VS.state, v: VS.v, badn: VS.badn, txt: VS.txt };
		/* testo già nella lingua dell'app (txt): uguale nelle due lingue */
		let wi = length(VS.txt) ? ' · ' + VS.txt : '', we = wi, b0 = (VS.badl ?? [])[0];
		if (VS.state == 'pause') add('vpn', 'info', 'Servizio VPN In Pausa', 'VPN Service Paused', 'vpn');
		else if (VS.state == 'off') add('vpn', 'info', 'Servizio VPN Spento', 'VPN Service Off', 'vpn');
		else if (VS.state == 'bad') add('vpn', 'bad', 'Servizio VPN Non Risponde', 'VPN Service Not Responding', 'vpn');
		else if (VS.state == 'wait') add('vpn', 'info', 'Servizio VPN Si Sta Collegando', 'VPN Service Connecting', 'vpn');
		else add('vpn', 'ok', 'Servizio VPN Collegato' + wi, 'VPN Service Connected' + we, 'vpn');
		/* un collegamento di alcuni dispositivi che non risponde: da vedere, la casa resta collegata */
		if (VS.state == 'ok' && VS.badn == 1) {
			let x = b0.who + (length(b0.where) ? ' · ' + b0.where : '');
			add('vpn_bad', 'warn', 'Servizio VPN · ' + x + ' Non Risponde', 'VPN Service · ' + x + ' Not Responding', 'vpn');
		}
		else if (VS.state == 'ok' && VS.badn > 1)
			add('vpn_bad', 'warn', 'Servizio VPN · ' + VS.badn + ' Collegamenti Non Rispondono', 'VPN Service · ' + VS.badn + ' Connections Not Responding', 'vpn');
	}
	/* sistema: temperatura e spazio («—» senza sensore o lettura, mai 0), servizi fermi (snapshot, ultimi 10 minuti) */
	let tc = thermc(), dp = diskpct(), HT = hth(W);
	if (tc == null) add('temp', 'ok', 'Temperatura ' + dash, 'Temperature ' + dash, 'sys');
	else add('temp', hlev('temp', tc, HT), 'Temperatura ' + tc + ' °C', 'Temperature ' + tc + ' °C', 'sys');
	if (dp == null) add('disk', 'ok', 'Spazio Libero ' + dash, 'Free Space ' + dash, 'sys');
	else add('disk', hlev('disk', dp, HT), 'Spazio Libero ' + (100 - dp) + '%', 'Free Space ' + (100 - dp) + '%', 'sys');
	/* solo quanti (i nomi stanno nella pagina Servizi Del Router): stesso calcolo di svc (svcstate) */
	let ns = svcstate().n;
	if (ns)
		add('svc', 'warn', ns == 1 ? '1 Servizio Del Router Fermo' : ns + ' Servizi Del Router Fermi',
			ns == 1 ? '1 Router Service Stopped' : ns + ' Router Services Stopped', 'svc');
	/* pacchetto da aggiornare: manifesto firmato già scaricato da upd.sh */
	let MF = rjs('/tmp/wf-upd.json'), cur = trim(readfile('/usr/share/wrtfreedom/VERSION') ?? '');
	if (MF?.pkg?.v && length(cur) && vnewer(MF.pkg.v, cur))
		add('upd', 'info', 'Pacchetto Router ' + MF.pkg.v + ' Disponibile', 'Router Package ' + MF.pkg.v + ' Available', 'upd');
	/* dispositivi: collegati (presenza di notify.sh), nuovi da confermare (seen con «?»), persone a casa */
	let PR = B.pres ?? presence(), K = seenmap(), online = 0, nw = 0, home = [], people = 0, hp = stat(PRESD) != null;
	for (let m in PR) if (PR[m].on) online++;
	for (let m in K) if (!K[m]) nw++;
	for (let k in W) if (W[k]['.type'] == 'person') {
		people++;
		if (length(filter(vpnarr(W[k].mac), (m) => okmac(m) && PR[m]?.on))) push(home, W[k].name ?? k);
	}
	let dev = { online: hp ? online : null, new: nw, home: length(home), people: people, v: hp ? '' + online : dash };
	if (nw) add('newdev', 'warn', nw == 1 ? '1 Dispositivo Nuovo Da Confermare' : nw + ' Dispositivi Nuovi Da Confermare',
		nw == 1 ? '1 New Device To Confirm' : nw + ' New Devices To Confirm', 'dev');
	if (people) {
		if (length(home)) add('home', 'ok', (length(home) == 1 ? '1 Persona A Casa: ' : length(home) + ' Persone A Casa: ') + join(', ', home),
			(length(home) == 1 ? '1 Person At Home: ' : length(home) + ' People At Home: ') + join(', ', home), 'people');
		else add('home', 'info', 'Nessuno A Casa', 'Nobody At Home', 'people');
	}
	/* avvisi ignorati oggi fuori; prima i più gravi */
	let ign = casaign(), R = { bad: 0, warn: 1, info: 2, ok: 3 }, nn = 0;
	I = filter(I, (x) => index(ign, x.id) < 0);
	for (let x in I) if (x.sev == 'bad' || x.sev == 'warn') nn++;
	I = sort(I, (a, b) => R[a.sev] - R[b.sev]);
	return { t: now, ok: nn == 0, n: nn, items: I, line: line, wifi: wifi, vpn: vpn, dev: dev, today: today,
		sys: { temp: tc, disk: dp }, ign: ign };
}

/* ---------------- Rete e AdGuard (2.50) ----------------
   Il lavoro lento (cambi di schema del DNS, test, API di AdGuard, Telegram) lo fanno adgmode.sh e netx.uc in sottofondo,
   con il risultato in /tmp; qui solo letture di file e della configurazione. */
const NETX = '/usr/share/wrtfreedom/netx.uc', ADGM = '/usr/share/wrtfreedom/adgmode.sh', ADGFB = '/etc/wrtfreedom/dnsfb.state';
function adgyaml() {
	let A = ucfile('adguardhome');
	for (let f in [ ug(A, 'config', 'config_file'), ug(A, 'config', 'config'), '/etc/adguardhome/adguardhome.yaml', '/etc/adguardhome.yaml', '/opt/AdGuardHome/AdGuardHome.yaml' ])
		if (length(f) && has(f)) return f;
	return null;
}
/* chiavi del blocco «dns:» del file di AdGuard (valori semplici e liste) */
function adgdns(y) {
	let r = {}, d = false, k = null;
	for (let l in split(readfile(y ?? '') ?? '', '\n')) {
		if (match(l, /^[^ #]/)) { d = substr(l, 0, 4) == 'dns:'; k = null; continue; }
		if (!d) continue;
		let m = match(l, /^  ([a-z_]+):[ \t]*(.*)$/);
		if (m) { k = m[1]; let v = trim(m[2]); r[k] = (v == '' || v == '[]') ? [] : replace(v, /^['"]|['"]$/g, ''); continue; }
		m = match(l, /^(    |  )- (.*)$/);
		if (m && k && type(r[k]) == 'array') push(r[k], replace(trim(m[2]), /^['"]|['"]$/g, ''));
	}
	return r;
}
/* DNS di riserva in corso: stato scritto da adgmode.sh (righe NOME='valore') */
function adgfb() {
	let o = readfile(ADGFB);
	if (o == null) return null;
	let r = {};
	for (let l in split(o, '\n')) { let m = match(l, /^([A-Z]+)='(.*)'$/); if (m) r[m[1]] = m[2]; }
	return r;
}
function adginst() { return has('/etc/init.d/adguardhome') || has('/etc/init.d/AdGuardHome'); }
/* chi risponde al DNS: std = dnsmasq sulla 53 inoltra ad AdGuard; direct = AdGuard sulla 53 e dnsmasq su un'altra porta */
function adgmodeinfo() {
	let y = adgyaml(), D = ucfile('dhcp'), ds = null, fb = adgfb();
	for (let k in D) if (D[k]['.type'] == 'dnsmasq') { ds = k; break; }
	if (!y || !ds || !adginst()) return { mode: 'none', fb: fb };
	let Y = adgdns(y), ap = '' + (Y.port ?? ''), dp = ug(D, ds, 'port') || '53', mode = 'other';
	if (ap == '53' && dp != '53') mode = 'direct';
	else if (dp == '53' && length(filter(vpnarr(D[ds].server), (s) => match(s, /^(127\.0\.0\.1|::1|localhost)#/) && split(s, '#')[1] == ap))) mode = 'std';
	if (fb && match(fb.MODE ?? '', /^(std|direct)$/)) mode = fb.MODE;
	return { mode: mode, aport: +ap || null, dport: +dp, bind: type(Y.bind_hosts) == 'array' ? Y.bind_hosts : [], ddr: Y.handle_ddr == 'true', fb: fb };
}
function adgrunning() {
	let sv = ubcall('service', 'list', { name: 'adguardhome' }) ?? {};
	for (let k in ((sv.adguardhome ?? {}).instances ?? {})) if (sv.adguardhome.instances[k].running) return true;
	return false;
}
/* Livelli di protezione: liste del catalogo (HostlistsRegistry, lo stesso di adgcat) e filtri di AdGuard.
   Le liste valgono per tutta la casa; per una persona contano i filtri del suo client (sicura, parental, ricerca sicura) */
const ADGLU = (n) => 'https://adguardteam.github.io/HostlistsRegistry/assets/filter_' + n + '.txt';
const ADGLV = {
	base: { sb: true, par: false, ss: false, lists: [ [ 1, 'AdGuard DNS filter' ] ] },
	famiglia: { sb: true, par: true, ss: true, lists: [ [ 1, 'AdGuard DNS filter' ], [ 30, 'Phishing URL Blocklist (PhishTank and OpenPhish)' ], [ 11, 'Malicious URL Blocklist (URLHaus)' ] ] },
	massima: { sb: true, par: true, ss: true, lists: [ [ 1, 'AdGuard DNS filter' ], [ 48, 'HaGeZi\'s Pro Blocklist' ], [ 30, 'Phishing URL Blocklist (PhishTank and OpenPhish)' ],
		[ 11, 'Malicious URL Blocklist (URLHaus)' ], [ 44, 'HaGeZi\'s Threat Intelligence Feeds' ] ] },
	personale: null
};
/* dispositivi visti su ogni porta: tabella di inoltro dei bridge (/sys/class/net/<bridge>/brforward, voci di 16 byte:
   MAC 6, porta 1, «del router» 1, età 4, porta alta 1, …; niente processi) e, per le porte fuori dai bridge, la tabella ARP */
function portpeers() {
	let P = {}, add = (d, m) => { P[d] = P[d] ?? []; if (index(P[d], m) < 0) push(P[d], m); };
	for (let br in lsdir('/sys/class/net') ?? []) {
		let b = '/sys/class/net/' + br, pn = {};
		if (!stat(b + '/bridge')) continue;
		for (let p in lsdir(b + '/brif') ?? []) pn['' + hex(trim(readfile(b + '/brif/' + p + '/port_no') ?? '0'))] = p;
		let f = readfile(b + '/brforward') ?? '';
		for (let i = 0; i + 16 <= length(f); i += 16) {
			if (ord(f, i + 7)) continue;
			let d = pn['' + (ord(f, i + 6) + ord(f, i + 12) * 256)];
			if (d) add(d, sprintf('%02x:%02x:%02x:%02x:%02x:%02x', ord(f, i), ord(f, i + 1), ord(f, i + 2), ord(f, i + 3), ord(f, i + 4), ord(f, i + 5)));
		}
	}
	for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) {
		let p = split(trim(l), /[ \t]+/);
		if (length(p) >= 6 && p[2] != '0x0' && okmac(p[3]) && p[3] != '00:00:00:00:00:00') add(p[5], p[3]);
	}
	return P;
}
/* porte fisiche: dispositivi di /sys/class/net che non sono virtuali, Wi-Fi o modem, con i nomi di /etc/board.json */
function portsbase() {
	let r = { list: [] }, B = json(readfile('/etc/board.json') ?? '{}') ?? {}, N = B.network ?? {}, lab = {};
	let wd = N.wan ? (N.wan.device ?? (N.wan.ports ?? [])[0]) : null, i = 0;
	if (wd) lab[wd] = 'WAN';
	let lp = N.lan ? (N.lan.ports ?? (N.lan.device ? [ N.lan.device ] : [])) : [];
	for (let d in lp) lab[d] = length(lp) > 1 ? 'LAN ' + (++i) : 'LAN';
	for (let d in sort(lsdir('/sys/class/net') ?? [])) {
		let b = '/sys/class/net/' + d;
		if (trim(readfile(b + '/type') ?? '') != '1' || stat(b + '/phy80211') || stat(b + '/wireless') || stat(b + '/dsa')) continue;
		if (match(readlink(b) ?? '', /\/virtual\//) || match(readfile(b + '/uevent') ?? '', /DEVTYPE=(wwan|bridge|wlan|vlan)/)) continue;
		if (!lab[d] && length(keys(lab))) continue;
		let x = { dev: d, name: lab[d] ?? uc(d), carrier: trim(readfile(b + '/carrier') ?? '0'), speed: trim(readfile(b + '/speed') ?? '') };
		push(r.list, x); r[d] = x;
	}
	let o = (x) => x.name == 'WAN' ? 0 : 1;
	r.list = sort(r.list, (a, b) => o(a) - o(b) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
	return r;
}

/* ---------------- VPN Per Fuori Casa (2.52) ----------------
   Zone e reti lette dal firewall (fwzones, homenet), interfaccia scelta sempre da wgiface, reti di qualunque grandezza.
   Il lavoro lento (DDNS e IP pubblico della Prova, statistiche, avvisi, scadenze) lo fa wgx.uc in sottofondo con i
   risultati in /tmp; qui letture di file, uci e «wg» (netlink, risposta immediata). */
const WGX = '/usr/share/wrtfreedom/wgx.uc', WGPRB = '/tmp/wf-wgprobe.json', WGPRBC = '/tmp/wf-wgprobe.chk.json';
const VSITEF = '/usr/share/nftables.d/table-post/41-wrtfreedom-vpnsite.nft', VSITESET = '4#inet#fw4#wf_vpnx';
function ip2n(s) {
	let o = map(split('' + s, '.'), (x) => +x);
	return length(o) == 4 ? ((o[0] * 256 + o[1]) * 256 + o[2]) * 256 + o[3] : null;
}
function n2ip(n) { return sprintf('%d.%d.%d.%d', (n >> 24) & 255, (n >> 16) & 255, (n >> 8) & 255, n & 255); }
/* rete «a.b.c.d/n» di un indirizzo «a.b.c.d/n» */
function cidr(s) {
	let p = split('' + s, '/');
	return match(p[0], /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) ? vpnnet({ proto: 'static', ipaddr: p[0] + '/' + (p[1] ?? '32') }) : null;
}
/* indirizzo dentro una rete «a.b.c.d/n» */
function innet(ip, net) {
	let p = split('' + net, '/'), a = ip2n(ip), b = ip2n(p[0]), bits = +(p[1] ?? 32);
	if (a == null || b == null || bits < 0 || bits > 32) return false;
	let m = bits ? (0xffffffff << (32 - bits)) & 0xffffffff : 0;
	return (a & m) == (b & m);
}
/* rete di casa vera: prima rete statica della zona di casa (indirizzo del router, rete a.b.c.d/n, interfaccia) */
function homenet() {
	let N = ucfile('network'), F = ucfile('firewall'), zh = fwzones().home;
	for (let k in F) if (F[k]['.type'] == 'zone' && F[k].name == zh)
		for (let n in split(join(' ', vpnarr(F[k].network)), ' ')) {
			let x = vpnnet(N[n]);
			if (x) return { ip: split(vpnarr(N[n].ipaddr)[0], '/')[0], net: x, iface: n };
		}
	return { ip: split(ug(N, 'lan', 'ipaddr'), '/')[0] ?? '', net: vpnnet(N.lan), iface: 'lan' };
}
/* dispositivi della VPN Per Fuori Casa con le impostazioni dell'app (wrtfreedom.peer_<id>) */
function wgpeers(N, W, ifc) {
	N = N ?? ucfile('network'); W = W ?? ucfile('wrtfreedom'); ifc = ifc ?? wgiface(N);
	let r = [];
	if (!ifc) return r;
	for (let k in N) if (N[k]['.type'] == 'wireguard_' + ifc) {
		let s = N[k], m = W['peer_' + k] ?? {};
		push(r, { id: k, name: s.description ?? '', pub: s.public_key ?? '', ip: split(vpnarr(s.allowed_ips)[0] ?? '', '/')[0], full: m.full == '1', host: m.host ?? '',
			own: length(m.priv ?? '') > 0, psk: length(s.preshared_key ?? '') > 0, exp: +(m.exp ?? 0) || null, alert: m.alert == '1', alt: m.alt == '1',
			paused: s.disabled == '1', sched: length(m.sdays ?? '') ? { days: m.sdays, from: m.sfrom ?? '', to: m.sto ?? '' } : null });
	}
	return r;
}
/* regole del firewall che aprono la VPN Per Fuori Casa: quella del pacchetto (wf_wg «WrtFreedom-WireGuard»), «Allow-WireGuard»
   fatta a mano e ogni regola ACCEPT udp dalla zona internet verso la porta in ascolto (una regola con due nomi = una sola) */
function wgrules(F, port, wz) {
	let r = [];
	for (let k in F) {
		let s = F[k];
		if (s['.type'] != 'rule' || k == 'wf_wgalt_in') continue;
		let nm = s.name ?? '', pr = join(' ', vpnarr(s.proto));
		let byname = k == 'wf_wg' || nm == 'WrtFreedom-WireGuard' || nm == 'Allow-WireGuard';
		let byport = length('' + port) > 0 && join(' ', vpnarr(s.dest_port)) == '' + port && s.src == wz && s.target == 'ACCEPT' && !s.dest && (!length(pr) || match(pr, /udp|all/) != null);
		if (byname || byport) push(r, k);
	}
	return r;
}
/* Porta Alternativa: porta della zona internet inoltrata a quella della VPN (redirect wf_wgalt), null = spenta */
function wgaltport(F) {
	let s = (F ?? ucfile('firewall')).wf_wgalt;
	return s && s.enabled != '0' ? +(s.src_dport ?? 0) || null : null;
}
/* copia per il ritorno automatico della VPN Per Fuori Casa (2.52): solo l'interfaccia del server e le regole che la
   aprono (wgrules, Porta Alternativa); i dispositivi (sezioni wireguard_<if>) non si toccano: aggiunti, cambiati,
   messi in pausa o tolti durante l'attesa restano così */
function wgbak(N, ifc) {
	let R = wgrules(ucfile('firewall'), ug(N, ifc, 'listen_port'), fwzones().wan);
	return bakarm('wg', { network: { n: ifc }, firewall: { n: join('|', ['wf_wg', 'wf_wgalt', 'wf_wgalt_in', ...filter(R, (k) => substr(k, 0, 1) != '@')]), a: filter(R, (k) => substr(k, 0, 1) == '@') } }, [],
		'/etc/init.d/network reload; /etc/init.d/firewall reload', 120,
		L('↩️ VPN Per Fuori Casa: nessuna conferma entro 120 s, rimessa com\'era', '↩️ Away From Home VPN: no confirmation within 120 s, restored'));
}
/* nomi DDNS dei dispositivi con il Tunnel Parziale: il telefono chiede il nome al DNS di casa e deve ricevere l'indirizzo
   del router (regola dnsmasq address=/<nome>/<IP del router>). mine = regole messe dal pacchetto (wrtfreedom.wg.ddr) */
function wgddr(N, W) {
	W = W ?? ucfile('wrtfreedom');
	let P = filter(wgpeers(N, W, null), (p) => !p.full), need = [], have = [], D = ucfile('dhcp'), ip = homenet().ip;
	if (length(P)) {
		let gh = ug(W, 'wg', 'host');
		if (!length(gh)) gh = wgautohost().host;
		for (let p in P) {
			let h = length(p.host) ? p.host : gh;
			if (length(h) && !match(h, /^[0-9.]+$/) && index(h, ':') < 0 && index(need, h) < 0) push(need, h);
		}
	}
	for (let k in D) if (D[k]['.type'] == 'dnsmasq') for (let x in vpnarr(D[k].address)) push(have, x);
	return { part: length(P), ip: ip, need: need, missing: filter(need, (h) => index(have, '/' + h + '/' + ip) < 0), mine: vpnarr((W.wg ?? {}).ddr) };
}
/* AdGuard che risponde direttamente ai dispositivi (schema direct di adgmode.sh): i nomi che dnsmasq risolve o mette in
   un insieme (address=, nftset=) AdGuard deve chiederli a dnsmasq ([/<nome>/]127.0.0.1:<porta>); rebind rifà le voci del
   pacchetto in AdGuard. Da aggiungere ai comandi in sottofondo dopo ogni cambio di questi nomi */
const ADGRB = '; [ -f /etc/wrtfreedom/adgmode/orig ] && sh ' + ADGM + ' rebind';
/* regole che mancano aggiunte (e segnate per la disinstallazione), quelle del pacchetto non più servite tolte; dnsmasq
   ricaricato in sottofondo solo se cambia qualcosa (con AdGuard diretto anche le sue voci verso dnsmasq) */
function wgddrfix() {
	let R = wgddr(null, null), c = '';
	if (!length(R.ip)) return R;
	for (let h in R.missing) c += 'uci add_list ' + q('dhcp.@dnsmasq[0].address=/' + h + '/' + R.ip) + '; uci add_list ' + q('wrtfreedom.wg.ddr=/' + h + '/' + R.ip) + '; ';
	for (let x in R.mine) {
		let h = split(x, '/')[1] ?? '';
		if (index(R.need, h) < 0 || x != '/' + h + '/' + R.ip) c += 'uci -q del_list ' + q('dhcp.@dnsmasq[0].address=' + x) + '; uci -q del_list ' + q('wrtfreedom.wg.ddr=' + x) + '; ';
	}
	if (!length(c)) return R;
	cfgensure();
	sh('uci -q get wrtfreedom.wg >/dev/null || uci set wrtfreedom.wg=wg; ' + c + 'uci commit dhcp; uci commit wrtfreedom; ( /etc/init.d/dnsmasq reload' + ADGRB + ' ) >/dev/null 2>&1 </dev/null &');
	R.missing = []; R.fixed = true;
	return R;
}
/* controllo delle scadenze (cron.sh wgexp ogni 5 minuti) solo se almeno un dispositivo ne ha una */
function wgexpcron(P) {
	cronline('wgexp', length(filter(P, (p) => p.exp)) ? '*/5 * * * * sh /usr/share/wrtfreedom/cron.sh wgexp' : null);
}
/* minuti del giorno di «HH:MM» */
function hmin(s) { let p = split('' + s, ':'); return +p[0] * 60 + +p[1]; }
/* orari di un dispositivo: nei giorni scelti (1 = lunedì … 7 = domenica) attivo da «from», in pausa da «to» */
function wgschedcron(id, days, fromhm, to) {
	let tg = 'wgp_' + lc(replace(id, /[^A-Za-z0-9]/g, ''));
	if (!length(days)) { cronline(tg + '_on', null); cronline(tg + '_off', null); return; }
	let dw = [];
	for (let i = 0; i < length(days); i++) { let d = substr(days, i, 1); push(dw, d == '7' ? '0' : d); }
	let f = split(fromhm, ':'), t = split(to, ':');
	/* a cavallo della mezzanotte (to prima di from) la pausa è il giorno dopo */
	let dn = hmin(to) < hmin(fromhm) ? map(dw, (d) => '' + ((+d + 1) % 7)) : dw;
	cronline(tg + '_on', +f[1] + ' ' + +f[0] + ' * * ' + join(',', dw) + ' sh /usr/share/wrtfreedom/cron.sh wgpeeron ' + id);
	cronline(tg + '_off', +t[1] + ' ' + +t[0] + ' * * ' + join(',', dn) + ' sh /usr/share/wrtfreedom/cron.sh wgpeeroff ' + id);
}
/* dispositivo sospeso: fuori da wg subito e «disabled» in network (netifd non lo rimette quando la VPN riparte); chiavi e
   impostazioni restano (peer_<id>.paused = messo dal pacchetto, tolto con la disinstallazione). Ripreso = di nuovo in wg */
function wgpeerpause(ifc, id, pause) {
	let N = ucfile('network'), s = N[id];
	if (!s || s['.type'] != 'wireguard_' + ifc) return { error: 'dispositivo non trovato' };
	let pub = s.public_key ?? '';
	if (!match(pub, VPNKEY)) return { error: 'dispositivo senza chiave pubblica' };
	cfgensure();
	let meta = 'uci -q get wrtfreedom.peer_' + id + ' >/dev/null || uci set wrtfreedom.peer_' + id + '=peer; ';
	if (pause) {
		sh('wg set ' + ifc + ' peer ' + q(pub) + ' remove 2>/dev/null; ' + uset('network', id, 'disabled', '1') + meta + uset('wrtfreedom', 'peer_' + id, 'paused', '1') + 'uci commit network; uci commit wrtfreedom');
		return { ok: true, paused: true };
	}
	let psk = s.preshared_key ?? '', ips = join(',', vpnarr(s.allowed_ips)), ka = '' + (s.persistent_keepalive ?? '');
	let kf = length(psk) ? kfile(psk + '\n') : '';
	sh('wg set ' + ifc + ' peer ' + q(pub) + (length(kf) ? ' preshared-key ' + kf : '') + (length(ips) ? ' allowed-ips ' + q(ips) : '') +
		(match(ka, /^[0-9]{1,5}$/) ? ' persistent-keepalive ' + ka : '') + ' 2>/dev/null; ' + (length(kf) ? 'rm -f ' + kf + '; ' : '') + udel('network', id, 'disabled') + meta + udel('wrtfreedom', 'peer_' + id, 'paused') +
		'uci commit network; uci commit wrtfreedom');
	return { ok: true, paused: false };
}
/* Eccezioni Per Sito del Servizio VPN: siti in wrtfreedom.vpnsite.site, insieme wf_vpnx riempito da dnsmasq (nftset),
   connessioni nuove verso l'insieme segnate 0xe10000 nel conntrack (ct mark: flussi lunghi e ricariche del firewall, che
   svuotano l'insieme, restano sulla linea normale) e mark dei pacchetti dal ct mark; regola wf_vpnsite (priorità 890,
   prima delle regole del Servizio VPN) verso la tabella principale, cioè la linea normale. Niente siti = file, regola e
   voci di dnsmasq tolti. Sempre con la copia (bakarm 'vpnsites'): in sottofondo prima dnsmasq --test (nftset) e fw4 check,
   poi la ricarica; se una prova fallisce si torna subito com'era. safe (dall'app) = la copia resta in attesa di confirm
   per 120 s; senza safe si toglie dopo la ricarica riuscita (se non c'era già una copia in attesa) */
/* copia: regola wf_vpnsite, elenco dei siti e solo la lista nftset del primo dnsmasq (il resto non si tocca) */
function vsitebak() {
	let D = ucfile('dhcp'), dk = filter(keys(D), (k) => D[k]['.type'] == 'dnsmasq')[0];
	let P = { network: { n: 'wf_vpnsite' }, wrtfreedom: { n: 'vpnsite' } };
	if (dk) P.dhcp = substr(dk, 0, 1) == '@' ? { a: [dk], o: ['nftset'] } : { n: dk, o: ['nftset'] };
	return P;
}
function vsiteapply(S, old, safe) {
	let B = bakdir('vpnsites'), pend0 = bakpend('vpnsites');
	let e = bakarm('vpnsites', vsitebak(), [VSITEF], '/etc/init.d/network reload; /etc/init.d/firewall reload; /etc/init.d/dnsmasq restart' + ADGRB, 120,
		L('↩️ Eccezioni Per Sito: nessuna conferma entro 120 s, rimesse com\'era', '↩️ Per-Site Exceptions: no confirmation within 120 s, restored'));
	if (e !== true) return e;
	let c = '', t = '';
	for (let x in old) c += 'uci -q del_list ' + q('dhcp.@dnsmasq[0].nftset=/' + x + '/' + VSITESET) + '; ';
	c += 'uci -q delete wrtfreedom.vpnsite; ';
	if (length(S)) {
		c += 'uci set wrtfreedom.vpnsite=vpnsite; ';
		for (let x in S) { c += 'uci add_list ' + q('wrtfreedom.vpnsite.site=' + x) + '; uci add_list ' + q('dhcp.@dnsmasq[0].nftset=/' + x + '/' + VSITESET) + '; '; t += ' ' + q('--nftset=/' + x + '/' + VSITESET); }
		c += 'uci set network.wf_vpnsite=rule; uci set network.wf_vpnsite.mark=0xe10000/0xe10000; uci set network.wf_vpnsite.lookup=main; uci set network.wf_vpnsite.priority=890; ';
		mkdir('/usr/share/nftables.d'); mkdir('/usr/share/nftables.d/table-post');
		writefile(VSITEF, '# WrtFreedom: Eccezioni Per Sito del Servizio VPN (2.52)\n' +
			'set wf_vpnx { type ipv4_addr; flags timeout; timeout 12h; }\n' +
			'chain wf_vpnx_mark {\n\ttype filter hook prerouting priority mangle + 1; policy accept;\n' +
			'\tct state new ip daddr @wf_vpnx ct mark set ct mark or 0x00e10000\n' +
			'\tct mark & 0x00e10000 == 0x00e10000 meta mark set meta mark or 0x00e10000\n}\n');
	}
	else { c += 'uci -q delete network.wf_vpnsite; '; unlink(VSITEF); }
	cfgensure();
	let ok = (!safe && !pend0 ? 'rm -rf ' + B + '; ' : '') + '/etc/init.d/network reload; /etc/init.d/firewall reload; /etc/init.d/dnsmasq restart' + ADGRB;
	let bad = 'sh ' + B + '/back.sh ' + q(L('↩️ Eccezioni Per Sito: prova della configurazione non riuscita, rimesse com\'era', '↩️ Per-Site Exceptions: configuration test failed, restored'));
	sh(c + 'uci commit dhcp; uci commit network; uci commit wrtfreedom; ( if ' + (length(t) ? 'dnsmasq --test -C /dev/null' + t + ' && ' : '') +
		'fw4 -q check; then ' + ok + '; else ' + bad + '; fi ) >/dev/null 2>&1 </dev/null &');
	return { ok: true };
}

/* ---------------- Salute Del Router (2.54) ----------------
   Una sola regola di stato (healthcalc, con le soglie di hth/hlev): la usano il metodo health, health.uc (storico 24 ore e
   Avvisi Di Salute, che chiede «ubus call wrtfreedom health» dal sottofondo) e Stato Della Casa. Nei metodi solo letture di
   file del kernel e di /tmp: il lavoro lento (spazio, pulizia, motivo del riavvio) lo fa health.uc in sottofondo. */
const HCPU = '/tmp/wf-health.cpu', HHIST = '/tmp/wf-health.hist', HACC = '/tmp/wf-health.acc', HUC = '/usr/share/wrtfreedom/health.uc';
function hbg(a) { sh('( ucode ' + HUC + ' ' + a + ' ) >/dev/null 2>&1 </dev/null &'); }
/* processore (%) dalla differenza con la lettura precedente; tick = giro di ogni minuto di health.uc, con il suo stato a
   parte (le letture dell'app non accorciano il campione di un minuto usato per i picchi e per «sotto sforzo da 10
   minuti»); due letture nello stesso secondo = il valore di prima */
function hcpu(tick) {
	let F = tick ? HCPU + '.tick' : HCPU;
	let f = split(trim(substr(readfile('/proc/stat') ?? '', 4, 200)), /\s+/), tot = 0, n = [];
	for (let i = 0; i < 8 && i < length(f); i++) { push(n, +f[i]); tot += +f[i]; }
	let now = { t: +(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]), idle: (n[3] ?? 0) + (n[4] ?? 0), tot: tot }, pv = rjs(F), pct = null;
	if (pv && now.t >= pv.t && now.t - pv.t < 1 && pv.pct != null) return pv.pct;
	if (pv && now.t > pv.t && now.tot > pv.tot) {
		pct = int(100 - (now.idle - pv.idle) * 100.0 / (now.tot - pv.tot) + 0.5);
		pct = pct < 0 ? 0 : pct > 100 ? 100 : pct;
	}
	now.pct = pct;
	wjs(F, now);
	return pct;
}
/* ventola: giri al minuto (fan*_input) e forza (pwm, 0…255) dai sensori, altrimenti il raffreddamento «fan» del kernel;
   null = il router non ha una ventola che si legge */
function hfan() {
	let r = null;
	for (let h in lsdir('/sys/class/hwmon') ?? []) {
		let d = '/sys/class/hwmon/' + h + '/', L0 = lsdir(d) ?? [], isfan = match(trim(readfile(d + 'name') ?? ''), /fan/i) != null;
		for (let f in L0) if (match(f, /^fan[0-9]_input$/)) {
			isfan = true; r = r ?? {};
			let v = +trim(readfile(d + f) ?? '0');
			if (r.rpm == null || v > r.rpm) r.rpm = v;
		}
		if (isfan) for (let f in L0) if (match(f, /^pwm[0-9]$/)) {
			r = r ?? {};
			let v = int(+trim(readfile(d + f) ?? '0') * 100 / 255 + 0.5);
			if (r.pct == null || v > r.pct) r.pct = v;
		}
	}
	if (r?.pct == null) for (let c in lsdir('/sys/class/thermal') ?? []) {
		let d = '/sys/class/thermal/' + c + '/';
		if (index(c, 'cooling_device') != 0 || !match(trim(readfile(d + 'type') ?? ''), /fan/i)) continue;
		let cur = +trim(readfile(d + 'cur_state') ?? '0'), mx = +trim(readfile(d + 'max_state') ?? '0');
		if (mx > 0) { r = r ?? {}; r.pct = int(cur * 100 / mx + 0.5); }
	}
	if (r) r.on = (r.rpm ?? 0) > 0 || (r.pct ?? 0) > 0;
	return r;
}
/* temperatura del modem (°C) dall'ultima lettura fatta in sottofondo (al massimo 15 minuti fa), null se non la dà: solo il
   file /tmp/wf-modem.at (righe +QTEMP, la stessa lettura di n.temp in modem.uc: se cambia, cambiarle insieme) */
function hmtemp() {
	let s = stat('/tmp/wf-modem.at');
	if (!s || time() - s.mtime > 900) return null;
	let mx = null;
	for (let m in match(readfile('/tmp/wf-modem.at') ?? '', /\+QTEMP: *"[^"]+","([0-9]+)"/g) ?? []) if (mx == null || +m[1] > mx) mx = +m[1];
	return mx != null && mx > 0 && mx < 150 ? mx : null;
}
function healthcalc(tick) {
	let W = ucfile('wrtfreedom'), T = hth(W), now = time(), dash = '—', st = readfile('/proc/stat') ?? '';
	let cp = hcpu(tick), ld = map(slice(split(trim(readfile('/proc/loadavg') ?? ''), ' '), 0, 3), (x) => +x);
	let cpu = { pct: cp, n: length(filter(split(st, '\n'), (l) => match(l, /^cpu[0-9]+ /) != null)) || null, load: ld, long: +(rjs(HACC)?.cc ?? 0) >= 10,
		v: cp == null ? dash : cp >= T.cpu ? L('Sotto Sforzo', 'Under Strain') : cp >= 50 ? L('Impegnato', 'Busy') : L('Tranquillo', 'Calm') };
	/* memoria: lo stesso conto di snapshot (MemAvailable) */
	let mi = readfile('/proc/meminfo') ?? '', mt = match(mi, /MemTotal:[ \t]+([0-9]+)/), ma = match(mi, /MemAvailable:[ \t]+([0-9]+)/), mem = null;
	if (mt && ma && +mt[1] > 0) {
		let t = +mt[1] * 1024, a = +ma[1] * 1024, p = int((t - a) * 100 / t);
		mem = { pct: p, total: t, used: t - a, avail: a, lvl: hlev('mem', p, T) };
		mem.v = mem.lvl == 'ok' ? L('Normale', 'Normal') : L('Quasi Finita', 'Almost Full');
	}
	/* temperatura: il sensore più alto (thermc, come Stato Della Casa) */
	let tc = thermc(), temp = { c: tc, lvl: hlev('temp', tc, T), sensors: length(filter(lsdir('/sys/class/thermal') ?? [], (z) => index(z, 'thermal_zone') == 0)), modem: hmtemp() };
	temp.v = tc == null ? dash : temp.lvl == 'bad' ? L('Molto Alta', 'Very High') : temp.lvl == 'warn' ? L('Alta', 'High') : L('Normale', 'Normal');
	/* spazio: la percentuale di diskpct (come Stato Della Casa), le dimensioni da procd */
	let dp = diskpct(), rt = (ubcall('system', 'info') ?? {}).root ?? {};
	let disk = { pct: dp, free: dp == null ? null : 100 - dp, lvl: hlev('disk', dp, T), total: +(rt.total ?? 0) * 1024 || null, used: +(rt.used ?? 0) * 1024 || null };
	disk.v = dp == null ? dash : disk.lvl == 'bad' ? L('Pieno', 'Full') : disk.lvl == 'warn' ? L('Quasi Pieno', 'Almost Full') : L('Libero', 'Free');
	/* servizi fermi: solo quanti, stesso calcolo di svc (svcstate, 2.55) */
	let ns = svcstate().n;
	let why = [], add = (id, sev, it, en) => push(why, { id: id, sev: sev, text: L(it, en) });
	if (temp.lvl != 'ok') add('temp', temp.lvl, (temp.lvl == 'bad' ? 'Temperatura Molto Alta · ' : 'Temperatura Alta · ') + tc + ' °C', (temp.lvl == 'bad' ? 'Very High Temperature · ' : 'High Temperature · ') + tc + ' °C');
	if (disk.lvl != 'ok') add('disk', disk.lvl, (disk.lvl == 'bad' ? 'Spazio Pieno · ' : 'Spazio Quasi Pieno · ') + disk.free + '% Libero', (disk.lvl == 'bad' ? 'Storage Full · ' : 'Storage Almost Full · ') + disk.free + '% Free');
	if (mem?.lvl == 'warn') add('mem', 'warn', 'Memoria Quasi Finita · ' + mem.pct + '% Usata', 'Memory Almost Full · ' + mem.pct + '% Used');
	why = sort(why, (a, b) => (a.sev == 'bad' ? 0 : 1) - (b.sev == 'bad' ? 0 : 1));
	let state = length(filter(why, (x) => x.sev == 'bad')) ? 'bad' : length(why) ? 'warn' : 'ok';
	return { t: now, state: state, v: state == 'bad' ? L('Problema', 'Problem') : state == 'warn' ? L('Da Controllare', 'Check') : L('Tutto Bene', 'All Good'),
		why: why, th: T, cpu: cpu, mem: mem, temp: temp, disk: disk, up: upsec(), stopped: ns, fan: hfan(), boot: rjs('/tmp/wf-health.boot.json'),
		al: { temp: ug(W, 'health', 'al_temp') != '0', disk: ug(W, 'health', 'al_disk') != '0', mem: ug(W, 'health', 'al_mem') != '0',
			boot: ug(W, 'health', 'al_boot') != '0', cpu: ug(W, 'health', 'al_cpu') == '1' } };
}
/* storico 24 ore (health.uc: un punto ogni 5 minuti con i picchi dei minuti) più il blocco in corso; picco, minimo e media
   veri dei punti; boots = accensioni nelle 24 ore (segno sul grafico). Le righe si leggono come histread di health.uc: se
   cambia il formato, cambiarle insieme */
function hhist() {
	let now = time(), P = [], num = (x) => x == '-' ? null : +x;
	for (let l in split(readfile(HHIST) ?? '', '\n')) {
		let m = match(l, /^([0-9]{9,11}) (-|[0-9]{1,3}) (-|[0-9]{1,3}) (-|[0-9]{1,3})$/);
		if (m && +m[1] > now - 86400 && +m[1] <= now) push(P, [+m[1], num(m[2]), num(m[3]), num(m[4])]);
	}
	let A = rjs(HACC);
	if (A && +A.b > now - 600 && +A.b <= now && (!length(P) || P[length(P) - 1][0] < +A.b)) push(P, [+A.b, A.cpu ?? null, A.mem ?? null, A.temp ?? null]);
	let peak = {}, min = {}, avg = {}, K = ['cpu', 'mem', 'temp'];
	for (let i = 0; i < 3; i++) {
		let s = 0, n = 0, hi = null, lo = null;
		for (let p in P) {
			let v = p[i + 1];
			if (v == null) continue;
			s += v; n++;
			if (hi == null || v >= hi[0]) hi = [v, p[0]];
			if (lo == null || v < lo[0]) lo = [v, p[0]];
		}
		peak[K[i]] = hi; min[K[i]] = lo; avg[K[i]] = n ? int(s / n + 0.5) : null;
	}
	let B = rjs('/etc/wrtfreedom/boots.json');
	return { t: now, step: 300, pts: P, peak: peak, min: min, avg: avg,
		boots: map(filter(type(B) == 'array' ? B : [], (b) => b?.t != null && b.t > now - 86400), (b) => b.t) };
}
/* Cosa Pesa Di Più: nomi semplici dei programmi del router; [regola, nome, name, descrizione, description, true = la regola
   vale per tutta la riga di comando (script), altrimenti per il nome del processo o del programma] */
const HPN = [
	[ /^AdGuardHome$/i, 'AdGuard Home', 'AdGuard Home', 'Blocca pubblicità e siti pericolosi', 'Blocks ads and dangerous sites' ],
	[ /^ModemManager$/, 'Gestione Del Modem', 'Modem Manager', 'Tiene collegata la SIM', 'Keeps the SIM connected' ],
	[ /^nlbwmon$/, 'Statistiche Del Traffico', 'Traffic Statistics', 'Quanto consuma ogni dispositivo', 'How much each device uses' ],
	[ /^dnsmasq$/, 'Nomi e Indirizzi Della Rete', 'Network Names and Addresses', 'Dà gli indirizzi ai dispositivi', 'Gives addresses to devices' ],
	[ /^odhcpd$/, 'Indirizzi Moderni Della Rete', 'Modern Network Addresses', 'Indirizzi di nuova generazione', 'Next-generation addresses' ],
	[ /^(hostapd|wpad|wpa_supplicant)$/, 'Wi-Fi', 'Wi-Fi', 'Le reti senza fili del router', 'The router wireless networks' ],
	[ /^netifd$/, 'Gestione Della Rete', 'Network Manager', 'Accende le reti e la linea', 'Brings up networks and the line' ],
	[ /^(uhttpd|nginx|lighttpd)$/, 'Pagina Web Del Router', 'Router Web Page', 'L\'app e la pagina di configurazione', 'The app and the setup page' ],
	[ /^rpcd$/, 'Collegamento Con L\'App', 'App Connection', 'Risponde alle richieste dell\'app', 'Answers the app requests' ],
	[ /^dropbear$/, 'Accesso Da Terminale', 'Terminal Access', 'Per le app di terminale', 'For terminal apps' ],
	[ /^ubusd$/, 'Comunicazione Interna', 'Internal Messaging', 'Fa parlare i programmi del router', 'Lets router programs talk' ],
	[ /^procd$/, 'Avvio Dei Servizi', 'Service Starter', 'Accende e controlla i servizi', 'Starts and watches services' ],
	[ /^logd$/, 'Registro Del Router', 'Router Log', 'Tiene i messaggi del router', 'Keeps router messages' ],
	[ /^crond$/, 'Pianificazioni', 'Schedules', 'Esegue le attività a orario', 'Runs scheduled tasks' ],
	[ /^(ntpd|sysntpd|chronyd)$/, 'Ora Esatta', 'Exact Time', 'Prende l\'ora da internet', 'Gets the time from internet' ],
	[ /cake-autorate|autorate/, 'Velocità Adattiva', 'Adaptive Speed', 'Segue la velocità della linea', 'Follows the line speed', true ],
	[ /tgbot\.uc/, 'Bot Telegram', 'Telegram Bot', 'Avvisi e comandi', 'Alerts and commands', true ],
	[ /\/usr\/share\/wrtfreedom\//, 'Controlli Di WrtFreedom', 'WrtFreedom Checks', 'Dispositivi, linea e avvisi', 'Devices, line and alerts', true ],
	[ /^(tailscaled|tailscale)$/, 'Tailscale', 'Tailscale', 'Rete privata Tailscale', 'Tailscale private network' ],
	[ /^zerotier-one$/, 'ZeroTier', 'ZeroTier', 'Rete privata ZeroTier', 'ZeroTier private network' ],
	[ /^(dockerd|containerd)$/, 'Docker', 'Docker', 'Programmi nei contenitori', 'Programs in containers' ],
	[ /^openvpn$/, 'OpenVPN', 'OpenVPN', 'Collegamento VPN', 'VPN connection' ],
	[ /^(smbd|nmbd|ksmbd|samba)$/, 'Cartelle Condivise', 'Shared Folders', 'File in rete', 'Network files' ],
	[ /^minidlna$/, 'Video e Musica In Rete', 'Network Video and Music', 'Per TV e casse', 'For TVs and speakers' ]
];
function hpname(comm, cl) {
	let c0 = replace(split(cl, ' ')[0] ?? '', /^.*\//, '');
	for (let x in HPN) if (x[5] ? match(cl, x[0]) : (match(comm, x[0]) || match(c0, x[0])))
		return { id: lc(replace(x[2], /[^A-Za-z0-9]+/g, '')), name: L(x[1], x[2]), desc: L(x[3], x[4]) };
	return { id: 'p_' + lc(replace(comm, /[^A-Za-z0-9_.-]+/g, '')), name: comm, desc: '' };
}
/* programmi che usano più memoria (e quanto processore dall'ultima lettura): /proc/<pid>/stat e cmdline, nessun processo;
   i processi dello stesso programma vanno insieme */
function htop(nmax) {
	let st = readfile('/proc/stat') ?? '', f = split(trim(substr(st, 4, index(st, '\n') - 4)), /\s+/), tot = 0, R = [], P = {};
	for (let x in f) tot += +x;
	/* pagina di memoria (kB): VmRSS / rss di questo processo, di solito 4 */
	let ss = readfile('/proc/self/stat') ?? '', sr = +(split(substr(ss, rindex(ss, ')') + 2), ' ')[21] ?? 0), vr = +(match(readfile('/proc/self/status') ?? '', /VmRSS:[ \t]+([0-9]+)/)?.[1] ?? 0);
	let pk = sr > 0 && vr > 0 ? int(vr / sr + 0.5) : 4;
	if (index([4, 8, 16, 64], pk) < 0) pk = 4;
	let up = +(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]), pv = rjs('/tmp/wf-htop.prev'), G = {};
	for (let d in lsdir('/proc') ?? []) {
		if (!match(d, /^[0-9]{1,10}$/)) continue;
		let s = readfile('/proc/' + d + '/stat');
		if (!s) continue;
		let a = index(s, '('), e = rindex(s, ')'), x = split(substr(s, e + 2), ' '), rss = +(x[21] ?? 0);
		if (a < 0 || e < a || rss <= 0) continue;	/* processi del kernel: niente memoria propria */
		let tk = +(x[11] ?? 0) + +(x[12] ?? 0), cl = join(' ', split(readfile('/proc/' + d + '/cmdline') ?? '', chr(0)));
		P[d] = tk;
		let N = hpname(substr(s, a + 1, e - a - 1), trim(cl)), g = G[N.id];
		if (!g) g = G[N.id] = { id: N.id, name: N.name, desc: N.desc, mem: 0, tk: 0, n: 0, up: 0, cpu: null };
		g.mem += rss * pk * 1024; g.n++;
		let age = int(up - +(x[19] ?? 0) / 100);
		if (age > g.up) g.up = age;
		if (pv?.p && pv.p[d] != null && tot > +(pv.tot ?? 0) && tk >= pv.p[d]) g.tk += tk - pv.p[d];
	}
	writefile('/tmp/wf-htop.prev', sprintf('%J', { tot: tot, p: P }));
	let dt = pv ? tot - +(pv.tot ?? 0) : 0;
	for (let k in G) { if (dt > 0) G[k].cpu = int(G[k].tk * 1000 / dt + 0.5) / 10; delete G[k].tk; push(R, G[k]); }
	R = sort(R, (a, b) => b.mem - a.mem);
	let mi = readfile('/proc/meminfo') ?? '', mt = +(match(mi, /MemTotal:[ \t]+([0-9]+)/)?.[1] ?? 0) * 1024, ma = +(match(mi, /MemAvailable:[ \t]+([0-9]+)/)?.[1] ?? 0) * 1024;
	return { t: time(), list: slice(R, 0, nmax), total: mt || null, used: mt ? mt - ma : null, n: length(R) };
}
/* Spie Di Notte (wrtfreedom.ledn {on, from, to, days, keep}): righe «# wf:ledn_off» e «# wf:ledn_on» con cron.sh
   ledoff/ledon (spente senza scrivere sulla memoria interna; le spie spente per sempre con ledset restano spente) */
function hmin2(s) { let m = match('' + (s ?? ''), /^([01][0-9]|2[0-3]):([0-5][0-9])$/); return m ? +m[1] * 60 + +m[2] : null; }
function ledninfo() {
	let W = ucfile('wrtfreedom'), dd = split(trim(ug(W, 'ledn', 'days')), ' '), C = crsplit(readfile(CRONF) ?? '');
	let r = { on: ug(W, 'ledn', 'on') == '1', from: ug(W, 'ledn', 'from') || '23:00', to: ug(W, 'ledn', 'to') || '07:00',
		days: length(dd[0]) ? map(dd, (x) => +x) : [0, 1, 2, 3, 4, 5, 6], keep: filter(split(trim(ug(W, 'ledn', 'keep')), ' '), (x) => length(x)),
		leds: length(lsdir('/sys/class/leds') ?? []), night: has('/tmp/wf-leds.save'),
		/* attività accese di Pianificazioni che fanno lo stesso (spegnere o riaccendere le spie): con Spie Di Notte accese si
		   sospendono */
		dup: length(filter(C.app, (p) => p.on && match(p.cmd, /cron\.sh led(off|on)( |$)/) != null)) };
	return r;
}
/* adesso è dentro la fascia delle Spie Di Notte? (f, t minuti; days 0 = domenica: conta il giorno in cui la notte inizia) */
function lednnow(f, t, days) {
	let lt = localtime(time()), n = lt.hour * 60 + lt.min, inw = f < t ? (n >= f && n < t) : (n >= f || n < t), dw = (f > t && n < t) ? (lt.wday + 6) % 7 : lt.wday;
	return inw && index(days, dw) >= 0;
}
/* ---------- Altro · Manutenzione (2.55): nomi semplici, registro, test di velocità, assistenza, strumenti, rc.local ----------
   Servizi In Parole Semplici: i nomi sono quelli di Cosa Pesa Di Più (HPN, hpname) con il nome del programma del
   servizio; SVCX = servizi che non sono un programma con quel nome. Gruppi: ess (Essenziali), fun (Funzioni: servizi
   conosciuti), alt (Altri) */
const SVCESS = { dropbear: true, uhttpd: true, nginx: true, rpcd: true, network: true, firewall: true, dnsmasq: true, odhcpd: true,
	log: true, sysntpd: true, cron: true, wpad: true, urngd: true };
const SVCPROC = { log: 'logd', cron: 'crond', network: 'netifd', modemmanager: 'ModemManager', adguardhome: 'AdGuardHome',
	wrtfreedom: '/usr/share/wrtfreedom/' };
const SVCX = {
	firewall: [ 'Protezione Della Rete', 'Network Protection', 'Ferma gli accessi da fuori casa', 'Stops access from outside' ],
	sqm: [ 'Controllo Della Linea', 'Line Control', 'Tiene bassa l\'attesa con la linea piena', 'Keeps delay low on a busy line' ],
	ddns: [ 'Nome Del Router In Internet', 'Router Name On The Internet', 'Segue l\'indirizzo quando cambia', 'Follows the address when it changes' ],
	umdns: [ 'Nomi Dei Dispositivi', 'Device Names', 'Fa trovare i dispositivi per nome', 'Lets devices be found by name' ],
	urngd: [ 'Numeri Casuali', 'Random Numbers', 'Servono alle connessioni sicure', 'Needed for secure connections' ],
	irqbalance: [ 'Ripartizione Del Lavoro', 'Load Sharing', 'Divide il lavoro tra i processori', 'Spreads work across processors' ],
	acme: [ 'Certificati', 'Certificates', 'Rinnova i certificati del router', 'Renews the router certificates' ],
	miniupnpd: [ 'Apertura Automatica Delle Porte', 'Automatic Port Opening', 'Per giochi e console', 'For games and consoles' ],
	ttyd: [ 'Terminale Nel Browser', 'Browser Terminal', 'Comandi dalla pagina web', 'Commands from the web page' ],
	vnstat: [ 'Statistiche Della Linea', 'Line Statistics', 'Traffico per giorno e mese', 'Traffic per day and month' ],
	mwan3: [ 'Più Linee Insieme', 'Multiple Lines', 'Usa più linee internet', 'Uses more internet lines' ],
	'https-dns-proxy': [ 'Nomi Cifrati', 'Encrypted Names', 'Chiede i nomi dei siti in modo cifrato', 'Asks site names encrypted' ],
	stubby: [ 'Nomi Cifrati', 'Encrypted Names', 'Chiede i nomi dei siti in modo cifrato', 'Asks site names encrypted' ]
};
function svcname(nm) {
	let x = SVCX[nm];
	if (x) return { name: L(x[0], x[1]), desc: L(x[2], x[3]), known: true };
	let p = SVCPROC[nm] ?? nm, N = hpname(p, p);
	return { name: N.name, desc: N.desc, known: substr(N.id, 0, 2) != 'p_' };
}
/* stato di svcstate con nome semplice, descrizione e gruppo; in ordine: Essenziali, Funzioni, Altri, poi per nome */
function svclist() {
	let S = svcstate(), G = { ess: 0, fun: 1, alt: 2 };
	for (let x in S.list) {
		let N = svcname(x.id);
		x.name = N.name; x.desc = N.desc; x.grp = SVCESS[x.id] ? 'ess' : N.known ? 'fun' : 'alt';
	}
	S.list = sort(S.list, (a, b) => G[a.grp] != G[b.grp] ? G[a.grp] - G[b.grp] : (lc(a.name) < lc(b.name) ? -1 : lc(a.name) > lc(b.name) ? 1 : 0));
	return S;
}
/* Registro In Parole Semplici: le righe (al massimo 300, come la pagina Registro) lette una volta e divise in {t, lv
   (0 emerg … 7 debug), prog, msg}. «Da Vedere» = lv <= 4 (warn…emerg): lo stesso conto di snapshot.logw */
const LOGLV = [ 'emerg', 'alert', 'crit', 'err', 'warn', 'notice', 'info', 'debug' ];
const LOGMON = { Jan: 1, Feb: 2, Mar: 3, Apr: 4, May: 5, Jun: 6, Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12 };
/* ora locale del registro → epoch con il fuso del router, ora legale compresa (2.58: timelocal senza isdst la leggeva
   come ora solare, un'ora avanti d'estate): g = stessa ora letta come UTC, meno la differenza tra ora locale e UTC in
   quel momento, riletta una seconda volta per i giorni del cambio d'ora */
function logtime(T) {
	let g = timegm(T), o = timegm(localtime(g)) - g;
	o = timegm(localtime(g - o)) - (g - o);
	return g - o;
}
/* riga di busybox crond (cron.err) all'avvio di un'attività: «USER <utente> pid <n> cmd <comando>» non è un errore
   (2.58): livello info e testo «Partita: <primo script o comando>» (nome senza cartella; il seguito «; ucode … svc.uc
   log … $?» che aggiunge WrtFreedom non conta); null se la riga non è di questo tipo */
function logcron(msg) {
	let m = match(msg, /^USER [^ ]+ pid [0-9]+ cmd (.*)$/);
	if (!m) return null;
	let c = replace(m[1], /^[{( \t]+/, ''), w = match(c, /^[^ \t;|&(){}]+/);
	let b = w ? replace(w[0], /^.*\//, '') : '';
	return L('Partita: ', 'Started: ') + (length(b) ? b : L('attività', 'task'));
}
function logrows(kind) {
	let R = [];
	if (kind == 'kern') {
		let b = time() - upsec();
		for (let l in split(sh('dmesg -r 2>/dev/null | tail -n 300'), '\n')) {
			let m = match(l, /^<([0-9]{1,3})>\[ *([0-9]{1,10})[.0-9]*\] ?(.*)$/);
			if (m) push(R, { t: b + +m[2], lv: +m[1] & 7, prog: 'kernel', msg: m[3] });
		}
		return R;
	}
	for (let l in split(sh('logread -l 300 2>/dev/null'), '\n')) {
		let m = match(l, /^[A-Za-z]{3} ([A-Za-z]{3}) +([0-9]{1,2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) ([0-9]{4}) [a-z0-9]{1,12}\.([a-z]{1,8}) ([^:]{1,64}): ?(.*)$/);
		if (!m) continue;
		let lv = index(LOGLV, m[7]), t = LOGMON[m[1]] ? logtime({ sec: +m[5], min: +m[4], hour: +m[3], mday: +m[2], mon: LOGMON[m[1]], year: +m[6] }) : null;
		let pg = replace(trim(m[8]), /\[[0-9]{1,10}\]$/, ''), ms = m[9], cr = pg == 'crond' ? logcron(ms) : null;
		if (cr) { lv = 6; ms = cr; }
		push(R, { t: t, lv: lv < 0 ? 6 : lv, prog: pg, msg: ms });
	}
	return R;
}
/* nome semplice di un programma del registro: kernel = Sistema Di Base, poi come i servizi (svcname, hpname) */
function logname(p) {
	let b = replace(p, /-(dhcp|script)$/, '');
	if (b == 'kernel') return { id: 'kernel', name: L('Sistema Di Base', 'Base System'), desc: L('Messaggi del sistema e dei driver', 'System and driver messages') };
	if (b == 'ddns-scripts') b = 'ddns';
	if (b == 'fw4') b = 'firewall';
	if (match(b, /^(wrtfreedom|wf-)/)) b = 'wrtfreedom';
	let N = SVCX[b] || SVCPROC[b] ? svcname(b) : hpname(b, b);
	return { id: lc(replace(b, /[^A-Za-z0-9]+/g, '')) || 'altro', name: N.name, desc: N.desc };
}
/* gruppi per programma: righe uguali (numeri a parte) contate insieme; see = righe Da Vedere; rep = righe ripetute */
function loggroups(R, onlysee) {
	let G = {}, out = [];
	for (let r in R) {
		if (onlysee && r.lv > 4) continue;
		let N = logname(r.prog), g = G[N.id];
		if (!g) g = G[N.id] = { id: N.id, name: N.name, desc: N.desc, prog: r.prog, n: 0, see: 0, rep: 0, lv: 7, t: null, M: {} };
		g.n++;
		if (r.lv <= 4) g.see++;
		if (r.lv < g.lv) g.lv = r.lv;
		if (r.t != null && (g.t == null || r.t >= g.t)) g.t = r.t;
		let k = replace(r.msg, /[0-9]+/g, '#'), x = g.M[k];
		if (x) { x.n++; g.rep++; x.text = r.msg; if (r.t != null) x.t = r.t; if (r.lv < x.lv) x.lv = r.lv; }
		else g.M[k] = { text: r.msg, n: 1, lv: r.lv, t: r.t };
	}
	for (let id, g in G) {
		let M = sort(map(keys(g.M), (k) => g.M[k]), (a, b) => a.lv <= 4 && b.lv > 4 ? -1 : b.lv <= 4 && a.lv > 4 ? 1 : b.n - a.n);
		g.msgs = map(slice(M, 0, 5), (x) => ({ text: substr(x.text, 0, 240), n: x.n, lv: LOGLV[x.lv], see: x.lv <= 4, t: x.t }));
		g.kinds = length(M);
		g.lv = LOGLV[g.lv];
		delete g.M;
		push(out, g);
	}
	return sort(out, (a, b) => b.see != a.see ? b.see - a.see : b.n - a.n);
}
/* Un Solo Test Di Velocità: speed.uc fa il test (speedtest-go, Cloudflare solo come ripiego dichiarato in via) e salva
   l'ultimo risultato in /tmp (copia rara in /etc); pagina, widget, bot e Pianificazioni leggono lo stesso file */
const SPDUC = '/usr/share/wrtfreedom/speed.uc', SPDF = '/tmp/wf-speed.json', SPDFE = '/etc/wrtfreedom/speed.json', SPDLK = '/tmp/wf-speed.lock';
function spdbusy() { let s = stat(SPDLK); return s != null && time() - s.mtime < 180; }
/* comando del test con la partenza dal collegamento del Servizio VPN (via = wgout, wgo1…): regola temporanea per
   l'indirizzo del router nella VPN, tolta alla fine (come la 2.42) */
function spdcmd(via) {
	let pre = '', post = '', src = '', vv = '';
	if (length(via)) {
		if (!match(via, /^wgo(ut|[1-5])$/)) return { error: 'collegamento non valido' };
		let ad = trim(sh("ip -4 -o addr show dev " + via + " 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n 1")), tb = via == 'wgout' ? 100 : 100 + +substr(via, 3);
		if (!length(ad)) return { error: 'il collegamento VPN non è attivo' };
		pre = 'ip rule add from ' + ad + ' lookup ' + tb + ' priority 899; '; post = '; ip rule del from ' + ad + ' lookup ' + tb + ' priority 899';
		src = ad; vv = via;
	}
	return pre + 'ucode ' + SPDUC + ' run ' + q(src) + ' ' + q(vv) + post;
}
function spdget() {
	let S = rjs(SPDF) ?? rjs(SPDFE) ?? {};
	return { last: S.last ?? null, list: S.list ?? [], fail: S.fail ?? null, run: spdbusy(),
		tool: { go: has('/usr/bin/speedtest-go'), alt: has('/usr/bin/curl') || has('/bin/uclient-fetch') } };
}
/* Pacchetto Per L'Assistenza: assist.uc lo prepara in sottofondo (senza segreti, controllato), si toglie dopo 30 minuti */
const ASF = '/tmp/wf-assist.tar.gz', ASJ = '/tmp/wf-assist.json', ASLK = '/tmp/wf-assist.lock', ASTTL = 1800;
function asget() {
	let S = rjs(ASJ) ?? {}, st = stat(ASF), lk = stat(ASLK), busy = lk != null && time() - lk.mtime < 300;
	if (st && !busy && time() - st.mtime > ASTTL) { unlink(ASF); unlink(ASJ); st = null; S = {}; }
	return { busy: busy, ready: st != null && !busy, t: st ? S.t ?? st.mtime : null, size: st ? st.size : 0,
		left: st && !busy ? ASTTL - (time() - st.mtime) : 0, path: ASF, files: S.files ?? [], skip: S.skip ?? [], err: S.err ?? null };
}
/* Strumenti Mancanti: [id, nome, name, programmi possibili, pacchetto da installare (null = parte del sistema)] */
const DGTOOLS = [
	[ 'speed', 'Test Di Velocità', 'Speed Test', [ '/usr/bin/speedtest-go' ], 'speedtest-go' ],
	[ 'ping', 'Tempo Di Risposta', 'Response Time', [ '/bin/ping', '/usr/bin/ping', '/sbin/ping' ], 'iputils-ping' ],
	[ 'trace', 'Percorso', 'Route', [ '/usr/bin/traceroute', '/bin/traceroute', '/usr/sbin/traceroute' ], 'traceroute' ],
	[ 'dns', 'Prova Dei Nomi', 'Name Test', [ '/usr/bin/nslookup', '/bin/nslookup', '/usr/sbin/nslookup' ], 'bind-nslookup' ],
	[ 'arp', 'Prova Un Dispositivo', 'Test A Device', [ '/usr/sbin/arping', '/usr/bin/arping', '/bin/arping', '/sbin/arping' ], 'iputils-arping' ],
	[ 'curl', 'Ripiego Del Test Di Velocità', 'Speed Test Fallback', [ '/usr/bin/curl' ], 'curl' ]
];
/* Comandi All'Avvio Con Copia: copia di /etc/rc.local prima di ogni modifica (ultime 5), Annulla L'Ultima Modifica */
const RCL = '/etc/rc.local', RCLD = '/etc/wrtfreedom/rclocal';
function rclcopies() {
	let C = [];
	for (let f in lsdir(RCLD) ?? []) {
		let m = match(f, /^rc\.local\.([0-9]{9,11})$/), s = m ? stat(RCLD + '/' + f) : null;
		if (s) push(C, { t: +m[1], size: s.size, f: f });
	}
	return sort(C, (a, b) => b.t - a.t);
}
/* copia buona solo se il file ha la dimensione del testo (spazio pieno = copia tolta, falso) */
function rclcopy(cur) {
	mkdir('/etc/wrtfreedom'); mkdir(RCLD, 448);
	let t = time();
	while (has(RCLD + '/rc.local.' + t)) t++;
	let f = RCLD + '/rc.local.' + t, w = writefile(f, cur);
	if (w !== length(cur) || stat(f)?.size !== length(cur)) { unlink(f); return false; }
	return true;
}
/* nuovo rc.local al posto del vecchio solo se scritto tutto (altrimenti il vecchio resta e il .wf si toglie) */
function rclput(n) {
	let w = writefile(RCL + '.wf', n);
	if (w !== length(n) || !rename(RCL + '.wf', RCL)) { unlink(RCL + '.wf'); return false; }
	return true;
}
function rcltrim() { for (let x in slice(rclcopies(), 5)) unlink(RCLD + '/' + x.f); }
function rclget() {
	let C = rclcopies();
	return { text: readfile(RCL) ?? '', copies: map(C, (x) => ({ t: x.t, size: x.size })), undo: length(C) > 0 };
}

/* ---------- Assistente IA (2.60): chat, letture, comandi con conferma, Aiuto Senza Internet ----------
   Spento di serie: da spento nessuna chiamata, nessun processo, nessun file. Qui solo letture di file e uci: le chiamate
   al fornitore, le letture per l'IA e i comandi confermati li fa ai.uc in sottofondo, staccato da rpcd (setsid o
   start-stop-daemon -b), con file propri in /tmp/wf-ai (cartella 0700, file 0600), mai /tmp/.wf-job.
   Chiave in /etc/wrtfreedom/ai-<fornitore>.key (0600, fuori da uci, esclusa dalle copie, mai riletta dall'app); in uci
   (sezione wrtfreedom.ai) solo on, prov, ok_<fornitore> (consenso), key_<fornitore>, model_<fornitore>, url_openai, max.
   Lavori lunghi: il metodo scrive p-<id>.json (parametri, senza chiave) e job-<id>.json {id, kind, done:false, t},
   lancia «ai.uc <lavoro> <id>» e torna subito con {id}; l'esito si legge con aiget {job}. Una sola regola di stato: aistat */
const AID = '/tmp/wf-ai', AIUC = '/usr/share/wrtfreedom/ai.uc', AIK = '/etc/wrtfreedom/ai-';
/* Unione Europea, Spazio Economico Europeo, Svizzera e Regno Unito: Gemini gratuito con le regole dei servizi a pagamento */
const AIEU = [ 'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL',
	'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'IS', 'LI', 'NO', 'CH', 'GB' ];
/* fornitori: formato, indirizzo e modello di serie, limiti del piano gratuito (rpm richieste e tpm token al minuto) */
const AIPROV = {
	groq: { name: 'Groq', fmt: 'openai', url: 'https://api.groq.com/openai/v1', model: 'openai/gpt-oss-120b', key: true, rpm: 30, tpm: 8000, rpd: 1000, cc: 'USA',
		it: 'Le domande e i dati del router, già puliti, vanno a Groq, negli USA. Di serie Groq non li conserva; tiene un registro fino a 30 giorni solo per guasti o abusi.',
		en: 'Questions and router data, already cleaned, go to Groq, in the USA. By default Groq does not keep them; it keeps a log for up to 30 days only for faults or abuse.' },
	gemini: { name: 'Gemini', fmt: 'gemini', url: 'https://generativelanguage.googleapis.com/v1beta', model: 'gemini-3.5-flash-lite', key: true, cc: 'Google',
		it: 'Le domande e i dati del router, già puliti, vanno a Google (Gemini). Da qui valgono le regole dei servizi a pagamento: Google non li usa per migliorare i suoi prodotti.',
		en: 'Questions and router data, already cleaned, go to Google (Gemini). From here the rules of the paid services apply: Google does not use them to improve its products.',
		it2: 'Le domande e i dati del router, già puliti, vanno a Google (Gemini). Con il piano gratuito Google li usa per migliorare i suoi prodotti e persone possono leggerli.',
		en2: 'Questions and router data, already cleaned, go to Google (Gemini). With the free plan Google uses them to improve its products and people may read them.' },
	claude: { name: 'Claude', fmt: 'claude', url: 'https://api.anthropic.com/v1', model: 'claude-haiku-4-5', key: true, cc: 'USA',
		it: 'Le domande e i dati del router, già puliti, vanno ad Anthropic (Claude), negli USA. È a consumo: paghi quello che usi.',
		en: 'Questions and router data, already cleaned, go to Anthropic (Claude), in the USA. It is pay as you go.' },
	/* 2.64: OpenRouter, indirizzo fisso, formato OpenAI; modelli ospitati da fornitori diversi (anche DeepSeek, in Cina) */
	openrouter: { name: 'OpenRouter', fmt: 'openai', url: 'https://openrouter.ai/api/v1', model: 'deepseek/deepseek-chat', key: true, cc: 'USA',
		it: 'Le domande e i dati del router, già puliti, vanno a OpenRouter, negli USA, che li passa al fornitore che ospita il modello scelto, anche fuori dall\'Europa (DeepSeek è un\'azienda cinese). I modelli «:free» hanno limiti bassi e le domande possono essere usate per addestrarli.',
		en: 'Questions and router data, already cleaned, go to OpenRouter, in the USA, which passes them to the provider hosting the chosen model, also outside Europe (DeepSeek is a Chinese company). «:free» models have low limits and questions may be used to train them.' },
	openai: { name: 'Formato OpenAI', fmt: 'openai', url: '', model: '', key: false, cc: '',
		it: 'Le domande e i dati del router, già puliti, vanno all\'indirizzo che hai scelto: %s.', en: 'Questions and router data, already cleaned, go to the address you chose: %s.',
		it2: 'Le domande e i dati del router restano in casa: il modello gira su un tuo computer.', en2: 'Questions and router data stay at home: the model runs on one of your computers.' }
};
/* indirizzo in casa (Ollama, LM Studio): IP privato, localhost o nome locale */
function aihost(u) { let m = match('' + u, /^https?:\/\/(\[[0-9A-Fa-f:]{2,39}\]|[A-Za-z0-9.-]{1,253})/); return m ? lc(m[1]) : ''; }
function aipriv(u) {
	let h = aihost(u);
	return match(h, /^(10\.|127\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|169\.254\.)/) != null || match(h, /^\[(fd|fc|fe80|::1)/) != null ||
		h == 'localhost' || match(h, /\.(lan|local|home|internal|home\.arpa)$/) != null || (length(h) > 0 && index(h, '.') < 0 && substr(h, 0, 1) != '[');
}
/* paese del router: quello del Wi-Fi, altrimenti il fuso (Europe/… in Europa) */
function aieu() {
	let WL = ucfile('wireless');
	for (let k in WL) if (WL[k]['.type'] == 'wifi-device' && match(WL[k].country ?? '', /^[A-Za-z]{2}$/)) return index(AIEU, uc(WL[k].country)) >= 0;
	let z = '', SY = ucfile('system');
	for (let k in SY) if (!length(z)) z = SY[k].zonename ?? '';
	return match(z, /^Europe\//) != null && !match(z, /(Moscow|Minsk|Kiev|Kyiv|Istanbul|Belgrade|Sarajevo|Skopje|Podgorica|Tirane|Chisinau|Simferopol|Volgograd|Samara|Kaliningrad|Ulyanovsk|Saratov|Astrakhan|Kirov)$/);
}
/* fornitore con le scelte di uci (modello, indirizzo) e la frase su dove vanno i dati */
function aiprov(W, id) {
	let D = AIPROV[id];
	if (!D) return null;
	let url = id == 'openai' ? ug(W, 'ai', 'url_openai') : D.url, loc = id == 'openai' && length(url) > 0 && aipriv(url), eu = id == 'gemini' ? aieu() : true;
	let where = id == 'openai' ? (loc ? L(D.it2, D.en2) : sprintf(L(D.it, D.en), aihost(url) || '…')) : eu ? L(D.it, D.en) : L(D.it2, D.en2);
	return { id: id, name: id == 'openai' && loc ? L('Modello In Casa', 'Model At Home') : D.name, fmt: D.fmt, url: url, model: ug(W, 'ai', 'model_' + id) || D.model,
		key: D.key, has: has(AIK + id + '.key'), ok: ug(W, 'ai', 'ok_' + id) == '1', local: loc, rpm: D.rpm ?? 0, tpm: D.tpm ?? 0,
		cc: id == 'openai' ? (loc ? L('In Casa', 'At Home') : aihost(url)) : D.cc, where: where + ' ' + L('Chiavi e password non partono mai.', 'Keys and passwords are never sent.') };
}
/* fornitore pronto in alternativa a quello attivo pid (una sola regola, 2.64: altro da proporre, alts, riserva): '' = pronto,
   altrimenti il motivo in una frase (consenso, chiave, indirizzo o modello) */
function ainotready(W, id, pid) {
	let X = aiprov(W, id);
	if (!X) return 'fornitore di riserva non valido';
	if (id == pid) return 'il fornitore di riserva deve essere diverso da quello attivo';
	if (!X.ok) return 'serve il consenso del fornitore di riserva: sceglilo in Fornitore e accetta';
	if (X.key && !X.has) return 'manca la chiave del fornitore di riserva';
	if (!length(X.url) || !length(X.model)) return 'mancano l\'indirizzo o il modello del fornitore di riserva';
	return '';
}
function aiready(W, id, pid) { return !length(ainotready(W, id, pid)); }
/* stato degli errori di un fornitore (2.64, una sola regola): err-<id>.json {kind key|limit|busy, prov, until, t} scritto da
   ai.uc per ogni fornitore (un errore della riserva non tocca quello attivo); il vecchio err.json vale se è dello stesso */
function aierr(id) {
	if (!match('' + id, /^[a-z]{2,20}$/)) return null;
	let E = rjs(AID + '/err-' + id + '.json');
	if (E == null) { E = rjs(AID + '/err.json'); if (E?.prov != id) E = null; }
	return type(E) == 'object' ? E : null;
}
function aierrdel(id) {
	if (!match('' + id, /^[a-z]{2,20}$/)) return;
	unlink(AID + '/err-' + id + '.json');
	if (rjs(AID + '/err.json')?.prov == id) unlink(AID + '/err.json');
}
/* fornitore fermo adesso (chiave da rivedere, limite del giorno, occupato oltre 10 s): mai scelto come riserva o altro */
function aiheld(id, now) {
	let E = aierr(id);
	return E != null && (E.kind == 'key' || ((E.kind == 'limit' || E.kind == 'busy') && +(E.until ?? 0) - now > 10));
}
/* fornitore di riserva (2.64, uci wrtfreedom.ai.backup): id se pronto e diverso dall'attivo, altrimenti null */
function aibak(W, pid) { let b = ug(W, 'ai', 'backup'); return length(b) && aiready(W, b, pid) ? b : null; }
/* domande, comandi e token di oggi (ai.uc, /tmp/wf-ai/day.json; nuovo giorno = da zero, fuso del router) */
function aiday(now) {
	let D = rjs(AID + '/day.json') ?? {};
	/* 2.63: m = memorie automatiche, dp = domande con il ragionamento più profondo */
	return D.d == dday(now) ? { n: +(D.n ?? 0), c: +(D.c ?? 0), tok: +(D.tok ?? 0), w: +(D.w ?? 0), m: +(D.m ?? 0), dp: +(D.dp ?? 0) } : { n: 0, c: 0, tok: 0, w: 0, m: 0, dp: 0 };
}
/* secondi da aspettare prima della prossima chiamata (0 = subito): finestra di 60 s di min.json (richieste e token
   al minuto del piano gratuito, chiamata di ~1 500 token) o attesa chiesta dal fornitore (429 con retry-after) */
function aiwait(P, now, E) {
	let w = 0, M = filter(rjs(AID + '/min.json') ?? [], (x) => type(x) == 'object' && now - +(x.t ?? 0) < 60), tok = 0;
	for (let x in M) tok += +(x.tok ?? 0);
	if (P && length(M) && ((P.rpm && length(M) >= P.rpm) || (P.tpm && tok + 1500 > P.tpm))) w = +(M[0].t ?? now) + 60 - now;
	if (E?.kind == 'busy' && E.prov == P?.id && +(E.until ?? 0) - now > w) w = +E.until - now;
	return w > 0 ? w : 0;
}
/* lavoro in corso: pid scritto all'avvio (start-stop-daemon -m o ai.uc stesso), processo ancora vivo */
function aialive(id) { let p = trim(readfile(AID + '/pid-' + id) ?? ''); return match(p, /^[0-9]{1,10}$/) != null && has('/proc/' + p); }
/* lo stato (una sola regola): state off|nocurl|setup|busy|offline|key|limit|wait|ready, text = frase breve (riquadro,
   widget, tessera), why = frase per esteso, sev = colore (ok, info, warn, bad, off). wait = secondi prima della prossima
   chiamata (lo usa anche ai.uc: fino a 10 s aspetta, oltre si ferma). offline = senza internet (salvo modello in casa) */
function aistat(W) {
	W = W ?? ucfile('wrtfreedom');
	let now = time(), on = ug(W, 'ai', 'on') == '1', pid = ug(W, 'ai', 'prov'), P = aiprov(W, pid), D = aiday(now), max = +(ug(W, 'ai', 'max') || '1000');
	/* domanda in corso (dell'app o del bot, 2.62: id in run): blocco di meno di 150 s con il suo lavoro vivo (5 s di
	   margine per l'avvio) */
	let E = aierr(pid), lk = stat(AID + '/lock'), LS = lnstate(now);
	let busy = lk != null && now - lk.mtime < 150 && (now - lk.mtime < 5 || aialive(trim(readfile(AID + '/run') ?? '') || (rjs(AID + '/ans.json')?.id ?? 'x')));
	let off = LS.fresh && LS.ok == false && !(P?.local), wait = aiwait(P, now, E), nm = P ? P.name : '', st, it, en, wi, we, sev;
	if (!on) { st = 'off'; sev = 'off'; it = 'Spento'; en = 'Off'; wi = 'Accendilo per fare domande al router in parole semplici.'; we = 'Turn it on to ask the router in plain words.'; }
	else if (!has('/usr/bin/curl')) { st = 'nocurl'; sev = 'bad'; it = 'Manca Un Programma'; en = 'A Program Is Missing'; wi = 'Manca Un Programma: Installalo Da Software.'; we = 'A Program Is Missing: Install It From Software.'; }
	else if (!P || (P.key && !P.has) || !P.ok || !length(P.url) || !length(P.model)) { st = 'setup'; sev = 'info'; it = 'Da Configurare'; en = 'To Set Up'; wi = 'Scegli il fornitore e incolla la chiave.'; we = 'Choose the provider and paste the key.'; }
	else if (busy) { st = 'busy'; sev = 'info'; it = 'Sta Scrivendo'; en = 'Writing'; wi = nm + L(' sta scrivendo la risposta.', ' is writing the answer.'); we = wi; }
	else if (off) { st = 'offline'; sev = 'warn'; it = 'Senza Internet'; en = 'No Internet'; wi = 'Internet non c\'è: rispondo con i controlli del router, senza IA.'; we = 'There is no internet: I answer with the router checks, without AI.'; }
	else if (E?.kind == 'key' && E.prov == pid) { st = 'key'; sev = 'bad'; it = 'Chiave Da Rivedere'; en = 'Check The Key'; wi = 'La chiave non è valida o è scaduta: cambiala in Fornitore E Chiave.'; we = 'The key is not valid or has expired: change it in Provider And Key.'; }
	else if (D.n >= max) { st = 'limit'; sev = 'warn'; it = 'Limite Raggiunto'; en = 'Limit Reached'; wi = 'Hai fatto ' + D.n + ' domande oggi: il limite riparte a mezzanotte.'; we = 'You asked ' + D.n + ' questions today: the limit restarts at midnight.'; }
	else if (E?.kind == 'limit' && E.prov == pid && now < +(E.until ?? 0)) { st = 'limit'; sev = 'warn'; it = 'Limite Raggiunto'; en = 'Limit Reached'; wi = nm + ' ha finito le domande gratuite per oggi.'; we = nm + ' has run out of free questions for today.'; }
	else if (wait > 10) { st = 'wait'; sev = 'warn'; it = nm + ' È Occupato'; en = nm + ' Is Busy'; wi = nm + ' È Occupato, Riprova Tra ' + wait + ' Secondi'; we = nm + ' Is Busy, Try Again In ' + wait + ' Seconds'; }
	else { st = 'ready'; sev = 'ok'; it = 'Pronto'; en = 'Ready'; wi = nm + ' · ' + D.n + ' di ' + max + ' oggi'; we = nm + ' · ' + D.n + ' of ' + max + ' today'; }
	/* altro fornitore pronto (chiave e consenso) da proporre con il limite o con il fornitore occupato */
	let alt = null;
	if (st == 'limit' || st == 'wait' || st == 'key') for (let k in AIPROV) if (!alt && aiready(W, k, pid) && !aiheld(k, now)) alt = k;
	/* 2.64: fornitore di riserva (backup) e pfail = limit|wait|key quando lo stato viene dal fornitore attivo (non dal
	   limite di domande dell'utente): allora aiask manda la domanda alla riserva */
	let pf = st == 'key' || st == 'wait' || (st == 'limit' && D.n < max) ? st : null;
	return { state: st, text: L(it, en), why: L(wi, we), sev: sev, on: on, prov: length(pid) ? pid : null, name: nm, model: P ? P.model : '', local: !!P?.local,
		offline: off, since: off ? LS.since : null, wait: wait, alt: alt, backup: aibak(W, pid), pfail: pf, today: { n: D.n, max: max, c: D.c, tok: D.tok } };
}
/* id di 8 cifre esadecimali (richieste, lavori, proposte) */
function aiid() { let r = readfile('/dev/urandom', 4) ?? '', n = ''; for (let i = 0; i < 4; i++) n += sprintf('%02x', ord(r, i) ?? (time() + i * 7) % 256); return n; }
/* cartella dei lavori (0700) e pulizia dei lavori più vecchi di 10 minuti */
function aidir() {
	mkdir(AID, 448);
	let now = time();
	for (let f in lsdir(AID) ?? []) if (match(f, /^(job|p|do)-[0-9a-f]{8}\.json$/)) { let s = stat(AID + '/' + f); if (s && now - s.mtime > 600) unlink(AID + '/' + f); }
}
/* cervello sempre acceso (2.64): servizio wrtfreedom-ai (ai.uc serve, procd, solo con l'Assistente acceso). Pid del servizio
   vivo (svc.pid, riga di comando con ai.uc serve) o '' */
function aisvcpid() {
	let p = trim(readfile(AID + '/svc.pid') ?? '');
	if (!match(p, /^[0-9]{1,10}$/)) return '';
	let c = readfile('/proc/' + p + '/cmdline') ?? '';
	return index(c, 'ai.uc') >= 0 && index(c, 'serve') >= 0 ? p : '';
}
/* lavoro passato al servizio libero: blocco svc.run preso qui (mkdir), job {k, id}, evento ubus wrtfreedom.ai (non aspetta
   niente: rpcd mai fermo); il servizio scrive go quando lo prende e hb come segno di vita. false = occupato, assente o
   lavoro non suo (do e undo: processi a parte) → processo come prima. Servizio bloccato (lavoro non preso in 10 s o senza
   segno di vita da 240 s) = fermato, procd lo riavvia */
const AISVK = { ask: true, pre: true, load: true, mem: true, test: true, models: true, scan: true, tip: true };
function aisvc(kind, id) {
	let p = AISVK[kind] ? aisvcpid() : '', R = AID + '/svc.run';
	if (!length(p)) return false;
	let s = stat(R), now = time();
	if (s) {
		let h = stat(R + '/hb') ?? s;
		if (has(R + '/go') ? now - h.mtime < 240 : now - s.mtime < 10) return false;
		sh('kill -9 ' + p + ' 2>/dev/null');
		for (let f in [ 'job', 'go', 'hb' ]) unlink(R + '/' + f);
		rmdir(R);
		return false;
	}
	if (!mkdir(R, 448)) return false;
	wjs(R + '/job', { k: kind, id: id });
	sh('ubus send wrtfreedom.ai ' + q(sprintf('%J', { k: kind })) + ' </dev/null >/dev/null 2>&1');
	return true;
}
/* servizio acceso (enable, start) o fermato (stop, disable) con l'Assistente, in sottofondo (procd, mai rpcd) */
function aisvcset(on) {
	if (!has('/etc/init.d/wrtfreedom-ai')) return;
	let I = '/etc/init.d/wrtfreedom-ai ';
	sh('( ' + I + (on ? 'enable; ' + I + 'start' : 'stop; ' + I + 'disable') + ' ) </dev/null >/dev/null 2>&1 &');
}
/* lancio staccato da rpcd (nuova sessione: sopravvive al riavvio di rpcd), con il pid in /tmp/wf-ai/pid-<id>; 2.64: prima al
   servizio sempre acceso, se libero */
function aibg(kind, id) {
	if (aisvc(kind, id)) return;
	let a = AIUC + ' ' + kind + ' ' + id, pf = AID + '/pid-' + id;
	if (has('/sbin/start-stop-daemon')) sh('start-stop-daemon -S -b -m -p ' + pf + ' -x /usr/bin/ucode -- ' + a + ' </dev/null >/dev/null 2>&1');
	else if (has('/usr/bin/setsid') || has('/bin/setsid')) sh('setsid ucode ' + a + ' </dev/null >/dev/null 2>&1 &');
	else sh('( ucode ' + a + ' ) </dev/null >/dev/null 2>&1 &');
}
/* lavoro lungo: parametri in p-<id>.json, esito atteso in job-<id>.json, risposta subito {id} */
function aijob(kind, P) {
	aidir();
	let id = aiid(), now = time();
	wjs(AID + '/p-' + id + '.json', { ...(P ?? {}), lang: ug('wrtfreedom', 'ui', 'lang') == 'en' ? 'en' : 'it' });
	wjs(AID + '/job-' + id + '.json', { id: id, kind: kind, done: false, t: now });
	aibg(kind, id);
	return { id: id };
}
/* ferma il lavoro di una domanda (gruppo di processi: anche curl) e toglie i file delle intestazioni rimasti */
function aikill(id) {
	let p = trim(readfile(AID + '/pid-' + id) ?? '');
	/* 2.64: domanda fatta dal servizio sempre acceso = servizio fermato subito (procd lo riavvia) con tutti i discendenti
	   (anche i curl dentro «sh -c»: il servizio non ha un gruppo di processi suo) */
	if (match(p, /^[0-9]{1,10}$/) && has('/proc/' + p)) sh(p == aisvcpid() ? 'kill -9 ' + join(' ', [ ...pdesc(p), p ]) + ' 2>/dev/null' : 'kill -TERM -' + p + ' ' + p + ' 2>/dev/null');
	unlink(AID + '/pid-' + id);
	/* solo i file di questa domanda (2.62): un altro lavoro in corso tiene i suoi */
	if (match(id, /^[0-9a-f]{8}$/)) for (let x in [ 'h', 'b', 'r', 'tk', 'tb' ]) unlink(AID + '/' + x + '-' + id);
}
/* azione dell'IA confermata o annullata (2.64): letture anticipate tolte (pre.json) e segno act.t, così il servizio scarta le
   letture in memoria più vecchie (le rifà); ai.uc lo riscrive a azione finita */
function aiact() { unlink(AID + '/pre.json'); writefile(AID + '/act.t', '' + time()); }
/* riga nella chat in corso (nota del router: proposta rifiutata, comando fatto o annullato) */
function ainote(t, x, tg) {
	let f = AID + (tg != null ? '/tg-' + tg + '.json' : '/chat.json'), C = rjs(f);
	if (!C) return;
	push(C.msgs, { r: 'n', t: t, ts: time(), ...(x ?? {}) });
	wjs(f, C);
}
/* domande al giorno con il ragionamento più profondo (2.63, aistate.deep.max; lo legge anche ai.uc) */
const AIDEEPMAX = 20;
/* Cosa Può Fare L'IA (2.63): una sola regola (aican) per pagina, bot e IA (ai.uc la legge da aistate.can). Per gruppo
   [chiave, nome, name, cosa serve]: rd = letture (wrtfreedom.ai.rdno = spente), act = azioni più rule e remember (actno =
   spente), hi = Rischio Alto (wrtfreedom.ai.hi = accese, spente di serie) con il rischio per la finestra di avviso. Una
   chiave nuova delle versioni dopo nasce accesa (rd, act) o spenta (hi); le azioni nascoste (inversi) seguono la madre.
   2.64 B5: in rd e act 'off' al quinto posto = spenta di serie (wrtfreedom.ai.rdon, acton = quelle accese dall'utente) */
const AICAN = {
	rd: [ [ 'casa', 'Stato Della Casa', 'Home Status' ], [ 'health', 'Salute Del Router', 'Router Health' ], [ 'healthspace', 'Spazio', 'Storage' ],
		[ 'clients', 'Dispositivi', 'Devices' ], [ 'presence', 'Presenza', 'Presence' ], [ 'person', 'Persone', 'People' ], [ 'pause', 'Pausa Per Tutti', 'Pause For Everyone' ],
		[ 'wifi', 'Wi-Fi', 'Wi-Fi' ], [ 'wifiguest', 'Rete Ospiti', 'Guest Network', 'guest' ], [ 'vpnout', 'Servizio VPN', 'VPN Service' ], [ 'wgstats', 'VPN Per Fuori Casa', 'Away From Home VPN' ],
		[ 'fo', 'Linea Di Riserva', 'Backup Line' ], [ 'usage', 'Consumo Della SIM', 'SIM Usage' ], [ 'devuse', 'Consumo Dei Dispositivi', 'Device Usage' ],
		[ 'pubip', 'IP Pubblico', 'Public IP' ], [ 'line', 'Dettagli Della Linea', 'Line Details', 'modem' ], [ 'sighist', 'Storico Del Segnale', 'Signal History', 'modem' ],
		[ 'cells', 'Celle Vicine', 'Nearby Cells', 'modem' ], [ 'simslot', 'Seconda SIM', 'Second SIM', 'modem' ], [ 'sms', 'SMS', 'SMS', 'modem' ],
		[ 'credit', 'Credito e Codici', 'Credit and Codes', 'modem' ], [ 'speed', 'Ultimo Test Di Velocità', 'Last Speed Test' ], [ 'nettest', 'Ultima Prova Di Rete', 'Last Network Check' ],
		[ 'adgstate', 'AdGuard', 'AdGuard', 'adg' ], [ 'adgtop', 'Chi Usa Il DNS', 'Who Uses DNS', 'adg' ], [ 'fwstat', 'Firewall', 'Firewall' ],
		[ 'fwdhome', 'Porte Aperte e Indirizzo Di Casa', 'Open Ports and Home Address' ], [ 'ports', 'Porte Del Router', 'Router Ports' ],
		[ 'shaper', 'Orari e Velocità', 'Schedules and Speed' ], [ 'sqmstat', 'Controllo Della Linea', 'Line Control', 'sqm' ], [ 'cron', 'Pianificazioni', 'Schedules' ],
		[ 'evlist', 'Eventi', 'Events' ], [ 'evget', 'Azioni Degli Eventi', 'Event Actions' ], [ 'logsum', 'Registro', 'Log' ], [ 'healthhist', 'Storico 24 Ore', '24-Hour History' ],
		[ 'services', 'Servizi Del Router', 'Router Services' ], [ 'soft', 'Aggiornamenti e Pacchetti', 'Updates and Packages' ], [ 'fwupd', 'Aggiornamento Sistema', 'System Update' ],
		/* 2.64 Vedere Tutto (ai.uc RD): accese di serie, nessuna con i siti visitati */
		[ 'dev', 'Scheda Del Dispositivo', 'Device Card' ], [ 'wifinets', 'Reti e Radio Wi-Fi', 'Wi-Fi Networks and Radios' ], [ 'nets', 'Reti Del Router', 'Router Networks' ],
		[ 'homenet', 'Rete Di Casa', 'Home Network' ], [ 'fwrules', 'Regole Del Firewall', 'Firewall Rules' ], [ 'sqmhealth', 'Controllo Di Salute', 'Health Check', 'sqm' ],
		[ 'tg', 'Bot Telegram', 'Telegram Bot' ], [ 'cronlog', 'Registro Delle Esecuzioni', 'Run Log' ], [ 'wginfo', 'Impostazioni VPN Per Fuori Casa', 'Away From Home VPN Settings' ],
		[ 'log', 'Righe Del Registro', 'Log Lines' ], [ 'healthtop', 'Cosa Pesa Di Più', 'What Weighs Most' ], [ 'healthboot', 'Perché Si È Riavviato', 'Why It Restarted' ],
		[ 'adglevel', 'Livelli Di Protezione', 'Protection Levels', 'adg' ], [ 'months', 'Mesi Precedenti', 'Previous Months' ], [ 'access', 'Accesso Al Router', 'Router Access' ],
		/* 2.64 Wi-Fi per rete e radio */
		[ 'channels', 'Analisi Canali', 'Channel Analysis' ],
		/* 2.64 B4: Assistente IA (fornitore, domande di oggi, Memoria; mai chiavi) */
		[ 'ai', 'Assistente IA', 'AI Assistant' ],
		/* 2.64 B5: AdGuard nel dettaglio (liste, regole, servizi, protezioni, server DNS); i siti chiesti da un dispositivo spenta di serie */
		[ 'adglists', 'Liste e Regole Di AdGuard', 'AdGuard Lists and Rules', 'adg' ], [ 'adglog', 'Siti Chiesti Da Un Dispositivo', 'Sites Asked By A Device', 'adg', 'off' ],
		/* 2.64 B6: Internet e Modem */
		[ 'bands', 'Bande Del Modem', 'Modem Bands', 'modem' ], [ 'watchdog', 'Ripristino Automatico', 'Automatic Recovery' ],
		[ 'alerts', 'Allerte Pubbliche', 'Public Alerts', 'modem' ], [ 'sigfast', 'Trova Il Punto Migliore', 'Find The Best Spot', 'modem' ],
		/* 2.64 B7: spie del router una per una */
		[ 'leds', 'Spie Del Router', 'Router Lights', 'leds' ] ],
	act: [ [ 'wifi_on', 'Accendi Il Wi-Fi', 'Turn Wi-Fi On' ], [ 'wifi_off', 'Spegni Il Wi-Fi', 'Turn Wi-Fi Off' ], [ 'wifi_restart', 'Riavvia Il Wi-Fi', 'Restart Wi-Fi' ],
		[ 'guest_on', 'Accendi La Rete Ospiti', 'Turn Guest Network On', 'guest' ], [ 'guest_off', 'Spegni La Rete Ospiti', 'Turn Guest Network Off', 'guest' ],
		[ 'pause_all', 'Pausa Per Tutti', 'Pause For Everyone' ], [ 'pause_end', 'Togli La Pausa', 'End The Pause' ], [ 'pause_person', 'Pausa Di Una Persona', 'Pause A Person' ],
		[ 'block', 'Blocca Un Dispositivo', 'Block A Device' ], [ 'unblock', 'Sblocca Un Dispositivo', 'Unblock A Device' ], [ 'kick', 'Stacca Dal Wi-Fi', 'Disconnect From Wi-Fi' ],
		[ 'limit', 'Limita La Velocità', 'Limit The Speed' ], [ 'unlimit', 'Togli Il Limite', 'Remove The Limit' ], [ 'slow', 'Rallenta Per Un Po\'', 'Slow Down For A While' ],
		[ 'band', 'Fasce Di Velocità', 'Speed Time Slots' ], [ 'rename', 'Rinomina Un Dispositivo', 'Rename A Device' ], [ 'wol', 'Accendi Un Dispositivo', 'Power On A Device', 'wol' ],
		[ 'vpn_on', 'Accendi Il Servizio VPN', 'Turn VPN Service On', 'vpnsvc' ], [ 'vpn_off', 'Spegni Il Servizio VPN', 'Turn VPN Service Off', 'vpnsvc' ],
		[ 'vpn_next', 'Cambia Server Del Servizio VPN', 'Change VPN Service Server', 'vpnsvc' ], [ 'vpn_place', 'Cambia Paese Del Servizio VPN', 'Change VPN Service Country', 'vpnsvc' ],
		[ 'adg_on', 'Accendi AdGuard', 'Turn AdGuard On', 'adg' ], [ 'adg_off', 'Spegni AdGuard', 'Turn AdGuard Off', 'adg' ],
		[ 'sqm_on', 'Accendi Il Controllo Della Linea', 'Turn Line Control On', 'sqm' ], [ 'sqm_off', 'Spegni Il Controllo Della Linea', 'Turn Line Control Off', 'sqm' ],
		[ 'fo_on', 'Accendi La Linea Di Riserva', 'Turn Backup Line On', 'fo' ], [ 'fo_off', 'Spegni La Linea Di Riserva', 'Turn Backup Line Off', 'fo' ],
		[ 'night_on', 'Accendi Spie Di Notte', 'Turn Night Lights On', 'leds' ], [ 'night_off', 'Spegni Spie Di Notte', 'Turn Night Lights Off', 'leds' ],
		[ 'speed', 'Test Di Velocità', 'Speed Test' ], [ 'nettest', 'Prova Di Rete', 'Network Check' ], [ 'wan_reconnect', 'Riconnetti La Linea', 'Reconnect The Line' ],
		[ 'modem_restart', 'Riavvia Il Modem', 'Restart The Modem', 'modem' ], [ 'svc_restart', 'Riavvia Un Servizio', 'Restart A Service' ], [ 'reboot', 'Riavvia Il Router', 'Restart The Router' ],
		[ 'backup_now', 'Copia Al Bot', 'Backup To The Bot', 'tg' ], [ 'sms_send', 'Manda Un SMS', 'Send A Text', 'modem' ],
		/* 2.64 Dispositivi e Persone, uno per uno (ai.uc ACTS): accese di serie; le regole dell'utente si accendono e spengono, mai si cancellano */
		[ 'fixed_ip', 'Indirizzo Fisso', 'Fixed Address' ], [ 'priority', 'Priorità Di Un Dispositivo', 'Device Priority' ],
		[ 'adg_skip', 'Escludi Da AdGuard', 'Exclude From AdGuard', 'adg' ], [ 'notify_dev', 'Avvisami Quando Si Collega', 'Tell Me When It Connects' ],
		[ 'quota', 'Quota Di Dati', 'Data Quota' ], [ 'dev_type', 'Tipo Del Dispositivo', 'Device Type' ], [ 'known', 'Lo Conosco', 'I Know It' ],
		[ 'steer', 'Sposta Sul 5 GHz', 'Move To 5 GHz' ], [ 'band_on', 'Riaccendi Una Fascia', 'Turn A Time Slot Back On' ],
		[ 'band_off', 'Sospendi Una Fascia', 'Suspend A Time Slot' ], [ 'slow_all', 'Sospendi Le Fasce Rallenta', 'Suspend Slow Time Slots' ],
		[ 'person_add', 'Nuova Persona', 'New Person' ], [ 'person_dev', 'Dispositivi Di Una Persona', 'Devices Of A Person' ],
		[ 'person_time', 'Tempo Con Traffico', 'Time With Traffic' ], [ 'person_slot', 'Fasce Senza Internet', 'Offline Time Slots' ],
		[ 'adg_level', 'Livello Di AdGuard', 'AdGuard Level', 'adg' ],
		/* 2.64 Wi-Fi per rete e radio (ai.uc ACTS): quelle che possono staccare dal Wi-Fi tornano da sole dopo 2 minuti senza conferma */
		[ 'net_on', 'Accendi Reti e Radio', 'Turn Networks and Radios On' ], [ 'net_off', 'Spegni Reti e Radio', 'Turn Networks and Radios Off' ],
		[ 'net_set', 'Impostazioni Di Una Rete', 'Network Settings' ], [ 'wifi_channel', 'Canale Del Wi-Fi', 'Wi-Fi Channel' ],
		[ 'wifi_scan', 'Rianalizza I Canali', 'Scan The Channels' ], [ 'auto_channel', 'Canale Automatico', 'Automatic Channel' ],
		[ 'wifi_power', 'Potenza Del Wi-Fi', 'Wi-Fi Power' ], [ 'guest_limit', 'Limite Della Rete Ospiti', 'Guest Network Limit', 'guest' ],
		/* 2.64 Pianificazioni, Eventi e IA (ai.uc ACTS): le regole dell'utente si accendono, si spengono, si provano e si cambiano,
		   mai si cancellano (rule_del solo per quelle dell'IA) */
		[ 'cron_on', 'Accendi e Spegni Pianificazioni', 'Turn Schedules On and Off' ], [ 'cron_run', 'Esegui Ora Una Pianificazione', 'Run A Schedule Now' ],
		[ 'cron_time', 'Orario Di Una Pianificazione', 'Schedule Time' ], [ 'rule_on', 'Accendi e Spegni Azioni Degli Eventi', 'Turn Event Actions On and Off' ],
		[ 'rule_test', 'Prova Un\'Azione Degli Eventi', 'Test An Event Action' ], [ 'rule_edit', 'Cambia Un\'Azione Degli Eventi', 'Change An Event Action' ],
		[ 'quiet', 'Ore Silenziose e Avvisi Raggruppati', 'Quiet Hours and Grouped Alerts', 'tg' ], [ 'notify_cat', 'Avvisi Per Categoria', 'Alerts By Category', 'tg' ],
		[ 'events_keep', 'Conserva Dopo Il Riavvio', 'Keep After Restart' ], [ 'forget_fact', 'Dimentica Un Fatto', 'Forget A Fact' ],
		[ 'undo', 'Annulla L\'Ultima Azione', 'Undo The Last Action' ], [ 'rule_del', 'Togli Una Regola Dell\'IA', 'Remove An AI Rule' ],
		/* 2.64 B5 AdGuard, DNS e Firewall (ai.uc ACTS): regole e porte dell'utente si accendono e si spengono, mai si cancellano */
		[ 'list_on', 'Accendi e Spegni Le Liste', 'Turn Lists On and Off', 'adg' ], [ 'lists_update', 'Aggiorna Le Liste', 'Update The Lists', 'adg' ],
		[ 'site_block', 'Blocca Un Sito', 'Block A Site', 'adg' ], [ 'site_allow', 'Consenti Un Sito', 'Allow A Site', 'adg' ],
		[ 'service_block', 'Blocca Un Servizio', 'Block A Service', 'adg' ], [ 'adg_safe', 'Protezioni Di AdGuard', 'AdGuard Protections', 'adg' ],
		[ 'dns_backup', 'DNS Di Riserva', 'Backup DNS', 'adg' ], [ 'dns_flush', 'Svuota La Cache DNS', 'Clear The DNS Cache' ],
		[ 'dns_force', 'DNS Obbligatorio', 'Forced DNS' ], [ 'home_name', 'Nomi Di Casa', 'Home Names' ],
		[ 'weekly_now', 'Riepilogo Settimanale Adesso', 'Weekly Summary Now' ], [ 'port_off', 'Spegni Un Inoltro', 'Turn A Forward Off' ],
		[ 'upnp_off', 'Spegni Le Porte Automatiche', 'Turn Automatic Ports Off', 'upnp' ],
		/* 2.64 B6 Internet e Modem (ai.uc ACTS): mai firmware del modem né PIN, PUK, IMEI o ICCID */
		[ 'usage_set', 'Giga e Rinnovo', 'Data and Renewal' ], [ 'usage_slow', 'Rallenta Quando Finiscono', 'Slow Down When Used Up' ],
		[ 'usage_fast', 'Togli Il Limite', 'Remove The Limit' ], [ 'credit_check', 'Chiedi Il Credito', 'Ask The Credit', 'modem' ],
		[ 'watchdog', 'Ripristino Automatico', 'Automatic Recovery', 'wd' ], [ 'cells_scan', 'Scansione Completa', 'Full Scan', 'modem' ],
		[ 'signal_fast', 'Trova Il Punto Migliore', 'Find The Best Spot', 'modem' ], [ 'sim_auto', 'Cambio Automatico Della SIM', 'Automatic SIM Switch', 'sim2' ],
		[ 'alerts_on', 'Allerte Pubbliche', 'Public Alerts', 'modem' ], [ 'modem_report', 'Rapporto Modem Al Bot', 'Modem Report To The Bot', 'tg' ],
		/* 2.64 B7 Manutenzione, Reti e Sistema (ai.uc ACTS): spegnere una rete torna da solo dopo 2 minuti senza conferma, la Rete
		   Di Casa non si spegne; i servizi vitali solo con Servizi Vitali (Rischio Alto), mai i 5g-* dell'utente */
		[ 'diag', 'Diagnostica', 'Diagnostics' ], [ 'speed_stop', 'Annulla Il Test Di Velocità', 'Cancel The Speed Test' ],
		[ 'svc_start', 'Avvia Un Servizio', 'Start A Service' ], [ 'svc_stop', 'Ferma Un Servizio', 'Stop A Service' ],
		[ 'svc_boot', 'Avvio Automatico Dei Servizi', 'Service Autostart' ], [ 'net_reload', 'Riavvia Tutte Le Reti', 'Restart All Networks' ],
		[ 'net_restart', 'Riavvia Una Rete', 'Restart A Network' ], [ 'net_down', 'Spegni Una Rete', 'Turn A Network Off' ],
		[ 'net_up', 'Accendi Una Rete', 'Turn A Network On' ], [ 'led', 'Spie Una Per Una', 'Lights One By One', 'leds' ],
		[ 'time_sync', 'Sincronizza L\'Ora', 'Sync The Time' ], [ 'mem_free', 'Libera La Memoria', 'Free The Memory' ],
		[ 'router_name', 'Nome Del Router', 'Router Name' ], [ 'time_zone', 'Fuso Orario', 'Time Zone' ], [ 'time_auto', 'Ora Automatica', 'Automatic Time' ],
		[ 'health_alert', 'Avvisi Di Salute', 'Health Alerts' ], [ 'upd_check', 'Controlla Gli Aggiornamenti', 'Check For Updates' ],
		/* 2.64 B8 Servizi, Telegram e VPN Per Fuori Casa (ai.uc ACTS): mai token, chiavi, QR o password; spegnere la VPN torna da
		   sola dopo 2 minuti senza conferma; i Comandi Tuoi del bot restano fuori */
		[ 'sqm_mode', 'Modalità Del Controllo Della Linea', 'Line Control Mode', 'sqm' ], [ 'sqm_limit', 'Limiti Del Controllo Della Linea', 'Line Control Limits', 'sqm' ],
		[ 'sqm_test', 'Prova Prima e Dopo', 'Before and After Test', 'sqm' ], [ 'sqm_profile', 'Profili Per Orario', 'Scheduled Profiles', 'sqm' ],
		[ 'sqm_profile_now', 'Applica Un Profilo Adesso', 'Apply A Profile Now', 'sqm' ], [ 'ddns_now', 'Aggiorna Ora Un Nome', 'Update A Name Now', 'ddns' ],
		[ 'ddns_on', 'Accendi e Spegni Un Nome', 'Turn A Name On and Off', 'ddns' ], [ 'cert_renew', 'Rinnova I Certificati', 'Renew The Certificates', 'acme' ],
		[ 'tg_send', 'Messaggio Al Bot', 'Message To The Bot', 'tg' ], [ 'tg_cmds', 'Rispondi Ai Comandi', 'Answer Commands', 'tg' ],
		[ 'tg_preset', 'Comandi Pronti', 'Ready Commands', 'tg' ], [ 'wg_on', 'Accendi La VPN Per Fuori Casa', 'Turn Away From Home VPN On', 'wg' ],
		[ 'wg_off', 'Spegni La VPN Per Fuori Casa', 'Turn Away From Home VPN Off', 'wg' ], [ 'wg_pause', 'Pausa Di Un Dispositivo VPN', 'Pause A VPN Device', 'wg' ],
		[ 'wg_alert', 'Avvisami Quando Entra', 'Tell Me When It Joins', 'wg' ], [ 'wg_rename', 'Rinomina Un Dispositivo VPN', 'Rename A VPN Device', 'wg' ],
		[ 'wg_expire', 'Scadenza Di Un Dispositivo VPN', 'VPN Device Expiry', 'wg' ], [ 'wg_probe', 'Prova Da Fuori Casa', 'Away From Home Test', 'wg' ],
		[ 'rule', 'Regole Dette A Parole', 'Rules In Plain Words' ], [ 'remember', 'Salva In Memoria', 'Save To Memory' ] ],
	hi: [ [ 'sim_switch', 'Cambio SIM', 'SIM Switch', 'sim2', 'Il modem si riavvia sull\'altra SIM: internet manca per qualche minuto; se la linea non torna il router rimette la SIM di prima.', 'The modem restarts on the other SIM: no internet for a few minutes; if the line does not come back the router puts the previous SIM back.' ],
		[ 'cell_lock', 'Blocco Cella', 'Cell Lock', 'lock', 'Il modem resta su una cella sola: se il segnale peggiora internet rallenta; senza internet per 3 minuti il router toglie il blocco da solo.', 'The modem stays on one cell: if the signal gets worse the internet slows down; after 3 minutes without internet the router removes the lock by itself.' ],
		[ 'apn_set', 'Profilo Dati', 'Data Profile', 'modem', 'Un profilo dati sbagliato toglie internet: se non confermi entro 2 minuti il router rimette quello di prima.', 'A wrong data profile cuts the internet: if you do not confirm within 2 minutes the router puts the previous one back.' ],
		[ 'port_open', 'Apri Una Porta', 'Open A Port', '', 'Un dispositivo di casa diventa raggiungibile da Internet: aprila solo per programmi che conosci.', 'A home device becomes reachable from the Internet: open it only for programs you know.' ],
		[ 'upgrade', 'Aggiornamenti', 'Updates', '', 'Aggiorna pacchetti e WrtFreedom con la copia prima e il ritorno; mai il firmware del modem né di OpenWrt.', 'Updates packages and WrtFreedom with a backup first and rollback; never the modem or OpenWrt firmware.' ],
		[ 'wps', 'Collega Con Il Tasto', 'Connect With The Button', '', 'Per 2 minuti qualsiasi dispositivo vicino al router entra nella rete premendo il suo tasto WPS, senza password.', 'For 2 minutes any device near the router joins the network by pressing its WPS button, without a password.' ],
		/* 2.64 B5 */
		[ 'adg_direct', 'AdGuard Risponde Ai Dispositivi', 'AdGuard Answers Devices', 'adg', 'Per qualche secondo i siti non si aprono; se non confermi entro 2 minuti il router torna com\'era.', 'For a few seconds sites do not open; if you do not confirm within 2 minutes the router goes back.' ],
		[ 'dns_set', 'Server DNS', 'DNS Servers', 'adg', 'Un server DNS che non risponde lascia la casa senza siti: il router lo prova prima e, se non confermi entro 2 minuti, rimette quelli di prima.', 'A DNS server that does not answer leaves the home without sites: the router tests it first and, if you do not confirm within 2 minutes, puts the previous ones back.' ],
		[ 'port_on', 'Riaccendi Un Inoltro', 'Turn A Forward Back On', '', 'Un dispositivo di casa torna raggiungibile da Internet: se non confermi entro 2 minuti l\'inoltro si rispegne.', 'A home device becomes reachable from the Internet again: if you do not confirm within 2 minutes the forward turns off again.' ],
		[ 'upnp_on', 'Accendi Le Porte Automatiche', 'Turn Automatic Ports On', 'upnp', 'I dispositivi di casa aprono da soli porte verso Internet (giochi, console, chiamate): accendile solo se servono.', 'Home devices open ports to the Internet by themselves (games, consoles, calls): turn them on only if needed.' ],
		/* 2.64 B6: possono togliere la linea (bande, 5G, Roaming) o costare (codici) */
		[ 'band_set', 'Bande Del Modem', 'Modem Bands', 'modem', 'Con bande sbagliate il modem non trova la rete e internet cade: se in 3 minuti non torna, il router rimette le bande di prima.', 'With wrong bands the modem finds no network and the internet drops: if it is not back within 3 minutes, the router puts the previous bands back.' ],
		[ 'nr_mode', 'Modalità 5G', '5G Mode', 'modem', 'Con il solo 5G SA il modem può restare senza rete: se in 3 minuti internet non torna, il router rimette la modalità di prima.', 'With 5G SA only the modem may stay without network: if the internet is not back within 3 minutes, the router puts the previous mode back.' ],
		[ 'ussd_code', 'Codici All\'Operatore', 'Codes To The Provider', 'modem', 'Un codice può attivare servizi o offerte a pagamento: l\'IA manda solo quelli scritti da te nella domanda.', 'A code can turn on paid services or offers: the AI sends only the ones you write in the question.' ],
		[ 'roaming', 'Roaming Dati', 'Data Roaming', 'modem', 'All\'estero l\'operatore può far pagare; spento, all\'estero internet non va. Se non confermi entro 2 minuti il router torna com\'era.', 'Abroad the provider may charge; off, the internet does not work abroad. If you do not confirm within 2 minutes the router goes back.' ],
		/* 2.64 B7: fermare o togliere dall'avvio un servizio vitale (accesso, pagine, rete, firewall, DNS) */
		[ 'svc_vital', 'Servizi Vitali', 'Vital Services', '', 'Fermare l\'accesso, la rete, il firewall, il DNS o la linea mobile può lasciarti fuori dal router o senza internet: se non confermi entro 2 minuti il servizio torna com\'era.', 'Stopping access, network, firewall, DNS or the mobile line can lock you out of the router or leave you offline: if you do not confirm within 2 minutes the service goes back.' ],
		/* 2.64 B8: una porta in più aperta verso la VPN Per Fuori Casa */
		[ 'wg_alt', 'Porta Alternativa', 'Alternative Port', 'wg', 'Il router apre una porta in più da Internet (di serie la 443) verso la VPN Per Fuori Casa: se non confermi entro 2 minuti torna com\'era.', 'The router opens one more port from the Internet (443 by default) to the Away From Home VPN: if you do not confirm within 2 minutes it goes back.' ] ]
};
const AINEED = {
	modem: [ 'Questo router non ha un modem', 'This router has no modem' ], sqm: [ 'Controllo Della Linea non installato', 'Line Control not installed' ],
	tg: [ 'Bot Telegram non collegato', 'Telegram bot not connected' ], fo: [ 'Linea Di Riserva non configurata', 'Backup Line not set up' ],
	vpnsvc: [ 'Servizio VPN senza collegamenti', 'VPN Service without connections' ], guest: [ 'Rete Ospiti non creata', 'Guest Network not created' ],
	adg: [ 'AdGuard non installato', 'AdGuard not installed' ], wol: [ 'Manca un programma: installalo da Software', 'A program is missing: install it from Software' ],
	leds: [ 'Questo router non ha spie', 'This router has no lights' ], sim2: [ 'Serve un modem con due SIM', 'A modem with two SIMs is needed' ],
	lock: [ 'Questo modem non permette il Blocco Cella', 'This modem does not allow Cell Lock' ], upnp: [ 'Porte Automatiche non installate', 'Automatic Ports not installed' ],
	wd: [ 'C\'è già il controllo della linea degli Strumenti Modem 5G: due controlli insieme si disturbano', 'The 5G Modem Tools already check the line: two checks together get in each other\'s way' ],
	wg: [ 'VPN Per Fuori Casa non configurata', 'Away From Home VPN not set up' ], ddns: [ 'Indirizzo Di Casa non configurato', 'Home Address not set up' ],
	acme: [ 'Certificati non installati', 'Certificates not installed' ]
};
/* 2.64 B6: c'è il 5g-watchdog di quectel-5g-tools (il controllo della linea è suo, come in wrtfreedom.init): una regola sola */
function wdtools() { return has('/etc/init.d/5g-watchdog'); }
/* 2.64 B8: c'è l'Indirizzo Di Casa (ddns-scripts con almeno un servizio): una regola sola, la usa anche croncaps */
function ddnshave(D) { D = D ?? ucfile('ddns'); return has('/etc/init.d/ddns') && length(filter(keys(D), (k) => D[k]['.type'] == 'service')) > 0; }
/* motivo per cui una voce non si può usare su questo router ('' = si può); C = letture già fatte in questa chiamata */
function aineed(k, C) {
	if (!length(k ?? '') || !AINEED[k]) return '';
	if (C.modem == null) C.modem = hasmodem();
	if ((k == 'sim2' || k == 'lock') && !C.modem) k = 'modem';
	if (C[k] == null) {
		let ok = true, W = C.W;
		if (k == 'modem') ok = C.modem;
		else if (k == 'sqm') ok = has('/etc/init.d/sqm');
		else if (k == 'tg') { let T = tgconf(); ok = length(T.token) > 0 && length(T.chat) > 0; }
		else if (k == 'fo') ok = length(ug(W, 'fo', 'main')) > 0 && length(ug(W, 'fo', 'backup')) > 0;
		else if (k == 'vpnsvc') ok = length(vpntuns(W)) > 0;
		else if (k == 'guest') ok = length(guestifs(ucfile('wireless'))) > 0;
		else if (k == 'adg') ok = has('/etc/init.d/adguardhome') || has('/etc/init.d/AdGuardHome');
		else if (k == 'wol') ok = has('/usr/bin/etherwake') || has('/usr/sbin/etherwake') || has('/usr/bin/ether-wake') || has('/usr/sbin/ether-wake');
		else if (k == 'leds') ok = length(lsdir('/sys/class/leds') ?? []) > 0;
		else if (k == 'sim2') { let S = rjs('/tmp/wf-sim.json'); ok = !(S && +(S.slots ?? 0) == 1); }
		else if (k == 'lock') ok = q5gtools() || !!(M.drv(M.id())?.lock);
		else if (k == 'upnp') ok = has('/etc/init.d/miniupnpd');
		else if (k == 'wd') ok = !wdtools();
		else if (k == 'wg') ok = wgiface(null) != null;
		else if (k == 'ddns') ok = ddnshave();
		else if (k == 'acme') ok = has('/etc/init.d/acme');
		C[k] = ok;
	}
	return C[k] ? '' : L(AINEED[k][0], AINEED[k][1]);
}
/* aistate.can: {rd, act, hi: [{id, name, on, why}], n {rd, act, hi} = quante si possono usare}; hi con risk */
function aican(W) {
	let C = { W: W }, out = { n: {} }, ws = (o) => filter(split(ug(W, 'ai', o), ' '), length), no = { rd: ws('rdno'), act: ws('actno') }, yes = { rd: ws('rdon'), act: ws('acton') }, hi = ws('hi');
	for (let g in [ 'rd', 'act', 'hi' ]) {
		out[g] = []; out.n[g] = 0;
		for (let x in AICAN[g]) {
			let on = g == 'hi' ? index(hi, x[0]) >= 0 : x[4] === 'off' ? index(yes[g], x[0]) >= 0 : index(no[g], x[0]) < 0, why = aineed(x[3], C), o = { id: x[0], name: L(x[1], x[2]), on: on, why: length(why) ? why : null };
			if (g == 'hi') o.risk = L(x[4], x[5]);
			if (on && !length(why)) out.n[g]++;
			push(out[g], o);
		}
	}
	return out;
}
/* velocità del modello attivo (2.64, una sola regola): media degli ultimi 20 tempi alla risposta finita (secondi) scritti da
   ai.uc in /tmp/wf-ai/speed.json (copia rara in /etc/wrtfreedom/ai-speed.json) → null | {avg, n, slow, low}; slow oltre
   12 s, e allora ai.uc abbassa il ragionamento per le domande non difficili (low, non per i modelli in casa) */
const AISLOW = 12;
function aispeed(P) {
	if (!P || !length(P.model ?? '')) return null;
	let S = rjs(AID + '/speed.json') ?? rjs(AIK + 'speed.json'), l = type(S) == 'object' ? S[P.id + '|' + P.model] : null, t = 0;
	if (type(l) != 'array' || !length(l)) return null;
	for (let x in l) t += +x;
	let avg = +sprintf('%.1f', t * 1.0 / length(l)), slow = avg > AISLOW;
	/* low: il ragionamento si abbassa davvero (i modelli in casa non ne hanno uno da regolare) */
	return { avg: avg, n: length(l), slow: slow, low: slow && !P.local };
}
/* aistate: stato unico più fornitori (frase del consenso), proposta in attesa, ultima azione da annullare, domanda */
function aiinfo(W) {
	W = W ?? ucfile('wrtfreedom');
	let S = aistat(W), now = time(), PV = [];
	for (let k in AIPROV) {
		let X = aiprov(W, k);
		push(PV, { id: k, name: X.name, fmt: X.fmt, key: X.key, has: X.has, ok: X.ok, local: X.local, cc: X.cc, where: X.where, model: X.model, def: AIPROV[k].model, url: k == 'openai' ? X.url : null });
	}
	let PD = rjs(AID + '/pend.json'), U = rjs(AID + '/undo.json'), A = rjs(AID + '/ans.json'), C = rjs(AID + '/chat.json'), MM = rjs('/etc/wrtfreedom/ai-mem.json');
	S.provs = PV;
	S.curl = has('/usr/bin/curl');
	S.pend = PD && now - +(PD.t ?? 0) < 600 ? { id: PD.id, text: PD.text, back: PD.back ?? 0, left: 600 - (now - +PD.t) } : null;
	S.undo = U ? { text: U.text, t: U.t } : null;
	S.ask = A ? { id: A.id, done: !!A.done, t: A.t } : null;
	S.chat = length(C?.msgs ?? []);
	S.mem = length(MM?.f ?? []);
	/* 2.61: Avvisi Spiegati Dall'IA; 2.62: Anche Nel Bot (bot collegato che risponde ai comandi), consiglio del Riepilogo */
	S.expl = { on: ug(W, 'ai', 'why') == '1', max: +(ug(W, 'ai', 'whymax') || '5'), n: aiday(now).w };
	let TG = tgconf();
	S.tg = ug(W, 'ai', 'tg') == '1';
	S.bot = length(TG.token) > 0 && length(TG.chat) > 0 && ug(W, 'tg', 'cmd') == '1';
	S.weekly = ug(W, 'ai', 'weekly') == '1';
	if (S.pend) S.pend.kind = PD.kind ?? 'act';
	/* 2.63: Cosa Può Fare L'IA (una sola regola), Memoria Automatica (accesa di serie; avviso per i fornitori con poche
	   domande al giorno), ragionamento più profondo (spento di serie, tetto al giorno), esito atteso di un'azione lunga
	   (watch: l'app rilegge la chat ogni 2 s solo finché c'è), Annulla dell'ultima memoria automatica (memundo) */
	let DY = aiday(now), WT = rjs(AID + '/watch.json'), MP = stat(AID + '/mem-prev.json');
	S.can = aican(W);
	S.mauto = { on: ug(W, 'ai', 'mauto') != '0', n: DY.m, warn: S.prov == 'gemini' ? L('Con Gemini ogni chat finita costa una domanda in più.', 'With Gemini every finished chat costs one more question.') : null };
	S.deep = { on: ug(W, 'ai', 'deep') == '1', n: DY.dp, max: AIDEEPMAX };
	S.watch = WT && now - +(WT.t ?? 0) < 900 && aialive('' + (WT.id ?? '')) ? { cmd: WT.cmd, name: WT.name ?? '', t: WT.t, left: WT.left ?? 0 } : null;
	S.memundo = MP ? { t: MP.mtime } : null;
	/* 2.64: velocità del modello attivo */
	S.speed = aispeed(S.prov ? aiprov(W, S.prov) : null);
	return S;
}
/* Cose Da Ricordare (2.62): /etc/wrtfreedom/ai-mem.json (0600) {v:1, f:[{id, t, text, macs}]}, scritto solo alle
   modifiche; {0} nel testo = il dispositivo di macs[0] (in vista il nome di adesso, all'IA la sigla). Mai segreti:
   password, PIN, codici, IBAN, numeri lunghi, email, chiavi (come il filtro di ai.uc) */
/* 2.64: voti dell'Assistente IA (aivote); WF_AIVOTE solo per il router finto delle prove, come WF_CFGDIR */
const AIMEM = '/etc/wrtfreedom/ai-mem.json', AIMEMMAX = 15, AIVOTE = getenv('WF_AIVOTE') ?? '/etc/wrtfreedom/ai-votes.json';
function aisecret(t) {
	return match(t, /(^|[^[:alpha:]])(pass|password|passwd|pwd|pin|puk|chiave|codice|code|passcode|token|iban|segreto|secret|cvv)([^[:alpha:]]|$)/i) != null ||
		match(t, /[0-9]{6}/) != null || match(t, /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2}/) != null || match(t, /[A-Za-z0-9+\/_-]{24}/) != null;
}
/* caratteri (non byte) di un testo UTF-8 */
function uclen(t) { let n = 0; for (let i = 0; i < length(t); i++) if ((ord(t, i) & 192) != 128) n++; return n; }
function aimemsave(M) {
	mkdir('/etc/wrtfreedom', 448);
	let f = AIMEM + '.t';
	if (writefile(f, sprintf('%J', M)) == null) { unlink(f); return false; }
	sh('chmod 600 ' + f);
	return rename(f, AIMEM);
}
/* spiegazioni degli Avvisi Spiegati Dall'IA (2.61, ai.uc why, /tmp/wf-ai/why.json) per evento: {«t|e»: frase}; una sola
   regola per evlist e snapshot (campo ai dello stesso evento) */
function evai() {
	let AW = {};
	for (let x in rjs(AID + '/why.json')?.list ?? []) if (type(x) == 'object' && type(x.ai) == 'string' && length(x.ai)) AW[x.t + '|' + x.e] = x.ai;
	return AW;
}

/* ---------- Rischio Alto (2.63) ----------
   Profilo Dati (apnset), Apri Una Porta (fwd) e Aggiornamenti con copia e ritorno (updsafe), più il ritorno a richiesta di
   simslot set e q5gset lock/unlock (secs). Sempre la copia di prima e il ritorno automatico (bakarm; updsafe con il suo
   lavoro staccato): di serie 120 s, da 60 a 900; conferma con action confirm, ritorno subito con back; dry = solo la
   frase del router per la conferma (say), nessuna modifica. Errori { error (frase it/en), code }. Con modifiche di LuCI
   non ancora applicate nella stessa configurazione si rifiuta (il commit le porterebbe dentro) */
/* API di AdGuard Home (una sola regola: metodo adg e adgups): credenziali in un file per curl -K, mai sulla riga di comando */
function adgreq(m0, p0, body) {
	let m = (m0 == 'POST' || m0 == 'PUT' || m0 == 'DELETE') ? m0 : 'GET', p = '' + (p0 ?? '');
	if (!match(p, /^[A-Za-z0-9_\/.?=&%-]{1,200}$/))
		return { code: 0, error: 'percorso non valido' };
	let cred = trim(readfile(ADGCONF) ?? '');
	if (!length(cred))
		return { code: 401, error: 'credenziali mancanti' };
	writefile('/tmp/.wf-adgc', 'user = "' + cred + '"\n');
	/* 2.64: le letture (GET) con un tempo corto: AdGuard fermo non tiene rpcd fermo per 25 s a chiamata (adglists ne fa 7) */
	let cmd = 'curl -s ' + (m == 'GET' ? '--connect-timeout 2 -m 10' : '-m 25') + ' -K /tmp/.wf-adgc -w "\\n%{http_code}" -X ' + m + ' -H "Content-Type: application/json"';
	if (body != null) {
		writefile('/tmp/.wf-adgb', '' + body);
		cmd += ' --data-binary @/tmp/.wf-adgb';
	}
	let out = sh(cmd + ' http://' + adgaddr() + '/control/' + p);
	unlink('/tmp/.wf-adgc');
	unlink('/tmp/.wf-adgb');
	let nl = rindex(out, '\n'), code = +substr(out, nl + 1), b = substr(out, 0, nl), parsed = null;
	try { parsed = json(b); } catch (e) { parsed = null; }
	return { code: code, body: parsed, text: (parsed == null) ? b : null };
}
/* DNS Obbligatorio (2.64 B5): la sezione dell'app (dns_redirect o «Forza-DNS-AdGuard»), o quella del pacchetto; null = non c'è */
const DNSFID = 'wf_dnsforce';
function dnsfsec(F) {
	for (let k in F) if (F[k]['.type'] == 'redirect' && (k == 'dns_redirect' || k == DNSFID || F[k].name == 'Forza-DNS-AdGuard')) return k;
	return null;
}
/* parte di firewall di una sola sezione per bakarm (anonima: solo se è ancora la stessa); o = solo quelle opzioni */
function fwpart(id, o) { return substr(id, 0, 1) == '@' ? { a: [ id ], o: o ?? [ 'enabled' ] } : (o ? { n: id, o: o } : { n: id }); }
function hisecs(s) { s = int(+(s ?? 0)); return s < 1 ? 120 : (s < 60 ? 60 : (s > 900 ? 900 : s)); }
function hierr(code, it, en) { return { error: L(it, en), code: code }; }
/* 2.64 B7 Nome e Ora (sysset): fusi della pagina Sistema [zona, città, regola POSIX] (come SYTZ dell'app); un altro fuso solo
   se il router ha il suo file in /usr/share/zoneinfo (la regola è l'ultima riga) */
const SYTZR = [ [ 'Europe/Rome', 'Roma', 'CET-1CEST,M3.5.0,M10.5.0/3' ], [ 'Europe/Zurich', 'Zurigo', 'CET-1CEST,M3.5.0,M10.5.0/3' ], [ 'Europe/Paris', 'Parigi', 'CET-1CEST,M3.5.0,M10.5.0/3' ],
	[ 'Europe/Berlin', 'Berlino', 'CET-1CEST,M3.5.0,M10.5.0/3' ], [ 'Europe/Vienna', 'Vienna', 'CET-1CEST,M3.5.0,M10.5.0/3' ], [ 'Europe/Madrid', 'Madrid', 'CET-1CEST,M3.5.0,M10.5.0/3' ],
	[ 'Europe/Amsterdam', 'Amsterdam', 'CET-1CEST,M3.5.0,M10.5.0/3' ], [ 'Europe/Brussels', 'Bruxelles', 'CET-1CEST,M3.5.0,M10.5.0/3' ], [ 'Europe/London', 'Londra', 'GMT0BST,M3.5.0/1,M10.5.0' ],
	[ 'Europe/Lisbon', 'Lisbona', 'WET0WEST,M3.5.0/1,M10.5.0' ], [ 'Europe/Athens', 'Atene', 'EET-2EEST,M3.5.0/3,M10.5.0/4' ], [ 'UTC', 'Ora Universale', 'UTC0' ] ];
function sytz(z) {
	for (let x in SYTZR) if (x[0] == z) return x[2];
	if (!match(z, /^[A-Z][A-Za-z_]{1,30}(\/[A-Za-z0-9_+-]{1,30}){1,2}$/)) return null;
	let t = filter(split(readfile('/usr/share/zoneinfo/' + z) ?? '', '\n'), length), l = length(t) ? t[length(t) - 1] : '';
	return match(l, /^[A-Za-z<][-+A-Za-z0-9<>,.:\/]{2,60}$/) ? l : null;
}
/* {sec (sezione system), hostname, zone, ntp}: una sola regola per get e set */
function systate() {
	let SY = ucfile('system'), sec = null;
	for (let k in SY) if (!sec && SY[k]['.type'] == 'system') sec = k;
	for (let k in SY) if (!sec && SY[k].hostname != null) sec = k;
	return { sec: sec, hostname: sec ? SY[sec].hostname ?? '' : '', zone: sec ? SY[sec].zonename ?? 'UTC' : '', ntp: (SY.ntp?.enabled ?? '1') != '0' };
}
function ucpend(c) { let s = stat('/tmp/.uci/' + c); return s != null && s.size > 0; }
/* linea mobile riconosciuta dal protocollo, con l'opzione del tipo di indirizzo del suo protocollo (null = non c'è) */
const MOBPROTO = { modemmanager: 'iptype', qmi: 'pdptype', mbim: 'pdptype', ncm: 'pdptype', '3g': null, wwan: null };
function mobifc() {
	let N = ucfile('network');
	for (let k in N) if (N[k]['.type'] == 'interface' && (N[k].proto ?? '') in MOBPROTO) return { ifc: k, proto: N[k].proto, ipo: MOBPROTO[N[k].proto] };
	return null;
}
/* Profilo Dati di adesso: una sola regola per apnset get e per la frase */
function apnstate() {
	let m = mobifc();
	if (!m) return null;
	let N = ucfile('network');
	return { iface: m.ifc, proto: m.proto, apn: ug(N, m.ifc, 'apn'), iptype: m.ipo ? (ug(N, m.ifc, m.ipo) || 'ipv4v6') : null, ipo: m.ipo, pend: bakleft('apn') };
}
/* 2.64 B6: Roaming Dati della linea mobile (allow_roaming, di serie acceso) e Ripristino Automatico del pacchetto (tools = c'è il
   5g-watchdog di quectel-5g-tools: il controllo è suo e non si tocca, come in wrtfreedom.init): una sola regola per modemset */
function mdstate() {
	let m = mobifc(), W = ucfile('wrtfreedom'), g = (o, d) => ug(W, 'wd', o) || d;
	return { roam: m ? !match(ug(ucfile('network'), m.ifc, 'allow_roaming') ?? '', /^(0|false|no|off)$/) : null, iface: m?.ifc ?? null, pend: bakleft('roam'),
		wd: { on: g('enabled', '0') == '1', tools: wdtools(), interval: +g('interval', '60'), fails: +g('fails', '5'), action: g('action', 'reconnect') } };
}
/* porte «a b» (anche «a-b» o «a:b») */
function prange(p) {
	let m = match('' + (p ?? ''), /^([0-9]{1,5})([-:]([0-9]{1,5}))?$/);
	if (!m) return null;
	let a = +m[1], b = m[3] != null ? +m[3] : a;
	return a >= 1 && b <= 65535 && a <= b ? [ a, b ] : null;
}
/* porte del router stesso, mai inoltrate: DNS, web e terminale (lette da uhttpd e dropbear, almeno 22, 53, 80, 443) e
   le porte di WireGuard */
function rtports() {
	let P = { '22': true, '53': true, '80': true, '443': true }, U = ucfile('uhttpd'), Dr = ucfile('dropbear'), N = ucfile('network');
	for (let k in U) for (let o in [ 'listen_http', 'listen_https' ]) for (let x in vpnarr(U[k][o])) { let m = match('' + x, /:([0-9]{1,5})$/); if (m) P[m[1]] = true; }
	for (let k in Dr) if (Dr[k]['.type'] == 'dropbear' && match('' + (Dr[k].Port ?? ''), /^[0-9]{1,5}$/)) P['' + Dr[k].Port] = true;
	for (let k in N) if (N[k]['.type'] == 'interface' && N[k].proto == 'wireguard' && match('' + (N[k].listen_port ?? ''), /^[0-9]{1,5}$/)) P['' + N[k].listen_port] = true;
	return P;
}
/* inoltri dalla zona esterna che usano già una di quelle porte e protocolli: nome (o sezione) del primo, null = libera */
function pfclash(F, wz, R, prs) {
	for (let k in F) {
		let s = F[k];
		if (s['.type'] != 'redirect' || s.enabled == '0' || (s.src ?? '') != wz || (s.target ?? 'DNAT') != 'DNAT') continue;
		let x = prange(split(join(' ', vpnarr(s.src_dport)), ' ')[0]);
		if (!x || x[1] < R[0] || x[0] > R[1]) continue;
		let sp = split(join(' ', vpnarr(s.proto)) || 'tcp udp', /[ \t]+/);
		for (let p in prs) if (p in sp || 'all' in sp) return s.name ?? k;
	}
	return null;
}
/* dispositivo dal MAC: indirizzo fisso (dhcp host con questo MAC) o quello di adesso (assegnazioni DHCP, tabella ARP) */
function pfdev(mac) {
	let H = leases()[mac] ?? { ip: '', name: '' }, D = ucfile('dhcp'), sec = null, ip = '';
	for (let k in D) if (D[k]['.type'] == 'host' && mac in split(lc(join(' ', vpnarr(D[k].mac))), /[ \t]+/)) { sec = k; break; }
	if (sec && match(D[sec].ip ?? '', /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) return { sec: sec, ip: D[sec].ip, fixed: true, name: H.name || D[sec].name || mac };
	ip = H.ip;
	if (!length(ip)) for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) { let p = split(trim(l), /[ \t]+/); if (length(p) >= 4 && lc(p[3]) == mac && p[2] != '0x0') { ip = p[0]; break; } }
	return { sec: sec, ip: ip, fixed: false, name: H.name || (sec ? D[sec].name : '') || mac };
}
const PFRX = /^wf_pf_[0-9]{1,5}(_[0-9]{1,5})?_(t|u|tu)$/, PFPR = { tcp: 't', udp: 'u', 'tcp udp': 'tu' };
function pfname(n) { return replace(substr(trim('' + (n ?? '')), 0, 40), /[^A-Za-z0-9 ._-]/g, ''); }
/* porte aperte dal pacchetto (sezioni wf_pf_*): una sola regola per fwd list e per la frase di chiusura */
function pflist() {
	let F = ucfile('firewall'), H = leases(), byip = {}, r = [];
	for (let m in H) if (length(H[m].ip)) byip[H[m].ip] = { mac: m, name: H[m].name };
	for (let k in F) if (F[k]['.type'] == 'redirect' && match(k, PFRX)) {
		let s = F[k], d = byip[s.dest_ip ?? ''] ?? { mac: '', name: '' };
		push(r, { id: k, name: s.name ?? '', on: s.enabled != '0', proto: join(' ', vpnarr(s.proto)) || 'tcp udp', port: s.src_dport ?? '', to_port: s.dest_port ?? s.src_dport ?? '',
			ip: s.dest_ip ?? '', mac: d.mac, dev: d.name || d.mac || (s.dest_ip ?? '') });
	}
	return r;
}
/* Aggiornamenti con copia e ritorno: lavoro staccato (detach 'upg'), stato in UPGF, copie in /etc/wrtfreedom-copie */
const UPGD = '/tmp/wf-upg', UPGF = '/tmp/wf-upg.json', UPGC = '/etc/wrtfreedom-copie';
/* programmi di sistema mai aggiornati da qui (il ritorno rimette le impostazioni, non la versione di prima): kernel e moduli,
   firmware di ogni tipo, gestori dei pacchetti, ubus, rpcd, server web, firewall, rete, Wi-Fi, DNS, terminale, modem,
   librerie di base, firme e certificati, connessione sicura, linea dati e WrtFreedom (che ha il suo tipo). Una sola
   regola (UPGNOS): il metodo e la simulazione del lavoro (grep -E sui pacchetti che apk/opkg porterebbero insieme) */
const UPGNOS = '^(kernel|kmod-.*|base-files|busybox.*|procd.*|ubus.*|ubox|libubus.*|libubox.*|rpcd.*|uhttpd.*|firewall4?|nftables.*|iptables.*|apk.*|opkg|.*firmware.*|fwtool|mtd|fstools|libc|musl.*|libgcc.*|netifd|uci|libuci.*|ucode.*|libucode.*|dropbear|openssh-server.*|wpad.*|hostapd.*|dnsmasq.*|odhcpd.*|odhcp6c|modemmanager.*|libqmi.*|libmbim.*|qfirehose.*|fwupd.*|wrtfreedom.*|usign|ucert|curl|libcurl.*|libustream-.*|libmbedtls.*|libopenssl.*|libwolfssl.*|ca-bundle|ca-certificates|ppp.*|uqmi|umbim|comgt.*|iwinfo|libiwinfo.*|jsonfilter|logd|quectel-5g-tools.*)$', UPGNO = regexp(UPGNOS);
/* file del pacchetto: la stessa lista L di install.sh (righe di /etc/sysupgrade.conf), copiati e rimessi dal ritorno */
const WFFILES = '/www/wrtfreedom/ /usr/share/ucode/luci/template/themes/wrtfreedom/ /www/luci-static/wrtfreedom /usr/share/rpcd/ucode/wrtfreedom.uc /usr/libexec/rpcd/wrtfreedom.wait /www/cgi-bin/wf-live /www/cgi-bin/wf-me /www/cgi-bin/wf-ai /usr/share/rpcd/acl.d/wrtfreedom.json /usr/share/wrtfreedom/ /etc/wrtfreedom/ /etc/config/wrtfreedom /etc/init.d/wrtfreedom /etc/init.d/wrtfreedom-ai /etc/hotplug.d/iface/90-wrtfreedom /etc/hotplug.d/dhcp/90-wrtfreedom /etc/hotplug.d/usb/90-wrtfreedom /etc/hotplug.d/block/90-wrtfreedom /etc/hotplug.d/button/90-wrtfreedom /etc/hotplug.d/ntp/90-wrtfreedom';
function upgrun() { let p = trim(readfile('/tmp/wf-bg.upg.pid') ?? ''); return match(p, /^[0-9]{1,10}$/) != null && has('/proc/' + p); }
/* pacchetto nell'ultimo elenco degli aggiornabili già pronto (pkgs up): { from, to } o null. opkg «nome - vecchia - nuova»,
   apk «nome-nuova … [upgradable from: nome-vecchia]» */
function upgline(n) {
	for (let l in split(readfile('/tmp/.wf-pkgup') ?? '', '\n')) {
		let m = match(l, /^([^ ]+) - ([^ ]+) - ([^ ]+)/);
		if (m && m[1] == n) return { from: m[2], to: m[3] };
		m = match(l, /^([^ ]+) .*\[upgradable from: ([^] ]+)]/);
		let k = length(n) + 1;
		if (m && substr(m[1], 0, k) == n + '-' && substr(m[2], 0, k) == n + '-' && match(substr(m[1], k), /^[0-9]/))
			return { from: substr(m[2], k), to: substr(m[1], k) };
	}
	return null;
}
/* lavoro di /tmp/.wf-job in corso (Software, Pacchetto Router, Blocco Cella): uno alla volta */
function jobbusy() {
	let s = stat('/tmp/.wf-job');
	return s != null && time() - s.mtime < 600 && index(readfile('/tmp/.wf-job') ?? '', '__FINE__') < 0;
}
/* script del lavoro: copia (sysupgrade -b e, per WrtFreedom, i file del pacchetto), installazione, controllo che il
   router risponda (ubus wrtfreedom updsafe ping, fino a 60 s), finestra di conferma; senza risposta o senza conferma
   back.sh rimette com'era. Stati: copy, install, wait (left = secondi), ok, back, err (msg) */
function upgjob(K, N, oldver, to, secs, F, P, why) {
	let B = bakdir('upg'), wf = K == 'wf';
	let back = '[ -f ' + B + '/id ] || exit 0\n' + (wf ?
		'tar -xzf ' + q(P) + ' -C /\nfor x in etc/config/wrtfreedom etc/crontabs/root; do tar -xzf ' + q(F) + ' -C / $x 2>/dev/null; done\nrm -rf ' + B + '\n' + bakdonesh('upg') + '/etc/init.d/cron restart >/dev/null 2>&1\n' +
		'( /etc/init.d/rpcd stop; i=0; while pidof rpcd >/dev/null && [ $i -lt 5 ]; do sleep 1; i=$((i+1)); done; for p in $(pidof rpcd); do kill -9 $p; done; /etc/init.d/rpcd start; /etc/init.d/wrtfreedom restart ) >/dev/null 2>&1\n' :
		'sysupgrade -r ' + q(F) + ' >/dev/null 2>&1\nrm -rf ' + B + '\n' + bakdonesh('upg') + 'reload_config >/dev/null 2>&1\n') +
		'sh /usr/share/wrtfreedom/event.sh cron upg_back net "${1:-' + replace(why, /["$`\\]/g, '') + '}"\n';
	let s = 'umask 022\nD=' + UPGD + '; O=' + UPGF + '; B=' + B + '; K=' + K + '; N=' + q(N) + '; FROM=' + q(oldver) + '; TO=' + q(to) + '; S=' + int(secs) + '; F=' + q(F) + '\n' +
		'st() { m=$(printf "%s" "$2" | tr "\\n\\r\\t" "   " | tr -d "\\"\\\\\\\\" | cut -c1-300); printf \'{"t":%s,"st":"%s","kind":"%s","name":"%s","from":"%s","to":"%s","copy":"%s","left":%s,"msg":"%s"}\\n\' "$(date +%s)" "$1" "$K" "$N" "$FROM" "$TO" "$F" "${3:-0}" "$m" > $O.t && mv $O.t $O; }\n' +
		'alive() { i=0; while [ $i -lt 12 ]; do ubus -t 10 call wrtfreedom updsafe \'{"action":"ping"}\' 2>/dev/null | grep -q pong && return 0; sleep 5; i=$((i+1)); done; return 1; }\n' +
		'back() { st back "$1"; sh $B/back.sh "$2"; st back "$1"; rm -f $D/back; exit 0; }\n' +
		'rm -f $D/back; st copy ""\nmkdir -p ' + UPGC + '\n' +
		'{ sysupgrade -b "$F" >/dev/null 2>&1 && [ -s "$F" ]; } || { rm -f "$F"; st err ' + q(L('copia delle impostazioni non riuscita: niente è cambiato', 'settings backup failed: nothing changed')) + '; exit 0; }\n' +
		'ls -1t ' + UPGC + '/copia-prima-agg-*.tar.gz 2>/dev/null | tail -n +4 | while read x; do rm -f "$x"; done\n';
	if (wf) s += 'L=; for x in ' + WFFILES + '; do x=${x#/}; x=${x%/}; [ -e /$x ] && L="$L $x"; done\n' +
		'{ tar -czf ' + q(P) + ' -C / $L 2>/dev/null && [ -s ' + q(P) + ' ]; } || { st err ' + q(L('copia del pacchetto non riuscita: niente è cambiato', 'package backup failed: nothing changed')) + '; exit 0; }\n';
	/* back.sh (e la copia in attesa) solo dopo la copia: così la copia non contiene il ritorno */
	s += 'mkdir -p $B && chmod 700 $B && cp $D/back.sh $B/back.sh && echo 900 > $B/secs && echo run > $B/id || { st err "bak"; exit 0; }\nst install ""\n';
	if (wf) s += 'cp /usr/share/wrtfreedom/upd.sh $D/upd.sh; o=$(sh $D/upd.sh install 2>&1); echo "$o" > $D/out\n' +
		'if ! echo "$o" | grep -q "^## OK"; then m=$(echo "$o" | sed -n "s/^## ERRORE //p" | tail -n 1); echo "$o" | grep -q "^## Copio i file" && back "$m" ' + q(L('↩️ Aggiornamento di WrtFreedom non riuscito: rimessa la versione di prima', '↩️ WrtFreedom update failed: previous version restored')) + '; rm -rf $B; st err "$m"; exit 0; fi\n' +
		'TO=$(cat /usr/share/wrtfreedom/VERSION 2>/dev/null); [ "$TO" = "$FROM" ] && { rm -rf $B; st ok ' + q(L('già aggiornato', 'already up to date')) + '; exit 0; }\n';
	/* pacchetto: prima la simulazione (apk -s, opkg --noaction); se porta con sé un programma di sistema (UPGNOS) ci si
	   ferma senza cambiare niente */
	else s += 'if command -v apk >/dev/null 2>&1; then o=$(apk upgrade -s "$N" 2>&1); r=$?; u=$(echo "$o" | sed -nE ' + q('s/^\\([0-9]+\\/[0-9]+\\) [A-Za-z]+ ([^ ]+) .*/\\1/p') + ')\n' +
		'else o=$(opkg upgrade --noaction "$N" 2>&1); r=$?; u=$(echo "$o" | sed -nE ' + q('s/^(Upgrading|Installing|Downgrading) ([^ ]+) .*/\\2/p') + '); fi\n' +
		'[ $r = 0 ] || { rm -rf $B; st err "$(echo "$o" | tail -n 2)"; exit 0; }\n' +
		'x=$(echo "$u" | grep -E ' + q(UPGNOS) + ' | grep -vxF "$N" | head -n 3 | tr "\\n" " ")\n' +
		'[ -z "$x" ] || { rm -rf $B; st err ' + q(L('porterebbe anche programmi di sistema, che non si aggiornano da qui: ', 'it would also bring system programs, which are not updated from here: ')) + '"$x"; exit 0; }\n' +
		'if command -v apk >/dev/null 2>&1; then o=$(apk upgrade "$N" 2>&1); else o=$(opkg upgrade "$N" 2>&1); fi; r=$?; echo "$o" > $D/out\n' +
		'[ $r = 0 ] || { rm -rf $B; st err "$(echo "$o" | tail -n 2)"; exit 0; }\n';
	s += 'alive || back ' + q(L('il router non risponde dopo l\'aggiornamento', 'the router does not answer after the update')) + ' ' + q(L('↩️ Aggiornamento: il router non rispondeva, rimesso com\'era', '↩️ Update: the router did not answer, restored')) + '\n' +
		'echo $S > $B/secs; echo w$(date +%s) > $B/id; E=$(( $(date +%s) + S ))\n' +
		'while [ -f $B/id ]; do\n' +
		'\t[ -f $D/back ] && back ' + q(L('annullato', 'undone')) + ' ' + q(L('↩️ Aggiornamento annullato: rimesso com\'era', '↩️ Update undone: restored')) + '\n' +
		'\tl=$(( E - $(date +%s) )); [ $l -le 0 ] && back ' + q(L('nessuna conferma', 'no confirmation')) + '\n' +
		'\tst wait "" $l; sleep 2\ndone\nst ok ""\n' +
		'sh /usr/share/wrtfreedom/event.sh cron upg_ok net ' + q(wf ? L('✅ WrtFreedom aggiornato e confermato', '✅ WrtFreedom updated and confirmed') : L('✅ Pacchetto aggiornato e confermato', '✅ Package updated and confirmed') + ': ' + N) + ' >/dev/null 2>&1\n';
	mkdir(UPGD, 448);
	writefile(UPGD + '/back.sh', back);
	writefile(UPGD + '/run.sh', s);
	return detach('upg', 'sh ' + UPGD + '/run.sh');
}

const methods = {
	info: {
		call: function() {
			let pm = has('/usr/bin/apk') || has('/sbin/apk') ? 'apk' : (has('/bin/opkg') || has('/usr/bin/opkg') ? 'opkg' : '');
			/* strumento per i comandi AT: si cerca al massimo ogni 10 minuti (può chiedere a ModemManager, lento) */
			let tf = stat('/tmp/wf-attool');
			if (!tf || time() - tf.mtime > 600) writefile('/tmp/wf-attool', trim(sh('sh /usr/share/wrtfreedom/at.sh --tool 2>/dev/null')));
			let modem = hasmodem();
			return { version: trim(readfile('/usr/share/wrtfreedom/VERSION') ?? ''), pm: pm, at: trim(readfile('/tmp/wf-attool') ?? ''), modem: modem, q5g: q5gtools(), q5gwd: wdtools() };
		}
	},
	snapshot: {
		/* stato per notifiche, notifica fissa e impostazioni rapide del telefono, in una sola chiamata.
		   Deve essere velocissima: rpcd è fermo finché risponde, quindi niente attese, niente comandi al modem
		   e mai chiamate ubus servite da rpcd stesso (rc, session, uci, file, iwinfo…). Le parti che cambiano
		   poco (registro, servizi) si rileggono al massimo ogni minuto. */
		args: { since: 0 },
		call: function(req) {
			let since = +(req.args.since ?? 0);
			let b = { hostname: trim(readfile('/proc/sys/kernel/hostname') ?? ''), model: trim(readfile('/tmp/sysinfo/model') ?? '') };
			if (!length(b.model)) b = ubcall('system', 'board') ?? b;
			let r = { v: trim(readfile('/usr/share/wrtfreedom/VERSION') ?? ''), t: time(), host: b.hostname ?? '', model: b.model ?? '',
				up: 0 };
			let mi = readfile('/proc/meminfo') ?? '', mt = match(mi, /MemTotal:\s+(\d+)/), ma = match(mi, /MemAvailable:\s+(\d+)/);
			if (mt && ma) r.mem = int((+mt[1] - +ma[1]) * 100 / +mt[1]);
			r.load = split(trim(readfile('/proc/loadavg') ?? '0'), ' ')[0];
			let tc = thermc();
			if (tc != null) r.temp = tc;
			/* linea: l'interfaccia che porta la rotta predefinita, qualunque sia il suo nome */
			let D = (ubcall('network.interface', 'dump') ?? {}).interface ?? [], w = wanpick(D);
			let dev = w ? (w.l3_device ?? w.device ?? '') : '';
			if (!match(dev, /^[A-Za-z0-9_.@-]{1,32}$/)) dev = '';
			/* CPU e velocità: differenza dalla lettura precedente */
			let st = split(trim(substr(readfile('/proc/stat') ?? '', 4, 200)), /\s+/), n = [], tot = 0;
			for (let i = 0; i < 8 && i < length(st); i++) { push(n, +st[i]); tot += +st[i]; }
			/* /proc/uptime letto una volta sola: tempo acceso (up) e base per le velocità */
			let now = { t: +(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]), idle: n[3] + (n[4] ?? 0), tot: tot, dev: dev,
				rx: length(dev) ? +trim(readfile('/sys/class/net/' + dev + '/statistics/rx_bytes') ?? '0') : 0,
				tx: length(dev) ? +trim(readfile('/sys/class/net/' + dev + '/statistics/tx_bytes') ?? '0') : 0 };
			r.up = int(now.t);
			let pv = json(readfile('/tmp/wf-snap.prev') ?? 'null');
			writefile('/tmp/wf-snap.prev', sprintf('%J', now));
			r.wan = { name: w ? w.interface : '', up: w ? !!w.up : false, upt: w ? (w.uptime ?? 0) : 0, dev: dev, rx: now.rx, tx: now.tx };
			if (w && length(w['ipv4-address'] ?? [])) r.wan.ip = w['ipv4-address'][0].address;
			if (pv && now.t - pv.t >= 1 && now.tot > pv.tot) {
				let dt = now.t - pv.t;
				r.cpu = int(100 - (now.idle - pv.idle) * 100.0 / (now.tot - pv.tot));
				if (pv.dev == dev && now.rx >= pv.rx && now.tx >= pv.tx) {
					r.wan.dl = sprintf('%.1f', (now.rx - pv.rx) * 8 / dt / 1e6);
					r.wan.ul = sprintf('%.1f', (now.tx - pv.tx) * 8 / dt / 1e6);
					r.wan.span = int(dt);
				}
			}
			/* dispositivi collegati (2.49): presenza di notify.sh, la stessa di «clients» (Collegato unico); senza
			   /tmp/wf-pres (servizio appena avviato) Wi-Fi dai punti di accesso e gli altri dai vicini di rete attivi */
			let PC = stat(PRESD) ? presence() : null;
			if (PC) {
				let wifi = 0, cable = 0;
				for (let k in PC) if (PC[k].on) { if (PC[k].via == 'cavo') cable++; else wifi++; }
				r.clients = { online: wifi + cable, wifi: wifi, cable: cable };
			}
			else {
			let on = {}, wifi = 0;
			/* punti di accesso Wi-Fi: interfacce con phy80211; i client da hostapd, altrimenti da iwinfo */
			for (let d in (lsdir('/sys/class/net') ?? [])) {
				if (!has('/sys/class/net/' + d + '/phy80211') || !match(d, /^[A-Za-z0-9_.-]{1,32}$/)) continue;
				let hc = ubcall('hostapd.' + d, 'get_clients'), macs = [];
				if (hc && hc.clients) macs = keys(hc.clients);
				else for (let l in split(sh('iwinfo ' + q(d) + ' assoclist 2>/dev/null'), '\n')) { let m = match(l, /^([0-9A-Fa-f:]{17})/); if (m) push(macs, m[1]); }
				for (let mc in macs) if (!on[lc_(mc)]) { on[lc_(mc)] = 'w'; wifi++; }
			}
			let cable = 0;
			for (let l in split(sh('ip -4 neigh show 2>/dev/null'), '\n')) {
				let m = match(l, /^(\S+) dev (\S+) lladdr (\S+) (\S+)/);
				if (!m || m[2] == dev || on[lc_(m[3])]) continue;
				if (m[4] == 'REACHABLE' || m[4] == 'DELAY' || m[4] == 'PROBE') { on[lc_(m[3])] = 'c'; cable++; }
			}
			r.clients = { online: wifi + cable, wifi: wifi, cable: cable };
			}
			/* VPN: accesa se un'interfaccia WireGuard è su (null = WireGuard non c'è) */
			for (let i in D) if (i.proto == 'wireguard' && !match(i.interface, VPNIFRX)) r.vpn = (r.vpn ?? false) || !!i.up;
			/* linea mobile: tecnologia e segnale dall'ultima lettura del modem fatta in sottofondo (null = niente modem) */
			let MI = M.id();
			if (MI.mm || M.present()) {
				/* tecnologia e segnale per la notifica: modulo della marca (o ModemManager) dalle letture in sottofondo */
				modembg(MI);
				let n = M.state(MI).n, at = n.at, b4 = length(filter(n.ca, (x) => substr(x, 0, 1) == 'B')), nr5 = !!n.nr || length(filter(n.ca, (x) => substr(x, 0, 1) == 'n')) > 0;
				let rsrp = n.lte?.rsrp ?? n.nr?.rsrp;
				let lte = !!n.lte || 'lte' in at, sa = n.nr?.sa && !n.lte;
				if (lte || n.nr || length(at)) {
					r.line = { tech: sa ? '5G SA' : nr5 ? '5G NSA' : lte ? (b4 > 1 ? '4G LTE-A' : '4G LTE') : ('5gnr' in at ? '5G' : '3G') };
					if (rsrp != null && rsrp < 0 && rsrp > -160) r.line.rsrp = rsrp;
				}
			}
			/* Wi-Fi e rete ospiti */
			let ws = ubcall('network.wireless', 'status') ?? {}, wup = false;
			for (let k in ws) if (ws[k].up) wup = true;
			let WL = ucfile('wireless'), gs = 0, gon = false;
			for (let k in guestifs(WL)) { gs++; if (ug(WL, k, 'disabled') != '1') gon = true; }
			r.wifi = { up: wup, guest: gs > 0, guestOn: gon };
			/* avvisi del registro e servizi fermi: al massimo una volta al minuto */
			let ck = json(readfile('/tmp/wf-snap.slow') ?? 'null');
			if (!ck || time() - ck.t > 60) {
				/* avvisi del registro (2.55: stesso conto di logsum, logrows) e servizi fermi (stesso calcolo di svc,
				   svcstate); memoria interna usata (%, per Stato Della Casa) da diskpct */
				ck = { t: time(), logw: length(filter(logrows('sys'), (x) => x.lv <= 4)), stopped: svcstate().stopped };
				/* solo una lettura vera: il ripiego (dal file stesso) con una t nuova non scadrebbe mai */
				let dk = diskpct(true);
				if (dk != null) ck.disk = dk;
				let sv = ubcall('service', 'list') ?? {};
				/* AdGuard Home: acceso o no (null = non installato) */
				if (has('/etc/init.d/adguardhome')) { ck.adg = false; for (let ik in (sv.adguardhome ?? {}).instances ?? {}) if (sv.adguardhome.instances[ik].running) ck.adg = true; }
				writefile('/tmp/wf-snap.slow', sprintf('%J', ck));
			}
			r.logw = ck.logw; r.stopped = ck.stopped;
			if (ck.adg != null) r.adg = ck.adg;
			/* eventi dopo l'ultimo già visto dal telefono */
			/* 2.62: con il campo ai (Avvisi Spiegati Dall'IA, evai: la stessa regola di evlist) */
			let ev = [], AW = evai();
			for (let l in reverse(lastlines(evlog(), 40))) {
				let p = split(l, '|', 4);
				if (length(p) != 4 || +p[0] <= since || p[1] == 'rule') continue;
				let o = { t: +p[0], e: p[1], c: p[2], x: p[3] }, w = AW[p[0] + '|' + p[1]];
				if (w) o.ai = w;
				push(ev, o);
			}
			r.events = ev;
			/* Stato Della Casa (2.49): lo stesso calcolo della Dashboard e del bot (Tutto Bene / Da Vedere e quanti avvisi) */
			/* Servizio VPN (2.52): lo stesso stato di Stato Della Casa e del bot */
			let VS = vpnstate(null);
			if (VS) r.vpnsvc = { on: VS.on, ok: VS.ok, n: VS.n, where: L(VS.wherei, VS.where), cc: VS.cc, who: VS.who, all: VS.all, devs: VS.devs, pause: VS.pause, state: VS.state, v: VS.v, badn: VS.badn, txt: VS.txt };
			let CS = casacalc({ wup: r.wan.up, tech: r.line?.tech, ws: ws, pres: PC, vs: VS });
			r.casa_ok = CS.ok; r.casa_n = CS.n;
			return r;
		}
	},
	casa: {
		/* Stato Della Casa (2.49): {t, ok, n, items [{id, sev ok|info|warn|bad, text, act}], line, wifi, vpn, dev, today,
		   sys, ign}; sola lettura (file in /tmp e netifd, vedi casacalc). action ignore {id} = avviso nascosto fino a
		   mezzanotte, unignore {id} = di nuovo visibile */
		args: { action: 'action', id: 'id' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), id = '' + (req.args.id ?? '');
			if (a == 'ignore' || a == 'unignore') {
				if (!match(id, /^[a-z0-9_]{1,24}$/)) return { error: 'avviso non valido' };
				let ids = filter(casaign(), (x) => x != id);
				if (a == 'ignore') { if (length(ids) >= 32) return { error: 'troppi avvisi ignorati' }; push(ids, id); }
				casaignset(ids);
				return { done: true, ign: ids };
			}
			if (a != 'get') return { error: 'azione non valida' };
			return casacalc(null);
		}
	},
	quick: {
		/* azioni dai widget e dalle impostazioni rapide del telefono */
		args: { act: 'act', mac: 'mac', name: 'name' },
		call: function(req) {
			let a = '' + (req.args.act ?? '');
			if (a == 'vpn_on' || a == 'vpn_off') {
				sh('sh /usr/share/wrtfreedom/event.sh act ' + a + ' >/dev/null 2>&1 &');
				return { ok: true };
			}
			if (a == 'modem_restart') {
				sh(MODEMRESET);
				return { ok: true };
			}
			if (a == 'adg_on' || a == 'adg_off')
				return adgbg(a == 'adg_on' ? 'on' : 'off') ? { ok: true } : { error: 'AdGuard Home non collegato' };
			/* dispositivo nuovo segnato come conosciuto (app, Telegram «Lo Conosco»): /etc/wrtfreedom/seen senza «?» */
			if (a == 'known') {
				let mac = lc('' + (req.args.mac ?? ''));
				if (!okmac(mac)) return { error: 'dispositivo non valido' };
				seenwrite(mac, true);
				return { ok: true };
			}
			if (a == 'block' || a == 'unblock') {
				let mac = lc('' + (req.args.mac ?? '')), nm = replace(substr('' + (req.args.name ?? ''), 0, 60), /[\n\r'"]/g, '');
				if (!match(mac, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/)) return { error: 'dispositivo non valido' };
				/* stessa regola che crea l'app (Client › Blocca) */
				let id = 'firewall.x3kb_' + replace(mac, /:/g, ''), Z = fwzones();
				let cmd = a == 'block'
					? 'uci -q get ' + id + ' >/dev/null || { uci set ' + id + '=rule; uci set ' + id + '.name=' + q('Blocco ' + (length(nm) ? nm : mac)) + '; uci set ' + id + '.src=' + Z.home + '; uci set ' + id + '.dest=' + Z.wan + '; uci add_list ' + id + '.src_mac=' + mac + '; uci add_list ' + id + '.proto=all; uci set ' + id + '.target=REJECT; }; uci set ' + id + '.enabled=1; '
					: 'uci -q delete ' + id + '; ';
				sh(cmd + 'uci commit firewall; ( /etc/init.d/firewall reload ) >/dev/null 2>&1 &');
				return { ok: true };
			}
			if (a == 'wifi_on' || a == 'wifi_off') {
				sh('sh /usr/share/wrtfreedom/event.sh act ' + a + ' >/dev/null 2>&1 &');
				return { ok: true };
			}
			if (a == 'wifi_restart') {
				sh(WIFIRESTART);
				return { ok: true };
			}
			/* ospiti: stesso criterio e stessa strada di wifiguest (accesi senza scadenza; spenti = cambio di password in attesa) */
			if (a == 'guest_on' || a == 'guest_off')
				return guestset(a == 'guest_on', 0);
			return { error: 'azione sconosciuta' };
		}
	},
	clients: {
		/* dispositivi visti da notify.sh (Collegato unico): on, ultimo visto, come (Wi-Fi_2,4_GHz, Wi-Fi_5_GHz, cavo),
		   conosciuto (true), nuovo da confermare (false) o mai visto dagli avvisi (null), nome e IP */
		call: function() {
			let P = presence(), K = seenmap(), H = leases(), L = [], on = 0, w = 0, c = 0;
			for (let m in P) {
				let x = P[m];
				push(L, { mac: m, on: x.on, last: x.last, via: x.via, known: K[m] ?? null, name: H[m]?.name ?? '', ip: H[m]?.ip ?? '' });
				if (x.on) { on++; if (x.via == 'cavo') c++; else w++; }
			}
			return { now: time(), ok: stat(PRESD) != null, list: L, online: on, wifi: w, cable: c };
		}
	},
	clusage: {
		/* consumo per dispositivo (contatori nft di dev.uc) e quote. get {mac?}: oggi [giù, su, minuti con traffico],
		   ultimi 7 e 30 giorni [giù, su], velocità dell'ultimo minuto in byte/s; con mac anche i giorni (35).
		   set {mac, gb (0 = toglie), act warn|block, day 0 = ogni giorno, 1…28 = dal giorno del mese}.
		   reset {mac?} = azzera il consumo contato del dispositivo o di tutti (dev.uc reset, in sottofondo) */
		args: { action: 'action', mac: 'mac', gb: 0, act: 'act', day: 0 },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), mac = lc('' + (req.args.mac ?? ''));
			if (a == 'set') {
				if (!okmac(mac)) return { error: 'dispositivo non valido' };
				let g = int(+(req.args.gb ?? 0)), ac = '' + (req.args.act ?? 'warn'), d = int(+(req.args.day ?? 0)), s = 'q_' + m12(mac);
				if (g < 0 || g > 100000) return { error: 'quota non valida (0…100000 GB)' };
				if (ac != 'warn' && ac != 'block') return { error: 'azione non valida' };
				if (d < 0 || d > 28) return { error: 'giorno non valido (0 = ogni giorno, 1…28)' };
				cfgensure();
				let c = udel('wrtfreedom', s);
				if (g > 0) c += 'uci set ' + q('wrtfreedom.' + s + '=quota') + '; ' + uset('wrtfreedom', s, 'mac', mac) + uset('wrtfreedom', s, 'gb', '' + g) + uset('wrtfreedom', s, 'act', ac) + uset('wrtfreedom', s, 'day', '' + d);
				sh(c + 'uci commit wrtfreedom');
				devbg('apply');
				return { ok: true };
			}
			if (a == 'reset') {
				if (length(mac) && !okmac(mac)) return { error: 'dispositivo non valido' };
				devbg('reset ' + (length(mac) ? mac : 'all'));
				return { ok: true };
			}
			if (a != 'get') return { error: 'azione non valida' };
			if (length(mac) && !okmac(mac)) return { error: 'dispositivo non valido' };
			let S = rjs(DTMP) ?? {}, D = S.days ?? {}, now = time(), td = dday(now), w7 = dday(now - 6 * 86400), w30 = dday(now - 29 * 86400), R = {}, Q = {}, C = devcan();
			for (let d in sort(keys(D))) for (let m in D[d]) {
				if (length(mac) && m != mac) continue;
				let x = D[d][m], r = R[m] = R[m] ?? { today: [0, 0, 0], week: [0, 0], month: [0, 0] };
				if (d == td) r.today = [x[0], x[1], x[2]];
				if (d >= w7) { r.week[0] += x[0]; r.week[1] += x[1]; }
				if (d >= w30) { r.month[0] += x[0]; r.month[1] += x[1]; }
				if (length(mac)) push(r.days = r.days ?? [], [d, x[0], x[1], x[2]]);
			}
			let W = ucfile('wrtfreedom');
			for (let k in W) if (W[k]['.type'] == 'quota' && okmac(W[k].mac ?? '') && (!length(mac) || W[k].mac == mac)) {
				let x = S.qs?.[W[k].mac] ?? {};
				Q[W[k].mac] = { gb: +(W[k].gb ?? 0), act: W[k].act ?? 'warn', day: +(W[k].day ?? 0), used: x.used ?? 0, start: x.start ?? null, over: !!x.over, blocked: !!x.blocked };
			}
			let rt = {};
			for (let k in S.rate ?? {}) if (!length(mac) || k == mac) rt[k] = S.rate[k];
			let ok = C.can && stat(DEVNFT) != null && S.t != null && now - S.t < 300;
			return { now: now, day: td, ok: ok, why: ok ? null : (C.why ?? 'primo conteggio entro un minuto'), thr: 120000, rate: rt, devs: R, quota: Q };
		}
	},
	person: {
		/* Persone (sezioni uci «person», scritte solo alle modifiche): nome, dispositivi, Tempo Con Traffico al giorno
		   (budget in minuti, 0 = nessun limite), giorni (cifre 0…6, 0 = domenica; vuoto = tutti), fasce senza internet
		   («22:00-07:00», separate da virgole, al massimo 6). Pausa della persona: sec > 0 = per quei secondi (al massimo
		   7 giorni), -1 = finché non si toglie, 0 = toglie. Lo stato (minuti di oggi, motivo della pausa) lo calcola dev.uc */
		args: { action: 'action', id: 'id', name: 'name', macs: 'macs', budget: 0, days: 'days', slots: 'slots', sec: 0 },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), id = '' + (req.args.id ?? ''), W = ucfile('wrtfreedom'), now = time();
			if (a == 'get') {
				let S = rjs(DTMP) ?? {}, P = dpzget(), PR = presence(), L = [];
				for (let k in W) if (W[k]['.type'] == 'person') {
					let ms = filter(vpnarr(W[k].mac), okmac), st = S.ps?.[k] ?? {};
					push(L, { id: k, name: W[k].name ?? '', macs: ms, budget: +(W[k].budget ?? 0), days: W[k].days ?? '', slots: vpnarr(W[k].slot),
						used: st.used ?? 0, why: st.why ?? '', until: P.p?.[k] ?? null, online: length(filter(ms, (m) => PR[m]?.on)) });
				}
				let C = devcan();
				return { now: now, list: L, can: C.can, why: C.why };
			}
			if (a != 'set' || length(id)) {
				if (!match(id, /^p_[a-z0-9]{1,16}$/) || W[id]?.['.type'] != 'person') return { error: 'persona non trovata' };
			}
			if (a == 'del') {
				sh(udel('wrtfreedom', id) + 'uci commit wrtfreedom');
				let P = dpzget();
				if (P.p?.[id] != null) { delete P.p[id]; dpzset(P); }
				devbg('apply');
				return { ok: true };
			}
			if (a == 'pause') {
				/* solo numeri interi: un valore sbagliato non diventa mai una pausa senza fine */
				if (type(req.args.sec) != 'int') return { error: 'durata non valida (fino a 7 giorni)' };
				let s = req.args.sec, P = dpzget();
				if (s < -1 || s > 7 * 86400) return { error: 'durata non valida (fino a 7 giorni)' };
				P.p = P.p ?? {};
				if (s == 0) delete P.p[id];
				else P.p[id] = s > 0 ? now + s : 0;
				dpzset(P);
				devbg('apply');
				return { ok: true, until: s == 0 ? null : P.p[id] };
			}
			if (a != 'set') return { error: 'azione non valida' };
			let nm = trim('' + (req.args.name ?? '')), ms = maclist(req.args.macs, 16), b = int(+(req.args.budget ?? 0));
			let dy = '' + (req.args.days ?? ''), sl = filter(split('' + (req.args.slots ?? ''), /[ ,;]+/), length);
			if (!length(nm) || length(nm) > 48 || match(nm, /['"\\\n\r]/)) return { error: 'nome non valido' };
			if (b < 0 || b > 1440) return { error: 'tempo non valido (0…1440 minuti)' };
			if (!match(dy, /^[0-6]{0,7}$/)) return { error: 'giorni non validi' };
			if (length(sl) > 6) return { error: 'al massimo 6 fasce' };
			for (let x in sl) {
				let m = match(x, /^([01][0-9]|2[0-3]):([0-5][0-9])-([01][0-9]|2[0-3]):([0-5][0-9])$/);
				if (!m || m[1] + m[2] == m[3] + m[4]) return { error: 'fascia non valida: ' + x };
			}
			/* un dispositivo appartiene a una persona sola */
			for (let k in W) if (W[k]['.type'] == 'person' && k != id)
				for (let m in ms) if (index(vpnarr(W[k].mac), m) >= 0) return { error: 'dispositivo già di ' + (W[k].name ?? k) };
			let ds = join('', filter(['0', '1', '2', '3', '4', '5', '6'], (x) => index(dy, x) >= 0));
			if (!length(id)) id = 'p_' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + now), /[^0-9a-f]/g, ''), 0, 8);
			cfgensure();
			let c = udel('wrtfreedom', id) + 'uci set ' + q('wrtfreedom.' + id + '=person') + '; ' + uset('wrtfreedom', id, 'name', nm) + uset('wrtfreedom', id, 'budget', '' + b);
			if (length(ds)) c += uset('wrtfreedom', id, 'days', ds);
			if (match(W[id]?.adglevel ?? '', /^[a-z]{1,16}$/)) c += uset('wrtfreedom', id, 'adglevel', W[id].adglevel);	/* livello di protezione (2.50) */
			for (let m in ms) c += 'uci add_list ' + q('wrtfreedom.' + id + '.mac=' + m) + '; ';
			for (let x in sl) c += 'uci add_list ' + q('wrtfreedom.' + id + '.slot=' + x) + '; ';
			sh(c + 'uci commit wrtfreedom');
			devbg('apply');
			return { ok: true, id: id };
		}
	},
	devtype: {
		/* tipo e produttore: tipo scelto a mano (/etc/wrtfreedom/devtype.json), nome del dispositivo, classe DHCP (solo
		   con dnsmasq), tabella dei produttori. MAC privati (casuali) = produttore sconosciuto. type = tipo da salvare
		   per i macs (auto = toglie quello scelto a mano); macs vuoto = tutti i dispositivi noti */
		args: { macs: 'macs', type: 'type' },
		call: function(req) {
			let L = maclist(req.args.macs, 128), ty = '' + (req.args.type ?? ''), M = rjs(DTYPE) ?? {};
			if (length(ty)) {
				if (!length(L)) return { error: 'dispositivo non valido' };
				if (ty != 'auto' && index(DTYPES, ty) < 0) return { error: 'tipo non valido' };
				for (let m in L) { if (ty == 'auto') delete M[m]; else M[m] = ty; }
				mkdir('/etc/wrtfreedom');
				writefile(DTYPE + '.t', sprintf('%J', M)); rename(DTYPE + '.t', DTYPE);
			}
			let H = leases(), VC = {}, R = {};
			if (!length(L)) L = uniq([...keys(H), ...keys(presence())]);
			for (let l in split(readfile('/tmp/wf-dhcpvc') ?? '', '\n')) { let i = index(l, ' '); if (i == 17) VC[substr(l, 0, 17)] = substr(l, 18); }
			for (let m in L) {
				let priv = (hex(substr(m, 0, 2)) & 2) != 0, o = priv ? null : ouiget(m), vc = VC[m] ?? '', t = M[m], src = t ? 'manual' : '';
				if (!t) { t = nametype(H[m]?.name ?? ''); if (t) src = 'name'; }
				if (!t) { t = vctype(vc); if (t) src = 'dhcp'; }
				if (!t && o && length(o[1])) { t = o[1]; src = 'oui'; }
				R[m] = { vendor: o ? o[0] : '', type: t ?? '', src: src, priv: priv, vc: vc };
			}
			return { list: R, types: DTYPES, dhcp: has('/etc/hotplug.d/dhcp/90-wrtfreedom') };
		}
	},
	presence: {
		/* storico di presenza (righe di notify.sh, in /etc/wrtfreedom/pres.log ogni ora, 60 giorni): intervalli [da, a]
		   (a null = collegato adesso) e minuti per giorno degli ultimi days giorni (1…60, di serie 7).
		   mac = un dispositivo; macs = più dispositivi in una sola lettura (al massimo 32) → { list: { mac: … } } */
		args: { mac: 'mac', macs: 'macs', days: 0 },
		call: function(req) {
			let n = int(+(req.args.days ?? 0)) || 7, now = time(), M = [];
			for (let x in split(lc('' + (req.args.macs ?? req.args.mac ?? '')), /[ ,;]+/))
				if (okmac(x) && index(M, x) < 0 && length(M) < 32) push(M, x);
			if (!length(M)) return { error: 'dispositivo non valido' };
			if (n < 1 || n > 60) return { error: 'giorni non validi (1…60)' };
			let PP = presence(), tsince = now - n * 86400, E = {};
			for (let m in M) E[m] = [];
			for (let l in split(sh('cat /etc/wrtfreedom/pres.log /tmp/wf-presl.f /tmp/wf-presl 2>/dev/null | grep -F ' + join(' ', map(M, (m) => '-e ' + q(' ' + m + ' ')))), '\n')) {
				let p = split(l, ' ');
				if (length(p) >= 3 && type(E[p[1]]) == 'array') push(E[p[1]], [+p[0], p[2] == '1']);
			}
			/* minuti per giorno, da mezzanotte (ora del router) */
			let lt = localtime(now), m0 = now - lt.hour * 3600 - lt.min * 60 - lt.sec;
			let one = function(mac) {
				let iv = [], open = null, P = PP[mac] ?? {}, D = [];
				for (let e in sort(E[mac], (x, y) => x[0] - y[0])) {
					if (e[1]) { if (open == null) open = e[0]; }
					else if (open != null) { push(iv, [open, e[0]]); open = null; }
				}
				if (open != null) push(iv, [open, P.on ? null : (P.last ?? open)]);
				iv = filter(iv, (x) => (x[1] ?? now) >= tsince);
				for (let x in iv) if (x[0] < tsince) x[0] = tsince;
				for (let i = n - 1; i >= 0; i--) {
					let a = m0 - i * 86400, b = a + 86400, s = 0;
					for (let x in iv) { let f = x[0] > a ? x[0] : a, t = (x[1] ?? now) < b ? (x[1] ?? now) : b; if (t > f) s += t - f; }
					push(D, { d: dday(a + 3600), min: int(s / 60) });
				}
				return { mac: mac, now: now, days: n, on: !!P.on, last: P.last ?? null, via: P.via ?? '', iv: iv, day: D };
			};
			if (req.args.macs == null) return one(M[0]);
			let R = {};
			for (let m in M) R[m] = one(m);
			return { now: now, days: n, list: R };
		}
	},
	pause: {
		/* Pausa Per Tutti (non vale per i client VPN): pause {} = stato; sec > 0 = per quei secondi, sec -1 = finché non si
		   toglie, until = fino a quell'ora (secondi dal 1970), sec 0 = toglie; except = MAC che restano in internet.
		   Stato in /tmp/wf-dpause.json, insiemi del firewall da dev.uc (niente ricarica), fine dal giro di dev.uc */
		args: { sec: 0, until: 0, except: 'except' },
		call: function(req) {
			let P = dpzget(), now = time(), A = P.all, C = devcan();
			if (req.args.sec == null && req.args.until == null) {
				let on = !!A && (!(A.until > 0) || A.until > now);
				return { now: now, on: on, until: on ? A.until : null, except: on ? A.except ?? [] : [], since: on ? A.t0 : null, can: C.can, why: C.why };
			}
			for (let k in ['sec', 'until']) if (req.args[k] != null && type(req.args[k]) != 'int') return { error: 'durata non valida (fino a 7 giorni)' };
			let s = req.args.sec ?? 0, u = req.args.until ?? 0;
			if (s == 0 && u == 0) {
				let was = !!A;
				P.all = null; dpzset(P); devbg('apply');
				if (was) devev('dev_pause_end', '▶️ ' + L('Pausa per tutti finita', 'Pause for everyone ended'));
				return { ok: true, on: false };
			}
			if (!C.can) return { error: C.why };
			let until = u > 0 ? u : s > 0 ? now + s : 0;
			if (s < -1 || (until > 0 && (until <= now || until > now + 7 * 86400))) return { error: 'durata non valida (fino a 7 giorni)' };
			P.all = { until: until, except: maclist(req.args.except, 64), t0: now };
			dpzset(P);
			devbg('apply');
			devev('dev_pause', '⏸️ ' + L('Pausa per tutti', 'Pause for everyone') + (until > 0 ? ' · ' + L('fino alle', 'until') + ' ' + sprintf('%02d:%02d', localtime(until).hour, localtime(until).min) : ''));
			return { ok: true, on: true, until: until };
		}
	},
	forget: {
		/* Dimentica in un passaggio: IP fisso (dhcp host), blocco e orari (x3kb_/x3ks_), limiti (shaper), «Avvisami»,
		   quota, persone, tipo, già visto e presenza; un commit per configurazione e una sola ricarica in sottofondo, poi
		   dev.uc forget (AdGuard Home, consumo e storico di presenza) */
		args: { mac: 'mac' },
		call: function(req) {
			let mac = lc('' + (req.args.mac ?? ''));
			if (!okmac(mac)) return { error: 'dispositivo non valido' };
			let id = m12(mac), c = '', what = [], cm = {};
			/* IP fisso: sezioni host con questo MAC (anonime dall'ultima, così gli indici non cambiano) */
			let D = ucfile('dhcp'), fip = [];
			for (let k in reverse(keys(D))) if (D[k]['.type'] == 'host') {
				let L = filter(split(lc(join(' ', vpnarr(D[k].mac))), /[ \t]+/), length), rest = filter(L, (x) => x != mac);
				if (length(rest) == length(L)) continue;
				if (length(D[k].ip ?? '')) push(fip, '' + D[k].ip);
				if (length(rest)) { c += udel('dhcp', k, 'mac'); for (let x in rest) c += 'uci add_list ' + q('dhcp.' + k + '.mac=' + x) + '; '; }
				else c += udel('dhcp', k);
				cm.dhcp = true;
			}
			if (cm.dhcp) push(what, 'dhcp');
			/* blocco e orari dei dispositivi */
			let F = ucfile('firewall'), rx = regexp('^x3k[bs]_' + id + '(_[a-z])?$');
			for (let k in F) if (match(k, rx)) { c += udel('firewall', k); cm.firewall = true; }
			if (cm.firewall) push(what, 'rules');
			/* Avvisami, quota, persone */
			let W = ucfile('wrtfreedom'), nl = vpnarr(W.notify?.mac);
			if (length(filter(nl, (x) => lc(x) == mac))) {
				c += udel('wrtfreedom', 'notify', 'mac');
				for (let x in filter(nl, (x) => lc(x) != mac)) c += 'uci add_list ' + q('wrtfreedom.notify.mac=' + x) + '; ';
				cm.wrtfreedom = true; push(what, 'notify');
			}
			if (W['q_' + id]) { c += udel('wrtfreedom', 'q_' + id); cm.wrtfreedom = true; push(what, 'quota'); }
			for (let k in W) if (W[k]['.type'] == 'person' && index(vpnarr(W[k].mac), mac) >= 0) {
				c += udel('wrtfreedom', k, 'mac');
				for (let x in filter(vpnarr(W[k].mac), (x) => x != mac)) c += 'uci add_list ' + q('wrtfreedom.' + k + '.mac=' + x) + '; ';
				cm.wrtfreedom = true; push(what, 'person');
			}
			/* limiti e priorità: regole con il MAC; con il solo IP solo se è l'IP fisso (dhcp host) del dispositivo (un IP
			   assegnato al momento può passare a un altro dispositivo) */
			let R = rjs(SHJSON), shp = false;
			if (type(R) == 'array') {
				let R2 = [], ch = false;
				for (let r in R) {
					/* voci di una persona (2.59): il MAC esce dall'elenco, la voce resta se ha ancora dispositivi */
					if (type(r) == 'object' && type(r.macs) == 'array') {
						let ms = filter(r.macs, (x) => lc('' + x) != mac);
						if (length(ms) != length(r.macs)) { ch = true; if (length(ms)) push(R2, { ...r, macs: ms }); continue; }
					}
					if (type(r) == 'object' && (lc('' + (r.mac ?? '')) == mac || (!okmac(lc('' + (r.mac ?? ''))) && r.macs == null && r.casa !== true && index(fip, '' + (r.ip ?? '')) >= 0))) { ch = true; continue; }
					push(R2, r);
				}
				if (ch) { let e = shaperfile(R2); if (e) return { error: e }; shp = true; push(what, 'limit'); }
			}
			if (length(c)) sh(c + join('', map(keys(cm), (x) => 'uci commit ' + x + '; ')));
			/* tipo, già visto, presenza attuale */
			let M = rjs(DTYPE);
			if (M?.[mac]) { delete M[mac]; writefile(DTYPE + '.t', sprintf('%J', M)); rename(DTYPE + '.t', DTYPE); push(what, 'type'); }
			if (seenmap()[mac] != null) { seenwrite(mac, false); push(what, 'seen'); }
			unlink(PRESD + '/' + id);
			let bg = '';
			if (cm.dhcp) bg += '/etc/init.d/dnsmasq reload; [ -x /etc/init.d/odhcpd ] && /etc/init.d/odhcpd reload; ';
			if (cm.firewall || shp) bg += 'fw4 reload; ';
			sh('( ' + bg + 'ucode ' + DEVUC + ' forget ' + q(mac) + ' ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, removed: what };
		}
	},
	devset: {
		/* una voce di un dispositivo (2.64, Assistente IA; come la scheda dell'app): k ip = Indirizzo Fisso (v '1' =
		   l'indirizzo di adesso, come Apri Una Porta: pfdev; v = un IPv4 di casa, per rimettere quello di prima; v '0' = lo
		   toglie: ip e leasetime, la sezione con solo il MAC esce), k notify = Avvisami Quando Si Collega (v '1'/'0',
		   wrtfreedom.notify.mac). Risposta {ok, ip?, same?}; dnsmasq ricaricato in sottofondo */
		args: { mac: 'mac', k: 'k', v: 'v' },
		call: function(req) {
			let mac = lc('' + (req.args.mac ?? '')), k = '' + (req.args.k ?? ''), v = trim('' + (req.args.v ?? '')), c = '';
			if (!okmac(mac)) return { error: 'dispositivo non valido' };
			if (k == 'notify') {
				let W = ucfile('wrtfreedom'), nl = map(vpnarr(W.notify?.mac), lc), on = v == '1';
				if ((index(nl, mac) >= 0) == on) return { ok: true, same: true };
				cfgensure();
				if (on) c = (W.notify ? '' : 'uci set wrtfreedom.notify=notify; ') + 'uci add_list ' + q('wrtfreedom.notify.mac=' + mac) + '; ';
				else { c = udel('wrtfreedom', 'notify', 'mac'); for (let x in filter(nl, (x) => x != mac)) c += 'uci add_list ' + q('wrtfreedom.notify.mac=' + x) + '; '; }
				sh(c + 'uci commit wrtfreedom');
				return { ok: true };
			}
			if (k != 'ip') return { error: 'voce non valida' };
			let d = pfdev(mac), D = ucfile('dhcp'), ip = v == '1' ? d.ip : v;
			if (v == '0') {
				if (!d.fixed) return { ok: true, same: true };
				let o = filter(keys(D[d.sec]), (x) => substr(x, 0, 1) != '.' && index([ 'mac', 'ip', 'leasetime' ], x) < 0);
				c = length(o) ? udel('dhcp', d.sec, 'ip') + udel('dhcp', d.sec, 'leasetime') : udel('dhcp', d.sec);
			}
			else {
				if (!match(ip, /^(10(\.[0-9]{1,3}){3}|(192\.168|172\.(1[6-9]|2[0-9]|3[01]))(\.[0-9]{1,3}){2})$/)) return { error: 'il dispositivo non ha un indirizzo di casa: deve essere collegato' };
				if (d.fixed && d.ip == ip) return { ok: true, same: true, ip: ip };
				for (let s in D) if (D[s]['.type'] == 'host' && s != d.sec && D[s].ip == ip) return { error: 'indirizzo già di un altro dispositivo' };
				let hs = d.sec ?? ('wf_ip_' + m12(mac));
				c = (d.sec == null ? 'uci set dhcp.' + hs + '=host; ' + uset('dhcp', hs, 'mac', mac) + uset('dhcp', hs, 'name', replace(pfname(d.name) || 'dispositivo', / /g, '-')) : '') + uset('dhcp', hs, 'ip', ip);
			}
			sh(c + 'uci commit dhcp; ( /etc/init.d/dnsmasq reload; [ -x /etc/init.d/odhcpd ] && /etc/init.d/odhcpd reload ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, ip: v == '0' ? null : ip };
		}
	},
	wifi: {
		/* Salute Del Wi-Fi (2.48, wifi.uc tick in sottofondo). get = ultima lettura {t, iv, radios {radio: {band, up, ch, freq,
		   width, txpow, cfg, noise, busy, txp, rxp (% del canale in uso), nsta, sig, retry, ifs [{ifname, ssid}]}},
		   devs {mac: {if, radio, band, ssid, sig, avg, txr, rxr (Mbit/s), retry, fail, air (%), conn, inact, priv}}, dfs, cac}
		   e tiene viva la lettura (ogni 30 s per 10 minuti, poi ogni 5 minuti fino a 24 ore; {wait: true} la prima volta);
		   hist = riassunti di 5 minuti delle ultime 24 ore per radio; hist {mac} = ultime letture del dispositivo;
		   sta {mac} = segnale di un dispositivo adesso (una lettura); restart = Riavvia Wi-Fi (lavoro del router) */
		args: { action: 'action', mac: 'mac' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), mac = lc('' + (req.args.mac ?? ''));
			if (a == 'restart') { sh(WIFIRESTART); return { ok: true }; }
			if (a == 'get') {
				writefile(WFP + '.want', '' + upsec());
				let S = rjs(WFP + '.json');
				if (!S || time() - S.t >= 25) system('ucode ' + WIFIUC + ' tick >/dev/null 2>&1 &');
				let D = [];
				for (let l in lastlines(WFP + '.dfs', 10)) { let f = split(l, ' '); push(D, { t: +f[0], if: f[1], ch: +f[2] || null, to: +f[3] || null }); }
				return { ...(S ?? { wait: true }), now: time(), dfs: D, cac: rjs(WFP + '.cac') };
			}
			let nv = (x) => x == '-' ? null : +x, now = time(), rows = [];
			if (a == 'hist' && length(mac)) {
				if (!okmac(mac)) return { error: 'dispositivo non valido' };
				for (let l in split(readfile(WFP + '.d/' + replace(mac, /:/g, '')) ?? '', '\n')) { let f = split(l, ' '); if (length(f) == 5) push(rows, map(f, nv)); }
				return { mac: mac, now: now, cols: [ 't', 'sig', 'txr', 'retry', 'air' ], rows: rows };
			}
			if (a == 'hist') {
				for (let l in split(readfile(WFP + '.h') ?? '', '\n')) {
					let f = split(l, ' ');
					if (length(f) == 8 && +f[0] > now - 86400) push(rows, [ +f[0], f[1], ...map(slice(f, 2), nv) ]);
				}
				return { now: now, step: 300, cols: [ 't', 'radio', 'busy', 'txp', 'noise', 'nsta', 'sig', 'retry' ], rows: rows };
			}
			if (a == 'sta') {
				if (!okmac(mac)) return { error: 'dispositivo non valido' };
				let R = wradios();
				for (let rn in R) for (let I in R[rn].ifs) {
					if (!match(I.ifname, /^[A-Za-z0-9_.-]{1,32}$/)) continue;
					let o = sh('iw dev ' + q(I.ifname) + ' station get ' + mac + ' 2>/dev/null');
					if (index(o, 'Station') < 0) continue;
					let n = (k) => { let m = match(o, regexp('\n[ \t]*' + k + ':[ \t]*(-?[0-9.]+)')); return m ? +m[1] : null; };
					return { mac: mac, on: true, t: now, if: I.ifname, radio: rn, band: R[rn].band, ssid: I.ssid, sig: n('signal'), avg: n('signal avg'), txr: n('tx bitrate'), rxr: n('rx bitrate'), inact: n('inactive time') };
				}
				return { mac: mac, on: false, t: now };
			}
			return { error: 'azione non valida' };
		}
	},
	wifiguest: {
		/* Ospiti A Tempo, password che cambia e Limite Di Velocità (2.48). get = {has, on, nets [{sec, ssid, on}], sel (reti
		   ospiti che on riaccende: quelle accese all'ultimo spegnimento; vuoto = tutte), until, left,
		   every, pend, pendsince, limit {dl, ul, ok, err, can, why}}; on {min, bands?} = accende (bands = solo quelle bande, 2.64) (0 = senza scadenza, 15…1440 = si
		   spegne da sola: notify.sh controlla wrtfreedom.guest.until); off; end = tempo scaduto (da notify.sh: spegne ed
		   evento cron_guest_end); pwd {pwd, force} = nuova password ('' = casuale; con gli ospiti accesi serve force: i
		   dispositivi ospiti si scollegano); every {every: ''|'day'|'week'|'month'} = cambio automatico (cron.sh guestpwd
		   alle 4:10); rot = cambio dal cron: subito con gli ospiti spenti, altrimenti allo spegnimento (pend; dopo 7 giorni
		   di attesa evento cron_guest_pwd_wait, al massimo uno a settimana); limit {dl, ul} = limite per tutta la rete
		   ospiti in kbit/s (0 = nessuno, 128…1000000), CAKE in sottofondo con wifi.uc glimit (can false = mancano tc o
		   sch_cake, why = cosa manca) */
		args: { action: 'action', min: 0, pwd: 'pwd', force: true, every: 'every', dl: 0, ul: 0, bands: 'bands' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), WL = ucfile('wireless'), W = ucfile('wrtfreedom'), G = guestifs(WL);
			let on = length(filter(G, (g) => ug(WL, g, 'disabled') != '1')) > 0, until = +(ug(W, 'guest', 'until') || 0), pend = +(ug(W, 'guest', 'pend') || 0);
			let guest0 = 'uci -q get wrtfreedom.guest >/dev/null || uci set wrtfreedom.guest=guest; ';
			if (a == 'get') {
				let gl = rjs('/tmp/wf-glimit.json') ?? {}, why = glimcan();
				return { has: length(G) > 0, on: on, nets: map(G, (g) => ({ sec: g, ssid: ug(WL, g, 'ssid'), on: ug(WL, g, 'disabled') != '1' })),
					until: until || null, left: (on && until) ? (until > time() ? until - time() : 0) : null, every: ug(W, 'guest', 'every'),
					pend: length(ug(W, 'guest', 'pend')) > 0, pendsince: pend > 1 ? pend : null, sel: filter(split(ug(W, 'guest', 'ifs'), ' '), (x) => index(G, x) >= 0),
					limit: { dl: +(ug(W, 'guest', 'dl') || 0), ul: +(ug(W, 'guest', 'ul') || 0), ok: gl.ok ?? null, err: gl.err ?? null, can: why == null, why: why } };
			}
			if (!length(G)) return { error: 'nessuna rete ospiti' };
			if (a == 'on') {
				let m = int(+(req.args.min ?? 0));
				if (m != 0 && (m < 15 || m > 1440)) return { error: 'durata non valida (15…1440 minuti)' };
				let bs = '' + (req.args.bands ?? '');
				if (length(bs) && !match(bs, /^(2g|5g|6g)( (2g|5g|6g))*$/)) return { error: 'bande non valide' };
				return guestset(true, m, bs);
			}
			if (a == 'off') return guestset(false, 0);
			if (a == 'end') {
				if (!until || until > time()) return { ok: true, skip: true };
				/* già spenta da un'altra parte (LuCI): si toglie solo la scadenza */
				if (!on) { sh('uci -q delete wrtfreedom.guest.until; uci commit wrtfreedom'); return { ok: true, skip: true }; }
				let r = guestset(false, 0);
				if (r.ok) wevent('guest_end', L('👥 Rete ospiti spenta: tempo scaduto', '👥 Guest network off: time is up'));
				return r;
			}
			if (a == 'pwd' || a == 'rot') {
				let k = a == 'rot' ? '' : '' + (req.args.pwd ?? '');
				if (length(k) && !match(k, /^[ -~]{8,63}$/)) return { error: 'password non valida (8…63 caratteri)' };
				cfgensure();
				if (a == 'rot' && on) {
					/* in attesa che la rete ospiti si spenga; dopo 7 giorni un avviso (al massimo uno a settimana) */
					let pw = +(ug(W, 'guest', 'pendwarn') || 0), c = guest0;
					if (!pend) c += uset('wrtfreedom', 'guest', 'pend', '' + time());
					else if (time() - pend > 7 * 86400 && time() - pw > 7 * 86400) {
						c += uset('wrtfreedom', 'guest', 'pendwarn', '' + time());
						wevent('guest_pwd_wait', L('🔑 La nuova password della rete ospiti aspetta da più di 7 giorni: spegni la rete ospiti per cambiarla', '🔑 The new guest password has been waiting for over 7 days: turn the guest network off to change it'));
					}
					sh(c + 'uci commit wrtfreedom');
					return { ok: true, pend: true };
				}
				if (on && req.args.force !== true) return { error: 'ospiti accesi: i dispositivi si scollegano', on: true };
				if (!length(k)) k = wkey(10);
				let c = '';
				for (let g in G) c += uset('wireless', g, 'key', k);
				sh(c + 'uci -q delete wrtfreedom.guest.pend; uci -q delete wrtfreedom.guest.pendwarn; uci commit wireless; uci commit wrtfreedom; ' + (on ? '( wifi reload ) >/dev/null 2>&1 </dev/null &' : ''));
				if (a == 'rot') wevent('guest_pwd', L('🔑 Nuova password della rete ospiti: la trovi nell\'app', '🔑 New guest network password: see the app'));
				return { ok: true, kicked: on };
			}
			if (a == 'every') {
				let e = '' + (req.args.every ?? ''), when = { day: '10 4 * * *', week: '10 4 * * 1', month: '10 4 1 * *' }[e];
				if (length(e) && !when) return { error: 'valore non valido' };
				cfgensure();
				sh(guest0 + (length(e) ? uset('wrtfreedom', 'guest', 'every', e) : udel('wrtfreedom', 'guest', 'every')) + 'uci commit wrtfreedom');
				cronline('guestpwd', when ? when + ' sh /usr/share/wrtfreedom/cron.sh guestpwd' : null);
				return { ok: true, every: e };
			}
			if (a == 'limit') {
				let dl = int(+(req.args.dl ?? 0)), ul = int(+(req.args.ul ?? 0)), okv = (x) => x == 0 || (x >= 128 && x <= 1000000);
				if (!okv(dl) || !okv(ul)) return { error: 'limite non valido (128…1000000 kbit/s, 0 = nessuno)' };
				let why = glimcan();
				if (why && (dl || ul)) return { error: why };
				cfgensure();
				sh(guest0 + (dl ? uset('wrtfreedom', 'guest', 'dl', '' + dl) : udel('wrtfreedom', 'guest', 'dl')) + (ul ? uset('wrtfreedom', 'guest', 'ul', '' + ul) : udel('wrtfreedom', 'guest', 'ul')) + 'uci commit wrtfreedom');
				system('ucode ' + WIFIUC + ' glimit' + (dl || ul ? '' : ' off') + ' >/dev/null 2>&1 &');
				return { ok: true, dl: dl, ul: ul };
			}
			return { error: 'azione non valida' };
		}
	},
	wifichan: {
		/* Canale Automatico e radar (2.48, wifi.uc). get = {radios {radio: {band, up, ch, freq, cfg, auto}}, plan {radio:
		   {t, run, error, width, cur, curblock, cfg, nets, chans [{ch, dfs, weather, radar, nets, best, score}], best,
		   bestnodfs}}, job {radio, ch, from, step switch|wait|ok|back|error, end, msg, live, reloadpending}, undo {radio:
		   {ch, cfg, t}}, dfs, cac}; reloadpending = canale cambiato senza riavvio e salvato: netifd lo applicherà al
		   prossimo riavvio del Wi-Fi (quella radio ripartirà una volta). plan {radio} = scansione delle reti vicine in
		   sottofondo (qualche secondo di rallentamento); apply {radio, ch} = cambio con switch_chan senza riavvio, poi uci
		   (canali DFS: riavvio della radio e attesa radar); ritorno automatico se la radio non riparte in 120 s; undo {radio}
		   = canale di prima; auto {radio, on} = scelta di notte (cron.sh wifichan alle 3:40, mai canali DFS). Un lavoro
		   fermo da più di 800 s (scansione: 120 s) vale come finito con errore */
		args: { action: 'action', radio: 'radio', ch: 0, on: true },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), rn = '' + (req.args.radio ?? ''), R = wradios(), now = time();
			let auto = filter(split(ug('wrtfreedom', 'wifichan', 'auto'), ' '), length);
			let busy = (k, age) => { let s = stat(WFP + '.' + k + '.lock'); return s != null && now - s.mtime < age; };
			if (a == 'get') {
				let X = {}, Pl = {}, U = {}, J = rjs(WFP + '.chan');
				for (let k in R) {
					let r = R[k], st = length(r.ifs) ? ubcall('hostapd.' + r.ifs[0].ifname, 'get_status') : null, p = rjs(WFP + '.plan.' + k);
					X[k] = { band: r.band, up: r.up, ch: st?.channel ?? null, freq: st?.freq ?? null, cfg: r.cfg, auto: index(auto, k) >= 0 };
					if (p?.run && now - p.t > 120) p = { t: p.t, radio: k, run: false, error: 'scansione non riuscita' };
					Pl[k] = p; U[k] = rjs(WFP + '.undo.' + k);
				}
				if (J && (J.step == 'switch' || J.step == 'wait') && now - J.t > 800) { J.step = 'error'; J.msg = 'cambio interrotto'; }
				let D = [];
				for (let l in lastlines(WFP + '.dfs', 10)) { let f = split(l, ' '); push(D, { t: +f[0], if: f[1], ch: +f[2] || null, to: +f[3] || null }); }
				return { radios: X, plan: Pl, job: J, undo: U, dfs: D, cac: rjs(WFP + '.cac'), now: now };
			}
			if (!match(rn, /^[A-Za-z0-9_]{1,32}$/) || !R[rn]) return { error: 'radio non valida' };
			if (a == 'plan') {
				if (busy('scan.' + rn, 120)) return { ok: true, run: true };
				if (!length(R[rn].ifs)) return { error: 'radio spenta o senza reti' };
				wjs(WFP + '.plan.' + rn, { t: now, radio: rn, run: true });
				system('ucode ' + WIFIUC + ' scan ' + rn + ' >/dev/null 2>&1 &');
				return { ok: true, run: true };
			}
			if (a == 'apply' || a == 'undo') {
				if (busy('chan', 800)) return { error: 'un cambio di canale è già in corso' };
				let ch = int(+(req.args.ch ?? 0));
				if (a == 'apply' && !(ch >= 1 && ch <= 233)) return { error: 'canale non valido' };
				if (a == 'undo' && !rjs(WFP + '.undo.' + rn)) return { error: 'niente da annullare' };
				wjs(WFP + '.chan', { t: now, radio: rn, ch: ch || null, step: 'switch' });
				system('ucode ' + WIFIUC + ' ' + (a == 'undo' ? 'undo ' + rn : 'chan ' + rn + ' ' + ch) + ' >/dev/null 2>&1 &');
				return { ok: true };
			}
			if (a == 'auto') {
				let L2 = filter(auto, (x) => x != rn && R[x]);
				if (req.args.on === true) push(L2, rn);
				cfgensure();
				let c = 'uci -q get wrtfreedom.wifichan >/dev/null || uci set wrtfreedom.wifichan=wifichan; uci -q delete wrtfreedom.wifichan.auto; ';
				for (let x in L2) c += 'uci add_list wrtfreedom.wifichan.auto=' + q(x) + '; ';
				sh(c + 'uci commit wrtfreedom');
				cronline('wifichan', length(L2) ? '40 3 * * * sh /usr/share/wrtfreedom/cron.sh wifichan' : null);
				return { ok: true, auto: L2 };
			}
			return { error: 'azione non valida' };
		}
	},
	wifinet: {
		/* Reti e Radio Wi-Fi una per una (2.64, Assistente IA): set {sec, k, v, secs} su una rete (wifi-iface: k on, name,
		   hidden, isolate) o una radio (wifi-device: k on, channel 'auto'|1…233, txpower ''|1…30 dBm; '' = massima); v '1'/'0'
		   per on, hidden e isolate. secs 60…300 = copia delle sole opzioni toccate (bakarm 'wifi') e ritorno da solo se entro
		   secs non arriva confirm (risposta {ok, confirm}); secs 0 = senza ritorno (riaccensione a tempo). Potenza subito con
		   cron.sh txradio (senza riavvio, se c'è iw), il resto con wifi reload. Mai le chiavi. confirm; back = subito com'era */
		args: { action: 'action', sec: 'sec', k: 'k', v: 'v', secs: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'set');
			if (act == 'confirm') return bakconfirm('wifi');
			if (act == 'back') return bakback('wifi', L('↩️ Wi-Fi: annullato, rimesso com\'era', '↩️ Wi-Fi: undone, restored'));
			if (act != 'set') return { error: 'azione non valida' };
			let sec = '' + (a.sec ?? ''), k = '' + (a.k ?? ''), v = trim('' + (a.v ?? '')), secs = int(+(a.secs ?? 0)), WL = ucfile('wireless');
			if (!match(sec, /^([A-Za-z0-9_]{1,64}|@wifi-(iface|device)[[][0-9]{1,3}[]])$/) || (WL[sec]?.['.type'] != 'wifi-iface' && WL[sec]?.['.type'] != 'wifi-device')) return { error: 'rete o radio non trovata' };
			let dev = WL[sec]['.type'] == 'wifi-device', K = { on: 'disabled', name: 'ssid', hidden: 'hidden', isolate: 'isolate', channel: 'channel', txpower: 'txpower' }[k];
			if (!K || index(dev ? [ 'on', 'channel', 'txpower' ] : [ 'on', 'name', 'hidden', 'isolate' ], k) < 0) return { error: 'voce non valida' };
			if (secs && (secs < 60 || secs > 300)) return { error: 'tempo di ritorno non valido (60…300 s)' };
			let nv = v, flag = k == 'on' || k == 'hidden' || k == 'isolate';
			if (flag && !match(v, /^[01]$/)) return { error: 'valore non valido' };
			if (k == 'on') nv = v == '1' ? '0' : '1';
			if (k == 'name' && (!length(v) || length(v) > 32 || match(v, /[[:cntrl:]]/))) return { error: 'nome non valido (1…32 caratteri)' };
			if (k == 'channel' && !(v == 'auto' || (match(v, /^[0-9]{1,3}$/) && +v >= 1 && +v <= 233))) return { error: 'canale non valido' };
			if (k == 'txpower' && length(v) && !(match(v, /^[0-9]{1,2}$/) && +v >= 1 && +v <= 30)) return { error: 'potenza non valida (1…30 dBm)' };
			let cur = ug(WL, sec, K);
			if ((length(cur) ? cur : flag ? '0' : k == 'channel' ? 'auto' : '') == (length(nv) ? nv : flag ? '0' : '')) return { ok: true, same: true };
			let st = stat(WFP + '.chan.lock');
			if (k == 'channel' && st && time() - st.mtime < 800) return { error: 'un cambio di canale è già in corso' };
			if (secs && bakpend('wifi')) return { error: 'conferma prima la modifica in attesa', pend: 'wifi' };
			let rl = k == 'txpower' && dev && match(sec, /^[A-Za-z0-9_]{1,32}$/) && (has('/usr/sbin/iw') || has('/usr/bin/iw') || has('/sbin/iw')) ? 'sh /usr/share/wrtfreedom/cron.sh txradio ' + q(sec) : 'wifi reload';
			if (secs) {
				let e = bakarm('wifi', { wireless: substr(sec, 0, 1) == '@' ? { a: [ sec ], o: [ K ] } : { n: sec, o: [ K ] } }, [], rl, secs,
					L('↩️ Wi-Fi: nessuna conferma entro ' + secs + ' s, rimesso com\'era', '↩️ Wi-Fi: no confirmation within ' + secs + ' s, restored'));
				if (e !== true) return e;
			}
			sh((length(nv) ? uset('wireless', sec, K, nv) : udel('wireless', sec, K)) + 'uci commit wireless; ( ' + rl + ' ) >/dev/null 2>&1 </dev/null &');
			return secs ? { ok: true, confirm: secs } : { ok: true };
		}
	},
	wifiwps: {
		/* WPS a tempo (2.48): solo reti a 2,4 GHz con WPA2 (psk2 o psk-mixed), visibili, con l'oggetto hostapd.<iface>.
		   state = {list [{iface, ssid, sec, pb}], iface, ssid, step restart|on|restore|off|error, t, end, added, res, stale,
		   status}; start {iface} = 2 minuti di WPS a pulsante; se wps_pushbutton manca lo mette e alla fine lo toglie: la rete
		   riparte due volte ({restart: true}). Prima di toccare wireless il segno wrtfreedom.wifi.wpsadd = sezione: se il
		   lavoro si interrompe lo ripuliscono l'avvio del servizio e uninstall.sh. Riavvio fermo da più di 300 s = finito
		   (stale, con ripulitura). stop = ferma */
		args: { action: 'action', iface: 'iface' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'state'), ifn = '' + (req.args.iface ?? ''), R = wradios(), Ls = [];
			for (let rn in R) if (R[rn].band == '2g') for (let I in R[rn].ifs) {
				if (!match(I.enc, /^(psk2|psk-mixed)/) || I.hidden || !match(I.ifname, /^[A-Za-z0-9_.-]{1,32}$/) || ubcall('hostapd.' + I.ifname, 'get_status') == null) continue;
				push(Ls, { iface: I.ifname, ssid: I.ssid, sec: I.sec, pb: I.pb });
			}
			let S = rjs(WFP + '.wps') ?? {};
			if ((S.step == 'restart' || S.step == 'restore') && time() - (S.t ?? 0) > 300) {
				system('ucode ' + WIFIUC + ' wpsclean force >/dev/null 2>&1 &');
				S.step = 'off'; S.stale = true; S.t = time(); wjs(WFP + '.wps', S);
			}
			if (a == 'state') return { list: Ls, ...S, status: S.iface ? ubcall('hostapd.' + S.iface, 'wps_status') : null, now: time() };
			if (a == 'start') {
				let I = filter(Ls, (x) => x.iface == ifn)[0];
				if (!I) return { error: 'WPS non disponibile su questa rete (solo 2,4 GHz con WPA2)' };
				if (!match(I.sec, /^[]A-Za-z0-9_@[-]{1,64}$/) || trim(sh('uci -q get ' + q('wireless.' + I.sec))) != 'wifi-iface') return { error: 'rete non trovata nella configurazione' };
				if (S.step == 'restart' || S.step == 'restore') return { error: 'la rete sta ripartendo: riprova tra poco' };
				unlink(WFP + '.wps.stop');
				if (I.pb) {
					let ok = trim(sh('ubus call hostapd.' + ifn + " wps_start '{}' >/dev/null 2>&1; echo $?")) == '0';
					wjs(WFP + '.wps', { iface: ifn, ssid: I.ssid, step: ok ? 'on' : 'error', t: time(), end: time() + 120, added: false });
					return ok ? { ok: true, restart: false, end: time() + 120 } : { error: 'WPS non avviato' };
				}
				cfgensure();
				sh('uci -q get wrtfreedom.wifi >/dev/null || uci set wrtfreedom.wifi=wifi; ' + uset('wrtfreedom', 'wifi', 'wpsadd', I.sec) + 'uci commit wrtfreedom');
				wjs(WFP + '.wps', { iface: ifn, ssid: I.ssid, sec: I.sec, step: 'restart', t: time(), added: true });
				system('ucode ' + WIFIUC + ' wps ' + q(ifn) + ' ' + q(I.sec) + ' >/dev/null 2>&1 &');
				return { ok: true, restart: true };
			}
			if (a == 'stop') {
				if (match(S.iface ?? '', /^[A-Za-z0-9_.-]{1,32}$/)) sh('ubus call hostapd.' + S.iface + " wps_cancel '{}' >/dev/null 2>&1");
				if (S.added && S.step != 'off') writefile(WFP + '.wps.stop', '');
				else if (S.iface) { S.step = 'off'; S.t = time(); wjs(WFP + '.wps', S); }
				return { ok: true };
			}
			return { error: 'azione non valida' };
		}
	},
	wifikick: {
		/* Sposta e Stacca (2.48). mode steer = invito 802.11v (bss_transition_request) dalla rete a 2,4 GHz a quella a 5 GHz
		   con lo stesso nome ({sent: true}: il dispositivo decide); mode ban = scollegato e tenuto fuori sec secondi
		   (30…86400, di serie 300) da tutte le reti del router (del_client con ban_time) */
		args: { mac: 'mac', mode: 'mode', sec: 0 },
		call: function(req) {
			let mac = lc('' + (req.args.mac ?? '')), mode = '' + (req.args.mode ?? ''), R = wradios();
			if (!okmac(mac)) return { error: 'dispositivo non valido' };
			if (mode == 'ban') {
				let s = int(+(req.args.sec ?? 0)) || 300, c = '';
				if (s < 30 || s > 86400) return { error: 'durata non valida (30…86400 secondi)' };
				for (let rn in R) for (let I in R[rn].ifs) if (match(I.ifname, /^[A-Za-z0-9_.-]{1,32}$/))
					c += 'ubus call hostapd.' + I.ifname + ' del_client ' + q(sprintf('%J', { addr: mac, reason: 5, deauth: true, ban_time: s * 1000 })) + ' >/dev/null 2>&1; ';
				if (!length(c)) return { error: 'nessuna rete Wi-Fi' };
				sh(c);
				return { ok: true, ban: s };
			}
			if (mode != 'steer') return { error: 'modo non valido' };
			let cur = null, C = null;
			for (let rn in R) for (let I in R[rn].ifs) if (!cur && match(I.ifname, /^[A-Za-z0-9_.-]{1,32}$/)) {
				let x = ubcall('hostapd.' + I.ifname, 'get_clients')?.clients?.[mac];
				if (x) { cur = { ...I, band: R[rn].band }; C = x; }
			}
			if (!cur) return { error: 'il dispositivo non è collegato al Wi-Fi' };
			if (cur.band != '2g') return { error: 'il dispositivo è già sui 5 GHz' };
			let tgt = null;
			for (let rn in R) if (R[rn].band == '5g') for (let I in R[rn].ifs) if (!tgt && I.ssid == cur.ssid) tgt = I;
			if (!tgt) return { error: 'nessuna rete a 5 GHz con lo stesso nome' };
			/* BSS Transition = bit 19 delle capacità estese (byte 2, bit 3); senza l'elenco si prova lo stesso */
			let ec = C.extended_capabilities, wnm = type(ec) == 'array' ? ((+(ec[2] ?? 0)) & 8) != 0 : null;
			if (wnm === false) return { error: 'il dispositivo non accetta lo spostamento: usa Stacca', wnm: false };
			let nr = wnr(tgt.ifname);
			if (!nr) return { error: 'rete a 5 GHz non pronta' };
			let ok = trim(sh('ubus call hostapd.' + cur.ifname + ' bss_transition_request ' + q(sprintf('%J', { addr: mac, disassociation_imminent: false, disassociation_timer: 0, validity_period: 30, abridged: true, neighbors: [ nr ] })) + ' >/dev/null 2>&1; echo $?')) == '0';
			return ok ? { ok: true, sent: true, to: tgt.ifname, wnm: wnm } : { error: 'richiesta non accettata dal Wi-Fi del router' };
		}
	},
	wifiiot: {
		/* Dispositivi Smart (2.48): l'unica creazione della rete (app e Firewall la chiedono qui). get = {has, nets [{sec,
		   ssid, radio, on}], net, zone, b2, b5, pending}; make {ssid, key, band '2g'|'both', hidden} = bridge br-iot,
		   interfaccia iot su una rete 192.168.x libera, DHCP, zona iot (ingresso e inoltro rifiutati) con inoltro verso la
		   zona internet vera (quella con il NAT; senza = errore), DNS e DHCP consentiti, Wi-Fi isolato psk2 sulle radio della
		   banda. Tutte le sezioni create hanno «option wf '1'»: del toglie solo quelle. Ritorno automatico come Applica
		   dell'app: copia di network, dhcp, firewall e wireless; senza confirm entro 60 s si rimette tutto com'era (evento
		   cron_iot_back). {confirm: 60} nella risposta = l'app deve chiamare confirm; back = annulla subito l'ultima
		   make/del in attesa (copia rimessa ed evento cron_iot_back) */
		args: { action: 'action', ssid: 'ssid', key: 'key', band: 'band', hidden: true },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), N = ucfile('network'), F = ucfile('firewall'), WL = ucfile('wireless'), Dh = ucfile('dhcp'), R = wradios();
			let BAK = '/tmp/wf-iot.bak', pending = stat(BAK) != null;
			let nets = filter(keys(WL), (k) => WL[k]['.type'] == 'wifi-iface' && index(split(ug(WL, k, 'network'), ' '), 'iot') >= 0);
			let zone = filter(keys(F), (k) => F[k]['.type'] == 'zone' && F[k].name == 'iot')[0];
			let rad = (b) => filter(keys(R), (k) => R[k].band == b);
			if (a == 'get')
				return { has: !!N.iot || !!zone || length(nets) > 0, net: N.iot ? ug(N, 'iot', 'ipaddr') : null, zone: zone ? 'iot' : null,
					nets: map(nets, (k) => ({ sec: k, ssid: ug(WL, k, 'ssid'), radio: ug(WL, k, 'device'), on: ug(WL, k, 'disabled') != '1' })),
					b2: length(rad('2g')) > 0, b5: length(rad('5g')) > 0, pending: pending };
			/* copia in BAK con un numero (id): il ritorno dopo 60 s vale solo se la copia è ancora quella sua.
			   confirm = copia buttata; back = copia rimessa subito (come allo scadere dei 60 s) */
			let reload = '/etc/init.d/network reload; /etc/init.d/firewall reload; /etc/init.d/dnsmasq reload; wifi reload';
			let CF = join(' ', map([ 'network', 'dhcp', 'firewall', 'wireless' ], (x) => BAK + '/' + x));
			let restore = (why) => 'cp ' + CF + ' /etc/config/ && rm -rf ' + BAK + '; ' + reload + '; sh /usr/share/wrtfreedom/event.sh cron iot_back net ' + q(why);
			if (a == 'confirm') {
				if (!pending) return { error: 'niente da confermare' };
				sh('rm -rf ' + BAK);
				return { ok: true };
			}
			if (a == 'back') {
				if (!pending) return { error: 'niente da annullare' };
				sh('( ' + restore(L('↩️ Dispositivi Smart: modifica annullata, rete rimessa com\'era', '↩️ Smart Devices: change cancelled, network restored')) + ' ) >/dev/null 2>&1 </dev/null &');
				return { ok: true };
			}
			if (pending) return { error: 'una modifica aspetta la conferma' };
			/* copia, modifica, ricarica; senza conferma entro 60 s la copia torna al suo posto */
			let id = '' + time() + wkey(6);
			let apply = (c) => sh('mkdir -p ' + BAK + ' && cp /etc/config/network /etc/config/dhcp /etc/config/firewall /etc/config/wireless ' + BAK + '/ && echo ' + id + ' > ' + BAK + '/id && { ' + c +
				'uci commit network; uci commit dhcp; uci commit firewall; uci commit wireless; ( ' + reload + '; sleep 60; [ "$(cat ' + BAK + '/id 2>/dev/null)" = ' + id + ' ] && { ' +
				restore(L('↩️ Dispositivi Smart: nessuna conferma entro 60 s, rete rimessa com\'era', '↩️ Smart Devices: no confirmation within 60 s, network restored')) +
				'; } ) >/dev/null 2>&1 </dev/null & } || rm -rf ' + BAK);
			let mine = (S) => filter(keys(S), (k) => S[k].wf == '1');
			if (a == 'del') {
				let c = '';
				for (let k in mine(N)) c += udel('network', k);
				for (let k in mine(Dh)) c += udel('dhcp', k);
				for (let k in mine(F)) c += udel('firewall', k);
				for (let k in mine(WL)) c += udel('wireless', k);
				if (!length(c)) return { error: 'nessuna rete Dispositivi Smart creata dall\'app' };
				apply(c);
				return { ok: true, confirm: 60 };
			}
			if (a != 'make') return { error: 'azione non valida' };
			let ssid = '' + (req.args.ssid ?? ''), key = '' + (req.args.key ?? ''), band = '' + (req.args.band ?? '2g');
			if (!length(ssid) || length(ssid) > 32 || match(ssid, /[[:cntrl:]]/)) return { error: 'nome della rete non valido (1…32 caratteri)' };
			if (!match(key, /^[ -~]{8,63}$/)) return { error: 'password non valida (8…63 caratteri)' };
			let RR = band == 'both' ? [ ...rad('2g'), ...rad('5g') ] : rad('2g');
			if (!length(RR)) return { error: 'serve una radio Wi-Fi a 2,4 GHz' };
			/* zona internet: quella con il NAT (mai un nome fisso) */
			let wz = null;
			for (let k in F) if (!wz && F[k]['.type'] == 'zone' && F[k].name && F[k].name != 'vpnout' && (F[k].masq == '1' || F[k].masq == 'true')) wz = F[k].name;
			if (!wz) return { error: 'nessuna zona internet con il NAT nel firewall' };
			/* nomi già usati: niente sovrascritture */
			let taken = N.iot_dev || N.iot || Dh.iot || F.iot_zone || F.iot_wan || F.iot_dns || F.iot_dhcp || zone || length(nets) > 0;
			for (let d in RR) if (WL['iot_' + replace(d, /[^A-Za-z0-9_]/g, '_')]) taken = true;
			if (taken) return { error: 'la rete Dispositivi Smart (o una sezione con lo stesso nome) esiste già' };
			/* rete libera: 192.168.x non usata da nessuna interfaccia */
			let used = {}, net = null;
			for (let k in N) for (let ip in vpnarr(N[k].ipaddr)) { let m = match('' + ip, /^192\.168\.([0-9]+)\./); if (m) used[+m[1]] = true; }
			for (let x = 4; x < 250 && !net; x++) if (!used[x]) net = '192.168.' + x + '.1/24';
			net = net ?? '10.77.0.1/24';
			let c = 'uci set network.iot_dev=device; uci set network.iot_dev.name=br-iot; uci set network.iot_dev.type=bridge; uci set network.iot_dev.bridge_empty=1; uci set network.iot_dev.wf=1; ' +
				'uci set network.iot=interface; uci set network.iot.proto=static; uci set network.iot.device=br-iot; uci set network.iot.ipaddr=' + net + '; uci set network.iot.wf=1; ' +
				'uci set dhcp.iot=dhcp; uci set dhcp.iot.interface=iot; uci set dhcp.iot.start=100; uci set dhcp.iot.limit=150; uci set dhcp.iot.leasetime=12h; uci set dhcp.iot.wf=1; ' +
				'uci set firewall.iot_zone=zone; uci set firewall.iot_zone.name=iot; uci add_list firewall.iot_zone.network=iot; uci set firewall.iot_zone.input=REJECT; uci set firewall.iot_zone.output=ACCEPT; uci set firewall.iot_zone.forward=REJECT; uci set firewall.iot_zone.wf=1; ' +
				'uci set firewall.iot_wan=forwarding; uci set firewall.iot_wan.src=iot; uci set firewall.iot_wan.dest=' + q(wz) + '; uci set firewall.iot_wan.wf=1; ' +
				"uci set firewall.iot_dns=rule; uci set firewall.iot_dns.name='Dispositivi Smart DNS'; uci set firewall.iot_dns.src=iot; uci set firewall.iot_dns.dest_port=53; uci add_list firewall.iot_dns.proto=tcp; uci add_list firewall.iot_dns.proto=udp; uci set firewall.iot_dns.target=ACCEPT; uci set firewall.iot_dns.wf=1; " +
				"uci set firewall.iot_dhcp=rule; uci set firewall.iot_dhcp.name='Dispositivi Smart DHCP'; uci set firewall.iot_dhcp.src=iot; uci set firewall.iot_dhcp.dest_port=67-68; uci add_list firewall.iot_dhcp.proto=udp; uci set firewall.iot_dhcp.target=ACCEPT; uci set firewall.iot_dhcp.wf=1; ";
			for (let d in RR) {
				let s = 'iot_' + replace(d, /[^A-Za-z0-9_]/g, '_');
				c += 'uci set wireless.' + s + '=wifi-iface; ' + uset('wireless', s, 'device', d) + uset('wireless', s, 'mode', 'ap') + uset('wireless', s, 'network', 'iot') +
					uset('wireless', s, 'ssid', ssid) + uset('wireless', s, 'encryption', 'psk2') + uset('wireless', s, 'key', key) + uset('wireless', s, 'isolate', '1') +
					uset('wireless', s, 'wf', '1') + (req.args.hidden === true ? uset('wireless', s, 'hidden', '1') : '');
			}
			apply(c);
			return { ok: true, net: net, radios: RR, zone: wz, confirm: 60 };
		}
	},
	modem: {
		call: function() {
			modembg();
			let o = readfile('/tmp/wf-modem.at');
			if (o == null) return { wait: true };
			/* dati uguali per tutte le marche (n); i campi grezzi Quectel restano per l'app */
			let St = M.state(), I = St.id, D = St.D;
			return { mm: St.mm, serving: lines(o, '+QENG:'), ca: lines(o, '+QCAINFO:'), temp: lines(o, '+QTEMP:'), n: St.n,
				id: { vendor: I.vendor, mfr: I.mfr, model: I.model, rev: I.rev ?? '', mm: I.mm, lock: !!(D && D.lock), drv: D ? D.name : '' },
				age: time() - (stat('/tmp/wf-modem.at')?.mtime ?? time()) };
		}
	},
	modeminfo: {
		/* SIM e bande: supportate, in uso e modalità, dalla strada giusta per questo modem (ModemManager o AT della marca) */
		call: function() {
			return { sim: js('mmcli -i any -J 2>/dev/null'), nb: M.bands() };
		}
	},
	cells: {
		/* celle vicine: comandi AT della marca, altrimenti ModemManager (--get-cell-info).
		   ready (Assistente IA): solo letture già pronte in /tmp (q5g e modembg in sottofondo), mai AT qui */
		args: { ready: true },
		call: function(req) {
			let I = M.id(), D = M.drv(I), o = '';
			if (req?.args?.ready) {
				let a = readfile('/tmp/wf-q5g.at') ?? '', nb = D && D.parse && length(a) ? D.parse(a).nb : [], st = stat('/tmp/wf-q5g.at');
				if (!length(nb)) {
					let cl = json(readfile('/tmp/wf-modem.cell') ?? 'null')?.modem?.generic?.['cell-info'];
					if (cl) { nb = M.mmcells(cl).nb; st = stat('/tmp/wf-modem.cell'); }
				}
				return { nb: nb ?? [], ready: length(nb ?? []) > 0, age: st ? time() - st.mtime : null };
			}
			if (D && D.neigh) for (let c in D.neigh) o += M.at(c) + '\n';
			let nb = D && D.parse ? D.parse(o).nb : [];
			if (!length(nb)) {
				let cl = json(readfile('/tmp/wf-modem.cell') ?? 'null')?.modem?.generic?.['cell-info'];
				if (cl) nb = M.mmcells(cl).nb;
			}
			return { neigh: o, nb: nb };
		}
	},
	cellfull: {
		/* scansione completa delle celle (modem Quectel): fino a 3 minuti, internet cade */
		call: function() {
			return job("sh /usr/share/wrtfreedom/at.sh 'AT+QSCAN=3,1' 2>&1");
		}
	},
	modemreset: {
		call: function() {
			sh(MODEMRESET);
			return { ok: true };
		}
	},
	live: {
		/* tempo reale: solo letture di file del kernel, nessun processo avviato */
		args: { dev: 'dev', sqm: true, sqmh: true, wifi: true },
		call: function(req) {
			let d = '' + (req.args.dev ?? '');
			/* SQM (2.46): limiti attuali delle code CAKE (quelli che regola cake-autorate) per il grafico della pagina SQM, con lo
			   stesso orologio del Traffico. tc è un processo: lo fa sqmlive.sh, un giro a parte una volta al secondo, solo
			   finché l'app li chiede (si ferma 15 s dopo l'ultima richiesta). sqmh = anche gli ultimi minuti (grafico già pieno) */
			let sq = null, sqh = null;
			if (req.args.sqm) {
				let up = int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]));
				writefile('/tmp/wf-sqmlive.want', '' + up);
				let pid = trim(readfile('/tmp/wf-sqmlive.pid') ?? '');
				if (!length(pid) || !stat('/proc/' + pid))
					system('sh /usr/share/wrtfreedom/sqmlive.sh >/dev/null 2>&1 &');
				let kb = (n, u) => +n * ({ K: 1, M: 1000, G: 1000000 }[u] ?? 0.001);
				sq = {};
				for (let l in split(readfile('/tmp/wf-sqmlive') ?? '', '\n')) {
					let m = match(l, /^[0-9]+ ([A-Za-z0-9_.@-]+) ([0-9.]+)([KMG]?)bit/);
					if (m) sq[m[1]] = kb(m[2], m[3]);
				}
				if (req.args.sqmh) {
					sqh = [];
					for (let l in split(readfile('/tmp/wf-sqmlive.h') ?? '', '\n')) {
						let m = match(l, /^([0-9]+) ([A-Za-z0-9_.@-]+) ([0-9.]+)([KMG]?)bit/);
						if (m && +m[1] > up - 80) push(sqh, [+m[1], m[2], kb(m[3], m[4])]);
					}
				}
			}
			if (!match(d, /^[A-Za-z0-9_.@-]{1,32}$/))
				d = '';
			let st = readfile('/proc/stat') ?? '';
			let r = { t: +(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]), cpu: substr(st, 0, index(st, '\n')), temp: [] };
			if (length(d)) {
				r.rx = trim(readfile('/sys/class/net/' + d + '/statistics/rx_bytes') ?? '');
				r.tx = trim(readfile('/sys/class/net/' + d + '/statistics/tx_bytes') ?? '');
			}
			for (let z in (lsdir('/sys/class/thermal') ?? [])) {
				if (index(z, 'thermal_zone') != 0) continue;
				let t = trim(readfile('/sys/class/thermal/' + z + '/temp') ?? '');
				if (length(t)) push(r.temp, +t);
			}
			let mi = readfile('/proc/meminfo') ?? '';
			let mt = match(mi, /MemTotal:\s+(\d+)/), ma = match(mi, /MemAvailable:\s+(\d+)/);
			if (mt && ma) { r.mt = +mt[1]; r.ma = +ma[1]; }
			r.load = slice(split(trim(readfile('/proc/loadavg') ?? ''), ' '), 0, 3);
			/* Servizio VPN (2.43): contatori dei collegamenti accesi, per il widget sincronizzato con il Traffico */
			for (let n in (lsdir('/sys/class/net') ?? [])) if (match(n, /^wgo(ut|[1-5])$/)) {
				r.vpn = r.vpn ?? {};
				r.vpn[n] = [+trim(readfile('/sys/class/net/' + n + '/statistics/rx_bytes') ?? '0'), +trim(readfile('/sys/class/net/' + n + '/statistics/tx_bytes') ?? '0')];
			}
			/* Wi-Fi (2.48): contatori di ogni interfaccia Wi-Fi {ifname: [rx, tx]} per il grafico per rete (solo file del kernel) */
			if (req.args.wifi === true) for (let n in (lsdir('/sys/class/net') ?? [])) if (has('/sys/class/net/' + n + '/phy80211')) {
				r.wifi = r.wifi ?? {};
				r.wifi[n] = [+trim(readfile('/sys/class/net/' + n + '/statistics/rx_bytes') ?? '0'), +trim(readfile('/sys/class/net/' + n + '/statistics/tx_bytes') ?? '0')];
			}
			if (sq) r.sqm = sq;
			if (sqh) r.sqmh = sqh;
			return r;
		}
	},
	sys: {
		call: function() {
			return {
				stat: split(readfile('/proc/stat') ?? '', '\n')[0] + '\n',
				temp: join('', map(filter(sort(lsdir('/sys/class/thermal') ?? []), (z) => index(z, 'thermal_zone') == 0), (z) => readfile('/sys/class/thermal/' + z + '/temp') ?? ''))
			};
		}
	},
	neigh: {
		call: function() {
			return { out: sh('ip -4 neigh show 2>/dev/null') };
		}
	},
	routes: {
		call: function() {
			let o = sh('ip -4 route show 2>/dev/null; echo @@WF@@; ip -6 route show 2>/dev/null'), i = index(o, '@@WF@@\n');
			return i < 0 ? { v4: o, v6: '' } : { v4: substr(o, 0, i), v6: substr(o, i + 7) };
		}
	},
	ports: {
		/* porte di rete fisiche del router (anche switch DSA), con i nomi di /etc/board.json: WAN, LAN 1, LAN 2…
		   2.50: duplex, dispositivo collegato (peer {mac, ip, name}, n = indirizzi visti sulla porta: più di uno = switch),
		   max (velocità della porta da ethtool; senza, la più alta delle altre porte, guess) e slow + warn «cavo lento»
		   (10/100 Mbit/s su una porta gigabit; cable = anche il dispositivo arriva a 1000: è proprio il cavo) */
		call: function() {
			let R = portsbase(), PP = portpeers(), H = leases(), ARP = {}, top = 0;
			for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) { let p = split(trim(l), /[ \t]+/); if (length(p) >= 4 && okmac(p[3])) ARP[p[3]] = p[0]; }
			for (let x in R.list) if (x.carrier == '1' && +x.speed > top) top = +x.speed;
			/* velocità massima della porta e del dispositivo collegato: ethtool lo fa netx.uc eth in sottofondo
			   (/tmp/wf-ports.json, letto qui); di nuovo se manca una porta, se la velocità è cambiata o dopo un'ora */
			let EF = rjs('/tmp/wf-ports.json'), EP = EF?.ports ?? {}, need = !EF || time() - (EF.t ?? 0) > 3600;
			for (let x in R.list) {
				let b = '/sys/class/net/' + x.dev, sp = +x.speed, M = PP[x.dev] ?? [];
				x.duplex = x.carrier == '1' ? trim(readfile(b + '/duplex') ?? '') : '';
				if (length(M)) {
					let m = filter(M, (y) => length(H[y]?.name ?? ''))[0] ?? M[0];
					x.peer = { mac: m, ip: ARP[m] ?? H[m]?.ip ?? '', name: H[m]?.name ?? '', n: length(M) };
				}
				if (x.carrier != '1') continue;
				let slow = sp > 0 && sp < 1000, E = EP[x.dev], mx = E?.max ?? null;
				if (!E || E.sp != sp) need = true;
				x.max = mx ?? (top >= 1000 ? top : null); x.guess = mx == null;
				if (slow && x.max >= 1000) {
					x.slow = true; x.cable = (E?.lp ?? 0) >= 1000;
					x.warn = L('Cavo lento: ' + sp + ' Mbit/s su porta da ' + x.max, 'Slow cable: ' + sp + ' Mbit/s on a ' + x.max + ' port') +
						(x.cable ? L(' (il dispositivo arriva a ' + E.lp + ')', ' (the device supports ' + E.lp + ')') : '');
				}
				if (x.duplex == 'half') x.warn = (x.warn ? x.warn + ' · ' : '') + L('half duplex: cavo o presa difettosi', 'half duplex: faulty cable or socket');
			}
			let devs = map(filter(R.list, (x) => x.carrier == '1'), (x) => q(x.dev));
			if (need && length(devs) && time() - (stat('/tmp/wf-ports.run')?.mtime ?? 0) > 30) {
				writefile('/tmp/wf-ports.run', '');
				sh('( ucode ' + NETX + ' eth ' + join(' ', devs) + ' ) >/dev/null 2>&1 </dev/null &');
			}
			return R;
		}
	},
	qr: {
		/* text = testo libero; iface = sezione wifi-iface (2.48): il testo WIFI: lo prepara il router dalla configurazione,
		   con l'escape di \ ; , : " e T:nopass per le reti aperte (la password non passa dall'app) */
		args: { text: 'text', iface: 'iface' },
		call: function(req) {
			let t = (req.args && req.args.text) ? '' + req.args.text : '', ifs = '' + (req.args?.iface ?? '');
			if (length(ifs)) {
				let WL = ucfile('wireless');
				if (!match(ifs, /^[]A-Za-z0-9_@[-]{1,64}$/) || WL[ifs]?.['.type'] != 'wifi-iface') return { error: 'rete non valida' };
				t = wqr(WL[ifs]);
			}
			if (!length(t) || length(t) > 1200)
				return { error: 'testo non valido' };
			writefile('/tmp/.wf-qr', t);
			let svg = sh('qrencode -t SVG -m 0 -r /tmp/.wf-qr -o - 2>/dev/null');
			unlink('/tmp/.wf-qr');
			return { svg: svg };
		}
	},
	at: {
		args: { cmd: 'cmd' },
		call: function(req) {
			let c = (req.args && req.args.cmd) ? '' + req.args.cmd : '';
			if (!match(c, /^[Aa][Tt][ -~]*$/) || index(c, "'") >= 0 || length(c) > 200)
				return { error: 'comando non valido' };
			return { out: at(c) };
		}
	},
	log: {
		args: { kind: 'kind' },
		call: function(req) {
			let k = (req.args && req.args.kind) ? req.args.kind : 'sys';
			return { out: (k == 'kern') ? sh('dmesg 2>/dev/null | tail -n 300') : sh('logread -l 300 2>/dev/null') };
		}
	},
	diag: {
		args: { tool: 'tool', target: 'target', v6: true, via: 'via' },
		call: function(req) {
			let a = req.args ?? {}, t = a.target ?? '', six = a.v6 ? true : false;
			if (a.tool == 'speed') {
				/* Un Solo Test Di Velocità (2.55): speed.uc (uscita come speedtest-go, risultato salvato nel router);
				   via = collegamento del Servizio VPN (2.42) */
				if (spdbusy()) return { error: 'un test di velocità è già in corso', run: true };
				let c = spdcmd('' + (a.via ?? ''));
				return type(c) == 'object' ? c : job(c);
			}
			if (!okhost(t))
				return { error: 'indirizzo non valido' };
			if (a.tool == 'ping')
				return job((six ? 'ping -6' : 'ping -4') + ' -c 4 -W 2 ' + t);
			if (a.tool == 'trace')
				return job((six ? 'traceroute6' : 'traceroute') + ' -n -q 1 -w 2 -m 15 ' + t);
			if (a.tool == 'dns')
				return job('nslookup ' + (six ? '-type=AAAA ' : '') + t + ' 127.0.0.1');
			if (a.tool == 'arp') {
				/* interfaccia della rete di casa letta dal router (2.55; prima br-lan fisso) */
				let H = ubcall('network.interface', 'status', { interface: homenet().iface }) ?? {}, dv = '' + (H.l3_device ?? H.device ?? '');
				if (!match(dv, /^[A-Za-z0-9_.@-]{1,32}$/)) return { error: 'rete di casa non trovata' };
				return job('arping -c 3 -I ' + dv + ' ' + t);
			}
			return { error: 'strumento sconosciuto' };
		}
	},
	job: {
		call: function() {
			/* 2.64 B7: busy = un lavoro in corso (jobbusy, una regola sola: l'Assistente IA non ne lancia un altro) */
			return { out: readfile('/tmp/.wf-job') ?? '', busy: jobbusy() };
		}
	},
	jobstop: {
		/* Annulla del Test Di Velocità (2.38): ferma speedtest-go; il lavoro finisce con __FINE__ come sempre */
		call: function() {
			/* 2.55: anche il ripiego di Cloudflare (speed.uc scrive il processo in corso nel blocco) e niente salvataggio */
			sh('[ -d ' + SPDLK + ' ] && { touch ' + SPDLK + '/stop; kill $(cat ' + SPDLK + '/c 2>/dev/null) 2>/dev/null; }; killall speedtest-go 2>/dev/null; pkill -f speed.cloudflare.com 2>/dev/null; echo "## Annullato" >> /tmp/.wf-job');
			return { ok: true };
		}
	},
	adg: {
		args: { method: 'method', path: 'path', body: 'body' },
		call: function(req) {
			let a = req.args ?? {};
			return adgreq(a.method, a.path, a.body);
		}
	},
	xget: {
		/* stato delle funzioni sperimentali gestite fuori da uci */
		call: function() {
			let wed = trim(readfile('/sys/module/mt7915e/parameters/wed_enable') ?? '');
			return {
				wedmod: length(wed) > 0,
				wed: wed == 'Y' || wed == '1',
				wednext: length(filter(lsdir('/etc/modules.d') ?? [], (f) => index(f, 'mt7915e') >= 0 && index(readfile('/etc/modules.d/' + f) ?? '', 'wed_enable=Y') >= 0)) > 0,
				bbr: trim(readfile('/proc/sys/net/ipv4/tcp_congestion_control') ?? ''),
				bbravail: index(readfile('/proc/sys/net/ipv4/tcp_available_congestion_control') ?? '', 'bbr') >= 0 || stat('/lib/modules/' + trim(readfile('/proc/sys/kernel/osrelease') ?? '') + '/tcp_bbr.ko') != null,
				irqpkg: stat('/etc/init.d/irqbalance') != null,
				irq: ug('irqbalance', 'irqbalance', 'enabled') == '1',
				nlbw: stat('/usr/sbin/nlbw') != null,
				nlbwon: length(filter(lsdir('/etc/rc.d') ?? [], (f) => match(f, /^S[0-9]+nlbwmon$/))) > 0,
				wolbin: has('/usr/bin/etherwake') || has('/usr/sbin/etherwake') || has('/usr/bin/ether-wake') || has('/usr/sbin/ether-wake'),
				shaper: readfile('/etc/wrtfreedom/shaper.json') ?? ''
			};
		}
	},
	xset: {
		args: { name: 'name', on: true },
		call: function(req) {
			let n = '' + (req.args.name ?? ''), on = !!req.args.on, out = '';
			if (n == 'wed') {
				let f = trim(sh("ls /etc/modules.d/*mt7915e* 2>/dev/null | head -n 1"));
				if (!length(f)) return { error: 'driver MediaTek mt7915e non presente' };
				out = sh("sed -i 's/^mt7915e.*/mt7915e" + (on ? ' wed_enable=Y' : '') + "/' " + q(f) + " && cat " + q(f));
				return { ok: true, out: out, reboot: true };
			}
			if (n == 'bbr') {
				if (on) {
					sh('modprobe tcp_bbr 2>/dev/null');
					writefile('/etc/sysctl.d/90-wrtfreedom-bbr.conf', 'net.ipv4.tcp_congestion_control=bbr\n');
					out = sh('sysctl -w net.ipv4.tcp_congestion_control=bbr 2>&1');
				} else {
					unlink('/etc/sysctl.d/90-wrtfreedom-bbr.conf');
					out = sh('sysctl -w net.ipv4.tcp_congestion_control=cubic 2>&1');
				}
				return { ok: index(out, 'error') < 0 && index(out, 'Invalid') < 0, out: out };
			}
			if (n == 'irq') {
				if (stat('/etc/init.d/irqbalance') == null) return { error: 'manca il pacchetto irqbalance' };
				out = sh('uci set irqbalance.irqbalance.enabled=' + (on ? '1' : '0') + ' && uci commit irqbalance && /etc/init.d/irqbalance ' + (on ? 'enable; /etc/init.d/irqbalance restart' : 'stop; /etc/init.d/irqbalance disable') + ' 2>&1');
				return { ok: true, out: out };
			}
			return { error: 'funzione sconosciuta' };
		}
	},
	shaper: {
		/* limiti di velocità, priorità, fasce e Rallenta Per Un Po' per dispositivo, persona o Tutta La Casa Insieme:
		   regole nftables in fw4 (shapergen). shaper {} = si può usare? {can, why, sqm} e dalla 2.59 posti (max, used,
		   left), voci salvate con lo stato (list, shinfo) e meta dell'app: mai tc né code, anche con SQM acceso (le sue
		   regole restano come sono); can false con Flow Offloading acceso o senza firewall4. rules = tutte le voci (JSON,
		   come prima); dalla 2.59 add = una voce (shadd) e del = id di una voce, senza rimandare il resto. Più posti di
		   SHMAX = niente cambia, errore con used e max */
		args: { rules: 'rules', add: 'add', del: 'del' },
		call: function(req) {
			let C = devcan(), a = req.args ?? {}, now = time(), R;
			if (a.rules == null && a.add == null && a.del == null) return shinfo(C, now);
			if (a.rules != null) {
				try { R = json('' + a.rules); } catch (e) { return { error: 'regole non valide' }; }
				if (type(R) != 'array' || length(R) > 128) return { error: 'regole non valide' };
			}
			else {
				R = rjs(SHJSON);
				if (type(R) != 'array') R = [];
				if (a.del != null) {
					let d = '' + a.del, n0 = length(R);
					R = filter(R, (r) => type(r) != 'object' || r.id != d);
					if (length(R) == n0) return { error: 'voce non trovata' };
				}
				if (a.add != null) {
					let x = null;
					try { x = json('' + a.add); } catch (e) {}
					let O = shadd(R, x, now);
					if (type(O) == 'string') return { error: O };
					R = O;
				}
			}
			R = shnorm(R, now);
			let need = shapergen(R, false).need;
			if (need > SHMAX) return { error: 'troppe regole: ' + need + ' posti su ' + SHMAX, used: need, max: SHMAX, left: 0 };
			let e = shaperfile(R);
			if (e) return { error: e };
			sh('( fw4 reload; ucode ' + DEVUC + ' apply ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, rules: need, used: need, max: SHMAX, left: SHMAX - need, can: C.can, why: C.why };
		}
	},
	nlbw: {
		call: function() {
			return { out: sh('nlbw -c json -g mac 2>/dev/null') };
		}
	},
	wol: {
		args: { mac: 'mac' },
		call: function(req) {
			let m = '' + (req.args.mac ?? '');
			if (!match(m, /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/)) return { error: 'MAC non valido' };
			let b = trim(sh('command -v etherwake || command -v ether-wake'));
			if (!length(b)) return { error: 'manca il pacchetto etherwake' };
			/* interfaccia di casa: l3_device della prima rete accesa della zona di casa (niente br-lan fisso) */
			let F = ucfile('firewall'), hz = fwzones().home, nets = [], dev = '';
			for (let k in F) if (F[k]['.type'] == 'zone' && F[k].name == hz) nets = type(F[k].network) == 'array' ? F[k].network : split(F[k].network ?? '', ' ');
			let D = (ubcall('network.interface', 'dump') ?? {}).interface ?? [];
			for (let x in nets) for (let i in D) if (!length(dev) && i.interface == x && i.up) dev = i.l3_device ?? i.device ?? '';
			if (!match(dev, /^[A-Za-z0-9_.@-]{1,32}$/)) return { error: 'rete di casa non trovata' };
			return { ok: true, out: sh(b + ' -i ' + dev + ' ' + m + ' 2>&1') };
		}
	},
	adgstate: {
		call: function() {
			let installed = has('/etc/init.d/adguardhome') || has('/usr/bin/AdGuardHome') || has('/usr/sbin/AdGuardHome') || has('/opt/AdGuardHome/AdGuardHome');
			let A = ucfile('adguardhome'), yaml = '';
			for (let f in [ ug(A, 'config', 'config_file'), ug(A, 'config', 'config'), '/etc/adguardhome/adguardhome.yaml', '/etc/adguardhome.yaml' ])
				if (!length(yaml) && length(f) && has(f)) yaml = f;
			/* utenti nella configurazione: "users:" seguito da almeno un "name:" */
			let y = length(yaml) ? (readfile(yaml) ?? '') : '', ui = substr(y, 0, 6) == 'users:' ? 0 : index(y, '\nusers:');
			let configured = ui >= 0 && match(substr(y, ui, 400), /\n\s+-?\s*name:\s*\S/) != null;
			let sv = ubcall('service', 'list', { name: 'adguardhome' }) ?? {}, run = false;
			for (let k in ((sv.adguardhome ?? {}).instances ?? {})) if (sv.adguardhome.instances[k].running) run = true;
			if (!run && !installed) run = length(trim(sh('pidof AdGuardHome'))) > 0;
			/* mode (2.50): std = dnsmasq sulla 53 inoltra ad AdGuard, direct = AdGuard sulla 53 (adgmode), other, none */
			return { installed: installed, running: run, configured: configured, creds: stat(ADGCONF) != null, curl: has('/usr/bin/curl'), mode: adgmodeinfo().mode };
		}
	},
	adgsetup: {
		args: { user: 'user', pass: 'pass' },
		call: function(req) {
			let u = '' + (req.args.user ?? ''), p = '' + (req.args.pass ?? '');
			if (!match(u, /^[A-Za-z0-9._@-]{1,64}$/) || length(p) < 8 || !match(p, /^[^"\n]{8,128}$/))
				return { error: 'utente o password non validi' };
			writefile('/tmp/.wf-adgnew', u + ':' + p + '\n');
			sh('chmod 600 /tmp/.wf-adgnew');
			writefile('/tmp/.wf-adgset.json', sprintf('%J', { web: { ip: '0.0.0.0', port: '__WEB__' }, dns: { ip: '127.0.0.1', port: '__DNS__' }, username: u, password: p }));
			sh('chmod 600 /tmp/.wf-adgset.json');
			return job('sh /usr/share/wrtfreedom/adgsetup.sh');
		}
	},
	adglogout: {
		call: function() {
			unlink(ADGCONF);
			return { ok: true };
		}
	},
	adgcred: {
		args: { user: 'user', pass: 'pass' },
		call: function(req) {
			let u = '' + (req.args.user ?? ''), p = '' + (req.args.pass ?? '');
			if (!match(u, /^[^:"\n]{1,64}$/) || !match(p, /^[^"\n]{1,128}$/))
				return { error: 'non valido' };
			sh('mkdir -p /etc/wrtfreedom; chmod 700 /etc/wrtfreedom');
			writefile(ADGCONF, u + ':' + p + '\n');
			sh('chmod 600 ' + ADGCONF);
			return { ok: true };
		}
	},
	pkgs: {
		args: { kind: 'kind', force: true, ready: true },
		call: function(req) {
			let k = req.args.kind ?? 'inst';
			if (k == 'up') {
				/* l'elenco aggiornabili legge gli indici dei repository: pesante, quindi lo teniamo 30 minuti.
				   ready (Assistente IA): solo l'ultimo elenco già pronto con la sua età, mai il controllo qui */
				let f = '/tmp/.wf-pkgup', st = stat(f);
				if (req.args.ready)
					return st ? { out: readfile(f) ?? '', cached: true, age: time() - st.mtime } : { none: true };
				if (!req.args.force && st && time() - st.mtime < 1800)
					return { out: readfile(f) ?? '', cached: true };
				let o = sh(has('/usr/bin/apk') || has('/sbin/apk') ? 'apk list --upgradable 2>/dev/null' : 'opkg list-upgradable 2>/dev/null');
				writefile(f, o);
				return { out: o };
			}
			if (k == 'av')
				return { out: sh('apk list 2>/dev/null | grep -v installed | head -n 4000') };
			/* installati: letti direttamente dal database, senza aprire gli indici */
			if (stat('/lib/apk/db/installed'))
				return { out: sh("awk 'function o(){if(p!=\"\")printf \"%s-%s %s {%s} (%s) [installed]\\n\",p,v,a,g,l;p=v=a=g=l=\"\"} /^P:/{p=substr($0,3)} /^V:/{v=substr($0,3)} /^A:/{a=substr($0,3)} /^o:/{g=substr($0,3)} /^L:/{l=substr($0,3)} /^$/{o()} END{o()}' /lib/apk/db/installed") };
			return { out: sh('apk list --installed 2>/dev/null') };
		}
	},
	pkgmissing: {
		/* pacchetti aggiunti prima dell'aggiornamento del firmware e ora mancanti */
		call: function() {
			let saved = readfile('/etc/wrtfreedom/pkgs.txt'), sf = readfile('/etc/wrtfreedom/pkgs.fw');
			if (saved == null) { sh(PKGSNAP); return { list: [], saved: false }; }
			/* firmware non cambiato: niente da reinstallare, l'elenco segue anche le modifiche fatte a mano */
			if (sf != null && trim(sf) == trim(fwver())) { sh(PKGSNAP); return { list: [], saved: true }; }
			let H = pkgHave(), out = [];
			for (let l in split(saved, '\n')) {
				let n = trim(replace(l, /[<>=~@].*$/, ''));
				if (length(n) && !H[n] && match(n, /^[A-Za-z0-9._+-]+$/)) push(out, n);
			}
			/* tutto a posto dopo l'aggiornamento: l'elenco riparte dal firmware nuovo */
			if (!length(out)) sh('rm -f /etc/wrtfreedom/pkgs.fw; ' + PKGSNAP);
			return { list: out, saved: true };
		}
	},
	pkgdo: {
		args: { action: 'action', name: 'name' },
		call: function(req) {
			let a = req.args.action, n = '' + (req.args.name ?? '');
			if (a != 'update' && a != 'cakeinst' && a != 'cakedel' && (length(n) > 400 || !match(n, /^[A-Za-z0-9._+ -]+$/)))
				return { error: 'nome non valido' };
			if (a == 'cakeinst') return job('sh /usr/share/wrtfreedom/cakeinst.sh');
			if (a == 'cakedel') return job('sh /usr/share/wrtfreedom/cakedel.sh');
			/* apk (OpenWrt 25) oppure opkg (versioni precedenti); dopo ogni modifica salva l'elenco dei pacchetti aggiunti */
			let apk = length(trim(sh('command -v apk 2>/dev/null'))) > 0, snap = '; ' + PKGSNAP;
			if (a == 'update') return job(apk ? 'apk update' : 'opkg update');
			if (a == 'add') return job(pkgaddc(n, apk));
			if (a == 'del') return job((apk ? 'apk del ' : 'opkg remove ') + n + snap);
			if (a == 'upgrade') return job((apk ? 'apk upgrade ' : 'opkg upgrade ') + n);
			if (a == 'addfile') return job((apk ? 'apk add --allow-untrusted /tmp/wf-pkg.apk' : 'opkg install /tmp/wf-pkg.apk') + '; rm -f /tmp/wf-pkg.apk' + snap);
			return { error: 'azione sconosciuta' };
		}
	},
	backup: {
		/* backup completo verificato (backup.sh, 2.40): sysupgrade -l più quello che manca, scheda e pacchetti */
		call: function() {
			if (has('/usr/share/wrtfreedom/backup.sh')) {
				let r = js('sh /usr/share/wrtfreedom/backup.sh create /tmp/backup.tar.gz');
				return r ?? { error: 'backup non creato' };
			}
			sh('rm -f /tmp/backup.tar.gz; sysupgrade -b /tmp/backup.tar.gz >/dev/null 2>&1');
			let s = stat('/tmp/backup.tar.gz');
			return { ok: s != null, size: s ? s.size : 0, list: sh('sysupgrade -l 2>/dev/null') };
		}
	},
	restore: {
		/* app vecchie: tutto il file e riavvio (le nuove usano bakrestore, per categorie e con il ritorno automatico) */
		call: function() {
			if (!stat('/tmp/backup.tar.gz'))
				return { error: 'file mancante' };
			sh('(sleep 2; sysupgrade -r /tmp/backup.tar.gz && reboot) >/dev/null 2>&1 &');
			return { ok: true };
		}
	},
	bakinfo: {
		/* il file caricato è un backup valido? cosa contiene, per categoria, e da che router viene */
		call: function() {
			return js('sh /usr/share/wrtfreedom/backup.sh inspect /tmp/backup.tar.gz') ?? { error: 'file non leggibile' };
		}
	},
	bakrestore: {
		/* ripristino delle categorie scelte, senza riavvio; senza bakconfirm entro 120 s torna tutto com'era */
		args: { cats: 'cats' },
		call: function(req) {
			let c = '' + (req.args.cats ?? '');
			if (!match(c, /^[a-z]+(,[a-z]+){0,15}$/)) return { error: 'categorie non valide' };
			if (!stat('/tmp/backup.tar.gz')) return { error: 'file mancante' };
			return job('sh /usr/share/wrtfreedom/backup.sh restore /tmp/backup.tar.gz ' + c + ' 2>&1');
		}
	},
	bakconfirm: {
		call: function() {
			return js('sh /usr/share/wrtfreedom/backup.sh confirm') ?? { ok: true };
		}
	},
	bakpkgs: {
		/* pacchetti del backup che ora mancano (da reinstallare) */
		call: function() {
			return { list: filter(split(trim(sh('sh /usr/share/wrtfreedom/backup.sh pkgs /tmp/backup.tar.gz')), '\n'), length) };
		}
	},
	fwcheck: {
		call: function() {
			let s = stat('/tmp/firmware.bin');
			if (!s) return { error: 'file mancante' };
			return { size: s.size, test: sh('sysupgrade -T /tmp/firmware.bin 2>&1; echo "exit=$?"'), sha: trim(sh("sha256sum /tmp/firmware.bin | cut -d' ' -f1")) };
		}
	},
	fwflash: {
		args: { keep: true, force: true },
		call: function(req) {
			let o = (req.args.keep ? '' : '-n ') + (req.args.force ? '-F ' : '');
			sh('(sleep 2; sysupgrade ' + o + '/tmp/firmware.bin) >/dev/null 2>&1 &');
			return { ok: true };
		}
	},
	factory: {
		call: function() {
			sh('(sleep 2; firstboot -y && reboot) >/dev/null 2>&1 &');
			return { ok: true };
		}
	},
	cert: {
		args: { domain: 'domain' },
		call: function(req) {
			let d = '' + (req.args.domain ?? '');
			if (!okhost(d)) return { error: 'dominio non valido' };
			let f = '/etc/ssl/acme/' + d + '.crt';
			if (!stat(f)) return { present: false };
			return { present: true, info: sh('openssl x509 -in ' + f + ' -noout -subject -issuer -dates -serial -fingerprint -sha256 2>/dev/null') };
		}
	},
	certdo: {
		args: { action: 'action' },
		call: function(req) {
			if (req.args.action == 'renew')
				return job('/etc/init.d/acme renew; sleep 2; logread -l 30 | grep -i acme');
			return { error: 'azione sconosciuta' };
		}
	},
	ddnslog: {
		args: { section: 'section' },
		call: function(req) {
			let s = '' + (req.args.section ?? '');
			if (!match(s, /^[A-Za-z0-9_]{1,64}$/)) return { error: 'non valido' };
			return { log: sh('tail -n 40 /var/log/ddns/' + s + '.log 2>/dev/null'), ip: trim(readfile('/var/run/ddns/' + s + '.ip') ?? ''), upd: trim(readfile('/var/run/ddns/' + s + '.update') ?? ''),
				/* ddns-scripts scrive nel .update i secondi dall'accensione, non una data: up = accensione attuale (2.40) */
				up: int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])) };
		}
	},
	ddnsdo: {
		args: { section: 'section' },
		call: function(req) {
			let s = '' + (req.args.section ?? '');
			if (!match(s, /^[A-Za-z0-9_]{0,64}$/)) return { error: 'non valido' };
			if (length(s))
				unlink('/var/run/ddns/' + s + '.update');
			else
				sh('rm -f /var/run/ddns/*.update');
			sh('(/etc/init.d/ddns restart) >/dev/null 2>&1 </dev/null &');
			return { ok: true };
		}
	},
	pubip: {
		/* IP pubblico della linea vera (2.53, mai quello della VPN in uscita): IP pubblico sulla linea = quello, subito;
		   linea con un indirizzo privato (CGNAT o un altro router) = l'ultimo chiesto fuori casa da svc.uc pubip con la
		   richiesta che esce dalla linea (curl --interface), rinnovato in sottofondo dopo 10 minuti o se la linea cambia.
		   { ip ('' = non ancora letto), src line|web, cgnat, line (IP della linea), ifc, pending } */
		call: function() {
			let Ln = lineinfo();
			if (!Ln || !length(Ln.ip)) return { ip: '', src: 'none', cgnat: false, line: '', ifc: Ln?.ifc ?? '' };
			if (!Ln.priv) return { ip: Ln.ip, src: 'line', cgnat: false, line: Ln.ip, ifc: Ln.ifc };
			let P = rjs('/tmp/wf-pubip.json') ?? {}, same = P.line == Ln.ip, fresh = same && time() - (P.t ?? 0) < 600;
			if (!fresh && !has('/tmp/wf-svc.pubip.lock')) svcbg('pubip');
			return { ip: same ? (P.ip ?? '') : '', src: 'web', cgnat: true, line: Ln.ip, ifc: Ln.ifc, t: P.t ?? 0, pending: !fresh };
		}
	},
	adgcat: {
		call: function() {
			let j = js('uclient-fetch -q -T 20 -O - https://adguardteam.github.io/HostlistsRegistry/assets/filters.json 2>/dev/null');
			let out = [], groups = [];
			if (j && j.filters)
				for (let f in j.filters)
					if (!f.deprecated)
						push(out, { n: f.name, u: f.downloadUrl ?? ('https://adguardteam.github.io/HostlistsRegistry/assets/filter_' + f.filterId + '.txt'), g: f.groupId ?? 0, r: f.rulesCount ?? f.rules_count ?? 0, d: substr('' + (f.description ?? ''), 0, 160) });
			if (j && j.groups)
				for (let g in j.groups)
					push(groups, { id: g.groupId, n: g.groupName });
			return { list: out, groups: groups, error: (j && j.filters) ? null : 'catalogo non raggiungibile: il router è collegato a internet?' };
		}
	},
	adgmode: {
		/* AdGuard risponde ai dispositivi (2.50). get = {mode std|direct|other|none, aport, dport, bind, ddr, run, pend,
		   until, busy, st, msg, fb, fbon, vpnp, warn}; direct = AdGuard sulla 53 (adgmode.sh in sottofondo: copia, cambio,
		   verifica, poi {confirm: 120}: senza confirm entro 120 s torna tutto com'era); confirm; back = annulla il cambio in
		   attesa oppure torna allo schema std. handle_ddr non si tocca (resta false: VPN Parziale) */
		args: { action: 'action' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), I = adgmodeinfo(), J = rjs('/tmp/wf-adgmode.json') ?? {};
			/* stato valido solo se recente: lucchetto o «run» più vecchi di 300 s = giro interrotto (adgmode.sh check
			   rimette la copia), file vecchi tolti */
			let now = time(), lk = stat('/tmp/wf-adgmode.lock'), lkok = lk != null && now - lk.mtime < 300;
			let busy = (lkok || J.st == 'run') && now - (J.t ?? 0) < 300;
			let pend = has('/tmp/wf-adgmode.pend') && (J.until ?? 0) > now && lkok;
			if (!lkok) { unlink('/tmp/wf-adgmode.pend'); if (lk) rmdir('/tmp/wf-adgmode.lock'); }
			if (J.st == 'run' && !busy) { J.st = 'err'; J.msg = L('Cambio interrotto', 'Change interrupted'); wjs('/tmp/wf-adgmode.json', J); }
			/* VPN Parziale (2.52): dispositivi della VPN Per Fuori Casa con il Tunnel Parziale (full=0), che usano il DNS di casa
			   per il nome DDNS: la scoperta automatica del DNS (handle_ddr) resta spenta */
			let vp = length(filter(wgpeers(null, null, null), (p) => !p.full)) > 0;
			let warn = vp ? L('VPN Parziale: i dispositivi della VPN Per Fuori Casa usano il DNS di casa. Alcune funzioni di scoperta automatica del DNS restano spente',
				'Partial VPN: Away From Home VPN devices use the home DNS. Some automatic DNS discovery features stay off') : null;
			let bg = (x) => { wjs('/tmp/wf-adgmode.json', { st: 'run', msg: '', t: time(), until: 0 }); sh('( sh ' + ADGM + ' ' + x + ' ) >/dev/null 2>&1 </dev/null &'); };
			if (a == 'get')
				return { mode: I.mode, aport: I.aport ?? null, dport: I.dport ?? null, bind: I.bind ?? [], ddr: I.ddr ?? false, run: I.mode != 'none' && adgrunning(),
					pend: pend, until: pend ? (J.until ?? 0) : 0, busy: busy, st: J.st ?? '', msg: J.msg ?? '', t: J.t ?? 0,
					fb: I.fb != null, fbon: ug('wrtfreedom', 'dnsfb', 'on') == '1', vpnp: vp, warn: warn };
			if (a == 'confirm') {
				if (!pend) return { error: 'niente da confermare' };
				writefile('/tmp/wf-adgmode.ok', '');
				return { ok: true };
			}
			if (a == 'back') {
				if (pend) { writefile('/tmp/wf-adgmode.no', ''); return { ok: true }; }
				if (busy) return { error: 'cambio già in corso' };
				if (I.mode != 'direct') return { error: 'AdGuard non risponde direttamente ai dispositivi' };
				bg('back');
				return { ok: true, started: true };
			}
			if (a != 'direct') return { error: 'azione non valida' };
			if (busy || pend) return { error: 'cambio già in corso' };
			if (I.fb) return { error: 'DNS di riserva in uso: AdGuard non risponde' };
			if (I.mode == 'direct') return { error: 'AdGuard risponde già ai dispositivi' };
			if (I.mode != 'std') return { error: 'schema del DNS non riconosciuto: serve dnsmasq sulla 53 che inoltra ad AdGuard' };
			if (!adgrunning()) return { error: 'AdGuard Home non è avviato' };
			bg('direct');
			return { ok: true, confirm: 120, warn: warn };
		}
	},
	dnsfb: {
		/* DNS di riserva (2.50): con on, notify.sh ogni minuto (adgmode.sh check) controlla AdGuard; se non risponde il DNS
		   di casa passa ai server dell'operatore e torna ad AdGuard quando risponde (eventi cron_adg_down / cron_adg_up).
		   get = {on, active, since, mode, avail} */
		args: { action: 'action', on: true },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), fb = adgfb();
			if (a == 'get') {
				let I = adgmodeinfo();
				return { on: ug('wrtfreedom', 'dnsfb', 'on') == '1', active: fb != null, since: fb ? +(fb.T ?? 0) : null, mode: I.mode, avail: I.mode == 'std' || I.mode == 'direct' };
			}
			if (a != 'set' || type(req.args.on) != 'bool') return { error: 'azione non valida' };
			cfgensure();
			sh('uci -q get wrtfreedom.dnsfb >/dev/null || uci set wrtfreedom.dnsfb=dnsfb; uci set wrtfreedom.dnsfb.on=' + (req.args.on ? '1' : '0') + '; uci commit wrtfreedom');
			/* spento durante la riserva: si torna ad AdGuard appena risponde (il controllo continua finché serve) */
			return { ok: true, on: req.args.on, active: fb != null };
		}
	},
	nettest: {
		/* «La Mia Rete È A Posto?» (2.50): netx.uc test in sottofondo. Risposta {run, t, end, ok, items [{id, ok, text, act}]}
		   (ok null = informazione). Un test finito da meno di 60 s si rimanda com'è (again: true = nuovo test) */
		args: { again: true },
		call: function(req) {
			let R = rjs('/tmp/wf-nettest.json'), now = time();
			if (R?.run && now - (R.t ?? 0) < 120) return R;
			if (R && !R.run && now - (R.end ?? 0) < 60 && req.args.again !== true) return R;
			wjs('/tmp/wf-nettest.json', { run: true, t: now, items: [] });
			sh('( ucode ' + NETX + ' test ) >/dev/null 2>&1 </dev/null &');
			return { run: true, t: now, items: [] };
		}
	},
	ifctl: {
		/* Riavvia, spegne o accende una rete (2.50), sempre in sottofondo: il telefono collegato da quella rete non
		   resta a metà. restart = ifdown, 2 s, ifup; down = ifdown con ritorno: se entro 90 s l'app non manda keep (era la
		   rete da cui è collegata e non risponde più) la rete si riaccende da sola; up = ifup. 2.64 B7 (Assistente IA): down con
		   secs = ritorno con bakarm 'ifc' (ifup dopo secs senza confirm, anche dopo un riavvio); confirm, back */
		args: { iface: 'iface', action: 'action', secs: 0 },
		call: function(req) {
			let i = '' + (req.args.iface ?? ''), a = '' + (req.args.action ?? ''), N = ucfile('network') ?? {}, f = '/tmp/wf-ifdown.' + i;
			if (a == 'confirm') return bakconfirm('ifc');
			if (a == 'back') return bakback('ifc', L('↩️ Rete del router: riaccesa', '↩️ Router network: back on'));
			if (!match(i, /^[A-Za-z0-9_]{1,15}$/) || i == 'loopback' || N[i]?.['.type'] != 'interface') return { error: 'rete non trovata' };
			if (a == 'restart') { sh('( sleep 1; ifdown ' + i + '; sleep 2; ifup ' + i + ' ) >/dev/null 2>&1 </dev/null &'); return { ok: true }; }
			/* rete riaccesa a mano mentre aspetta il ritorno (ifc) della stessa rete: il cambio è finito, niente più barra */
			if (a == 'up') { unlink(f); if (bakpend('ifc') && trim(readfile(bakdir('ifc') + '/iface') ?? '') == i) bakconfirm('ifc'); sh('( sleep 1; ifup ' + i + ' ) >/dev/null 2>&1 </dev/null &'); return { ok: true }; }
			if (a == 'down' && +(req.args.secs ?? 0) > 0) {
				let secs = hisecs(req.args.secs), e = bakarm('ifc', [], [], 'ifup ' + i, secs, L('↩️ Rete ' + i + ': nessuna conferma entro ' + secs + ' s, riaccesa', '↩️ Network ' + i + ': no confirmation within ' + secs + ' s, back on'));
				if (e !== true) return e;
				writefile(bakdir('ifc') + '/iface', i);
				sh('( sleep 1; ifdown ' + i + ' ) >/dev/null 2>&1 </dev/null &');
				return { ok: true, back: secs, pend: secs };
			}
			if (a == 'down') {
				writefile(f, '' + time());
				sh('( sleep 1; ifdown ' + i + '; sleep 90; [ -f ' + f + ' ] && { rm -f ' + f + '; ifup ' + i + '; } ) >/dev/null 2>&1 </dev/null &');
				return { ok: true, back: 90 };
			}
			if (a == 'keep') { if (!has(f)) return { error: 'niente da confermare' }; unlink(f); return { ok: true }; }
			return { error: 'azione non valida' };
		}
	},
	adglevel: {
		/* Livelli di protezione (2.50): base | famiglia | massima | personale (= nessun cambio). Senza person: liste del
		   catalogo e filtri di tutta la casa; con person (sezione «person»): client AdGuard con i MAC della persona e i
		   filtri del livello (le liste restano di tutta la casa). Il client per persona funziona solo con lo schema
		   diretto (AdGuard vede i dispositivi): altrimenti warn. Lavoro: netx.uc level, esito in st */
		args: { action: 'action', level: 'level', person: 'person' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), W = ucfile('wrtfreedom'), I = adgmodeinfo(), S = rjs('/tmp/wf-adglevel.json');
			let direct = I.mode == 'direct', note = direct ? null : L('Per persona funziona solo con «AdGuard Risponde Ai Dispositivi»: ora AdGuard vede solo il router',
				'Per person it only works with «AdGuard Answers Devices»: AdGuard now only sees the router');
			if (a == 'get') {
				let LV = {}, P = [];
				for (let k in ADGLV) LV[k] = ADGLV[k] ? { sb: ADGLV[k].sb, par: ADGLV[k].par, ss: ADGLV[k].ss, lists: map(ADGLV[k].lists, (x) => ({ n: x[1], u: ADGLU(x[0]) })) } : null;
				for (let k in W) if (W[k]['.type'] == 'person') push(P, { id: k, name: W[k].name ?? '', level: W[k].adglevel ?? 'personale', n: length(filter(vpnarr(W[k].mac), okmac)) });
				return { level: ug(W, 'adg', 'level') || 'personale', persons: P, levels: LV, direct: direct, note: note, creds: has(ADGCONF), st: S };
			}
			if (a != 'set') return { error: 'azione non valida' };
			let lv = '' + (req.args.level ?? ''), pid = '' + (req.args.person ?? ''), pe = null;
			if (!exists(ADGLV, lv)) return { error: 'livello non valido' };
			if (length(pid)) {
				if (!match(pid, /^p_[a-z0-9]{1,16}$/) || W[pid]?.['.type'] != 'person') return { error: 'persona non trovata' };
				pe = { id: pid, name: W[pid].name ?? pid, macs: filter(vpnarr(W[pid].mac), okmac) };
				if (!length(pe.macs)) return { error: 'la persona non ha dispositivi' };
			}
			if (ADGLV[lv] && !has(ADGCONF)) return { error: 'credenziali di AdGuard mancanti' };
			if (S?.st == 'run' && time() - (S.t ?? 0) < 120) return { error: 'livello già in applicazione' };
			cfgensure();
			sh(pe ? uset('wrtfreedom', pid, 'adglevel', lv) + 'uci commit wrtfreedom' : 'uci -q get wrtfreedom.adg >/dev/null || uci set wrtfreedom.adg=adg; ' + uset('wrtfreedom', 'adg', 'level', lv) + 'uci commit wrtfreedom');
			if (!ADGLV[lv]) return { ok: true, level: lv };
			let X = ADGLV[lv];
			wjs('/tmp/wf-adglevel.req', { level: lv, sb: X.sb, par: X.par, ss: X.ss, person: pe, lists: pe ? [] : map(X.lists, (x) => ({ n: x[1], u: ADGLU(x[0]) })) });
			wjs('/tmp/wf-adglevel.json', { st: 'run', msg: '', t: time(), level: lv, person: pid || null });
			sh('( ucode ' + NETX + ' level ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, started: true, level: lv, warn: pe && !direct ? note : null };
		}
	},
	adgtop: {
		/* Chi Usa Il DNS (2.50): client e domini bloccati dalla API di AdGuard (netx.uc top in sottofondo, al massimo ogni
		   5 minuti). Con lo schema std risponde {same: true}: AdGuard vede tutto dal router */
		call: function() {
			let I = adgmodeinfo(), now = time();
			if (I.mode != 'direct') return { same: true, mode: I.mode };
			let C = rjs('/tmp/wf-adgtop.json'), r = +(trim(readfile('/tmp/wf-adgtop.run') ?? '0')), run = now - r < 60;
			if (!run && (!C || now - (C.t ?? 0) > 300)) {
				writefile('/tmp/wf-adgtop.run', '' + now); run = true;
				sh('( ucode ' + NETX + ' top ) >/dev/null 2>&1 </dev/null &');
			}
			return C ? { ...C, run: run, mode: I.mode } : { run: true, mode: I.mode };
		}
	},
	weekly: {
		/* Riepilogo Settimanale (2.50): riga del crontab «# wf:weekly» (cron.sh weekly). get = {on, day, hour, tg};
		   set {on, day 0…6 (0 = domenica), hour 0…23}; send = adesso. 2.60: anche senza bot (riga negli Eventi, categoria
		   sys, per la notifica del telefono; con il bot anche su Telegram) */
		args: { action: 'action', on: true, day: 0, hour: 0, ai: true },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), c = tgconf(), tg = length(c.token) > 0 && length(c.chat) > 0, ai = ug('wrtfreedom', 'ai', 'weekly') == '1';
			if (a == 'get') {
				for (let l in split(readfile('/etc/crontabs/root') ?? '', '\n')) {
					let m = match(l, /^([0-9]+) ([0-9]+) \* \* ([0-6]) .*# wf:weekly$/);
					if (m) return { on: true, day: +m[3], hour: +m[2], tg: tg, ai: ai };
				}
				return { on: false, day: 0, hour: 9, tg: tg, ai: ai };
			}
			/* Con Il Consiglio Dell'IA (2.62, wrtfreedom.ai.weekly): da solo o insieme a on, day, hour */
			if (a == 'set' && req.args.ai != null) {
				if (type(req.args.ai) != 'bool') return { error: 'azione non valida' };
				ai = req.args.ai;
				cfgensure();
				sh('uci set wrtfreedom.ai=ai; uci set wrtfreedom.ai.weekly=' + (ai ? '1' : '0') + '; uci commit wrtfreedom');
				if (req.args.on == null) return { ok: true, ai: ai };
			}
			/* 2.62: staccato da rpcd (nuova sessione), il metodo torna subito */
			if (a == 'send') {
				detach('weekly', 'sh /usr/share/wrtfreedom/cron.sh weekly >/dev/null 2>&1');
				return { ok: true };
			}
			if (a != 'set' || type(req.args.on) != 'bool') return { error: 'azione non valida' };
			if (!req.args.on) { cronline('weekly', null); return { ok: true, on: false, ai: ai }; }
			let d = req.args.day ?? 0, h = req.args.hour ?? 9;
			if (type(d) != 'int' || type(h) != 'int' || d < 0 || d > 6 || h < 0 || h > 23) return { error: 'giorno o ora non validi' };
			cronline('weekly', '0 ' + h + ' * * ' + d + ' sh /usr/share/wrtfreedom/cron.sh weekly');
			return { ok: true, on: true, day: d, hour: h, tg: tg, ai: ai };
		}
	},
	monthly: {
		/* Consumo Del Mese Su Telegram (2.59): riga del crontab «# wf:monthly» (cron.sh monthly <quanti>), il giorno 1
		   all'ora scelta, con i primi dispositivi del mese finito (stessi contatori di Consumo Dei Dispositivi, dev.uc).
		   get = {on, hour, top, tg}; set {on, hour 0…23, top 1…10}; send = adesso (dal giorno 2 il mese in corso fino a oggi) */
		args: { action: 'action', on: true, hour: 0, top: 0 },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), c = tgconf(), tg = length(c.token) > 0 && length(c.chat) > 0;
			if (a == 'get') {
				for (let l in split(readfile('/etc/crontabs/root') ?? '', '\n')) {
					let m = match(l, /^0 ([0-9]+) 1 \* \* .* monthly ([0-9]+) # wf:monthly$/);
					if (m) return { on: true, hour: +m[1], top: +m[2], tg: tg };
				}
				return { on: false, hour: 9, top: 5, tg: tg };
			}
			if (a == 'send') {
				if (!tg) return { error: 'bot Telegram non collegato' };
				let n = req.args.top ?? 5;
				if (type(n) != 'int' || n < 1 || n > 10) return { error: 'numero non valido (1…10)' };
				sh('( sh /usr/share/wrtfreedom/cron.sh monthly ' + n + ' ) >/dev/null 2>&1 </dev/null &');
				return { ok: true };
			}
			if (a != 'set' || type(req.args.on) != 'bool') return { error: 'azione non valida' };
			if (!req.args.on) { cronline('monthly', null); return { ok: true, on: false }; }
			let h = req.args.hour ?? 9, n = req.args.top ?? 5;
			if (type(h) != 'int' || type(n) != 'int' || h < 0 || h > 23 || n < 1 || n > 10) return { error: 'ora o numero non validi' };
			cronline('monthly', '0 ' + h + ' 1 * * sh /usr/share/wrtfreedom/cron.sh monthly ' + n);
			return { ok: true, on: true, hour: h, top: n, tg: tg };
		}
	},
	months: {
		/* Mesi Precedenti (2.59, nlbwconf): get {p?} = periodo e mesi tenuti, «Conserva Dopo Il Riavvio» (keep), elenco
		   dei periodi (list: p = inizio, cur = in corso, rx, tx, n dispositivi, top = il primo) o, con p, i dispositivi di
		   quel periodo (devs: mac, name, rx, tx). Dati di netx.uc nlbw (in /tmp, rifatti in sottofondo se più vecchi di 10
		   minuti: run true mentre lavora). refresh = rilegge adesso. keep {on} = sposta i dati (in sottofondo, moving); off
		   solo se la cartella permanente l'ha messa il pacchetto. start {day 1…28} = giorno d'inizio dei periodi (in
		   sottofondo, moving) */
		args: { action: 'action', p: 'p', on: true, day: 0 },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), C = nlbwconf(), now = time(), mv = stat(NLBWMV), rs = stat(NLBWRUN);
			let moving = mv != null && now - mv.mtime < 300, run = rs != null && now - rs.mtime < 120;
			let nlbwgo = () => { if (!run && C.pkg && C.on && !moving) { writefile(NLBWRUN, '' + now); sh('( ucode ' + NETX + ' nlbw ) >/dev/null 2>&1 </dev/null &'); run = true; } };
			if (a == 'start') {
				if (!C.pkg || C.sec == null) return { error: 'Statistiche Del Traffico non installate' };
				let d = req.args.day;
				if (type(d) != 'int' || d < 1 || d > 28) return { error: 'giorno non valido (1…28)' };
				if (moving) return { error: 'spostamento già in corso' };
				if (C.interval == '' + d) return { ok: true, interval: C.interval };
				cfgensure();
				sh('( ' + nlbwstart(C.sec, d) + ' ) >/dev/null 2>&1 </dev/null &');
				return { ok: true, run: true, interval: '' + d };
			}
			if (a == 'keep') {
				if (!C.pkg || C.sec == null) return { error: 'Statistiche Del Traffico non installate' };
				if (type(req.args.on) != 'bool') return { error: 'azione non valida' };
				if (moving) return { error: 'spostamento già in corso' };
				if (req.args.on == C.keep) return { ok: true, keep: C.keep };
				let W = ucfile('wrtfreedom'), prev = ug(W, 'nlbw', 'prev'), to = NLBWDIR;
				if (req.args.on) {
					/* copia della configurazione e cartella di prima (una volta), per il ritorno */
					cfgensure();
					sh(NLBWBAK + (length(prev) ? '' : 'uci set wrtfreedom.nlbw=nlbw; ' + uset('wrtfreedom', 'nlbw', 'prev', C.dir) + 'uci commit wrtfreedom'));
				}
				/* off: solo la cartella che ha messo il pacchetto (prev scritto da keep on); quella scelta dall'utente resta */
				else if (!length(prev) || prev == NLBWDIR || C.dir != NLBWDIR) return { error: 'cartella dei dati scelta da te: non si sposta' };
				else to = prev;
				sh('( ' + nlbwmove(C.sec, C.dir, to) + ' ) >/dev/null 2>&1 </dev/null &');
				return { ok: true, run: true, keep: req.args.on };
			}
			if (a == 'refresh') { nlbwgo(); return { ok: true, run: run }; }
			if (a != 'get') return { error: 'azione non valida' };
			let D = rjs(NLBWM), H = leases(), p = '' + (req.args.p ?? '');
			if (!D || now - (D.t ?? 0) > 600) nlbwgo();
			let r = { pkg: C.pkg, on: C.on, interval: C.interval, gens: C.gens, commit: C.commit, keep: C.keep, moving: moving, run: run, t: D?.t ?? null, ok: D?.ok ?? null };
			if (length(p)) {
				let M = filter(D?.list ?? [], (x) => x.p == p)[0];
				if (!M) return { ...r, error: 'periodo non trovato' };
				return { ...r, p: M.p, cur: M.cur, rx: M.rx, tx: M.tx, devs: map(M.devs ?? [], (x) => ({ mac: x[0], name: H[x[0]]?.name ?? '', rx: x[1], tx: x[2] })) };
			}
			r.list = map(D?.list ?? [], (x) => ({ p: x.p, cur: x.cur, rx: x.rx, tx: x.tx, n: length(x.devs ?? []),
				top: length(x.devs ?? []) ? { mac: x.devs[0][0], name: H[x.devs[0][0]]?.name ?? '', b: x.devs[0][1] + x.devs[0][2] } : null }));
			return r;
		}
	},
	arconf: {
		args: { key: 'key', value: 'value' },
		call: function(req) {
			let f = '/root/cake-autorate/config.primary.sh', k = req.args.key, v = req.args.value;
			if (k == 'ifc') {
				/* interfacce: upload = quella di SQM, download = la sua ifb4… (sqmline.sh, 2.44) */
				if (!match('' + v, /^[A-Za-z0-9._@-]{1,15}$/)) return { error: 'interfaccia non valida' };
				sh('sh /usr/share/wrtfreedom/sqmline.sh ar ' + v + ' >/dev/null 2>&1');
			}
			else if (k != null) {
				if (!match('' + k, /^[A-Za-z_]{3,48}$/) || !match('' + v, /^[0-9.]{1,10}$/))
					return { error: 'non valido' };
				sh("sed -i 's/^" + k + "=.*/" + k + "=" + v + "/' " + f);
			}
			let r = {};
			for (let l in split(readfile(f) ?? '', '\n')) {
				let m = match(l, /^([A-Za-z_]+)=([0-9.]+)/) ?? match(l, /^(ul_if|dl_if)=([A-Za-z0-9._@-]+)/);
				if (m) r[m[1]] = m[2];
			}
			return { conf: r };
		}
	},
	run: {
		args: { cmd: 'cmd' },
		call: function(req) {
			let c = '' + (req.args.cmd ?? '');
			if (!length(c) || length(c) > 4000)
				return { error: 'comando non valido' };
			writefile('/tmp/.wf-run.sh', c + '\n');
			return job('sh /tmp/.wf-run.sh');
		}
	},
	sqmstat: {
		call: function() {
			return { out: sh('tc qdisc show 2>/dev/null | grep -i cake') };
		}
	},
	q5g: {
		/* quectel-5g-tools (5g-lock, 5g-info): letti in sottofondo al massimo ogni 15 s, perché 5g-info chiede al modem
		   e rpcd resterebbe fermo; risponde subito con l'ultima lettura (la prima volta {wait:true}) */
		call: function() {
			if (!q5gtools()) {
				/* modulo della marca (modem.uc): cella attuale dalla lettura del modem, celle vicine e stato del blocco in sottofondo */
				modembg();
				let I = M.id(), D = M.drv(I), t = stat('/tmp/wf-q5g.ts');
				if (D && (!t || time() - t.mtime >= 15)) {
					let c = 'touch /tmp/wf-q5g.ts; ( { ';
					for (let x in [ ...(D.neigh ?? []), ...(D.lockq ?? []) ]) c += 'sh /usr/share/wrtfreedom/at.sh ' + q(x) + '; ';
					sh(c + '} > /tmp/wf-q5g.at.t 2>/dev/null; mv /tmp/wf-q5g.at.t /tmp/wf-q5g.at ) >/dev/null 2>&1 </dev/null &');
				}
				let o = readfile('/tmp/wf-q5g.at'), sv = readfile('/tmp/wf-modem.at') ?? '';
				if (D && o == null) return { wait: true };
				let S = D && D.parse ? D.parse(sv + '\n' + (o ?? '')) : { nb: [] };
				let cl = json(readfile('/tmp/wf-modem.cell') ?? 'null')?.modem?.generic?.['cell-info'];
				if (cl) { let c = M.mmcells(cl); S.lte ??= c.lte; S.nr ??= c.nr; if (!length(S.nb)) S.nb = c.nb; }
				let lk = D && D.lockparse ? D.lockparse(o ?? '') : { lte: 'none', nr: 'none' };
				let WC = ucfile('wrtfreedom');
				S.ltelock = lk.lte; S.nrlock = lk.nr; S.mode = ug(WC, 'modem', 'mode'); S.locked = lk.lte != 'none' || lk.nr != 'none';
				let r = { at: true, s: S, boot: ug(WC, 'lock', 'boot') == '1', drv: D ? D.name : '', vendor: I.mfr || I.vendor, model: I.model };
				if (!D || !D.lock) r.nolock = true;
				if (!S.lte && !S.nr && !cl) r.noat = true;
				return r;
			}
			let ts = stat('/tmp/wf-q5g.ts');
			if (!ts || time() - ts.mtime >= 15)
				sh("touch /tmp/wf-q5g.ts; ( 5g-lock > /tmp/wf-q5g.lock.t 2>&1; 5g-info 2>&1 | sed -E 's/((IMEI|IMSI|ICCID|MSISDN)[^:]*:).*/\\1 ***/I; s/[0-9]{14,20}/***/g' > /tmp/wf-q5g.info.t; " +
					"logread -e 5g-watchdog 2>/dev/null | tail -n 8 > /tmp/wf-q5g.wd; mv /tmp/wf-q5g.lock.t /tmp/wf-q5g.lock; mv /tmp/wf-q5g.info.t /tmp/wf-q5g.info ) >/dev/null 2>&1 </dev/null &");
			let info = readfile('/tmp/wf-q5g.info');
			if (info == null) return { wait: true };
			return { lock: readfile('/tmp/wf-q5g.lock') ?? '', info: info, wdlog: readfile('/tmp/wf-q5g.wd') ?? '' };
		}
	},
	tgget: {
		call: function() {
			let W = ucfile('wrtfreedom'), t = ug(W, 'tg', 'token'), c = ug(W, 'tg', 'chat');
			return { configured: length(t) > 0 && length(c) > 0, chat: c, bot: ug(W, 'tg', 'bot'), cmd: ug(W, 'tg', 'cmd') == '1' };
		}
	},
	tgcheck: {
		/* controlla il token e trova le chat che hanno scritto al bot */
		args: { token: 'token' },
		call: function(req) {
			let t = '' + (req.args.token ?? '');
			if (!match(t, /^[0-9]{5,15}:[A-Za-z0-9_-]{20,60}$/))
				return { error: 'token non valido' };
			if (!curlok()) return { error: CURLE };
			let me = tgreq(t, 'getMe');
			if (!me) return { error: 'Telegram non risponde: il router è collegato a internet?' };
			if (!me.ok) return { error: 'token rifiutato da Telegram' };
			let up = tgreq(t, 'getUpdates', { limit: 50 }), chats = [], seen = {};
			for (let u in ((up && up.result) ?? [])) {
				let m = u.message ?? u.my_chat_member ?? u.channel_post;
				let c = m && m.chat;
				if (!c || seen[c.id]) continue;
				seen[c.id] = true;
				push(chats, { id: '' + c.id, name: c.title ?? trim((c.first_name ?? '') + ' ' + (c.last_name ?? '')) ?? c.username });
			}
			return { bot: me.result.username, chats: chats };
		}
	},
	tgset: {
		args: { token: 'token', chat: 'chat', bot: 'bot' },
		call: function(req) {
			return tgsave('' + (req.args.token ?? ''), '' + (req.args.chat ?? ''), '' + (req.args.bot ?? ''));
		}
	},
	tgfind: {
		/* bot già configurati sul router da altri programmi (es. watchdog 5G): il token non esce mai dal router */
		call: function() {
			let out = [], seen = {};
			for (let l in split(sh('uci -q show 2>/dev/null'), '\n')) {
				let m = match(l, /^([A-Za-z0-9_-]+\.[]A-Za-z0-9_@[-]+)\.[A-Za-z0-9_]*token[A-Za-z0-9_]*='([0-9]{5,15}:[A-Za-z0-9_-]{20,60})'$/);
				if (!m || m[1] == 'wrtfreedom.tg' || seen[m[2]]) continue;
				seen[m[2]] = true;
				let chat = '';
				for (let k in split(sh('uci -q show ' + q(m[1])), '\n')) {
					let c = match(k, /\.[A-Za-z0-9_]*chat[A-Za-z0-9_]*='(-?[0-9]{3,20})'$/);
					if (c) { chat = c[1]; break; }
				}
				let me = tgreq(m[2], 'getMe');
				push(out, { id: m[1], bot: (me && me.ok) ? me.result.username : '', chat: chat });
			}
			return { list: out };
		}
	},
	tgimport: {
		args: { id: 'id' },
		call: function(req) {
			let id = '' + (req.args.id ?? '');
			if (!match(id, /^[A-Za-z0-9_-]+\.[]A-Za-z0-9_@[-]+$/)) return { error: 'non valido' };
			let t = '', c = '';
			for (let k in split(sh('uci -q show ' + q(id)), '\n')) {
				let a = match(k, /\.[A-Za-z0-9_]*token[A-Za-z0-9_]*='([^']+)'$/), b = match(k, /\.[A-Za-z0-9_]*chat[A-Za-z0-9_]*='([^']+)'$/);
				if (a) t = a[1];
				if (b) c = b[1];
			}
			let me = tgreq(t, 'getMe');
			return tgsave(t, c, (me && me.ok) ? me.result.username : '');
		}
	},
	tgdel: {
		call: function() {
			sh('uci -q delete wrtfreedom.tg; uci commit wrtfreedom');
			return { ok: true };
		}
	},
	tgcmd: {
		/* "Rispondi Ai Comandi": acceso = WrtFreedom legge i comandi del bot (tgbot.uc), spento = solo avvisi */
		args: { on: true },
		call: function(req) {
			cfgensure();
			sh('uci set wrtfreedom.tg=tg; uci set wrtfreedom.tg.cmd=' + (req.args.on ? '1' : '0') + '; uci commit wrtfreedom; rm -f /tmp/wf-tg.offset; touch /tmp/wf-tg.menu');
			sh('( /etc/init.d/wrtfreedom restart ) >/dev/null 2>&1 </dev/null &');
			return { ok: true };
		}
	},
	tgpresets: {
		/* catalogo dei Comandi Pronti con quello che manca su questo router e quali sono installati
		   (requisiti riletti al massimo ogni 60 s, subito con fresh dopo un'installazione) */
		args: { fresh: true },
		call: function(req) {
			let C = tgcatalog();
			if (!length(C.cmds)) return { error: 'catalogo non trovato' };
			/* requisiti: subito la prima volta e con fresh, altrimenti si rileggono in sottofondo per la volta dopo */
			let nf = stat('/tmp/wf-tg.needs'), nd = 'sh ' + TGP + ' --needs > /tmp/wf-tg.needs.t 2>/dev/null; mv /tmp/wf-tg.needs.t /tmp/wf-tg.needs';
			if (!nf || req.args.fresh) sh(nd);
			else if (time() - nf.mtime > 60) { writefile('/tmp/wf-tg.needs', readfile('/tmp/wf-tg.needs') ?? ''); sh('( ' + nd + ' ) >/dev/null 2>&1 </dev/null &'); }
			let N = {};
			for (let l in split(readfile('/tmp/wf-tg.needs') ?? '', '\n')) { let x = split(l, ' '); if (length(x[0])) N[x[0]] = x[1] == '1'; }
			let W = ucfile('wrtfreedom'), saved = ug(W, 'tg', 'pset') == '1', set = {};
			for (let n in split(ug(W, 'tg', 'preset'), ' ')) if (length(n)) set[n] = true;
			let U = tgusernames(W);
			for (let c in C.cmds) {
				c.miss = filter(c.need, (x) => !N[x]);
				c.over = index(c.fl, 'l') < 0 && (U[c.n] || U[c.en]) ? true : false;
				c.on = index(c.fl, 'l') >= 0 || (saved ? !!set[c.n] : index(c.fl, 'd') >= 0);
			}
			return { cats: C.cats, list: C.cmds, cmd: ug(W, 'tg', 'cmd') == '1' };
		}
	},
	tgpreset: {
		/* installa o toglie Comandi Pronti (uno o più, separati da spazi) */
		args: { names: 'names', on: true },
		call: function(req) {
			let C = tgcatalog(), valid = {}, saved = trim(sh('uci -q get wrtfreedom.tg.pset')) == '1', set = {};
			for (let c in C.cmds) valid[c.n] = c;
			/* prima modifica: si parte dai comandi installati di serie */
			if (!saved) { for (let c in C.cmds) if (index(c.fl, 'd') >= 0) set[c.n] = true; }
			else for (let n in split(trim(sh('uci -q get wrtfreedom.tg.preset')), ' ')) if (valid[n]) set[n] = true;
			for (let n in split(trim('' + (req.args.names ?? '')), ' ')) {
				if (!valid[n] || index(valid[n].fl, 'l') >= 0) continue;
				if (req.args.on) set[n] = true; else delete set[n];
			}
			cfgensure();
			let cmd = 'uci set wrtfreedom.tg=tg; uci -q delete wrtfreedom.tg.preset; uci set wrtfreedom.tg.pset=1; ';
			for (let n in sort(keys(set))) cmd += 'uci add_list wrtfreedom.tg.preset=' + n + '; ';
			sh(cmd + 'uci commit wrtfreedom; touch /tmp/wf-tg.menu');
			return { ok: true, on: sort(keys(set)) };
		}
	},
	tgprtest: {
		/* "Prova": esegue il comando in sottofondo e il risultato arriva su Telegram */
		args: { name: 'name', arg: 'arg' },
		call: function(req) {
			let n = '' + (req.args.name ?? '');
			if (!match(n, /^[a-z0-9_]{1,32}$/)) return { error: 'comando non valido' };
			let c = tgconf();
			if (!length(c.token) || !length(c.chat)) return { error: 'collega prima il bot' };
			let f = '/tmp/wf-tg.arg.' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time()), /[^0-9a-f]/g, ''), 0, 10);
			writefile(f, substr('' + (req.args.arg ?? ''), 0, 200));
			sh('( ucode /usr/share/wrtfreedom/tgbot.uc run ' + n + ' ' + f + ' ) >/dev/null 2>&1 </dev/null &');
			return { ok: true };
		}
	},
	tgcmds: {
		/* comandi personali (sezioni tgcmd) e altri programmi del router che usano un bot Telegram */
		call: function() {
			let out = [], W = ucfile('wrtfreedom');
			for (let c in W) {
				if (W[c]['.type'] != 'tgcmd') continue;
				let g = (o) => ug(W, c, o);
				push(out, { id: c, name: g('name'), desc: g('desc'), cmd: g('cmd'), cat: g('cat') || 'altro', on: g('enabled') != '0',
					confirm: g('confirm') == '1', askmode: g('askmode'), ask: g('ask') });
			}
			/* processi in esecuzione letti da /proc (niente pgrep: la shell che lo lancia conterrebbe la parola cercata) */
			let others = {}, re = /(tg[-_]?bot|telegram)/i;
			for (let pid in (lsdir('/proc') ?? [])) {
				if (!match(pid, /^[0-9]+$/)) continue;
				let cl = join(' ', split(readfile('/proc/' + pid + '/cmdline') ?? '', chr(0)));
				if (!match(cl, re) || match(cl, /wrtfreedom|rpcd/)) continue;
				/* scaricatori (curl, wget…): sono le richieste a Telegram, anche quelle di WrtFreedom */
				if (match(split(trim(cl), ' ')[0], /(^|\/)(curl|wget|uclient-fetch)$/)) continue;
				for (let t in split(trim(cl), ' ')) {
					if (!match(t, re) || index(t, '://') >= 0) continue;
					let parts = filter(split(t, '/'), length), n = '';
					for (let x in parts) if (match(x, re)) n = x;
					n = replace(n || parts[length(parts) - 1], /\.(sh|uc|lua|py)$/, '');
					if (length(n)) others[n] = true;
					break;
				}
			}
			/* servizi installati con quel nome, anche se fermi */
			for (let l in (lsdir('/etc/init.d') ?? []))
				if (match(l, re) && !match(l, /wrtfreedom/) && !(l in others))
					others[l] = length(trim(sh('/etc/init.d/' + q(l) + ' running >/dev/null 2>&1 && echo 1'))) > 0;
			let svc = [];
			for (let n in sort(keys(others))) push(svc, { name: n, on: others[n] });
			return { list: out, others: svc };
		}
	},
	tgcmdset: {
		/* aggiunge, modifica, accende/spegne o elimina un comando personale */
		args: { action: 'action', id: 'id', name: 'name', desc: 'desc', cmd: 'cmd', cat: 'cat', on: true, confirm: true, askmode: 'askmode', ask: 'ask' },
		call: function(req) {
			let a = req.args ?? {}, op = '' + (a.action ?? ''), id = '' + (a.id ?? '');
			if (!(op in ['add', 'set', 'on', 'del'])) return { error: 'azione non valida' };
			cfgensure();
			if (op != 'add' && !match(id, /^c[0-9]{1,14}$/)) return { error: 'comando non valido' };
			if (op == 'del') { sh('uci -q delete wrtfreedom.' + id + '; uci commit wrtfreedom; touch /tmp/wf-tg.menu'); return { ok: true }; }
			if (op == 'on') { sh('uci set wrtfreedom.' + id + '.enabled=' + (a.on ? '1' : '0') + '; uci commit wrtfreedom; touch /tmp/wf-tg.menu'); return { ok: true }; }
			let n = lc('' + (a.name ?? '')), d = replace(substr('' + (a.desc ?? ''), 0, 60), /[\n\r]/g, ' '), c = substr('' + (a.cmd ?? ''), 0, 500);
			let k = '' + (a.cat ?? 'altro');
			if (!match(k, /^[a-z]{1,12}$/)) k = 'altro';
			if (!match(n, /^[a-z0-9_]{1,32}$/) || !length(trim(c)))
				return { error: 'nome non valido (solo lettere minuscole, numeri e _)' };
			if (n in ['start', 'help', 'aiuto', 'menu']) return { error: '/' + n + ' è riservato al bot: scegli un altro nome' };
			let am = '' + (a.askmode ?? ''), ak = replace(substr('' + (a.ask ?? ''), 0, 60), /[\n\r]/g, ' ');
			if (!(am in ['', 'opt', 'req'])) am = '';
			for (let o in filter(split(trim(sh("uci -q show wrtfreedom | sed -n \"s/^wrtfreedom\\.\\([A-Za-z0-9_]*\\)\\.name='\\(.*\\)'$/\\1 \\2/p\"")), '\n'), length)) {
				let x = split(o, ' ');
				if (x[1] == n && x[0] != id) return { error: 'esiste già un comando /' + n };
			}
			if (op == 'add') id = 'c' + time();
			sh('uci set wrtfreedom.' + id + '=tgcmd; uci set wrtfreedom.' + id + '.name=' + n + '; uci set wrtfreedom.' + id + '.desc=' + q(d) + '; uci set wrtfreedom.' + id + '.cmd=' + q(c) + '; uci set wrtfreedom.' + id + '.cat=' + k +
				'; uci set wrtfreedom.' + id + '.confirm=' + (a.confirm ? '1' : '0') + '; uci set wrtfreedom.' + id + '.askmode=' + q(am) + '; uci set wrtfreedom.' + id + '.ask=' + q(ak) +
				'; uci -q get wrtfreedom.' + id + '.enabled >/dev/null || uci set wrtfreedom.' + id + '.enabled=1; uci commit wrtfreedom; touch /tmp/wf-tg.menu');
			return { ok: true, id: id };
		}
	},
	setlang: {
		/* lingua dell'app: la usano eventi, avvisi e risposte del bot */
		args: { lang: 'it' },
		call: function(req) {
			let l = '' + (req.args.lang ?? '');
			if (l != 'it' && l != 'en') return { error: 'lingua non valida' };
			cfgensure();
			sh('uci -q get wrtfreedom.ui >/dev/null || uci set wrtfreedom.ui=ui; uci set wrtfreedom.ui.lang=' + l + '; uci commit wrtfreedom');
			return { ok: true, lang: l };
		}
	},
	tgsend: {
		/* bg = avviso (event.sh, Watchdog, Pianificazioni…): va nella coda /tmp/wf-tgq e lo manda tgq.uc in sottofondo
		   (rpcd non resta fermo ad aspettare Telegram); se la linea manca resta in coda e riparte più tardi (2.42) */
		args: { text: 'text', bg: true, kb: 'kb' },
		call: function(req) {
			let c = tgconf(), t = substr('' + (req.args.text ?? ''), 0, 3500), kb = lc('' + (req.args.kb ?? ''));
			if (!length(c.token) || !length(c.chat)) return { error: 'bot Telegram non configurato' };
			if (length(kb) && !okmac(kb)) return { error: 'dispositivo non valido' };
			if (req.args.bg) {
				/* pulsanti: prima riga «#kb:<mac>» del messaggio in coda, tgq.uc li mette se il bot risponde ai comandi */
				mkdir('/tmp/wf-tgq');
				writefile('/tmp/wf-tgq/' + time() + '-' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '0', /[^0-9a-f]/g, ''), 0, 10), (length(kb) ? '#kb:' + kb + '\n' : '') + t);
				sh('( ucode /usr/share/wrtfreedom/tgq.uc flush ) </dev/null >/dev/null 2>&1 &');
				return { ok: true };
			}
			let pr = { chat_id: c.chat, text: t };
			if (length(kb)) pr.reply_markup = sprintf('%J', { inline_keyboard: [[{ text: L('✅ Lo Conosco', '✅ I Know It'), callback_data: 'dk:' + m12(kb) }, { text: L('⛔ Blocca', '⛔ Block'), callback_data: 'db:' + m12(kb) }]] });
			let r = tgreq(c.token, 'sendMessage', pr);
			return (r && r.ok) ? { ok: true } : { error: (r && r.description) || 'Telegram non risponde' };
		}
	},
	wginfo: {
		/* VPN Per Fuori Casa: stato e configurazione. 2.52: home (rete di casa a.b.c.d/n, per il Tunnel Parziale senza /24
		   fisse), vnet (rete della VPN), peers (impostazioni di ogni dispositivo: full, host, exp, alert, alt, paused, sched,
		   psk, own), rules (regole del firewall che aprono la porta), alt (Porta Alternativa), ddr (regola DNS del Parziale:
		   need, missing), pend (cambio in attesa di conferma) */
		call: function() {
			let has_ = has('/usr/bin/wg') || has('/usr/sbin/wg'), N = ucfile('network'), W = ucfile('wrtfreedom'), ifc = wgiface(N), HN = homenet();
			let r = { tools: has_, iface: ifc ?? null, host: ug(W, 'wg', 'host'), dns: ug(W, 'wg', 'dns') };
			/* niente impostato a mano: l'app usa i valori automatici */
			if (!length(r.host)) { let h = wgautohost(); r.host = h.host; r.hostAuto = h.how; r.cgnat = h.cgnat ?? false; }
			if (!length(r.dns)) { r.dns = HN.ip; r.dnsAuto = true; }
			/* senza maschera: con «DNS = 192.168.1.1/24» l'app WireGuard rifiuta tutto il QR (pacchetto 2.39) */
			r.dns = split('' + (r.dns ?? ''), '/')[0];
			/* indirizzi tra cui scegliere per ogni dispositivo: nomi DDNS accesi, IP pubblico della linea, quello impostato */
			let Dd = ucfile('ddns'), hs = [], add = (h) => { if (length(h) && index(hs, h) < 0) push(hs, h); };
			add(r.host);
			for (let k in Dd) if (Dd[k]['.type'] == 'service' && Dd[k].enabled != '0') add(Dd[k].lookup_host ?? '');
			let wip = wanip();
			if (length(wip) && !privip(wip)) add(wip);
			r.hosts = hs;
			r.home = HN.net;
			if (ifc) {
				let F = ucfile('firewall');
				r.on = ug(N, ifc, 'disabled') != '1';
				r.port = ug(N, ifc, 'listen_port');
				r.addr = ug(N, ifc, 'addresses');
				r.vnet = cidr(split(r.addr, ' ')[0]);
				r.mtu = ug(N, ifc, 'mtu');
				r.rules = map(wgrules(F, r.port, fwzones().wan), (k) => ({ id: k, name: F[k].name ?? k, on: F[k].enabled != '0', port: join(' ', vpnarr(F[k].dest_port)) }));
				r.alt = wgaltport(F);
				r.peers = wgpeers(N, W, ifc);
				let D = wgddr(N, W);
				r.ddr = { need: D.need, missing: D.missing, ip: D.ip };
				r.pend = bakpend('wg'); r.left = bakleft('wg');
				r.pub = ''; r.st = [];
				if (has_) {
					/* chiave pubblica e stato in un solo comando (la chiave privata da un file letto da stdin e tolto subito).
					   Del dump solo {pub, ep, hs, rx, tx} per dispositivo: mai la chiave privata (prima riga) né le PSK */
					let k = ug(N, ifc, 'private_key'), kf = length(k) ? kfile(k + '\n') : '';
					let o = sh((length(kf) ? 'wg pubkey < ' + kf + ' 2>/dev/null; rm -f ' + kf + '; ' : '') + 'echo @@WF@@; wg show ' + ifc + ' dump 2>/dev/null');
					let i = index(o, '@@WF@@\n');
					if (i >= 0) {
						r.pub = trim(substr(o, 0, i));
						let Ls = split(trim(substr(o, i + 7)), '\n');
						for (let j = 1; j < length(Ls); j++) {
							let f = split(Ls[j], '\t');
							if (length(f) >= 7) push(r.st, { pub: f[0], ep: f[2], hs: +f[4], rx: +f[5], tx: +f[6] });
						}
					}
				}
			}
			return r;
		}
	},

	wgsetup: {
		/* crea il server: interfaccia, chiavi, zona di casa e regola dalla zona internet (nomi veri del firewall). Rete,
		   firewall e interfaccia ripartono in sottofondo (niente attese nel metodo) */
		args: { host: 'host', port: 'port', net: 'net', dns: 'dns' },
		call: function(req) {
			let a = req.args ?? {}, host = '' + (a.host ?? ''), port = '' + (a.port ?? ''), net = '' + (a.net ?? ''), dns = '' + (a.dns ?? '');
			/* tutto automatico se non indicato */
			if (!length(port)) { port = '51820'; for (let p = 51820; p < 51840; p++) if (udpfree(p)) { port = '' + p; break; } }
			if (!length(net)) net = wgautonet();
			let hostSaved = length(host) > 0;
			if (!length(host)) host = wgautohost().host;
			if (!length(host)) host = 'da-impostare';
			if (!has('/usr/bin/wg') && !has('/usr/sbin/wg')) return { error: 'manca wireguard-tools: installalo da Dipendenze' };
			let N = ucfile('network');
			if (wgiface(N)) return { error: 'la VPN Per Fuori Casa è già configurata' };
			if (!match(host, /^[A-Za-z0-9.:-]{3,120}$/) || !match(port, /^[0-9]{2,5}$/) || !match(net, /^[0-9]{1,3}(\.[0-9]{1,3}){3}\/[0-9]{1,2}$/) || !match(dns, /^[0-9.:a-fA-F, ]{0,80}$/))
				return { error: 'dati non validi' };
			let ifc = N.wg0 ? 'wgf' : 'wg0', priv = trim(sh('wg genkey')), Z = fwzones(), F = ucfile('firewall');
			if (!match(priv, VPNKEY)) return { error: 'chiave non creata: manca wireguard-tools?' };
			let hz = filter(keys(F), (k) => F[k]['.type'] == 'zone' && F[k].name == Z.home)[0];
			let cmd = 'uci set network.' + ifc + '=interface; uci set network.' + ifc + ".proto='wireguard'; " + ukey('network', ifc, 'private_key', priv) +
				'uci set network.' + ifc + '.listen_port=' + port + '; uci set network.' + ifc + '.mtu=1280; uci add_list network.' + ifc + '.addresses=' + q(net) + '; ';
			if (hz) cmd += 'uci add_list ' + q('firewall.' + hz + '.network=' + ifc) + '; ';
			cmd += "uci set firewall.wf_wg=rule; uci set firewall.wf_wg.name='WrtFreedom-WireGuard'; uci set firewall.wf_wg.src=" + q(Z.wan) + "; uci set firewall.wf_wg.proto='udp'; uci set firewall.wf_wg.dest_port=" + port + "; uci set firewall.wf_wg.target='ACCEPT'; ";
			cfgensure();
			cmd += 'uci set wrtfreedom.wg=wg; ' + (hostSaved ? 'uci set wrtfreedom.wg.host=' + q(host) + '; ' : '') + (length(dns) ? 'uci set wrtfreedom.wg.dns=' + q(dns) + '; ' : '');
			sh(cmd + 'uci commit network; uci commit firewall; uci commit wrtfreedom; ( /etc/init.d/firewall reload; ifup ' + ifc + ' ) >/dev/null 2>&1 </dev/null &');
			let km = has('/sys/module/wireguard') || length(filter(lsdir('/lib/modules') ?? [], (v) => has('/lib/modules/' + v + '/wireguard.ko'))) > 0;
			return { ok: true, iface: ifc, zone: hz ? Z.home : null, warn: km ? null : 'interfaccia creata ma manca kmod-wireguard' };
		}
	},
	wgset: {
		/* accesa/spenta, porta, indirizzo da fuori, DNS, MTU, chiavi nuove. La porta cambia anche in tutte le regole che la
		   aprono (wgrules: «WrtFreedom-WireGuard», «Allow-WireGuard» fatta a mano o altre) e nella Porta Alternativa.
		   safe (2.52, dall'app) con on false, una porta nuova (libera: udpfree) o rekey: copia dell'interfaccia e delle sue regole (wgbak), risposta {ok, confirm: 120}; senza
		   action confirm entro 120 s torna tutto com'era (chi era collegato da fuori ritrova l'accesso, evento cron_wg_back);
		   action back = annulla subito. Bot, Pianificazioni ed Eventi non passano safe (nessuno può confermare).
		   ddr true = regola DNS del Tunnel Parziale creata se manca, risposta {ok, ddr {need, missing}} */
		args: { action: 'action', on: true, port: 'port', host: 'host', dns: 'dns', mtu: 'mtu', rekey: true, safe: true, ddr: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? ''), N = ucfile('network'), ifc = wgiface(N);
			if (act == 'confirm') return bakconfirm('wg');
			if (act == 'back') return bakback('wg', L('↩️ VPN Per Fuori Casa: modifica annullata, rimessa com\'era', '↩️ Away From Home VPN: change cancelled, restored'));
			if (length(act)) return { error: 'azione non valida' };
			if (!ifc) return { error: 'VPN Per Fuori Casa non configurata' };
			/* ddr: regola DNS del Tunnel Parziale creata se manca (wginfo.ddr.missing) */
			if (a.ddr === true) { let R = wgddrfix(); return { ok: true, ddr: { need: R.need, missing: R.missing } }; }
			let cmd = '', up = false, arm = false, ddr = false;
			if (a.on != null) { cmd += uset('network', ifc, 'disabled', a.on ? '0' : '1'); up = true; if (!a.on) arm = true; }
			if (a.port != null) {
				let p = '' + a.port, old = ug(N, ifc, 'listen_port');
				if (!match(p, /^[0-9]{2,5}$/) || +p < 10 || +p > 65535) return { error: 'porta non valida' };
				if (p == '' + wgaltport(null)) return { error: 'porta usata dalla Porta Alternativa' };
				if (p != old && !udpfree(p)) return { error: 'porta già usata sul router' };
				if (p != old) {
					let F = ucfile('firewall');
					cmd += uset('network', ifc, 'listen_port', p);
					for (let k in wgrules(F, old, fwzones().wan)) cmd += uset('firewall', k, 'dest_port', p);
					if (F.wf_wgalt) cmd += uset('firewall', 'wf_wgalt', 'dest_port', p);
					if (F.wf_wgalt_in) cmd += uset('firewall', 'wf_wgalt_in', 'dest_port', p);
					up = true; arm = true;
				}
			}
			if (a.mtu != null) {
				if (!match('' + a.mtu, /^[0-9]{0,4}$/)) return { error: 'MTU non valido' };
				cmd += length('' + a.mtu) ? uset('network', ifc, 'mtu', a.mtu) : udel('network', ifc, 'mtu'); up = true;
			}
			if (a.rekey) {
				let k = trim(sh('wg genkey'));
				if (!match(k, VPNKEY)) return { error: 'chiave non creata' };
				cmd += ukey('network', ifc, 'private_key', k); up = true; arm = true;
			}
			if (a.host != null || a.dns != null) {
				if ((a.host != null && !match('' + a.host, /^([A-Za-z0-9.:-]{3,120})?$/)) || (a.dns != null && !match('' + a.dns, /^[0-9.:a-fA-F, ]{0,80}$/))) return { error: 'dati non validi' };
				cfgensure();
				cmd += 'uci -q get wrtfreedom.wg >/dev/null || uci set wrtfreedom.wg=wg; ';
				/* vuoto = di nuovo automatico */
				if (a.host != null) { cmd += length('' + a.host) ? uset('wrtfreedom', 'wg', 'host', a.host) : udel('wrtfreedom', 'wg', 'host'); ddr = true; }
				if (a.dns != null) cmd += length('' + a.dns) ? uset('wrtfreedom', 'wg', 'dns', a.dns) : udel('wrtfreedom', 'wg', 'dns');
			}
			let safe = arm && a.safe === true;
			if (safe) { let e = wgbak(N, ifc); if (e !== true) return e; }
			cmd += 'uci commit network; uci commit firewall; uci commit wrtfreedom; ';
			if (up) cmd += '( ' + ((a.on === false) ? 'ifdown ' + ifc : 'ifup ' + ifc + '; /etc/init.d/firewall reload') + ' ) >/dev/null 2>&1 </dev/null &';
			sh(cmd);
			if (ddr) wgddrfix();
			return safe ? { ok: true, confirm: 120 } : { ok: true };
		}
	},
	wgpeer: {
		/* dispositivi, subito e senza riavviare la VPN. add {name, full, host, exp, alert, psk} (2.52: exp = ora di scadenza,
		   alert = avviso quando si collega, psk false = senza Chiave In Più; la rete della VPN può avere qualunque grandezza);
		   set {id, name, full, host, exp (0 = senza) o expin (secondi da adesso), alert, alt (QR con la Porta Alternativa)}; del {id}; pause/resume {id}
		   (fuori da wg ma salvato); sched {id, days 1…7, from, to} (attivo solo in quegli orari, days vuoto = senza orari);
		   psk {id, on} (Chiave In Più nuova o tolta: il QR va rifatto). Con il Tunnel Parziale la regola DNS del nome DDNS
		   si crea da sola (wgddrfix) */
		args: { action: 'action', id: 'id', name: 'name', full: true, host: 'host', exp: 0, expin: 0, alert: true, alt: true, psk: true, on: true, days: 'days', from: 'from', to: 'to' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? ''), N = ucfile('network'), ifc = wgiface(N);
			if (!ifc) return { error: 'VPN Per Fuori Casa non configurata' };
			/* indirizzo del router scelto per questo dispositivo (2.39): vuoto = quello generale */
			let host = '' + (a.host ?? '');
			if (length(host) && !match(host, /^[A-Za-z0-9.:-]{1,253}$/)) return { error: 'indirizzo non valido' };
			let name = replace(substr('' + (a.name ?? ''), 0, 40), /[\n\r'"\\]/g, '');
			let id = '' + (a.id ?? ''), now = time();
			if (act != 'add' && (!match(id, /^[A-Za-z0-9_]{1,40}$/) || N[id]?.['.type'] != 'wireguard_' + ifc)) return { error: 'client non valido' };
			/* expin = secondi da adesso (l'app non usa l'ora del telefono); exp = ora di scadenza, 0 = senza */
			let exp = a.expin != null && +a.expin > 0 ? now + int(+a.expin) : a.exp != null ? int(+a.exp) : null;
			if (exp != null && exp != 0 && (exp < now + 60 || exp > now + 400 * 86400)) return { error: 'scadenza non valida' };
			let pm = 'wrtfreedom.peer_' + id, meta = 'uci -q get ' + pm + ' >/dev/null || uci set ' + pm + '=peer; ';
			cfgensure();
			if (act == 'add') {
				if (!length(name)) return { error: 'serve un nome' };
				/* primo indirizzo libero della rete della VPN (qualunque maschera) */
				let ad = split(vpnarr(N[ifc].addresses)[0] ?? '10.8.0.1/24', '/'), me = ip2n(ad[0]), bits = +(ad[1] ?? 24);
				if (me == null) return { error: 'rete della VPN non valida' };
				if (bits < 8 || bits > 30) bits = 24;
				let base = me & ((0xffffffff << (32 - bits)) & 0xffffffff), size = 1 << (32 - bits), used = {}, ip = null;
				used['' + me] = true;
				for (let k in N) if (N[k]['.type'] == 'wireguard_' + ifc) for (let x in vpnarr(N[k].allowed_ips)) { let n = ip2n(split(x, '/')[0]); if (n != null) used['' + n] = true; }
				for (let i = 1; i < size - 1 && i < 4096; i++) if (!used['' + (base + i)]) { ip = n2ip(base + i); break; }
				if (!ip) return { error: 'nessun indirizzo libero nella rete VPN' };
				let priv = trim(sh('wg genkey')), psk = a.psk === false ? '' : trim(sh('wg genpsk'));
				let pf = kfile(priv + '\n'), pub = trim(sh('wg pubkey < ' + pf + ' 2>/dev/null; rm -f ' + pf));
				if (!match(pub, VPNKEY)) return { error: 'chiavi non create: manca wireguard-tools?' };
				let sec = 'wf' + now;
				while (N[sec]) sec += 'x';
				let kf = length(psk) ? kfile(psk + '\n') : '';
				sh('wg set ' + ifc + ' peer ' + q(pub) + (length(kf) ? ' preshared-key ' + kf : '') + ' allowed-ips ' + ip + '/32 persistent-keepalive 25 2>/dev/null' + (length(kf) ? '; rm -f ' + kf : ''));
				pm = 'wrtfreedom.peer_' + sec;
				sh('uci set network.' + sec + '=wireguard_' + ifc + '; ' + uset('network', sec, 'description', name) + uset('network', sec, 'public_key', pub) +
					(length(psk) ? ukey('network', sec, 'preshared_key', psk) : '') + 'uci add_list network.' + sec + '.allowed_ips=' + ip + '/32; ' + uset('network', sec, 'persistent_keepalive', '25') +
					'uci set ' + pm + '=peer; ' + ukey('wrtfreedom', 'peer_' + sec, 'priv', priv) + (length(psk) ? ukey('wrtfreedom', 'peer_' + sec, 'psk', psk) : '') +
					uset('wrtfreedom', 'peer_' + sec, 'full', a.full ? '1' : '0') + (length(host) ? uset('wrtfreedom', 'peer_' + sec, 'host', host) : '') +
					(exp ? uset('wrtfreedom', 'peer_' + sec, 'exp', '' + exp) : '') + (a.alert === true ? uset('wrtfreedom', 'peer_' + sec, 'alert', '1') : '') +
					'uci commit network; uci commit wrtfreedom');
				if (exp) wgexpcron(wgpeers(null, null, ifc));
				if (!a.full) wgddrfix();
				return { ok: true, id: sec, ip: ip, priv: priv, psk: psk, pub: pub, exp: exp || null };
			}
			if (act == 'del') {
				let pub = N[id].public_key ?? '';
				if (length(pub)) sh('wg set ' + ifc + ' peer ' + q(pub) + ' remove 2>/dev/null');
				sh('uci -q delete network.' + id + '; uci -q delete wrtfreedom.peer_' + id + '; uci commit network; uci commit wrtfreedom');
				wgschedcron(id, '', '', '');
				wgexpcron(wgpeers(null, null, ifc));
				wgddrfix();
				return { ok: true };
			}
			if (act == 'set') {
				let cmd = '';
				if (length(name)) cmd += uset('network', id, 'description', name);
				if (a.full != null || a.host != null || exp != null || a.alert != null || a.alt != null) cmd += meta;
				if (a.full != null) cmd += uset('wrtfreedom', 'peer_' + id, 'full', a.full ? '1' : '0');
				if (a.host != null) cmd += length(host) ? uset('wrtfreedom', 'peer_' + id, 'host', host) : udel('wrtfreedom', 'peer_' + id, 'host');
				if (exp != null) cmd += exp ? uset('wrtfreedom', 'peer_' + id, 'exp', '' + exp) : udel('wrtfreedom', 'peer_' + id, 'exp');
				if (a.alert != null) cmd += a.alert ? uset('wrtfreedom', 'peer_' + id, 'alert', '1') : udel('wrtfreedom', 'peer_' + id, 'alert');
				if (a.alt != null) cmd += a.alt ? uset('wrtfreedom', 'peer_' + id, 'alt', '1') : udel('wrtfreedom', 'peer_' + id, 'alt');
				sh(cmd + 'uci commit network; uci commit wrtfreedom');
				if (exp != null) wgexpcron(wgpeers(null, null, ifc));
				if (a.full != null || a.host != null) wgddrfix();
				return { ok: true };
			}
			if (act == 'pause' || act == 'resume') return wgpeerpause(ifc, id, act == 'pause');
			if (act == 'sched') {
				let d = '' + (a.days ?? ''), f = '' + (a.from ?? ''), t2 = '' + (a.to ?? ''), hm = /^([01][0-9]|2[0-3]):[0-5][0-9]$/;
				if (length(d) && (!match(d, /^[1-7]{1,7}$/) || !match(f, hm) || !match(t2, hm) || f == t2)) return { error: 'giorni o orari non validi' };
				sh(meta + (length(d) ? uset('wrtfreedom', 'peer_' + id, 'sdays', d) + uset('wrtfreedom', 'peer_' + id, 'sfrom', f) + uset('wrtfreedom', 'peer_' + id, 'sto', t2)
					: udel('wrtfreedom', 'peer_' + id, 'sdays') + udel('wrtfreedom', 'peer_' + id, 'sfrom') + udel('wrtfreedom', 'peer_' + id, 'sto')) + 'uci commit wrtfreedom');
				wgschedcron(id, d, f, t2);
				if (!length(d)) return { ok: true };
				/* stato giusto subito: dentro gli orari attivo, fuori in pausa (anche nei giorni non scelti). A cavallo della
				   mezzanotte la parte dopo le 0:00 appartiene al giorno prima */
				let lt = localtime(now), wn = lt.wday == 0 ? 7 : lt.wday, wd = '' + wn, yd = '' + (wn == 1 ? 7 : wn - 1), m = lt.hour * 60 + lt.min, a1 = hmin(f), b1 = hmin(t2);
				let inw = a1 < b1 ? (index(d, wd) >= 0 && m >= a1 && m < b1) : ((index(d, wd) >= 0 && m >= a1) || (index(d, yd) >= 0 && m < b1));
				let r = wgpeerpause(ifc, id, !inw);
				return r.error ? r : { ok: true, paused: r.paused };
			}
			if (act == 'psk') {
				let W = ucfile('wrtfreedom'), pub = N[id].public_key ?? '';
				if (!length(W['peer_' + id]?.priv ?? '')) return { error: 'dispositivo creato fuori dall\'app: la Chiave In Più va messa anche sul dispositivo' };
				if (!match(pub, VPNKEY)) return { error: 'dispositivo senza chiave pubblica' };
				if (a.on === false) {
					sh('wg set ' + ifc + ' peer ' + q(pub) + ' preshared-key /dev/null 2>/dev/null; ' + udel('network', id, 'preshared_key') + udel('wrtfreedom', 'peer_' + id, 'psk') + 'uci commit network; uci commit wrtfreedom');
					return { ok: true, psk: '' };
				}
				let psk = trim(sh('wg genpsk'));
				if (!match(psk, VPNKEY)) return { error: 'chiave non creata' };
				let kf = kfile(psk + '\n');
				sh((N[id].disabled == '1' ? '' : 'wg set ' + ifc + ' peer ' + q(pub) + ' preshared-key ' + kf + ' 2>/dev/null; ') + 'rm -f ' + kf + '; ' +
					ukey('network', id, 'preshared_key', psk) + ukey('wrtfreedom', 'peer_' + id, 'psk', psk) + 'uci commit network; uci commit wrtfreedom');
				return { ok: true, psk: psk };
			}
			return { error: 'azione non valida' };
		}
	},
	wgprobe: {
		/* Prova Da Fuori Casa (2.52). start {id}: prova armata per 3 minuti (un contatto di quel dispositivo arrivato dopo
		   l'inizio da un indirizzo fuori casa = la VPN si raggiunge da fuori) e controlli lenti in sottofondo (wgx.uc probe:
		   nome DDNS risolto da un DNS pubblico, IP pubblico); get: stato senza attese; stop. Risposta {armed, id, name, t,
		   until, ok, hs, ago, from, outside, host, port, listen, on, rules [{id, name, on, port}], alt, wanip, cgnat, run,
		   pub, ddns {host, ips, ok}, svc [{name, ip, ok}]} */
		args: { action: 'action', id: 'id' },
		call: function(req) {
			let act = '' + (req.args.action ?? 'get'), N = ucfile('network'), W = ucfile('wrtfreedom'), ifc = wgiface(N), now = time();
			if (!ifc) return { error: 'VPN Per Fuori Casa non configurata' };
			let P = wgpeers(N, W, ifc), R = rjs(WGPRB);
			if (act == 'stop') { unlink(WGPRB); unlink(WGPRBC); return { ok: true }; }
			if (act == 'start') {
				let id = '' + (req.args.id ?? ''), p = filter(P, (x) => x.id == id)[0];
				if (!p) return { error: 'dispositivo non trovato' };
				if (p.paused) return { error: 'dispositivo in pausa' };
				let gh = ug(W, 'wg', 'host');
				if (!length(gh)) gh = wgautohost().host;
				R = { id: id, name: p.name, t: now, until: now + 180, ok: false, host: length(p.host) ? p.host : gh };
				wjs(WGPRB, R);
				wjs(WGPRBC, { run: true, t: now });
				sh('( ucode ' + WGX + ' probe ) >/dev/null 2>&1 </dev/null &');
			}
			else if (act != 'get') return { error: 'azione non valida' };
			let on = ug(N, ifc, 'disabled') != '1';
			if (!R) return { armed: false, on: on };
			/* ultimo contatto letto adesso; la prima riga del dump è l'interfaccia (porta in ascolto nel terzo campo) */
			let pub = filter(P, (x) => x.id == R.id)[0]?.pub ?? '', hs = 0, ep = '', lp = '', Ls = split(trim(sh('wg show ' + ifc + ' dump 2>/dev/null')), '\n');
			for (let i = 0; i < length(Ls); i++) {
				let f = split(Ls[i], '\t');
				if (i == 0) lp = f[2] ?? '';
				else if (length(pub) && f[0] == pub && length(f) >= 7) { hs = +f[4]; ep = f[2]; }
			}
			let srcip = match(ep, /^[0-9.]+:[0-9]+$/) ? replace(ep, /:[0-9]+$/, '') : '', HN = homenet();
			let outside = length(srcip) > 0 && !(HN.net && innet(srcip, HN.net)) && !innet(srcip, cidr(split(ug(N, ifc, 'addresses'), ' ')[0]) ?? '0.0.0.0/32');
			let ok = R.ok || (hs >= R.t && outside);
			if (ok && !R.ok) { R.ok = true; R.hs = hs; R.from = srcip; wjs(WGPRB, R); }
			let port = ug(N, ifc, 'listen_port'), F = ucfile('firewall'), wip = wanip(), C = rjs(WGPRBC) ?? {};
			let rules = map(wgrules(F, port, fwzones().wan), (k) => ({ id: k, name: F[k].name ?? k, on: F[k].enabled != '0', port: join(' ', vpnarr(F[k].dest_port)) }));
			/* nomi DDNS accesi: ultimo IP mandato dal servizio (/var/run/ddns/<servizio>.ip) confrontato con l'IP pubblico */
			let Dd = ucfile('ddns'), svc = [];
			for (let k in Dd) if (Dd[k]['.type'] == 'service' && Dd[k].enabled != '0' && length(Dd[k].lookup_host ?? '')) {
				let ip = trim(readfile('/var/run/ddns/' + k + '.ip') ?? '');
				push(svc, { name: Dd[k].lookup_host, ip: ip, ok: length(C.pub ?? '') && length(ip) ? ip == C.pub : null });
			}
			return { armed: now < R.until && !ok, id: R.id, name: R.name, t: R.t, until: R.until, ok: ok, hs: hs || null, ago: hs ? now - hs : null, from: ok ? (R.from ?? srcip) : srcip,
				outside: outside, host: R.host, port: port, listen: length(lp) > 0 && lp == port, on: on, rules: rules, alt: wgaltport(F), wanip: wip, cgnat: privip(wip),
				run: C.run == true && now - (C.t ?? 0) < 60, pub: C.pub ?? null, ddns: C.ddns ?? null, svc: svc };
		}
	},
	wgstats: {
		/* Statistiche Per Dispositivo (2.52): byte al giorno di ogni dispositivo della VPN Per Fuori Casa (wgx.uc ogni 30 s,
		   60 giorni). {id} = solo quello. Risposta {t, today, peers [{id, name, today [rx, tx], month [rx, tx], days [[giorno,
		   rx, tx]]}]}; rx = ricevuti dal router (inviati dal dispositivo), tx = mandati al dispositivo */
		args: { id: 'id' },
		call: function(req) {
			let U = rjs('/tmp/wf-wguse.json') ?? rjs('/etc/wrtfreedom/wguse.json') ?? {}, D = U.d ?? {}, now = time(), d = dday(now), mo = substr(d, 0, 7), id = '' + (req.args.id ?? '');
			let ks = sort(keys(D)), out = [];
			for (let p in wgpeers(null, null, null)) {
				if (length(id) && p.id != id) continue;
				let days = [], m = [0, 0];
				for (let k in ks) {
					let v = D[k][p.id];
					if (!v) continue;
					push(days, [k, v[0], v[1]]);
					if (substr(k, 0, 7) == mo) { m[0] += v[0]; m[1] += v[1]; }
				}
				push(out, { id: p.id, name: p.name, today: (D[d] ?? {})[p.id] ?? [0, 0], month: m, days: days });
			}
			return { t: now, today: d, peers: out };
		}
	},
	wgalt: {
		/* Porta Alternativa (2.52): una seconda porta UDP dalla zona internet (di serie 443, aperta quasi ovunque: alberghi,
		   lavoro) inoltrata alla porta della VPN (redirect wf_wgalt) e accettata (regola wf_wgalt_in solo se nessuna regola
		   apre già la porta della VPN). Con conferma come wgset: {ok, confirm: 120}, senza confirm entro 120 s torna com'era.
		   get = {on, port, lport, pend}; on {port}; off; confirm; back. I QR dei dispositivi con alt usano questa porta */
		args: { action: 'action', port: 0 },
		call: function(req) {
			let act = '' + (req.args.action ?? 'get'), N = ucfile('network'), F = ucfile('firewall'), ifc = wgiface(N), cur = wgaltport(F);
			if (act == 'confirm') return bakconfirm('wg');
			if (act == 'back') return bakback('wg', L('↩️ VPN Per Fuori Casa: modifica annullata, rimessa com\'era', '↩️ Away From Home VPN: change cancelled, restored'));
			if (!ifc) return { error: 'VPN Per Fuori Casa non configurata' };
			let lp = ug(N, ifc, 'listen_port'), wz = fwzones().wan;
			if (act == 'get') return { on: cur != null, port: cur ?? 443, lport: +lp || null, pend: bakpend('wg'), left: bakleft('wg') };
			let c = '';
			if (act == 'on') {
				let p = int(+(req.args.port ?? 443) || 443);
				if (p < 1 || p > 65535 || '' + p == lp) return { error: 'porta non valida' };
				for (let k in F) if (k != 'wf_wgalt' && F[k]['.type'] == 'redirect' && F[k].enabled != '0' && join(' ', vpnarr(F[k].src_dport)) == '' + p && (F[k].src ?? '') == wz && !match(join(' ', vpnarr(F[k].proto)), /^tcp$/))
					return { error: 'porta già inoltrata da un\'altra regola' };
				if (p != cur && !udpfree(p)) return { error: 'porta già usata sul router' };
				c = 'uci set firewall.wf_wgalt=redirect; ' + uset('firewall', 'wf_wgalt', 'name', 'WrtFreedom-WireGuard-' + p) + uset('firewall', 'wf_wgalt', 'src', wz) +
					uset('firewall', 'wf_wgalt', 'proto', 'udp') + uset('firewall', 'wf_wgalt', 'src_dport', '' + p) + uset('firewall', 'wf_wgalt', 'dest_port', lp) +
					uset('firewall', 'wf_wgalt', 'target', 'DNAT') + udel('firewall', 'wf_wgalt', 'enabled') + udel('firewall', 'wf_wgalt_in');
				if (!length(wgrules(F, lp, wz)))
					c += 'uci set firewall.wf_wgalt_in=rule; ' + uset('firewall', 'wf_wgalt_in', 'name', 'WrtFreedom-WireGuard-In') + uset('firewall', 'wf_wgalt_in', 'src', wz) +
						uset('firewall', 'wf_wgalt_in', 'proto', 'udp') + uset('firewall', 'wf_wgalt_in', 'dest_port', lp) + uset('firewall', 'wf_wgalt_in', 'target', 'ACCEPT');
			}
			else if (act == 'off') {
				if (!F.wf_wgalt && !F.wf_wgalt_in) return { error: 'Porta Alternativa già spenta' };
				c = udel('firewall', 'wf_wgalt') + udel('firewall', 'wf_wgalt_in');
			}
			else return { error: 'azione non valida' };
			let e = wgbak(N, ifc);
			if (e !== true) return e;
			sh(c + 'uci commit firewall; ( /etc/init.d/firewall reload ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, confirm: 120 };
		}
	},
	vpnsites: {
		/* Eccezioni Per Sito del Servizio VPN (2.52): i siti scelti escono dalla linea normale anche per chi usa la VPN
		   (banca, siti che bloccano le VPN). Serve dnsmasq-full (nftset) con il firewall fw4: senza, get dice cosa manca
		   (need) e add risponde con l'errore. get = {avail, need [pacchetti], sites, warn, max, pend}; add {site, safe};
		   del {site, safe}; confirm; back. Ogni cambio è provato prima della ricarica (vsiteapply) e con safe (dall'app)
		   la risposta ha confirm: 120: senza action confirm entro 120 s torna com'era (evento cron_vpnsites_back).
		   Con AdGuard diretto fatto dall'app (adgmode) i siti passano da dnsmasq (voci di adgmode rebind) */
		args: { action: 'action', site: 'site', safe: true },
		call: function(req) {
			let act = '' + (req.args.action ?? 'get');
			if (act == 'confirm') return bakconfirm('vpnsites');
			if (act == 'back') return bakback('vpnsites', L('↩️ Eccezioni Per Sito: modifica annullata, rimesse com\'era', '↩️ Per-Site Exceptions: change cancelled, restored'));
			let H = pkgHave(), need = [], W = ucfile('wrtfreedom'), S = vpnarr((W.vpnsite ?? {}).site), safe = req.args.safe === true;
			if (!H['dnsmasq-full']) push(need, 'dnsmasq-full');
			if (!has('/usr/share/nftables.d') || !(H.firewall4 || has('/sbin/fw4'))) push(need, 'firewall4');
			let O = vpnopts(W), mode = adgmodeinfo().mode;
			let warn = mode == 'direct' && !has('/etc/wrtfreedom/adgmode/orig') ? L('AdGuard risponde direttamente ai dispositivi: le eccezioni valgono solo per chi usa il DNS del router', 'AdGuard answers devices directly: exceptions only work for devices using the router DNS')
				: O.dns != 'adg' ? L('Con il DNS del servizio o personale le eccezioni non funzionano: scegli il DNS del router', 'With the service or custom DNS exceptions do not work: choose the router DNS') : null;
			if (act == 'get') return { avail: !length(need), need: need, sites: S, warn: warn, max: 50, pend: bakpend('vpnsites'), left: bakleft('vpnsites') };
			let x = lc(trim('' + (req.args.site ?? '')));
			x = replace(replace(replace(x, /^[a-z]{1,10}:\/\//, ''), /[\/:?#].*$/, ''), /^\*?\./, '');
			if (!match(x, /^([a-z0-9-]{1,63}\.){1,10}[a-z0-9-]{2,63}$/)) return { error: 'sito non valido (esempio: banca.it)' };
			let n = null;
			if (act == 'add') {
				if (length(need)) return { error: 'serve ' + join(' e ', need), need: need };
				if (index(S, x) >= 0) return { ok: true, sites: S };
				if (length(S) >= 50) return { error: 'al massimo 50 siti' };
				n = [...S, x];
			}
			else if (act == 'del') {
				if (index(S, x) < 0) return { error: 'sito non trovato' };
				n = filter(S, (y) => y != x);
			}
			else return { error: 'azione non valida' };
			let r = vsiteapply(n, S, safe);
			if (r.error) return r;
			return safe ? { ok: true, sites: n, warn: warn, confirm: 120 } : { ok: true, sites: n, warn: warn };
		}
	},
	upnp: {
		/* UPnP / NAT-PMP con miniupnpd (2.41): stato, porte aperte dai dispositivi, accensione. Interfaccia esterna
		   vuota = la sceglie miniupnpd dalla rotta predefinita (segue anche la linea di riserva), interna = la rete di
		   casa del firewall; modalità sicura di serie (un dispositivo apre porte solo verso se stesso). Pacchetto da
		   installare: nftables con fw4, altrimenti iptables */
		args: { action: 'action', on: true, natpmp: true, secure: true },
		call: function(req) {
			let a = req.args ?? {}, U = ucfile('upnpd'), C = U.config ?? {}, inst = has('/etc/init.d/miniupnpd');
			let pkg = has('/sbin/fw4') ? 'miniupnpd-nftables' : 'miniupnpd-iptables';
			if (('' + (a.action ?? 'get')) == 'get') {
				let L = [], lf = C.upnp_lease_file ?? '/var/run/miniupnpd.leases';
				/* righe «PROTO:porta esterna:ip:porta interna:scadenza:descrizione» */
				for (let l in split(readfile(lf) ?? '', '\n')) {
					let f = split(l, ':');
					if (length(f) >= 4 && match(f[1], /^[0-9]+$/)) push(L, { proto: f[0], ext: +f[1], ip: f[2], int: +f[3], exp: +(f[4] ?? 0), desc: join(':', slice(f, 5)) });
				}
				return { installed: inst, pkg: pkg, on: inst && C.enabled == '1', natpmp: C.enable_natpmp != '0', secure: C.secure_mode != '0',
					run: length(trim(sh('pgrep miniupnpd 2>/dev/null'))) > 0, leases: L, now: time() };
			}
			if (!inst) return { error: 'manca il pacchetto ' + pkg + ': installalo' };
			let home = fwzones().home, F = ucfile('firewall'), nets = 'lan';
			for (let k in F) if (F[k]['.type'] == 'zone' && F[k].name == home) { let n = type(F[k].network) == 'array' ? F[k].network : split(F[k].network ?? '', ' '); nets = n[0] ?? 'lan'; }
			let on = !!a.on;
			sh('uci -q get upnpd.config >/dev/null || uci set upnpd.config=upnpd; uci set upnpd.config.enabled=' + (on ? 1 : 0) + '; uci set upnpd.config.enable_upnp=1; uci set upnpd.config.enable_natpmp=' + (a.natpmp ? 1 : 0) +
				'; uci set upnpd.config.secure_mode=' + (a.secure ? 1 : 0) + '; uci -q delete upnpd.config.external_iface; uci set upnpd.config.internal_iface=' + nets + '; uci commit upnpd; ' +
				'( ' + (on ? '/etc/init.d/miniupnpd enable; /etc/init.d/miniupnpd restart' : '/etc/init.d/miniupnpd stop; /etc/init.d/miniupnpd disable') + ' ) >/dev/null 2>&1 &');
			return { ok: true };
		}
	},
	vpnout: {
		/* Servizio VPN (2.42; prima «VPN in uscita», 2.41): collegamenti, servizi, opzioni, verifiche. Le parti lente
		   (API dei servizi, server più veloce, IP pubblico, controllo DNS, controllo ogni 30 s) le fa vpnctl.uc.
		   2.52: state = stato unico (vpnstate, anche in get.state); pause {min} = Pausa Del Servizio VPN (collegamenti accesi
		   spenti fino a pause_until, ripresi da notify.sh con cron.sh vpnsvcresume o con resume); safe (dall'app) con le
		   azioni che cambiano l'uscita di tutta la casa (topts, onoff, connect, next, fuse, tdel, resume, oset di kill, dns,
		   dnsc, v6, guest, mtu, reset): copia delle sole sezioni del servizio (VPNBAK) e del file DNS, risposta con confirm: 120;
		   senza action confirm entro 120 s torna tutto com'era (evento cron_vpn_back); back = annulla subito. connect/next con safe: setprof (da vpnctl) riarma la copia quando cambia davvero */
		args: { action: 'action', tid: 'tid', prov: 'prov', place: 'place', conf: 'conf', name: 'name', on: true, mode: 'mode', devs: [],
			guest: true, kill: true, dns: 'dns', auto: true, token: 'token', account: 'account', user: 'user', pass: 'pass', cc: 'cc', city: 'city', sname: 'sname', pname: 'pname', pid: 'pid', srvid: 'srvid', ips: [], k: 'k', v: 'v', host: 'host', req: 'req', sid: 'sid', days: 'days', from: 'from', to: 'to', sact: 'sact', min: 0, safe: true, dev: 'dev', mac: 'mac' },
		call: function(req) {
			let a0 = req.args ?? {}, act0 = '' + (a0.action ?? 'get'), pend0 = bakpend('vpn');
			if (act0 == 'confirm') return bakconfirm('vpn');
			if (act0 == 'back') return bakback('vpn', L('↩️ Servizio VPN: modifica annullata, rimesso com\'era', '↩️ VPN Service: change cancelled, restored'));
			/* pause spegne il servizio (la casa resta su internet): non serve la conferma; resume lo riaccende sì */
			let safe = a0.safe === true && (index(['topts', 'onoff', 'connect', 'next', 'fuse', 'tdel', 'resume'], act0) >= 0 ||
				(act0 == 'oset' && index(['kill', 'dns', 'dnsc', 'v6', 'guest', 'mtu', 'reset'], '' + a0.k) >= 0));
			let vbak = () => bakarm('vpn', VPNBAK, [VPNDNSF, VPNMACF], '/etc/init.d/firewall reload; /etc/init.d/network reload; /etc/init.d/dnsmasq reload', 120,
				L('↩️ Servizio VPN: nessuna conferma entro 120 s, rimesso com\'era', '↩️ VPN Service: no confirmation within 120 s, restored'));
			if (safe) { let e = vbak(); if (e !== true) return e; }
			let r = (function() {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), N = ucfile('network'), W = ucfile('wrtfreedom'), O = vpnopts(W), T = vpntuns(W), Ps = vpnprofs(W);
			let rd = (f) => { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } };
			const CTL = 'ucode /usr/share/wrtfreedom/vpnctl.uc ', PROVS = VPNPROVS;
			let LG = vpnlegacy(W, N);
			if (LG) { Ps[LG.P.id] = LG.P; push(T, LG.T); }
			/* fine della Pausa Del Servizio VPN (accensione a mano, ripresa) */
			const UNP = 'uci -q delete wrtfreedom.vpnout.pause_until; uci -q delete wrtfreedom.vpnout.pause_on; ';
			if (act == 'state') return vpnstate(W) ?? { none: true };
			if (act == 'pause') {
				let m = int(+(a.min ?? 0)), pu = +(ug(W, 'vpnout', 'pause_until') || '0'), until = time() + m * 60;
				if (m < 1 || m > 1440) return { error: 'durata non valida (1…1440 minuti)' };
				if (pu > time()) { sh(uset('wrtfreedom', 'vpnout', 'pause_until', '' + until) + 'uci commit wrtfreedom'); return { ok: true, until: until }; }
				let ON = filter(T, (x) => x.on), pre = 'uci -q get wrtfreedom.vpnout >/dev/null || uci set wrtfreedom.vpnout=vpnout; uci -q delete wrtfreedom.vpnout.pause_on; ';
				if (!length(ON)) return { error: 'Servizio VPN già spento' };
				for (let x in ON) { pre += 'uci add_list wrtfreedom.vpnout.pause_on=' + q(x.id) + '; '; x.on = false; x.fb = false; }
				vpnapply(T, O, pre + uset('wrtfreedom', 'vpnout', 'pause_until', '' + until));
				return { ok: true, until: until };
			}
			if (act == 'resume') {
				let ids = vpnarr((W.vpnout ?? {}).pause_on);
				if (!length(ids) && !length(ug(W, 'vpnout', 'pause_until'))) return { error: 'nessuna pausa in corso' };
				for (let x in T) if (index(ids, x.id) >= 0) { x.on = true; x.fb = false; }
				vpnapply(T, O, UNP);
				return { ok: true };
			}
			let tun = (id) => filter(T, (t) => t.id == id)[0];
			let clean = (s, n) => replace(substr('' + (s ?? ''), 0, n), /[\n\r'"\\`$]/g, '');
			let devsOk = (t, devs) => {
				/* un dispositivo sta in un solo collegamento per dispositivi (nessun MAC in comune, o stesso IP per le voci senza MAC) */
				let K = {};
				for (let o in T) if (o.n > 0 && o.id != t.id) for (let d in vpndevs(o.devs)) for (let k in vpndevkeys(d)) K[k] = 1;
				for (let x in vpndevs(devs)) for (let k in vpndevkeys(x)) if (K[k]) return false;
				return true;
			};
			if (act == 'get') {
				let IP = rd('/tmp/wf-vpnip.json') ?? {}, MON = rd('/tmp/wf-vpn.json') ?? {}, USE = rd('/tmp/wf-vpnuse.json') ?? {}, today = substr(trim(sh('date +%Y-%m-%d')), 0, 10), Zs = vpnzones();
				let wg = {};
				for (let l in split(trim(sh('wg show all dump 2>/dev/null')), '\n')) { let f = split(l, '\t'); if (length(f) >= 8) wg[f[0]] = { hs: +f[5], rx: +f[6], tx: +f[7], ep: f[3] }; }
				let out = [];
				for (let t in T) {
					let P = Ps[t.prof] ?? {}, I = vpnif(t.n), u = (USE.t ?? {})[t.id] ?? {}, mo = 0, dy = (u.d ?? {})[today] ?? [0, 0];
					for (let k, v in (u.d ?? {})) if (substr(k, 0, 7) == substr(today, 0, 7)) mo += (v[0] ?? 0) + (v[1] ?? 0);
					/* dl = voci lette: tutti i MAC, priv = almeno un MAC privato (l'app avvisa), byip = MAC non ancora trovato */
					push(out, { id: t.id, n: t.n, iface: I, on: t.on, fb: t.fb, mode: t.mode, devs: t.devs,
						dl: map(vpndevs(t.devs), (d) => { return { macs: d.macs, ip: d.ip, name: d.name, priv: d.priv, byip: !length(d.macs) }; }),
						srv: { prov: P.prov ?? 'other', name: P.name ?? '', place: P.place ?? '', cc: P.cc ?? '', city: P.city ?? '', sname: P.sname ?? '', host: P.host ?? '', dns: P.dns ?? [], port: P.port ?? '', pub: P.pub ?? '', addr: P.addr ?? [], mtu: P.mtu ?? '' },
						st: wg[I] ?? { hs: 0, rx: 0, tx: 0 }, ip: IP[t.id], mon: MON[t.id], use: { today: dy[0] + dy[1], month: mo } });
				}
				let acc = {}, AI = rd('/tmp/wf-vpnacc.json') ?? {};
				for (let p in PROVS) {
					let s = W['va_' + p] ?? {}, ok = length(s.key ?? s.priv ?? '') > 0 && (index(['mullvad', 'azire', 'ivpn'], p) < 0 || length(s.addr ?? '') > 0);
					acc[p] = { ok: ok, user: p == 'pia' ? (s.user ?? '') : (p == 'mullvad' || p == 'ivpn') && s.account ? '…' + substr(s.account, -4) : '', chk: AI[p],
						recent: map(vpnarr(s.recent), (x) => { let f = split(x, '|'); return { id: f[0], cc: f[1] ?? '', name: f[2] ?? '' }; }),
						fav: map(vpnarr(s.fav), (x) => { let f = split(x, '|'); return { id: f[0], cc: f[1] ?? '', name: f[2] ?? '' }; }), q: { id: s.qplace ?? '', name: s.qname ?? '', cc: s.qcc ?? '' } };
				}
				let files = [];
				for (let k, P in Ps) if (P.lib) push(files, { id: k, prov: P.prov, name: P.name, host: P.host, cc: P.cc, dns: P.dns, added: P.added });
				/* orari, traffico per giorno (tutti i collegamenti, ultimi 30 giorni), disponibilità e cadute del mese */
				let sched = [], H = {}, mo = substr(today, 0, 7), av = [0, 0], EVS = rd('/etc/wrtfreedom/vpnev.json') ?? [];
				for (let k in W) if (W[k]['.type'] == 'vpnsched') { let s = W[k]; push(sched, { id: k, name: s.name ?? '', days: s.days ?? '', from: s.from ?? '', to: s.to ?? '', act: s.act == 'place' ? 'place' : 'off', prov: s.prov ?? '', place: s.place ?? '', pname: s.pname ?? '', cc: s.cc ?? '', on: s.on != '0' }); }
				for (let id, u in (USE.t ?? {})) for (let k, v in (u.d ?? {})) H[k] = (H[k] ?? 0) + (v[0] ?? 0) + (v[1] ?? 0);
				for (let k, v in (USE.av ?? {})) if (substr(k, 0, 7) == mo) { av[0] += v[0]; av[1] += v[1]; }
				let hk = sort(keys(H)); hk = slice(hk, length(hk) > 30 ? length(hk) - 30 : 0);
				return { none: !length(out) && !length(files) && !length(filter(keys(acc), (k) => acc[k].ok)), tunnels: out, acc: acc, files: files, kill: O.kill, auto: O.auto, dns: O.dns, guest: O.guest, guestz: length(Zs.gz) > 0,
					o: O, sched: sched, hist: map(hk, (k) => [k, H[k]]), av: av, evs: slice(EVS, length(EVS) > 12 ? length(EVS) - 12 : 0), cad: length(filter(EVS, (e) => e.k == 'down' && substr(e.d ?? '', 0, 7) == mo)),
					fw4: has('/usr/share/nftables.d'), adg: has('/etc/init.d/adguardhome') || has('/etc/init.d/AdGuardHome'), curl: has('/usr/bin/curl'), speed: has('/usr/bin/speedtest-go'),
					leak: rd('/tmp/wf-vpnleak.json'), max: 6, now: time(), state: vpnstate(W), pend: bakpend('vpn'), left: bakleft('vpn'), sites: vpnarr((W.vpnsite ?? {}).site) };
			}
			if (act == 'places') {
				/* paesi o località del servizio: letti in sottofondo, tenuti un giorno */
				if (index(PROVS, a.prov) < 0) return { error: 'servizio non valido' };
				let f = '/tmp/wf-vpnplaces-' + a.prov + '.json', C = rd(f), s = stat(f);
				if (!C || !s || time() - s.mtime > 86400) sh('( ' + CTL + 'places ' + a.prov + ' ) >/dev/null 2>&1 &');
				return C ? { list: C } : { wait: true };
			}
			if (act == 'account') {
				/* credenziali del servizio: si salvano e vpnctl.uc le controlla subito con il servizio (lavoro) */
				let p = '' + (a.prov ?? ''), c = 'uci set wrtfreedom.va_' + p + '=vpnacc; ';
				if (p == 'nord') { let t = trim('' + (a.token ?? '')); if (!match(t, /^[A-Za-z0-9]{40,128}$/)) return { error: 'il token di NordVPN è molto lungo: copia il «token di accesso», non utente e password del servizio' };	/* utente e password del servizio: circa 24 caratteri */ c += 'uci set wrtfreedom.va_nord.token=' + q(t) + '; uci -q delete wrtfreedom.va_nord.key; '; }
				else if (p == 'mullvad') { let n = replace('' + (a.account ?? ''), /[ -]/g, ''); if (!match(n, /^[0-9]{16}$/)) return { error: 'il numero di account Mullvad ha 16 cifre' }; c += 'uci set wrtfreedom.va_mullvad.account=' + n + '; uci -q delete wrtfreedom.va_mullvad.addr; '; }
				else if (p == 'pia') {
					let u = trim('' + (a.user ?? '')), pw = '' + (a.pass ?? '');
					if (!match(u, /^[A-Za-z0-9._@-]{3,64}$/) || !length(pw) || length(pw) > 128) return { error: 'utente o password non validi' };
					c += 'uci set wrtfreedom.va_pia.user=' + q(u) + '; uci set wrtfreedom.va_pia.pass=' + q(pw) + '; ';
				}
				else if (p == 'azire') { let t = trim('' + (a.token ?? '')); if (!match(t, /^[A-Za-z0-9._-]{20,255}$/)) return { error: 'token di AzireVPN non valido: copialo intero dal Manager' }; c += 'uci set wrtfreedom.va_azire.token=' + q(t) + '; uci -q delete wrtfreedom.va_azire.addr; '; }
				else if (p == 'ivpn') { let n = trim('' + (a.account ?? '')); if (!match(n, /^i-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}$/)) return { error: 'il numero di account IVPN è del tipo i-XXXX-XXXX-XXXX' }; c += 'uci set wrtfreedom.va_ivpn.account=' + q(n) + '; uci -q delete wrtfreedom.va_ivpn.addr; '; }
				else return { error: 'servizio non valido' };
				cfgensure();
				sh(c + 'uci commit wrtfreedom');
				return job(CTL + 'login ' + p);
			}
			if (act == 'ipcheck') { sh('( ' + CTL + 'ipcheck ) >/dev/null 2>&1 &'); return { ok: true }; }
			if (act == 'fav') {
				let p = '' + (a.prov ?? ''), pl = '' + (a.place ?? '');
				if (index(PROVS, p) < 0 || !match(pl, /^[A-Za-z0-9_-]{1,40}$/)) return { error: 'paese non valido' };
				let L = filter(vpnarr((W['va_' + p] ?? {}).fav), (y) => split(y, '|')[0] != pl), c = 'uci -q delete wrtfreedom.va_' + p + '.fav; ';
				if (a.on) push(L, pl + '|' + (match('' + (a.cc ?? ''), /^[A-Z]{2}$/) ? a.cc : '') + '|' + clean(a.pname, 60));
				for (let y in slice(L, 0, 30)) c += 'uci add_list wrtfreedom.va_' + p + '.fav=' + q(y) + '; ';
				sh(c + 'uci commit wrtfreedom');
				return { ok: true };
			}
			if (act == 'acccheck') { sh('( ' + CTL + 'acccheck ) >/dev/null 2>&1 &'); return { ok: true }; }
			if (act == 'oset') {
				/* un'opzione alla volta; solo quelle della rete ricostruiscono collegamenti e regole */
				let k = '' + (a.k ?? ''), v = '' + (a.v ?? '');
				if (k == 'reset') { O.mtu = ''; O.ka = '25'; }
				else if (k == 'bootpl') {
					/* paese all'avvio: «id|sigla|nome» ('' = l'ultimo usato) */
					let f = split(v, '|');
					if (length(f[0]) && !match(f[0], VPNV.bootpl[1])) return { error: 'paese non valido' };
					O.bootpl = f[0]; O.bootcc = length(f[0]) && match(f[1] ?? '', /^[A-Z]{2}$/) ? f[1] : ''; O.bootpn = length(f[0]) ? clean(f[2], 60) : '';
				}
				else if (k == 'dnsc') { let L = filter(map(split(v, ','), (x) => trim(x)), (x) => match(x, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)); if (!length(L)) return { error: 'indirizzo DNS non valido' }; O.dnsc = slice(L, 0, 2); }
				else if (VPNB[k] != null) { if (!match(v, /^[01]$/)) return { error: 'valore non valido' }; O[k] = v == '1'; }
				else if (VPNV[k]) { if (!match(v, VPNV[k][1]) && !(k == 'mtu' && v == '') && !(substr(k, 0, 4) == 'boot' && v == '')) return { error: 'valore non valido' }; O[k] = v; }
				else return { error: 'opzione non valida' };
				if (k == 'kill' && O.kill) for (let x in T) x.fb = false;
				if (k == 'dns' && v == 'own' && !length(O.dnsc)) O.dnsc = ['9.9.9.9'];
				if (index(['reset', 'kill', 'guest', 'dns', 'dnsc', 'v6', 'mtu', 'ka'], k) >= 0) { vpnapply(T, O); return { ok: true }; }
				cfgensure();
				let c = 'uci -q get wrtfreedom.vpnout >/dev/null || uci set wrtfreedom.vpnout=vpnout; ';
				for (let x in (k == 'bootpl' ? ['bootpl', 'bootcc', 'bootpn'] : [k])) c += 'uci set wrtfreedom.vpnout.' + x + '=' + q(VPNB[x] != null ? (O[x] ? 1 : 0) : O[x]) + '; ';
				sh(c + 'uci commit wrtfreedom');
				return { ok: true };
			}
			if (act == 'quick') {
				/* paese del collegamento rapido del servizio ('' = automatico) */
				let p = '' + (a.prov ?? ''), pl = '' + (a.place ?? '');
				if (index(PROVS, p) < 0 || !W['va_' + p] || !match(pl, /^[A-Za-z0-9_-]{0,40}$/)) return { error: 'paese non valido' };
				sh('uci set wrtfreedom.va_' + p + '.qplace=' + q(pl) + '; uci set wrtfreedom.va_' + p + '.qname=' + q(length(pl) ? clean(a.pname, 60) : '') + '; uci set wrtfreedom.va_' + p + '.qcc=' + q(length(pl) && match('' + (a.cc ?? ''), /^[A-Z]{2}$/) ? a.cc : '') + '; uci commit wrtfreedom');
				return { ok: true };
			}
			if (act == 'srvlist') {
				/* server di un paese, per scegliere quello esatto: letti in sottofondo, tenuti 5 minuti */
				let p = '' + (a.prov ?? ''), pl = '' + (a.place ?? '');
				if (index(PROVS, p) < 0 || !match(pl, /^[A-Za-z0-9_-]{1,40}$/)) return { error: 'paese non valido' };
				let f = '/tmp/wf-vpnsrv-' + p + '-' + pl + '.json', C = rd(f), s = stat(f);
				if (!C || !s || time() - s.mtime > 300) { sh('( ' + CTL + 'srvlist ' + p + ' ' + pl + ' ) >/dev/null 2>&1 &'); if (!C || time() - s.mtime > 3600) return { wait: true }; }
				return { list: C };
			}
			if (act == 'sched') {
				/* orario: nei giorni scelti, da «from» scollega o passa a un paese, a «to» torna come prima */
				let sid = '' + (a.sid ?? ''), d = '' + (a.days ?? ''), f = '' + (a.from ?? ''), t2 = '' + (a.to ?? ''), x = a.sact == 'place' ? 'place' : 'off', hm = /^([01][0-9]|2[0-3]):[0-5][0-9]$/;
				if (!match(d, /^[1-7]{1,7}$/) || !match(f, hm) || !match(t2, hm) || f == t2) return { error: 'giorni o orari non validi' };
				if (x == 'place' && (index(PROVS, '' + a.prov) < 0 || !match('' + (a.place ?? ''), /^[A-Za-z0-9_-]{1,40}$/))) return { error: 'scegli il paese' };
				if (length(sid) && !match(sid, /^vs_[a-z0-9]{1,12}$/)) return { error: 'orario non valido' };
				if (!length(sid)) {
					if (length(filter(keys(W), (k) => W[k]['.type'] == 'vpnsched')) >= 10) return { error: 'al massimo 10 orari' };
					sid = 'vs_' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '', /[^0-9a-f]/g, ''), 0, 8);
				}
				cfgensure();
				sh('uci set wrtfreedom.' + sid + '=vpnsched; uci set wrtfreedom.' + sid + '.name=' + q(clean(a.name, 30)) + '; uci set wrtfreedom.' + sid + '.days=' + d + '; uci set wrtfreedom.' + sid + '.from=' + f +
					'; uci set wrtfreedom.' + sid + '.to=' + t2 + '; uci set wrtfreedom.' + sid + '.act=' + x + '; uci set wrtfreedom.' + sid + '.prov=' + q(x == 'place' ? a.prov : '') + '; uci set wrtfreedom.' + sid + '.place=' + q(x == 'place' ? a.place : '') +
					'; uci set wrtfreedom.' + sid + '.pname=' + q(x == 'place' ? clean(a.pname, 60) : '') + '; uci set wrtfreedom.' + sid + '.cc=' + q(x == 'place' && match('' + (a.cc ?? ''), /^[A-Z]{2}$/) ? a.cc : '') +
					'; uci set wrtfreedom.' + sid + '.on=' + (a.on === false ? 0 : 1) + '; uci commit wrtfreedom');
				return { ok: true, sid: sid };
			}
			if (act == 'schdel') {
				let sid = '' + (a.sid ?? '');
				if (!match(sid, /^vs_[a-z0-9]{1,12}$/) || !W[sid]) return { error: 'orario non trovato' };
				sh('uci -q delete wrtfreedom.' + sid + '; uci commit wrtfreedom');
				return { ok: true };
			}
			/* collegamento nuovo o esistente: per quelli nuovi il primo è il principale, gli altri sono per dispositivi */
			let target = () => {
				let t = tun(a.tid);
				if (t) return t;
				if (length(T) >= 6) return { error: 'al massimo 6 collegamenti' };
				let used = map(T, (x) => x.n), n = 0;
				while (index(used, n) >= 0) n++;
				let id = n == 0 ? 'vt_main' : 'vt_' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '', /[^0-9a-f]/g, ''), 0, 8);
				let devs = map(vpndevs(a.devs), vpndevstr);
				if (n > 0 && !length(devs)) return { error: 'scegli i dispositivi che usano questo collegamento' };
				return { id: id, n: n, prof: 'vp_' + substr(id, 3), on: true, mode: n == 0 ? (a.mode == 'dev' || a.mode == 'except' ? a.mode : 'all') : 'dev', devs: devs, fb: false, isnew: true };
			};
			if (act == 'connect' || act == 'next') {
				/* servizi automatici: vpnctl.uc sceglie il server più veloce del paese e chiama «setprof» */
				let t = target();
				if (t.error) return t;
				let P = Ps[t.prof] ?? {}, p = act == 'next' ? P.prov : '' + (a.prov ?? ''), place = act == 'next' ? P.place : '' + (a.place ?? '');
				if (index(PROVS, p) < 0) return { error: act == 'next' ? 'questo collegamento usa un file: carica un altro file' : 'servizio non valido' };
				if (!match(place, /^[A-Za-z0-9_-]{1,40}$/)) return { error: 'paese non valido' };
				if (t.isnew && !devsOk(t, t.devs)) return { error: 'un dispositivo usa già un altro collegamento' };
				let host = act == 'connect' && match('' + (a.host ?? ''), /^[A-Za-z0-9.-]{1,80}$/) ? a.host : '';
				writefile('/tmp/wf-vpnreq.json', sprintf('%J', { tid: t.id, n: t.n, mode: t.mode, devs: t.devs, prov: p, place: place, skip: act == 'next' ? P.host : '', pname: clean(a.pname, 60), host: host, safe: safe }));
				return job(CTL + 'connect');
			}
			if (act == 'fadd') {
				/* file .conf di un servizio senza collegamento automatico: resta nella sua sezione, si usa con «fuse» */
				let x = vpnparse(a.conf);
				if (x.error) return x;
				x.id = 'vp_f' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '', /[^0-9a-f]/g, ''), 0, 8); x.lib = true;
				x.prov = match('' + (a.prov ?? ''), /^[a-z]{2,16}$/) ? a.prov : 'other'; x.name = clean(a.name, 40) || x.host; x.place = ''; x.cc = ''; x.city = ''; x.sname = ''; x.added = time();
				cfgensure();
				sh(vpnprofcmd(x) + 'uci commit wrtfreedom');
				return { ok: true, pid: x.id };
			}
			if (act == 'fuse') {
				/* collegamento (nuovo o esistente) con un file salvato */
				let P = Ps[a.pid];
				if (!P || !P.lib) return { error: 'file non trovato' };
				let t = target();
				if (t.error) return t;
				if (t.isnew && !devsOk(t, t.devs)) return { error: 'un dispositivo usa già un altro collegamento' };
				if (!t.isnew && t.prof != P.id && !Ps[t.prof]?.lib) sh('uci -q delete wrtfreedom.' + t.prof);
				t.prof = P.id; t.on = true; t.fb = false; delete t.isnew;
				if (!tun(t.id)) push(T, t);
				vpnapply(T, O);
				return { ok: true, tid: t.id };
			}
			if (act == 'fdel') {
				let P = Ps[a.pid];
				if (!P || !P.lib) return { error: 'file non trovato' };
				for (let x in T) if (x.prof == P.id) return { error: 'il file è usato da un collegamento: collegane un altro prima' };
				sh('uci -q delete wrtfreedom.' + P.id + '; uci commit wrtfreedom');
				return { ok: true };
			}
			if (act == 'provdel') {
				/* Esci dal servizio: via i suoi collegamenti, i suoi file e il suo accesso */
				let p = '' + (a.prov ?? '');
				if (!match(p, /^[a-z]{2,16}$/)) return { error: 'servizio non valido' };
				let pre = 'uci -q delete wrtfreedom.va_' + p + '; ';
				T = filter(T, (x) => { let P = Ps[x.prof] ?? {}; if (P.prov != p) return true; pre += 'uci -q delete wrtfreedom.' + x.id + '; ' + (P.lib ? '' : 'uci -q delete wrtfreedom.' + x.prof + '; '); return false; });
				for (let k, P in Ps) if (P.lib && P.prov == p) pre += 'uci -q delete wrtfreedom.' + k + '; ';
				vpnapply(T, O, pre);
				return { ok: true };
			}
			if (act == 'setprof') {
				let x = vpnparse(a.conf);
				if (x.error) return x;
				/* richiesta: quella di «connect» (/tmp/wf-vpnreq.json) o il file proprio di vpnctl.uc (tick, rotate, boot) */
				let rf = match('' + (a.req ?? ''), /^\/tmp\/wf-vpnreq(\.[0-9a-f]{1,16})?\.json$/) ? a.req : '/tmp/wf-vpnreq.json';
				let R = rd(rf) ?? {}, t = tun(R.tid) ?? { id: R.tid, n: +R.n, prof: 'vp_' + substr(R.tid, 3), on: true, mode: R.mode, devs: R.devs ?? [], fb: false, isnew: true };
				if (!match('' + (R.tid ?? ''), /^vt_[a-z0-9]{1,12}$/)) return { error: 'richiesta non valida' };
				/* collegamento che usava un file salvato: ora ha il suo server */
				if (Ps[t.prof]?.lib) t.prof = 'vp_' + substr(t.id, 3);
				x.id = t.prof; x.prov = R.prov; x.place = R.place;
				x.name = clean(a.name, 40); x.cc = match('' + (a.cc ?? ''), /^[A-Z]{2}$/) ? a.cc : ''; x.city = clean(a.city, 40); x.sname = clean(a.sname, 60); x.srvid = match('' + (a.srvid ?? ''), /^[0-9]{1,12}$/) ? a.srvid : '';
				t.on = true; t.fb = false; t.P = x; delete t.isnew;
				if (!tun(t.id)) push(T, t);
				/* ultimi paesi usati con questo servizio (al massimo 5; il collegamento rapido non conta) */
				let rc = '';
				if (R.place != 'auto' && match('' + R.prov, /^[a-z]{2,16}$/)) {
					let it = R.place + '|' + x.cc + '|' + clean(R.pname, 60), old = filter(vpnarr((W['va_' + R.prov] ?? {}).recent), (y) => split(y, '|')[0] != R.place);
					rc = 'uci -q delete wrtfreedom.va_' + R.prov + '.recent; ';
					for (let y in slice([it, ...old], 0, 5)) rc += 'uci add_list wrtfreedom.va_' + R.prov + '.recent=' + q(y) + '; ';
				}
				/* richiesta di «connect» o «next» fatta dall'app con safe: il cambio vero arriva adesso (dopo la scelta del
				   server), la copia si riarma da qui (resta quella di prima se ancora in attesa) e il tempo riparte */
				if (R.safe === true) { let e = vbak(); if (e !== true) return e; }
				vpnapply(T, O, vpnprofcmd(x) + rc);
				return { ok: true, tid: t.id };
			}
			if (act == 'onoff') {
				/* tutti i collegamenti insieme (Pianificazioni, bot, pannello) */
				if (!length(T)) return { error: 'servizio VPN non configurato' };
				for (let x in T) { x.on = !!a.on; x.fb = false; }
				vpnapply(T, O, UNP);
				return { ok: true };
			}
			let t = tun(a.tid);
			if (act == 'topts') {
				if (!t) return { error: 'collegamento non trovato' };
				if (a.on != null) { t.on = !!a.on; t.fb = false; }
				if (t.n == 0 && a.mode != null) t.mode = a.mode == 'dev' || a.mode == 'except' ? a.mode : 'all';
				if (a.devs != null) { let d = map(vpndevs(a.devs), vpndevstr); if (!devsOk(t, d)) return { error: 'un dispositivo usa già un altro collegamento' }; t.devs = d; }
				if ((t.n > 0 || t.mode != 'all') && !length(t.devs)) return { error: 'scegli almeno un dispositivo' };
				vpnapply(T, O, a.on ? UNP : null);
				return { ok: true };
			}
			if (act == 'addmac') {
				/* un altro MAC dello stesso dispositivo (MAC privato diverso per ogni Wi-Fi): dev = un suo MAC o il suo IP */
				if (!t) return { error: 'collegamento non trovato' };
				let m = lc(trim('' + (a.mac ?? ''))), dv = lc(trim('' + (a.dev ?? ''))), D = vpndevs(t.devs);
				if (!okmac(m) || m == '00:00:00:00:00:00') return { error: 'MAC non valido' };
				let x = filter(D, (d) => length(dv) && (index(d.macs, dv) >= 0 || d.ip == dv))[0];
				if (!x) return { error: 'dispositivo non trovato' };
				if (index(x.macs, m) >= 0) return { ok: true, same: true, macs: x.macs, priv: x.priv };
				for (let d in D) if (d != x && index(d.macs, m) >= 0) return { error: 'MAC già usato da un altro dispositivo' };
				push(x.macs, m); x.mac = x.macs[0]; x.priv = length(filter(x.macs, vpnmacpriv)) > 0;
				let nd = map(D, vpndevstr);
				if (!devsOk(t, nd)) return { error: 'un dispositivo usa già un altro collegamento' };
				t.devs = nd;
				vpnapply(T, O);
				return { ok: true, macs: x.macs, priv: x.priv };
			}
			if (act == 'fallback') {
				/* da vpnctl.uc: server che non risponde con il blocco spento → regole tolte; tornato → rimesse */
				if (!t || O.kill || t.fb == !!a.on) return { ok: true, same: true };
				t.fb = !!a.on; vpnapply(T, O);
				return { ok: true };
			}
			if (act == 'export') {
				/* configurazione WireGuard del collegamento, per un altro dispositivo (contiene la chiave privata) */
				let P = t ? Ps[t.prof] : null;
				if (!P) return { error: 'collegamento non trovato' };
				let mtu = length(O.mtu) ? O.mtu : P.mtu;
				return { name: substr(replace(lc(replace(P.sname || P.city || P.name || 'vpn', /\..*$/, '')), /[^a-z0-9_-]/g, ''), 0, 15) || 'vpn', conf: '[Interface]\nPrivateKey = ' + P.priv + '\nAddress = ' + join(', ', P.addr) + (length(P.dns) ? '\nDNS = ' + join(', ', P.dns) : '') + (length(mtu) ? '\nMTU = ' + mtu : '') +
					'\n\n[Peer]\nPublicKey = ' + P.pub + (length(P.psk) ? '\nPresharedKey = ' + P.psk : '') + '\nAllowedIPs = 0.0.0.0/0\nEndpoint = ' + P.host + ':' + P.port + (+O.ka > 0 ? '\nPersistentKeepalive = ' + O.ka : '') + '\n' };
			}
			if (act == 'leak') {
				if (!t) return { error: 'collegamento non trovato' };
				return job(CTL + 'leak ' + t.id);
			}
			if (act == 'tdel') {
				if (!t) return { error: 'collegamento non trovato' };
				T = filter(T, (x) => x.id != t.id);
				/* tolto il principale, quelli in più restano per i loro dispositivi; il prossimo nuovo sarà il principale */
				let pre = 'uci -q delete wrtfreedom.' + t.id + '; ' + (Ps[t.prof]?.lib ? '' : 'uci -q delete wrtfreedom.' + t.prof + '; ');	/* i file salvati restano */
				vpnapply(T, O, pre);
				return { ok: true };
			}
			if (act == 'migrate') {
				/* aggiornamento alla 2.53 (da install.sh): dispositivi dal MAC invece che dall'IP. Le voci senza MAC si
				   completano (vpnmacof); quelle il cui MAC non si trova restano con l'IP e con le regole per IP (byip = quante).
				   Niente da fare se le voci sono già a posto e non restano regole per IP di voci con il MAC, o senza fw4.
				   Con il ritorno automatico (vbak): senza confirm entro 120 s torna com'era */
				let chg = false, byip = 0, ipk = {};
				for (let t in T) {
					let D = vpndevs(t.devs), nd = map(D, vpndevstr);
					if (join('
', nd) != join('
', t.devs)) chg = true;
					t.devs = nd;
					for (let d in D) if (!length(d.macs)) { byip++; ipk[d.ip + '/32'] = 1; }
				}
				for (let k in N) if (N[k]['.type'] == 'rule' && match(k, /^wgout_r[0-9]{1,4}$/) && match(N[k].src ?? '', /^[0-9.]{7,15}\/32$/) && !ipk[N[k].src]) chg = true;
				if (!chg || !length(T) || !has('/usr/share/nftables.d')) return { ok: true, same: true, byip: byip };
				let e = vbak(); if (e !== true) return e;
				vpnapply(T, O);
				return { ok: true, byip: byip, confirm: 120 };
			}
			if (act == 'dnsips') {
				/* server DNS del router (da vpnctl.uc): si aggiungono e non si tolgono (rispondono ogni volta con alcuni dei
				   loro indirizzi: senza l'unione la rete si ricaricherebbe ogni 10 minuti); al massimo 24 */
				let D = [...O.dnsips];
				for (let x in (a.ips ?? [])) { x = '' + x; if (match(x, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) && index(D, x) < 0) push(D, x); }
				if (length(D) == length(O.dnsips) || length(O.dnsips) >= 24) return { ok: true, same: true };
				O.dnsips = slice(D, 0, 24);
				/* rete ricostruita solo se le regole servono (principale acceso, non in fallback, non «solo alcuni»);
				   altrimenti l'elenco si salva e basta, per quando serviranno */
				let m0 = filter(T, (t) => t.n == 0)[0];
				if (m0 && m0.on && !m0.fb && m0.mode != 'dev') vpnapply(T, O);
				else {
					let c = 'uci -q get wrtfreedom.vpnout >/dev/null || uci set wrtfreedom.vpnout=vpnout; uci -q delete wrtfreedom.vpnout.dnsips; ';
					for (let x in O.dnsips) c += 'uci add_list wrtfreedom.vpnout.dnsips=' + q(x) + '; ';
					sh(c + 'uci commit wrtfreedom');
				}
				return { ok: true };
			}
			if (act == 'del') {
				/* tutto: collegamenti, server, account dei servizi, interfacce, regole, zona e DNS */
				sh('for s in $(uci -q show wrtfreedom | sed -n "s/^wrtfreedom\\.\\([A-Za-z0-9_]*\\)=\\(vpnprof\\|vpntun\\|vpnacc\\|vpnsched\\)$/\\1/p"); do uci -q delete wrtfreedom.$s; done; uci -q delete wrtfreedom.vpnout; ' +
					'for i in $(uci -q show network | sed -nE "s/^network\\.(wgo(ut|[0-9]+))=interface$/\\1/p"); do ifdown $i 2>/dev/null; done; ' +
					VPNDEL + 'rm -f /tmp/wf-vpn*.json /etc/wrtfreedom/vpnuse.json /etc/wrtfreedom/vpnev.json; ' +
					'uci commit wrtfreedom; uci commit network; uci commit firewall; ( /etc/init.d/network reload; /etc/init.d/firewall reload ) >/dev/null 2>&1 &');
				return { ok: true };
			}
			return { error: 'azione non valida' };
			})();
			/* azione non riuscita: la copia appena fatta non serve (quella di prima, se c'era, resta) */
			if (safe) { if (r?.error) { if (!pend0) sh('rm -rf ' + bakdir('vpn')); } else r.confirm = 120; }
			return r;
		}
	},
	fo: {
		/* Linea Di Riserva: impostazioni e stato del controllo della linea (line.sh, 2.42: cambio in circa 3 s,
		   ritorno dopo 30 s di fila; niente più intervallo e prove da scegliere) */
		call: function() {
			let W = ucfile('wrtfreedom'), S = null;
			try { S = json(readfile('/tmp/wf-line.json') ?? 'null'); } catch (e) {}
			return { enabled: ug(W, 'fo', 'enabled') == '1', main: ug(W, 'fo', 'main'), backup: ug(W, 'fo', 'backup'), fast: true,
				state: S, zone: fwzones().wan };
		}
	},
	foset: {
		/* accende/spegne; la riserva va nella zona internet del firewall e ha una priorità più bassa della principale */
		args: { enabled: true, main: 'main', backup: 'backup', interval: 0, fails: 0 },
		call: function(req) {
			let a = req.args ?? {}, N = ucfile('network'), F = ucfile('firewall'), m = '' + (a.main ?? ''), b = '' + (a.backup ?? '');
			let on = !!a.enabled;	/* interval e fails: solo per le app più vecchie, non si usano più */
			let ok = (i) => match(i, /^[A-Za-z0-9_]{1,32}$/) && N[i] && N[i]['.type'] == 'interface' && i != 'loopback';
			if (on && (!ok(m) || !ok(b) || m == b)) return { error: 'scegli due linee diverse' };
			cfgensure();
			let cmd = 'uci -q get wrtfreedom.fo >/dev/null || uci set wrtfreedom.fo=fo; uci set wrtfreedom.fo.enabled=' + (on ? 1 : 0) + '; uci -q delete wrtfreedom.fo.interval; uci -q delete wrtfreedom.fo.fails; ';
			if (on) {
				cmd += 'uci set wrtfreedom.fo.main=' + m + '; uci set wrtfreedom.fo.backup=' + b + '; ';
				/* zona internet: quella con il NAT; la riserva ci va se non è già in una zona */
				let Z = fwzones().wan, zs = null, inz = null;
				for (let k in F) if (F[k]['.type'] == 'zone') {
					let nets = type(F[k].network) == 'array' ? F[k].network : split(F[k].network ?? '', ' ');
					if (F[k].name == Z) zs = k;
					if (index(nets, b) >= 0) inz = F[k].name;
				}
				if (inz && inz != Z) return { error: 'la linea di riserva è nella zona «' + inz + '» del firewall, non in quella di internet' };
				if (!inz && zs) cmd += 'uci add_list firewall.' + zs + '.network=' + b + '; uci commit firewall; /etc/init.d/firewall reload >/dev/null 2>&1; ';
				/* priorità: la riserva sempre dopo la principale (metric più alta) */
				let mm = +(N[m].metric ?? 0), bm = +(N[b].metric ?? 0);
				if (bm <= mm) cmd += 'uci set network.' + b + '.metric=' + (mm + 50) + '; uci commit network; ifup ' + b + '; ';
			}
			sh(cmd + 'uci commit wrtfreedom; ( sleep 1; /etc/init.d/wrtfreedom reload ) >/dev/null 2>&1 &');
			return { ok: true };
		}
	},
	fwstat: {
		/* tentativi bloccati dal firewall (2.45, fwstat.uc tick ogni minuto): oggi, ultima ora, porte più cercate */
		call: function() {
			let S = null; try { S = json(readfile('/tmp/wf-fwstat.json') ?? 'null'); } catch (e) {}
			return { s: S, now: time() };
		}
	},
	fwcustom: {
		/* Regole Personalizzate (2.56): {} = fwcstate {file, table, text, lines, rules, mtime, pend (s al ritorno)};
		   {text, apply: 1} = fw4 check, se non valide {error: 'invalid', out} e niente cambia, se valide fw4 reload con
		   ritorno dopo 60 s senza confirm (tag «fwc», evento cron_fwc_back) e {ok, pend: 60}; {confirm: 1} = conferma */
		args: { text: 'text', apply: 0, confirm: 0 },
		call: function(req) {
			let a = req.args ?? {};
			if (a.confirm) { bakconfirm('fwc'); return { ok: true }; }
			if (a.apply) return fwcapply(a.text ?? '');
			return fwcstate();
		}
	},
	ping1: {
		/* ping dal router per SQM (2.45): risponde subito con l'ultima misura e ne lancia una nuova in sottofondo (al
		   massimo ogni 4 s); indirizzo = il primo dei controlli della linea (wrtfreedom.fo.hosts), di serie 1.1.1.1 */
		call: function() {
			let L = null; try { L = json(readfile('/tmp/wf-ping1.json') ?? 'null'); } catch (e) {}
			if (!L || time() - (L.t ?? 0) >= 4) {
				let h = split(trim(ug(ucfile('wrtfreedom'), 'fo', 'hosts') || '1.1.1.1'), /[[:space:]]+/)[0];
				if (!match(h, /^[0-9A-Za-z.:-]{1,64}$/)) h = '1.1.1.1';
				sh("( r=$(ping -c 1 -W 2 " + h + " 2>/dev/null | sed -n 's/.*time=\\([0-9.]*\\).*/\\1/p'); printf '{\"ms\":%s,\"t\":%s}' \"${r:-null}\" $(date +%s) > /tmp/wf-ping1.json.n && mv /tmp/wf-ping1.json.n /tmp/wf-ping1.json ) >/dev/null 2>&1 &");
			}
			return { ms: L?.ms ?? null, t: L?.t ?? 0, now: time() };
		}
	},
	usage: {
		/* consumo della SIM (2.41, usage.uc): periodo in corso, impostazioni e storico; slow (2.47) = limite di velocità a
		   giga finiti: opzioni, attivo (active), tolto fino al prossimo periodo (unslow), esito di slow.sh (st: ok|err) */
		call: function() {
			let S = null; try { S = json(readfile('/tmp/wf-usage.json') ?? readfile('/etc/wrtfreedom/usage.json') ?? 'null'); } catch (e) {}
			let W = ucfile('wrtfreedom');
			return { s: S, day: +(ug(W, 'usage', 'day') || '1'), quota: +(ug(W, 'usage', 'quota') || '0'), warn: +(ug(W, 'usage', 'warn') || '80'), now: time(),
				slow: { on: ug(W, 'usage', 'slow') == '1', dl: +(ug(W, 'usage', 'slowdl') || '0'), ul: +(ug(W, 'usage', 'slowul') || '0'), at: +(ug(W, 'usage', 'slowat') || '100'),
					active: !!(S?.slow), unslow: !!(S?.unslow), st: trim(readfile('/tmp/wf-slow.on') ?? '') } };
		}
	},
	usageset: {
		/* giorno di rinnovo 1…31, giga dell'offerta (0 = senza limite), avviso in %; i valori non mandati restano.
		   2.47: slow (rallenta a giga finiti), slowdl/slowul in kbit/s (0 = quel verso libero), slowat = soglia 90 o 100 (% della
		   quota), unslow = togli il limite
		   fino al prossimo periodo (in sottofondo: slow.sh rimette SQM com'era) */
		args: { day: 0, quota: 'quota', warn: 0, reset: true, slow: true, slowdl: 0, slowul: 0, slowat: 0, unslow: true },
		call: function(req) {
			let a = req.args ?? {}, W = ucfile('wrtfreedom'), g0 = (k, def) => ug(W, 'usage', k) || def;
			let d = +(a.day ?? g0('day', '1')), g = +(a.quota ?? g0('quota', '0')), w = +(a.warn ?? g0('warn', '80'));
			if (d < 1 || d > 31 || g < 0 || g > 100000 || w < 10 || w > 99) return { error: 'valori non validi' };
			let sl = a.slow != null ? !!a.slow : g0('slow', '0') == '1', sdl = +(a.slowdl ?? g0('slowdl', '0')), sul = +(a.slowul ?? g0('slowul', '0'));
			if (sdl < 0 || sdl > 10000000 || sul < 0 || sul > 10000000) return { error: 'limiti non validi' };
			if (sl && !(sdl > 0 || sul > 0)) return { error: 'scegli almeno un limite di velocità' };
			let sat = +(a.slowat ?? g0('slowat', '100'));
			if (sat != 90 && sat != 100) return { error: 'soglia non valida (90 o 100)' };
			cfgensure();
			sh('uci -q get wrtfreedom.usage >/dev/null || uci set wrtfreedom.usage=usage; uci set wrtfreedom.usage.day=' + int(d) + '; uci set wrtfreedom.usage.quota=' + g + '; uci set wrtfreedom.usage.warn=' + int(w) +
				'; uci set wrtfreedom.usage.slow=' + (sl ? 1 : 0) + '; uci set wrtfreedom.usage.slowdl=' + int(sdl) + '; uci set wrtfreedom.usage.slowul=' + int(sul) + '; uci set wrtfreedom.usage.slowat=' + sat + '; uci commit wrtfreedom');
			/* azzera il periodo in corso (es. offerta cambiata): resta lo storico */
			if (a.reset) sh('ucode /usr/share/wrtfreedom/usage.uc reset >/dev/null 2>&1');
			/* limite tolto, oppure impostazioni nuove applicate subito (senza aspettare il giro dei 30 s) */
			sh('ucode /usr/share/wrtfreedom/usage.uc ' + (a.unslow ? 'unslow' : 'tick') + ' >/dev/null 2>&1 </dev/null &');
			return { ok: true };
		}
	},
	sms: {
		/* SMS del modem (2.41, sms.uc fuori da rpcd): list = elenco letto in sottofondo (al massimo ogni 15 s, «fresh» subito),
		   send = lavoro con il risultato, delete = in sottofondo */
		args: { action: 'action', num: 'num', text: 'text', id: 'id', fresh: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'list'), F = '/tmp/wf-sms.json', S = '/usr/share/wrtfreedom/sms.uc';
			if (act == 'list') {
				let st = stat(F), old = !st || time() - st.mtime > 15;
				if (old || a.fresh) sh('ucode ' + S + ' refresh >/dev/null 2>&1 &');
				if (!st) return { wait: true };
				let r = null; try { r = json(readfile(F)); } catch (e) {}
				return r ?? { wait: true };
			}
			if (act == 'send') {
				let num = '' + (a.num ?? ''), text = '' + (a.text ?? '');
				if (!match(num, /^\+?[0-9]{3,20}$/)) return { error: 'numero non valido' };
				if (!length(trim(text)) || length(text) > 1600) return { error: 'testo non valido' };
				writefile('/tmp/wf-sms.out', text);
				return job('ucode ' + S + ' send ' + q(num) + ' /tmp/wf-sms.out 2>&1; rm -f /tmp/wf-sms.out');
			}
			if (act == 'delete') {
				let id = '' + (a.id ?? '');
				if (!match(id, /^[0-9]{1,6}$/)) return { error: 'messaggio non valido' };
				sh('ucode ' + S + ' delete ' + id + ' >/dev/null 2>&1 &');
				return { ok: true };
			}
			return { error: 'azione non valida' };
		}
	},
	ussd: {
		/* codici USSD (2.47, ussd.uc in sottofondo: la rete risponde in secondi). send {code}, reply {code} e cancel rispondono
		   subito {busy: true}; get = ultimo risultato {t, act, code, via, state: idle|user-response|error, text, err, busy} */
		args: { action: 'action', code: 'code' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), code = trim('' + (a.code ?? '')), F = '/tmp/wf-ussd.json', r = null;
			try { r = json(readfile(F) ?? 'null'); } catch (e) {}
			let ls = stat('/tmp/wf-ussd.lock'), busy = (ls != null && time() - ls.mtime < 120) || (!!r?.busy && time() - +(r.t ?? 0) < 120);
			if (act == 'get') return { ...(r ?? { state: 'idle', text: '' }), busy: busy };
			if (index([ 'send', 'reply', 'cancel' ], act) < 0) return { error: 'azione non valida' };
			if (act == 'send' && !match(code, /^[0-9*#+]{2,40}$/)) return { error: 'codice non valido' };
			if (act == 'reply' && !match(code, /^[0-9A-Za-z*#+ ]{1,40}$/)) return { error: 'risposta non valida' };
			if (act != 'cancel' && busy) return { busy: true, error: 'richiesta USSD già in corso' };
			/* in attesa da subito: la lettura dopo vede «busy» anche se ussd.uc non è ancora partito */
			writefile(F, sprintf('%J', { ...(r ?? {}), t: time(), act: act, code: act == 'send' ? code : (r?.code ?? ''), busy: true }));
			sh('ucode /usr/share/wrtfreedom/ussd.uc ' + act + (act == 'cancel' ? '' : ' ' + q(code)) + ' >/dev/null 2>&1 </dev/null &');
			return { busy: true };
		}
	},
	sighist: {
		/* storico del segnale (2.47, sighist.uc ogni minuto da notify.sh). range 24h: righe al minuto [t, tecnologia, rsrp,
		   rsrq, sinr, rsrp 5G, rsrq 5G, sinr 5G, linea 1/0] e ore delle cadute di internet; range 7d: riassunti orari
		   {h, n, tech, lr, lq, ls, nr, nq, ns, drops, down, nosig} con l'ora in corso per ultima */
		args: { range: 'range' },
		call: function(req) {
			let rg = '' + (req.args?.range ?? '24h'), now = time(), S = null;
			try { S = json(readfile('/tmp/wf-sighist.7d.json') ?? readfile('/etc/wrtfreedom/sighist.json') ?? 'null'); } catch (e) {}
			if (rg == '7d') {
				let H = filter(S?.h ?? [], (x) => x && +x.h > now - 7 * 86400);
				if (S?.now && +S.now.h > now - 7200) push(H, S.now);
				return { range: '7d', now: now, on: S != null, hours: H };
			}
			if (rg != '24h') return { error: 'intervallo non valido' };
			let rows = [], drops = [], nv = (x) => (x == null || x == '-') ? null : +x;
			for (let l in split(readfile('/tmp/wf-sighist.24h') ?? '', '\n')) {
				let f = split(l, ' ');
				if (length(f) < 9 || +f[0] <= now - 86400) continue;
				push(rows, [ +f[0], f[1] == '-' ? '' : f[1], nv(f[2]), nv(f[3]), nv(f[4]), nv(f[5]), nv(f[6]), nv(f[7]), nv(f[8]) ]);
			}
			for (let l in split((readfile('/tmp/wf-sighist.drops') ?? '') + (readfile('/tmp/wf-line.drops') ?? ''), '\n')) if (+l > now - 86400) push(drops, +l);
			return { range: '24h', now: now, on: length(rows) > 0, step: 60, cols: [ 't', 'tech', 'rsrp', 'rsrq', 'sinr', 'nrrsrp', 'nrrsrq', 'nrsinr', 'up' ], rows: rows, drops: drops };
		}
	},
	sigfast: {
		/* Trova Il Punto Migliore (2.47, sigfast.uc): {on: true} avvia la lettura veloce (al massimo 5 minuti), {on: false} la
		   ferma, {} = ultima lettura e la tiene viva (senza richieste per 15 s si ferma da sola) */
		args: { on: true },
		call: function(req) {
			let P = '/tmp/wf-sigfast', on = req.args?.on, up = int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]));
			let pid = trim(readfile(P + '.pid') ?? ''), run = length(pid) > 0 && index(readfile('/proc/' + pid + '/cmdline') ?? '', 'sigfast') >= 0;
			if (on === false) writefile(P + '.want', '0');
			else if (on === true || run) writefile(P + '.want', '' + up);
			if (on === true && !run) { unlink(P + '.json'); system('ucode /usr/share/wrtfreedom/sigfast.uc >/dev/null 2>&1 &'); run = true; }
			let r = null; try { r = json(readfile(P + '.json') ?? 'null'); } catch (e) {}
			return { ...(r ?? { on: run, wait: run }), run: run, now: time() };
		}
	},
	simslot: {
		/* seconda SIM (2.47, sim.uc in sottofondo: il modem si riavvia). get = slot letti dal modem {via, slots, active, sims,
		   busy, last, auto, after, onquota, back ('0'|'1'|'renew'), backwait, minwait, main, apn1, apn2}; set {slot} = cambio
		   (lavoro, {busy: true}); cfg {auto, after, onquota, back, backwait, minwait, main, apn1, apn2} = cambio automatico
		   (lo fa line.sh una volta al minuto) e profilo dati (APN) di ogni slot ('' = quello dell'interfaccia).
		   2.63 (Rischio Alto): set con secs (60–900, consigliati 300) = ritorno allo slot di prima se non arriva confirm
		   (bakarm 'sim', aspetta la fine del cambio); dry = solo la frase (say); confirm, back; get dà anche pend */
		args: { action: 'action', slot: 0, auto: true, after: 0, onquota: true, back: 'back', backwait: 0, minwait: 0, main: 0, apn1: 'apn', apn2: 'apn', secs: 0, dry: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), F = '/tmp/wf-sim.json', S = '/usr/share/wrtfreedom/sim.uc', r = null;
			try { r = json(readfile(F) ?? 'null'); } catch (e) {}
			let ls = stat('/tmp/wf-sim.lock'), lp = stat('/tmp/wf-sim.pend'), busy = (ls != null && time() - ls.mtime < 600) || (lp != null && time() - lp.mtime < 15);
			if (act == 'get') {
				if (!busy && (!r || time() - +(r.t ?? 0) > 60)) sh('ucode ' + S + ' read >/dev/null 2>&1 </dev/null &');
				let W = ucfile('wrtfreedom'), L = null; try { L = json(readfile('/etc/wrtfreedom/sim.last') ?? 'null'); } catch (e) {}
				return { ...(r ?? { wait: true }), busy: busy, last: L, auto: ug(W, 'sim', 'auto') == '1', after: +(ug(W, 'sim', 'after') || '5'),
					onquota: ug(W, 'sim', 'onquota') == '1', back: ug(W, 'sim', 'back') || '0', backwait: +(ug(W, 'sim', 'backwait') || '360'),
					minwait: +(ug(W, 'sim', 'minwait') || '30'), main: +(ug(W, 'sim', 'main') || '1'), apn1: ug(W, 'sim', 'apn1'), apn2: ug(W, 'sim', 'apn2'), pend: bakleft('sim') };
			}
			if (act == 'confirm') return bakconfirm('sim');
			if (act == 'back') return bakback('sim', L('↩️ Seconda SIM: rimesso lo slot di prima', '↩️ Second SIM: previous slot restored'));
			if (act == 'set') {
				let n = int(+(a.slot ?? 0)), sec = +(a.secs ?? 0) > 0 ? hisecs(a.secs) : 0, oldslot = int(+(r?.active ?? 0)), say = null;
				if (n < 1 || n > 8 || (r && n > +(r.slots ?? 1))) return { error: 'slot non valido' };
				if (sec || a.dry) {
					if (oldslot < 1) return hierr('noslot', 'slot attivo non ancora letto: riprova tra poco', 'active slot not read yet: try again shortly');
					if (n == oldslot) return { ok: true, same: true };
					say = L('Passo dalla SIM dello slot ' + oldslot + ' a quella dello slot ' + n + ': il modem si riavvia e internet manca per circa un minuto' + (sec ? '; se non confermi entro ' + sec + ' secondi torno allo slot ' + oldslot : '') + '.',
						'I switch from the SIM in slot ' + oldslot + ' to the one in slot ' + n + ': the modem restarts and the internet is down for about a minute' + (sec ? '; without your confirmation within ' + sec + ' seconds I go back to slot ' + oldslot : '') + '.');
					if (a.dry) return { ok: true, dry: true, say: say };
				}
				if (busy) return { busy: true, error: 'cambio SIM già in corso' };
				if (sec) {
					if (bakpend('sim')) return { error: L('conferma prima il cambio SIM in attesa', 'confirm the pending SIM switch first'), code: 'pend', pend: 'sim' };
					/* ritorno: aspetta che il cambio in corso finisca (blocco di sim.uc, al massimo 10 minuti), poi lo slot di prima */
					let e = bakarm('sim', [], [], 'i=0; while [ -d /tmp/wf-sim.lock ] && [ $i -lt 120 ]; do sleep 5; i=$((i+1)); done; ucode ' + S + ' set ' + oldslot + ' manual', sec,
						L('↩️ Seconda SIM: nessuna conferma entro ' + sec + ' s, torno allo slot ' + oldslot, '↩️ Second SIM: no confirmation within ' + sec + ' s, back to slot ' + oldslot));
					if (e !== true) return e;
				}
				writefile('/tmp/wf-sim.pend', '' + n);
				sh('ucode ' + S + ' set ' + n + ' manual >/dev/null 2>&1 </dev/null &');
				return sec ? { busy: true, pend: sec, from: oldslot, say: say } : { busy: true };
			}
			if (act == 'cfg') {
				let c = 'uci -q get wrtfreedom.sim >/dev/null || uci set wrtfreedom.sim=sim; ', bnd = { after: [ 1, 240 ], minwait: [ 5, 1440 ], main: [ 1, 8 ], backwait: [ 30, 2880 ] };
				for (let k in [ 'auto', 'onquota' ]) if (a[k] != null) c += 'uci set wrtfreedom.sim.' + k + '=' + (a[k] ? 1 : 0) + '; ';
				if (a.back != null) {
					let b = '' + a.back;
					if (index([ '0', '1', 'renew' ], b) < 0) return { error: 'ritorno non valido' };
					c += 'uci set wrtfreedom.sim.back=' + b + '; ';
				}
				for (let k in [ 'apn1', 'apn2' ]) if (a[k] != null) {
					let v = trim('' + a[k]);
					if (length(v) && !match(v, /^[A-Za-z0-9._-]{1,64}$/)) return { error: 'APN non valido' };
					c += length(v) ? 'uci set wrtfreedom.sim.' + k + '=' + q(v) + '; ' : 'uci -q delete wrtfreedom.sim.' + k + '; ';
				}
				for (let k in bnd) if (a[k] != null) {
					let v = int(+a[k]);
					if (v < bnd[k][0] || v > bnd[k][1]) return { error: 'valori non validi' };
					c += 'uci set wrtfreedom.sim.' + k + '=' + v + '; ';
				}
				cfgensure();
				sh(c + 'uci commit wrtfreedom');
				return { ok: true };
			}
			return { error: 'azione non valida' };
		}
	},
	simpin: {
		/* PIN della SIM (2.47, sim.uc pin in sottofondo). get = {via, enabled (richiesta attiva), retries (tentativi del PIN),
		   puk, state, busy, last: {act, ok, err, t}}; enable/disable {pin}, change {pin, newpin} = lavoro, {busy: true}.
		   Il PIN passa in un file temporaneo (mai sulla riga di comando, nei registri o nelle risposte). Con un solo tentativo
		   rimasto si rifiuta, salvo force: true (dopo serve il PUK) */
		args: { action: 'action', pin: 'pin', newpin: 'pin', force: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), F = '/tmp/wf-simpin.json', S = '/usr/share/wrtfreedom/sim.uc', r = null;
			try { r = json(readfile(F) ?? 'null'); } catch (e) {}
			let ls = stat('/tmp/wf-sim.lock'), lp = stat('/tmp/wf-simpin.pend'), busy = (ls != null && time() - ls.mtime < 600) || (lp != null && time() - lp.mtime < 30);
			if (act == 'get') {
				if (!busy && (!r || time() - +(r.t ?? 0) > 60)) sh('ucode ' + S + ' pin get >/dev/null 2>&1 </dev/null &');
				return { ...(r ?? { wait: true }), busy: busy };
			}
			if (index([ 'enable', 'disable', 'change' ], act) < 0) return { error: 'azione non valida' };
			let pin = '' + (a.pin ?? ''), np = '' + (a.newpin ?? '');
			if (!match(pin, /^[0-9]{4,8}$/) || (act == 'change' && !match(np, /^[0-9]{4,8}$/))) return { error: 'PIN non valido (4–8 cifre)' };
			if (busy) return { busy: true, error: 'operazione sulla SIM già in corso' };
			if (r?.retries != null && +r.retries <= 1 && !a.force) return { error: 'resta un solo tentativo: se il PIN è sbagliato servirà il PUK', retries: r.retries, confirm: true };
			let f = '/tmp/wf-simpin.' + time() + '.in';
			writefile(f, pin + (act == 'change' ? ' ' + np : ''));
			sh('chmod 600 ' + f);
			writefile('/tmp/wf-simpin.pend', act);
			sh('ucode ' + S + ' pin ' + act + ' ' + f + ' >/dev/null 2>&1 </dev/null &');
			return { busy: true };
		}
	},
	nrmode: {
		/* 5G (2.47, modemctl.uc nrmode in sottofondo): get = {mode: nsa (4G + 5G NSA, di serie) | auto (NSA e SA) | sa (solo 5G
		   SA), can (il modem lo permette: comandi della marca o ModemManager con bande 5G), busy, last {t, mode, ok, err,
		   wait, restored}}; set {mode} = lavoro, {busy: true}: con la linea accesa, se in 3 minuti internet non torna il
		   router rimette la modalità di prima */
		args: { action: 'action', mode: 'mode' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), F = '/tmp/wf-nrmode.json', r = null;
			try { r = json(readfile(F) ?? 'null'); } catch (e) {}
			let st = stat(F), busy = !!(r?.busy || r?.wait) && st != null && time() - st.mtime < 300;
			if (act == 'get') {
				/* niente comandi al modem qui: bande 5G dall'ultima lettura di ModemManager in sottofondo */
				let I = M.id(), D = M.drv(I), g = null;
				try { g = json(readfile('/tmp/wf-modem.mm') ?? 'null')?.modem?.generic; } catch (e) {}
				let nr5 = index(join(' ', g?.['supported-bands'] ?? []), 'ngran') >= 0;
				return { mode: ug('wrtfreedom', 'modem', 'nrmode') || 'nsa', can: !!(D?.nrmode) || (!!I.mm && nr5), busy: busy, last: r };
			}
			if (act != 'set') return { error: 'azione non valida' };
			let m = '' + (a.mode ?? '');
			if (index([ 'nsa', 'auto', 'sa' ], m) < 0) return { error: 'modalità non valida' };
			if (busy) return { busy: true, error: 'cambio del 5G già in corso' };
			writefile(F, sprintf('%J', { t: time(), mode: m, busy: true }));
			sh('ucode /usr/share/wrtfreedom/modemctl.uc nrmode ' + m + ' >/dev/null 2>&1 </dev/null &');
			return { busy: true };
		}
	},
	modemset: {
		/* 2.64 B6 (Assistente IA): get = mdstate; roam {on, secs} = Roaming Dati con copia dell'opzione e ricollegamento della
		   linea (bakarm 'roam', ritorno dopo secs senza confirm); wd {on} = Ripristino Automatico del pacchetto (mai con il
		   5g-watchdog dell'utente); confirm, back */
		args: { action: 'action', on: true, secs: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), on = a.on === true;
			if (act == 'confirm') return bakconfirm('roam');
			if (act == 'back') return bakback('roam', L('↩️ Roaming Dati: rimesso com\'era', '↩️ Data Roaming: restored'));
			let S = mdstate();
			if (act == 'get') return S;
			if (act == 'wd') {
				if (S.wd.tools) return hierr('tools', 'il controllo della linea lo fanno gli Strumenti Modem 5G: si cambia lì', 'the line check is done by the 5G Modem Tools: it is changed there');
				if (S.wd.on == on) return { ok: true, changed: false };
				cfgensure();
				sh('uci -q get wrtfreedom.wd >/dev/null || uci set wrtfreedom.wd=watchdog; uci set wrtfreedom.wd.enabled=' + (on ? '1' : '0') + '; uci commit wrtfreedom; ( /etc/init.d/wrtfreedom reload ) >/dev/null 2>&1 </dev/null &');
				return { ok: true, changed: true };
			}
			if (act != 'roam') return { error: 'azione non valida' };
			if (S.roam == null) return hierr('nomodem', 'questo router non ha una linea mobile', 'this router has no mobile line');
			if (S.roam == on) return { ok: true, changed: false };
			if (ucpend('network')) return hierr('luci', 'ci sono modifiche della rete non applicate (LuCI): applicale o annullale prima', 'there are unapplied network changes (LuCI): apply or revert them first');
			let secs = hisecs(a.secs), e = bakarm('roam', { network: { n: S.iface, o: [ 'allow_roaming' ] } }, [], 'ifup ' + q(S.iface), secs,
				L('↩️ Roaming Dati: nessuna conferma entro ' + secs + ' s, rimesso com\'era', '↩️ Data Roaming: no confirmation within ' + secs + ' s, restored'));
			if (e !== true) return e;
			sh((on ? udel('network', S.iface, 'allow_roaming') : uset('network', S.iface, 'allow_roaming', '0')) + 'uci commit network; ( ifup ' + q(S.iface) + ' ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, changed: true, pend: secs };
		}
	},
	sysset: {
		/* 2.64 B7 (Assistente IA): Nome Del Router, Fuso Orario, Ora Automatica (come la pagina Sistema). get = systate più
		   zones [{id, name}]; set {hostname, zone, ntp} = /etc/config/system, poi system reload e sysntpd in sottofondo */
		args: { action: 'action', hostname: 'hostname', zone: 'zone', ntp: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), S = systate();
			if (act == 'get') return { hostname: S.hostname, zone: S.zone, ntp: S.ntp, zones: map(SYTZR, (x) => ({ id: x[0], name: x[1] })) };
			if (act != 'set') return { error: 'azione non valida' };
			if (!S.sec) return hierr('nosys', 'impostazioni del sistema non trovate', 'system settings not found');
			let c = '', rl = false, nt = false;
			if (a.hostname != null) {
				let h = '' + a.hostname;
				if (!match(h, /^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/)) return hierr('name', 'nome non valido: lettere senza accenti, cifre e trattini, fino a 63', 'invalid name: plain letters, digits and dashes, up to 63');
				if (h != S.hostname) { c += uset('system', S.sec, 'hostname', h); rl = true; }
			}
			if (a.zone != null) {
				let z = '' + a.zone, t = sytz(z);
				if (!t) return hierr('zone', 'fuso orario non valido', 'invalid time zone');
				if (z != S.zone) { c += uset('system', S.sec, 'zonename', z) + uset('system', S.sec, 'timezone', t); rl = true; }
			}
			if (a.ntp != null && (a.ntp === true) != S.ntp) { c += 'uci -q get system.ntp >/dev/null || uci set system.ntp=timeserver; ' + uset('system', 'ntp', 'enabled', a.ntp === true ? '1' : '0'); nt = true; }
			if (!length(c)) return { ok: true, changed: false };
			sh(c + 'uci commit system; ( ' + (rl ? '/etc/init.d/system reload; ' : '') + (nt ? '[ -x /etc/init.d/sysntpd ] && /etc/init.d/sysntpd restart; ' : '') + ': ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, changed: true };
		}
	},
	cbs: {
		/* allerte IT-Alert / Cell Broadcast (2.47, cbs.uc). get = supporto {supported, via mm|at, reason nomodem|mmold|nocb|
		   noport|setfail, channels, enabled} e ultimi messaggi {list: [{t, ch, sn, text, sev, test, via}]}; il rilevamento
		   (solo lettura) si rifà in sottofondo ogni ora. setup {on} = accende o spegne la ricezione (lavoro, {busy: true}) */
		args: { action: 'action', on: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), C = '/usr/share/wrtfreedom/cbs.uc';
			let ld = (f) => { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } };
			let ls = stat('/tmp/wf-cbs.lock'), busy = ls != null && time() - ls.mtime < 120;
			if (act == 'setup') {
				if (busy) return { busy: true };
				sh('ucode ' + C + ' setup ' + (a.on === false ? 'off' : 'on') + ' >/dev/null 2>&1 </dev/null &');
				return { busy: true };
			}
			if (act != 'get') return { error: 'azione non valida' };
			let s = ld('/tmp/wf-cbs.sup'), m = ld('/tmp/wf-cbs.json') ?? ld('/etc/wrtfreedom/cbs.json');
			if (!busy && (!s || time() - +(s.t ?? 0) > 3600)) sh('ucode ' + C + ' detect >/dev/null 2>&1 </dev/null &');
			if (!s) return { wait: true, supported: null, busy: busy, list: m?.list ?? [] };
			return { ...s, busy: busy, list: m?.list ?? [] };
		}
	},
	cron: {
		/* Pianificazioni (2.53). get = { lines [{id, on, when, cmd, meta, last {t, rc, k}}], sys [righe di sistema], wf [{tag,
		   line}] righe del pacchetto (gestite dalla loro pagina, mai modificabili), fixed, guard {left} }.
		   set {lines [righe dell'app], sys [righe di sistema: solo se c'è], guard, secs}: le righe «# wf:» restano com'erano.
		   Con un'attività nuova o cambiata che toglie la rete (o guard) il crontab di prima torna da solo dopo secs (di serie
		   120) se l'app non manda confirm; risposta { ok, changed, guard: secondi o 0 }. confirm, back = come bakarm.
		   log = { list [{t, id, rc, k, name}] } dal più recente (k: c orario, r recuperata all'avvio, n Esegui Ora).
		   run {id} = Esegui Ora in sottofondo, nel registro; con un'azione che toglie la rete conferma con ritorno (guard) */
		args: { action: 'action', lines: [], sys: [], guard: true, secs: 0, id: 'id', ids: [], edits: [] },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), why = L('Pianificazioni non confermate: rimesse com\'erano', 'Schedules not confirmed: put back as they were');
			if (act == 'confirm') return bakconfirm('cron');
			if (act == 'back') return bakback('cron', why);
			let C = crsplit(readfile(CRONF) ?? '');
			if (act == 'get') {
				let last = {};
				for (let x in reverse(crlog(300))) last[x.id] = x;
				return { lines: map(C.app, (p) => ({ id: p.id, on: p.on, when: p.when, cmd: p.cmd, meta: p.meta, last: last[p.id] ?? null, net: crnet(p) != null })),
					sys: C.sys, wf: C.wf, fixed: C.fixed, guard: { left: bakleft('cron') } };
			}
			if (act == 'log') {
				let N = {};
				for (let p in C.app) N[p.id] = { name: p.meta.n ?? '', a: p.meta.a ?? '' };
				return { list: map(crlog(200), (x) => ({ t: x.t, id: x.id, rc: x.rc, k: x.k, name: N[x.id]?.name ?? '', a: N[x.id]?.a ?? '' })) };
			}
			if (act == 'run') {
				let id = '' + (a.id ?? ''), p = filter(C.app, (x) => x.id == id)[0];
				if (!p) return { error: 'attività non trovata' };
				let back = crnet(p), secs = 0;
				/* anche con il ritorno vuoto (riavvio, linea, modem: '') serve la conferma con ritorno */
				if (back != null) {
					secs = (a.secs >= 60 && a.secs <= 600) ? int(a.secs) : 120;
					let r = bakarm('cron', [], [], back || 'true', secs, why);
					if (type(r) == 'object') return r;
				}
				svcbg('run ' + id);
				return { ok: true, guard: back != null ? secs : 0 };
			}
			/* Regole Dette A Parole (2.62, ai.uc): add = da 1 a 4 righe dell'app in più (mai azioni che tolgono la rete: niente
			   ritorno), del = toglie le righe dell'app per id; le altre righe restano com'erano */
			if (act == 'add' || act == 'del') {
				/* 2.64: il «cron del» con cui una riga «una volta sola» (meta.once) si toglie dopo essere partita passa anche con
				   Pianificazioni in attesa di conferma (solo righe once o già tolte) */
				let onlyonce = act == 'del' && type(a.ids) == 'array' && length(a.ids) > 0 && !length(filter(C.app, (p) => index(a.ids, p.id) >= 0 && !(p.meta.once == 1 || p.meta.once === true)));
				if (bakleft('cron') > 0 && !onlyonce) return { error: L('Pianificazioni in attesa di conferma: riprova tra poco', 'Schedules waiting for confirmation: try again shortly') };
				let ids = [], A = C.app;
				if (act == 'add') {
					if (type(a.lines) != 'array' || !length(a.lines) || length(a.lines) > 4) return { error: 'riga non valida' };
					let N = [];
					for (let l in a.lines) {
						if (type(l) != 'string' || length(l) > 2000 || index(l, '\n') >= 0 || index(l, '\r') >= 0) return { error: 'riga non valida' };
						let p = crparse(rtrim(l));
						if (!p || !p.on || !match(p.when, /^[0-9A-Za-z*\/,-]{1,60}( [0-9A-Za-z*\/,-]{1,60}){4}$/) || match(p.cmd, CRSVC)) return { error: 'riga non valida' };
						push(N, p);
					}
					/* 2.64: Spegni Il Wi-Fi (woff) e Spegni VPN (vpnoff) solo con la loro riaccensione (CRPAIR, stesso nome) nella stessa
					   aggiunta: la rete torna da sola; il riavvio solo una volta sola (meta.once, la riga si toglie prima di riavviare) */
					for (let p in N) {
						let b = CRPAIR[p.meta.a ?? ''], pair = (b != null && length(p.meta.n ?? '') && length(filter(N, (y) => y.meta.a == b && '' + (y.meta.n ?? '') == '' + p.meta.n)) > 0) ||
							(p.meta.a == 'reboot' && (p.meta.once == 1 || p.meta.once === true));
						if ((crnet(p) != null && !pair) || p.meta.w != null) return { error: L('questa attività toglie la rete: salvala da Pianificazioni', 'this task takes the network down: save it from Schedules') };
						if (length(filter(A, (x) => x.id == p.id))) return { error: 'attività già presente' };
						push(A, p); push(ids, p.id);
					}
				}
				else {
					ids = filter(type(a.ids) == 'array' ? a.ids : [], (x) => match('' + x, /^[0-9a-f]{8}$/) != null);
					A = filter(A, (p) => index(ids, p.id) < 0);
				}
				C.app = A;
				crwrite(crtext(C));
				return { ok: true, ids: ids };
			}
			/* 2.64 B4 (Assistente IA): edit {edits [{id, on, when, r, n}], secs} = una o più righe dell'app accese, spente o con un
			   orario nuovo (r = Recupera Se Saltata, n = nome), le altre com'erano; poi come set (conferma con ritorno se toglie la rete) */
			if (act == 'edit') {
				if (bakleft('cron') > 0) return { error: L('Pianificazioni in attesa di conferma: riprova tra poco', 'Schedules waiting for confirmation: try again shortly') };
				if (type(a.edits) != 'array' || !length(a.edits) || length(a.edits) > 4) return { error: 'modifica non valida' };
				let N = map(C.app, (x) => ({ ...x, meta: { ...x.meta } }));
				for (let e in a.edits) {
					let p = type(e) == 'object' ? filter(N, (x) => x.id == '' + (e.id ?? ''))[0] : null;
					if (!p) return { error: 'attività non trovata' };
					if (e.on != null) p.on = !!e.on;
					if (e.when != null) {
						if (!match('' + e.when, /^[0-9A-Za-z*\/,-]{1,60}( [0-9A-Za-z*\/,-]{1,60}){4}$/)) return { error: 'orario non valido' };
						p.when = '' + e.when;
					}
					if (e.n != null) p.meta.n = substr(replace('' + e.n, /[[:cntrl:]]+/g, ' '), 0, 60);
					if (e.r != null) { if (e.r) p.meta.r = 1; else delete p.meta.r; }
					if (e.r != null || e.n != null) p.mraw = replace(sprintf('%J', p.meta), '%', () => '\\%');
				}
				a = { lines: map(N, crline), secs: a.secs };
				act = 'set';
			}
			if (act != 'set' || type(a.lines) != 'array') return { error: 'azione non valida' };
			let cur = {}, A = [], S = C.sys, guard = a.guard === true, back = {};
			for (let p in C.app) cur[crline(p)] = true;
			for (let l in a.lines) {
				if (type(l) != 'string' || length(l) > 2000 || (index(l, '\n') >= 0 || index(l, '\r') >= 0)) return { error: 'riga non valida' };
				let p = crparse(rtrim(l));
				if (!p || !match(p.when, /^[0-9A-Za-z*\/,-]{1,60}( [0-9A-Za-z*\/,-]{1,60}){4}$/)) return { error: 'riga non valida: ' + substr(l, 0, 60) };
				push(A, p);
				/* Riavvia Router salvato o riacceso: niente conferma con ritorno (serve solo eseguendolo ora: dopo il riavvio
				   il ritorno non ci sarebbe più) */
				let r = p.meta.a == 'reboot' ? null : crnet(p);
				if (r != null && p.on && !cur[crline(p)]) { guard = true; if (length(r)) back[r] = true; }
			}
			if (type(a.sys) == 'array') {
				S = [];
				for (let l in a.sys) {
					if (type(l) != 'string' || length(l) > 2000 || (index(l, '\n') >= 0 || index(l, '\r') >= 0)) return { error: 'riga non valida' };
					l = rtrim(l);
					/* righe del pacchetto e dell'app non passano da qui */
					if (length(l) && !match(l, CRWF) && !match(l, / #(wrtfreedom|x3000) /)) push(S, l);
				}
			}
			let C0 = C.app;
			C.app = A; C.sys = S;
			let n = crtext(C), secs = 0;
			if (n == (readfile(CRONF) ?? '')) return { ok: true, changed: false, guard: 0, fixed: 0 };
			if (guard) {
				secs = (a.secs >= 60 && a.secs <= 600) ? int(a.secs) : 120;
				let r = bakarm('cron', [], [CRONF], '/etc/init.d/cron restart; ' + join('; ', keys(back)) + (length(back) ? '; ' : '') + 'true', secs, why);
				if (type(r) == 'object') return r;
			}
			/* attività All'Avvio tolte, spente o cambiate: il processo vecchio si ferma prima della scrittura */
			let sv = (X) => { let o = {}; for (let p in X) if (p.on && match(p.cmd, CRSVC)) o[p.id] = crline(p); return o; };
			let o1 = sv(C0), o2 = sv(A);
			for (let id in keys({ ...o1, ...o2 })) if (o1[id] != o2[id]) crsvcstop(id);
			crwrite(n);
			/* attività con «recupera» nuove: ora di partenza per il recupero all'avvio (svc.uc boot), file scritto solo se cambia */
			let F = '/etc/wrtfreedom/cronlast.json', R = rjs(F) ?? {}, R2 = {}, ch = false;
			for (let p in A) if (p.meta.r == 1 || p.meta.r === true) { R2[p.id] = R[p.id] ?? time(); if (R[p.id] == null) ch = true; }
			if (ch || length(keys(R2)) != length(keys(R))) { mkdir('/etc/wrtfreedom'); writefile(F + '.t', sprintf('%J', R2)); rename(F + '.t', F); }
			return { ok: true, changed: true, guard: secs, fixed: C.fixed };
		}
	},
	ddnsname: {
		/* Il Nome Funziona? (2.53): per ogni servizio DDNS il nome come lo vede internet (A e AAAA da un DNS pubblico o dal
		   dns_server del servizio) contro l'IP pubblico della linea vera; CGNAT; storico dei cambi di IP. Il controllo lo fa
		   svc.uc name in sottofondo (al massimo ogni 5 minuti, force = subito); qui le impostazioni lette dal router con i
		   nomi veri delle opzioni (cfg) e l'ultimo esito (chk: {a, aaaa, reg, ok, why}) */
		args: { force: true },
		call: function(req) {
			let D = ucfile('ddns'), R = rjs('/tmp/wf-ddnsname.json') ?? {}, C = {}, list = [], rk = ddretry();
			for (let x in R.list ?? []) C[x.sec] = x;
			for (let k in D) {
				let s = D[k];
				if (s['.type'] != 'service') continue;
				push(list, { sec: k, on: s.enabled == '1', name: s.lookup_host ?? s.domain ?? '', prov: s.service_name ?? '', cfg: ddcfg(s, rk), chk: C[k] ?? null });
			}
			let run = has('/tmp/wf-svc.name.lock');
			if (!run && length(list) && (req.args.force === true || time() - (R.t ?? 0) > 300)) { svcbg('name'); run = true; }
			let H = (rjs('/tmp/wf-iphist.json') ?? rjs('/etc/wrtfreedom/iphist.json') ?? {}).list ?? [], t = time();
			return { t: R.t ?? 0, run: run, line: R.line ?? null, pub: R.pub ?? '', cgnat: R.cgnat ?? false, list: list,
				hist: slice(H, -30), n24: length(filter(H, (x) => t - x.t < 86400)), ddns: has('/etc/init.d/ddns') };
		}
	},
	ddnsset: {
		/* impostazioni di un servizio DDNS che conservano quelle del router (2.53): retry nella chiave che c'è (retry_max_count
		   o retry_count), unità dei tempi, ip_network con ip_source network (ip_interface con interface). host = nome
		   (lookup_host): «domain» lo segue solo se era lo stesso nome o il suo sottonome DuckDNS (altrimenti è il nome di accesso). Si salva subito e
		   ddns riparte in sottofondo */
		args: { section: 'section', host: 'host', check: 0, cunit: 'cunit', force: 0, funit: 'funit', retry: 0, rwait: 0, runit: 'runit', src: 'src', net: 'net', url: 'url', on: true },
		call: function(req) {
			let a = req.args ?? {}, s = '' + (a.section ?? ''), D = ucfile('ddns'), S = D[s];
			if (!match(s, /^[A-Za-z0-9_]{1,64}$/) || !S || S['.type'] != 'service') return { error: 'servizio non trovato' };
			let c = '', P = 'ddns.' + s;
			/* 2.64 B8: on = nome acceso o spento (Assistente IA, come l'interruttore della pagina) */
			if (a.on != null) c += uset('ddns', s, 'enabled', a.on ? '1' : '0');
			if (a.host != null) {
				let h = '' + a.host;
				if (!okhost(h) || index(h, '.') < 0) return { error: 'nome non valido' };
				c += uset('ddns', s, 'lookup_host', h);
				/* domain segue il nome solo se prima era lo stesso nome o il suo sottonome DuckDNS («casa» di casa.duckdns.org) */
				let oh = '' + (S.lookup_host ?? ''), od = '' + (S.domain ?? ''), sub = (x) => match(x, /^([^.]{1,63})\.duckdns\.org$/i)?.[1];
				if (length(od) && od == oh) c += uset('ddns', s, 'domain', h);
				else if (length(od) && od == sub(oh)) c += uset('ddns', s, 'domain', sub(h) ?? h);
			}
			for (let T in [['check', 'cunit', 'check_interval', 'check_unit'], ['force', 'funit', 'force_interval', 'force_unit'], ['rwait', 'runit', 'retry_interval', 'retry_unit']]) {
				if (a[T[0]] == null) continue;
				if (type(a[T[0]]) != 'int' || a[T[0]] < 0 || a[T[0]] > 100000) return { error: 'tempo non valido' };
				c += uset('ddns', s, T[2], a[T[0]]);
				if (a[T[1]] != null) { if (!match('' + a[T[1]], DDUNIT)) return { error: 'unità non valida' }; c += uset('ddns', s, T[3], a[T[1]]); }
			}
			if (a.retry != null) {
				if (type(a.retry) != 'int' || a.retry < 0 || a.retry > 1000) return { error: 'tentativi non validi' };
				let k = ddcfg(S, ddretry()).retry[1];
				c += uset('ddns', s, k, a.retry) + udel('ddns', s, k == 'retry_max_count' ? 'retry_count' : 'retry_max_count');
			}
			let src = a.src != null ? '' + a.src : (S.ip_source ?? 'network');
			if (a.src != null) { if (!match(src, /^(network|interface|web|script)$/)) return { error: 'fonte non valida' }; c += uset('ddns', s, 'ip_source', src); }
			if (a.net != null) {
				if (!match('' + a.net, /^[A-Za-z0-9_.@-]{1,32}$/)) return { error: 'interfaccia non valida' };
				c += uset('ddns', s, src == 'interface' ? 'ip_interface' : 'ip_network', a.net);
			}
			if (a.url != null) { if (!match('' + a.url, /^https?:\/\/[^ '"\\`$]{3,255}$/)) return { error: 'indirizzo non valido' }; c += uset('ddns', s, 'ip_url', a.url); }
			if (!length(c)) return { error: 'niente da cambiare' };
			sh(c + 'uci commit ddns; ( /etc/init.d/ddns restart ) >/dev/null 2>&1 </dev/null &');
			return { ok: true };
		}
	},
	certadg: {
		/* certificato di AdGuard Home (2.53): una sola strada, la riga del pacchetto «# wf:certadg» (cron.sh certadg ogni
		   notte alle 00:30, copia solo se il certificato è cambiato). on toglie le righe vecchie che facevano la stessa cosa
		   (riga di sistema con la copia in /etc/adguardhome/tls/ e attività «Certificato Ad AdGuard») e copia subito;
		   get = { on, old: righe vecchie ancora presenti } */
		args: { action: 'action' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), C = crsplit(readfile(CRONF) ?? '');
			/* solo le righe del certificato: copia («cp … /tls») o cron.sh certadg; le altre righe con /etc/adguardhome restano */
			let old = (l) => match(l, /(^|[;&|(]|[[:space:]])cp[[:space:]][^;&|]*\/tls(\/|[[:space:]]|$)/) != null || match(l, /cron\.sh certadg/) != null;
			let on = length(filter(C.wf, (w) => w.tag == 'certadg' && substr(w.line, 0, 1) != '#')) > 0;
			let n = length(filter(C.sys, old)) + length(filter(C.app, (p) => p.meta.a == 'certadg' || old(p.cmd)));
			if (a == 'get') return { on: on, old: n, acme: has('/etc/init.d/acme'), adg: adginst() };
			if (a != 'on' && a != 'off') return { error: 'azione non valida' };
			if (n) { C.sys = filter(C.sys, (l) => !old(l)); C.app = filter(C.app, (p) => !(p.meta.a == 'certadg' || old(p.cmd))); crwrite(crtext(C)); }
			cronline('certadg', a == 'on' ? '30 0 * * * sh /usr/share/wrtfreedom/cron.sh certadg' : null);
			if (a == 'on') sh('( sh /usr/share/wrtfreedom/cron.sh certadg ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, on: a == 'on', removed: n };
		}
	},
	sqmhealth: {
		/* Controllo Di Salute del Controllo Della Linea (2.53, solo lettura): code CAKE presenti sulle interfacce delle regole
		   accese (uscita e ifb4… dell'entrata), servizio acceso all'avvio, Accelerazione Software o Hardware (scavalcano
		   CAKE), cake-autorate, carico del router. items [{id, ok (true, false, null = informazione), text (senza nomi
		   tecnici: la rete in parole semplici), act, tech (nomi veri per i Dettagli Tecnici)}] */
		call: function() {
			let Q = ucfile('sqm'), I = [], add = (id, ok, it, en, act, tech) => push(I, { id: id, ok: ok, text: L(it, en), act: act, tech: tech ?? '' });
			let inst = has('/etc/init.d/sqm'), on = filter(keys(Q), (k) => Q[k]['.type'] == 'queue' && Q[k].enabled == '1'), C = {};
			if (!inst) add('inst', false, 'Controllo Della Linea non installato', 'Line Control not installed', 'pkg', 'sqm-scripts');
			else if (!length(on)) add('off', null, 'Controllo Della Linea spento', 'Line Control off', 'sqm', 'sqm');
			if (inst && length(on)) {
				for (let l in split(sh('tc qdisc show 2>/dev/null'), '\n')) {
					let m = match(l, /^qdisc cake [0-9a-f]+: dev ([^ ]+) root.* bandwidth ([^ ]+)/);
					if (m) C[m[1]] = m[2];
				}
				/* rete della regola in parole semplici: linea (la linea vera o una rete delle zone con il NAT), Rete Di Casa (zona
				   di casa), altrimenti un'altra rete; nomi letti dal router */
				let D = ubcall('network.interface', 'dump')?.interface ?? [], F0 = ucfile('firewall'), Z = fwzones(), Ln = lineinfo();
				let where = (d) => {
					if (Ln && Ln.dev == d) return ['sulla linea', 'on the line'];
					for (let i in D) if ((i.l3_device ?? '') == d || (i.device ?? '') == d)
						for (let k in F0) {
							let z = F0[k];
							if (z['.type'] != 'zone' || index(type(z.network) == 'array' ? z.network : split(z.network ?? '', ' '), i.interface) < 0) continue;
							if (z.name == Z.home) return ['sulla Rete Di Casa', 'on the Home Network'];
							if (z.masq == '1' || z.masq == 'true') return ['sulla linea', 'on the line'];
						}
					return ['su un\'altra rete', 'on another network'];
				};
				for (let k in on) {
					let d = Q[k].interface ?? '', b = substr('ifb4' + d, 0, 15), u = C[d] != null, i = C[b] != null, w = where(d);
					add('cake_' + k, u && i, u && i ? 'Controllo attivo ' + w[0] : 'Controllo ' + (u || i ? 'incompleto ' : 'non attivo ') + w[0] + (u ? ': manca l\'entrata' : i ? ': manca l\'uscita' : ''),
						u && i ? 'Control active ' + w[1] : 'Control ' + (u || i ? 'incomplete ' : 'not active ') + w[1] + (u ? ': ingress missing' : i ? ': egress missing' : ''), 'restart',
						'sqm.' + k + ' · cake ' + d + ' ' + (C[d] ?? '—') + ' · ' + b + ' ' + (C[b] ?? '—'));
				}
				let boot = length(filter(lsdir('/etc/rc.d') ?? [], (f) => match(f, /^S[0-9]+sqm$/))) > 0;
				add('boot', boot, boot ? 'Si accende all\'avvio' : 'Non si accende all\'avvio', boot ? 'Starts at boot' : 'Does not start at boot', 'enable', '/etc/rc.d/S*sqm');
			}
			let F = ucfile('firewall'), sw = false, hw = false;
			for (let k in F) if (F[k]['.type'] == 'defaults') { sw = sw || F[k].flow_offloading == '1'; hw = hw || F[k].flow_offloading_hw == '1'; }
			if (length(on)) add('offload', !(sw || hw), sw || hw ? 'Accelerazione ' + (hw ? 'Hardware' : 'Software') + ' accesa: scavalca le code' : 'Accelerazione spenta',
				sw || hw ? (hw ? 'Hardware' : 'Software') + ' offloading on: bypasses the queues' : 'Offloading off', 'offload',
				'flow_offloading ' + (sw ? 1 : 0) + ' · flow_offloading_hw ' + (hw ? 1 : 0));
			let ar = has('/etc/init.d/cake-autorate');
			if (ar && length(on)) {
				let run = length(trim(sh('/etc/init.d/cake-autorate running >/dev/null 2>&1 && echo 1'))) > 0;
				add('ar', null, run ? 'Velocità adattiva attiva' : 'Velocità adattiva ferma', run ? 'Adaptive speed running' : 'Adaptive speed stopped', 'sqm', 'cake-autorate');
			}
			let l1 = +(split(readfile('/proc/loadavg') ?? '0', ' ')[0]), nc = length(match(readfile('/proc/cpuinfo') ?? '', /^processor/g) ?? []) || 1, pc = int(l1 * 100 / nc);
			add('load', pc < 70 ? true : pc < 100 ? null : false, 'Carico del router ' + pc + '%', 'Router load ' + pc + '%', 'load', 'loadavg ' + l1 + ' · ' + nc + ' CPU');
			return { t: time(), ok: length(filter(I, (x) => x.ok === false)) == 0, items: I, cake: C, offload: { sw: sw, hw: hw }, load: { l1: l1, ncpu: nc, pct: pc }, ar: ar, inst: inst };
		}
	},
	sqmsched: {
		/* profili del Controllo Della Linea per orario (2.53): wrtfreedom.sqmp_<id> {name, enabled, hour, min, days, mode
		   off|fixed|auto, prof safe|bal|fast, dl, ul (kbit/s della linea)} e riga «# wf:sqmp_<id>» (cron.sh sqmp <id>).
		   get = { list, sqm, ar }; set {id (vuoto = nuovo), …}; del {id}; apply {id} = subito */
		args: { action: 'action', id: 'id', name: 'name', on: true, hour: 0, min: 0, days: 'days', mode: 'mode', prof: 'prof', dl: 0, ul: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), id = '' + (a.id ?? '');
			if (act == 'get') return { list: sqmprofs(), sqm: has('/etc/init.d/sqm'), ar: has('/etc/init.d/cake-autorate') };
			if (length(id) && !match(id, /^[a-z0-9]{1,12}$/)) return { error: 'profilo non valido' };
			let W = ucfile('wrtfreedom'), S = 'sqmp_' + id;
			if (act == 'del' || act == 'apply') {
				if (!W[S]) return { error: 'profilo non trovato' };
				if (act == 'apply') { sh('( sh ' + SQMCTL + ' prof ' + id + ' ) >/dev/null 2>&1 </dev/null &'); return { ok: true }; }
				cronline(S, null);
				sh('uci -q delete wrtfreedom.' + S + '; uci commit wrtfreedom');
				return { ok: true };
			}
			if (act != 'set') return { error: 'azione non valida' };
			if (!length(id)) { if (length(sqmprofs(W)) >= 12) return { error: 'al massimo 12 profili' }; id = lc(wkey(6)); S = 'sqmp_' + id; }
			let o = W[S] ?? {}, md = '' + (a.mode ?? o.mode ?? 'auto'), pf = '' + (a.prof ?? o.prof ?? 'bal'), h = a.hour ?? +(o.hour ?? 20), mi = a.min ?? +(o.min ?? 0);
			let dy = '' + (a.days ?? o.days ?? '*'), dl = a.dl ?? +(o.dl ?? 0), ul = a.ul ?? +(o.ul ?? 0), nm = replace(substr('' + (a.name ?? o.name ?? ''), 0, 40), /[\r\n]/g, ' ');
			let on = a.on != null ? a.on === true : o.enabled != '0';
			if (!match(md, /^(off|fixed|auto)$/) || !match(pf, /^(safe|bal|fast)$/)) return { error: 'modalità non valida' };
			if (type(h) != 'int' || type(mi) != 'int' || h < 0 || h > 23 || mi < 0 || mi > 59) return { error: 'orario non valido' };
			if (!match(dy, /^(\*|[0-6](,[0-6]){0,6}|[0-6]-[0-6])$/)) return { error: 'giorni non validi' };
			/* dl e ul controllati sempre (salvati anche con le altre modalità); in Fisso almeno 100 kbit/s */
			let lo = md == 'fixed' ? 100 : 0;
			if (type(dl) != 'int' || type(ul) != 'int' || dl < lo || ul < lo || dl > 10000000 || ul > 10000000) return { error: 'limiti non validi' };
			if (md == 'auto' && !has('/etc/init.d/cake-autorate')) return { error: 'cake-autorate non è installato' };
			cfgensure();
			sh('uci set wrtfreedom.' + S + '=sqmp; ' + uset('wrtfreedom', S, 'name', nm) + uset('wrtfreedom', S, 'enabled', on ? '1' : '0') + uset('wrtfreedom', S, 'hour', h) +
				uset('wrtfreedom', S, 'min', mi) + uset('wrtfreedom', S, 'days', dy) + uset('wrtfreedom', S, 'mode', md) + uset('wrtfreedom', S, 'prof', pf) +
				uset('wrtfreedom', S, 'dl', int(dl ?? 0)) + uset('wrtfreedom', S, 'ul', int(ul ?? 0)) + 'uci commit wrtfreedom');
			cronline(S, on ? mi + ' ' + h + ' * * ' + dy + ' sh /usr/share/wrtfreedom/cron.sh sqmp ' + id : null);
			return { ok: true, id: id };
		}
	},
	sqmset: {
		/* 2.64 B8: Controllo Della Linea in un solo metodo (Assistente IA). Stato con la stessa regola di sqmctl.sh (la prima
		   regola accesa, altrimenti la prima; Adattivo = cake-autorate al lavoro; limiti in kbit/s nel verso della linea: sulla
		   rete di casa br-… scambiati). get = {inst, ar, rule, on, mode off|fixed|auto, prof safe|bal|fast, dl, ul, slow};
		   set {mode, prof, dl, ul} = sqmctl.sh in sottofondo. L'interfaccia della regola non si tocca mai */
		args: { action: 'action', mode: 'mode', prof: 'prof', dl: 0, ul: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), Q = ucfile('sqm'), W = ucfile('wrtfreedom'), S = null;
			for (let k in Q) if (Q[k]['.type'] == 'queue') { if (!S) S = k; if (Q[k].enabled == '1') { S = k; break; } }
			let inst = has('/etc/init.d/sqm'), ar = has('/etc/init.d/cake-autorate'), q0 = S ? Q[S] : {}, on = q0.enabled == '1', br = match(q0.interface ?? '', /^br-/) != null;
			let au = on && ar && length(trim(sh('pgrep -f "cake[-]autorate" 2>/dev/null'))) > 0, pf = ug(W, 'sqm', 'prof');
			let G = { inst: inst, ar: ar, rule: S != null, on: on, mode: !on ? 'off' : au ? 'auto' : 'fixed', prof: match(pf, /^(safe|bal|fast)$/) ? pf : 'bal',
				dl: +((br ? q0.upload : q0.download) ?? 0), ul: +((br ? q0.download : q0.upload) ?? 0), slow: has('/etc/wrtfreedom/slow') };
			if (act == 'get') return G;
			if (act != 'set') return { error: 'azione non valida' };
			let md = '' + (a.mode ?? ''), p = '' + (a.prof ?? G.prof), dl = a.dl ?? G.dl, ul = a.ul ?? G.ul;
			if (!inst) return { error: 'Controllo Della Linea non installato' };
			if (!S) return { error: 'nessuna regola del Controllo Della Linea' };
			if (G.slow) return { error: 'limite dei giga finiti attivo' };
			if (!match(md, /^(off|fixed|auto)$/) || !match(p, /^(safe|bal|fast)$/)) return { error: 'modalità non valida' };
			if (md == 'auto' && !ar) return { error: 'cake-autorate non è installato' };
			if (md == 'fixed' && (type(dl) != 'int' || type(ul) != 'int' || dl < 100 || ul < 100 || dl > 10000000 || ul > 10000000)) return { error: 'limiti non validi' };
			sh('( sh ' + SQMCTL + ' mode ' + md + (md == 'fixed' ? ' ' + dl + ' ' + ul : md == 'auto' ? ' ' + p : '') + ' ) >/dev/null 2>&1 </dev/null &');
			return { ok: true };
		}
	},
	sqmtest: {
		/* Prova Prima E Dopo (2.53): svc.uc abtest misura in sottofondo il ritardo a riposo e a linea carica (download e upload,
		   ~10 s ciascuno) senza e con il Controllo Della Linea, voto A–F; rispetta la soglia del Consumo Della SIM.
		   start → { started } o { error }; get = /tmp/wf-abtest.json {st run|ok|err, step, msg, t, off, on, mb, scope all (regola sulla linea) | lan (regola
		   sulla rete di casa, linea su modem: solo lo stato di quella che c'è) | up (coda provvisoria in uscita, linea non modem)};
		   mai una coda provvisoria sul modem; con la soglia della SIM e il consumo non ancora letto la prova non parte */
		args: { action: 'action' },
		call: function(req) {
			let a = '' + (req.args.action ?? 'get'), R = rjs('/tmp/wf-abtest.json') ?? { st: 'none' };
			if (a == 'get') return R;
			if (a != 'start') return { error: 'azione non valida' };
			if (has('/tmp/wf-svc.abtest.lock')) return { error: 'prova già in corso' };
			if (!has('/usr/bin/curl')) return { error: 'serve curl' };
			if (has('/etc/wrtfreedom/slow')) return { error: 'limite dei giga finiti attivo' };
			wjs('/tmp/wf-abtest.json', { st: 'run', step: 'start', t: time() });
			svcbg('abtest');
			return { started: true };
		}
	},
	hb: {
		/* Router Spento? (2.53): richiesta periodica a un indirizzo scelto dall'utente (healthchecks.io, ntfy, Uptime Kuma…):
		   se smette di arrivare il servizio avvisa. Spento di serie. wrtfreedom.hb {enabled, url, every (minuti)}, riga
		   «# wf:hb» (cron.sh hb, che legge l'indirizzo da uci: mai nella riga del crontab). get = { on, set, host, every,
		   last {t, ok, code} }; set {on, url, every}; test = una richiesta adesso */
		args: { action: 'action', on: true, url: 'url', every: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), W = ucfile('wrtfreedom'), u = ug(W, 'hb', 'url'), ev = +(ug(W, 'hb', 'every') || 5);
			let get = () => ({ on: ug('wrtfreedom', 'hb', 'enabled') == '1', set: length(ug('wrtfreedom', 'hb', 'url')) > 0,
				host: match(ug('wrtfreedom', 'hb', 'url'), /^https?:\/\/([^\/:]+)/)?.[1] ?? '', every: +(ug('wrtfreedom', 'hb', 'every') || 5), last: rjs('/tmp/wf-hb.json') });
			if (act == 'get') return get();
			if (act == 'test') {
				if (!length(u)) return { error: 'indirizzo mancante' };
				sh('( sh /usr/share/wrtfreedom/cron.sh hb ) >/dev/null 2>&1 </dev/null &');
				return { ok: true };
			}
			if (act != 'set') return { error: 'azione non valida' };
			let c = '';
			cfgensure();
			if (a.url != null) {
				let x = '' + a.url;
				if (length(x) && !match(x, /^https?:\/\/[A-Za-z0-9.-]{1,253}(:[0-9]{1,5})?(\/[^ '"\\`$<>]{0,255})?$/)) return { error: 'indirizzo non valido' };
				c += length(x) ? ukey('wrtfreedom', 'hb', 'url', x) : udel('wrtfreedom', 'hb', 'url');
				u = x;
			}
			if (a.every != null) { if (index([1, 2, 5, 10, 15, 30, 60], a.every) < 0) return { error: 'intervallo non valido' }; ev = a.every; c += uset('wrtfreedom', 'hb', 'every', ev); }
			let on = a.on != null ? a.on === true : ug(W, 'hb', 'enabled') == '1';
			if (on && !length(u)) return { error: 'indirizzo mancante' };
			sh('uci set wrtfreedom.hb=hb; ' + c + uset('wrtfreedom', 'hb', 'enabled', on ? '1' : '0') + 'uci commit wrtfreedom');
			cronline('hb', on ? (ev == 60 ? '0 * * * *' : ev == 1 ? '* * * * *' : '*/' + ev + ' * * * *') + ' sh /usr/share/wrtfreedom/cron.sh hb' : null);
			let r = get(); r.ok = true;
			return r;
		}
	},
	tgchats: {
		/* Bot Per Più Persone (2.53): chat in più che ricevono gli avvisi (role a), anche i comandi sicuri (s: Comandi Pronti
		   senza conferma, senza file e senza azioni) o tutto (t). La chat collegata con il bot ha sempre tutto. get = { primary,
		   list [{id, role, name}], seen [{id, name, t}] chat che hanno scritto al bot e non sono ancora autorizzate };
		   add / set {id, role, name}; del {id}. Al massimo 10; alla chat aggiunta arriva un messaggio di benvenuto */
		args: { action: 'action', id: 'id', role: 'role', name: 'name' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), W = ucfile('wrtfreedom'), c = tgconf(), Ls = tgchatlist(W);
			if (act == 'get') {
				let have = {};
				have[c.chat] = true;
				for (let x in Ls) have[x.id] = true;
				return { primary: c.chat, list: map(Ls, (x) => ({ id: x.id, role: x.role, name: x.name })), seen: filter(rjs('/tmp/wf-tg.seen.json') ?? [], (x) => !have['' + x.id]), max: 10 };
			}
			let id = '' + (a.id ?? ''), ex = filter(Ls, (x) => x.id == id)[0];
			if (!match(id, /^-?[0-9]{1,20}$/)) return { error: 'chat non valida' };
			if (!length(c.token) || !length(c.chat)) return { error: 'bot Telegram non collegato' };
			if (act == 'del') {
				if (!ex) return { error: 'chat non trovata' };
				sh('uci -q delete wrtfreedom.' + ex.sec + '; uci commit wrtfreedom; touch /tmp/wf-tg.menu');
				return { ok: true };
			}
			if (act != 'add' && act != 'set') return { error: 'azione non valida' };
			if (id == c.chat) return { error: 'è già la chat principale' };
			let role = '' + (a.role ?? ex?.role ?? 'a'), nm = replace(substr('' + (a.name ?? ex?.name ?? ''), 0, 40), /[\r\n]/g, ' ');
			if (!match(role, /^[ast]$/)) return { error: 'permesso non valido' };
			if (act == 'add' && ex) return { error: 'chat già presente' };
			if (act == 'set' && !ex) return { error: 'chat non trovata' };
			if (act == 'add' && length(Ls) >= 10) return { error: 'al massimo 10 chat' };
			let S = ex ? ex.sec : 'tgc_' + replace(id, '-', 'm');
			cfgensure();
			sh('uci set wrtfreedom.' + S + '=tgchat; ' + uset('wrtfreedom', S, 'id', id) + uset('wrtfreedom', S, 'role', role) + uset('wrtfreedom', S, 'name', nm) + 'uci commit wrtfreedom');
			if (act == 'add') tgqto(id, L('✅ WrtFreedom: questa chat riceve gli avvisi del router', '✅ WrtFreedom: this chat receives the router alerts') +
				(role == 'a' ? '' : role == 's' ? L(' e risponde ai comandi sicuri (/aiuto)', ' and answers safe commands (/help)') : L(' e risponde a tutti i comandi (/aiuto)', ' and answers all commands (/help)')));
			return { ok: true, sec: S };
		}
	},
	croncaps: {
		/* Pianificazioni (2.40): cosa c'è su questo router, così «Cosa Fare» mostra solo i preset che funzionano */
		call: function() {
			let N = ucfile('network'), D = ucfile('ddns'), Wl = ucfile('wireless'), c = tgconf(), any = (o, f) => length(filter(keys(o), (k) => f(o[k]))) > 0;
			let bin = (n) => has('/usr/bin/' + n) || has('/usr/sbin/' + n) || has('/bin/' + n) || has('/sbin/' + n);
			return {
				cron: has('/usr/share/wrtfreedom/cron.sh'),
				acme: has('/etc/init.d/acme'),
				ddns: ddnshave(D),
				adg: has('/etc/init.d/adguardhome') || has('/etc/init.d/AdGuardHome'),
				wg: wgiface(N) != null,
				vpnsvc: length(vpntuns(ucfile('wrtfreedom'))) > 0,	/* Servizio VPN (2.42) */
				guest: length(guestifs(Wl)) > 0,
				wifi: any(Wl, (s) => s['.type'] == 'wifi-iface'),
				wifitx: bin('iw') && any(Wl, (s) => s['.type'] == 'wifi-iface'),	/* Potenza Di Notte (2.48): cron.sh txlow/txnorm */
				wifichan: has(WIFIUC) && bin('iw'),	/* Canale Automatico di notte (2.48) */
				leds: length(trim(sh('ls /sys/class/leds 2>/dev/null'))) > 0,
				wol: bin('etherwake') || bin('ether-wake'),
				nlbw: bin('nlbw'),
				speed: bin('speedtest-go') || bin('speedtest'),
				tg: length(c.token) > 0 && length(c.chat) > 0 && bin('curl'),
				weekly: true,	/* Riepilogo Settimanale (2.50; 2.60 anche senza bot): cron.sh weekly */
				monthly: length(c.token) > 0 && length(c.chat) > 0 && has(DEVUC),	/* Consumo Del Mese Su Telegram (2.59): cron.sh monthly */
				thermal: has('/sys/class/thermal/thermal_zone0/temp'),
				sqm: has('/etc/init.d/sqm'),	/* Controllo Della Linea (2.53): cron.sh sqmon/sqmoff */
				hb: bin('curl'),	/* Router Spento? (2.53): solo curl (l'indirizzo segreto passa da stdin, mai nella riga di comando) */
				cronm: true,	/* metodo cron (2.53): righe dell'app senza toccare quelle del pacchetto */
				svcs: filter(split(trim(sh('ls /etc/init.d 2>/dev/null')), '\n'), (x) => match(x, /^[A-Za-z0-9_.-]+$/))
			};
		}
	},
	evlist: {
		/* registro eventi: gli ultimi, dal più recente. 2.61: ai = spiegazione dell'Assistente IA (Avvisi Spiegati, ai.uc why,
		   /tmp/wf-ai/why.json) sullo stesso evento, mai un evento in più */
		args: { limit: 0 },
		call: function(req) {
			let n = +(req.args.limit ?? 300);
			if (!(n > 0 && n <= 500)) n = 300;
			let out = [], AW = evai();
			for (let l in reverse(lastlines(evlog(), n))) {
				let p = split(l, '|', 4);
				if (length(p) != 4) continue;
				let o = { t: +p[0], e: p[1], c: p[2], x: p[3] }, w = AW[p[0] + '|' + p[1]];
				if (w) o.ai = w;
				push(out, o);
			}
			return { list: out };
		}
	},

	evclear: {
		call: function() {
			sh(': > /tmp/wf-events.log; [ -f /etc/wrtfreedom/events.log ] && : > /etc/wrtfreedom/events.log');
			return { ok: true };
		}
	},
	evget: {
		call: function() {
			let W = ucfile('wrtfreedom'), N = ucfile('network'), rules = [], ifs = [], wg = false;
			for (let r in W) {
				if (W[r]['.type'] != 'rule') continue;
				let g = (o) => ug(W, r, o);
				push(rules, { id: r, event: g('event'), action: g('action'), arg: g('arg'), delay: +(g('delay') || 0), label: g('label'), on: g('enabled') != '0', by: g('by'), mac: g('mac'), person: g('person') });
			}
			for (let k in N) if (N[k]['.type'] == 'interface') { if (k != 'loopback') push(ifs, k); if (N[k].proto == 'wireguard' && !match(k, VPNIFRX)) wg = true; }
			return { ifaces: ifs, persist: ug(W, 'ev', 'persist') == '1', notify: filter(split(ug(W, 'ev', 'notify'), ' '), length), rules: rules,
				/* Ore Silenziose e Avvisi Raggruppati (2.53, solo Telegram: tgq.uc) */
				quiet: { on: ug(W, 'ev', 'quiet') == '1', from: ug(W, 'ev', 'qfrom') || '23:00', to: ug(W, 'ev', 'qto') || '07:00', pass: filter(split(ug(W, 'ev', 'qpass') || 'net sys', ' '), (x) => match(x, /^(net|new|dev|usb|button|sys)$/)) },
				group: +(ug(W, 'ev', 'group') || 0),
				buttons: sort(lsdir('/etc/rc.button') ?? []), usb: stat('/sys/bus/usb') != null, wg: wg };
		}
	},

	evset: {
		/* quiet, qfrom, qto (HH:MM), qpass (categorie che passano lo stesso), group (secondi: 0, 60, 300, 900) dalla 2.53 */
		args: { persist: true, notify: 'notify', quiet: true, qfrom: 'qfrom', qto: 'qto', qpass: 'qpass', group: 0 },
		call: function(req) {
			let a = req.args ?? {}, cmd = 'uci set wrtfreedom.ev=ev; ';
			cfgensure();
			if (a.persist != null) {
				cmd += 'uci set wrtfreedom.ev.persist=' + (a.persist ? '1' : '0') + '; ';
				/* il registro segue: in memoria o sulla memoria interna */
				cmd += a.persist ? 'cat /tmp/wf-events.log >> /etc/wrtfreedom/events.log 2>/dev/null; ' : 'cat /etc/wrtfreedom/events.log >> /tmp/wf-events.log 2>/dev/null; rm -f /etc/wrtfreedom/events.log; ';
			}
			if (a.notify != null) {
				let L = filter(type(a.notify) == 'array' ? a.notify : split('' + a.notify, ' '), function(x) { return match('' + x, /^(net|new|dev|usb|button|sys)$/); });
				cmd += 'uci -q delete wrtfreedom.ev.notify; ';
				if (length(L)) cmd += 'uci set wrtfreedom.ev.notify=' + q(join(' ', L)) + '; ';
			}
			if (a.quiet != null) cmd += 'uci set wrtfreedom.ev.quiet=' + (a.quiet ? '1' : '0') + '; ';
			for (let k in ['qfrom', 'qto']) if (a[k] != null) {
				if (!match('' + a[k], /^([01][0-9]|2[0-3]):[0-5][0-9]$/)) return { error: 'orario non valido' };
				cmd += 'uci set wrtfreedom.ev.' + k + '=' + a[k] + '; ';
			}
			if (a.qpass != null) {
				let P = filter(split('' + a.qpass, ' '), (x) => match(x, /^(net|new|dev|usb|button|sys)$/));
				/* di serie «net sys»; nessuna categoria = «none» (un valore vuoto tornerebbe a quelle di serie) */
				cmd += 'uci set wrtfreedom.ev.qpass=' + q(length(P) ? join(' ', P) : 'none') + '; ';
			}
			if (a.group != null) {
				if (index([0, 60, 300, 900], a.group) < 0) return { error: 'raggruppamento non valido' };
				cmd += 'uci set wrtfreedom.ev.group=' + a.group + '; ';
			}
			sh(cmd + 'uci commit wrtfreedom');
			return { ok: true };
		}
	},
	evrule: {
		/* by (2.62) = 'ai': regola creata dall'Assistente IA (Regole Dette A Parole); '' = toglie il segno. 2.64 B4: mac (un
		   dispositivo) o person (id di una Persona) = solo per lui, con dev_join e dev_leave (filtro in event.sh); '' = tutti;
		   assenti = come prima; con un altro evento il filtro si toglie */
		args: { action: 'action', id: 'id', event: 'event', act: 'act', arg: 'arg', delay: 0, label: 'label', on: true, by: 'by', mac: 'mac', person: 'person' },
		call: function(req) {
			let a = req.args ?? {}, op = '' + (a.action ?? ''), id = '' + (a.id ?? '');
			cfgensure();
			if (op == 'del') {
				if (!match(id, /^r[0-9]{1,14}$/)) return { error: 'regola non valida' };
				sh('uci -q delete wrtfreedom.' + id + '; uci commit wrtfreedom');
				return { ok: true };
			}
			if (op == 'on') {
				if (!match(id, /^r[0-9]{1,14}$/)) return { error: 'regola non valida' };
				sh('uci set wrtfreedom.' + id + '.enabled=' + (a.on ? '1' : '0') + '; uci commit wrtfreedom');
				return { ok: true };
			}
			let ev = '' + (a.event ?? ''), ac = '' + (a.act ?? ''), arg = substr('' + (a.arg ?? ''), 0, 300), d = +(a.delay ?? 0), lab = replace(substr('' + (a.label ?? ''), 0, 80), /[\n\r]/g, ' ');
			if (!match(ev, /^[A-Za-z0-9_]{2,64}$/) || !match(ac, /^(modem_restart|wan_reconnect|vpn_restart|vpn_on|vpn_off|wifi_on|wifi_off|wifi_toggle|mount|tg|cmd|sqm_on|sqm_off)$/) || !(d >= 0 && d <= 3600))
				return { error: 'regola non valida' };
			let mc = a.mac != null ? lc('' + a.mac) : null, pr = a.person != null ? '' + a.person : null, dv = match(ev, /^dev_(join|leave)$/) != null, fl = '';
			if ((length(mc ?? '') && !match(mc, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/)) || (length(pr ?? '') && !match(pr, /^p_[a-z0-9]{1,16}$/))) return { error: 'regola non valida' };
			if (op == 'add') id = 'r' + time();
			else if (!match(id, /^r[0-9]{1,14}$/)) return { error: 'regola non valida' };
			for (let k in [ [ 'mac', mc ], [ 'person', pr ] ]) if (!dv || k[1] != null) fl += dv && length(k[1]) ? 'uci set wrtfreedom.' + id + '.' + k[0] + '=' + q(k[1]) + '; ' : 'uci -q delete wrtfreedom.' + id + '.' + k[0] + '; ';
			sh('uci set wrtfreedom.' + id + '=rule; ' + fl + 'uci set wrtfreedom.' + id + '.event=' + ev + '; uci set wrtfreedom.' + id + '.action=' + ac + '; uci set wrtfreedom.' + id + '.arg=' + q(arg) +
				'; uci set wrtfreedom.' + id + '.delay=' + int(d) + '; uci set wrtfreedom.' + id + '.label=' + q(lab) + "; uci -q get wrtfreedom." + id + ".enabled >/dev/null || uci set wrtfreedom." + id + ".enabled=1; " +
				(a.by != null ? (a.by == 'ai' ? 'uci set wrtfreedom.' + id + '.by=ai; ' : 'uci -q delete wrtfreedom.' + id + '.by; ') : '') + 'uci commit wrtfreedom');
			return { ok: true, id: id };
		}
	},
	evtest: {
		/* prova subito un'azione, come farebbe l'evento */
		args: { act: 'act', arg: 'arg' },
		call: function(req) {
			let ac = '' + (req.args.act ?? ''), arg = substr('' + (req.args.arg ?? ''), 0, 300);
			if (!match(ac, /^(modem_restart|wan_reconnect|vpn_restart|vpn_on|vpn_off|wifi_on|wifi_off|wifi_toggle|mount|tg|cmd|sqm_on|sqm_off)$/))
				return { error: 'azione non valida' };
			sh('sh /usr/share/wrtfreedom/event.sh test ' + ac + ' ' + q(arg) + ' >/dev/null 2>&1 &');
			return { ok: true };
		}
	},
	evhp: {
		/* gli script hotplug degli altri (pacchetti, script personali): attivi e disattivati */
		call: function() {
			let out = [];
			for (let l in filter(split(sh("for f in /etc/hotplug.d/*/* /etc/hotplug.d/.disabled/*/*; do [ -f \"$f\" ] && echo \"$f\"; done 2>/dev/null"), '\n'), length)) {
				let m = match(l, /^\/etc\/hotplug\.d\/(\.disabled\/)?([^\/]+)\/([^\/]+)$/);
				if (!m || m[3] == '90-wrtfreedom') continue;
				push(out, { dir: m[2], name: m[3], on: !m[1] });
			}
			return { list: out };
		}
	},
	evhpread: {
		args: { dir: 'dir', name: 'name', on: true },
		call: function(req) {
			let d = '' + (req.args.dir ?? ''), n = '' + (req.args.name ?? '');
			if (!match(d, /^[a-z0-9_-]{1,32}$/) || !match(n, /^[A-Za-z0-9._-]{1,64}$/)) return { error: 'file non valido' };
			let f = (req.args.on === false ? '/etc/hotplug.d/.disabled/' : '/etc/hotplug.d/') + d + '/' + n;
			return { text: substr(readfile(f) ?? '', 0, 12000) };
		}
	},
	evhpset: {
		/* disattiva = sposta in /etc/hotplug.d/.disabled (l'hotplug non lo legge più); riattiva = lo rimette */
		args: { dir: 'dir', name: 'name', on: true },
		call: function(req) {
			let d = '' + (req.args.dir ?? ''), n = '' + (req.args.name ?? '');
			if (!match(d, /^[a-z0-9_-]{1,32}$/) || !match(n, /^[A-Za-z0-9._-]{1,64}$/) || n == '90-wrtfreedom') return { error: 'file non valido' };
			let on = '/etc/hotplug.d/' + d + '/' + n, off = '/etc/hotplug.d/.disabled/' + d + '/' + n;
			if (req.args.on)
				sh('[ -f ' + q(off) + ' ] && mkdir -p /etc/hotplug.d/' + d + ' && mv ' + q(off) + ' ' + q(on));
			else
				sh('[ -f ' + q(on) + ' ] && mkdir -p /etc/hotplug.d/.disabled/' + d + ' && mv ' + q(on) + ' ' + q(off));
			return { ok: stat(req.args.on ? on : off) != null };
		}
	},
	ledlist: {
		/* le spie che il router ha davvero (/sys/class/leds) */
		call: function() {
			/* spie spente dall'app: sezioni con nome wf_led_<spia> (ledset), lette tutte da /etc/config/system */
			let out = [], SY = ucfile('system');
			for (let n in (lsdir('/sys/class/leds') ?? [])) {
				let tr = readfile('/sys/class/leds/' + n + '/trigger') ?? '', cur = match(tr, /\[([^\]]+)\]/);
				let sec = 'wf_led_' + replace(n, /[^A-Za-z0-9_]/g, '_');
				push(out, { name: n, on: trim(ug(SY, sec, 'sysfs')) == '', trigger: cur ? cur[1] : '', bright: +trim(readfile('/sys/class/leds/' + n + '/brightness') ?? '0') });
			}
			return { list: sort(out, function(a, b) { return a.name < b.name ? -1 : 1; }) };
		}
	},
	ledset: {
		/* spegne una spia (resta spenta anche dopo il riavvio) o la riaccende com'era */
		args: { name: 'name', on: true },
		call: function(req) {
			let n = '' + (req.args.name ?? '');
			if (!match(n, /^[A-Za-z0-9:_.-]{1,64}$/) || stat('/sys/class/leds/' + n) == null) return { error: 'spia non trovata' };
			let sec = 'wf_led_' + replace(n, /[^A-Za-z0-9_]/g, '_'), d = '/sys/class/leds/' + n;
			if (req.args.on) {
				let prev = trim(sh('uci -q get system.' + sec + '.wf_prev'));
				sh('uci -q delete system.' + sec + '; uci commit system');
				if (length(prev)) writefile(d + '/trigger', prev);
				sh('/etc/init.d/led restart >/dev/null 2>&1');
			}
			else {
				let tr = readfile(d + '/trigger') ?? '', cur = match(tr, /\[([^\]]+)\]/);
				sh('uci set system.' + sec + '=led; uci set system.' + sec + '.sysfs=' + q(n) + "; uci set system." + sec + ".trigger='none'; uci set system." + sec + ".default='0'; uci set system." + sec + '.wf_prev=' + q(cur ? cur[1] : 'none') + '; uci commit system');
				writefile(d + '/trigger', 'none');
				writefile(d + '/brightness', '0');
			}
			return { ok: true };
		}
	},
	health: {
		/* Salute Del Router (2.54): get = healthcalc {t, state ok|warn|bad, v, why [{id, sev, text}], th, cpu, mem, temp, disk,
		   up, stopped, fan, boot, al}; set {temp, disk, mem (soglie), al_temp, al_disk, al_mem, al_boot, al_cpu (avvisi)};
		   tick = true solo dal giro di ogni minuto di health.uc (processore misurato sul suo minuto) */
		args: { action: 'action', temp: 0, disk: 0, mem: 0, al_temp: true, al_disk: true, al_mem: true, al_boot: true, al_cpu: true, tick: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get');
			if (act == 'get') return healthcalc(a.tick === true);
			if (act != 'set') return { error: 'azione non valida' };
			let c = '', okv = { temp: [70, 75, 80], disk: [80, 85, 90], mem: [85, 90, 95] };
			for (let k in ['temp', 'disk', 'mem']) if (a[k] != null) {
				if (index(okv[k], +a[k]) < 0) return { error: 'soglia non valida' };
				c += uset('wrtfreedom', 'health', k, int(+a[k]));
			}
			for (let k in ['al_temp', 'al_disk', 'al_mem', 'al_boot', 'al_cpu']) if (a[k] != null) c += uset('wrtfreedom', 'health', k, a[k] === true ? '1' : '0');
			if (!length(c)) return { error: 'niente da cambiare' };
			cfgensure();
			sh('uci set wrtfreedom.health=health; ' + c + 'uci commit wrtfreedom');
			let r = healthcalc(); r.ok = true;
			return r;
		}
	},
	healthhist: {
		/* Storico 24 Ore (2.54): {t, step 300, pts [[t, cpu, mem, temp]] (null = dato che manca), peak/min {cpu, mem, temp:
		   [valore, t]}, avg {cpu, mem, temp}, boots [t]} */
		call: function() { return hhist(); }
	},
	healthtop: {
		/* Cosa Pesa Di Più (2.54): {t, list [{id, name, desc, mem (byte), cpu (% dall'ultima lettura, null alla prima), n, up}],
		   total, used, n}; n = quanti (1…20, di serie 5) */
		args: { n: 0 },
		call: function(req) {
			let n = int(+(req.args?.n ?? 5));
			return htop(n >= 1 && n <= 20 ? n : 5);
		}
	},
	healthboot: {
		/* Perché Si È Riavviato (2.54, health.uc boot): last {t, why sched|watchdog|asked|upgrade|power|crash, off, approx}
		   (why null = non si sa, per esempio la prima accensione con il pacchetto), list = ultime 20 dalla più recente, n = quante
		   per motivo negli ultimi 7 giorni, sched = orari delle righe accese del crontab che riavviano, al = avviso acceso */
		call: function() {
			let B = rjs('/etc/wrtfreedom/boots.json'), now = time(), n = {}, sc = [];
			B = type(B) == 'array' ? B : [];
			for (let b in B) if (b?.why && b.t != null && b.t > now - 7 * 86400) n[b.why] = (n[b.why] ?? 0) + 1;
			/* la regola «reboot» è la stessa di downwhy in health.uc: se cambia, cambiarle insieme */
			for (let l in split(readfile(CRONF) ?? '', '\n')) {
				let f = match(l, /^[ \t]*([0-9*][^ \t]*[ \t]+[^ \t]+[ \t]+[^ \t]+[ \t]+[^ \t]+[ \t]+[^ \t]+)[ \t]+(.*)$/);
				if (f && match(f[2], /(^|[ ;&|({])(\/sbin\/)?reboot([ ;&|)}]|$)/)) push(sc, f[1]);
			}
			return { last: rjs('/tmp/wf-health.boot.json'), list: reverse(B), n: n, up: upsec(), sched: sc, al: ug('wrtfreedom', 'health', 'al_boot') != '0' };
		}
	},
	healthspace: {
		/* Cosa Occupa Lo Spazio e Pulizia Sicura (2.54, lavoro di health.uc): get = ultima lettura (rifatta in sottofondo se ha
		   più di 30 minuti) {busy, t, pct, free, lvl, total, used, items [{id, name, b}], clean [{id, name, desc, b, ram}],
		   last {t, ids, freed}}; scan = rileggi adesso; clean {ids: pkg|tmp|logs|adg} = libera (mai configurazione,
		   programmi o copie di sicurezza), poi rilegge */
		args: { action: 'action', ids: [] },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), S = rjs('/tmp/wf-space.json'), lk = stat('/tmp/wf-health.space.lock');
			let busy = lk != null && time() - lk.mtime < 300;
			if (act == 'clean') {
				let ids = [];
				for (let x in (type(a.ids) == 'array' ? a.ids : [])) if (index(['pkg', 'tmp', 'logs', 'adg'], '' + x) >= 0 && index(ids, '' + x) < 0) push(ids, '' + x);
				if (!length(ids)) return { error: 'niente da liberare' };
				if (busy) return { error: 'lettura dello spazio in corso' };
				unlink('/tmp/wf-clean.json');
				hbg('clean ' + join(',', ids));
				return { started: true };
			}
			if (act != 'get' && act != 'scan') return { error: 'azione non valida' };
			if (!busy && (act == 'scan' || !S || time() - +(S.t ?? 0) > 1800)) { hbg('space'); busy = true; }
			let dp = diskpct();
			return { busy: busy, t: S?.t ?? null, pct: dp, free: dp == null ? null : 100 - dp, lvl: hlev('disk', dp, hth()), total: S?.total ?? null,
				used: S?.used ?? null, items: S?.items ?? [], clean: S?.clean ?? [], last: rjs('/tmp/wf-clean.json') };
		}
	},
	ledsnight: {
		/* Spie Di Notte (2.54): get {on, from, to, days [0 = domenica…6], keep [spie che restano accese], leds, night (spente
		   adesso), dup (attività accese di Pianificazioni che spengono o riaccendono le spie)}; set {on, from, to, days, keep}:
		   righe «# wf:ledn_off/ledn_on» (cron.sh ledoff/ledon); accese, le attività doppie si sospendono («#off#» come in
		   Pianificazioni, id in wrtfreedom.ledn.susp; removed = quante sospese adesso), spente si riaccendono quelle sospese */
		args: { action: 'action', on: true, from: 'from', to: 'to', days: [], keep: [] },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get');
			if (act == 'get') return ledninfo();
			if (act != 'set') return { error: 'azione non valida' };
			let I = ledninfo(), on = a.on != null ? a.on === true : I.on, fr = a.from != null ? '' + a.from : I.from, to = a.to != null ? '' + a.to : I.to;
			let f = hmin2(fr), t = hmin2(to), days = [], keep = [];
			if (f == null || t == null || f == t) return { error: 'orario non valido' };
			for (let x in (a.days != null ? a.days : I.days)) {
				if (type(x) != 'int' || x < 0 || x > 6) return { error: 'giorni non validi' };
				if (index(days, x) < 0) push(days, x);
			}
			if (!length(days)) return { error: 'giorni non validi' };
			days = sort(days, (p, r) => p - r);
			for (let x in (a.keep != null ? a.keep : I.keep)) {
				if (!match('' + x, /^[A-Za-z0-9:_.-]{1,64}$/) || length(keep) >= 32) return { error: 'spia non valida' };
				if (has('/sys/class/leds/' + x) && index(keep, '' + x) < 0) push(keep, '' + x);
			}
			/* attività di Pianificazioni sulle spie: sospese (spente con «#off#», non cancellate) finché le Spie Di Notte sono
			   accese, poi riaccese solo quelle sospese da qui */
			let C = crsplit(readfile(CRONF) ?? ''), dup = 0, kq = length(keep) ? ' ' + q(join(',', keep)) : '';
			let sus = filter(split(trim(ug(ucfile('wrtfreedom'), 'ledn', 'susp')), ' '), (x) => match(x, /^[0-9a-f]{8}$/) != null);
			for (let p in C.app) {
				if (!match(p.cmd, /cron\.sh led(off|on)( |$)/)) continue;
				if (on && p.on) { p.on = false; dup++; if (index(sus, p.id) < 0) push(sus, p.id); }
				else if (!on && !p.on && index(sus, p.id) >= 0) p.on = true;
			}
			if (!on) sus = [];
			cfgensure();
			sh('uci set wrtfreedom.ledn=ledn; ' + uset('wrtfreedom', 'ledn', 'on', on ? '1' : '0') + uset('wrtfreedom', 'ledn', 'from', fr) + uset('wrtfreedom', 'ledn', 'to', to) +
				uset('wrtfreedom', 'ledn', 'days', join(' ', days)) + (length(keep) ? uset('wrtfreedom', 'ledn', 'keep', join(' ', keep)) : udel('wrtfreedom', 'ledn', 'keep')) +
				(length(sus) ? uset('wrtfreedom', 'ledn', 'susp', join(' ', sus)) : udel('wrtfreedom', 'ledn', 'susp')) + 'uci commit wrtfreedom');
			C.wf = filter(C.wf, (w) => w.tag != 'ledn_off' && w.tag != 'ledn_on');
			if (on) {
				/* riaccensione il giorno dopo se la notte passa la mezzanotte */
				let all = length(days) == 7, d2 = sort(map(days, (x) => t < f ? (x + 1) % 7 : x), (p, r) => p - r);
				push(C.wf, { tag: 'ledn_off', line: (f % 60) + ' ' + int(f / 60) + ' * * ' + (all ? '*' : join(',', days)) + ' sh /usr/share/wrtfreedom/cron.sh ledoff' + kq + ' # wf:ledn_off' });
				push(C.wf, { tag: 'ledn_on', line: (t % 60) + ' ' + int(t / 60) + ' * * ' + (all ? '*' : join(',', d2)) + ' sh /usr/share/wrtfreedom/cron.sh ledon # wf:ledn_on' });
			}
			crwrite(crtext(C));
			/* subito: dentro la fascia si spengono, fuori (o spente le Spie Di Notte) tornano come erano */
			let nw = on && lednnow(f, t, days);
			if (nw) sh('( sh /usr/share/wrtfreedom/cron.sh ledoff' + kq + ' ) >/dev/null 2>&1 </dev/null &');
			else if (has('/tmp/wf-leds.save')) sh('( sh /usr/share/wrtfreedom/cron.sh ledon ) >/dev/null 2>&1 </dev/null &');
			let r = ledninfo();
			r.night = nw; r.removed = dup; r.ok = true;
			return r;
		}
	},
	sysacc: {
		/* Accesso Al Router con conferma con ritorno (2.54, bakarm tag «acc»): get {ssh {on, iface ('' = da ovunque), port,
		   pwd, rootpwd, gw}, web {https, rebind}, home (rete di casa), vpn (VPN Per Fuori Casa o null), nets, pend, left};
		   set {on, iface, port, pwd, rootpwd, gw, https, rebind, secs (30…300, di serie 60)}: cambia subito e, senza
		   confirm entro secs, dropbear e uhttpd tornano come prima da soli (anche se l'app si chiude); back = torna ora */
		args: { action: 'action', on: true, iface: 'iface', port: 0, pwd: true, rootpwd: true, gw: true, https: true, rebind: true, secs: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), D = ucfile('dropbear'), U = ucfile('uhttpd'), N = ucfile('network');
			/* dropbear: si legge la prima sezione; Port solo lì, Interface dove non crea conflitti, il resto su tutte (il
			   ritorno rimette tutto il file, quindi ogni sezione com'era) */
			let DS = filter(keys(D), (k) => D[k]['.type'] == 'dropbear'), ds = DS[0], us = U.main?.['.type'] == 'uhttpd' ? 'main' : filter(keys(U), (k) => U[k]['.type'] == 'uhttpd')[0];
			let why = L('↩️ Accesso Al Router: modifica non confermata, rimesso com\'era', '↩️ Router Access: change not confirmed, restored');
			if (act == 'confirm') return bakconfirm('acc');
			if (act == 'back') return bakback('acc', why);
			let yes = (v, d) => (v == null || v == '') ? d : index(['1', 'on', 'true', 'yes', 'enabled'], lc('' + v)) >= 0;
			let nets = filter(keys(N), (k) => N[k]['.type'] == 'interface' && k != 'loopback');
			if (act == 'get') {
				let x = ds ? D[ds] : null, w = us ? U[us] : null;
				return { ssh: x ? { on: yes(x.enable, true), iface: x.Interface ?? '', port: +(x.Port || 22), pwd: yes(x.PasswordAuth, true), rootpwd: yes(x.RootPasswordAuth, true),
						gw: yes(x.GatewayPorts, false) } : null,
					web: w ? { https: yes(w.redirect_https, false), rebind: yes(w.rfc1918_filter, false) } : null,
					home: homenet().iface, vpn: wgiface(N) ?? null, nets: nets, pend: bakpend('acc'), left: bakleft('acc') };
			}
			if (act != 'set') return { error: 'azione non valida' };
			let cd = '', cu = '', secs = int(+(a.secs ?? 60));
			if (secs < 30 || secs > 300) secs = 60;
			if ((a.on != null || a.iface != null || a.port != null || a.pwd != null || a.rootpwd != null || a.gw != null) && !ds) return { error: 'accesso da terminale non trovato' };
			if ((a.https != null || a.rebind != null) && !us) return { error: 'pagina web del router non trovata' };
			if (a.iface != null && length('' + a.iface) && index(nets, '' + a.iface) < 0) return { error: 'rete non valida' };
			if (a.port != null && (type(a.port) != 'int' || a.port < 1 || a.port > 65535)) return { error: 'porta non valida' };
			let oo = (v) => v === true ? 'on' : 'off';
			/* Port solo sulla prima sezione (quella mostrata); Interface sulle altre solo se non fa due ascolti sulla stessa
			   porta e rete (o uno da ovunque): quella sezione resta com'era; il resto su tutte */
			let FI = map(DS, (x) => '' + (D[x].Interface ?? '')), FP = map(DS, (x) => +(D[x].Port || 22));
			if (a.port != null) FP[0] = a.port;
			for (let i = 0; a.iface != null && i < length(DS); i++) {
				let ni = '' + a.iface, ok = true;
				for (let j = 0; i > 0 && j < length(DS); j++)
					if (j != i && FP[j] == FP[i] && (FI[j] == ni || FI[j] == '' || ni == '')) ok = false;
				if (!ok) continue;
				FI[i] = ni;
				cd += length(ni) ? uset('dropbear', DS[i], 'Interface', ni) : udel('dropbear', DS[i], 'Interface');
			}
			if (a.port != null) cd += uset('dropbear', ds, 'Port', a.port);
			for (let x in DS) {
				if (a.on != null) cd += uset('dropbear', x, 'enable', a.on === true ? '1' : '0');
				if (a.pwd != null) cd += uset('dropbear', x, 'PasswordAuth', oo(a.pwd));
				if (a.rootpwd != null) cd += uset('dropbear', x, 'RootPasswordAuth', oo(a.rootpwd));
				if (a.gw != null) cd += uset('dropbear', x, 'GatewayPorts', oo(a.gw));
			}

			if (a.https != null) cu += uset('uhttpd', us, 'redirect_https', a.https === true ? '1' : '0');
			if (a.rebind != null) cu += uset('uhttpd', us, 'rfc1918_filter', a.rebind === true ? '1' : '0');
			if (!length(cd) && !length(cu)) return { error: 'niente da cambiare' };
			/* copia e ritorno solo dei servizi toccati; si riavviano dopo la risposta (l'app può passare dalla pagina web) */
			let cf = [], rl = [];
			if (length(cd)) { push(cf, 'dropbear'); push(rl, '/etc/init.d/dropbear restart'); }
			if (length(cu)) { push(cf, 'uhttpd'); push(rl, '/etc/init.d/uhttpd restart'); }
			let e = bakarm('acc', cf, [], join('; ', rl), secs, why);
			if (e !== true) return e;
			sh(cd + cu + join('', map(cf, (x) => 'uci commit ' + x + '; ')) + '( sleep 1; ' + join('; ', rl) + ' ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, pend: true, left: bakleft('acc'), secs: secs };
		}
	},
	svc: {
		/* Servizi Del Router (2.55): get = svclist {t, list [{id, name, desc, grp ess|fun|alt, on, boot, vital}], stopped,
		   n, pend, left, what}; start|stop|restart|enable|disable {name}: i servizi vitali fermati, riavviati o disattivati
		   tornano come prima da soli dopo 120 s senza confirm (bakarm tag «svc», anche con l'app chiusa), gli altri
		   subito; confirm, back = come sysacc */
		args: { action: 'action', name: 'name' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), nm = '' + (a.name ?? '');
			let why = L('↩️ Servizi Del Router: modifica non confermata, servizio rimesso com\'era', '↩️ Router Services: change not confirmed, service restored');
			if (act == 'get') {
				let r = svclist(), p = bakpend('svc');
				r.pend = p; r.left = bakleft('svc'); r.what = p ? rjs(bakdir('svc') + '/what.json') : null;
				return r;
			}
			if (act == 'confirm') return bakconfirm('svc');
			if (act == 'back') return bakback('svc', why);
			if (index(['start', 'stop', 'restart', 'enable', 'disable'], act) < 0) return { error: 'azione non valida' };
			/* solo i servizi principali di svcstate (mai gli script di una volta: umount, boot, done, sysfixtime…) */
			let S = match(nm, /^[A-Za-z0-9_.-]{1,64}$/) && has('/etc/init.d/' + nm) ? filter(svcstate().list, (x) => x.id == nm)[0] : null;
			if (!S) return { error: 'servizio non trovato' };
			let I = '/etc/init.d/' + nm, en = S.boot, on = S.on;
			/* come tornare: riattivare all'avvio se era attivato, riaccendere se era acceso (o se si riavvia) */
			let rb = (act == 'disable' && en ? I + ' enable; ' : '') + ((act == 'stop' && on) || act == 'restart' ? I + ' start' : '');
			if (!SVCVIT[nm] || !length(rb)) {
				sh('( ' + I + ' ' + act + ' ) >/dev/null 2>&1 </dev/null &');
				return { ok: true, pend: false };
			}
			if (bakpend('svc')) return { error: 'conferma prima la modifica in attesa', pend: 'svc' };
			let e = bakarm('svc', [], [], rb, 120, why);
			if (e !== true) return e;
			wjs(bakdir('svc') + '/what.json', { name: nm, action: act, t: time() });
			/* dopo la risposta (l'app può passare proprio da questo servizio) */
			sh('( sleep 1; ' + I + ' ' + act + ' ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, pend: true, left: bakleft('svc'), secs: 120 };
		}
	},
	speed: {
		/* Un Solo Test Di Velocità (2.55): get = {last {t, down, up, ping, jitter (Mbps, ms), via speedtest-go|cloudflare,
		   why (perché il ripiego) |null, server, vpn}|null, list (ultimi 10), fail {t, why}|null, run, tool {go, alt}};
		   start {via} = come diag {tool:'speed'} (uscita dal vivo in job) */
		args: { action: 'action', via: 'via' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get');
			if (act == 'get') return spdget();
			if (act != 'start') return { error: 'azione non valida' };
			if (spdbusy()) return { error: 'un test di velocità è già in corso', run: true };
			let c = spdcmd('' + (a.via ?? ''));
			return type(c) == 'object' ? c : job(c);
		}
	},
	logsum: {
		/* Registro In Parole Semplici (2.55): {t, kind sys|kern, n (righe), see (Da Vedere = warn…emerg, come snapshot.logw),
		   groups [{id, name, desc, prog, n, see, rep (ripetute), kinds (messaggi diversi), lv (il più grave), t,
		   msgs [{text, n, lv, see, t}] (al massimo 5)}], out (testo grezzo, solo con raw)}; see:true = solo Da Vedere */
		args: { kind: 'kind', see: true, raw: true },
		call: function(req) {
			let a = req.args ?? {}, k = a.kind == 'kern' ? 'kern' : 'sys', R = logrows(k);
			let r = { t: time(), kind: k, n: length(R), see: length(filter(R, (x) => x.lv <= 4)), groups: loggroups(R, a.see === true) };
			if (a.raw === true) r.out = k == 'kern' ? sh('dmesg 2>/dev/null | tail -n 300') : sh('logread -l 300 2>/dev/null');
			return r;
		}
	},
	aistate: {
		/* Assistente IA (2.60): stato unico (aistat) + provs, curl, pend, undo, ask, chat, mem (2.61 expl; 2.62 tg, bot,
		   weekly; 2.64 speed = velocità del modello attivo, aispeed); solo letture di file e uci. full = anche P (fornitore scelto, senza chiave) e alts: lo usa ai.uc per gli
		   Avvisi Spiegati e il consiglio del Riepilogo, mai l'app */
		args: { full: true },
		call: function(req) {
			let W = ucfile('wrtfreedom'), S = aiinfo(W);
			if (req.args?.full === true) {
				S.P = aiprov(W, S.prov ?? '');
				S.alts = filter(keys(AIPROV), (x) => aiready(W, x, S.prov));
			}
			return S;
		}
	},
	aipre: {
		/* Lettura anticipata (2.64): all'apertura della chat o mentre si scrive, le letture più usate in sottofondo (ai.uc pre)
		   in /tmp/wf-ai/pre.json, valide 30 s, che la domanda usa al posto di rileggere; al massimo una ogni 20 s (pre.t),
		   solo con l'Assistente IA acceso. Risposta subito {ok:true} */
		call: function() {
			let s = stat(AID + '/pre.t'), now = time();
			if (ug('wrtfreedom', 'ai', 'on') != '1' || (s && now - s.mtime < 20)) return { ok: true };
			aidir();
			writefile(AID + '/pre.t', '' + now);
			/* 2.64: servizio sempre acceso assente (fermato dopo troppi riavvii, mai partito): riavviato, al massimo ogni 5 minuti */
			let sv = stat(AID + '/svc.try');
			if (!length(aisvcpid()) && has('/etc/init.d/wrtfreedom-ai') && (!sv || now - sv.mtime > 300)) {
				writefile(AID + '/svc.try', '' + now);
				sh('( /etc/init.d/wrtfreedom-ai enable; /etc/init.d/wrtfreedom-ai restart ) </dev/null >/dev/null 2>&1 &');
			}
			aibg('pre', aiid());
			return { ok: true };
		}
	},
	aiset: {
		/* on (true = acceso, serve il consenso del fornitore scelto), prov (groq|gemini|claude|openrouter|openai), ok (true = Accetto:
		   consenso salvato in ok_<prov>; false = ritirato), key (scritta una volta in /etc/wrtfreedom/ai-<prov>.key 0600, mai
		   riletta; '' = tolta), model ('' = di serie), url (solo formato OpenAI, '' = tolto), max (domande al giorno 1…1000).
		   Spento (on false o consenso ritirato): lavori fermati e /tmp/wf-ai tolta. Risposta = aistate dopo il cambio */
		/* 2.63: rdno, actno = letture e azioni spente, hi = azioni Rischio Alto accese (parole separate da spazio, solo
		   chiavi di aistate.can: le altre si scartano); mauto = Memoria Automatica; deep = ragionamento più profondo */
		/* 2.64: backup = fornitore di riserva (id di un fornitore pronto e diverso da quello attivo; '' = nessuno); rdon, acton =
		   le spente di serie accese (solo se l'app le manda: un'app vecchia non le conosce e non le accende) */
		args: { on: true, prov: 'prov', ok: true, key: 'key', model: 'model', url: 'url', max: 0, why: true, whymax: 0, tg: true, rdno: 'rdno', actno: 'actno', rdon: 'rdon', acton: 'acton', hi: 'hi', mauto: true, deep: true, backup: 'backup' },
		call: function(req) {
			let a = req.args ?? {}, W = ucfile('wrtfreedom'), cur = ug(W, 'ai', 'prov'), pid = a.prov != null ? '' + a.prov : cur, c = 'uci set wrtfreedom.ai=ai; ';
			let only = a.on == null && a.prov == null && a.ok == null && a.key == null && a.model == null && a.url == null && a.max == null;
			if (only && a.why == null && a.whymax == null && a.tg == null && a.rdno == null && a.actno == null && a.rdon == null && a.acton == null && a.hi == null && a.mauto == null && a.deep == null && a.backup == null) return { error: 'niente da cambiare' };
			if (a.backup != null) {
				let b = trim('' + a.backup), e = length(b) ? ainotready(W, b, pid) : '';
				if (length(e)) return { error: e };
				c += length(b) ? 'uci set wrtfreedom.ai.backup=' + q(b) + '; ' : 'uci -q delete wrtfreedom.ai.backup; ';
			}
			/* 2.64 B5: le spente di serie si salvano al contrario (rdon, acton = quelle accese) e solo da rdon/acton mandati
			   dall'app; in rdno/actno si scartano (le parole sono sempre e solo chiavi di aistate.can) */
			let ws = (v, K) => { let V = []; for (let w in split(trim('' + v), /[ ,]+/)) if (index(K, w) >= 0 && index(V, w) < 0) push(V, w); return V; };
			for (let o in [ [ 'rdno', 'rd', 'rdon' ], [ 'actno', 'act', 'acton' ], [ 'hi', 'hi' ] ]) {
				let D = o[1] == 'hi' ? [] : map(filter(AICAN[o[1]], (x) => x[4] === 'off'), (x) => x[0]);
				if (o[2] && a[o[2]] != null) { let Y = ws(a[o[2]], D); c += length(Y) ? 'uci set wrtfreedom.ai.' + o[2] + '=' + q(join(' ', Y)) + '; ' : 'uci -q delete wrtfreedom.ai.' + o[2] + '; '; }
				if (a[o[0]] == null) continue;
				let V = filter(ws(a[o[0]], map(AICAN[o[1]], (x) => x[0])), (k) => index(D, k) < 0);
				c += length(V) ? 'uci set wrtfreedom.ai.' + o[0] + '=' + q(join(' ', V)) + '; ' : 'uci -q delete wrtfreedom.ai.' + o[0] + '; ';
			}
			if (a.mauto != null) c += 'uci set wrtfreedom.ai.mauto=' + (a.mauto === true ? '1' : '0') + '; ';
			if (a.deep != null) c += 'uci set wrtfreedom.ai.deep=' + (a.deep === true ? '1' : '0') + '; ';
			/* 2.61 Avvisi Spiegati Dall'IA (why, whymax 1…20 al giorno); 2.62 Anche Nel Bot (tg) */
			if (a.whymax != null && (type(a.whymax) != 'int' || a.whymax < 1 || a.whymax > 20)) return { error: 'tetto non valido (1…20 spiegazioni al giorno)' };
			if (a.why != null) c += 'uci set wrtfreedom.ai.why=' + (a.why === true ? '1' : '0') + '; ';
			if (a.whymax != null) c += 'uci set wrtfreedom.ai.whymax=' + a.whymax + '; ';
			if (a.tg != null) c += 'uci set wrtfreedom.ai.tg=' + (a.tg === true ? '1' : '0') + '; ';
			if (only) {
				cfgensure();
				sh(c + 'uci commit wrtfreedom');
				let r0 = aiinfo(null);
				r0.ok = true;
				return r0;
			}
			if (a.prov != null && !AIPROV[pid]) return { error: 'fornitore non valido' };
			if ((a.key != null || a.model != null || a.ok != null || a.url != null || a.on === true) && !AIPROV[pid]) return { error: 'scegli prima il fornitore' };
			let k = a.key != null ? trim('' + a.key) : null, md = a.model != null ? trim('' + a.model) : null, url = a.url != null ? replace(trim('' + a.url), /\/+$/, '') : null;
			if (k != null && length(k) && !match(k, /^[!-~]{8,255}$/)) return { error: 'chiave non valida' };
			if (md != null && length(md) && !match(md, /^[A-Za-z0-9._:\/@+-]{1,128}$/)) return { error: 'modello non valido' };
			if (url != null && length(url) && (pid != 'openai' || !match(url, /^https?:\/\/([A-Za-z0-9.-]{1,253}|\[[0-9A-Fa-f:]{2,39}\])(:[0-9]{1,5})?(\/[A-Za-z0-9._~\/-]{0,200})?$/))) return { error: 'indirizzo non valido' };
			if (a.max != null && (type(a.max) != 'int' || a.max < 1 || a.max > 1000)) return { error: 'limite non valido (1…1000 domande al giorno)' };
			let ok = a.ok === true || (a.ok !== false && ug(W, 'ai', 'ok_' + pid) == '1');
			if (((a.prov != null && pid != cur) || a.on === true) && !ok) return { error: 'serve il consenso', consent: pid };
			if (a.prov != null) c += 'uci set wrtfreedom.ai.prov=' + q(pid) + '; ';
			if (a.ok != null) c += a.ok === true ? 'uci set wrtfreedom.ai.ok_' + pid + '=1; ' : 'uci -q delete wrtfreedom.ai.ok_' + pid + '; ';
			if (md != null) c += length(md) ? 'uci set wrtfreedom.ai.model_' + pid + '=' + q(md) + '; ' : 'uci -q delete wrtfreedom.ai.model_' + pid + '; ';
			if (url != null) c += length(url) ? 'uci set wrtfreedom.ai.url_openai=' + q(url) + '; ' : 'uci -q delete wrtfreedom.ai.url_openai; ';
			if (a.max != null) c += 'uci set wrtfreedom.ai.max=' + a.max + '; ';
			let stop = a.on === false || (a.ok === false && pid == cur);
			if (a.on != null || stop) c += 'uci set wrtfreedom.ai.on=' + (a.on === true && !stop ? '1' : '0') + '; ';
			if (k != null) {
				/* la chiave va solo nel file (umask 077 di rpcd, poi 0600 sicuro): mai nella riga di comando né in uci */
				let f = AIK + pid + '.key';
				if (length(k)) {
					mkdir('/etc/wrtfreedom', 448);
					if (writefile(f + '.t', k) !== length(k)) { unlink(f + '.t'); return { error: 'chiave non salvata (spazio pieno?)' }; }
					sh('chmod 600 ' + f + '.t');
					rename(f + '.t', f);
					c += 'uci set wrtfreedom.ai.key_' + pid + '=1; ';
				}
				else { unlink(f); c += 'uci -q delete wrtfreedom.ai.key_' + pid + '; '; }
				aierrdel(pid);
			}
			if (md != null || url != null) aierrdel(pid);
			cfgensure();
			sh(c + 'uci commit wrtfreedom');
			/* 2.64: servizio sempre acceso solo con l'Assistente acceso */
			if (a.on != null || stop) aisvcset(a.on === true && !stop);
			if (stop) {
				for (let f in lsdir(AID) ?? []) { let m = match(f, /^pid-([0-9a-f]{8})$/); if (m) aikill(m[1]); }
				sh('rm -rf ' + AID);
			}
			let r = aiinfo(null);
			r.ok = true;
			return r;
		}
	},
	aiask: {
		/* una domanda (text, al massimo 2000 caratteri; me = MAC del telefono che usa l'app, da /cgi-bin/wf-me?once=1:
		   mai bloccato né staccato dall'IA). Una alla volta (/tmp/wf-ai/lock, scade dopo 150 s); con lo stato Pronto va al
		   fornitore, Senza Internet risponde il router (local). Risposta subito {id}; testo con aiget o /cgi-bin/wf-ai */
		args: { text: 'text', me: 'me', tg: 'tg' },
		call: function(req) {
			let W = ucfile('wrtfreedom'), S = aistat(W), now = time(), t = trim(replace('' + (req.args.text ?? ''), /[[:cntrl:]]+/g, ' '));
			if (!length(t) || length(t) > 2000) return { error: 'domanda vuota o troppo lunga (al massimo 2000 caratteri)' };
			/* 2.62 Anche Nel Bot (da tgbot.uc): tg = chat collegata o con ruolo «tutto»; chat a parte (tg-<chat>.json), risposta
			   mandata da ai.uc nella chat Telegram, niente ans.json (quella dell'app resta com'è) */
			let tg = req.args.tg != null ? '' + req.args.tg : null;
			if (tg != null) {
				let ok = match(tg, /^-?[0-9]{1,20}$/) != null && tg == tgconf().chat;
				for (let k in W) if (!ok && W[k]['.type'] == 'tgchat' && W[k].id == tg && W[k].role == 't') ok = match(tg, /^-?[0-9]{1,20}$/) != null;
				if (!ok || ug(W, 'ai', 'tg') != '1') return { error: 'chat non valida' };
			}
			if (S.state == 'busy') return { error: L('Una domanda alla volta: aspetta la risposta o fermala', 'One question at a time: wait for the answer or stop it'), state: S.state };
			/* 2.64: fornitore attivo fermo (limite del fornitore, occupato, chiave) con una riserva pronta = la domanda va alla riserva */
			let bk = S.backup && !aiheld(S.backup, now) ? S.backup : null, pre = S.pfail && bk ? S.pfail : null;
			if (S.state != 'ready' && S.state != 'offline' && !pre) return { error: S.why, state: S.state, wait: S.wait, alt: S.alt };
			let me = lc('' + (req.args.me ?? ''));
			if (!okmac(me)) me = '';
			aidir();
			/* blocco rimasto da un lavoro finito male (aistat lo dà già per libero): si riprende */
			if (!mkdir(AID + '/lock') && !(rmdir(AID + '/lock') && mkdir(AID + '/lock'))) return { error: L('Una domanda alla volta: aspetta la risposta o fermala', 'One question at a time: wait for the answer or stop it'), state: 'busy' };
			let id = aiid(), P = aiprov(W, S.prov), alts = [], cf = AID + (tg != null ? '/tg-' + tg + '.json' : '/chat.json'), C = rjs(cf) ?? { v: 1, sum: '', msgs: [], sig: {} };
			for (let x in AIPROV) if (aiready(W, x, S.prov) && !aiheld(x, now)) push(alts, x);
			push(C.msgs, { r: 'u', t: t, ts: now });
			wjs(cf, C);
			/* 2.64: B = fornitore di riserva (senza chiave), pre = perché si parte già dalla riserva (limit|wait|key) */
			let B = bk ? aiprov(W, bk) : null;
			wjs(AID + '/p-' + id + '.json', { id: id, text: t, me: me, tg: tg, P: P, B: B, pre: pre, alts: alts, lang: ug(W, 'ui', 'lang') == 'en' ? 'en' : 'it', t: now });
			if (tg == null) wjs(AID + '/ans.json', { id: id, t: now, text: '', done: false, src: [] });
			writefile(AID + '/run', id);
			aibg('ask', id);
			return { id: id, state: 'busy' };
		}
	},
	aiget: {
		/* risposta in corso (ans.json): from = il len ricevuto l'ultima volta (byte) → {id, t, text (solo il pezzo nuovo), len,
		   done, err, errk, ask, local, items, since, src, alt, wait}; id = quello di aiask (diverso o file sparito: lost).
		   2.64: st = stato dal vivo null | {k read|think|prop, t frase}, tm = tempi in ms a risposta finita
		   {first, tot, think, rounds, reads, rd}.
		   job = esito di un lavoro lungo {id, kind, done, ok, msg, data} (il file si toglie quando si legge con done) */
		args: { from: 0, id: 'id', job: 'job' },
		call: function(req) {
			let a = req.args ?? {}, now = time();
			if (a.job != null) {
				let j = '' + a.job, f = AID + '/job-' + j + '.json';
				if (!match(j, /^[0-9a-f]{8}$/)) return { error: 'lavoro non valido' };
				let R = rjs(f);
				if (!R) return { id: j, done: true, ok: false, lost: true, msg: L('Il lavoro si è perso: riprova', 'The task was lost: try again') };
				if (!R.done && now - +(R.t ?? 0) > 5 && !aialive(j)) R = { ...R, done: true, ok: false, lost: true, msg: L('Il lavoro si è fermato: riprova', 'The task stopped: try again') };
				if (R.done) unlink(f);
				/* 2.63: conferma con left e done (bakcf) */
				if (type(R.data?.confirm) == 'object') R.data.confirm = bakcf(R.data.confirm, R.t);
				return R;
			}
			let A = rjs(AID + '/ans.json'), id = '' + (a.id ?? '');
			if (!A || (length(id) && A.id != id)) return { none: true, lost: length(id) > 0, done: true, err: length(id) ? L('La risposta si è persa', 'The answer was lost') : null, errk: length(id) ? 'lost' : null };
			let tx = A.text ?? '', txfrom = type(a.from) == 'int' && a.from > 0 && a.from <= length(tx) ? a.from : 0;
			let r = { id: A.id, t: A.t, text: substr(tx, txfrom), len: length(tx), done: !!A.done, err: A.err ?? null, errk: A.errk ?? null, ask: A.ask ?? null,
				local: !!A.local, items: A.items ?? null, since: A.since ?? null, src: A.src ?? [], alt: A.alt ?? null, wait: A.wait ?? 0,
				/* 2.64: risposta data dal fornitore di riserva {t} (frase del router) */
				via: A.via ?? null,
				/* 2.63: dati composti dal router per la bolla e pagina da aprire per fare qualcosa (Apri) */
				cards: A.cards ?? null, go: A.go ?? null, st: A.done ? null : A.st ?? null, tm: A.tm ?? null,
				/* 2.64 precisione: scelta a pulsanti quando un nome è ambiguo {t, opts [{t, v}]} (l'app manda aiask {text: v}) */
				pick: A.done ? A.pick ?? null : null };
			if (!r.done && now - +(A.t ?? 0) > 5 && !aialive(A.id)) { r.done = true; r.errk = 'lost'; r.err = L('La risposta si è persa', 'The answer was lost'); r.st = null; }
			return r;
		}
	},
	aistop: {
		/* Ferma: lavoro della domanda in corso fermato (anche curl), file delle intestazioni tolti, risposta chiusa */
		call: function() {
			let A = rjs(AID + '/ans.json');
			if (A?.id) aikill(A.id);
			rmdir(AID + '/lock');
			if (A && !A.done) { A.done = true; A.errk = 'stop'; A.err = L('Risposta fermata', 'Answer stopped'); wjs(AID + '/ans.json', A); }
			return { ok: true };
		}
	},
	aichat: {
		/* chat in corso (solo in /tmp, mai in flash): get = {msgs [{r u|a|n, t, ts, src, local, ask}], sum, n}; new = Nuova
		   Chat; load {msgs [{r u|a, t}] al massimo 40} = riapre una chat salvata sul telefono, ripulita dai segreti in
		   sottofondo: risposta subito {id}, esito con aiget {job} */
		args: { action: 'action', msgs: [] },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), S = aistat(null);
			/* 2.63: note con confirm {method, secs, t} + left e done (bakcf), così l'app non usa l'orologio del telefono */
			if (act == 'get') {
				let C = rjs(AID + '/chat.json') ?? {}, M = C.msgs ?? [];
				for (let m in M) if (m?.r == 'n' && type(m.confirm) == 'object') m.confirm = bakcf(m.confirm);
				return { msgs: M, sum: length(C.sum ?? '') > 0, n: length(M) };
			}
			if (act != 'new' && act != 'load') return { error: 'azione non valida' };
			if (S.state == 'busy') return { error: L('Una domanda alla volta: aspetta la risposta o fermala', 'One question at a time: wait for the answer or stop it') };
			if (act == 'new') {
				/* 2.63 Memoria Automatica (accesa di serie): la chat finita va a ai.uc mem, una chiamata in sottofondo, se ha
				   domande non ancora ricordate */
				let C = rjs(AID + '/chat.json'), lu = 0;
				for (let m in C?.msgs ?? []) if (m?.r == 'u') lu = +(m.ts ?? 0);
				if (S.on && ug('wrtfreedom', 'ai', 'mauto') != '0' && lu > 0 && lu > +(C.mt ?? 0)) aijob('mem', { chat: C });
				for (let f in [ 'chat.json', 'ans.json', 'sent.json', 'pend.json' ]) unlink(AID + '/' + f);
				return { ok: true };
			}
			if (!S.on) return { error: 'Assistente IA spento' };
			if (type(a.msgs) != 'array' || !length(a.msgs) || length(a.msgs) > 40) return { error: 'chat non valida (da 1 a 40 messaggi)' };
			for (let m in a.msgs) if (type(m) != 'object' || (m.r != 'u' && m.r != 'a') || type(m.t) != 'string' || !length(m.t) || length(m.t) > 4000) return { error: 'chat non valida' };
			return aijob('load', { msgs: map(a.msgs, (m) => ({ r: m.r, t: m.t })) });
		}
	},
	aido: {
		/* risposta alla proposta in attesa (pend.json, una alla volta, scade dopo 10 minuti): yes true = fatto da ai.uc in
		   sottofondo, risposta subito {id} ed esito con aiget {job}: {ok, msg, data {confirm: {method, secs}}} (conferma
		   con ritorno, es. vpnout confirm); yes false = rifiutata */
		args: { id: 'id', yes: true, tg: 'tg' },
		call: function(req) {
			let id = '' + (req.args.id ?? ''), now = time(), tg = req.args.tg != null ? '' + req.args.tg : null;
			/* 2.62 Anche Nel Bot: proposte del bot in pend-tg.json {id: proposta}, solo dalla stessa chat */
			if (tg != null) {
				let M = rjs(AID + '/pend-tg.json') ?? {}, X = M[id];
				if (!match(id, /^[0-9a-f]{8}$/) || !X || X.tg != tg) return { error: L('Richiesta non trovata', 'Request not found') };
				delete M[id];
				for (let k in keys(M)) if (now - +(M[k].t ?? 0) > 600) delete M[k];
				wjs(AID + '/pend-tg.json', M);
				if (now - +(X.t ?? 0) > 600) return { error: L('Richiesta scaduta', 'Request expired'), expired: true };
				if (req.args.yes !== true) { ainote(L('Annullato: ', 'Cancelled: ') + X.text, { no: { cmd: X.cmd ?? '', mac: X.mac ?? '', q: X.q ?? '' } }, tg); return { ok: true, no: true }; }
				if (ug('wrtfreedom', 'ai', 'on') != '1') return { error: 'Assistente IA spento' };
				aiact();
				return aijob('do', X);
			}
			let P = rjs(AID + '/pend.json');
			if (!P || P.id != id) return { error: L('Richiesta non trovata', 'Request not found') };
			if (now - +(P.t ?? 0) > 600) { unlink(AID + '/pend.json'); ainote(L('Richiesta scaduta: ', 'Request expired: ') + P.text); return { error: L('Richiesta scaduta', 'Request expired'), expired: true }; }
			unlink(AID + '/pend.json');
			/* 2.64: la nota del No tiene cosa era stato proposto (no {cmd, mac, q}): ai.uc impara dalla richiesta riformulata */
			if (req.args.yes !== true) { ainote(L('Annullato: ', 'Cancelled: ') + P.text, { no: { cmd: P.cmd ?? '', mac: P.mac ?? '', q: P.q ?? '' } }); return { ok: true, no: true }; }
			if (ug('wrtfreedom', 'ai', 'on') != '1') return { error: 'Assistente IA spento' };
			aiact();
			return aijob('do', P);
		}
	},
	aiundo: {
		/* Annulla L'Ultima Azione dell'IA (undo.json, inverso salvato dopo il comando): in sottofondo, risposta subito {id} */
		call: function() {
			let U = rjs(AID + '/undo.json');
			if (!U) return { error: L('Niente da annullare', 'Nothing to undo') };
			unlink(AID + '/undo.json');
			aiact();
			return aijob('undo', U);
		}
	},
	aisent: {
		/* Cosa Parte: l'ultima richiesta mandata al fornitore, già pulita {t, prov, name, host, model, body} */
		call: function() {
			return rjs(AID + '/sent.json') ?? { none: true };
		}
	},
	aitest: {
		/* Prova La Chiave: domanda brevissima in sottofondo (prov = fornitore, di serie quello scelto); risposta subito {id},
		   esito con aiget {job}: {ok, msg «Groq ha risposto in 0,8 secondi.» o l'errore in una frase} */
		args: { prov: 'prov' },
		call: function(req) {
			let W = ucfile('wrtfreedom'), pid = '' + (req.args.prov ?? ug(W, 'ai', 'prov')), P = aiprov(W, pid);
			if (!P) return { error: 'scegli prima il fornitore' };
			if (!has('/usr/bin/curl')) return { error: L('Manca Un Programma: Installalo Da Software', 'A Program Is Missing: Install It From Software'), state: 'nocurl' };
			if (P.key && !P.has) return { error: 'manca la chiave' };
			if (!length(P.url) || !length(P.model)) return { error: 'mancano l\'indirizzo o il modello' };
			return aijob('test', { P: P });
		}
	},
	aimodels: {
		/* modelli del fornitore (prov, di serie quello scelto) in sottofondo: risposta subito {id}, elenco con aiget {job}:
		   data {list [id], cur}; 2.64 OpenRouter: list [{id, tools, free}] (tools = usa gli strumenti, free = gratis) */
		args: { prov: 'prov' },
		call: function(req) {
			let W = ucfile('wrtfreedom'), pid = '' + (req.args.prov ?? ug(W, 'ai', 'prov')), P = aiprov(W, pid);
			if (!P) return { error: 'scegli prima il fornitore' };
			if (!has('/usr/bin/curl')) return { error: L('Manca Un Programma: Installalo Da Software', 'A Program Is Missing: Install It From Software'), state: 'nocurl' };
			if (P.key && !P.has) return { error: 'manca la chiave' };
			if (!length(P.url)) return { error: 'manca l\'indirizzo' };
			return aijob('models', { P: P });
		}
	},
	aiscan: {
		/* Cerca Nella Rete (solo su richiesta): Ollama (11434) e LM Studio (1234) sui dispositivi di casa, in sottofondo;
		   risposta subito {id}, esito con aiget {job}: data {list [{ip, d, name, kind ollama|lmstudio, port, url, models}]} */
		call: function() {
			if (!has('/usr/bin/curl')) return { error: L('Manca Un Programma: Installalo Da Software', 'A Program Is Missing: Install It From Software'), state: 'nocurl' };
			return aijob('scan', {});
		}
	},
	aimem: {
		/* Cose Da Ricordare (2.62): get = {list [{id, t, text (nome di adesso), raw ({0}), macs, dev {mac, name, gone},
		   person (Persona che ha già il dispositivo: «Già in Persone»)}], n, max, len}; add {text, macs}, set {id, text,
		   macs}, del {id}, clear (Cancella Tutto). Al massimo 15 fatti da 100 caratteri, mai segreti */
		/* 2.63: check {text, macs} = stesso controllo di add senza salvare (proposte dell'IA: un solo tetto e un solo
		   controllo dei segreti); undo = rimette la Memoria di prima dell'ultima memoria automatica (mem-prev.json) */
		args: { action: 'action', id: 'id', text: 'text', macs: 'macs' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), M = rjs(AIMEM) ?? {}, H = leases();
			if (act == 'undo') {
				let PF = AID + '/mem-prev.json', P = rjs(PF);
				if (!P) return { error: L('Niente da annullare', 'Nothing to undo') };
				if (P.none || type(P.f) != 'array') unlink(AIMEM);
				else if (!aimemsave({ v: 1, f: P.f })) return { error: 'non salvato (spazio pieno?)' };
				unlink(PF);
				ainote(L('Memoria: rimessa com\'era prima dell\'ultimo aggiornamento automatico.', 'Memory: put back as it was before the last automatic update.'));
				return { ok: true };
			}
			M = { v: 1, f: filter(type(M.f) == 'array' ? M.f : [], (x) => type(x) == 'object' && type(x.text) == 'string') };
			if (act == 'get') {
				let W = ucfile('wrtfreedom'), PR = presence(), K = seenmap(), PM = {};
				for (let k in W) if (W[k]['.type'] == 'person') for (let m in vpnarr(W[k].mac)) PM[lc(m)] = W[k].name ?? '';
				let list = map(M.f, (x) => {
					let m = (x.macs ?? [])[0], nm = m ? (H[m]?.name ?? '') : '', dn = length(nm) ? nm : L('un dispositivo senza nome', 'an unnamed device');
					return { id: x.id, t: x.t, text: replace(x.text, '{0}', () => dn), raw: x.text, macs: x.macs ?? [],
						dev: m ? { mac: m, name: nm, gone: !PR[m] && !H[m] && K[m] == null } : null, person: m ? (PM[m] ?? null) : null };
				});
				return { list: list, n: length(list), max: AIMEMMAX, len: 100 };
			}
			if (act == 'clear') { unlink(AIMEM); return { ok: true }; }
			let id = '' + (a.id ?? ''), i = -1;
			for (let k = 0; k < length(M.f); k++) if (M.f[k].id == id) i = k;
			if (act == 'del') {
				if (i < 0) return { error: 'fatto non trovato' };
				splice(M.f, i, 1);
				return aimemsave(M) ? { ok: true } : { error: 'non salvato (spazio pieno?)' };
			}
			if (act != 'add' && act != 'set' && act != 'check') return { error: 'azione non valida' };
			if (act == 'set' && i < 0) return { error: 'fatto non trovato' };
			let t = trim(replace('' + (a.text ?? ''), /[[:cntrl:]]+/g, ' ')), ms = a.macs != null ? maclist(a.macs, 4) : (act == 'set' ? (M.f[i].macs ?? []) : []);
			/* il nome di adesso del dispositivo nel testo diventa {0}: il fatto segue il dispositivo anche se cambia nome */
			let dn = length(ms) ? (H[ms[0]]?.name ?? '') : '', j = length(dn) && index(t, '{0}') < 0 ? index(t, dn) : -1;
			if (j >= 0) t = substr(t, 0, j) + '{0}' + substr(t, j + length(dn));
			if (!length(ms)) t = trim(replace(t, '{0}', ''));
			if (!length(t) || uclen(t) > 100) return { error: 'fatto vuoto o troppo lungo (al massimo 100 caratteri)' };
			if (aisecret(t)) return { error: L('Non salvo password o codici', 'I do not save passwords or codes') };
			if (act != 'set' && length(M.f) >= AIMEMMAX) return { error: L('Elenco pieno: togli un fatto', 'List full: remove a fact') };
			if (act == 'check') return { ok: true, text: t };
			if (act == 'add') {
				id = aiid();
				push(M.f, { id: id, t: time(), text: t, macs: ms });
			}
			else { M.f[i].text = t; M.f[i].macs = ms; M.f[i].t = time(); }
			return aimemsave(M) ? { ok: true, id: id } : { error: 'non salvato (spazio pieno?)' };
		}
	},
	aivote: {
		/* 2.64 precisione: pollice su (up true) o giù (false) sotto una risposta dell'IA (ts del messaggio r:'a' della chat in
		   corso, vote 1|-1 nel messaggio); lo stesso di nuovo = tolto. I voti stanno in /etc/wrtfreedom/ai-votes.json (0600)
		   {v, list [{k, t, v, q, a, rd, how, cat, model, prova}]}, ultimi 200: domanda e risposta in breve, letture, strumenti,
		   tipo di domanda e modello. Positivi = esempi per le domande simili (ai.uc); negativi = prova «categoria|domanda»
		   proposta per la serie di prove (tools/v2/aimisura.txt: la aggiunge il coordinatore, mai il router) */
		args: { ts: 0, up: true },
		call: function(req) {
			let a = req.args ?? {}, ts = a.ts, f = AID + '/chat.json', C = rjs(f), i = -1;
			if (type(ts) != 'int' || type(a.up) != 'bool') return { error: 'voto non valido' };
			for (let k = length(C?.msgs ?? []) - 1; k >= 0; k--) if (C.msgs[k]?.r == 'a' && +(C.msgs[k].ts ?? 0) == ts) { i = k; break; }
			if (i < 0) return { error: L('Risposta non trovata', 'Answer not found') };
			let m = C.msgs[i], v = a.up ? 1 : -1, q = '';
			for (let k = i - 1; k >= 0; k--) if (C.msgs[k]?.r == 'u') { q = '' + (C.msgs[k].t ?? ''); break; }
			if (m.vote == v) delete m.vote; else m.vote = v;
			wjs(f, C);
			/* testo su una riga, al massimo n byte senza spezzare un carattere */
			let one = (t, n) => { t = trim(replace('' + (t ?? ''), /[[:space:]]+/g, ' ')); if (length(t) <= n) return t; while (n > 0 && (ord(t, n) & 192) == 128) n--; return substr(t, 0, n); };
			let key = ts + '|' + one(q, 60), V = rjs(AIVOTE), Lv = filter(type(V?.list) == 'array' ? V.list : [], (x) => type(x) == 'object' && x.k != key);
			if (m.vote) push(Lv, { k: key, t: time(), v: m.vote, q: one(q, 300), a: one(length(m.t ?? '') ? m.t : (m.ask ?? m.pick?.t), 300), rd: m.src ?? [], how: m.how ?? '', cat: m.cat ?? '',
				model: m.mdl ?? '', prova: m.vote < 0 && length(q) ? (m.cat ?? 'S') + '|' + one(replace(q, /[|]/g, '/'), 200) : null });
			mkdir(replace(AIVOTE, /\/[^\/]*$/, ''), 448);
			if (writefile(AIVOTE + '.t', sprintf('%J', { v: 1, list: slice(Lv, length(Lv) > 200 ? length(Lv) - 200 : 0) })) == null) { unlink(AIVOTE + '.t'); return { error: 'non salvato (spazio pieno?)' }; }
			sh('chmod 600 ' + AIVOTE + '.t');
			rename(AIVOTE + '.t', AIVOTE);
			return { ok: true };
		}
	},
	assist: {
		/* Pacchetto Per L'Assistenza (2.55): get = asget {busy, ready, t, size, left (secondi alla rimozione), path, files,
		   skip [{f, n}] (righe tolte dal controllo dei segreti), err}; make = assist.uc in sottofondo; del = toglie subito */
		args: { action: 'action' },
		call: function(req) {
			let act = '' + (req.args?.action ?? 'get');
			if (act == 'get') return asget();
			if (act == 'del') { unlink(ASF); unlink(ASJ); writefile('/tmp/wf-assist.id', ''); return { ok: true }; }
			if (act != 'make') return { error: 'azione non valida' };
			let r = asget();
			if (r.busy) return r;
			mkdir(ASLK, 448);
			sh('( ucode /usr/share/wrtfreedom/assist.uc ) >/dev/null 2>&1 </dev/null &');
			r = asget(); r.started = true; r.busy = true; r.ready = false;
			return r;
		}
	},
	diagtools: {
		/* Strumenti Mancanti (2.55): {list [{id, name, ok, pkg}], miss (quanti mancano), pm apk|opkg|''}; l'installazione
		   resta quella di Software (pkgdo add) */
		call: function() {
			let R = [], n = 0;
			for (let x in DGTOOLS) {
				let ok = length(filter(x[3], (p) => has(p))) > 0;
				if (!ok) n++;
				push(R, { id: x[0], name: L(x[1], x[2]), ok: ok, pkg: x[4] });
			}
			return { list: R, miss: n, pm: has('/usr/bin/apk') || has('/sbin/apk') ? 'apk' : (has('/bin/opkg') || has('/usr/bin/opkg') ? 'opkg' : '') };
		}
	},
	rclocal: {
		/* Comandi All'Avvio Con Copia (2.55): get = {text, copies [{t, size}] (ultime 5, dalla più recente), undo};
		   set {text} = copia del file di adesso in /etc/wrtfreedom/rclocal, poi salva; undo = rimette l'ultima copia */
		args: { action: 'action', text: 'text' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get');
			if (act == 'get') return rclget();
			if (act == 'undo') {
				let C = rclcopies();
				if (!length(C)) return { error: 'niente da annullare' };
				let o = readfile(RCLD + '/' + C[0].f), cur = readfile(RCL);
				if (o == null) return { error: 'copia non leggibile' };
				/* prima la copia del file di adesso (anche lui fra le ultime 5), la copia usata si toglie solo a file rimesso */
				if (cur != null && cur != o && !rclcopy(cur)) return { error: 'copia non riuscita' };
				if (!rclput(o)) return { error: 'ripristino non riuscito' };
				unlink(RCLD + '/' + C[0].f); rcltrim();
				let r = rclget(); r.ok = true;
				return r;
			}
			if (act != 'set') return { error: 'azione non valida' };
			if (type(a.text) != 'string' || length(a.text) > 65536) return { error: 'testo non valido' };
			let n = replace(a.text, /\r/g, ''), cur = readfile(RCL);
			if (length(n) && substr(n, -1) != '\n') n += '\n';
			if (n == cur) { let r = rclget(); r.ok = true; r.same = true; return r; }
			if (cur != null && !rclcopy(cur)) return { error: 'copia non riuscita' };
			if (!rclput(n)) return { error: 'salvataggio non riuscito' };
			rcltrim();
			let r = rclget(); r.ok = true;
			return r;
		}
	},
	tgdoc: {
		/* backup delle impostazioni mandato al bot collegato nell'app. 2.62: backup e invio in sottofondo (staccati da rpcd),
		   il metodo torna subito {ok, bg} ({ok, busy} se un invio è già in corso); esito di Telegram in /tmp/wf-tgdoc.json */
		call: function() {
			let c = tgconf();
			if (!length(c.token) || !length(c.chat)) return { error: 'collega prima il bot in Bot Telegram' };
			if (!curlok()) return { error: CURLE };
			let lt = localtime(), host = replace(trim(readfile('/proc/sys/kernel/hostname') ?? '') || 'router', /[^A-Za-z0-9_-]/g, '-');
			let f = '/tmp/backup-' + host + '-' + sprintf('%04d%02d%02d', lt.year, lt.mon, lt.mday) + '.tar.gz', o = '/tmp/wf-tgdoc.json';
			/* backup completo verificato (2.40), altrimenti quello standard */
			/* copia per Telegram (2.62): senza chiavi dell'Assistente IA né Cose Da Ricordare (backup.sh create … tg) */
			let mk = has('/usr/share/wrtfreedom/backup.sh') ? 'sh /usr/share/wrtfreedom/backup.sh create ' + q(f) + ' tg' : 'sysupgrade -b ' + q(f);
			let k = tgk(c.token, 'sendDocument', [ [ 'form-string', 'chat_id=' + c.chat ], [ 'form', 'document=@' + f ],
				[ 'form-string', 'caption=💾 ' + L('Backup di ', 'Backup of ') + host ] ]);
			if (!detach('tgdoc', mk + ' >/dev/null 2>&1; if [ -s ' + q(f) + ' ]; then curl -s -m 60 -K ' + k + ' > ' + o + '.t 2>/dev/null; ' +
				'else echo \'{"ok":false,"description":"backup non creato"}\' > ' + o + '.t; fi; mv -f ' + o + '.t ' + o + '; rm -f ' + k + ' ' + q(f))) {
				unlink(k);
				return { ok: true, busy: true };
			}
			return { ok: true, bg: true };
		}
	},
	tgfile: {
		/* file di testo preparato dall'app (es. configurazione WireGuard) mandato al bot collegato (pacchetto 2.39).
		   ttl = secondi dopo i quali il bot cancella il messaggio (0 = resta): la configurazione ha la chiave privata.
		   2.62: invio (e cancellazione a tempo) in sottofondo, il metodo torna subito {ok, bg}; esito in /tmp/wf-tgfile.json */
		args: { name: 'name', data: 'data', caption: 'caption', ttl: 0 },
		call: function(req) {
			let a = req.args ?? {}, c = tgconf(), name = '' + (a.name ?? ''), data = '' + (a.data ?? ''), ttl = +(a.ttl ?? 0);
			if (!length(c.token) || !length(c.chat)) return { error: 'collega prima il bot in Bot Telegram' };
			if (!curlok()) return { error: CURLE };
			if (!match(name, /^[A-Za-z0-9._=+-]{1,40}$/) || !length(data) || length(data) > 65536) return { error: 'file non valido' };
			if (ttl < 0 || ttl > 86400) ttl = 0;
			let d = '/tmp/wf-tgfile', f = d + '/' + name, o = '/tmp/wf-tgfile.json';
			mkdir(d, 448);
			writefile(f, data);
			let k = tgk(c.token, 'sendDocument', [ [ 'form-string', 'chat_id=' + c.chat ], [ 'form', 'document=@' + f ],
				[ 'form-string', 'caption=' + substr('' + (a.caption ?? ''), 0, 1000) ] ]);
			let x = tgk(c.token, 'deleteMessage', [ [ 'data', 'chat_id=' + urlenc(c.chat) ] ]);
			let s = 'r=$(curl -s -m 60 -K ' + k + ' 2>/dev/null); rm -f ' + k + ' ' + q(f) + '; printf %s "$r" > ' + o + '.t; mv -f ' + o + '.t ' + o;
			if (ttl > 0) s += '; m=$(jsonfilter -s "$r" -e @.result.message_id 2>/dev/null); case "$m" in ""|*[!0-9]*) ;; *) sleep ' + int(ttl) +
				'; curl -s -m 30 -d message_id=$m -K ' + x + ' >/dev/null 2>&1 ;; esac';
			/* un lavoro per invio (nome del file delle opzioni): due invii insieme non si fermano a vicenda */
			detach('tgfile.' + substr(k, length(KD) + 1), s + '; rm -f ' + x);
			return { ok: true, bg: true };
		}
	},
	wanre: {
		/* riconnette le interfacce internet (zona wan), qualunque sia il loro nome */
		call: function() {
			sh('sh /usr/share/wrtfreedom/event.sh act wan_reconnect >/dev/null 2>&1 &');
			return { ok: true };
		}
	},
	updcheck: {
		/* aggiornamenti dal server: manifesto firmato verificato da upd.sh (lettura in sottofondo, al massimo ogni 6 ore) */
		args: { fresh: true, app: 'app' },
		call: function(req) {
			let a = '' + (req.args.app ?? '');
			if (match(a, /^[0-9][0-9.]{0,15}$/) && trim(readfile('/etc/wrtfreedom/appver') ?? '') != a)
				writefile('/etc/wrtfreedom/appver', a + '\n');
			let o = stat('/tmp/wf-upd.json'), e = stat('/tmp/wf-upd.err'), r = stat('/tmp/wf-upd.run'), now = time();
			let lo = o ? o.mtime : 0, le = e ? e.mtime : 0, last = lo > le ? lo : le, busy = r != null && now - r.mtime < 120;
			if (!busy && (req.args.fresh || now - last > 21600)) {
				sh('( touch /tmp/wf-upd.run; sh /usr/share/wrtfreedom/upd.sh check; rm -f /tmp/wf-upd.run ) >/dev/null 2>&1 </dev/null &');
				busy = true;
			}
			let m = null;
			try { m = json(readfile('/tmp/wf-upd.json') ?? 'null'); } catch (x) {}
			return { cur: trim(readfile('/usr/share/wrtfreedom/VERSION') ?? ''), m: m, err: trim(readfile('/tmp/wf-upd.err') ?? ''),
				t: o ? o.mtime : 0, busy: busy, usign: has('/usr/bin/usign') || has('/bin/usign'),
				check: ug('wrtfreedom', 'upd', 'check') != '0' };
		}
	},
	updpkg: {
		/* il router scarica il Pacchetto Router, lo controlla (firma e sha256) e lo installa: web app e bot */
		call: function() {
			return job('sh /usr/share/wrtfreedom/upd.sh install');
		}
	},
	updset: {
		/* controllo periodico degli aggiornamenti acceso o spento */
		args: { check: true },
		call: function(req) {
			sh('uci -q get wrtfreedom.upd >/dev/null || uci set wrtfreedom.upd=update; uci set wrtfreedom.upd.check=' + (req.args.check ? '1' : '0') + '; uci commit wrtfreedom');
			return { ok: true };
		}
	},
	fwupd: {
		/* c'è un firmware più nuovo? fwupd.uc in sottofondo (rete), al massimo ogni 6 ore o con «fresh»; «repo» = progetto
		   GitHub scritto dall'utente (owner/nome o indirizzo), «-» lo toglie e si torna al riconoscimento automatico */
		args: { fresh: true, repo: '' },
		call: function(req) {
			let rp = req.args.repo;
			if (rp != null && length(rp)) {
				if (rp == '-')
					sh('uci -q delete wrtfreedom.fw.repo; uci commit wrtfreedom');
				else {
					let m = match(replace(rp, /\.git\/?$/, ''), /^(https?:\/\/github\.com\/)?([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)\/?$/);
					if (!m) return { error: 'indirizzo del progetto non valido (es. autore/progetto)' };
					sh('uci -q get wrtfreedom.fw >/dev/null || uci set wrtfreedom.fw=firmware; uci set wrtfreedom.fw.repo=' + q(m[2]) + '; uci set wrtfreedom.fw.auto=0; uci commit wrtfreedom');
				}
				req.args.fresh = true;
			}
			let o = stat('/tmp/wf-fw.json'), r = stat('/tmp/wf-fw.run'), now = time();
			let busy = r != null && now - r.mtime < 180;
			if (!busy && (req.args.fresh || !o || now - o.mtime > 21600)) {
				sh('( touch /tmp/wf-fw.run; ucode /usr/share/wrtfreedom/fwupd.uc; rm -f /tmp/wf-fw.run ) >/dev/null 2>&1 </dev/null &');
				busy = true;
			}
			let d = null;
			try { d = json(readfile('/tmp/wf-fw.json') ?? 'null'); } catch (x) {}
			return { busy: busy, r: d, repo: ug('wrtfreedom', 'fw', 'repo'), auto: ug('wrtfreedom', 'fw', 'auto') != '0' };
		}
	},
	fwget: {
		/* scarica il firmware nuovo in /tmp/firmware.bin (lavoro con l'avanzamento), controlla lo sha256 se c'è e lo prova con
		   sysupgrade -T: poi l'app mostra la stessa conferma di Carica Firmware */
		args: { url: '', sha: '' },
		call: function(req) {
			let u = '' + (req.args.url ?? ''), s = '' + (req.args.sha ?? '');
			if (!match(u, /^https:\/\/[A-Za-z0-9.\/_~%+:=?&-]+$/)) return { error: 'indirizzo non valido' };
			if (length(s) && !match(s, /^[0-9a-f]{64}$/)) return { error: 'sha256 non valido' };
			return job('rm -f /tmp/firmware.bin; echo "## Scarico il firmware"; ' +
				'if command -v uclient-fetch >/dev/null 2>&1; then uclient-fetch -T 60 -O /tmp/firmware.bin ' + q(u) + '; else curl -fL -m 900 -o /tmp/firmware.bin ' + q(u) + '; fi; ' +
				'[ -s /tmp/firmware.bin ] || { echo "## ERRORE download non riuscito"; exit 1; }; ' +
				(length(s) ? '[ "$(sha256sum /tmp/firmware.bin | cut -c1-64)" = ' + q(s) + ' ] || { rm -f /tmp/firmware.bin; echo "## ERRORE il file non corrisponde allo sha256 pubblicato"; exit 1; }; echo "## SHA256 verificato"; ' : '') +
				'echo "## OK scaricato"');
		}
	},
	prefs: {
		/* preferenze dell'app uguali su tutti i dispositivi (Dashboard, sezioni nascoste e ordine delle pagine): senza «data»
		   le legge, con «data» (JSON) le salva. Metodo del pacchetto: non dipende dai permessi di rpcd sui file */
		args: { data: '' },
		call: function(req) {
			const F = '/etc/wrtfreedom/prefs.json';
			let d = req.args.data;
			if (d != null && length(d)) {
				let j = null;
				try { j = json(d); } catch (e) {}
				if (type(j) != 'object' || length(d) > 65536)
					return { error: 'preferenze non valide' };
				writefile(F + '.tmp', d + '
');
				sh('chmod 600 ' + F + '.tmp; mv -f ' + F + '.tmp ' + F);
				return { ok: true };
			}
			return { data: readfile(F) ?? '' };
		}
	},
	luciui: {
		/* interfaccia all'indirizzo del router: WrtFreedom (tema di LuCI «WrtFreedom», installato da install.sh) o LuCI.
		   Senza «on» dice solo com'è. Accendendo si ricorda il tema di prima, per rimetterlo spegnendo */
		args: { on: true },
		call: function(req) {
			const W = '/luci-static/wrtfreedom';
			let ok = stat('/usr/share/ucode/luci/template/themes/wrtfreedom/header.ut') != null;
			let cur = trim(sh('uci -q get luci.main.mediaurlbase'));
			if (ok && req.args.on != null) {
				if (req.args.on && cur != W)
					sh('uci -q get wrtfreedom.luci >/dev/null || uci set wrtfreedom.luci=luci; uci set wrtfreedom.luci.prev=' + q(cur) + '; uci commit wrtfreedom; uci set luci.main.mediaurlbase=' + W + '; uci commit luci');
				else if (!req.args.on && cur == W) {
					let p = trim(sh('uci -q get wrtfreedom.luci.prev'));
					if (!length(p) || p == W || !stat('/www' + p))
						p = '/luci-static/bootstrap';
					sh('uci set luci.main.mediaurlbase=' + q(p) + '; uci commit luci');
				}
				cur = trim(sh('uci -q get luci.main.mediaurlbase'));
			}
			return { avail: ok, on: cur == W };
		}
	},
	modemreport: {
		/* Rapporto Modem: produttore, modello, firmware, strade usate, comandi mandati e risposte (senza IMEI né SIM) */
		call: function() {
			return job('ucode /usr/share/wrtfreedom/modemctl.uc report');
		}
	},
	bandset: {
		/* bande e modalità (modem.uc sceglie ModemManager o i comandi AT della marca), con il ripristino automatico */
		args: { lte: 'lte', nr: 'nr', mode: 'mode' },
		call: function(req) {
			let a = req.args ?? {}, lte = trim('' + (a.lte ?? '')), nr = trim('' + (a.nr ?? '')), mode = '' + (a.mode ?? '');
			if (!match(lte, /^[0-9 ]{1,160}$/) || !match(nr, /^[0-9 ]{0,160}$/) || !(mode in ['nr', 'lte', 'custom']))
				return { error: 'valori non validi' };
			M.guard();
			let r = M.bandsset(filter(split(lte, /\s+/), length), filter(split(nr, /\s+/), length), mode == 'lte' ? 'lte' : 'nr');
			return r;
		}
	},
	q5gset: {
		/* 2.63 (Rischio Alto): lock/unlock con secs (60–900) = copia del blocco di prima e ritorno se non arriva confirm
		   (bakarm 'cell', oltre a modemguard che rimette tutto dopo 180 s senza internet); dry = solo la frase (say);
		   confirm, back */
		args: { lte: 'lte', nr: 'nr', ltecell: 'ltecell', nrcell: 'nrcell', action: 'action', boot: true, secs: 0, dry: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'apply'), sec = +(a.secs ?? 0) > 0 ? hisecs(a.secs) : 0;
			if (act == 'confirm') return bakconfirm('cell');
			if (act == 'back') return bakback('cell', L('↩️ Blocco Cella: rimesso com\'era', '↩️ Cell Lock: restored'));
			let ok = function(v, re) { return v == null || match('' + v, re) != null; };
			if (!ok(a.lte, /^[0-9 ]{0,120}$/) || !ok(a.nr, /^[0-9 ]{0,120}$/) || !ok(a.ltecell, /^[0-9, ]{0,120}$/) || !ok(a.nrcell, /^[0-9, ]{0,120}$/))
				return { error: 'valori non validi' };
			/* frase per la conferma e ritorno a richiesta (cfgs = parte della configurazione del blocco, rc = comandi di prima) */
			let hold = function(cfgs, rc) {
				let L4 = trim('' + (a.ltecell ?? '')), N5 = trim('' + (a.nrcell ?? ''));
				let say = act == 'lock' ? L('Blocco il modem sulla cella 4G ' + L4 + (length(N5) ? ' e 5G ' + N5 : '') + ': se la cella non va la linea cade', 'I lock the modem to the 4G cell ' + L4 + (length(N5) ? ' and 5G ' + N5 : '') + ': if the cell does not work the line drops') :
					L('Tolgo il blocco cella: il modem sceglie da solo la cella', 'I remove the cell lock: the modem picks the cell by itself');
				say += sec ? L('; se non confermi entro ' + sec + ' secondi torna com\'era.', '; without your confirmation within ' + sec + ' seconds it goes back.') : '.';
				if (a.dry) return { ok: true, dry: true, say: say };
				if (sec) {
					if (bakpend('cell')) return { error: L('conferma prima il blocco cella in attesa', 'confirm the pending cell lock first'), code: 'pend', pend: 'cell' };
					let e = bakarm('cell', cfgs, [], rc + 'rm -f /tmp/wf-q5g.*', sec, L('↩️ Blocco Cella: nessuna conferma entro ' + sec + ' s, rimesso com\'era', '↩️ Cell Lock: no confirmation within ' + sec + ' s, restored'));
					if (e !== true) return e;
				}
				return { say: say };
			};
			if (!q5gtools()) {
				/* comandi AT della marca (modem.uc); il blocco si salva in wrtfreedom.lock e all'accensione modemctl.uc lo rimette */
				let D = M.drv(M.id()), L = trim('' + (a.ltecell ?? '')), N = trim('' + (a.nrcell ?? '')), c = '';
				if (a.boot != null) { sh('uci set wrtfreedom.lock=celllock; uci set wrtfreedom.lock.boot=' + (a.boot ? '1' : '0') + '; uci commit wrtfreedom'); if (act == 'boot') return { ok: true }; }
				if (!D || !D.lock) return { error: 'il blocco cella non è disponibile per questo modem' };
				if (act == 'lock' && (!match(L, /^[0-9]+,[0-9]+(,[0-9]+)?$/) || (length(N) && !match(N, /^[0-9]+,[0-9]+,[0-9]*,[0-9]+$/)))) return { error: 'valori non validi' };
				if (act != 'lock' && act != 'unlock') return { error: 'senza quectel-5g-tools le bande si cambiano dalla pagina Bande' };
				let W = ucfile('wrtfreedom'), rc = '';
				for (let x in M.lockcmds(D, ug(W, 'lock', 'lte'), ug(W, 'lock', 'nr'))) rc += 'sh /usr/share/wrtfreedom/at.sh ' + q(x) + '; ';
				let h = hold({ wrtfreedom: { n: 'lock', o: [ 'lte', 'nr' ] } }, rc);
				if (h.error || h.dry) return h;
				M.guard();
				for (let x in (act == 'lock' ? M.lockcmds(D, L, N) : D.unlock())) c += 'sh /usr/share/wrtfreedom/at.sh ' + q(x) + ' 2>&1; ';
				c += act == 'lock' ? 'uci set wrtfreedom.lock=celllock; uci set wrtfreedom.lock.lte=' + q(L) + '; ' + (length(N) ? 'uci set wrtfreedom.lock.nr=' + q(N) + '; ' : 'uci -q delete wrtfreedom.lock.nr; ')
					: 'uci -q delete wrtfreedom.lock.lte; uci -q delete wrtfreedom.lock.nr; ';
				let j = job(c + 'uci commit wrtfreedom; rm -f /tmp/wf-q5g.*');
				return sec ? { ...j, pend: sec, say: h.say } : j;
			}
			let h = null;
			if (act == 'lock' || act == 'unlock') {
				let Q = ucfile('quectel'), was = length(ug(Q, 'modem', 'lte_cells')) || length(ug(Q, 'modem', 'nr5g_cells'));
				h = hold({ quectel: { n: 'modem', o: [ 'lte_cells', 'nr5g_cells', 'lte_bands', 'nr5g_bands' ] } },
					was ? '5g-lock --apply; ' : "5g-lock --apply; sh /usr/share/wrtfreedom/at.sh 'AT+QNWLOCK=\"common/4g\",0'; sh /usr/share/wrtfreedom/at.sh 'AT+QNWLOCK=\"common/5g\",0'; ");
				if (h.error || h.dry) return h;
			}
			let cmd = '';
			let setl = function(opt, v) {
				cmd += 'uci -q delete quectel.modem.' + opt + '; ';
				for (let x in split(trim('' + v), /\s+/))
					if (length(x)) cmd += 'uci add_list quectel.modem.' + opt + '=' + x + '; ';
			};
			if (a.lte != null) setl('lte_bands', a.lte);
			if (a.nr != null) setl('nr5g_bands', a.nr);
			if (a.ltecell != null) setl('lte_cells', a.ltecell);
			if (a.nrcell != null) setl('nr5g_cells', a.nrcell);
			cmd += 'uci commit quectel; ';
			if (act == 'unlock')
				cmd += "5g-lock --apply 2>&1; sh /usr/share/wrtfreedom/at.sh 'AT+QNWLOCK=\"common/4g\",0' 2>&1; sh /usr/share/wrtfreedom/at.sh 'AT+QNWLOCK=\"common/5g\",0' 2>&1; ";
			else if (act == 'lock')
				cmd += '5g-lock --apply --verify 2>&1; ';
			else
				cmd += '5g-lock --apply 2>&1; ';
			cmd += 'echo; 5g-lock 2>&1';
			let j = job(cmd + '; rm -f /tmp/wf-q5g.*');
			return h && sec ? { ...j, pend: sec, say: h.say } : j;
		}
	},
	apnset: {
		/* Profilo Dati della linea mobile (2.63, Rischio Alto): get = { iface, proto, apn, iptype, pend }; set {apn, iptype,
		   secs, dry} = copia delle due opzioni (bakarm 'apn'), scrittura, ricollegamento (ifup) e ritorno da solo dopo secs
		   senza confirm; apn '' = nessun nome (solo ModemManager). Mai utente e password: restano quelli di prima */
		args: { action: 'action', apn: 'apn', iptype: 'iptype', secs: 0, dry: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? (a.apn != null ? 'set' : 'get'));
			if (act == 'confirm') return bakconfirm('apn');
			if (act == 'back') return bakback('apn', L('↩️ Profilo Dati: rimesso com\'era', '↩️ Data Profile: restored'));
			let A = apnstate();
			if (!A) return hierr('nomodem', 'questo router non ha una linea mobile', 'this router has no mobile line');
			if (act == 'get') return A;
			if (act != 'set') return { error: 'azione non valida' };
			let apn = trim('' + (a.apn ?? A.apn)), ipt = a.iptype != null ? '' + a.iptype : A.iptype, secs = hisecs(a.secs);
			if (length(apn) ? !match(apn, /^[A-Za-z0-9._-]{1,62}$/) : A.proto != 'modemmanager')
				return hierr('apn', 'nome del profilo non valido: lettere, numeri, punti e trattini', 'invalid profile name: letters, digits, dots and dashes');
			if (A.ipo && !(ipt in [ 'ipv4v6', 'ipv4', 'ipv6' ])) return hierr('iptype', 'tipo di indirizzo non valido (ipv4v6, ipv4, ipv6)', 'invalid address type (ipv4v6, ipv4, ipv6)');
			if (!A.ipo) ipt = null;
			if (apn == A.apn && ipt == A.iptype) return { ok: true, changed: false, iface: A.iface };
			let nm = (x) => length(x) ? '«' + x + '»' : L('nessun nome', 'no name');
			let say = L('Cambio il Profilo Dati della SIM da ' + nm(A.apn) + ' a ' + nm(apn) + (ipt != A.iptype ? ' (indirizzi ' + ipt + ')' : '') +
				': la linea si ricollega (circa 20 secondi) e se non confermi entro ' + secs + ' secondi torna ' + nm(A.apn) + '.',
				'I change the SIM Data Profile from ' + nm(A.apn) + ' to ' + nm(apn) + (ipt != A.iptype ? ' (' + ipt + ' addresses)' : '') +
				': the line reconnects (about 20 seconds) and without your confirmation within ' + secs + ' seconds it goes back to ' + nm(A.apn) + '.');
			if (a.dry) return { ok: true, dry: true, say: say, iface: A.iface };
			if (ucpend('network')) return hierr('luci', 'ci sono modifiche della rete non applicate (LuCI): applicale o annullale prima', 'there are unapplied network changes (LuCI): apply or revert them first');
			let e = bakarm('apn', { network: { n: A.iface, o: A.ipo ? [ 'apn', A.ipo ] : [ 'apn' ] } }, [], 'ifup ' + q(A.iface), secs,
				L('↩️ Profilo Dati: nessuna conferma entro ' + secs + ' s, rimesso com\'era', '↩️ Data Profile: no confirmation within ' + secs + ' s, restored'));
			if (e !== true) return e;
			sh((length(apn) ? uset('network', A.iface, 'apn', apn) : 'uci -q delete network.' + A.iface + '.apn; ') + (A.ipo ? uset('network', A.iface, A.ipo, ipt) : '') +
				'uci commit network; ( ifup ' + q(A.iface) + ' ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, changed: true, pend: secs, iface: A.iface, from: { apn: A.apn, iptype: A.iptype }, to: { apn: apn, iptype: ipt }, say: say };
		}
	},
	fwd: {
		/* Apri Una Porta verso un dispositivo (2.63, Rischio Alto): list = { list [porte aperte da qui], zone, pend };
		   add {name, proto tcp|udp|'tcp udp', port (una o «a-b», al massimo 100), to_port, mac, secs, dry} = inoltro dalla zona
		   esterna vera (masq) verso l'indirizzo fisso del dispositivo (creato se manca); del {id} chiude una porta aperta da
		   qui. Copia del firewall e dell'indirizzo fisso (bakarm 'fwd'), fw4 check prima, ritorno dopo secs senza confirm;
		   del senza secs (Annulla dell'Assistente IA) chiude subito, senza ritorno. Senza la zona con NAT (masq) o quella di
		   casa: errore, mai nomi di ripiego */
		args: { action: 'action', id: 'id', name: 'name', proto: 'proto', port: 'port', to_port: 'to_port', mac: 'mac', secs: 0, dry: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'list'), Z = fwzones(), secs = act == 'del' && !(+(a.secs ?? 0) > 0) ? 0 : hisecs(a.secs);
			if (act == 'confirm') return bakconfirm('fwd');
			if (act == 'back') return bakback('fwd', L('↩️ Porte: rimesse com\'erano', '↩️ Ports: restored'));
			if (act == 'list') return { list: pflist(), zone: Z.nowan ? null : Z.wan, home: Z.nohome ? null : Z.home, pend: bakleft('fwd') };
			if (act != 'add' && act != 'del' && act != 'on') return { error: 'azione non valida' };
			if (Z.nowan || Z.nohome) return hierr('zone', 'il firewall non ha la zona verso internet con il NAT o quella di casa: non si aprono porte', 'the firewall has no internet zone with NAT or no home zone: no ports are opened');
			let F = ucfile('firewall'), say = '', parts = {}, b = '', id = '', fx = null;
			/* 2.64 B5: on {id, on} = un inoltro che c'è (anche dell'utente) acceso con il ritorno dopo secs, o spento subito; mai tolto */
			if (act == 'on') {
				id = '' + (a.id ?? '');
				let s = F[id], on = a.on === true;
				if (!match(id, /^(@redirect\[[0-9]{1,3}\]|[A-Za-z0-9_]{1,64})$/) || s?.['.type'] != 'redirect' || (s.target ?? 'DNAT') != 'DNAT' || s.src != Z.wan)
					return hierr('id', 'inoltro non trovato tra quelli da internet', 'forward not found among those from the internet');
				if ((s.enabled != '0') == on) return hierr('same', on ? 'l\'inoltro è già acceso' : 'l\'inoltro è già spento', on ? 'the forward is already on' : 'the forward is already off');
				if (!on) secs = 0;
				let nm = s.name ?? id, ps = s.src_dport ?? '';
				b = 'set firewall.' + id + '.enabled=' + (on ? '1' : '0') + '\n';
				parts.firewall = fwpart(id);
				say = on ? L('Riaccendo l\'inoltro «' + nm + '» (porta ' + ps + ' verso ' + (s.dest_ip ?? '') + '): chiunque su internet potrà raggiungerlo. Se non confermi entro ' + secs + ' secondi si rispegne.',
					'I turn the forward «' + nm + '» back on (port ' + ps + ' to ' + (s.dest_ip ?? '') + '): anyone on the internet will reach it. Without your confirmation within ' + secs + ' seconds it turns off again.')
					: L('Spengo l\'inoltro «' + nm + '» (porta ' + ps + '): resta salvato e lo riaccendi quando vuoi.', 'I turn the forward «' + nm + '» off (port ' + ps + '): it stays saved and you can turn it back on any time.');
			}
			else if (act == 'add') {
				let mac = lc('' + (a.mac ?? '')), nm = pfname(a.name), pr = '' + (a.proto ?? 'tcp udp'), R = prange(a.port), T = length('' + (a.to_port ?? '')) ? prange(a.to_port) : R;
				if (pr == 'tcp+udp' || pr == 'both') pr = 'tcp udp';
				if (!okmac(mac)) return hierr('mac', 'dispositivo non valido', 'invalid device');
				if (!(pr in PFPR)) return hierr('proto', 'protocollo non valido (tcp, udp, tcp udp)', 'invalid protocol (tcp, udp, tcp udp)');
				if (!R || !T || R[1] - R[0] > 99 || T[1] - T[0] != R[1] - R[0]) return hierr('port', 'porta non valida: una porta o un intervallo di al massimo 100', 'invalid port: one port or a range of at most 100');
				let P = rtports();
				for (let x in P) if (+x >= R[0] && +x <= R[1]) return hierr('router', 'la porta ' + x + ' è del router: non si inoltra', 'port ' + x + ' belongs to the router: it is not forwarded');
				let prs = split(pr, ' '), c = pfclash(F, Z.wan, R, prs);
				if (c != null) return hierr('used', 'porta già aperta («' + c + '»)', 'port already open («' + c + '»)');
				let d = pfdev(mac);
				if (!match(d.ip, /^(10|192\.168|172\.(1[6-9]|2[0-9]|3[01]))\.[0-9.]+$/)) return hierr('noip', 'il dispositivo non ha un indirizzo di casa: deve essere collegato', 'the device has no home address: it must be connected');
				let ps = R[0] == R[1] ? '' + R[0] : R[0] + '-' + R[1], ts = T[0] == T[1] ? '' + T[0] : T[0] + '-' + T[1];
				id = 'wf_pf_' + R[0] + (R[0] == R[1] ? '' : '_' + R[1]) + '_' + PFPR[pr];
				if (!length(nm)) nm = 'WrtFreedom ' + ps;
				let A = 'firewall.' + id;
				b = 'set ' + A + '=redirect\nset ' + A + '.name=' + q(nm) + '\nset ' + A + '.src=' + q(Z.wan) + '\nset ' + A + '.dest=' + q(Z.home) + '\nset ' + A + '.target=DNAT\n' +
					'set ' + A + '.src_dport=' + q(ps) + '\nset ' + A + '.dest_ip=' + q(d.ip) + '\nset ' + A + '.dest_port=' + q(ts) + '\n' + join('', map(prs, (p) => 'add_list ' + A + '.proto=' + p + '\n'));
				parts.firewall = { n: id };
				/* indirizzo fisso: nuovo (wf_ip_<mac>) o aggiunto all'host che c'è già */
				if (!d.fixed) {
					let hs = d.sec ?? ('wf_ip_' + replace(mac, /:/g, ''));
					parts.dhcp = d.sec == null ? { n: hs } : (substr(hs, 0, 1) == '@' ? { a: [ hs ], o: [ 'ip' ] } : { n: hs, o: [ 'ip' ] });
					fx = (d.sec == null ? uset('dhcp', hs, 'mac', mac) + uset('dhcp', hs, 'name', replace(pfname(d.name) || 'dispositivo', / /g, '-')) : '') + uset('dhcp', hs, 'ip', d.ip);
					if (d.sec == null) fx = 'uci set dhcp.' + hs + '=host; ' + fx;
				}
				let pn = { tcp: 'TCP', udp: 'UDP', 'tcp udp': 'TCP e UDP' }[pr];
				say = L('Apro la porta ' + pn + ' ' + ps + ' da internet verso «' + d.name + '» (' + d.ip + (ts != ps ? ', porta ' + ts : '') + (d.fixed ? '' : ', con un indirizzo fisso nuovo') +
					'): chiunque su internet potrà raggiungerla. Se non confermi entro ' + secs + ' secondi la porta si richiude.',
					'I open ' + replace(pn, ' e ', ' and ') + ' port ' + ps + ' from the internet to «' + d.name + '» (' + d.ip + (ts != ps ? ', port ' + ts : '') + (d.fixed ? '' : ', with a new fixed address') +
					'): anyone on the internet will reach it. Without your confirmation within ' + secs + ' seconds the port closes again.');
			}
			else {
				id = '' + (a.id ?? '');
				let x = filter(pflist(), (p) => p.id == id)[0];
				if (!match(id, PFRX) || !x) return hierr('id', 'porta non trovata tra quelle aperte da qui', 'port not found among those opened here');
				b = 'delete firewall.' + id + '\n';
				parts.firewall = { n: id };
				say = L('Chiudo la porta ' + x.port + ' (' + x.proto + ') verso «' + x.dev + '».' + (secs ? ' Se non confermi entro ' + secs + ' secondi si riapre.' : ''),
					'I close port ' + x.port + ' (' + x.proto + ') to «' + x.dev + '».' + (secs ? ' Without your confirmation within ' + secs + ' seconds it opens again.' : ''));
			}
			if (a.dry) return { ok: true, dry: true, say: say, id: id };
			if (ucpend('firewall') || (fx && ucpend('dhcp'))) return hierr('luci', 'ci sono modifiche del firewall non applicate (LuCI): applicale o annullale prima', 'there are unapplied firewall changes (LuCI): apply or revert them first');
			/* una porta alla volta in attesa: la copia di una seconda non sarebbe nella prima */
			if (bakpend('fwd')) return { error: L('conferma prima la porta in attesa', 'confirm the pending port first'), code: 'pend', pend: 'fwd' };
			writefile('/tmp/wf-pf.uci', b);
			let o = sh('uci -q batch < /tmp/wf-pf.uci && { [ ! -x /sbin/fw4 ] || fw4 -q check >/dev/null 2>&1; } && echo __OK; rm -f /tmp/wf-pf.uci');
			if (trim(o) != '__OK') { sh('uci -q revert firewall'); return hierr('check', 'il firewall non accetta la regola: niente è cambiato', 'the firewall rejects the rule: nothing changed'); }
			/* copia delle parti di prima (dal file, le modifiche in sospeso non contano), poi commit e ricarica */
			let e = secs ? bakarm('fwd', parts, [], '/etc/init.d/dnsmasq reload; fw4 -q reload || /etc/init.d/firewall reload', secs,
				L('↩️ Porte: nessuna conferma entro ' + secs + ' s, rimesse com\'erano', '↩️ Ports: no confirmation within ' + secs + ' s, restored')) : true;
			if (e !== true) { sh('uci -q revert firewall'); return e; }
			sh((fx ? fx + 'uci commit dhcp; ' : '') + 'uci commit firewall; ( ' + (fx ? '/etc/init.d/dnsmasq reload; ' : '') + 'fw4 -q reload || /etc/init.d/firewall reload ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, id: id, pend: secs, say: say };
		}
	},
	updsafe: {
		/* Aggiornamenti con copia e ritorno (2.63, Rischio Alto): get = stato { st copy|install|wait|ok|back|err, kind, name,
		   from, to, copy, left, msg, t, busy, pend, cur, pm }; start {kind 'wf'|'pkg', name (pkg: uno dell'ultimo elenco
		   pkgs up, mai i programmi di sistema UPGNO), secs, dry} = lavoro staccato (upgjob); confirm (solo in wait); back;
		   ping (lo usa il lavoro per sapere se il router risponde). Mai firmware del modem né di OpenWrt */
		args: { action: 'action', kind: 'kind', name: 'name', secs: 0, dry: true },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), S = rjs(UPGF), run = upgrun(), cur = trim(readfile('/usr/share/wrtfreedom/VERSION') ?? '');
			if (act == 'ping') return { pong: true };
			if (act == 'get') return { ...(S ?? { st: '' }), busy: run, pend: bakleft('upg'), cur: cur, pm: has('/usr/bin/apk') || has('/sbin/apk') ? 'apk' : (has('/bin/opkg') || has('/usr/bin/opkg') ? 'opkg' : '') };
			if (act == 'confirm') {
				if (!S || S.st != 'wait' || !run) return hierr('nopend', 'niente da confermare', 'nothing to confirm');
				return bakconfirm('upg');
			}
			if (act == 'back') {
				if (run && S?.st == 'wait') { writefile(UPGD + '/back', ''); return { ok: true }; }
				if (run) return hierr('busy', 'aggiornamento in corso: aspetta la fine', 'update in progress: wait for the end');
				return bakback('upg', L('↩️ Aggiornamento: rimesso com\'era', '↩️ Update: restored'));
			}
			/* 2.64 B7 (Assistente IA): install {name (fino a 20, separati da spazi), dry} = pacchetti nuovi come pkgdo add (mai i
			   programmi di sistema UPGNO né quelli già installati), con lo spazio libero (free_mb); have {name} = installati adesso */
			if (act == 'have' || act == 'install') {
				let P = filter(split(trim('' + (a.name ?? '')), ' '), length), H = pkgHave(), o = {}, fk = +((ubcall('system', 'info') ?? {}).root?.free ?? 0);
				if (!length(P) || length(P) > 20) return hierr('name', 'nome del pacchetto non valido', 'invalid package name');
				for (let n in P) {
					if (!match(n, /^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$/)) return hierr('name', 'nome del pacchetto non valido', 'invalid package name');
					if (act == 'install' && match(n, UPGNO)) return hierr('system', '«' + n + '» è un programma di sistema: non si installa da qui', '«' + n + '» is a system program: it is not installed from here');
					if (act == 'install' && H[n]) return hierr('have', '«' + n + '» è già installato', '«' + n + '» is already installed');
					o[n] = !!H[n];
				}
				if (act == 'have') return { have: o };
				if (fk > 0 && fk < 1024) return hierr('space', 'spazio finito sul router: liberalo prima', 'no space left on the router: free some first');
				if (a.dry) return { ok: true, dry: true, names: P, free_mb: fk > 0 ? int(fk / 1024) : null };
				if (run || jobbusy()) return hierr('job', 'un altro lavoro è in corso (Software o Pacchetto Router): aspetta la fine', 'another job is running (Software or Router Package): wait for the end');
				return { ...job(pkgaddc(join(' ', P), has('/usr/bin/apk') || has('/sbin/apk'))), names: P };
			}
			if (act != 'start') return { error: 'azione non valida' };
			let K = '' + (a.kind ?? ''), N = '' + (a.name ?? ''), secs = hisecs(a.secs), oldver = '', to = '', say = '';
			if (K == 'wf') {
				to = '' + (rjs('/tmp/wf-upd.json')?.pkg?.v ?? '');
				if (!vnewer(to, cur)) return hierr('noupd', 'nessuna versione più nuova di WrtFreedom: controlla prima (updcheck)', 'no newer WrtFreedom version: check first (updcheck)');
				oldver = cur; N = 'wrtfreedom';
				say = L('Aggiorno WrtFreedom dalla ' + oldver + ' alla ' + to + ': prima copio le impostazioni e il pacchetto di adesso, poi installo. Se dopo il router non risponde o non confermi entro ' + secs + ' secondi rimetto la ' + oldver + '.',
					'I update WrtFreedom from ' + oldver + ' to ' + to + ': first I back up the settings and the current package, then I install. If the router does not answer afterwards or you do not confirm within ' + secs + ' seconds I put ' + oldver + ' back.');
			}
			else if (K == 'pkg') {
				if (!match(N, /^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$/)) return hierr('name', 'nome del pacchetto non valido', 'invalid package name');
				if (match(N, UPGNO)) return hierr('system', '«' + N + '» è un programma di sistema: non si aggiorna da qui', '«' + N + '» is a system program: it is not updated from here');
				let U = upgline(N);
				if (!U) return hierr('noup', '«' + N + '» non è nell\'elenco degli aggiornabili (pkgs up)', '«' + N + '» is not in the upgradable list (pkgs up)');
				oldver = U.from; to = U.to;
				say = L('Aggiorno il pacchetto «' + N + '» dalla ' + oldver + ' alla ' + to + ': prima copio le impostazioni. Se dopo il router non risponde o non confermi entro ' + secs + ' secondi rimetto le impostazioni di prima (il programma resta alla versione nuova).',
					'I update the «' + N + '» package from ' + oldver + ' to ' + to + ': first I back up the settings. If the router does not answer afterwards or you do not confirm within ' + secs + ' seconds I put the previous settings back (the program stays on the new version).');
			}
			else return hierr('kind', 'tipo non valido (wf, pkg)', 'invalid kind (wf, pkg)');
			if (a.dry) return { ok: true, dry: true, say: say, kind: K, name: N, from: oldver, to: to };
			if (run) return hierr('busy', 'aggiornamento già in corso', 'update already in progress');
			if (jobbusy()) return hierr('job', 'un altro lavoro è in corso (Software o Pacchetto Router): aspetta la fine', 'another job is running (Software or Router Package): wait for the end');
			for (let t in BAKTAGS) if (bakpend(t)) return { error: L('conferma prima la modifica in attesa', 'confirm the pending change first'), code: 'pend', pend: t };
			let F = UPGC + '/copia-prima-agg-' + (K == 'wf' ? 'wrtfreedom-' + oldver : replace(N, /[^A-Za-z0-9._-]/g, '')) + '-' + (function(t) { return sprintf('%04d%02d%02d-%02d%02d', t.year, t.mon, t.mday, t.hour, t.min); })(localtime()) + '.tar.gz';
			if (!upgjob(K, N, oldver, to, secs, F, UPGC + '/pacchetto-prima.tar.gz', L('↩️ Aggiornamento: nessuna conferma entro ' + secs + ' s, rimesso com\'era', '↩️ Update: no confirmation within ' + secs + ' s, restored')))
				return hierr('busy', 'aggiornamento già in corso', 'update already in progress');
			writefile(UPGF, sprintf('%J', { t: time(), st: 'copy', kind: K, name: N, from: oldver, to: to, copy: F, left: 0, msg: '' }));
			return { ok: true, started: true, kind: K, name: N, from: oldver, to: to, pend: secs, copy: F, say: say };
		}
	},
	homename: {
		/* Nomi Di Casa (2.64 B5): nomi che da casa portano a un indirizzo (sezioni domain di dhcp, come la pagina). get = {list
		   [{id, name, ip, ai}]}; add {name, mac} = nome verso l'indirizzo del dispositivo (sezione wf_hn_<chiave>); del {id} solo
		   quelle aggiunte da qui (wf_hn_*). Mai le righe address= di dnsmasq (Indirizzo Di Casa) */
		args: { action: 'action', name: 'name', mac: 'mac', id: 'id' },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), D = ucfile('dhcp'), Ls = [], rl = '( /etc/init.d/dnsmasq reload ) >/dev/null 2>&1 </dev/null &';
			for (let k in D) if (D[k]['.type'] == 'domain') push(Ls, { id: k, name: D[k].name ?? '', ip: D[k].ip ?? '', ai: match(k, /^wf_hn_[a-z0-9]{1,16}$/) != null });
			if (act == 'get') return { list: Ls };
			if (act != 'add' && act != 'del') return { error: 'azione non valida' };
			if (ucpend('dhcp')) return hierr('luci', 'ci sono modifiche non applicate (LuCI): applicale o annullale prima', 'there are unapplied changes (LuCI): apply or revert them first');
			if (act == 'del') {
				let id = '' + (a.id ?? '');
				if (!match(id, /^wf_hn_[a-z0-9]{1,16}$/) || D[id]?.['.type'] != 'domain') return hierr('id', 'nome non trovato tra quelli aggiunti da qui', 'name not found among those added here');
				sh('uci -q delete dhcp.' + id + '; uci commit dhcp; ' + rl);
				return { ok: true };
			}
			let n = lc(trim('' + (a.name ?? ''))), mac = lc('' + (a.mac ?? ''));
			if (!match(n, /^[a-z0-9]([a-z0-9.-]{0,62}[a-z0-9])?$/) || index(n, '..') >= 0) return hierr('name', 'nome non valido: lettere senza accenti, cifre, trattini e punti', 'invalid name: plain letters, digits, dashes and dots');
			if (!okmac(mac)) return hierr('mac', 'dispositivo non valido', 'invalid device');
			if (length(filter(Ls, (x) => lc(x.name) == n))) return hierr('used', 'c\'è già il nome di casa «' + n + '»', 'the home name «' + n + '» already exists');
			for (let k in D) if (D[k]['.type'] == 'dnsmasq') for (let x in vpnarr(D[k].address)) if (index(lc(x), '/' + n + '/') >= 0) return hierr('router', '«' + n + '» è un nome usato dal router', '«' + n + '» is a name used by the router');
			let ip = leases()[mac]?.ip ?? '';
			if (!match(ip, /^(10|192\.168|172\.(1[6-9]|2[0-9]|3[01]))\.[0-9.]+$/)) return hierr('noip', 'il dispositivo non ha un indirizzo di casa: deve essere collegato', 'the device has no home address: it must be connected');
			let id = 'wf_hn_' + wkey(8);
			sh('uci set dhcp.' + id + '=domain; ' + uset('dhcp', id, 'name', n) + uset('dhcp', id, 'ip', ip) + 'uci commit dhcp; ' + rl);
			return { ok: true, id: id, name: n, ip: ip };
		}
	},
	dnsforce: {
		/* DNS Obbligatorio (2.64 B5): inoltro dalla zona di casa vera che porta ogni richiesta DNS (porta 53) al router; sezione
		   dell'app (dnsfsec) o, se manca, wf_dnsforce. get = {on, have, pend}; set {on, secs}: acceso con la copia e il ritorno
		   dopo secs senza confirm (bakarm 'dnsf'), spento subito; confirm, back. fw4 check prima della ricarica */
		args: { action: 'action', on: true, secs: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get'), F = ucfile('firewall'), s = dnsfsec(F), cur = s != null && F[s].enabled != '0';
			if (act == 'confirm') return bakconfirm('dnsf');
			if (act == 'back') return bakback('dnsf', L('↩️ DNS Obbligatorio: rimesso com\'era', '↩️ Forced DNS: restored'));
			if (act == 'get') return { on: cur, have: s != null, pend: bakleft('dnsf') };
			if (act != 'set' || type(a.on) != 'bool') return { error: 'azione non valida' };
			let Z = fwzones(), on = a.on, id = s ?? DNSFID, A = 'firewall.' + id, secs = on ? hisecs(a.secs) : 0;
			if (cur == on) return { ok: true, same: true, on: on };
			if (Z.nohome) return hierr('zone', 'il firewall non ha la zona di casa', 'the firewall has no home zone');
			if (ucpend('firewall')) return hierr('luci', 'ci sono modifiche del firewall non applicate (LuCI): applicale o annullale prima', 'there are unapplied firewall changes (LuCI): apply or revert them first');
			writefile('/tmp/wf-dnsf.uci', s ? 'set ' + A + '.enabled=' + (on ? '1' : '0') + '\n' : 'set ' + A + '=redirect\nset ' + A + '.name=Forza-DNS-AdGuard\nset ' + A + '.src=' + q(Z.home) +
				'\nset ' + A + '.src_dport=53\nset ' + A + '.dest_port=53\nset ' + A + '.target=DNAT\nadd_list ' + A + '.proto=tcp\nadd_list ' + A + '.proto=udp\n');
			let o = sh('uci -q batch < /tmp/wf-dnsf.uci && { [ ! -x /sbin/fw4 ] || fw4 -q check >/dev/null 2>&1; } && echo __OK; rm -f /tmp/wf-dnsf.uci');
			if (trim(o) != '__OK') { sh('uci -q revert firewall'); return hierr('check', 'il firewall non accetta la regola: niente è cambiato', 'the firewall rejects the rule: nothing changed'); }
			if (secs) {
				let e = bakarm('dnsf', { firewall: s ? fwpart(id) : { n: id } }, [], 'fw4 -q reload || /etc/init.d/firewall reload', secs,
					L('↩️ DNS Obbligatorio: nessuna conferma entro ' + secs + ' s, rimesso com\'era', '↩️ Forced DNS: no confirmation within ' + secs + ' s, restored'));
				if (e !== true) { sh('uci -q revert firewall'); return e; }
			}
			sh('uci commit firewall; ( fw4 -q reload || /etc/init.d/firewall reload ) >/dev/null 2>&1 </dev/null &');
			return { ok: true, on: on, confirm: secs || null };
		}
	},
	adgups: {
		/* Server DNS di AdGuard con la copia e il ritorno (2.64 B5, Assistente IA): set {ups = server separati da spazio, secs} =
		   copia del file di AdGuard (bakarm 'adg'), poi dns_config; senza confirm entro secs back.sh rimette il file e riavvia
		   AdGuard. La prova del server nuovo la fa chi chiama (test_upstream_dns), prima. get = {pend}; confirm, back */
		args: { action: 'action', ups: 'ups', secs: 0 },
		call: function(req) {
			let a = req.args ?? {}, act = '' + (a.action ?? 'get');
			if (act == 'confirm') return bakconfirm('adg');
			if (act == 'back') return bakback('adg', L('↩️ Server DNS: rimessi com\'erano', '↩️ DNS servers: restored'));
			if (act == 'get') return { pend: bakleft('adg') };
			if (act != 'set') return { error: 'azione non valida' };
			let U = filter(split(trim('' + (a.ups ?? '')), /[ \n]+/), length), y = adgyaml(), secs = hisecs(a.secs);
			if (!length(U) || length(U) > 8 || length(filter(U, (u) => !match(u, /^[]A-Za-z0-9.:\/_[-]{1,200}$/)))) return hierr('ups', 'server DNS non validi', 'invalid DNS servers');
			if (!y || !adginst()) return hierr('adg', 'AdGuard Home non trovato', 'AdGuard Home not found');
			let e = bakarm('adg', [], [ y ], '/etc/init.d/' + (has('/etc/init.d/adguardhome') ? 'adguardhome' : 'AdGuardHome') + ' restart', secs,
				L('↩️ Server DNS: nessuna conferma entro ' + secs + ' s, rimessi com\'erano', '↩️ DNS servers: no confirmation within ' + secs + ' s, restored'));
			if (e !== true) return e;
			let r = adgreq('POST', 'dns_config', sprintf('%J', { upstream_dns: U }));
			if (r.code != 200) { sh('rm -rf ' + bakdir('adg')); return hierr('adg', 'AdGuard non ha accettato i server: niente è cambiato', 'AdGuard did not accept the servers: nothing changed'); }
			return { ok: true, confirm: secs };
		}
	},
};

return { 'wrtfreedom': methods };
