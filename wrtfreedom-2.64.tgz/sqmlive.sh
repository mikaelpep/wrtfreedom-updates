#!/bin/sh
# WrtFreedom: limiti attuali delle code CAKE di SQM (quelli che regola cake-autorate), una lettura al secondo (pacchetto
# 2.46). Lo avvia il metodo live quando l'app li chiede e si ferma da solo 15 s dopo l'ultima richiesta
# (/tmp/wf-sqmlive.want = secondi dall'accensione dell'ultima richiesta). Righe «secondi dispositivo banda»:
# /tmp/wf-sqmlive = ultima lettura, /tmp/wf-sqmlive.h = ultimi minuti (così il grafico dell'app parte già pieno)
P=/tmp/wf-sqmlive
echo $$ > $P.pid
trap 'rm -f $P.pid' EXIT
n=0
while :; do
	read u _ </proc/uptime; u=${u%.*}
	w=0; [ -f $P.want ] && read w <$P.want
	[ $((u - ${w:-0})) -lt 15 ] || break
	tc qdisc show 2>/dev/null | sed -n "s/^qdisc cake .* dev \([^ ]*\) .*bandwidth \([^ ]*\).*/$u \1 \2/p" > $P.n && mv $P.n $P
	while read l; do echo "$l"; done < $P >> $P.h
	n=$((n + 1)); [ $((n % 30)) = 0 ] && { tail -n 400 $P.h > $P.h.n; mv $P.h.n $P.h; }
	sleep 1
done
