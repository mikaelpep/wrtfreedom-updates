#!/usr/bin/ucode
'use strict';
/* WrtFreedom: bot Telegram (solo se "Rispondi Ai Comandi" è acceso nell'app).
   Comandi Pronti in tgpresets.sh (catalogo nelle righe "#@"), Comandi Utente nelle sezioni uci tgcmd.
   /menu = pulsanti per categoria; i comandi che chiedono un valore lo domandano con una risposta, quelli che possono
   interrompere la connessione chiedono conferma. Ogni comando gira in un processo a parte (tgbot.uc run …), così il bot
   continua a rispondere anche durante un test di velocità.
   uso: tgbot.uc            ciclo del bot (lo avvia il servizio wrtfreedom)
        tgbot.uc run <nome> [file con il valore] [chat]   esegue un comando e manda il risultato alla chat (di serie quella
                                                          collegata; un'altra solo se autorizzata per quel comando)
   Bot Per Più Persone (2.53): oltre alla chat collegata (tutto), le chat delle sezioni tgchat con role s (comandi
   sicuri: Comandi Pronti senza conferma, senza file e senza azioni) o t (tutto); role a = solo avvisi. Le chat
   sconosciute che scrivono al bot finiscono in /tmp/wf-tg.seen.json (ultime 10), da aggiungere dall'app.
   2.62: il token non va più sulla riga di comando (curl -K con l'indirizzo in un file della cartella 0700 /tmp/wf-tg.k);
   Anche Nel Bot: con l'Assistente IA acceso e «Anche Nel Bot» (wrtfreedom.ai.tg) i messaggi senza barra della chat
   collegata e delle chat con «tutto» vanno a wrtfreedom aiask {tg}; ai.uc risponde nella chat, i pulsanti ai:y:<id> /
   ai:n:<id> confermano o rifiutano la proposta (wrtfreedom aido {tg}); 2.64: ai:p:<testo> = scelta a pulsanti di un nome
   ambiguo, il testo va a aiask come una domanda */
import { popen, readfile, writefile, unlink, stat, mkdir } from 'fs';

const W = '/usr/share/wrtfreedom', P = W + '/tgpresets.sh', OFF = '/tmp/wf-tg.offset', PEND = '/tmp/wf-tg.pend', MENU = '/tmp/wf-tg.menu';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
/* identificativo casuale (senza il modulo math, che può mancare) */
function rid() { return substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time()), /[^0-9a-f]/g, ''), 0, 10); }
function ug(k) { return trim(sh('uci -q get ' + k)); }
/* più opzioni di wrtfreedom con una sola shell: K = [ 'tg.token', … ] → valori come ug() */
function ugs(K) {
	let c = '';
	for (let k in K) c += 'uci -q get wrtfreedom.' + k + '; echo @@WF@@; ';
	let o = split(sh(c), '@@WF@@\n'), r = [];
	for (let i = 0; i < length(K); i++) push(r, trim(o[i] ?? ''));
	return r;
}
/* permessi delle chat: { chat: a|s|t }, la chat collegata ha sempre tutto (sezioni «config tgchat» lette dal file) */
function roles(main) {
	let R = {}, cur = null;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { if (cur && cur.id) R[cur.id] = cur.role ?? 'a'; cur = match(l, /^config tgchat /) ? {} : null; continue; }
		let m = cur ? match(l, /^[[:blank:]]*option (id|role) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m) cur[m[1]] = m[2];
	}
	if (cur && cur.id) R[cur.id] = cur.role ?? 'a';
	for (let k in keys(R)) if (!match(k, /^-?[0-9]{1,20}$/) || !match(R[k], /^[ast]$/)) delete R[k];
	if (length(main)) R[main] = 't';
	return R;
}
/* versione della configurazione: file salvato e modifiche non ancora salvate di uci (/tmp/.uci) */
function cfgstamp() {
	let s = stat('/etc/config/wrtfreedom'), d = stat('/tmp/.uci/wrtfreedom');
	return { k: (s ? s.inode + ':' + s.mtime + ':' + s.size : '') + '|' + (d ? d.inode + ':' + d.mtime + ':' + d.size : ''),
		m: (s ? s.mtime : 0) > (d ? d.mtime : 0) ? s.mtime : (d ? d.mtime : 0) };
}
/* impostazioni del bot: rilette solo quando la configurazione cambia (prima: 4 "uci get" a ogni giro del ciclo).
   Una lettura vale solo se fatta in un secondo successivo all'ultima modifica (la data dei file ha i secondi) */
let CFG = null, CFGK = null, CFGT = 0;
function cfg() {
	let s = cfgstamp();
	if (CFG && CFGK == s.k && s.m < CFGT) return CFG;
	CFGT = time();
	let v = ugs([ 'tg.token', 'tg.chat', 'ui.lang', 'tg.cmd', 'tg.pset', 'tg.preset', 'ai.on', 'ai.tg' ]);
	CFG = { token: v[0], chat: v[1], en: v[2] == 'en', cmd: v[3], pset: v[4], preset: v[5], ai: v[6] == '1' && v[7] == '1', roles: roles(v[1]) }; CFGK = s.k;
	return CFG;
}
let EN = false;
function L(it, en) { return EN ? en : it; }

/* ---------- Telegram ---------- */
/* curl in una delle cartelle del PATH del servizio (come "command -v curl", senza avviare la shell) */
const CURL = length(filter([ '/usr/sbin/curl', '/usr/bin/curl', '/sbin/curl', '/bin/curl' ], (f) => stat(f) != null)) > 0;
function urlenc(s) {
	s = '' + s; let o = '';
	for (let i = 0; i < length(s); i++) {
		let c = ord(s, i);
		o += ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 46 || c == 95 || c == 126) ? chr(c) : sprintf('%%%02X', c);
	}
	return o;
}
let TOKEN = '', CHAT = '', ROLE = 't';
/* indirizzo con il token in un file per curl -K (cartella 0700): il token non compare mai tra i processi (2.62) */
const KD = '/tmp/wf-tg.k';
function kfile(url) {
	mkdir(KD, 448);
	let f = KD + '/' + rid();
	writefile(f, 'url = "' + replace(replace(url, '\\', () => '\\\\'), '"', () => '\\"') + '"\n');
	return f;
}
function api(method, params, wait) {
	let qs = [];
	for (let k in (params ?? {})) {
		let v = params[k];
		if (v == null) continue;
		push(qs, k + '=' + urlenc(type(v) in ['object', 'array'] ? sprintf('%J', v) : v));
	}
	let url = 'https://api.telegram.org/bot' + TOKEN + '/' + method + (length(qs) ? '?' + join('&', qs) : '');
	let m = wait ?? 20, o = '';
	/* senza curl niente chiamata (2.62): uclient-fetch vorrebbe il token sulla riga di comando */
	if (!CURL) return null;
	let f = kfile(url); o = sh('curl -s -m ' + m + ' -K ' + f + ' 2>/dev/null; rm -f ' + f); unlink(f);
	try { return json(o); } catch (e) { return null; }
}
function say(text, extra) {
	let p = { chat_id: CHAT, text: substr('' + text, 0, 3900) };
	for (let k in (extra ?? {})) p[k] = extra[k];
	return api('sendMessage', p);
}
/* ttl = secondi dopo i quali il messaggio si cancella da solo (2.48: password delle reti, come WireGuard nell'app) */
function sendfile(kind, file, caption, ttl) {
	if (!CURL) { unlink(file); return say(L('Per mandare file serve il pacchetto curl', 'Sending files needs the curl package')); }
	let f = kind == 'PHOTO' ? 'photo' : 'document';
	let kf = kfile('https://api.telegram.org/bot' + TOKEN + '/send' + (kind == 'PHOTO' ? 'Photo' : 'Document'));
	let o = sh('curl -s -m 120 -F chat_id=' + q(CHAT) + ' -F ' + q(f + '=@' + file) + ' -F ' + q('caption=' + substr(caption, 0, 1000)) + ' -K ' + kf + ' 2>/dev/null');
	unlink(kf);
	unlink(file);
	if (index(o, '"ok":true') < 0) return say(L('File non inviato', 'File not sent'));
	let mid = match(o, /"message_id":([0-9]{1,20})/);
	if (ttl > 0 && mid) {
		let df = kfile('https://api.telegram.org/bot' + TOKEN + '/deleteMessage');
		sh('( sleep ' + int(ttl) + '; curl -s -m 30 -d chat_id=' + q(CHAT) + ' -d message_id=' + mid[1] + ' -K ' + df + '; rm -f ' + df + ' ) >/dev/null 2>&1 </dev/null &');
	}
}

/* ---------- catalogo ---------- */
/* catalogo dei Comandi Pronti: riletto solo quando tgpresets.sh cambia (aggiornamento del pacchetto) */
let CAT = null, CATM = null;
function catalog() {
	let st = stat(P), m = st ? st.mtime : 0;
	if (CAT && CATM == m) return CAT;
	let cats = [], cmds = [];
	for (let l in split(readfile(P) ?? '', '\n')) {
		if (substr(l, 0, 3) == '#% ') { let f = split(substr(l, 3), '|'); push(cats, { id: f[0], it: f[1], en: f[2], icon: f[3] }); }
		else if (substr(l, 0, 3) == '#@ ') {
			let f = split(substr(l, 3), '|');
			push(cmds, { n: f[0], en: f[1], cat: f[2], fl: f[3], need: filter(split(f[4], ','), length), it: f[5], den: f[6], ait: f[7], aen: f[8], pre: true });
		}
		else if (length(cmds) && substr(l, 0, 1) != '#') break;
	}
	push(cats, { id: 'altro', it: 'Altri', en: 'Other', icon: '🧩' });
	CAT = { cats, cmds }; CATM = m;
	return CAT;
}
function has(c, x) { return index(c.fl ?? '', x) >= 0; }
/* comandi sicuri (role s, 2.53): solo questa LISTA CONSENTITA di Comandi Pronti (stato, consumo, ospiti, pausa…); mai file,
   SMS, IMEI, SIM, cella, indirizzi, registri, Pianificazioni, test di velocità o dati di altri dispositivi */
const SAFE = [ 'stato', 'uptime', 'carico', 'memoria', 'temperatura', 'versione', 'consumo', 'ora', 'linea', 'segnale', 'sqm',
	'wifi', 'ospiti', 'ospiti_on', 'ospiti_off', 'adguard', 'pausa', 'vpn', 'latenza' ];
function allowed(c, role) {
	role = role ?? ROLE;
	return role == 't' || has(c, 'l') || (role == 's' && c.pre && !has(c, 'f') && index(SAFE, c.n) >= 0);
}
function installed(cmds) {
	let K = cfg(), set = {}, saved = K.pset == '1';
	for (let n in split(K.preset, ' ')) if (length(n)) set[n] = true;
	let out = [];
	for (let c in cmds) if (has(c, 'l') || (saved ? set[c.n] : has(c, 'd'))) push(out, c);
	return out;
}
/* Comandi Utente: un solo `uci show`, ripetuto solo quando la configurazione cambia */
let CUS = null, CUSM = null;
function custom() {
	let st = stat('/etc/config/wrtfreedom'), cm = st ? st.mtime + ':' + st.size : '';
	if (CUS && CUSM == cm) return CUS;
	let S = {}, order = [];
	for (let l in split(sh('uci -q show wrtfreedom'), '\n')) {
		let m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)=tgcmd$/);
		if (m) { if (!S[m[1]]) push(order, m[1]); S[m[1]] = S[m[1]] ?? {}; continue; }
		m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)\.([a-z]+)='(.*)'$/);
		if (m) { S[m[1]] = S[m[1]] ?? {}; S[m[1]][m[2]] = replace(m[3], "'\\''", "'"); }
	}
	let out = [];
	for (let s in order) {
		let g = S[s];
		if (g.enabled == '0' || !length(g.name ?? '')) continue;
		let fl = (g.confirm == '1' ? 'c' : '') + (g.askmode == 'req' ? 'a' : g.askmode == 'opt' ? 'o' : '');
		push(out, { n: g.name, en: g.name, cat: g.cat || 'altro', fl: fl, need: [], it: g.desc ?? '', den: g.desc ?? '', ait: g.ask ?? '', aen: g.ask ?? '', cmd: s, user: true });
	}
	CUS = out; CUSM = cm;
	return out;
}
/* tutti i comandi attivi, in ordine di categoria */
function active() {
	/* un Comando Utente con lo stesso nome di un Comando Pronto prende il suo posto */
	let C = catalog(), U = custom(), taken = {};
	for (let c in U) taken[c.n] = true;
	let A = [...filter(installed(C.cmds), (c) => has(c, 'l') || !(taken[c.n] || taken[c.en])), ...U], out = [];
	for (let k in C.cats) for (let c in A) if (c.cat == k.id) push(out, c);
	return { cats: C.cats, list: out };
}
function nm(c) { return EN ? c.en : c.n; }
function desc(c) { return substr(EN ? c.den : c.it, 0, 100); }
function find(list, w) {
	w = lc(w);
	if (w == 'start') w = 'aiuto';
	for (let c in list) if (c.n == w || c.en == w) return c;
	return null;
}

/* menu "/" di Telegram: al massimo 100 comandi (gli altri funzionano lo stesso e sono in /menu) */
function setmenu() {
	let A = active(), cmds = [];
	for (let c in A.list) if (has(c, 'l')) push(cmds, { command: nm(c), description: desc(c) || nm(c) });
	for (let c in A.list) if (!has(c, 'l') && length(cmds) < 100 && match(nm(c), /^[a-z0-9_]{1,32}$/)) push(cmds, { command: nm(c), description: desc(c) || nm(c) });
	api('setMyCommands', { commands: cmds });
}

/* ---------- pulsanti ---------- */
function kbcats() {
	let A = active(), rows = [], row = [];
	for (let k in A.cats) {
		let n = length(filter(A.list, (c) => c.cat == k.id && !has(c, 'l') && allowed(c)));
		if (!n) continue;
		push(row, { text: k.icon + ' ' + (EN ? k.en : k.it), callback_data: 'c:' + k.id });
		if (length(row) == 2) { push(rows, row); row = []; }
	}
	if (length(row)) push(rows, row);
	return { inline_keyboard: rows };
}
function kbcat(id) {
	let A = active(), rows = [], row = [];
	for (let c in A.list) {
		if (c.cat != id || has(c, 'l') || !allowed(c)) continue;
		push(row, { text: '/' + nm(c), callback_data: 'r:' + c.n });
		if (length(row) == 2) { push(rows, row); row = []; }
	}
	if (length(row)) push(rows, row);
	push(rows, [{ text: L('⬅️ Categorie', '⬅️ Categories'), callback_data: 'm' }]);
	return { inline_keyboard: rows };
}
function catname(id) {
	for (let k in catalog().cats) if (k.id == id) return k.icon + ' ' + (EN ? k.en : k.it);
	return id;
}
function helptext() {
	let A = active(), o = L('Comandi disponibili:', 'Available commands:'), last = '';
	for (let c in A.list) {
		if (!allowed(c)) continue;
		if (c.cat != last) { o += '\n\n' + catname(c.cat); last = c.cat; }
		o += '\n/' + nm(c) + ' - ' + desc(c);
	}
	return o + '\n\n' + L('/menu mostra i pulsanti per categoria', '/menu shows buttons by category');
}

/* ---------- esecuzione ---------- */
function spawn(c, arg) {
	let f = '/tmp/wf-tg.arg.' + rid();
	writefile(f, '' + (arg ?? ''));
	sh('( ucode ' + W + '/tgbot.uc run ' + q(c.n) + ' ' + f + ' ' + q(CHAT) + ' ) >/dev/null 2>&1 </dev/null &');
}
function pend_get() { try { return json(readfile(PEND) ?? '{}') ?? {}; } catch (e) { return {}; } }
/* un comando richiesto (scritto, da pulsante o in risposta a una domanda) */
function request(c, arg, confirmed) {
	if (c.n == 'menu') return say(L('Scegli una categoria', 'Choose a category'), { reply_markup: kbcats() });
	if (c.n == 'aiuto') return say(helptext());
	if (!allowed(c)) return say(L('⛔ Comando non permesso per questa chat', '⛔ Command not allowed for this chat'));
	arg = trim('' + (arg ?? ''));
	if (has(c, 'a') && !length(arg))
		return say('✍️ /' + nm(c) + '\n' + (EN ? c.aen : c.ait), { reply_markup: { force_reply: true, input_field_placeholder: substr(EN ? c.aen : c.ait, 0, 60) } });
	if (has(c, 'c') && !confirmed) {
		let P = pend_get(), id = rid(), now = time();
		for (let k in keys(P)) if (now - P[k].t > 600) delete P[k];
		P[id] = { n: c.n, arg: arg, t: now, chat: CHAT };
		writefile(PEND, sprintf('%J', P));
		return say(L('Confermi', 'Confirm') + ' /' + nm(c) + (length(arg) ? ' ' + arg : '') + '?\n' + desc(c), { reply_markup: { inline_keyboard: [[{ text: L('✅ Sì', '✅ Yes'), callback_data: 'y:' + id }, { text: L('✖️ No', '✖️ No'), callback_data: 'n' }]] } });
	}
	spawn(c, arg);
}
/* "/wifi off" e simili: stesso comando delle versioni precedenti */
function alias(w, arg) {
	let a = lc(trim(arg ?? ''));
	if (!(a in ['on', 'off', 'si', 'sì', 'yes'])) return null;
	let m = { wifi: 'wifi_', vpn: 'vpn_', adguard: 'adg_', ospiti: 'ospiti_', guest: 'ospiti_' }[lc(w)];
	if (m && a in ['on', 'off']) return m + a;
	if (lc(w) in ['riavvia', 'reboot'] && a in ['si', 'sì', 'yes']) return 'riavvia!';
	return null;
}
/* Anche Nel Bot (2.62): metodo del Pacchetto Router (da qui, mai da rpcd stesso) */
function wf(m, a) { let o = sh('ubus -t 20 call wrtfreedom ' + m + ' ' + q(sprintf('%J', a)) + ' 2>/dev/null'); try { return length(o) ? json(o) : null; } catch (e) { return null; } }
function aiask(tx) {
	let r = wf('aiask', { text: substr(tx, 0, 2000), tg: CHAT });
	if (!r || r.error) return say('⚠️ ' + (r?.error ?? L('Il router non ha risposto: riprova', 'The router did not answer: try again')));
	api('sendChatAction', { chat_id: CHAT, action: 'typing' });
}
function onmessage(msg) {
	let tx = trim(msg.text ?? '');
	/* risposta a una domanda del bot ("✍️ /comando") */
	let rq = msg.reply_to_message && msg.reply_to_message.text;
	const ASK = '✍️ /';
	if (rq && index(rq, ASK) == 0 && substr(tx, 0, 1) != '/') {
		let w = split(substr(split(rq, '\n')[0], length(ASK)), ' ')[0], c = find(active().list, w);
		if (c) return request(c, tx);
	}
	/* senza barra: all'Assistente IA (2.62) solo con «Anche Nel Bot» acceso e per chi ha «tutto» */
	if (substr(tx, 0, 1) != '/') return length(tx) && ROLE == 't' && cfg().ai ? aiask(tx) : null;
	let m = match(tx, /^\/([A-Za-z0-9_]+)(@[A-Za-z0-9_]+)?[ \n]*(.*)$/s);
	if (!m) return;
	let w = m[1], arg = m[3] ?? '', list = active().list, al = alias(w, arg);
	if (al == 'riavvia!') { let c = find(list, 'riavvia'); if (c) return request(c, '', true); }
	if (al) { let c = find(list, al); if (c) return request(c, ''); w = al; }
	let c = al ? null : find(list, w);
	if (c) return request(c, arg);
	/* comando che esiste ma non è installato */
	for (let x in catalog().cmds) if (x.n == lc(w) || x.en == lc(w))
		return say(L('Il comando /' + w + ' non è installato: attivalo nell\'app in Bot Telegram › Comandi Pronti', 'The /' + w + ' command is not installed: turn it on in the app under Telegram Bot › Ready Commands'));
	say(L('Comando non riconosciuto: /' + w + ' · scrivi /aiuto o /menu', 'Unknown command: /' + w + ' · type /help or /menu'));
}
function oncallback(cb) {
	let d = cb.data ?? '', mid = cb.message.message_id;
	api('answerCallbackQuery', { callback_query_id: cb.id });
	if (d == 'm') return api('editMessageText', { chat_id: CHAT, message_id: mid, text: L('Scegli una categoria', 'Choose a category'), reply_markup: kbcats() });
	if (substr(d, 0, 2) == 'c:') return api('editMessageText', { chat_id: CHAT, message_id: mid, text: catname(substr(d, 2)), reply_markup: kbcat(substr(d, 2)) });
	if (substr(d, 0, 2) == 'r:') { let c = find(active().list, substr(d, 2)); return c ? request(c, '') : null; }
	if (d == 'n') return api('editMessageText', { chat_id: CHAT, message_id: mid, text: L('✖️ Annullato', '✖️ Cancelled') });
	/* proposta dell'Assistente IA (2.62): la frase resta, sotto l'esito del tocco; il risultato lo manda ai.uc */
	if (match(d, /^ai:[yn]:[0-9a-f]{8}$/)) {
		let y = substr(d, 3, 1) == 'y', r = ROLE == 't' ? wf('aido', { id: substr(d, 5), yes: y, tg: CHAT }) : { error: L('Comando non permesso per questa chat', 'Command not allowed for this chat') };
		let res = !r ? '⚠️ ' + L('Il router non ha risposto', 'The router did not answer') : r.error ? '⚠️ ' + r.error : y ? '▶️ ' + L('Confermato', 'Confirmed') : '✖️ ' + L('Annullato', 'Cancelled');
		return api('editMessageText', { chat_id: CHAT, message_id: mid, text: substr((cb.message.text ?? '') + '\n\n' + res, 0, 3900) });
	}
	/* scelta a pulsanti dell'Assistente IA (2.64, nome ambiguo): il testo del pulsante va all'IA come domanda, come nell'app */
	if (substr(d, 0, 5) == 'ai:p:' && length(d) > 5) {
		if (ROLE != 't' || !cfg().ai) return say('⚠️ ' + L('Comando non permesso per questa chat', 'Command not allowed for this chat'));
		api('editMessageText', { chat_id: CHAT, message_id: mid, text: substr((cb.message.text ?? '') + '\n\n▶️ ' + substr(d, 5), 0, 3900) });
		return aiask(substr(d, 5));
	}
	/* nuovo dispositivo (2.49): dk = Lo Conosco, db = Blocca; MAC di 12 cifre esadecimali controllato prima dell'uso */
	if (match(d, /^d[kb]:[0-9a-f]{12}$/) && ROLE == 't') {
		let h = substr(d, 3), mac = join(':', map([0, 2, 4, 6, 8, 10], (i) => substr(h, i, 2))), k = substr(d, 1, 1) == 'k', r = null;
		try { r = json(sh('ubus call wrtfreedom quick ' + q(sprintf('%J', { act: k ? 'known' : 'block', mac: mac })) + ' 2>/dev/null') || 'null'); } catch (e) {}
		let res = r?.ok ? (k ? L('✅ Segnato come conosciuto', '✅ Marked as known') : L('⛔ Internet bloccato: lo sblocchi dall\'app', '⛔ Internet blocked: unblock it from the app')) : L('⚠️ Non riuscito', '⚠️ Failed');
		return api('editMessageText', { chat_id: CHAT, message_id: mid, text: substr((cb.message.text ?? '') + '\n\n' + res, 0, 3900) });
	}
	if (substr(d, 0, 2) == 'y:') {
		let P = pend_get(), p = P[substr(d, 2)];
		let c = p ? find(active().list, p.n) : null;
		/* conferma: chat con «tutto» o, per le chat con i comandi sicuri, solo un comando della lista consentita */
		if (!p || time() - p.t > 600 || (ROLE != 't' && !(c && allowed(c))) || (p.chat != null && p.chat != CHAT)) return api('editMessageText', { chat_id: CHAT, message_id: mid, text: L('Richiesta scaduta: ripeti il comando', 'Request expired: repeat the command') });
		delete P[substr(d, 2)]; writefile(PEND, sprintf('%J', P));
		api('editMessageText', { chat_id: CHAT, message_id: mid, text: '▶️ /' + (c ? nm(c) : p.n) + (length(p.arg) ? ' ' + p.arg : '') });
		if (c) spawn(c, p.arg);
		else say(L('Il comando non è più installato', 'The command is no longer installed'));
	}
}

/* chat sconosciuta che scrive al bot: annotata (ultime 10) per «Aggiungi» nell'app, mai una risposta */
function seen(ch) {
	let F = '/tmp/wf-tg.seen.json', S = [];
	try { S = json(readfile(F) ?? '[]') ?? []; } catch (e) {}
	S = filter(S, (x) => '' + x.id != '' + ch.id);
	push(S, { id: '' + ch.id, name: substr(ch.title ?? trim((ch.first_name ?? '') + ' ' + (ch.last_name ?? '')), 0, 40), t: time() });
	writefile(F, sprintf('%J', slice(S, length(S) > 10 ? length(S) - 10 : 0)));
}

/* ---------- avvio ---------- */
if (ARGV[0] == 'run') {
	/* esegue un comando e manda il risultato (anche dal pulsante "Prova" dell'app) */
	let K = ugs([ 'ui.lang', 'tg.token', 'tg.chat' ]);
	EN = K[0] == 'en'; TOKEN = K[1]; CHAT = K[2];
	if (!length(TOKEN) || !length(CHAT)) exit(1);
	let n = '' + ARGV[1], af = ARGV[2], arg = af ? (readfile(af) ?? '') : '';
	if (af && match(af, /^\/tmp\/wf-tg\.arg\./)) unlink(af);
	let C = catalog(), c = null;
	for (let x in [...custom(), ...C.cmds]) if (x.n == n) { c = x; break; }
	if (!c) exit(1);
	/* un'altra chat (2.53): solo se autorizzata per questo comando */
	let to = '' + (ARGV[3] ?? '');
	if (length(to) && to != CHAT) { let r = roles(CHAT)[to]; if (!r || r == 'a' || !allowed(c, r)) exit(1); CHAT = to; ROLE = r; }
	if (c.n == 'menu' || c.n == 'aiuto') { request(c, ''); exit(0); }
	api('sendChatAction', { chat_id: CHAT, action: has(c, 'f') ? 'upload_photo' : 'typing' });
	let env = 'ARG=' + q(arg) + ' ';
	let out = c.pre ? sh(env + 'sh ' + P + ' ' + q(c.n) + ' 2>&1') : sh(env + 'sh -c ' + q(ug('wrtfreedom.' + c.cmd + '.cmd')) + ' 2>&1');
	out = trim(out);
	/* prima riga «@@PHOTO <file>» o «@@DOC <file> [ttl=<secondi>]» */
	let fm = match(out, /^@@(PHOTO|DOC) (\/tmp\/[^\n ]+)( ttl=([0-9]{1,5}))?\n?(.*)$/s);
	if (fm) { sendfile(fm[1], fm[2], fm[5] ?? '', +(fm[4] ?? 0)); exit(0); }
	if (!length(out)) out = '✅ ' + L('Fatto', 'Done');
	/* messaggi lunghi in più parti (al massimo 3) */
	for (let i = 0; i < length(out) && i < 3 * 3800; i += 3800) say(substr(out, i, 3800));
	exit(0);
}

let last = '';
while (true) {
	let K = cfg();
	TOKEN = K.token; CHAT = K.chat; EN = K.en;
	if (K.cmd != '1' || !length(TOKEN) || !length(CHAT)) { sh('sleep 30'); last = ''; continue; }
	/* menu di Telegram: al cambio di bot o lingua, o quando l'app cambia i comandi */
	if (last != TOKEN + EN || stat(MENU)) { unlink(MENU); setmenu(); last = TOKEN + EN; }
	let off = +(trim(readfile(OFF) ?? '0')) || 0;
	let r = api('getUpdates', { timeout: 25, offset: off, allowed_updates: ['message', 'callback_query'] }, 40);
	if (!r || !r.ok) { sh('sleep 15'); continue; }
	for (let u in r.result) {
		writefile(OFF, '' + (u.update_id + 1));
		try {
			/* risponde alla chat collegata e alle chat autorizzate (2.53); le altre si annotano per l'app */
			let m = u.message ?? u.callback_query?.message, id = m ? '' + m.chat.id : '', rl = K.roles[id];
			if (m && !rl) seen(m.chat);
			else if (m) {
				CHAT = id; ROLE = rl;
				if (rl == 'a') { if (u.message && substr(trim(u.message.text ?? ''), 0, 1) == '/') say(L('Questa chat riceve solo gli avvisi', 'This chat only receives alerts')); }
				else if (u.message) onmessage(u.message);
				else oncallback(u.callback_query);
			}
		}
		catch (e) { warn('tgbot: ' + e + '\n'); }
		CHAT = K.chat; ROLE = 't';
	}
}
