'use strict';
/* WrtFreedom: modem universale.
   Riconosce il modem (ModemManager e comando ATI) e sceglie la strada giusta per ogni cosa:
   - bande e modalità: ModemManager (qualsiasi marca che lui sa gestire); se non può, i comandi AT della marca;
   - cella attuale e celle vicine: ModemManager (--get-cell-info) o i comandi AT della marca;
   - blocco cella: i comandi AT della marca (ModemManager non lo fa).
   Si carica con loadfile() da wrtfreedom.uc e da modemctl.uc e restituisce l'oggetto con le funzioni. */
import { popen, readfile, writefile, unlink, stat, lsdir } from 'fs';

const AT = '/usr/share/wrtfreedom/at.sh', ID = '/tmp/wf-modem.id', CMDLOG = '/tmp/wf-modem.cmd';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function cmdlog(c, o) {
	/* ultimi comandi mandati al modem, per il Rapporto Modem */
	let L = split(readfile(CMDLOG) ?? '', '\n'), d = localtime(), t = sprintf('%02d/%02d %02d:%02d:%02d', d.mday, d.mon, d.hour, d.min, d.sec);
	push(L, t + ' > ' + c, t + ' < ' + replace(trim('' + o), /\s*\n\s*/g, ' | '));
	if (length(L) > 80) L = slice(L, length(L) - 80);
	writefile(CMDLOG, join('\n', filter(L, length)) + '\n');
}
function at(c) { let o = sh('sh ' + AT + ' ' + q(c) + ' 2>&1'); cmdlog(c, o); return o; }
function atok(o) { return index(o, 'OK') >= 0 && index(o, 'ERROR') < 0; }
function mmcli(args) { return sh('mmcli -m any ' + args + ' 2>&1'); }
function mmjs(args) { let o = mmcli(args + ' -J'); try { return json(o); } catch (e) { return null; } }
function fields(l) { return map(split(replace(trim(l), /^[+$#!^][A-Za-z0-9_]+: */, ''), ','), (x) => trim(x, ' "')); }
function uniq(a) { let s = {}, r = []; for (let x in a) { x = '' + x; if (length(x) && !s[x]) { s[x] = 1; push(r, x); } } return sort(r, (a, b) => +a - +b); }

/* ---------------- bande da canale (per i modem che danno solo EARFCN / NR-ARFCN) ---------------- */
const LTEB = [ [0,599,1],[600,1199,2],[1200,1949,3],[1950,2399,4],[2400,2649,5],[2750,3449,7],[3450,3799,8],[3800,4149,9],[4150,4749,10],
	[5010,5179,12],[5180,5279,13],[5280,5379,14],[5730,5849,17],[5850,5999,18],[6000,6149,19],[6150,6449,20],[6450,6599,21],[8040,8689,25],
	[8690,9039,26],[9040,9209,27],[9210,9659,28],[9660,9769,29],[9770,9869,30],[9870,9919,32],[36000,36199,33],[36200,36349,34],[37750,38249,38],
	[38250,38649,39],[38650,39649,40],[39650,41589,41],[41590,43589,42],[43590,45589,43],[46790,54539,46],[55240,56739,48],[65536,66435,65],
	[66436,67335,66],[67336,67535,67],[68586,68935,71] ];
const NRB = [ [422000,434000,1],[386000,398000,2],[361000,376000,3],[173800,178800,5],[524000,538000,7],[185000,192000,8],[145800,149200,12],
	[158200,164200,20],[151600,160600,28],[386000,399000,25],[514000,524000,38],[376000,384000,39],[460000,480000,40],[499200,537999,41],
	[636667,646666,48],[422000,440000,66],[123400,130400,71],[286400,303400,75],[620000,653333,78],[620000,680000,77],[693334,733333,79] ];
function bandof(T, n, prefer) {
	n = +n; let found = [];
	for (let r in T) if (n >= r[0] && n <= r[1]) push(found, '' + r[2]);
	for (let b in found) if (prefer && index(prefer, b) >= 0) return b;
	return found[0] ?? '';
}

/* ---------------- riconoscimento ---------------- */
function vendorOf(s) {
	s = lc(s ?? '');
	for (let v in [ 'quectel', 'fibocom', 'sierra', 'telit', 'simcom', 'huawei', 'zte' ]) if (index(s, v) >= 0) return v;
	if (index(s, 'simtech') >= 0) return 'simcom';
	if (match(s, /\bdw58[0-9]{2}/)) return 'sierra';
	if (match(s, /\b(rm5\d\d|rm2\d\d|em0[56]|ep06|eg[0-9]{2}|ec2[0-9]|bg9[0-9])/)) return 'quectel';
	if (match(s, /\b(fm1[0-9]{2}|fm350|l8[56]0|nl668)/)) return 'fibocom';
	if (match(s, /\b(em7[0-9]{3}|em9[0-9]{3}|mc7[0-9]{3})/)) return 'sierra';
	if (match(s, /\b(fn9[0-9]{2}|ln9[0-9]{2}|lm9[0-9]{2}|le910)/)) return 'telit';
	if (match(s, /\b(sim7[0-9]{3}|sim8[0-9]{3}|a7[0-9]{3})/)) return 'simcom';
	return '';
}
function present() {
	for (let d in (lsdir('/dev') ?? [])) if (match(d, /^(cdc-wdm|wwan|ttyUSB|ttyACM|mhi_)/)) return true;
	return false;
}

/* modem: chi è e cosa sa fare. Letto dal file di ModemManager (/tmp/wf-modem.mm, riempito in sottofondo) e,
   solo se serve, con ATI; il risultato resta in /tmp/wf-modem.id per 10 minuti */
function id(fresh) {
	let st = stat(ID);
	if (!fresh && st && time() - st.mtime < 600) { let c = json(readfile(ID) ?? 'null'); if (c && (c.mm || c.vendor)) return c; }
	let mmj = json(readfile('/tmp/wf-modem.mm') ?? 'null'), g = mmj?.modem?.generic ?? {};
	let r = { mm: !!(mmj && g.model), mfr: g.manufacturer ?? '', model: g.model ?? '', rev: g.revision ?? '', plugin: g.plugin ?? '',
		drivers: g.drivers ?? [], mmver: '', vendor: '' };
	r.vendor = vendorOf(r.mfr + ' ' + r.model + ' ' + r.plugin);
	if (!r.vendor) {
		/* risposta di ATI letta in sottofondo (mai qui: rpcd resterebbe fermo ad aspettare il modem) */
		let o = readfile('/tmp/wf-modem.ati') ?? '';
		if (atok(o)) {
			let L = filter(map(split(o, '\n'), trim), (x) => length(x) && x != 'OK' && x != 'ATI');
			r.vendor = vendorOf(join(' ', L));
			if (!r.model && length(L) > 1) { r.mfr = L[0]; r.model = L[1]; }
		}
	}
	/* versione di ModemManager: serve solo con il modem visto da ModemManager (readcmd) e nel Rapporto (id(true));
	   negli altri casi niente processo (mmver resta vuoto) */
	if (r.mm || fresh) {
		let v = match(sh('mmcli --version 2>/dev/null'), /([0-9]+\.[0-9]+(\.[0-9]+)?)/);
		r.mmver = v ? v[1] : '';
	}
	r.qmi = length(filter(r.drivers, (d) => match(d, /qmi|mhi/))) > 0;
	r.mbim = length(filter(r.drivers, (d) => match(d, /mbim/))) > 0;
	r.present = r.mm || present();
	writefile(ID, sprintf('%J', r));
	return r;
}
function mmge(ver, want) {
	let a = split(ver ?? '', '.'), b = split(want, '.');
	for (let i = 0; i < 3; i++) { let x = +(a[i] ?? 0), y = +(b[i] ?? 0); if (x != y) return x > y; }
	return true;
}

/* ---------------- moduli per marca (comandi AT dai manuali ufficiali) ----------------
   read: comandi letti in sottofondo con la cella attuale; parse(o): {lte, nr, nb} dalla risposta;
   lock(L, N): comandi per bloccare (L = "earfcn,pci", N = "pci,arfcn,scs,band"); unlock(): comandi;
   lockq / lockparse(o): stato del blocco; bands*: bande con i comandi AT quando ModemManager non può. */
const DRV = {};
DRV.quectel = {
	name: 'Quectel',
	read: [ 'AT+QENG="servingcell"', 'AT+QCAINFO', 'AT+QTEMP' ],
	neigh: [ 'AT+QENG="neighbourcell"' ],
	parse: function(o) {
		let S = { nb: [] }, seen = {};
		for (let l in split(o, '\n')) {
			l = trim(l); let f = fields(l);
			if (index(l, '+QENG:') == 0 && index(l, 'neighbourcell') < 0) {
				let i = index(f, 'LTE');
				if (i >= 0 && length(f) > i + 14) S.lte = { pci: f[i + 5], earfcn: f[i + 6], band: f[i + 7], tac: f[i + 10], rsrp: +f[i + 11], rsrq: +f[i + 12], sinr: +f[i + 14], cid: f[i + 4] };
				i = index(f, 'NR5G-NSA');
				if (i >= 0 && length(f) > i + 8) S.nr = { pci: f[i + 3], rsrp: +f[i + 4], sinr: +f[i + 5], rsrq: +f[i + 6], arfcn: f[i + 7], band: f[i + 8], scs: f[i + 10] ?? '' };
				i = index(f, 'NR5G-SA');
				if (i >= 0 && length(f) > i + 12) S.nr = { pci: f[i + 5], tac: f[i + 6], arfcn: f[i + 7], band: f[i + 8], rsrp: +f[i + 10], rsrq: +f[i + 11], sinr: +f[i + 12], sa: true };
			}
			else if (index(l, '+QENG:') == 0 && f[1] == 'LTE' && length(f) > 5) {
				let k = f[2] + ',' + f[3];
				if (!seen[k]) { seen[k] = 1; push(S.nb, { earfcn: f[2], pci: f[3], rsrp: +f[5], band: bandof(LTEB, f[2]), t: index(f[0], 'intra') >= 0 ? 'intra' : 'inter' }); }
			}
		}
		return S;
	},
	lockq: [ 'AT+QNWLOCK="common/4g"', 'AT+QNWLOCK="common/5g"' ],
	lockparse: function(o) {
		let r = { lte: 'none', nr: 'none' };
		for (let l in split(o, '\n')) {
			let f = fields(l);
			if (index(l, '+QNWLOCK:') < 0) continue;
			if (f[0] == 'common/4g') r.lte = (f[1] && f[1] != '0' && length(f) > 3) ? f[2] + ',' + f[3] : 'none';
			if (f[0] == 'common/5g') r.nr = (f[1] && f[1] != '0' && length(f) > 4) ? join(',', slice(f, 1, 5)) : 'none';
		}
		return r;
	},
	/* L = {earfcn, pci, band}, N = {pci, arfcn, scs, band} oppure null */
	lock: function(L, N) { return [ 'AT+QNWLOCK="common/4g",1,' + L.earfcn + ',' + L.pci, N ? 'AT+QNWLOCK="common/5g",' + join(',', [ N.pci, N.arfcn, N.scs, N.band ]) : 'AT+QNWLOCK="common/5g",0' ]; },
	unlock: function() { return [ 'AT+QNWLOCK="common/4g",0', 'AT+QNWLOCK="common/5g",0' ]; },
	nrscs: true,
	/* bande con i comandi AT */
	bandsread: function() {
		let o = at('AT+QNWPREFCFG="policy_band"'), c = at('AT+QNWPREFCFG="lte_band";+QNWPREFCFG="nsa_nr5g_band";+QNWPREFCFG="mode_pref"');
		let g = (s, k) => { let m = match(s, regexp('"' + k + '",([0-9:]+)')); return m ? split(m[1], ':') : null; };
		let mp = match(c, /"mode_pref",([A-Z0-9:]+)/i);
		if (!g(c, 'lte_band')) return null;
		return { sup: { lte: g(o, 'lte_band') ?? [], nr: g(o, 'nsa_nr5g_band') ?? g(o, 'nr5g_band') ?? [] },
			cur: { lte: g(c, 'lte_band') ?? [], nr: g(c, 'nsa_nr5g_band') ?? [] },
			mode: mp ? (uc(mp[1]) == 'LTE' ? 'lte' : 'nr') : '' };
	},
	bandsset: function(L, N, mode) {
		let c = [ 'AT+QNWPREFCFG="lte_band",' + join(':', L) ];
		if (length(N) && mode != 'lte') {
			push(c, 'AT+QNWPREFCFG="nsa_nr5g_band",' + join(':', N), 'AT+QNWPREFCFG="nr5g_band",' + join(':', N));
			push(c, 'AT+QNWPREFCFG="mode_pref",LTE:NR5G', 'AT+QNWPREFCFG="nr5g_disable_mode",1');
		}
		else push(c, 'AT+QNWPREFCFG="mode_pref",LTE');
		return c;
	},
	nrbandsset: function(N) { return length(N) ? [ 'AT+QNWPREFCFG="nsa_nr5g_band",' + join(':', N), 'AT+QNWPREFCFG="nr5g_band",' + join(':', N) ] : []; },
	/* segnale per antenna (2.47, Trova Il Punto Migliore): «+QRSRP: <PRX>,<DRX>,<RX2>,<RX3>,<sysmode>», una riga per LTE e
	   una per NR5G; -32768 o -140 = antenna non usata */
	ant: 'AT+QRSRP',
	antparse: function(o) {
		let r = {};
		for (let l in split(o, '\n')) {
			if (index(l, '+QRSRP:') < 0) continue;
			let f = fields(l), k = match(f[4] ?? '', /NR5G/) ? 'nr' : 'lte';
			r[k] = map(slice(f, 0, 4), (x) => (+x <= -140 || +x >= 0 || !match(x, /^-?[0-9]+$/)) ? null : +x);
		}
		return r;
	},
	/* dopo un cambio di bande: 5G come scelto (wrtfreedom.modem.nrmode, di serie 5G NSA con SA spento); ModemManager non
	   distingue SA e NSA */
	after: function(mode) {
		if (mode == 'lte') return [];
		let nm = trim(sh('uci -q get wrtfreedom.modem.nrmode'));
		return [ 'AT+QNWPREFCFG="nr5g_disable_mode",' + (nm == 'sa' || nm == 'auto' ? 0 : 1) ];
	},
	/* 5G (2.47): nsa = 4G + 5G NSA (SA spento, di serie), auto = NSA e SA, sa = solo 5G SA («5G puro») */
	nrmode: function(m) {
		return m == 'sa' ? [ 'AT+QNWPREFCFG="mode_pref",NR5G', 'AT+QNWPREFCFG="nr5g_disable_mode",0' ] :
			[ 'AT+QNWPREFCFG="mode_pref",LTE:NR5G', 'AT+QNWPREFCFG="nr5g_disable_mode",' + (m == 'auto' ? 0 : 1) ];
	}
};
/* Fibocom FM150/FM160/FM190 (Qualcomm). Fonti: MikroTik LTE docs (GTCELLLOCK), QModem vendor/fibocom.sh (GTCCINFO, GTACT).
   Codici banda: 4G = 100+n (103 = B3), 5G = "50"+n (5078 = n78); scs 0 = 15 kHz, 1 = 30 kHz.
   FM350 (MediaTek) e L850/L860 (Intel): niente blocco cella nei manuali → solo bande. */
function fibonr(c) { c = '' + c; return (length(c) >= 3 && substr(c, 0, 2) == '50') ? substr(c, 2) : null; }
DRV.fibocom = {
	name: 'Fibocom',
	read: [ 'AT+GTCCINFO?' ],
	neigh: [],
	parse: function(o) {
		/* righe: servente(1)/vicina,rat(4 LTE, 9 NR),mcc,mnc,tac,cellid,arfcn,pci,banda,... (arfcn e pci in esadecimale) */
		let S = { nb: [] };
		for (let l in split(o, '\n')) {
			let f = map(split(trim(l), ','), (x) => trim(x, ' "'));
			if (length(f) < 9 || !match(f[0], /^[0-9]$/) || !match(f[1], /^[0-9]+$/)) continue;
			let arfcn = '' + hex(f[6]), pci = '' + hex(f[7]), bc = f[8];
			if (f[1] == '4') {
				let c = { pci: pci, earfcn: arfcn, band: (+bc > 100 && +bc < 300) ? '' + (+bc - 100) : bandof(LTEB, arfcn), tac: f[4], cid: f[5] };
				if (f[0] == '1' && !S.lte) S.lte = c; else push(S.nb, { ...c, t: S.lte && S.lte.earfcn == arfcn ? 'intra' : 'inter' });
			}
			if (f[1] == '9' && f[0] == '1' && !S.nr) S.nr = { pci: pci, arfcn: arfcn, band: fibonr(bc) ?? bandof(NRB, arfcn) };
		}
		return S;
	},
	lockq: [ 'AT+GTCELLLOCK?' ],
	lockparse: function(o) {
		let r = { lte: 'none', nr: 'none' };
		for (let l in split(o, '\n')) {
			if (index(l, '+GTCELLLOCK:') < 0) continue;
			let f = fields(l);
			if (f[0] != '1') continue;
			if (f[1] == '0' && length(f) > 4) r.lte = f[3] + ',' + f[4];
			if (f[1] == '1' && length(f) > 6) r.nr = join(',', [ f[4], f[3], f[5] == '1' ? '30' : '15', fibonr(f[6]) ?? f[6] ]);
		}
		return r;
	},
	lock: function(L, N) {
		let c = [ 'AT+GTCELLLOCK=0', 'AT+GTCELLLOCK=1,0,0,' + L.earfcn + ',' + L.pci ];
		if (N) push(c, 'AT+GTCELLLOCK=2,1,0,' + N.arfcn + ',' + N.pci + ',' + (N.scs == '30' ? '1' : '0') + ',50' + N.band);
		return c;
	},
	unlock: function() { return [ 'AT+GTCELLLOCK=0' ]; },
	bandsread: function() {
		let o = at('AT+GTACT?'), m = match(o, /\+GTACT: *([0-9,]+)/);
		if (!m) return null;
		let f = split(m[1], ','), L = [], N = [];
		for (let x in slice(f, 3)) { let n = fibonr(x); if (n) push(N, n); else if (+x > 100 && +x < 300) push(L, '' + (+x - 100)); }
		return { sup: { lte: uniq(L), nr: uniq(N) }, cur: { lte: uniq(L), nr: uniq(N) }, mode: (f[0] == '2') ? 'lte' : 'nr' };
	},
	bandsset: function(L, N, mode) {
		let lc = join(',', map(L, (x) => '' + (100 + +x))), nc = join(',', map(N, (x) => '50' + x));
		return [ (length(N) && mode != 'lte') ? 'AT+GTACT=17,6,,' + lc + ',' + nc : 'AT+GTACT=2,,,' + lc ];
	},
	nrbandsset: null
};
/* SIMCom SIM8200EA / SIM8262 (5G). Fonti: SIM82XX AT manual (indice: CCELLCFG, C5GCELLCFG, CSYSSEL), QModem vendor/simcom.sh.
   Ordine diverso da Quectel: prima PCI poi EARFCN; scs 0 = 15 kHz, 1 = 30 kHz. SIM7600/A7600: niente blocco cella → solo bande. */
DRV.simcom = {
	name: 'SIMCom',
	read: [ 'AT+CPSI?' ],
	neigh: [],
	parse: function(o) {
		let S = { nb: [] };
		for (let l in split(o, '\n')) {
			if (index(l, '+CPSI:') < 0) continue;
			let f = fields(l), bn = (x) => (match(x ?? '', /BAND([0-9]+)/) ?? [])[1] ?? '';
			if (f[0] == 'LTE' && length(f) > 7) S.lte = { pci: f[5], earfcn: f[7], band: bn(f[6]), tac: f[3], cid: f[4] };
			else if (f[0] == 'NR5G_SA' && length(f) > 7) S.nr = { pci: f[5], arfcn: f[7], band: bn(f[6]), sa: true };
			else if (f[0] == 'NR5G_NSA' && length(f) > 3) S.nr = { pci: f[1], arfcn: f[3], band: bn(f[2]) };
		}
		return S;
	},
	lockq: [ 'AT+CCELLCFG?', 'AT+C5GCELLCFG?' ],
	lockparse: function(o) {
		let r = { lte: 'none', nr: 'none' };
		for (let l in split(o, '\n')) {
			let f = fields(l);
			if (index(l, '+CCELLCFG:') >= 0 && f[0] == '1' && length(f) > 2) r.lte = f[2] + ',' + f[1];
			if (index(l, '+C5GCELLCFG:') >= 0 && length(f) > 1 && f[0] != '0' && !match(l, /unlock/i)) r.nr = join(',', slice(f, length(f) > 4 ? length(f) - 4 : 0));
		}
		return r;
	},
	lock: function(L, N) {
		let c = [ 'AT+CCELLCFG=1,' + L.pci + ',' + L.earfcn ];
		push(c, N ? 'AT+C5GCELLCFG="pci",' + N.pci + ',' + N.arfcn + ',' + (N.scs == '30' ? '1' : '0') + ',' + N.band : 'AT+C5GCELLCFG="unlock"');
		return c;
	},
	unlock: function() { return [ 'AT+CCELLCFG=0', 'AT+C5GCELLCFG="unlock"' ]; },
	bandsread: function() {
		let c = at('AT+CSYSSEL="lte_band";+CSYSSEL="nsa_nr5g_band"'), g = (k) => { let m = match(c, regexp('"' + k + '",([0-9:]+)')); return m ? split(m[1], ':') : null; };
		if (!g('lte_band')) return null;
		return { sup: { lte: g('lte_band'), nr: g('nsa_nr5g_band') ?? [] }, cur: { lte: g('lte_band'), nr: g('nsa_nr5g_band') ?? [] }, mode: '' };
	},
	bandsset: function(L, N, mode) {
		let c = [ 'AT+CSYSSEL="lte_band",' + join(':', L) ];
		if (length(N) && mode != 'lte') push(c, 'AT+CSYSSEL="nsa_nr5g_band",' + join(':', N), 'AT+CSYSSEL="nr5g_band",' + join(':', N));
		return c;
	},
	nrbandsset: function(N) { return length(N) ? [ 'AT+CSYSSEL="nsa_nr5g_band",' + join(':', N), 'AT+CSYSSEL="nr5g_band",' + join(':', N) ] : []; }
};

/* modulo per questo modem: alcune famiglie della stessa marca non hanno il blocco cella (o i comandi AT della marca) */
function drv(I) {
	if (type(I) == 'string') I = { vendor: I, model: '' };
	let D = DRV[I?.vendor ?? ''], m = lc(I?.model ?? '');
	if (!D) return null;
	if (I.vendor == 'fibocom' && match(m, /fm350|l8[56]0/)) return { ...D, name: D.name + ' ' + I.model, lock: null, unlock: null, lockq: [], read: match(m, /l8[56]0/) ? [] : D.read, bandsread: match(m, /l8[56]0/) ? null : D.bandsread, bandsset: match(m, /l8[56]0/) ? null : D.bandsset };
	if (I.vendor == 'simcom' && !match(m, /sim8[0-9]{3}/)) return { ...D, name: D.name + ' ' + I.model, lock: null, unlock: null, lockq: [], bandsread: null, bandsset: null, nrbandsset: null };
	return D;
}

/* blocco cella: dai valori salvati ("earfcn,pci" e "pci,arfcn,scs,band") ai comandi della marca */
function lockobj(L, N) {
	let l = null, n = null, f;
	if (length(L ?? '')) { f = split(L, ','); l = { earfcn: f[0], pci: f[1], band: f[2] ?? bandof(LTEB, f[0]) }; }
	if (length(N ?? '')) { f = split(N, ','); n = { pci: f[0], arfcn: f[1], scs: f[2] ?? '', band: f[3] ?? bandof(NRB, f[1]) }; }
	return [ l, n ];
}
function lockcmds(D, L, N) { let o = lockobj(L, N); return o[0] ? D.lock(o[0], o[1]) : D.unlock(); }

/* ---------------- bande e modalità ---------------- */
/* da ModemManager: "eutran-3" → 4G 3, "ngran-78" → 5G 78 */
function mmbands(list) {
	let r = { lte: [], nr: [] };
	for (let b in list ?? []) {
		let m = match(b, /^eutran-([0-9]+)$/); if (m) push(r.lte, m[1]);
		m = match(b, /^ngran-([0-9]+)$/); if (m) push(r.nr, m[1]);
	}
	r.lte = uniq(r.lte); r.nr = uniq(r.nr);
	return r;
}
function mmmode(s) {
	/* "allowed: 4g, 5g; preferred: 5g" */
	let m = match(s ?? '', /allowed: ([^;]+)/);
	if (!m) return '';
	let a = m[1];
	return index(a, '5g') >= 0 ? 'nr' : index(a, '4g') >= 0 ? 'lte' : '';
}
function bands() {
	let I = id(), mmj = json(readfile('/tmp/wf-modem.mm') ?? 'null'), g = mmj?.modem?.generic ?? {}, D = drv(I), r = null;
	if (I.mm && length(g['supported-bands'] ?? [])) {
		let s = mmbands(g['supported-bands']), c = mmbands(g['current-bands']);
		if (length(s.lte)) r = { sup: s, cur: c, mode: mmmode(g['current-modes']), via: 'mm' };
	}
	/* 5G: ModemManager troppo vecchio o modem che non dichiara le bande 5G → comandi AT della marca */
	if (D && D.bandsread && (!r || !length(r.sup.nr))) {
		let a = D.bandsread();
		if (a) {
			if (!r) r = { sup: a.sup, cur: a.cur, mode: a.mode, via: 'at' };
			else if (length(a.sup.nr)) { r.sup.nr = a.sup.nr; r.cur.nr = a.cur.nr; r.via = 'mm+at'; }
		}
	}
	return r;
}
/* interfaccia del modem nella configurazione (proto modemmanager…), per salvare la modalità */
function mobif() {
	for (let l in split(sh('uci -q show network'), '\n')) {
		let m = match(l, /^network\.([A-Za-z0-9_]+)\.proto='(modemmanager|qmi|mbim|ncm|3g|wwan)'$/);
		if (m) return [ m[1], m[2] ];
	}
	return null;
}
/* applica bande e modalità: mode = 'nr' (4G + 5G NSA) o 'lte' (solo 4G) */
function bandsset(L, N, mode) {
	let I = id(), D = drv(I), B = bands(), errs = [], via = [];
	if (!B) return { ok: false, errors: [ 'bande del modem non leggibili' ] };
	if (mode == 'lte') N = [];
	let mmok = B.via != 'at' && I.mm, mmnr = mmok && B.via == 'mm' && length(B.sup.nr);
	if (mmok) {
		let list = map(L, (x) => 'eutran-' + x);
		if (mmnr) for (let x in N) push(list, 'ngran-' + x);
		let c = '--set-current-bands=' + q(join('|', list)), o = mmcli(c);
		cmdlog('mmcli ' + c, o);
		if (match(o, /error/i)) {
			push(errs, 'ModemManager: ' + trim(o));
			mmok = false;
		} else push(via, 'mm');
		/* modalità: in ModemManager e nella configurazione, perché OpenWrt la rimette a ogni collegamento */
		let mi = mobif(), m5 = length(B.sup.nr) > 0;
		if (mmok) {
			let am = (mode == 'lte' || !m5) ? '4g' : '5g|4g', pm = am == '4g' ? '' : '5g';
			let o2 = mmcli('--set-allowed-modes=' + q(am) + (length(pm) ? ' --set-preferred-mode=' + pm : ''));
			cmdlog('mmcli --set-allowed-modes=' + am, o2);
			if (match(o2, /error/i) && !match(o2, /already|unchanged|same/i)) push(errs, 'ModemManager (modalità): ' + trim(o2));
			/* OpenWrt 23.05+: la modalità scritta nell'interfaccia vale a ogni collegamento (vuota = qualsiasi, dalla 24.10) */
			if (mi && mi[1] == 'modemmanager')
				sh('uci set network.' + mi[0] + '.allowedmode=' + q(am) + '; ' + (length(pm) ? 'uci set network.' + mi[0] + '.preferredmode=' + pm + '; ' : 'uci -q delete network.' + mi[0] + '.preferredmode; ') + 'uci commit network');
		}
	}
	/* comandi AT della marca: tutto se ModemManager non ha potuto, oppure solo le bande 5G */
	if (D) {
		let cmds = [];
		if (!mmok && D.bandsset) { cmds = D.bandsset(L, N, mode); errs = []; }
		else if (mmok && !mmnr && length(N) && D.nrbandsset) cmds = D.nrbandsset(N);
		/* dopo ModemManager il modem si riaggancia e per qualche secondo non risponde ai comandi AT: i comandi finali
		   (Quectel: 5G SA spento) partono in sottofondo dopo 15 s, con 3 tentativi, e finiscono nel registro dei comandi */
		if (mmok && D.after && length(D.after(mode))) {
			let bg = '( sleep 15; ';
			for (let c in D.after(mode))
				bg += 'for i in 1 2 3; do o=$(sh ' + AT + ' ' + q(c) + ' 2>&1); d=$(date +%d/%m\\ %H:%M:%S); printf "%s > %s\\n%s < %s\\n" "$d" ' + q(c) +
					' "$d" "$(echo "$o" | tr "\\n" " ")" >> ' + CMDLOG + '; echo "$o" | grep -q OK && break; sleep 10; done; ';
			sh(bg + ') >/dev/null 2>&1 </dev/null &');
			push(via, 'at');
		}
		for (let c in cmds) {
			let o = at(c);
			if (!atok(o)) { sh('sleep 1'); o = at(c); }
			if (!atok(o)) push(errs, c + ' → ' + (trim(o) || 'nessuna risposta'));
		}
		if (length(cmds)) push(via, 'at');
	}
	else if (!mmok) push(errs, 'questo modem non permette di cambiare le bande da qui');
	/* quectel-5g-tools rimette le sue bande a ogni avvio: le tiene allineate */
	if (stat('/etc/config/quectel') != null) {
		let c = 'uci -q delete quectel.modem.lte_bands; ';
		for (let x in L) c += 'uci add_list quectel.modem.lte_bands=' + x + '; ';
		if (length(N)) { c += 'uci -q delete quectel.modem.nr5g_bands; '; for (let x in N) c += 'uci add_list quectel.modem.nr5g_bands=' + x + '; '; }
		sh(c + 'uci commit quectel');
	}
	/* bande volute: all'accensione il router controlla e, se il modem le ha dimenticate, le rimette */
	sh('uci set wrtfreedom.modem=modem; uci set wrtfreedom.modem.lte=' + q(join(' ', L)) + '; uci set wrtfreedom.modem.nr=' + q(join(' ', N)) +
		'; uci set wrtfreedom.modem.mode=' + q(mode) + '; uci commit wrtfreedom');
	unlink('/tmp/wf-modem.ts');
	return { ok: !length(errs), errors: errs, via: join('+', via) };
}

/* ---------------- celle ---------------- */
/* ModemManager 1.20+ (modem QMI o MBIM): "cell type: lte, serving: yes, physical ci: 1F5, earfcn: 1850, rsrp: -95.000000, ..." */
function mmcells(list, curnr) {
	let S = { nb: [] };
	for (let s in list ?? []) {
		let kv = {};
		for (let p in split(s, ', ')) { let i = index(p, ': '); if (i > 0) kv[substr(p, 0, i)] = substr(p, i + 2); }
		let pci = kv['physical ci'] != null ? '' + hex(kv['physical ci']) : '';
		if (kv['cell type'] == 'lte') {
			let c = { pci: pci, earfcn: kv.earfcn ?? '', band: bandof(LTEB, kv.earfcn), rsrp: +(kv.rsrp ?? 0), rsrq: +(kv.rsrq ?? 0), tac: kv.tac ?? '', cid: kv.ci ?? '' };
			if (kv.serving == 'yes' && (!S.lte || kv['serving cell type'] == '1')) S.lte = c;
			else if (kv.serving != 'yes') push(S.nb, { ...c, t: (S.lte && S.lte.earfcn == c.earfcn) ? 'intra' : 'inter' });
		}
		if (kv['cell type'] == '5gnr' && !S.nr)
			S.nr = { pci: pci, arfcn: kv.nrarfcn ?? '', band: kv.nrarfcn ? bandof(NRB, kv.nrarfcn, curnr) : '', rsrp: +(kv.rsrp ?? 0), rsrq: +(kv.rsrq ?? 0), sinr: +(kv.sinr ?? 0) };
	}
	S.nb = sort(S.nb, (a, b) => b.rsrp - a.rsrp);
	return S;
}

/* ---------------- lettura (uguale per tutte le marche) ---------------- */
/* comando shell che rilegge il modem: ModemManager, ATI la prima volta, comandi della marca, segnale e celle.
   wrtfreedom.uc lo lancia in sottofondo (rpcd non deve aspettare il modem); modemctl.uc lo esegue e aspetta */
function readcmd() {
	let I = id(), D = drv(I), A = 'sh ' + AT + ' ', c = 'touch /tmp/wf-modem.ts; o=$(mmcli -m any -J 2>/dev/null); [ -n "$o" ] && echo "$o" > /tmp/wf-modem.mm; ';
	if (!stat('/tmp/wf-modem.ati')) c += A + "'ATI' > /tmp/wf-modem.ati 2>/dev/null; ";
	if (D && length(D.read)) { c += '{ '; for (let x in D.read) c += A + q(x) + '; '; c += '} > /tmp/wf-modem.at.t 2>/dev/null; '; }
	else c += ': > /tmp/wf-modem.at.t; ';
	if (I.mm) {
		c += 'mmcli -m any --signal-get -J > /tmp/wf-modem.sig 2>/dev/null; grep -q rsrp /tmp/wf-modem.sig || mmcli -m any --signal-setup=10 >/dev/null 2>&1; ';
		if (mmge(I.mmver, '1.20') && (I.qmi || I.mbim)) c += 'mmcli -m any --get-cell-info -J > /tmp/wf-modem.cell 2>/dev/null; ';
	}
	return c + 'mv /tmp/wf-modem.at.t /tmp/wf-modem.at';
}
/* stato normalizzato dalle ultime letture: cella 4G/5G, segnale, vicine, chi è il modem */
function state(I0) {
	/* I0 = id() appena letto da chi chiama (facoltativo: evita di rileggerlo) */
	let I = I0 ?? id(), D = drv(I), o = readfile('/tmp/wf-modem.at') ?? '', mm = json(readfile('/tmp/wf-modem.mm') ?? 'null');
	let n = D && D.parse ? D.parse(o) : { nb: [] };
	let cl = json(readfile('/tmp/wf-modem.cell') ?? 'null')?.modem?.generic?.['cell-info'];
	if (cl) {
		let c = mmcells(cl, mm?.modem?.generic?.['current-bands']);
		if (!n.lte) n.lte = c.lte;
		if (!n.nr) n.nr = c.nr;
		if (!length(n.nb ?? [])) n.nb = c.nb;
	}
	let sg = json(readfile('/tmp/wf-modem.sig') ?? 'null')?.modem?.signal;
	if (sg) {
		let num = (x) => (x == null || x == '--') ? null : +x;
		if (sg.lte && num(sg.lte.rsrp) != null) { n.lte = n.lte ?? {}; n.lte.rsrp ??= num(sg.lte.rsrp); n.lte.rsrq ??= num(sg.lte.rsrq); n.lte.sinr ??= num(sg.lte.snr); }
		if (sg['5g'] && num(sg['5g'].rsrp) != null) { n.nr = n.nr ?? {}; n.nr.rsrp ??= num(sg['5g'].rsrp); n.nr.rsrq ??= num(sg['5g'].rsrq); n.nr.sinr ??= num(sg['5g'].snr); }
	}
	/* aggregazione di portanti: dalle righe della marca (Quectel QCAINFO), altrimenti la cella principale e il 5G */
	let ca = [];
	for (let l in split(o, '\n')) { let m = match(l, /"(PCC|SCC)",[0-9]+,[0-9]+,"(LTE|NR5G) BAND ([0-9]+)"/); if (m) push(ca, (m[2] == 'LTE' ? 'B' : 'n') + m[3]); }
	if (!length(ca)) { if (n.lte?.band) push(ca, 'B' + n.lte.band); if (n.nr?.band) push(ca, 'n' + n.nr.band); }
	n.ca = ca;
	let t = []; for (let m in match(o, /\+QTEMP: *"[^"]+","([0-9]+)"/g) ?? []) push(t, +m[1]);
	if (length(t)) n.temp = t;
	let g = mm?.modem?.generic ?? {}, g3 = mm?.modem?.['3gpp'] ?? {};
	n.op = g3['operator-name'] ?? ''; n.at = g['access-technologies'] ?? [];
	return { n: n, raw: o, mm: mm, id: I, D: D };
}

/* tecnologia della linea dallo stato normalizzato: nr-sa, nr-nsa, lte, 3g, 2g o '' (nessun segnale) */
function tech(n) {
	let a = join(' ', n?.at ?? []);
	if (n?.nr?.sa || (!n?.lte && index(a, '5gnr') >= 0 && index(a, 'lte') < 0)) return 'nr-sa';
	if (n?.nr && n?.lte) return 'nr-nsa';
	if (n?.lte || index(a, 'lte') >= 0) return 'lte';
	if (match(a, /umts|hsdpa|hsupa|hspa/)) return '3g';
	if (match(a, /gsm|gprs|edge/)) return '2g';
	return '';
}
/* testo UCS2 in esadecimale (USSD e Cell Broadcast con dcs 72 o modem in UCS2) → UTF-8; altrimenti com'è */
function ucs2(s, force) {
	s = trim('' + (s ?? ''));
	/* senza «force» solo se sembra davvero UCS2: ogni carattere latino (00xx), greco/cirillico (03xx, 04xx) o simbolo (20xx) */
	if (!length(s) || length(s) % 4 != 0 || !match(s, /^[0-9A-Fa-f]+$/)) return s;
	if (!force && !match(s, /^(00[0-9A-Fa-f]{2}|0[34][0-9A-Fa-f]{2}|20[0-9A-Fa-f]{2})+$/)) return s;
	let o = '', u = (c) => c < 0x80 ? chr(c) : c < 0x800 ? chr(0xC0 | (c >> 6), 0x80 | (c & 63)) :
		c < 0x10000 ? chr(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63)) : chr(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
	for (let i = 0; i < length(s); i += 4) {
		let c = hex(substr(s, i, 4));
		/* coppie surrogate (emoji) */
		if (c >= 0xD800 && c < 0xDC00 && i + 8 <= length(s)) { let d = hex(substr(s, i + 4, 4)); if (d >= 0xDC00 && d < 0xE000) { c = 0x10000 + ((c - 0xD800) << 10) + (d - 0xDC00); i += 4; } }
		o += u(c);
	}
	return o;
}

/* ---------------- ripristino, riavvio, modalità ---------------- */
function lineup() {
	for (let l in split(readfile('/proc/net/route') ?? '', '\n')) { let f = split(l, '\t'); if (f[1] == '00000000' && f[7] == '00000000') return true; }
	return false;
}
/* prima di cambiare bande o blocco cella, se la linea c'è: salva com'è il modem e, dopo 3 minuti, modemctl.uc controlla */
function guard() {
	if (!lineup()) return;
	let B = bands();
	if (!B) return;
	let g = (k) => trim(sh('uci -q get wrtfreedom.lock.' + k));
	writefile('/etc/wrtfreedom/modem.prev', sprintf('%J', { t: time(), lte: B.cur.lte, nr: B.cur.nr, mode: B.mode || 'nr', locklte: g('lte'), locknr: g('nr') }));
	sh('( sleep 180; ucode /usr/share/wrtfreedom/modemctl.uc guard ) >/dev/null 2>&1 </dev/null &');
}
/* riavvio del modem, uguale per tutti (app, widget, eventi, watchdog, pianificazioni, bot): ModemManager se c'è, altrimenti AT */
function restart() {
	let I = id();
	if (I.mm) { let o = mmcli('-r'); cmdlog('mmcli -r', o); if (!match(o, /error/i)) return 'mm'; }
	let o = at('AT+CFUN=1,1');
	return atok(o) ? 'at' : '';
}
/* solo 4G ('lte') o 4G + 5G NSA ('nr'): tiene le bande 4G scelte; per il 5G quelle scelte o, se nessuna, tutte */
function setmode(mode) {
	let B = bands();
	if (!B) return { ok: false, errors: [ 'bande del modem non leggibili' ] };
	let L = length(B.cur.lte) ? B.cur.lte : B.sup.lte, N = mode == 'lte' ? [] : (length(B.cur.nr) ? B.cur.nr : B.sup.nr);
	let w = split(trim(sh('uci -q get wrtfreedom.modem.nr')), /\s+/);
	if (mode != 'lte' && length(w) && length(w[0])) N = w;
	if (mode != 'lte' && !length(B.sup.nr)) return { ok: false, errors: [ 'questo modem non ha bande 5G' ] };
	guard();
	return bandsset(L, N, mode);
}

/* ---------------- rapporto ---------------- */
function report() {
	let I = id(true), B = bands(), D = drv(I), L = [];
	let hide = (s) => replace(replace('' + s, /("?(imei|imsi|iccid|msisdn|equipment-identifier|own-numbers|esn|meid)"?[: ]+)"?[^",\n]*"?/gi, '$1***'), /[0-9]{14,20}/g, '***');
	push(L, 'WrtFreedom · Rapporto Modem', 'Pacchetto: ' + trim(readfile('/usr/share/wrtfreedom/VERSION') ?? ''),
		'OpenWrt: ' + trim(replace(match(readfile('/etc/openwrt_release') ?? '', /DISTRIB_DESCRIPTION='([^']*)'/)?.[1] ?? '', /'/g, '')),
		'Modem: ' + I.mfr + ' ' + I.model + ' · firmware ' + I.rev, 'Marca riconosciuta: ' + (I.vendor || 'nessuna') + (D ? ' (modulo ' + D.name + ')' : ' (nessun modulo per il blocco cella)'),
		'ModemManager: ' + (I.mm ? 'sì, versione ' + I.mmver + ' · plugin ' + I.plugin + ' · driver ' + join(' ', I.drivers) : (length(I.mmver) ? 'installato, modem non visto' : 'no')),
		'Strumento AT: ' + trim(sh('sh ' + AT + ' --tool 2>/dev/null')),
		'Bande: ' + (B ? 'via ' + B.via + ' · supportate 4G ' + join(' ', B.sup.lte) + ' · 5G ' + join(' ', B.sup.nr) + ' · in uso 4G ' + join(' ', B.cur.lte) + ' · 5G ' + join(' ', B.cur.nr) + ' · modalità ' + B.mode : 'non leggibili'),
		'', '--- ModemManager ---', hide(trim(mmcli('') || '(nessuna risposta)')), '', '--- ATI ---', trim(at('ATI')), '', '--- Ultimi comandi ---', hide(trim(readfile(CMDLOG) ?? '')));
	/* niente colori del terminale (mmcli scrive «\x1b[32mconnected\x1b[0m») */
	return replace(join('\n', L), /\x1b\[[0-9;]*m/g, '');
}

return { id, present, drv, bands, bandsset, readcmd, state, lineup, guard, restart, setmode, lockcmds, lockobj, mmcells, bandof, LTEB, NRB, at, atok, mmcli, mmjs, fields, report, mobif, mmge, cmdlog, vendorOf, tech, ucs2 };
