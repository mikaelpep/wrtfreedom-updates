#!/bin/sh
# WrtFreedom: rimuove dal router tutto ciò che ha installato l'app
say() { echo "## $*"; }
say "Rimuovo i file"
# Ritorno automatico (2.63): lavoro degli Aggiornamenti fermato (anche i figli, nel suo gruppo), poi ogni copia ancora in
# attesa di conferma rimessa com'era (come all'avvio in wrtfreedom.init), prima di ogni pulizia e di cancellare /etc/wrtfreedom
WF_UP=$(cat /tmp/wf-bg.upg.pid 2>/dev/null)
case "$WF_UP" in ''|*[!0-9]*) ;; *) kill -TERM -"$WF_UP" "$WF_UP" 2>/dev/null; rm -f /tmp/wf-bg.upg.pid ;; esac
for b in /etc/wrtfreedom/bak/*/back.sh; do [ -f "$b" ] && sh "$b" >/dev/null 2>&1; done
# tema di LuCI «WrtFreedom»: se è attivo torna quello di prima (o Bootstrap), così all'indirizzo del router si apre LuCI
if [ "$(uci -q get luci.main.mediaurlbase)" = /luci-static/wrtfreedom ]; then
	P=$(uci -q get wrtfreedom.luci.prev); { [ -n "$P" ] && [ "$P" != /luci-static/wrtfreedom ] && [ -e "/www$P" ]; } || P=/luci-static/bootstrap
	uci set luci.main.mediaurlbase="$P"
fi
uci -q delete luci.themes.WrtFreedom; uci commit luci
# Servizio VPN (come «del» del metodo vpnout): interfacce wgout/wgoN spente, poi tolte con server, rotte e regole;
# zona e inoltri del firewall, DNS. Solo i nomi del servizio: una WireGuard dell'utente (es. wgoffice) resta
say "Rimuovo il Servizio VPN"
for i in $(uci -q show network | sed -nE 's/^network\.(wgo(ut|[0-9]+))=interface$/\1/p'); do ifdown "$i" 2>/dev/null; done
for s in $(uci -q show network | sed -nE 's/^network\.(wgo(ut|[0-9]+)(_peer|_rt)?|wgout_(r[0-9]+|main))=.*/\1/p'); do uci -q delete network.$s; done
for s in $(uci -q show firewall | sed -nE 's/^firewall\.(wgout_[A-Za-z0-9_]+)=.*/\1/p'); do uci -q delete firewall.$s; done
rm -f /usr/share/nftables.d/chain-pre/dstnat/40-wrtfreedom-vpndns.nft /usr/share/nftables.d/table-post/42-wrtfreedom-vpnmac.nft
# Eccezioni Per Sito (2.52): voci nftset di dnsmasq messe dal pacchetto, insieme e catena, regola di instradamento
for x in $(uci -q get wrtfreedom.vpnsite.site); do uci -q del_list "dhcp.@dnsmasq[0].nftset=/$x/4#inet#fw4#wf_vpnx"; done
uci -q delete network.wf_vpnsite; rm -f /usr/share/nftables.d/table-post/41-wrtfreedom-vpnsite.nft
# VPN Per Fuori Casa (2.52): la WireGuard dell'utente resta; tolte Porta Alternativa, regole DNS del Tunnel Parziale messe
# dal pacchetto (wrtfreedom.wg.ddr) e pause dei dispositivi (senza il pacchetto nessuno le toglierebbe più)
uci -q delete firewall.wf_wgalt; uci -q delete firewall.wf_wgalt_in
for x in $(uci -q get wrtfreedom.wg.ddr); do uci -q del_list "dhcp.@dnsmasq[0].address=$x"; done
for s in $(uci -q show wrtfreedom | sed -n "s/^wrtfreedom\.peer_\([A-Za-z0-9_]*\)\.paused='1'$/\1/p"); do uci -q delete "network.$s.disabled"; done
# DNS Obbligatorio e Nomi Di Casa (2.64) messi dal pacchetto: wf_dnsforce e i nomi wf_hn_*; la regola DNS dell'utente
# (dns_redirect o «Forza-DNS-AdGuard») resta com'è
uci -q delete firewall.wf_dnsforce
for s in $(uci -q show dhcp | sed -nE 's/^dhcp\.(wf_hn_[a-z0-9]+)=domain$/\1/p'); do uci -q delete dhcp.$s; done
uci commit dhcp; /etc/init.d/dnsmasq reload >/dev/null 2>&1
# contatori dei tentativi bloccati (2.45, fwstat.uc): tolti prima della ricarica del firewall qui sotto
rm -f /usr/share/nftables.d/table-pre/90-wrtfreedom.nft /usr/share/nftables.d/chain-post/*/90-wrtfreedom.nft
# Dispositivi (2.49): contatori, pause e Pausa Per Tutti (dev.uc); limiti e priorità per dispositivo (shaper)
rm -f /usr/share/nftables.d/table-pre/91-wrtfreedom-dev.nft /etc/nftables.d/90-wrtfreedom.nft
uci commit network; uci commit firewall; /etc/init.d/network reload; /etc/init.d/firewall reload
rm -rf /usr/share/ucode/luci/template/themes/wrtfreedom /www/luci-static/wrtfreedom
[ -x /etc/init.d/wrtfreedom ] && { /etc/init.d/wrtfreedom stop; /etc/init.d/wrtfreedom disable; }
# DNS (2.50): cambio in corso o rimasto a metà → copia rimessa (adgmode.new, prima di cancellare /etc/wrtfreedom);
# AdGuard sulla 53 messo dall'app → schema di prima (dnsmasq sulla 53 che inoltra ad AdGuard). DNS di riserva in corso:
# se AdGuard risponde tornano i server di dnsmasq verso AdGuard (127.0.0.1#porta), altrimenti restano i server
# dell'operatore o pubblici messi dalla riserva (mai casa senza DNS)
if [ -f /usr/share/wrtfreedom/adgmode.sh ]; then
	if [ -d /etc/wrtfreedom/adgmode ] || [ -d /etc/wrtfreedom/adgmode.new ] || grep -q "^MODE='direct'" /etc/wrtfreedom/dnsfb.state 2>/dev/null; then
		say "Rimetto il DNS com'era prima"
		if [ -d /etc/wrtfreedom/adgmode.new ]; then
			if pgrep -f 'adgmode\.sh (direct|back)' >/dev/null 2>&1; then	# cambio in corso: annullato, attesa del ritorno
				touch /tmp/wf-adgmode.no; i=0; while [ -d /etc/wrtfreedom/adgmode.new ] && [ $i -lt 30 ]; do sleep 1; i=$((i+1)); done
				# ancora a metà (verifica in corso): fermato, poi copia rimessa
				[ -d /etc/wrtfreedom/adgmode.new ] && { pkill -f 'adgmode\.sh (direct|back)'; sleep 1; }
			fi
			[ -d /etc/wrtfreedom/adgmode.new ] && sh /usr/share/wrtfreedom/adgmode.sh recover
		fi
		[ -d /etc/wrtfreedom/adgmode ] || grep -q "^MODE='direct'" /etc/wrtfreedom/dnsfb.state 2>/dev/null && sh /usr/share/wrtfreedom/adgmode.sh back
	elif [ -f /etc/wrtfreedom/dnsfb.state ]; then
		sh /usr/share/wrtfreedom/adgmode.sh check
	fi
fi
# limite di velocità a giga finiti (2.47): SQM e cake-autorate tornano come erano prima
[ -f /etc/wrtfreedom/slow ] && [ -f /usr/share/wrtfreedom/slow.sh ] && sh /usr/share/wrtfreedom/slow.sh off cfg >/dev/null 2>&1
# IT-Alert (2.47): modem rimesso com'era (canali, CSCB e CNMI di prima) e ascolto fermato
[ "$(uci -q get wrtfreedom.cbs.enabled)" = 1 ] && [ -f /usr/share/wrtfreedom/cbs.uc ] && ucode /usr/share/wrtfreedom/cbs.uc setup off >/dev/null 2>&1
# Spie Di Notte (2.54): spie spente adesso → di nuovo come erano
[ -f /tmp/wf-leds.save ] && [ -f /usr/share/wrtfreedom/cron.sh ] && sh /usr/share/wrtfreedom/cron.sh ledon >/dev/null 2>&1
# attività di Pianificazioni sospese dalle Spie Di Notte (#off#, id in wrtfreedom.ledn.susp) riaccese come prima; id
# calcolato come in svc.uc (crapp), prima che qui sotto si tolga l'involucro del registro
WF_SUSP=$(uci -q get wrtfreedom.ledn.susp)
if [ -n "$WF_SUSP" ] && [ -f /etc/crontabs/root ]; then
	cat > /tmp/wf-lednback.uc <<'EOF'
'use strict';
import { readfile, writefile, rename } from 'fs';
const F = '/etc/crontabs/root';
let sus = split(trim(getenv('WF_SUSP') ?? ''), ' '), out = [], ch = 0;
function crhash(s) { let h = 5381; for (let i = 0; i < length(s); i++) h = ((h * 33) ^ ord(s, i)) & 0x7fffffff; return sprintf('%08x', h); }
function crunwrap(c) {
	let m = match(c, /^\{ (.*) \} ; ucode \/usr\/share\/wrtfreedom\/svc\.uc log [0-9a-f]{8} \$\?$/s);
	if (!m) return c;
	let x = m[1];
	return substr(x, length(x) - 1) == ';' ? rtrim(substr(x, 0, length(x) - 1)) : x;
}
for (let l in split(readfile(F) ?? '', '\n')) {
	let s = substr(l, 0, 6) == '#off# ' ? substr(l, 6) : null, mm = s != null ? match(s, / #(wrtfreedom|x3000) /) : null;
	if (mm && !match(rtrim(s), / # wf:[a-z0-9_]{1,40}$/)) {
		let mi = index(s, mm[0]), meta = null;
		try { meta = json(replace(substr(s, mi + length(mm[0])), /\\%/g, '%')); } catch (e) {}
		let f = type(meta) == 'object' ? match(substr(s, 0, mi), /^[ \t]*([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+(.*)$/s) : null;
		if (f) {
			let cmd = crunwrap(f[6]), a = '' + (meta.a ?? '');
			let id = match('' + (meta.i ?? ''), /^[0-9a-f]{8}$/) ? meta.i : crhash(a + '|' + (meta.x ?? '') + '|' + (meta.n ?? '') + '|' + (meta.w ?? '') + (a == 'custom' || a == '' ? '|' + cmd : ''));
			if (index(sus, id) >= 0 && match(cmd, /cron\.sh led(off|on)( |$)/)) { l = s; ch++; }
		}
	}
	push(out, l);
}
if (ch) { writefile(F + '.wf', join('\n', out)); rename(F + '.wf', F); }
print(ch, '\n');
EOF
	[ "$(WF_SUSP="$WF_SUSP" ucode /tmp/wf-lednback.uc 2>/dev/null)" -gt 0 ] 2>/dev/null && /etc/init.d/cron restart >/dev/null 2>&1
	rm -f /tmp/wf-lednback.uc
fi
# lettura veloce del segnale (2.47): si ferma da sola senza il file della richiesta
rm -f /tmp/wf-sigfast.want
# Wi-Fi (2.48): righe del crontab del pacchetto (password ospiti, Canale Automatico, Potenza Di Notte), WPS a tempo
# rimesso com'era se era in corso (wps_pushbutton messo dal pacchetto), potenza della configurazione
# Pianificazioni (2.53): righe del pacchetto (Router Spento?, profili del Controllo Della Linea, certificato di AdGuard)
# tolte; le attività dell'app restano senza l'involucro del registro delle esecuzioni («{ comando; } ; ucode svc.uc log …»).
# 2.62: tolte anche le attività dell'app e dell'Assistente IA (marcate «#wrtfreedom») che chiamano cron.sh, tolto qui sotto;
# le righe dell'utente (senza il marchio) restano
C=/etc/crontabs/root
if [ -f $C ] && grep -qE '# wf:[a-z0-9_]+$|/usr/share/wrtfreedom/cron\.sh (txlow|txnorm)( |$)|/usr/share/wrtfreedom/svc\.uc log |/usr/share/wrtfreedom/cron\.sh .* #wrtfreedom( |$)' $C; then
	sed -E -e '/# wf:[a-z0-9_]+$/d; \#/usr/share/wrtfreedom/cron\.sh (txlow|txnorm)( |$)#d; \@/usr/share/wrtfreedom/cron\.sh .* #wrtfreedom( |$)@d' \
		-e 's#\{ (.*); \} ; ucode /usr/share/wrtfreedom/svc\.uc log [0-9a-f]{8} \$\?( \#(wrtfreedom|x3000) )#\1\2#' \
		-e 's#\{ (.*) \} ; ucode /usr/share/wrtfreedom/svc\.uc log [0-9a-f]{8} \$\?( \#(wrtfreedom|x3000) )#\1\2#' $C > $C.wf && mv $C.wf $C
	/etc/init.d/cron restart >/dev/null 2>&1
fi
# Prova Prima E Dopo (2.53) in corso: fermata e stato di prima rimesso subito (comandi salvati dalla prova prima di toccare
# sqm o tc; il ripristino a tempo, senza il file, non fa più niente)
if [ -d /tmp/wf-svc.abtest.lock ] || ls /tmp/wf-abtest.held.* >/dev/null 2>&1; then
	pkill -f 'svc\.uc abtest' 2>/dev/null
	for f in /tmp/wf-abtest.held.*; do case "$f" in *.r) ;; *) [ -f "$f" ] && mv "$f" "$f.r" && sh "$f.r" >/dev/null 2>&1 ;; esac; done
fi
s=$(uci -q get wrtfreedom.wifi.wpsadd)
[ -n "$s" ] && { uci -q delete "wireless.$s.wps_pushbutton"; uci commit wireless; wifi reload >/dev/null 2>&1; }
if [ -f /usr/share/wrtfreedom/wifi.uc ]; then
	ucode /usr/share/wrtfreedom/wifi.uc glimit off >/dev/null 2>&1	# Limite Di Velocità della rete ospiti: code CAKE e ifb tolte
	sh /usr/share/wrtfreedom/cron.sh txnorm >/dev/null 2>&1
fi
# Mesi Precedenti (2.59): «Conserva Dopo Il Riavvio» acceso dal pacchetto → nlbwmon torna alla cartella di prima, con i
# dati copiati là (un file non sostituisce mai uno più grande); /etc/nlbwmon resta (mai cancellare dati)
WF_NP=$(uci -q get wrtfreedom.nlbw.prev); WF_ND=$(uci -q get nlbwmon.@nlbwmon[0].database_directory)
if [ -n "$WF_NP" ] && [ "$WF_NP" != /etc/nlbwmon ] && [ "$WF_ND" = /etc/nlbwmon ]; then
	[ -x /etc/init.d/nlbwmon ] && /etc/init.d/nlbwmon stop
	mkdir -p "$WF_NP"
	for f in /etc/nlbwmon/*; do [ -f "$f" ] || continue; d="$WF_NP/${f##*/}"; [ -f "$d" ] && [ "$(wc -c < "$d")" -ge "$(wc -c < "$f")" ] && continue; cp -p "$f" "$d"; done
	uci set nlbwmon.@nlbwmon[0].database_directory="$WF_NP"; uci commit nlbwmon
	[ -x /etc/init.d/nlbwmon ] && /etc/init.d/nlbwmon start
fi
rm -f /etc/init.d/wrtfreedom /etc/config/wrtfreedom /etc/hotplug.d/*/90-wrtfreedom
rm -f /usr/share/rpcd/ucode/wrtfreedom.uc /usr/libexec/rpcd/wrtfreedom.wait /www/cgi-bin/wf-live /www/cgi-bin/wf-me /www/cgi-bin/wf-ai /usr/share/rpcd/acl.d/wrtfreedom.json
# Salute Del Router (2.54): lavoro in sottofondo fermato (all'accensione può ancora aspettare l'ora per scrivere in /etc)
pkill -f 'health\.uc' 2>/dev/null
pkill -f 'assist\.uc|speed\.uc' 2>/dev/null
# Assistente IA (2.60): lavori fermati (anche curl, nel loro gruppo), chiavi ai-*.key e Cose Da Ricordare ai-mem.json
# (2.62, in /etc/wrtfreedom), /tmp/wf-ai, file del token del bot /tmp/wf-tg.k e sezione ai di uci (in /etc/config/wrtfreedom)
# 2.64: servizio sempre acceso fermato da procd prima (altrimenti lo riavvierebbe) e tolto
[ -x /etc/init.d/wrtfreedom-ai ] && { /etc/init.d/wrtfreedom-ai stop; /etc/init.d/wrtfreedom-ai disable; }
rm -f /etc/init.d/wrtfreedom-ai
for p in $(pgrep -f 'wrtfreedom/ai\.uc' 2>/dev/null); do kill -TERM -$p $p 2>/dev/null; done
rm -f /etc/wrtfreedom/ai-*.key /etc/wrtfreedom/ai-mem.json; rm -rf /tmp/wf-ai /tmp/wf-tg.k
rm -rf /etc/wrtfreedom /www/wrtfreedom /tmp/.wf-* /tmp/wf-*
set --
for f in /www/wrtfreedom/ /usr/share/ucode/luci/template/themes/wrtfreedom/ /www/luci-static/wrtfreedom /usr/share/rpcd/ucode/wrtfreedom.uc /usr/libexec/rpcd/wrtfreedom.wait /www/cgi-bin/wf-live /www/cgi-bin/wf-me /www/cgi-bin/wf-ai /usr/share/rpcd/acl.d/wrtfreedom.json /usr/share/wrtfreedom/ /etc/wrtfreedom/ /etc/config/wrtfreedom /etc/init.d/wrtfreedom /etc/init.d/wrtfreedom-ai /etc/hotplug.d/iface/90-wrtfreedom /etc/hotplug.d/dhcp/90-wrtfreedom /etc/hotplug.d/usb/90-wrtfreedom /etc/hotplug.d/block/90-wrtfreedom /etc/hotplug.d/button/90-wrtfreedom /etc/hotplug.d/ntp/90-wrtfreedom; do
	set -- "$@" -e "\#^$f\$#d"
done
# un solo passaggio di sed con tutte le righe da togliere
[ -f /etc/sysupgrade.conf ] && sed -i "$@" /etc/sysupgrade.conf
# riavvio di rpcd senza lasciarne due copie: se il vecchio, occupato da richieste lunghe, non si chiude in tempo, procd
# ne avvia un altro e quello vecchio resta appeso con i suoi oggetti ubus (LuCI e app non rispondono più)
rpcd_restart() { /etc/init.d/rpcd stop; i=0; while pidof rpcd >/dev/null && [ $i -lt 5 ]; do sleep 1; i=$((i+1)); done
	for p in $(pidof rpcd); do kill -9 $p 2>/dev/null; done; /etc/init.d/rpcd start; }
say "Riavvio rpcd"
rm -rf /usr/share/wrtfreedom
rpcd_restart
say "OK rimosso"
