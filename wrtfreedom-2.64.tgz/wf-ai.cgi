#!/usr/bin/ucode
'use strict';
/* WrtFreedom: risposta dell'Assistente IA mentre la scrive (pacchetto 2.60), /cgi-bin/wf-ai?sid=<sessione>[&id=<id>][&from=<byte>]
   Invece di chiedere aiget ogni mezzo secondo, il telefono apre UN collegamento e il router gli spedisce una riga JSON
   ogni volta che /tmp/wf-ai/ans.json cambia: {id, text (solo il pezzo nuovo), len, done, err, errk, ask, local, items,
   since, src, alt, wait} (stessi campi di aiget). from = byte già ricevuti; id = quello di aiask (diverso o file
   sparito: lost). Solo con una sessione valida (stesso permesso di wrtfreedom.aiget); nessun segreto passa di qui.
   Finisce con la risposta (done) o dopo 55 s (uhttpd ferma gli script a 60 s: l'app ne riapre un altro).
   2.62: ogni riga è il risultato di aiget (una sola regola per lost, lavoro vivo e testi nella lingua dell'app).
   2.64: controllo ogni ~100 ms (prima 250: solo stat del file, aiget solo quando cambia) e riga nuova anche quando cambia
   lo stato dal vivo (st); a risposta finita la riga ha i tempi (tm). */
import { readfile, stat, stdout, popen } from 'fs';

function out(s) { stdout.write(s); stdout.flush(); }
function param(k) { let m = match(getenv('QUERY_STRING') ?? '', regexp('(^|&)' + k + '=([^&]*)')); return m ? m[2] : ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function ub(o, m, a) {
	let p = popen('ubus -t 10 call ' + o + ' ' + m + ' ' + q(sprintf('%J', a)) + ' 2>/dev/null', 'r'), r = null;
	if (p) { try { r = json(p.read('all')); } catch (e) {} p.close(); }
	return r;
}
/* lingua scelta nell'app (wrtfreedom.ui.lang) letta dal file, solo per gli errori */
function en() {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?ui'?[[:blank:]]*$/) != null; continue; }
		if (s && match(l, /^[[:blank:]]*option lang '?en'?[[:blank:]]*$/)) return true;
	}
	return false;
}
function err(st, it, e) {
	out('Status: ' + st + '\r\nContent-Type: text/plain\r\n\r\n' + (en() ? e : it) + '\n');
	exit(0);
}

let sid = param('sid'), id = param('id'), start = +param('from') || 0;
if (!match(sid, /^[0-9a-f]{32}$/) || (length(id) && !match(id, /^[0-9a-f]{8}$/)) || start < 0)
	err('400 Bad Request', 'parametri non validi', 'invalid parameters');
let a = ub('session', 'access', { ubus_rpc_session: sid, scope: 'ubus', object: 'wrtfreedom', 'function': 'aiget' });
if (!a || !a.access)
	err('403 Forbidden', 'accesso negato', 'access denied');
out('Status: 200 OK\r\nContent-Type: application/x-ndjson\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nX-Accel-Buffering: no\r\n\r\n');
/* aiget (dal byte già mandato) si chiede quando ans.json cambia (inode, dimensione, data), comunque ogni secondo (lavoro
   fermato: lost) e all'ultima riga */
let c0 = clock(), last = '', pos = start, fk = null, tc = 0, r = null;
while (true) {
	let c = clock(), ms = (c[0] - c0[0]) * 1000 + int((c[1] - c0[1]) / 1000000), st = stat('/tmp/wf-ai/ans.json');
	let k0 = st ? st.inode + ':' + st.size + ':' + st.mtime : '';
	if (r == null || k0 != fk || ms - tc >= 1000 || ms > 55000) {
		fk = k0; tc = ms;
		let x = ub('wrtfreedom', 'aiget', length(id) ? { id: id, from: pos } : { from: pos });
		if (x && !x.error) r = x;
		else if (r == null) r = { id: length(id) ? id : null, none: true, lost: length(id) > 0, done: true, errk: length(id) ? 'lost' : null };
	}
	let k = sprintf('%J', [ r.len, r.done, r.errk, r.ask?.id, length(r.src ?? []), r.st?.k, r.st?.t ]);
	if (k != last || ms > 55000) {
		last = k;
		out(sprintf('%J\n', r));
		if (r.len != null) pos = r.len;
	}
	if (r.done || ms > 55000)
		break;
	sleep(100);
}
