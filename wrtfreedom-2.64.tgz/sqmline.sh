# WrtFreedom: interfacce giuste per SQM e cake-autorate (pacchetto 2.44, richiesta dell'utente: «quando si installano
# devono prendere le interfacce giuste, universalmente»). Cambia solo le interfacce (e, per una regola appena spostata
# sulla rete di casa, il verso di download e upload): le velocità scelte restano.
#  - una regola di SQM già accesa si rispetta sempre: è la scelta dell'utente;
#  - linea via cavo o PPPoE: SQM sulla linea (dispositivo della rotta predefinita della tabella principale);
#  - linea mobile (modemmanager, qmi, mbim, ncm, 3g, wwan): SQM sulla rete di casa (br-lan). Sul modem SQM deve creare
#    la ifb del download e con alcuni driver (Quectel su PCIe del GL-X3000) il router si bloccava o si riavviava.
#    Sulla rete di casa i versi sono al contrario: «download» di SQM = upload della linea, «upload» = download.
# uso: sqmline.sh sqm   regola di SQM sull'interfaccia giusta (dopo l'installazione di sqm-scripts)
#      sqmline.sh ar    cake-autorate sull'interfaccia della regola accesa (o quella giusta): ul_if e dl_if
#      sqmline.sh ar <interfaccia>   cake-autorate su quell'interfaccia (dalla pagina SQM dell'app)
LOG() { echo "## $*"; }
# configurazione di cake-autorate: cartella letta dal suo servizio (/etc/init.d/cake-autorate), poi i posti soliti
arconf() { for d in $(grep -o "/[A-Za-z0-9._/-]*cake-autorate/" /etc/init.d/cake-autorate 2>/dev/null) /root/cake-autorate/ /usr/share/cake-autorate/ /opt/cake-autorate/; do
	[ -f "${d}config.primary.sh" ] && { echo "${d}config.primary.sh"; return; }; done; }
D=$(ip -4 route show default table main 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n 1)
J=$(ubus call network.interface dump 2>/dev/null)
P=$(echo "$J" | jsonfilter -e "@.interface[@.l3_device='$D'].proto" 2>/dev/null | head -n 1)
H=$(echo "$J" | jsonfilter -e "@.interface[@.interface='lan'].l3_device" 2>/dev/null | head -n 1); [ -n "$H" ] || H=br-lan
# interfaccia giusta per SQM su questo router
case "$P" in modemmanager|qmi|mbim|ncm|3g|wwan) T=$H ;; *) T=$D ;; esac
Q=$(uci -q show sqm | sed -n "s/^sqm\.\([^.]*\)=queue$/\1/p")
# interfaccia della prima regola accesa, se c'è
ON=""; for s in $Q; do [ "$(uci -q get sqm.$s.enabled)" = 1 ] && { ON=$(uci -q get sqm.$s.interface); break; }; done
case "$1" in
sqm)
	[ -n "$T" ] || { LOG "Linea verso internet non trovata: interfaccia di SQM da scegliere nell'app"; exit 0; }
	[ -n "$ON" ] && { LOG "SQM ha già una regola accesa ($ON): resta com'è"; exit 0; }
	for s in $Q; do [ "$(uci -q get sqm.$s.interface)" = "$T" ] && { LOG "SQM è già su $T"; exit 0; }; done
	s=$(echo "$Q" | head -n 1)
	if [ -z "$s" ]; then s=$(uci add sqm queue); uci set sqm.$s.enabled=0; uci set sqm.$s.qdisc=cake; uci set sqm.$s.script=piece_of_cake.qos; fi
	# regola spostata dalla linea alla rete di casa: download e upload si scambiano, così le velocità restano le stesse
	case "$T" in br-*) case "$(uci -q get sqm.$s.interface)" in br-*) ;; *)
		dl=$(uci -q get sqm.$s.download); ul=$(uci -q get sqm.$s.upload)
		[ -n "$dl" ] && uci set sqm.$s.upload="$dl"; [ -n "$ul" ] && uci set sqm.$s.download="$ul" ;; esac ;; esac
	uci set sqm.$s.interface="$T" && uci commit sqm && LOG "SQM su $T" ;;
ar)
	F=$(arconf)
	[ -n "$F" ] || exit 0
	I=${2:-${ON:-$T}}
	echo "$I" | grep -qE '^[A-Za-z0-9._@-]{1,15}$' || { LOG "Interfaccia di cake-autorate da scegliere nell'app"; exit 0; }
	# nome dell'interfaccia del download come la crea SQM: ifb4 + interfaccia, al massimo 15 caratteri
	B=$(printf 'ifb4%s' "$I" | head -c 15)
	# sulla linea: upload = interfaccia, download = ifb; sulla rete di casa (br-…) al contrario
	U=$I; W=$B; case "$I" in br-*) U=$B; W=$I ;; esac
	# configurazione da uci (launcher di cake-autorate) oppure il file config.primary.sh
	if uci -q show cake-autorate >/dev/null 2>&1; then
		for c in $(uci -q show cake-autorate | sed -n "s/^cake-autorate\.\([^.]*\)\.enabled=.*/\1/p"); do uci set cake-autorate.$c.ul_if="$U"; uci set cake-autorate.$c.dl_if="$W"; done
		uci commit cake-autorate
	fi
	for k in ul_if dl_if; do v=$U; [ $k = dl_if ] && v=$W
		if grep -q "^$k=" "$F"; then sed -i "s/^$k=[^ #]*/$k=$v/" "$F"; else echo "$k=$v" >> "$F"; fi
	done
	LOG "cake-autorate: upload $U, download $W" ;;
*) echo "uso: sqmline.sh sqm | ar [interfaccia]"; exit 1 ;;
esac
exit 0
