#!/bin/sh
# WrtFreedom: backup completo e ripristino sicuro (pacchetto 2.40, scelta dell'utente: «completo al 100%, zero rischi»)
# uso: backup.sh create [file] [tg]     backup completo, verificato dopo la creazione (JSON); tg = copia da mandare su
#                                       Telegram, senza Cose Da Ricordare (2.62)
#      backup.sh inspect [file]         controlla il file e dice cosa contiene, per categoria (JSON)
#      backup.sh restore <file> <c,c>   ripristina le categorie scelte senza riavvio; prima salva la situazione attuale e,
#                                       se entro 120 s non arriva «confirm», rimette tutto com'era da solo
#      backup.sh confirm                tiene il ripristino (niente ritorno)
#      backup.sh pkgs [file]            pacchetti del backup che ora mancano, uno per riga
# Completo = l'elenco standard di OpenWrt (sysupgrade -l: /etc/config, file conservati, sysupgrade.conf) più quello che
# sysupgrade non prende: ethers, repository aggiunti, file caricati da LuCI, crontab, certificati, configurazione e
# certificati di AdGuard Home (percorsi letti dal suo file). Dentro: la scheda etc/wrtfreedom/backup.json (modello,
# versione di OpenWrt, data, numero di file) e l'elenco dei pacchetti installati dall'utente (backup-pkgs.txt), che
# dopo un ripristino si reinstallano nelle versioni del firmware di quel momento. Formato standard .tar.gz: si
# ripristina anche da LuCI o con sysupgrade -r.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
umask 077
W=/usr/share/wrtfreedom; D=/tmp/wf-backup; MF=/etc/wrtfreedom/backup.json; PF=/etc/wrtfreedom/backup-pkgs.txt
PEND=/tmp/wf-restore.pending; PRE=$D/prima-del-ripristino.tar.gz
mkdir -p $D /etc/wrtfreedom
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
js() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r'; }	# testo sicuro dentro una stringa JSON
err() { printf '{"error":"%s"}\n' "$(js "$1")"; exit 1; }

adgyaml() { for y in $(uci -q get adguardhome.config.config) /etc/adguardhome/adguardhome.yaml /etc/adguardhome.yaml /opt/AdGuardHome/AdGuardHome.yaml; do [ -f "$y" ] && { echo "$y"; return; }; done; }
adginit() { for s in adguardhome AdGuardHome; do [ -x /etc/init.d/$s ] && { echo $s; return; }; done; }
pm() { command -v apk >/dev/null && echo apk || echo opkg; }
# pacchetti installati dall'utente: quelli chiesti in più rispetto al firmware
userpkgs() {
	if [ "$(pm)" = apk ]; then
		[ -f /etc/apk/world ] || return 0
		if [ -f /rom/etc/apk/world ]; then grep -vxFf /rom/etc/apk/world /etc/apk/world; else cat /etc/apk/world; fi
	else
		awk '/^Package:/{p=$2} /^Status:/ && / user /{print p}' /usr/lib/opkg/status 2>/dev/null |
		while read -r p; do grep -qx "Package: $p" /rom/usr/lib/opkg/status 2>/dev/null || echo "$p"; done
	fi | sed 's/[<>=~].*//' | grep -E '^[A-Za-z0-9._+-]+$' | sort -u
}
hasp() { if [ "$(pm)" = apk ]; then apk info -e "$1" >/dev/null 2>&1; else opkg status "$1" 2>/dev/null | grep -q '^Status:.* installed'; fi; }
# file in più rispetto a sysupgrade -l
extras() {
	for f in /etc/ethers /etc/opkg/customfeeds.conf /etc/apk/repositories.d/customfeeds.list; do [ -f "$f" ] && echo "$f"; done
	for d in /etc/luci-uploads /etc/crontabs /etc/ssl/acme /etc/acme /etc/adguardhome; do [ -d "$d" ] && find "$d" -type f 2>/dev/null; done
	Y=$(adgyaml)
	if [ -n "$Y" ]; then
		echo "$Y"
		for k in certificate_path private_key_path; do
			p=$(sed -n "s/^ *$k: *['\"]\{0,1\}\([^'\"]*\)['\"]\{0,1\} *$/\1/p" "$Y" | head -n 1)
			[ -n "$p" ] && [ -f "$p" ] && echo "$p"
		done
	fi
}
# chiavi dell'Assistente IA (2.60, ai-<fornitore>.key) mai nella copia: può andare su Telegram; dopo un ripristino si riscrivono.
# Cose Da Ricordare (2.62, ai-mem.json; 2.64 anche i voti ai-votes.json): nella copia locale sì, in quella per Telegram (NOF con «tg») no
NOF='^/etc/wrtfreedom/ai-[A-Za-z0-9_]*\.key$'
filelist() { { sysupgrade -l 2>/dev/null; extras; echo $MF; echo $PF; } | grep '^/' | grep -vE "$NOF" | sort -u | while read -r f; do { [ -f "$f" ] || [ -L "$f" ]; } && echo "$f"; done; }

# categoria di un file (percorso con / iniziale). «wfpkg» = codice del Pacchetto Router: non si ripristina mai (un
# backup vecchio rimetterebbe una versione vecchia), si aggiorna con il pacchetto
cat_of() {
	case "$1" in
	/usr/share/wrtfreedom/*|/www/wrtfreedom/*|/usr/share/rpcd/ucode/wrtfreedom.uc|/usr/share/rpcd/acl.d/wrtfreedom.json|/usr/libexec/rpcd/wrtfreedom.wait|/www/cgi-bin/wf-live|/www/cgi-bin/wf-ai|/www/cgi-bin/wf-me|/etc/init.d/wrtfreedom|/etc/hotplug.d/*/90-wrtfreedom|/usr/share/ucode/luci/template/themes/wrtfreedom/*|/www/luci-static/wrtfreedom*) echo wfpkg ;;
	$MF|$PF) echo wfpkg ;;
	/etc/config/network|/etc/config/dhcp|/etc/config/sqm|/etc/config/mwan3|/etc/ethers|/etc/hosts) echo rete ;;
	/etc/config/wireless) echo wifi ;;
	/etc/config/firewall|/etc/firewall.user|/etc/nftables.d/*|/usr/share/nftables.d/*) echo firewall ;;
	/etc/config/adguardhome|/etc/adguardhome/*|/etc/adguardhome.yaml|*/AdGuardHome.yaml) echo adguard ;;
	/etc/config/ddns|/etc/config/acme|/etc/ssl/acme/*|/etc/acme/*) echo ddns ;;
	/etc/passwd|/etc/shadow|/etc/group|/etc/config/dropbear|/etc/dropbear/*|/etc/config/uhttpd|/etc/config/rpcd|/etc/uhttpd.*) echo accesso ;;
	/etc/config/quectel|/etc/config/modemmanager|/etc/config/qmodem|/etc/config/smstools3) echo modem ;;
	/etc/crontabs/*) echo cron ;;
	/etc/config/wrtfreedom|/etc/wrtfreedom/*) echo wf ;;
	/etc/config/system|/etc/config/luci|/etc/config/fstab|/etc/config/ubootenv|/etc/rc.local|/etc/sysctl.conf|/etc/sysctl.d/*|/etc/profile|/etc/profile.d/*|/etc/shells|/etc/inittab|/etc/sysupgrade.conf|/etc/opkg/*|/etc/apk/*|/etc/luci-uploads/*) echo sistema ;;
	/etc/config/*) echo altre ;;
	*) echo file ;;
	esac
}
CATS="rete wifi firewall adguard ddns accesso modem cron wf sistema altre file"

# servizi da riavviare dopo il ripristino di una categoria (solo quelli che ci sono)
svc() { [ -x "/etc/init.d/$1" ] && /etc/init.d/$1 "${2:-restart}" >/dev/null 2>&1; }
reload_cat() {
	case "$1" in
	firewall) svc firewall reload ;;
	adguard) s=$(adginit); [ -n "$s" ] && svc "$s" ;;
	ddns) svc ddns ;;
	cron) svc cron ;;
	wf) svc wrtfreedom ;;
	sistema) svc system reload; sysctl -p >/dev/null 2>&1; svc led ;;
	altre) # ogni /etc/config/<nome> ripristinato con il suo servizio
		grep '^etc/config/' $D/sel.list | sed 's#^etc/config/##' | while read -r n; do [ "$(cat_of /etc/config/$n)" = altre ] && svc "$n"; done ;;
	esac
}
# per ultimi quelli che possono far cadere il collegamento con l'app
reload_late() {
	case ",$1," in *,rete,*) svc network reload; svc dnsmasq; svc sqm ;; esac
	case ",$1," in *,wifi,*) wifi reload >/dev/null 2>&1 ;; esac
	case ",$1," in *,accesso,*) svc dropbear; svc uhttpd ;; esac
}
# file dell'archivio $1 delle categorie $2 → $D/sel.list (percorsi senza / iniziale)
select_cats() {
	tar tzf "$1" 2>/dev/null | sed 's#^\./##; s#/$##' | while read -r p; do
		[ -n "$p" ] || continue
		c=$(cat_of "/$p"); case ",$2," in *",$c,"*) echo "$p" ;; esac
	done > $D/sel.list
}
apply() { # archivio categorie
	select_cats "$1" "$2"
	[ -s $D/sel.list ] || return 1
	tar xzf "$1" -C / -T $D/sel.list 2>/dev/null || return 1
	for c in $(echo "$2" | tr ',' ' '); do reload_cat "$c"; done
	reload_late "$2"
}

A="$1"; F="${2:-$D/backup.tar.gz}"
[ "$A" = create ] && [ "$3" = tg ] && NOF="$NOF|^/etc/wrtfreedom/ai-mem\.json\$|^/etc/wrtfreedom/ai-votes\.json\$"
case "$A" in
create)
	. /etc/openwrt_release 2>/dev/null
	userpkgs > $PF; [ -f $MF ] || : > $MF
	n=$(filelist | wc -l)
	printf '{"v":1,"t":%s,"host":"%s","model":"%s","board":"%s","release":"%s","revision":"%s","target":"%s","pm":"%s","files":%s,"pkgs":%s,"wf":"%s"}\n' \
		"$(date +%s)" "$(js "$(uci -q get system.@system[0].hostname)")" "$(js "$(cat /tmp/sysinfo/model 2>/dev/null)")" "$(js "$(cat /tmp/sysinfo/board_name 2>/dev/null)")" \
		"$(js "$DISTRIB_RELEASE")" "$(js "$DISTRIB_REVISION")" "$(js "$DISTRIB_TARGET")" "$(pm)" "$n" "$(wc -l < $PF)" "$(js "$(cat $W/VERSION 2>/dev/null)")" > $MF
	filelist | sed 's#^/##' > $D/create.list
	rm -f "$F.t"
	tar czf "$F.t" -C / -T $D/create.list 2>/dev/null || { rm -f "$F.t"; err "$(t "archivio non creato" "archive not created")"; }
	# verifica: l'archivio si apre e contiene tutti i file dell'elenco
	gzip -t "$F.t" 2>/dev/null || { rm -f "$F.t"; err "$(t "archivio rovinato" "corrupted archive")"; }
	got=$(tar tzf "$F.t" 2>/dev/null | grep -vc '/$'); want=$(wc -l < $D/create.list)
	[ "$got" -ge "$want" ] || { rm -f "$F.t"; err "$(t "nell'archivio mancano dei file" "files missing from the archive") ($got/$want)"; }
	tar xzf "$F.t" -O etc/wrtfreedom/backup.json >/dev/null 2>&1 || { rm -f "$F.t"; err "$(t "scheda del backup mancante" "backup manifest missing")"; }
	mv "$F.t" "$F"
	printf '{"ok":true,"file":"%s","size":%s,"files":%s,"pkgs":%s,"sha256":"%s"}\n' "$F" "$(wc -c < "$F")" "$want" "$(wc -l < $PF)" "$(sha256sum "$F" | cut -d' ' -f1)" ;;

inspect)
	[ -f "$F" ] || err "$(t "file mancante" "file missing")"
	gzip -t "$F" 2>/dev/null && tar tzf "$F" > $D/in.list 2>/dev/null || err "$(t "il file non è un backup valido (.tar.gz rovinato o di altro tipo)" "the file is not a valid backup (corrupted or not a .tar.gz)")"
	m=$(tar xzf "$F" -O etc/wrtfreedom/backup.json 2>/dev/null | head -n 1); [ -n "$m" ] || m=null
	. /etc/openwrt_release 2>/dev/null
	o=""; for c in $CATS; do o="$o\"$c\":0,"; done
	cnt=$(sed 's#^\./##; s#/$##' $D/in.list | grep -v '^$' | while read -r p; do cat_of "/$p"; done | sort | uniq -c | awk '{printf "\"%s\":%s,", $2, $1}')
	printf '{"ok":true,"size":%s,"files":%s,"cats":{%s},"manifest":%s,"now":{"model":"%s","board":"%s","release":"%s","revision":"%s"},"pending":%s}\n' \
		"$(wc -c < "$F")" "$(grep -vc '/$' $D/in.list)" "$(echo "$cnt" | sed 's/,$//')" "$m" \
		"$(js "$(cat /tmp/sysinfo/model 2>/dev/null)")" "$(js "$(cat /tmp/sysinfo/board_name 2>/dev/null)")" "$(js "$DISTRIB_RELEASE")" "$(js "$DISTRIB_REVISION")" \
		"$([ -f $PEND ] && echo true || echo false)" ;;

restore)
	C=$(echo "$3" | tr -d ' '); echo "$C" | grep -qE '^[a-z]+(,[a-z]+)*$' || { echo "## ERRORE $(t "categorie non valide" "invalid categories")"; exit 1; }
	for c in $(echo "$C" | tr ',' ' '); do case " $CATS " in *" $c "*) ;; *) echo "## ERRORE $(t "categoria sconosciuta" "unknown category"): $c"; exit 1 ;; esac; done
	[ -f "$F" ] && gzip -t "$F" 2>/dev/null || { echo "## ERRORE $(t "il file di backup non è valido" "the backup file is not valid")"; exit 1; }
	[ -f $PEND ] && { echo "## ERRORE $(t "c'è già un ripristino da confermare" "a restore is already waiting for confirmation")"; exit 1; }
	echo "## $(t "Salvo la situazione attuale" "Saving the current state")"
	sh "$0" create $PRE > $D/pre.json 2>&1; grep -q '"ok":true' $D/pre.json || { echo "## ERRORE $(t "copia della situazione attuale non riuscita: non tocco niente" "could not save the current state: nothing changed")"; exit 1; }
	echo "$C" > $PEND
	echo "## $(t "Ripristino" "Restoring"): $(echo "$C" | sed 's/,/, /g')"
	if ! apply "$F" "$C"; then echo "## ERRORE $(t "nel backup non ci sono file di queste categorie" "the backup has no files in these categories")"; rm -f $PEND; exit 1; fi
	echo "## $(t "File ripristinati" "Files restored"): $(wc -l < $D/sel.list)"
	# ritorno automatico: senza conferma entro 120 s rimette la copia fatta prima (stesse categorie)
	( sleep 120; [ -f $PEND ] || exit 0
	  apply $PRE "$(cat $PEND)"; rm -f $PEND
	  sh $W/event.sh cron restore_undo sys "↩️ $(t "Ripristino del backup annullato: nessuna conferma dall'app, impostazioni rimesse com'erano" "Backup restore undone: no confirmation from the app, settings put back")"
	) >/dev/null 2>&1 </dev/null &
	echo "## OK $(t "in attesa di conferma" "waiting for confirmation")" ;;

confirm)
	[ -f $PEND ] || { echo '{"ok":true,"none":true}'; exit 0; }
	c=$(cat $PEND); rm -f $PEND
	sh $W/event.sh cron restore sys "🗂️ $(t "Backup ripristinato" "Backup restored"): $(echo "$c" | sed 's/,/, /g')" >/dev/null 2>&1
	echo '{"ok":true}' ;;

pkgs)
	[ -f "$F" ] || exit 0
	tar xzf "$F" -O etc/wrtfreedom/backup-pkgs.txt 2>/dev/null | grep -E '^[A-Za-z0-9._+-]+$' | while read -r p; do hasp "$p" || echo "$p"; done ;;

*)	echo "uso: backup.sh create|inspect|restore|confirm|pkgs"; exit 1 ;;
esac
exit 0
