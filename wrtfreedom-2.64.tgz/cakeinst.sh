# WrtFreedom: installa cake-autorate dal suo installer ufficiale (github.com/lynxthecat/cake-autorate)
LOG() { echo "## $*"; }
PM=apk; command -v apk >/dev/null 2>&1 || PM=opkg
LOG "Installo bash e fping"
if [ $PM = apk ]; then apk update >/dev/null 2>&1; apk add bash fping; else opkg update >/dev/null 2>&1; opkg install bash fping; fi || { LOG "ERRORE bash o fping non installati: il router è collegato a internet?"; exit 1; }
for c in tar grep cmp mktemp jsonfilter; do command -v $c >/dev/null 2>&1 || { LOG "ERRORE manca il comando $c sul router"; exit 1; }; done
[ -d /var/run/cake-autorate ] && { LOG "Fermo l'istanza in esecuzione"; /etc/init.d/cake-autorate stop 2>/dev/null; rm -rf /var/run/cake-autorate; }
LOG "Scarico l'installer ufficiale da GitHub"
F=/tmp/cake-autorate_setup.sh
if command -v curl >/dev/null 2>&1; then curl -fsSL -o $F https://raw.githubusercontent.com/lynxthecat/cake-autorate/master/setup.sh; else wget -q -O $F https://raw.githubusercontent.com/lynxthecat/cake-autorate/master/setup.sh; fi || { LOG "ERRORE download non riuscito"; exit 1; }
LOG "Installo cake-autorate (configurazione esistente conservata)"
printf "y\ny\ny\ny\n" | sh $F; rm -f $F
if [ -x /etc/init.d/cake-autorate ] && [ -f /root/cake-autorate/cake-autorate.sh ]; then
	grep -qxF /root/cake-autorate/ /etc/sysupgrade.conf 2>/dev/null || echo /root/cake-autorate/ >> /etc/sysupgrade.conf
	grep -qxF /etc/init.d/cake-autorate /etc/sysupgrade.conf 2>/dev/null || echo /etc/init.d/cake-autorate >> /etc/sysupgrade.conf
	# interfacce giuste subito (l'installatore mette wan / ifb-wan): la linea e la sua ifb4…
	sh /usr/share/wrtfreedom/sqmline.sh ar
	LOG "OK installato: non è ancora attivo, impostalo e avvialo dalla pagina SQM"
else LOG "ERRORE installazione non riuscita"; exit 1; fi
