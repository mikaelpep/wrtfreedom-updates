#!/bin/sh
# WrtFreedom: riceve gli eventi hotplug, li scrive nel registro, manda gli avvisi e lancia le azioni scelte nell'app
# uso: event.sh <sottosistema> (le variabili ACTION, INTERFACE, ... arrivano dall'hotplug)
S="$1"
# eventi hotplug che non finiscono nel registro: si esce subito, prima di leggere data e configurazione
# (stesse condizioni degli agganci in /etc/hotplug.d, scritti da install.sh)
case "$S" in
	iface) [ "$INTERFACE" != loopback ] && case "$INTERFACE" in wgout|wgo[0-9]|wgo[0-9][0-9]) false;; *) true;; esac && {	# wgout, wgo1…: gli avvisi del Servizio VPN li dà vpnctl.uc
		 [ "$ACTION" = ifup ] || [ "$ACTION" = ifdown ]; } || exit 0 ;;
	dhcp) exit 0 ;;	# vecchio aggancio (fino alla 2.41): i dispositivi ora li segue notify.sh (evento «dev»)
	usb) [ "$DEVTYPE" = usb_device ] && { [ "$ACTION" = add ] || [ "$ACTION" = remove ]; } || exit 0 ;;
	block) case "$DEVNAME" in sd*[0-9]|mmcblk*p[0-9]*|nvme*p[0-9]*) ;; *) exit 0;; esac
		[ "$ACTION" = add ] || [ "$ACTION" = remove ] || exit 0 ;;
	button) [ -n "$BUTTON" ] && { [ "$ACTION" = pressed ] || [ "$ACTION" = released ]; } || exit 0 ;;
	ntp) [ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ] || exit 0 ;;
esac
now=$(date +%s)
# configurazione letta una volta (un solo uci export al posto di un uci get per opzione e per regola)
. /lib/functions.sh; config_load wrtfreedom
config_get P ev persist; config_get NC ev notify; config_get L ui lang; config_get AO ai on; config_get AW ai why
LOG=/tmp/wf-events.log; [ "$P" = 1 ] && LOG=/etc/wrtfreedom/events.log
mkdir -p /etc/wrtfreedom
# lingua scelta nell'app: t "italiano" "inglese"
EN=0; [ "$L" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
# Telegram: il messaggio va nella coda (tgq.uc), che lo manda subito o, senza linea, appena torna (2.42).
# Scritto qui e non con ubus: all'accensione rpcd potrebbe non essere ancora pronto
# KB=<mac> (nuovo dispositivo, 2.49): prima riga «#kb:<mac>» = pulsanti «Lo Conosco / Blocca» (tgq.uc)
# $2 = categoria (2.53): riga «#c:<categoria>» per le Ore Silenziose (le categorie scelte passano lo stesso)
tq() { mkdir -p /tmp/wf-tgq; f="/tmp/wf-tgq/$(date +%s)-$$$RANDOM"; { [ -n "$KB" ] && printf '#kb:%s\n' "$KB"; [ -n "$2" ] && printf '#c:%s\n' "$2"; printf '%s' "$1"; } > "$f"; ( ucode /usr/share/wrtfreedom/tgq.uc flush ) </dev/null >/dev/null 2>&1 & }
log() { # tipo|categoria|testo
	echo "$now|$1|$2|$3" >> "$LOG"
	n=$(wc -l < "$LOG"); [ "$n" -gt 550 ] && { tail -n 500 "$LOG" > "$LOG.t" && mv "$LOG.t" "$LOG"; }
	case " $NC " in *" $2 "*) tq "$3" "$2" ;; esac
	rules "$1"
	aiwhy "$1"
}
# Avvisi Spiegati Dall'IA (2.61): per i tipi di avviso, con l'Assistente IA e gli Avvisi Spiegati accesi, ai.uc aggiunge
# due righe a questo evento (in sottofondo: l'avviso parte subito come sempre; tetto, stato e coda li controlla ai.uc)
aiwhy() {
	[ "$AO" = 1 ] && [ "$AW" = 1 ] || return 0
	case "$1" in
		cron_health_*_ok) return 0 ;;
		wan_down|lan_down|vpn_down|cron_net_down|cron_fo_backup|cron_fo_none|cron_signal|cron_vpn_fail|cron_space|cron_temp|cron_adg_down|cron_usage_full|cron_usage_slowerr|cron_sim|cron_simerr|cron_vpnsvc_down|cron_vpnacc|cron_wifi_radar|cron_dev_nft|cron_health_*|wd_modem|wd_reboot|wd_reconnect) ;;
		*) return 0 ;;
	esac
	# un avviso alla volta (2.62): con un altro già in corso (why.lock di meno di 2 minuti) niente processo in attesa
	wl_=$(date -r /tmp/wf-ai/why.lock +%s 2>/dev/null) && [ $((now - wl_)) -le 120 ] && return 0
	( ucode /usr/share/wrtfreedom/ai.uc why "$now" "$1" ) </dev/null >/dev/null 2>&1 &
}
wanifs() { for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do [ "$(uci -q get firewall.$z.name)" = vpnout ] || uci -q get "firewall.$z.network"; done; }	# zona internet vera (con il NAT, mai il nome «wan» fisso)
wgif() { wl_=$(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); for i in $wl_; do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; echo "$wl_" | head -n 1; }	# VPN Per Fuori Casa: con la porta in ascolto, senza il Servizio VPN (come wgiface)
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
act() { # esegue un'azione
	case "$1" in
		modem_restart) ucode /usr/share/wrtfreedom/modemctl.uc restart >/dev/null 2>&1 ;;
		wan_reconnect) for i in $(wanifs); do ifdown "$i"; sleep 3; ifup "$i"; done ;;
		vpn_restart) i=$(wgif); [ -n "$i" ] && ifup "$i" ;;
		vpn_on) i=$(wgif); [ -n "$i" ] && { uci set network.$i.disabled=0; uci commit network; ifup "$i"; } ;;
		vpn_off) i=$(wgif); [ -n "$i" ] && { uci set network.$i.disabled=1; uci commit network; ifdown "$i"; } ;;
		wifi_on) wifi up ;;
		wifi_off) wifi down ;;
		wifi_toggle) if ubus call network.wireless status 2>/dev/null | grep -q '"up": true'; then wifi down; else wifi up; fi ;;
		mount) block mount ;;
		tg) tq "$2" ;;
		cmd) sh -c "$2" >/dev/null 2>&1 ;;
		sqm_on) sh /usr/share/wrtfreedom/sqmctl.sh on >/dev/null 2>&1 ;;	# Controllo Della Linea (2.53)
		sqm_off) sh /usr/share/wrtfreedom/sqmctl.sh off >/dev/null 2>&1 ;;
	esac
}
rule1() { # una regola "Quando … Allora …": $1 = sezione, $2 = evento
	local r=$1 e=$2 on ev a x d lb rm rp pm
	config_get on $r enabled; [ "$on" = 0 ] && return
	config_get ev $r event; [ "$ev" = "$e" ] || return
	# 2.64: regola solo per un dispositivo (mac) o una Persona (person, i suoi dispositivi di adesso): EM = MAC dell'evento
	case "$e" in dev_join|dev_leave)
		config_get rm $r mac; config_get rp $r person; pm=; [ -n "$rp" ] && config_get pm "$rp" mac
		[ -n "$rm$rp" ] && { [ -n "$EM" ] || return; case " $rm $pm " in *" $EM "*) ;; *) return ;; esac; } ;;
	esac
	config_get a $r action; config_get x $r arg; config_get d $r delay 0; config_get lb $r label
	if [ "$d" -gt 0 ]; then
		# azione solo se dopo l'attesa la situazione è ancora quella
		( sleep "$d"; case "$e" in
			wan_down) for i in $(wanifs); do isup "$i" && exit 0; done ;;
			cron_vpnsvc_down) grep -q '"down": *true' /tmp/wf-vpn.json 2>/dev/null || exit 0 ;;
			cron_net_down) [ "$(jsonfilter -i /tmp/wf-line.json -e '@.ok' 2>/dev/null)" = true ] && exit 0 ;;
			vpn_down) i=$(wgif); [ -n "$i" ] && isup "$i" && exit 0 ;;
			if_*_down) i=${e#if_}; isup "${i%_down}" && exit 0 ;;
			if_*_up) i=${e#if_}; isup "${i%_up}" || exit 0 ;;
		  esac
		  echo "$(date +%s)|rule|sys|⚙️ $(t "Azione automatica" "Automatic action"): $lb" >> "$LOG"; act "$a" "$x" ) >/dev/null 2>&1 &
	else
		echo "$now|rule|sys|⚙️ $(t "Azione automatica" "Automatic action"): $lb" >> "$LOG"; act "$a" "$x" &
	fi
}
rules() { config_foreach rule1 rule "$1"; }	# regole per questo evento
case "$S" in
	send)
		act tg "$2" ;;
	act)
		act "$2" "$3" ;;
	test)
		echo "$now|rule|sys|🧪 $(t "Prova azione" "Action test"): $2" >> "$LOG"; act "$2" "$3" ;;
	iface)
		touch /tmp/wf-line.kick	# controllo della linea (line.sh): guarda subito, senza aspettare
		kind=lan; case " $(wanifs) " in *" $INTERFACE "*) kind=wan;; esac; [ "$INTERFACE" = "$(wgif)" ] && kind=vpn
		case "$ACTION" in ifup) rules "if_${INTERFACE}_up";; ifdown) rules "if_${INTERFACE}_down";; esac
		# Limite Di Velocità della rete ospiti (2.48): la rete ripartita perde le code, si rimettono (solo se mancano)
		[ "$ACTION" = ifup ] && { config_get gd guest dl; config_get gu guest ul; [ -n "$gd$gu" ] && ucode /usr/share/wrtfreedom/wifi.uc glimit check >/dev/null 2>&1 & }
		# AdGuard sulla 53 (2.50): una rete di casa accesa può avere un indirizzo nuovo, il bind di AdGuard si rifà se serve
		[ "$ACTION" = ifup ] && [ $kind != wan ] && [ -f /etc/wrtfreedom/adgmode/orig ] && sh /usr/share/wrtfreedom/adgmode.sh rebind >/dev/null 2>&1 &
		case "$ACTION" in
			ifup)
				ip=$(ifstatus "$INTERFACE" 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null)
				# storico dei cambi di IP pubblico (2.53, svc.uc: IP della linea o chiesto fuori casa dalla linea)
				[ $kind = wan ] && ( sleep 5; ucode /usr/share/wrtfreedom/svc.uc ip ) </dev/null >/dev/null 2>&1 &
				case $kind in wan) log wan_up net "$(t "🟢 Linea $INTERFACE tornata" "🟢 Line $INTERFACE back")${ip:+ · IP $ip}";; vpn) log vpn_up net "$(t "🔐 VPN Per Fuori Casa attiva" "🔐 Away From Home VPN up")";; *) log lan_up net "$(t "🟢 Rete $INTERFACE attiva" "🟢 Network $INTERFACE up")";; esac ;;
			ifdown)
				case $kind in wan) log wan_down net "$(t "🔴 Linea $INTERFACE caduta" "🔴 Line $INTERFACE down")";; vpn) log vpn_down net "$(t "🔓 VPN Per Fuori Casa spenta o caduta" "🔓 Away From Home VPN off or down")";; *) log lan_down net "$(t "🔴 Rete $INTERFACE spenta" "🔴 Network $INTERFACE down")";; esac ;;
		esac ;;
	dev)	# da notify.sh: $2 = join, leave o tg (solo Telegram), $3 = MAC, $4 = come è collegato (Wi-Fi 5 GHz, cavo)
		m=$3; ip=; h=
		# nome e indirizzo: assegnazione DHCP, poi indirizzo fisso (dhcp host), poi tabella dei vicini
		l=$(awk -v m="$m" 'tolower($2)==m{print $3" "$4; exit}' /tmp/dhcp.leases 2>/dev/null)
		[ -n "$l" ] && { ip=${l%% *}; h=${l#* }; [ "$h" = "*" ] && h=; }
		[ -n "$h" ] || { s=$(uci -q show dhcp | awk -F= -v m="$m" '$1 ~ /\.mac$/ && index(tolower($2), m) {split($1, a, "."); print a[2]; exit}'); [ -n "$s" ] && { h=$(uci -q get dhcp.$s.name); [ -n "$ip" ] || ip=$(uci -q get dhcp.$s.ip); }; }
		[ -n "$ip" ] || ip=$(ip -4 neigh show 2>/dev/null | awk -v m="$m" 'tolower($5)==m{print $1; exit}')
		h=${h:-$m}; EM=$m; w=$(echo "$4" | tr _ " "); [ $EN = 1 ] && { [ "$w" = cavo ] && w=cable; w=$(echo "$w" | tr , .); }
		case "$2" in
			join)
				# /etc/wrtfreedom/seen: «mac» = conosciuto, «mac ?» = nuovo da confermare (Lo Conosco dall'app o da Telegram)
				if grep -qE "^$m( |\$)" /etc/wrtfreedom/seen 2>/dev/null; then log dev_join dev "📱 $h $(t "si è collegato" "connected")${w:+ · $w}${ip:+ · $ip}"
				else echo "$m ?" >> /etc/wrtfreedom/seen; KB=$m; log dev_new new "🆕 $(t "Nuovo dispositivo" "New device"): $h${w:+ · $w}${ip:+ · $ip}"; KB=
					# Servizio VPN con «solo alcuni dispositivi» e Nuovi Dispositivi Protetti: entra nella VPN
					config_get nd vpnout newdev; [ "$nd" = 1 ] && ucode /usr/share/wrtfreedom/vpnctl.uc newdev "$m" "$ip" "$h" >/dev/null 2>&1 &
				fi ;;
			leave) log dev_leave dev "📴 $h $(t "ha lasciato la rete" "left the network")" ;;
			tg) act tg "📶 $h $(t "si è collegato" "connected")${w:+ ($w)}" ;;
		esac ;;
	usb)
		case "$ACTION" in add) log usb_add usb "🔌 $(t "Dispositivo USB collegato" "USB device connected")${PRODUCT:+ ($PRODUCT)}";; remove) log usb_remove usb "⏏️ $(t "Dispositivo USB scollegato" "USB device disconnected")";; esac ;;
	block)
		case "$ACTION" in add) log disk_add usb "💾 $(t "Chiavetta o disco inserito" "USB stick or drive inserted") ($DEVNAME)";; remove) log disk_remove usb "💾 $(t "Chiavetta o disco tolto" "USB stick or drive removed") ($DEVNAME)";; esac ;;
	button)
		case "$ACTION" in pressed) log "button_${BUTTON}_pressed" button "🔘 $(t "Pulsante $BUTTON premuto" "Button $BUTTON pressed")";; released) log "button_${BUTTON}_released" button "🔘 $(t "Pulsante $BUTTON rilasciato" "Button $BUTTON released")";; esac ;;
	boot)
		log boot sys "🔄 $(t "Router acceso" "Router powered on")" ;;
	upd)	# aggiornamenti dal server (upd.sh): $2 = pkg o app, $3 = testo già nella lingua scelta
		log "upd_$2" sys "$3" ;;
	wd)	# Watchdog Della Linea (watchdog.sh): $2 = tipo di evento, $3 = testo già nella lingua scelta
		log "wd_$2" net "$3" ;;
	cron)	# Pianificazioni (cron.sh): $2 = tipo, $3 = categoria (net, sys…), $4 = testo già nella lingua scelta
		log "cron_$2" "${3:-sys}" "$4" ;;
	ntp)
		[ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ] && { touch /tmp/.wf-ntp; log ntp sys "🕒 $(t "Orologio sincronizzato" "Clock synced")"; } ;;
esac
exit 0
