#!/bin/sh
# WrtFreedom: azioni delle Pianificazioni (preset di «Cosa Fare» nell'app, pacchetto 2.40)
# uso: cron.sh <azione> [valore]
# Ogni azione trova da sola i percorsi di questo router (interfaccia della VPN, servizi DDNS, certificati, file di
# AdGuard Home, LED, ponte della rete di casa), così la riga del crontab resta breve e vale su qualsiasi OpenWrt.
# Gli avvisi vanno negli Eventi (event.sh cron): Telegram e telefono secondo le categorie scelte nell'app.
# I controlli avvisano una volta sola per problema (/tmp/wf-cron.<tipo>), non a ogni giro.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh $W/event.sh cron "$1" "$2" "$3"; }	# tipo categoria testo
quick() { ubus call wrtfreedom quick "{\"act\":\"$1\"${2:+,\"mac\":\"$2\"}}" >/dev/null 2>&1; }
wgif() { wl_=$(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); for i in $wl_; do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; echo "$wl_" | head -n 1; }	# VPN Per Fuori Casa: con la porta in ascolto, senza il Servizio VPN (come wgiface)
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
mac() { echo "$1" | tr 'A-F' 'a-f' | grep -qE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'; }
# un avviso per problema: once <tipo> <secondi> → vero se è passato abbastanza dall'ultimo
once() { f=/tmp/wf-cron.$1; n=$(date +%s); l=$(cat "$f" 2>/dev/null); [ -n "$l" ] && [ $((n - l)) -lt "$2" ] && return 1; echo "$n" > "$f"; }
unflag() { rm -f "/tmp/wf-cron.$1"; }
# soglia di Salute Del Router (2.54): la sola fonte è hth di wrtfreedom.uc (campo th del metodo health); hth <temp|tempbad|disk|diskbad|mem>
hth() { ubus call wrtfreedom health 2>/dev/null | jsonfilter -e "@.th.$1" 2>/dev/null; }
# file al bot collegato nell'app (sendDocument): tgdoc <file> <didascalia>
tgdoc() {
	TK=$(uci -q get wrtfreedom.tg.token); CH=$(uci -q get wrtfreedom.tg.chat)
	[ -n "$TK" ] && [ -n "$CH" ] && command -v curl >/dev/null || return 1
	# 2.62: indirizzo con il token in un file per curl -K (cartella 0700, come tgbot.uc), mai sulla riga di comando
	mkdir -p /tmp/wf-tg.k && chmod 700 /tmp/wf-tg.k || return 1
	K=/tmp/wf-tg.k/c-$$
	( umask 077; printf 'url = "https://api.telegram.org/bot%s/sendDocument"\n' "$TK" > "$K" )
	curl -s -m 60 -F chat_id="$CH" -F "document=@$1" --form-string "caption=$2" -K "$K" >/dev/null; r=$?
	rm -f "$K"; return $r
}
adgyaml() { for y in $(uci -q get adguardhome.config.config) /etc/adguardhome/adguardhome.yaml /etc/adguardhome.yaml /opt/AdGuardHome/AdGuardHome.yaml; do [ -f "$y" ] && { echo "$y"; return; }; done; }
adginit() { for s in adguardhome AdGuardHome; do [ -x /etc/init.d/$s ] && { echo $s; return; }; done; }
# ponte della rete di casa: quello reale dell'interfaccia lan (OpenWrt 19.07…25.x), poi la configurazione
lanbr() { d=$(ifstatus lan 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null); [ -n "$d" ] || d=$(uci -q get network.lan.device); echo "${d:-br-lan}"; }

A="$1"; X="$2"
case "$A" in
# ---------- Router ----------
ledoff)	# salva lo stato di ogni spia (una volta) e le spegne; valore = spie da lasciare come sono, con la virgola (Spie Di Notte)
	S=/tmp/wf-leds.save
	for l in /sys/class/leds/*; do
		[ -d "$l" ] || continue
		case ",$X," in *",${l##*/},"*) continue ;; esac
		[ -f $S ] || echo "${l##*/}|$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$l/trigger")|$(cat "$l/brightness")" >> $S.t
		echo none > "$l/trigger" 2>/dev/null; echo 0 > "$l/brightness" 2>/dev/null
	done
	[ -f $S.t ] && mv $S.t $S ;;
ledon)	# rimette lo stato salvato e le impostazioni LED del router
	S=/tmp/wf-leds.save
	if [ -f $S ]; then
		while IFS='|' read -r n tr b; do
			[ -d "/sys/class/leds/$n" ] || continue
			echo "${tr:-none}" > "/sys/class/leds/$n/trigger" 2>/dev/null
			[ "${tr:-none}" = none ] && echo "${b:-0}" > "/sys/class/leds/$n/brightness" 2>/dev/null
		done < $S
		rm -f $S
	fi
	[ -x /etc/init.d/led ] && /etc/init.d/led restart >/dev/null 2>&1 ;;
memfree) sync; echo 3 > /proc/sys/vm/drop_caches ;;
ntpsync) # client NTP del router: sysntpd (BusyBox), altrimenti chrony o ntpd
	for s in sysntpd chronyd ntpd; do [ -x /etc/init.d/$s ] && { /etc/init.d/$s restart >/dev/null 2>&1; exit 0; }; done ;;
svc)	# riavvia un servizio di /etc/init.d
	echo "$X" | grep -qE '^[A-Za-z0-9_.-]{1,40}$' && [ -x "/etc/init.d/$X" ] || { echo "servizio non valido"; exit 1; }
	/etc/init.d/$X restart >/dev/null 2>&1 ;;
ifrestart) # riavvia un'interfaccia di rete
	echo "$X" | grep -qE '^[A-Za-z0-9_]{1,32}$' && [ "$(uci -q get network.$X)" = interface ] || { echo "interfaccia non valida"; exit 1; }
	ifup "$X" ;;

# ---------- Linea e modem ----------
signalcheck) # avvisa se il segnale del modem è sotto la soglia (RSRP, di serie −110 dBm)
	r=$(ucode -e 'let M=loadfile("/usr/share/wrtfreedom/modem.uc")(),s=M.state().n;print(s.lte?.rsrp ?? s.nr?.rsrp ?? "")' 2>/dev/null)
	[ -n "$r" ] || exit 0; lim=${X:--110}
	r=${r%.*}
	if [ "$r" -lt "$lim" ]; then once signal 7200 && ev signal net "📶 $(t "Segnale scarso" "Weak signal"): $r dBm"; else unflag signal; fi ;;
modemreport) # Rapporto Modem come file al bot
	mkdir -p /tmp/wf-tgfile && chmod 700 /tmp/wf-tgfile
	f=/tmp/wf-tgfile/$(t Rapporto-Modem Modem-Report).txt
	ucode $W/modemctl.uc report > "$f" 2>/dev/null
	tgdoc "$f" "📡 $(t "Rapporto Modem" "Modem Report") · $(uci -q get system.@system[0].hostname)"; rm -f "$f" ;;

# ---------- VPN e DNS ----------
vpncheck) # riattiva la VPN se è giù (non se è spenta apposta)
	i=$(wgif); [ -n "$i" ] || exit 0
	[ "$(uci -q get network.$i.disabled)" = 1 ] && exit 0
	ok() { isup "$i" || return 1; command -v wg >/dev/null || return 0; wg show "$i" >/dev/null 2>&1; }
	ok && { unflag vpn; exit 0; }
	logger -t wrtfreedom-cron "VPN $i giù, la riattivo"
	ifup "$i"; sleep 15
	if ok; then ev vpn_fix net "🔐 $(t "La VPN Per Fuori Casa era spenta: riattivata" "The Away From Home VPN was down: restarted")"
	else once vpn 3600 && ev vpn_fail net "⚠️ $(t "VPN Per Fuori Casa spenta e non riattivabile: controlla il router" "Away From Home VPN down and cannot be restarted: check the router")"; fi ;;
ddnscheck) # IP della linea cambiato: i servizi DDNS si aggiornano subito (una volta per IP)
	[ -x /etc/init.d/ddns ] || exit 0
	dev=$(ip -4 route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n 1)
	IP=$(ip -4 addr show dev "$dev" 2>/dev/null | sed -n 's/.*inet \([0-9.]*\).*/\1/p' | head -n 1)
	[ -n "$IP" ] || exit 0
	[ "$(cat /tmp/wf-cron.ddnsip 2>/dev/null)" = "$IP" ] && exit 0
	same=1
	for s in $(uci -q show ddns | sed -n "s/^ddns\.\([A-Za-z0-9_]*\)=service$/\1/p"); do
		[ "$(uci -q get ddns.$s.enabled)" = 0 ] && continue
		[ "$(cat /var/run/ddns/$s.ip 2>/dev/null)" = "$IP" ] || same=0
	done
	echo "$IP" > /tmp/wf-cron.ddnsip
	( ucode $W/svc.uc ip ) >/dev/null 2>&1 </dev/null &	# storico dei cambi di IP (2.53)
	[ $same = 1 ] && exit 0
	/etc/init.d/ddns restart >/dev/null 2>&1
	ev ddns net "🌐 $(t "Nuovo IP della linea" "New line IP") $IP: $(t "nomi DDNS aggiornati" "DDNS names updated")" ;;
certrenew) [ -x /etc/init.d/acme ] && /etc/init.d/acme renew >/dev/null 2>&1 ;;
certadg) # certificato del nome di AdGuard Home (acme) copiato nei percorsi di AdGuard, solo se è cambiato
	Y=$(adgyaml); [ -n "$Y" ] || exit 0
	g() { sed -n "s/^ *$1: *['\"]\{0,1\}\([^'\"]*\)['\"]\{0,1\} *$/\1/p" "$Y" | head -n 1; }
	C=$(g certificate_path); K=$(g private_key_path); N=$(g server_name)
	[ -n "$C" ] && [ -n "$K" ] && [ -n "$N" ] || exit 0
	for d in /etc/ssl/acme /etc/acme/$N /etc/acme/${N}_ecc; do
		[ -f "$d/$N.fullchain.crt" ] && { SC=$d/$N.fullchain.crt; SK=$d/$N.key; break; }
		[ -f "$d/fullchain.cer" ] && { SC=$d/fullchain.cer; SK=$d/$N.key; break; }
	done
	[ -n "$SC" ] && [ -f "$SK" ] || exit 0
	cmp -s "$SC" "$C" && cmp -s "$SK" "$K" && exit 0
	mkdir -p "$(dirname "$C")" "$(dirname "$K")"
	cp -L "$SC" "$C" && cp -L "$SK" "$K" && chmod 600 "$K"
	s=$(adginit); [ -n "$s" ] && /etc/init.d/$s restart >/dev/null 2>&1
	ev cert sys "🔐 $(t "Certificato aggiornato in AdGuard Home" "Certificate updated in AdGuard Home") ($N)" ;;
adgrestart) s=$(adginit); [ -n "$s" ] && /etc/init.d/$s restart >/dev/null 2>&1 ;;
adgpause) quick adg_off ;;
adgon) quick adg_on ;;
vpnoff) sh $W/event.sh act vpn_off ;;
vpnon) sh $W/event.sh act vpn_on ;;
# Servizio VPN (2.42): stessa strada dell'app (ubus), così regole e blocco restano giusti
vpnsvcon) ubus call wrtfreedom vpnout '{"action":"onoff","on":true}' >/dev/null 2>&1 ;;
vpnsvcoff) ubus call wrtfreedom vpnout '{"action":"onoff","on":false}' >/dev/null 2>&1 ;;
vpnsvcnext) ucode $W/vpnctl.uc rotate ;;
vpnsvcresume) # fine della Pausa Del Servizio VPN (2.52, da notify.sh): tornano accesi i collegamenti accesi prima
	ubus call wrtfreedom vpnout '{"action":"resume"}' >/dev/null 2>&1 ;;
# VPN Per Fuori Casa (2.52): Dispositivi Con Scadenza e Orari Per Dispositivo (righe del crontab # wf:wgexp, # wf:wgp_…)
wgexp) ucode $W/wgx.uc exp >/dev/null 2>&1 ;;
wgpeeron|wgpeeroff)
	echo "$X" | grep -qE '^[A-Za-z0-9_]{1,40}$' || { echo "dispositivo non valido"; exit 1; }
	a=resume; [ "$A" = wgpeeroff ] && a=pause
	ubus call wrtfreedom wgpeer "{\"action\":\"$a\",\"id\":\"$X\"}" >/dev/null 2>&1 ;;
guestoff) quick guest_off ;;
gueston) quick guest_on ;;
# ---------- Wi-Fi (2.48) ----------
guestpwd) # password nuova della rete ospiti (subito se è spenta, altrimenti quando si spegne)
	ubus call wrtfreedom wifiguest '{"action":"rot"}' >/dev/null 2>&1 ;;
guestend) # ospiti a tempo scaduti (da notify.sh)
	ubus call wrtfreedom wifiguest '{"action":"end"}' >/dev/null 2>&1 ;;
wifichan) # Canale Automatico di notte per le radio scelte nell'app (mai canali DFS)
	ucode $W/wifi.uc night >/dev/null 2>&1 ;;
txlow|txnorm) # Potenza Di Notte: subito con iw (niente riavvio, niente scritture); txnorm senza valore = quella della configurazione
	command -v iw >/dev/null || exit 0
	if [ -n "$X" ] || [ "$A" = txlow ]; then
		echo "$X" | grep -qE '^[0-9]{1,2}$' && [ "$X" -ge 1 ] && [ "$X" -le 30 ] || { echo "potenza non valida (1…30 dBm)"; exit 1; }
	fi
	S=$(ubus call network.wireless status 2>/dev/null)
	for r in $(uci -q show wireless | sed -n "s/^wireless\.\([A-Za-z0-9_]*\)=wifi-device$/\1/p"); do
		i=$(echo "$S" | jsonfilter -e "@.$r.interfaces[0].ifname" 2>/dev/null); [ -n "$i" ] && [ -d "/sys/class/net/$i" ] || continue
		if [ "$A" = txlow ] || [ -n "$X" ]; then v="fixed ${X}00"
		else p=$(uci -q get wireless.$r.txpower); case "$p" in ''|*[!0-9]*) v=auto ;; *) v="fixed ${p}00" ;; esac; fi
		iw dev "$i" set txpower $v 2>/dev/null
	done ;;
txradio) # 2.64 una radio sola (wifinet, Assistente IA): la potenza della configurazione subito con iw, senza riavvio; radio
	# anonima (@wifi-device[0]), senza iw o senza la sua interfaccia accesa = wifi reload (la configurazione vale lo stesso)
	command -v iw >/dev/null && echo "$X" | grep -qE '^[A-Za-z0-9_]{1,32}$' || { wifi reload; exit 0; }
	i=$(ubus call network.wireless status 2>/dev/null | jsonfilter -e "@.$X.interfaces[0].ifname" 2>/dev/null); [ -n "$i" ] && [ -d "/sys/class/net/$i" ] || { wifi reload; exit 0; }
	p=$(uci -q get wireless.$X.txpower); case "$p" in ''|*[!0-9]*) v=auto ;; *) v="fixed ${p}00" ;; esac
	iw dev "$i" set txpower $v 2>/dev/null ;;
dnsflush) # DNS del router: dnsmasq, altrimenti unbound o smartdns
	for s in dnsmasq unbound smartdns; do [ -x /etc/init.d/$s ] && /etc/init.d/$s restart >/dev/null 2>&1; done ;;

# ---------- Dispositivi ----------
block|unblock) mac "$X" || { echo "dispositivo non valido"; exit 1; }; quick "$A" "$(echo "$X" | tr 'A-F' 'a-f')" ;;
wol)	# accende un dispositivo con Wake-on-LAN
	mac "$X" || { echo "dispositivo non valido"; exit 1; }
	if command -v etherwake >/dev/null; then etherwake -i "$(lanbr)" "$X"
	elif command -v ether-wake >/dev/null; then ether-wake -i "$(lanbr)" "$X"
	else echo "manca etherwake"; exit 1; fi ;;

# ---------- Controlli ----------
spacecheck) # memoria del router quasi piena (di serie la soglia «Quasi Pieno» di Salute Del Router)
	[ "$(uci -q get wrtfreedom.health.al_disk)" = 0 ] || exit 0	# Avvisi Di Salute accesi: l'avviso lo manda già health.uc
	m=/overlay; grep -q " /overlay " /proc/mounts || m=/	# x86 o router con disco: niente overlay
	p=$(df "$m" 2>/dev/null | awk 'NR==2{gsub("%","",$5);print $5}'); [ -n "$p" ] || exit 0; lim=${X:-$(hth disk)}; [ -n "$lim" ] || exit 0
	if [ "$p" -ge "$lim" ]; then once space 43200 && ev space sys "💾 $(t "Memoria del router quasi piena" "Router storage almost full"): $p%"; else unflag space; fi ;;
tempcheck) # temperatura più alta dei sensori del router (di serie la soglia «Molto Alta» di Salute Del Router)
	[ "$(uci -q get wrtfreedom.health.al_temp)" = 0 ] || exit 0	# Avvisi Di Salute accesi: l'avviso lo manda già health.uc

	m=0; for z in /sys/class/thermal/thermal_zone*/temp; do [ -f "$z" ] || continue; v=$(( $(cat "$z") / 1000 )); [ $v -gt $m ] && m=$v; done
	[ $m -gt 0 ] || exit 0; lim=${X:-$(hth tempbad)}; [ -n "$lim" ] || exit 0
	if [ $m -ge "$lim" ]; then once temp 7200 && ev temp sys "🌡️ $(t "Router molto caldo" "Router very hot"): $m °C"; else unflag temp; fi ;;

# ---------- Manutenzione ----------
updcheck) sh $W/upd.sh notify >/dev/null 2>&1 ;;
pkgupd) sh $W/upd.sh install tg >/dev/null 2>&1 ;;
pkglist) if command -v apk >/dev/null; then apk update >/dev/null 2>&1; else opkg update >/dev/null 2>&1; fi ;;
trafficsave) command -v nlbw >/dev/null && nlbw -c commit >/dev/null 2>&1 ;;

# ---------- Controllo Della Linea (2.53) ----------
sqmon) sh $W/sqmctl.sh on >/dev/null ;;
sqmoff) sh $W/sqmctl.sh off >/dev/null ;;
sqmp)	# profilo per orario (righe # wf:sqmp_<id>, metodo sqmsched)
	echo "$X" | grep -qE '^[a-z0-9]{1,12}$' || { echo "profilo non valido"; exit 1; }
	sh $W/sqmctl.sh prof "$X" >/dev/null ;;
# ---------- Router Spento? (2.53) ----------
hb)	# richiesta all'indirizzo scelto (riga # wf:hb): l'indirizzo resta in uci, a curl arriva da stdin (mai nei processi)
	U=$(uci -q get wrtfreedom.hb.url); [ -n "$U" ] || exit 0
	echo "$U" | grep -qE "^https?://[^ '\"\]+$" || exit 1
	# solo curl: l'indirizzo arriva da stdin (printf è della shell); uclient-fetch lo vorrebbe nella riga di comando
	command -v curl >/dev/null || exit 1
	c=$(printf 'url = "%s"\n' "$U" | curl -s -o /dev/null -m 15 --retry 2 -w '%{http_code}' -K - 2>/dev/null)
	c=$(echo "$c" | tr -cd 0-9 | head -c 3 | sed 's/^0*//'); [ -n "$c" ] || c=0
	ok=false; case "$c" in 2??|3??) ok=true;; esac
	printf '{"t":%s,"ok":%s,"code":%s}\n' "$(date +%s)" "$ok" "$c" > /tmp/wf-hb.json.t && mv /tmp/wf-hb.json.t /tmp/wf-hb.json ;;

# ---------- Telegram ----------
bot)	# un Comando Pronto del bot, risultato su Telegram
	echo "$X" | grep -qE '^[a-z0-9_]{1,40}$' || { echo "comando non valido"; exit 1; }
	ucode $W/tgbot.uc run "$X" >/dev/null 2>&1 ;;
weekly) # Riepilogo Settimanale (2.50): consumo, bloccati da AdGuard, dispositivi nuovi, cadute della linea
	ucode $W/netx.uc weekly >/dev/null 2>&1 ;;
monthly) # Consumo Del Mese Su Telegram (2.59, riga # wf:monthly): i primi dispositivi del mese (valore = quanti, 1…10)
	echo "${X:-5}" | grep -qE '^([1-9]|10)$' || { echo "numero non valido (1…10)"; exit 1; }
	ucode $W/dev.uc monthly "${X:-5}" >/dev/null 2>&1 ;;
*)	echo "uso: cron.sh <azione> [valore]"; exit 1 ;;
esac
exit 0
