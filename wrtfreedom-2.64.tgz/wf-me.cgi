#!/usr/bin/ucode
'use strict';
/* WrtFreedom: Giro Della Casa (pacchetto 2.48), /cgi-bin/wf-me?sid=<sessione>[&mac=<MAC>][&iv=<ms>][&once=1]
   Il telefono non conosce il suo MAC (Android e iPhone lo nascondono alle pagine): lo trova il router dall'indirizzo di
   chi chiama (REMOTE_ADDR → tabella dei vicini → MAC). Prima riga {me, ip, mac, own}; once=1 = solo questa riga (per
   sapere il proprio MAC, es. per non staccare sé stessi con wifikick). Poi ogni iv ms (500…2000, di serie 1 s) una riga
   {t, mac, on, if, band, ch, sig, avg, txr, rxr} da «iw dev <if> station get <mac>» sui soli punti di accesso di netifd;
   dispositivo non collegato al Wi-Fi = nuova prova ogni 2,5 s. Una sola lettura alla volta (/tmp/wf-me.lock, scade dopo
   70 s; altrimenti 429). Lavora solo con la pagina aperta: chiusa la pagina la scrittura fallisce e lo script finisce;
   in ogni caso dopo 55 s (uhttpd ferma gli script a 60 s: l'app ne riapre un altro). mac = un altro dispositivo scelto
   nell'app. Solo con una sessione valida (stesso permesso di wrtfreedom.wifi). */
import { readfile, popen, stdout, stat, mkdir, rmdir } from 'fs';

function out(s) { stdout.write(s); stdout.flush(); }
function param(k) { let m = match(getenv('QUERY_STRING') ?? '', regexp('(^|&)' + k + '=([^&]*)')); return m ? m[2] : ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }

let sid = param('sid'), mac = lc(replace(param('mac'), /%3[Aa]/g, ':')), iv = +param('iv') || 1000, once = param('once') == '1';
if (iv < 500 || iv > 2000) iv = 1000;
if (!match(sid, /^[0-9a-f]{32}$/) || (length(mac) && !match(mac, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/))) {
	out('Status: 400 Bad Request\r\nContent-Type: text/plain\r\n\r\nparametri non validi\n');
	exit(0);
}
let a = null;
try { a = json(sh('ubus call session access ' + q(sprintf('%J', { ubus_rpc_session: sid, scope: 'ubus', object: 'wrtfreedom', 'function': 'wifi' })) + ' 2>/dev/null')); } catch (e) {}
if (!a || !a.access) {
	out('Status: 403 Forbidden\r\nContent-Type: text/plain\r\n\r\naccesso negato\n');
	exit(0);
}
/* MAC di chi chiama: IPv4 dalla tabella ARP del kernel (senza processi), IPv6 dai vicini */
let ip = replace(getenv('REMOTE_ADDR') ?? '', /^::ffff:/, ''), me = '';
if (match(ip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) {
	for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) {
		let f = split(trim(l), /[ \t]+/);
		if (f[0] == ip && match(f[3] ?? '', /^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$/) && f[3] != '00:00:00:00:00:00') { me = lc(f[3]); break; }
	}
}
else if (match(ip, /^[0-9a-fA-F:]{2,39}$/)) {
	let m = match(sh('ip -6 neigh show ' + q(ip) + ' 2>/dev/null'), /lladdr ([0-9a-fA-F:]{17})/);
	if (m) me = lc(m[1]);
}
if (!length(mac)) mac = me;
let head = sprintf('%J\n', { me: me || null, ip: ip, mac: mac || null, own: length(mac) > 0 && mac == me });
if (once || !length(mac)) {
	out('Status: 200 OK\r\nContent-Type: application/json\r\nCache-Control: no-store\r\n\r\n' + head);
	exit(0);
}
/* una sola lettura alla volta: blocco con mkdir, ripreso se più vecchio di 70 s (script fermato da uhttpd) */
const LK = '/tmp/wf-me.lock';
if (!mkdir(LK)) {
	let s = stat(LK);
	if (!(s && time() - s.mtime > 70 && rmdir(LK) && mkdir(LK))) {
		out('Status: 429 Too Many Requests\r\nContent-Type: text/plain\r\nRetry-After: 5\r\n\r\nlettura già in corso\n');
		exit(0);
	}
}
out('Status: 200 OK\r\nContent-Type: application/x-ndjson\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nX-Accel-Buffering: no\r\n\r\n' + head);

/* punti di accesso da netifd (pochi: uno o due per radio); quello del dispositivo si cerca di nuovo se cambia rete */
let IFS = [];
try {
	let S = json(sh('ubus call network.wireless status 2>/dev/null'));
	for (let r in S) for (let i in (S[r].interfaces ?? [])) if (i.ifname && (i.config?.mode ?? 'ap') == 'ap' && match(i.ifname, /^[A-Za-z0-9_.-]{1,32}$/)) push(IFS, i.ifname);
} catch (e) {}
function sta(i) { let o = sh('iw dev ' + q(i) + ' station get ' + mac + ' 2>/dev/null'); return index(o, 'Station') >= 0 ? o : null; }
function num(o, k) { let m = match(o, regexp('\n[ \t]*' + k + ':[ \t]*(-?[0-9.]+)')); return m ? +m[1] : null; }
let cur = null, inf = null, c0 = clock();
while (true) {
	let c = clock(), ms = (c[0] - c0[0]) * 1000 + int((c[1] - c0[1]) / 1000000), o = cur ? sta(cur) : null;
	if (!o) {
		cur = null;
		for (let i in IFS) { o = sta(i); if (o) { cur = i; break; } }
		if (cur) {
			let m = match(sh('iw dev ' + q(cur) + ' info 2>/dev/null'), /channel ([0-9]+) \(([0-9]+) MHz\)/);
			inf = m ? { ch: +m[1], band: +m[2] < 2500 ? '2g' : +m[2] >= 5925 ? '6g' : '5g' } : { ch: null, band: null };
		}
	}
	let r = { t: ms, mac: mac, on: o != null };
	if (o) { r.if = cur; r.band = inf.band; r.ch = inf.ch; r.sig = num(o, 'signal'); r.avg = num(o, 'signal avg'); r.txr = num(o, 'tx bitrate'); r.rxr = num(o, 'rx bitrate'); }
	out(sprintf('%J\n', r));
	if (ms > 55000) break;
	sleep(o ? iv : 2500);
}
rmdir(LK);
