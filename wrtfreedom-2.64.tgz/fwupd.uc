// WrtFreedom: c'è un firmware più nuovo? (lanciato in sottofondo dal metodo fwupd, risultato in /tmp/wf-fw.json)
// Fonte scelta da sola, uguale per ogni router:
//  1. firmware personalizzato su GitHub: progetto scritto dall'utente (wrtfreedom.fw.repo) oppure trovato dai feed
//     installati (<autore>.github.io/.../kmods/<build>/): tra i progetti dell'autore quello con la release <build>
//  2. OpenWrt ufficiale snapshot: revisione installata contro version_code di profiles.json del proprio target
//  3. OpenWrt ufficiale stabile: versione installata contro .versions.json (stessa serie e serie nuova)
// Il file da installare è sempre il sysupgrade del proprio modello (board_name con «_» al posto di «,»).
'use strict';
import { popen, readfile, writefile, lsdir, stat, rename } from 'fs';

const OUT = '/tmp/wf-fw.json';
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function get(url) {
	if (stat('/bin/uclient-fetch') || stat('/usr/bin/uclient-fetch'))
		return sh('uclient-fetch -q -T 25 -O - ' + q(url) + ' 2>/dev/null');
	return sh('curl -fsSL -m 30 -A wrtfreedom ' + q(url) + ' 2>/dev/null');
}
function J(url) { let t = get(url); if (!length(t)) return null; try { return json(t); } catch (e) { return null; } }
function kv(f) {
	let r = {};
	for (let l in split(readfile(f) ?? '', '\n')) {
		let m = match(l, /^([A-Z_]+)=(.*)$/);
		if (m) r[m[1]] = replace(replace(trim(m[2]), /^['"]/, ''), /['"]$/, '');
	}
	return r;
}
function rnum(rev) { let m = match('' + rev, /^r(\d+)/); return m ? +m[1] : 0; }
// date ISO (2026-10-01T14:47:51Z) in secondi
function iso(s) {
	let m = match('' + s, /^(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)/);
	if (!m) return 0;
	let y = +m[1], mo = +m[2], d = +m[3];
	if (mo <= 2) { y--; mo += 12; }
	let days = 365 * y + int(y / 4) - int(y / 100) + int(y / 400) + int((153 * (mo - 3) + 2) / 5) + d - 719469;
	return days * 86400 + (+m[4]) * 3600 + (+m[5]) * 60 + (+m[6]);
}
function vcmp(a, b) {
	let x = split('' + a, '.'), y = split('' + b, '.');
	for (let i = 0; i < 3; i++) { let p = +(x[i] ?? 0), r = +(y[i] ?? 0); if (p != r) return p > r ? 1 : -1; }
	return 0;
}

let R = kv('/etc/openwrt_release'), O = kv('/etc/os-release');
let board = trim(readfile('/tmp/sysinfo/board_name') ?? ''), bid = replace(board, ',', '_');
let cur = { version: R.DISTRIB_RELEASE ?? '', revision: R.DISTRIB_REVISION ?? '', target: R.DISTRIB_TARGET ?? '',
	date: +(O.OPENWRT_BUILD_DATE ?? 0), board: board };
let res = { t: time(), cur: cur, kind: '', newer: false, latest: null, err: '' };

// feed installati: autore su GitHub Pages e nome del build (kmods/<build>/)
let feeds = '';
for (let d in ['/etc/apk/repositories.d', '/etc/opkg'])
	for (let f in (lsdir(d) ?? [])) feeds += (readfile(d + '/' + f) ?? '') + '\n';
feeds += (readfile('/etc/apk/repositories') ?? '') + '\n';
let owner = null, tag = null;
for (let l in split(feeds, '\n')) {
	if (match(l, /^\s*#/)) continue;
	let m = match(l, /https?:\/\/([A-Za-z0-9-]+)\.github\.io\/[^\s]*?\/kmods\/([A-Za-z0-9._-]+)\//);
	if (m) { owner = m[1]; tag = m[2]; break; }
}
let repo = trim(sh('uci -q get wrtfreedom.fw.repo'));
// solo per le prove: WF_FW_TEST=snapshot (OpenWrt ufficiale snapshot) o una versione stabile da simulare (es. 24.10.0)
const TEST = getenv('WF_FW_TEST');
if (TEST) { repo = ''; owner = null; tag = null; if (TEST != 'snapshot') cur.version = TEST; }

function asset(rel) {
	let best = null;
	for (let a in (rel.assets ?? [])) {
		let n = a.name ?? '';
		if (!match(n, /sysupgrade/)) continue;
		if (length(bid) && index(n, bid) >= 0) return a;
		if (!best) best = a;
	}
	return best;
}

if (!length(repo) && owner && tag) {
	// tra i progetti dell'autore (i più recenti) quello che ha la release del build installato
	let rs = J('https://api.github.com/users/' + owner + '/repos?per_page=100&sort=pushed') ?? [];
	let n = 0;
	for (let r in rs) {
		if (n++ >= 25) break;
		if (r.fork) continue;
		let rel = J('https://api.github.com/repos/' + r.full_name + '/releases/tags/' + tag);
		if (rel && rel.tag_name == tag) {
			repo = r.full_name;
			sh('uci -q get wrtfreedom.fw >/dev/null || uci set wrtfreedom.fw=firmware; uci set wrtfreedom.fw.repo=' + q(repo) + '; uci set wrtfreedom.fw.auto=1; uci commit wrtfreedom');
			break;
		}
	}
}

if (length(repo)) {
	res.kind = 'github'; res.repo = repo; res.tag = tag;
	let rels = J('https://api.github.com/repos/' + repo + '/releases?per_page=15');
	if (type(rels) != 'array') res.err = 'GitHub non raggiungibile';
	else {
		let L = filter(rels, (r) => !r.draft && !r.prerelease && asset(r));
		let last = L[0];
		if (!last) res.err = 'nessuna release con il firmware per questo modello';
		else {
			let a = asset(last);
			res.latest = { tag: last.tag_name, name: last.name ?? last.tag_name, date: iso(last.published_at), url: last.html_url,
				file: a.browser_download_url, fname: a.name, size: a.size, notes: substr(last.body ?? '', 0, 700) };
			let mine = tag ? filter(L, (r) => r.tag_name == tag)[0] : null;
			if (mine) res.cur.name = mine.name ?? mine.tag_name;
			// con il nome del build installato si confrontano le release; senza, la data di pubblicazione con quella della build
			res.newer = tag ? last.tag_name != tag && (!mine || iso(last.published_at) > iso(mine.published_at))
				: iso(last.published_at) > cur.date + 86400;
			// SHA256SUMS della release, se c'è: il file scaricato si controlla
			for (let x in (last.assets ?? []))
				if (x.name == 'SHA256SUMS' || x.name == 'sha256sums') {
					for (let l in split(get(x.browser_download_url), '\n')) {
						let m = match(l, /^([0-9a-f]{64})\s+\*?(.+)$/);
						if (m && trim(m[2]) == a.name) res.latest.sha256 = m[1];
					}
				}
		}
	}
}
else {
	let base = O.FIRMWARE_URL ?? 'https://downloads.openwrt.org/';
	if (substr(base, -1) != '/') base += '/';
	let snap = match(cur.version, /SNAPSHOT/);
	if (snap) {
		res.kind = 'snapshot';
		let dir = base + (cur.version == 'SNAPSHOT' ? 'snapshots/' : 'releases/' + cur.version + '/') + 'targets/' + cur.target + '/';
		let p = J(dir + 'profiles.json');
		if (!p) res.err = 'server di OpenWrt non raggiungibile';
		else {
			let img = null;
			for (let i in (p.profiles?.[bid]?.images ?? [])) if (i.type == 'sysupgrade') img = i;
			res.latest = { tag: p.version_code, name: 'OpenWrt ' + (p.version_number ?? cur.version) + ' ' + p.version_code,
				url: dir, file: img ? dir + img.name : null, fname: img?.name, sha256: img?.sha256 };
			res.newer = rnum(p.version_code) > rnum(cur.revision);
			if (!img) res.err = 'nessun firmware per ' + board + ' in questa build';
		}
	}
	else {
		res.kind = 'stable';
		let V = J('https://downloads.openwrt.org/.versions.json');
		if (!V) res.err = 'server di OpenWrt non raggiungibile';
		else {
			let ser = join('.', slice(split(cur.version, '.'), 0, 2)), best = null, major = V.stable_version;
			for (let v in (V.versions_list ?? [])) {
				if (match(v, /rc|SNAPSHOT/)) continue;
				if (index(v, ser + '.') == 0 && vcmp(v, cur.version) > 0 && (!best || vcmp(v, best) > 0)) best = v;
			}
			let nv = best ?? (major && vcmp(major, cur.version) > 0 ? major : null);
			res.major = !best && nv != null;
			if (nv) {
				let dir = base + 'releases/' + nv + '/targets/' + cur.target + '/', p = J(dir + 'profiles.json'), img = null;
				for (let i in (p?.profiles?.[bid]?.images ?? [])) if (i.type == 'sysupgrade') img = i;
				res.latest = { tag: nv, name: 'OpenWrt ' + nv, url: dir, file: img ? dir + img.name : null, fname: img?.name, sha256: img?.sha256 };
				res.newer = true;
				if (!img) res.err = 'nessun firmware per ' + board + ' nella ' + nv;
			}
			else res.latest = { tag: cur.version, name: 'OpenWrt ' + cur.version };
		}
	}
}

writefile(OUT + '.t', sprintf('%J', res));
rename(OUT + '.t', OUT);
