#!/bin/sh
# WrtFreedom: aggiornamenti dal server, firmati (usign, la stessa firma di OpenWrt)
# uso: upd.sh check            scarica latest.json e la firma, li verifica → /tmp/wf-upd.json (solo se la firma è giusta)
#      upd.sh install [tg]     scarica il Pacchetto Router, controlla sha256 e installa (tg = esito anche su Telegram)
#      upd.sh notify           controllo periodico: evento «disponibile» una volta per versione
#      upd.sh status           versione installata, disponibile e app (testo per il bot)
# permessi normali per quello che si crea: lanciato dall'app passa da rpcd, che ha umask 077, e la web app in
# /www/wrtfreedom diventava leggibile solo da root (Forbidden)
umask 022
BASE=$(uci -q get wrtfreedom.upd.url); BASE=${BASE:-https://raw.githubusercontent.com/mikaelpep/wrtfreedom-updates/main}
W=/usr/share/wrtfreedom; PUB=$W/wrtfreedom-upd.pub; D=/tmp/wf-upd; OUT=/tmp/wf-upd.json; ERR=/tmp/wf-upd.err
mkdir -p $D
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
# a è più nuova di b? (versioni con i punti: 2.9 < 2.10)
newer() { [ -n "$1" ] && [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -t. -k1,1n -k2,2n -k3,3n | tail -n 1)" = "$1" ]; }
get() { # url file
	rm -f "$2"
	if command -v uclient-fetch >/dev/null 2>&1; then uclient-fetch -q -T 30 -O "$2" "$1" >/dev/null 2>&1
	elif command -v curl >/dev/null 2>&1; then curl -fsSL -m 300 -o "$2" "$1" >/dev/null 2>&1
	else wget -q -T 30 -O "$2" "$1" >/dev/null 2>&1; fi
	[ -s "$2" ]
}
fail() { echo "$1" > $ERR; return 1; }
check() {
	command -v usign >/dev/null 2>&1 || { fail nousign; return 1; }
	[ -f "$PUB" ] || { fail nokey; return 1; }
	get "$BASE/latest.json" $D/latest.json && get "$BASE/latest.json.sig" $D/latest.json.sig || { fail net; return 1; }
	usign -V -q -p "$PUB" -m $D/latest.json -x $D/latest.json.sig >/dev/null 2>&1 || { fail sig; return 1; }
	cp $D/latest.json $OUT.t && mv $OUT.t $OUT; rm -f $ERR
}
jf() { jsonfilter -i $OUT -e "$1" 2>/dev/null; }
tg() { [ "$TG" = 1 ] && ubus call wrtfreedom tgsend "{\"bg\":true,\"text\":\"$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g')\"}" >/dev/null 2>&1; }
cur() { cat $W/VERSION 2>/dev/null; }

case "$1" in
check)
	check ;;
install)
	TG=0; [ "$2" = tg ] && TG=1
	echo "## $(t "Controllo il server degli aggiornamenti" "Checking the update server")"
	if ! check; then
		case "$(cat $ERR)" in
			nousign) m=$(t "manca usign (il programma che controlla la firma): installalo da Software" "usign is missing (it checks the signature): install it from Software");;
			sig) m=$(t "la firma dell'aggiornamento non è valida: niente è stato installato" "the update signature is not valid: nothing was installed");;
			*) m=$(t "server non raggiungibile: il router è collegato a internet?" "server not reachable: is the router online?");;
		esac
		echo "## ERRORE $m"; tg "❌ $m"; exit 1
	fi
	v=$(jf '@.pkg.v'); f=$(jf '@.pkg.file'); h=$(jf '@.pkg.sha256')
	case "$f" in ''|*[!A-Za-z0-9._-]*) echo "## ERRORE $(t "elenco degli aggiornamenti non valido" "invalid update list")"; exit 1;; esac
	newer "$v" "$(cur)" || [ "$3" = force ] || { m="$(t "Pacchetto Router già aggiornato" "Router Package already up to date") ($(cur))"; echo "## OK $(cur)"; echo "$m"; tg "✅ $m"; exit 0; }
	echo "## $(t "Scarico la versione" "Downloading version") $v"
	get "$BASE/$f" /tmp/wf-pkg.tgz || { m=$(t "download non riuscito" "download failed"); echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	[ "$(sha256sum /tmp/wf-pkg.tgz | cut -d' ' -f1)" = "$h" ] || { rm -f /tmp/wf-pkg.tgz; m=$(t "il file scaricato non corrisponde a quello firmato" "the downloaded file does not match the signed one"); echo "## ERRORE $m"; tg "❌ $m"; exit 1; }
	echo "## $(t "File verificato, installo" "File verified, installing")"
	rm -rf /tmp/wfpkg && mkdir -p /tmp/wfpkg && tar xzf /tmp/wf-pkg.tgz -C /tmp/wfpkg || { echo "## ERRORE $(t "archivio non valido" "invalid archive")"; exit 1; }
	o=$(sh /tmp/wfpkg/install.sh 2>&1); echo "$o"
	if echo "$o" | grep -q '^## OK'; then tg "✅ $(t "Pacchetto Router aggiornato alla" "Router Package updated to") $(cur)"
	else tg "❌ $(t "Aggiornamento non riuscito" "Update failed"): $(echo "$o" | sed -n 's/^## ERRORE //p' | tail -n 1)"; fi
	;;
notify)
	[ "$(uci -q get wrtfreedom.upd.check)" = 0 ] && exit 0
	check || exit 0
	S=/etc/wrtfreedom/upd.seen; touch $S
	v=$(jf '@.pkg.v')
	if newer "$v" "$(cur)" && ! grep -qx "pkg $v" $S; then
		echo "pkg $v" >> $S
		sh $W/event.sh upd pkg "📦 $(t "Pacchetto Router $v disponibile (installato $(cur))" "Router Package $v available (installed $(cur))")"
	fi
	# app Android: solo se il telefono ha detto al router la sua versione (Software › Pacchetto Router)
	a=$(jf '@.app.v'); have=$(cat /etc/wrtfreedom/appver 2>/dev/null)
	if [ -n "$have" ] && newer "$a" "$have" && ! grep -qx "app $a" $S; then
		echo "app $a" >> $S
		sh $W/event.sh upd app "📱 $(t "App WrtFreedom $a disponibile (sul telefono $have)" "WrtFreedom app $a available (on the phone $have)")"
	fi
	;;
status)
	check
	v=$(jf '@.pkg.v'); a=$(jf '@.app.v')
	echo "📦 $(t "Pacchetto Router" "Router Package"): $(cur)"
	if [ -f $ERR ] && [ ! -s $OUT ]; then case "$(cat $ERR)" in nousign) t "⚠️ Manca usign: non posso controllare gli aggiornamenti" "⚠️ usign is missing: cannot check for updates";; *) t "⚠️ Server degli aggiornamenti non raggiungibile" "⚠️ Update server not reachable";; esac; echo; exit 0; fi
	if newer "$v" "$(cur)"; then echo "🆕 $(t "Disponibile" "Available"): $v · /$(t aggiorna_pacchetto update_package)"; else t "✅ Aggiornato" "✅ Up to date"; echo; fi
	[ -n "$a" ] && echo "📱 $(t "App WrtFreedom" "WrtFreedom app"): $a"
	;;
*)
	echo "uso: upd.sh check|install|notify|status"; exit 1 ;;
esac
