#!/bin/sh
# WrtFreedom 2.53: Controllo Della Linea (SQM) dal bot, dalle Pianificazioni e dalle regole degli Eventi
# uso: sqmctl.sh on                    acceso con la modalità di prima (Adattivo se c'è cake-autorate, altrimenti Fisso)
#      sqmctl.sh off                   spento (la modalità si ricorda in wrtfreedom.sqm.last)
#      sqmctl.sh state                 stato in parole (bot)
#      sqmctl.sh mode fixed <down> <up>   limiti fissi in kbit/s nel verso della linea
#      sqmctl.sh mode auto <safe|bal|fast> velocità adattiva con il profilo
#      sqmctl.sh prof <id>             profilo per orario wrtfreedom.sqmp_<id> (cron.sh sqmp)
#      sqmctl.sh pick <parola>         profilo dal bot: prudente|bilanciato|veloce|spento o il nome di un profilo per orario
# Regola: la prima accesa, altrimenti la prima. Sulla rete di casa (br-…) «download» di SQM = upload della linea
# (come sqmline.sh). Con il limite dei giga finiti (slow.sh) non si cambia niente. Eventi cron_sqm_on / cron_sqm_off.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1; }
num() { case "$1" in ''|*[!0-9]*) echo 0;; *) echo "$1";; esac; }
mb() { awk -v k="$1" 'BEGIN { v = k / 1000; s = sprintf(v < 10 ? "%.1f" : "%.0f", v); sub(/\.0$/, "", s); print s }'; }
[ -x /etc/init.d/sqm ] || { t "Controllo Della Linea non installato (sqm-scripts)" "Line Control not installed (sqm-scripts)"; echo; exit 1; }
S=
for s in $(uci -q show sqm | sed -n "s/^sqm\.\([^.]*\)=queue$/\1/p"); do
	[ -z "$S" ] && S=$s
	[ "$(uci -q get sqm.$s.enabled)" = 1 ] && { S=$s; break; }
done
[ -n "$S" ] || { t "Nessuna regola del Controllo Della Linea: configurala nell'app" "No Line Control rule: set it up in the app"; echo; exit 1; }
I=$(uci -q get sqm.$S.interface)
# configurazione di cake-autorate: cartella letta dal suo servizio (/etc/init.d/cake-autorate), poi i posti soliti
arconf() { for d in $(grep -o "/[A-Za-z0-9._/-]*cake-autorate/" /etc/init.d/cake-autorate 2>/dev/null) /root/cake-autorate/ /usr/share/cake-autorate/ /opt/cake-autorate/; do
	[ -f "${d}config.primary.sh" ] && { echo "${d}config.primary.sh"; return; }; done; }
F=$(arconf)
AR=0; [ -x /etc/init.d/cake-autorate ] && [ -n "$F" ] && AR=1
arrun() { [ $AR = 1 ] && /etc/init.d/cake-autorate running >/dev/null 2>&1; }
ison() { [ "$(uci -q get sqm.$S.enabled)" = 1 ]; }
pname() { case "$1" in safe) t Prudente Cautious;; fast) t Veloce Fast;; *) t Bilanciato Balanced;; esac; }
# profili della velocità adattiva (come l'app: minimo, base, massimo in Mbit/s, download poi upload)
prof() { case "$1" in safe) echo "5 30 60 2 6 12";; fast) echo "20 60 150 5 10 25";; *) echo "10 40 90 3 8 15";; esac; }
slowchk() { [ -f /etc/wrtfreedom/slow ] && { t "Limite dei giga finiti attivo: il Controllo Della Linea torna libero con il nuovo periodo" "Data cap limit active: Line Control is free again with the new period"; echo; exit 1; }; }
start() { /etc/init.d/sqm enable; /etc/init.d/sqm restart >/dev/null 2>&1; }
# limiti nel verso della linea: sulla rete di casa download e upload di SQM sono al contrario
setlim() { d=$1; u=$2; case "$I" in br-*) d=$2; u=$1;; esac; uci set sqm.$S.download="$d"; uci set sqm.$S.upload="$u"; }
fixed() {
	d=$(num "$1"); u=$(num "$2")
	[ "$d" -ge 100 ] && [ "$u" -ge 100 ] || { t "Limiti non validi" "Invalid limits"; echo; exit 1; }
	was=0; ison && was=1
	arrun && { /etc/init.d/cake-autorate stop >/dev/null 2>&1; /etc/init.d/cake-autorate disable; }
	uci set sqm.$S.enabled=1; setlim "$d" "$u"; uci commit sqm; start
	uci set wrtfreedom.sqm=sqm; uci set wrtfreedom.sqm.last=fixed; uci commit wrtfreedom
	msg="🎚 $(t "Controllo Della Linea · Fisso" "Line Control · Fixed") ↓ $(mb "$d") ↑ $(mb "$u") Mbit/s"
	[ $was = 0 ] && ev sqm_on "$msg"; echo "$msg"
}
auto() {
	[ $AR = 1 ] || { t "Velocità adattiva non installata (cake-autorate)" "Adaptive speed not installed (cake-autorate)"; echo; exit 1; }
	p=${1:-bal}; set -- $(prof "$p")
	was=0; ison && was=1
	i=0; for k in min_dl base_dl max_dl min_ul base_ul max_ul; do
		i=$((i + 1)); eval v=\$$i
		sed -i "s/^${k}_shaper_rate_kbps=.*/${k}_shaper_rate_kbps=$((v * 1000))/" $F
	done
	uci set sqm.$S.enabled=1; uci commit sqm; start
	/etc/init.d/cake-autorate enable; /etc/init.d/cake-autorate restart >/dev/null 2>&1
	uci set wrtfreedom.sqm=sqm; uci set wrtfreedom.sqm.last=auto; uci set wrtfreedom.sqm.prof="$p"; uci commit wrtfreedom
	msg="🎚 $(t "Controllo Della Linea · Adattivo" "Line Control · Adaptive") $(pname "$p")"
	[ $was = 0 ] && ev sqm_on "$msg"; echo "$msg"
}
off() {
	ison || { t "Controllo Della Linea già spento" "Line Control already off"; echo; return 0; }
	l=fixed; arrun && l=auto
	uci set wrtfreedom.sqm=sqm; uci set wrtfreedom.sqm.last=$l; uci commit wrtfreedom
	[ $AR = 1 ] && { /etc/init.d/cake-autorate stop >/dev/null 2>&1; /etc/init.d/cake-autorate disable; }
	uci set sqm.$S.enabled=0; uci commit sqm
	/etc/init.d/sqm stop >/dev/null 2>&1; /etc/init.d/sqm disable
	msg="🎚 $(t "Controllo Della Linea spento" "Line Control off")"
	ev sqm_off "$msg"; echo "$msg"
}
on() {
	ison && { arrun || [ $AR = 0 ] || [ "$(uci -q get wrtfreedom.sqm.last)" != auto ]; } && { t "Controllo Della Linea già acceso" "Line Control already on"; echo; return 0; }
	if [ $AR = 1 ] && [ "$(uci -q get wrtfreedom.sqm.last)" != fixed ]; then auto "$(uci -q get wrtfreedom.sqm.prof)"
	else
		d=$(uci -q get sqm.$S.download); u=$(uci -q get sqm.$S.upload); case "$I" in br-*) x=$d; d=$u; u=$x;; esac
		fixed "$d" "$u"
	fi
}
state() {
	if ! ison; then t "🎚 Controllo Della Linea: spento" "🎚 Line Control: off"; echo; return; fi
	if arrun; then echo "🎚 $(t "Controllo Della Linea: Adattivo" "Line Control: Adaptive") $(pname "$(uci -q get wrtfreedom.sqm.prof)")"
	else echo "🎚 $(t "Controllo Della Linea: Fisso" "Line Control: Fixed")"; fi
	b=$(printf 'ifb4%s' "$I" | head -c 15)
	o=$(tc qdisc show dev "$I" 2>/dev/null | sed -n 's/.* bandwidth \([^ ]*\).*/\1/p' | head -n 1)
	n=$(tc qdisc show dev "$b" 2>/dev/null | sed -n 's/.* bandwidth \([^ ]*\).*/\1/p' | head -n 1)
	case "$I" in br-*) x=$o; o=$n; n=$x;; esac
	[ -n "$o$n" ] && echo "$(t "Limiti adesso" "Limits now"): ↓ ${n:-?} · ↑ ${o:-?}" || t "Code CAKE non attive" "CAKE queues not active"
	echo "$(t "Si applica a" "Applies to"): $I"
}
case "$1" in
	state) state ;;
	on) slowchk; on ;;
	off) slowchk; off ;;
	mode) slowchk
		case "$2" in off) off ;; fixed) fixed "$3" "$4" ;; auto) auto "$3" ;; *) t "Modalità non valida" "Invalid mode"; echo; exit 1 ;; esac ;;
	prof)
		echo "$2" | grep -qE '^[a-z0-9]{1,12}$' && [ "$(uci -q get wrtfreedom.sqmp_$2)" = sqmp ] || { t "Profilo non trovato" "Profile not found"; echo; exit 1; }
		slowchk; P=wrtfreedom.sqmp_$2
		case "$(uci -q get $P.mode)" in off) off ;; fixed) fixed "$(uci -q get $P.dl)" "$(uci -q get $P.ul)" ;; *) auto "$(uci -q get $P.prof)" ;; esac ;;
	pick)
		w=$(echo "$2" | tr 'A-Z' 'a-z' | sed 's/^ *//; s/ *$//')
		case "$w" in
			prudente|cautious|safe) slowchk; auto safe ;;
			bilanciato|balanced|bal) slowchk; auto bal ;;
			veloce|fast) slowchk; auto fast ;;
			spento|off) slowchk; off ;;
			acceso|on) slowchk; on ;;
			*) id=$(uci -q show wrtfreedom | sed -n "s/^wrtfreedom\.sqmp_\([a-z0-9]*\)\.name='\(.*\)'$/\1 \2/p" | awk -v w="$w" 'tolower(substr($0, index($0, " ") + 1)) == w { print $1; exit }')
				[ -n "$id" ] && exec sh "$0" prof "$id"
				t "Profilo non trovato: scrivi prudente, bilanciato, veloce, spento o il nome di un profilo per orario" "Profile not found: type cautious, balanced, fast, off or the name of a scheduled profile"; echo ;;
		esac ;;
	*) echo "uso: sqmctl.sh on|off|state|mode <off|fixed <down> <up>|auto <safe|bal|fast>>|prof <id>|pick <parola>"; exit 1 ;;
esac
exit 0
