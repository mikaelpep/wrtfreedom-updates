'use strict';
/* WrtFreedom: Wi-Fi in sottofondo (pacchetto 2.48). Tutto quello che chiede processi (iw, logread, wifi) sta qui e non
   nei metodi di rpcd. Radio, bande e interfacce lette da netifd (network.wireless status), mai fisse.
   uso: ucode wifi.uc <comando> [argomenti]
   tick            Salute Del Wi-Fi: occupazione del canale in uso (iw survey dump, differenza dalla lettura precedente) e
                   dispositivi (iw station dump: segnale, velocità, ripetizioni, falliti, airtime). La lancia notify.sh ogni
                   30 s se l'app l'ha chiesta da meno di 10 minuti, ogni 5 minuti fino a 24 ore dall'ultima richiesta, poi
                   niente (/tmp/wf-wifi.want = secondi dall'accensione dell'ultima richiesta, come sqmlive.sh).
                   /tmp/wf-wifi.json = ultima lettura; /tmp/wf-wifi.h = riassunti di 5 minuti per radio (24 ore);
                   /tmp/wf-wifi.d/<mac> = ultime letture del dispositivo. Nessuna scrittura nella memoria interna.
   radar           episodi DFS dal registro di hostapd (DFS-RADAR-DETECTED + DFS-NEW-CHANNEL): una riga per episodio in
                   /tmp/wf-wifi.dfs e l'evento cron_wifi_radar; attesa radar (CAC) in /tmp/wf-wifi.cac
   scan <radio>    Canale Automatico: reti vicine per canale (solo reti e segnale) → /tmp/wf-wifi.plan.<radio>
   chan <radio> <canale> [valore uci]   cambio con switch_chan (annuncio CSA, i dispositivi restano collegati) e poi uci;
                   se serve il riavvio della radio e non risale entro 120 s (più l'attesa radar) torna al canale di prima
   night           Canale Automatico di notte (cron.sh wifichan): solo le radio scelte, mai canali DFS
   wps <iface> <sezione>   WPS a tempo quando wps_pushbutton manca: lo mette, avvia il WPS, alla fine lo toglie
   wpsclean        WPS rimasto a metà (segno wrtfreedom.wifi.wpsadd): toglie wps_pushbutton (avvio del servizio, uninstall)
   restart         Riavvia Wi-Fi: «wifi», controllo dopo 30 s, secondo «wifi up» ed evento se una radio non riparte
   glimit [check|off]   Limite Di Velocità della rete ospiti (CAKE) */
import { popen, readfile, writefile, unlink, stat, lsdir, rename, mkdir, rmdir } from 'fs';

const W = '/usr/share/wrtfreedom', P = '/tmp/wf-wifi';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function up() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
function rj(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function pct(a, b) { if (!(b > 0) || a == null) return null; let v = a * 100.0 / b; return v < 0 ? 0 : v > 100 ? 100 : int(v * 10 + 0.5) / 10.0; }
let LANG = null;
function L(it, en) { if (LANG == null) LANG = trim(sh('uci -q get wrtfreedom.ui.lang')); return LANG == 'en' ? en : it; }
/* evento negli Eventi (avvisi su telefono e Telegram secondo le categorie scelte): tipo → cron_<tipo> */
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' net ' + q(txt) + ' >/dev/null 2>&1'); }
function once(k, sec) { let f = P + '.once.' + k, s = stat(f); if (s && time() - s.mtime < sec) return false; writefile(f, ''); return true; }
let UB = null;
function ub(obj, m, a) {
	if (UB == null) { try { UB = require('ubus').connect() ?? false; } catch (e) { UB = false; } }
	if (UB) { let r = UB.call(obj, m, a ?? {}); if (r != null) return r; }
	let o = sh('ubus call ' + obj + ' ' + m + (a ? ' ' + q(sprintf('%J', a)) : '') + ' 2>/dev/null');
	try { return json(o); } catch (e) { return null; }
}
/* chiamata che cambia qualcosa: esito dal codice di uscita (una risposta vuota è un successo) */
function ubok(obj, m, a) { return trim(sh('ubus call ' + obj + ' ' + m + ' ' + q(sprintf('%J', a ?? {})) + ' >/dev/null 2>&1; echo $?')) == '0'; }
function chfreq(band, ch) { return band == '2g' ? (ch == 14 ? 2484 : 2407 + 5 * ch) : band == '6g' ? 5950 + 5 * ch : 5000 + 5 * ch; }
function fch(f) { return f == 2484 ? 14 : f < 2500 ? (f - 2407) / 5 : f >= 5955 ? (f - 5950) / 5 : (f - 5000) / 5; }
function fband(f) { return f < 2500 ? '2g' : f >= 5925 ? '6g' : '5g'; }
function blabel(b) { return b == '2g' ? '2,4 GHz' : b == '6g' ? '6 GHz' : '5 GHz'; }

/* canale, larghezza e potenza in uso (iw dev <if> info) */
function ifinfo(i) {
	let o = sh('iw dev ' + q(i) + ' info 2>/dev/null'), m = match(o, /channel ([0-9]+) \(([0-9]+) MHz\)(, width: ([0-9]+))?/), t = match(o, /txpower ([0-9.]+) dBm/);
	return { ch: m ? +m[1] : null, freq: m ? +m[2] : null, width: (m && m[4]) ? +m[4] : null, txpow: t ? +t[1] : null };
}
/* radio da netifd: banda (band, altrimenti hwmode o canale), canale scelto in uci, punti di accesso con nome e sezione */
function radios() {
	let S = ub('network.wireless', 'status') ?? {}, R = {};
	for (let rn in S) {
		let v = S[rn], c = v.config ?? {}, band = c.band ?? '';
		let ifs = [];
		for (let i in (v.interfaces ?? [])) {
			let ic = i.config ?? {};
			if (i.ifname && (ic.mode ?? 'ap') == 'ap' && stat('/sys/class/net/' + i.ifname)) push(ifs, { ifname: i.ifname, sec: i.section ?? '', ssid: ic.ssid ?? '', enc: ic.encryption ?? '' });
		}
		/* banda: band, poi hwmode, poi la frequenza in uso (iw), infine il canale */
		if (!match(band, /^(2g|5g|6g|60g)$/)) {
			let f = (!c.hwmode && length(ifs)) ? ifinfo(ifs[0].ifname).freq : null;
			band = f ? fband(f) : (c.hwmode == '11a' || +c.channel > 14) ? '5g' : '2g';
		}
		R[rn] = { up: !!v.up, band: band, cfgch: '' + (c.channel ?? 'auto'), htmode: c.htmode ?? '', ifs: ifs };
	}
	return R;
}
/* tempi del canale in uso (ms dall'accensione della radio) e rumore */
function survey(i, freq) {
	let best = null;
	for (let b in split(sh('iw dev ' + q(i) + ' survey dump 2>/dev/null'), 'Survey data from')) {
		let f = match(b, /frequency:[ \t]*([0-9]+) MHz/);
		if (!f) continue;
		let use = index(b, '[in use]') >= 0;
		if (!use && +f[1] != freq) continue;
		let n = (k) => { let m = match(b, regexp(k + ':[ \t]*(-?[0-9]+)')); return m ? +m[1] : null; };
		best = { freq: +f[1], noise: n('noise'), active: n('channel active time'), busy: n('channel busy time'), rx: n('channel receive time'), tx: n('channel transmit time') };
		if (use) break;
	}
	return best;
}
/* dispositivi di un punto di accesso: contatori grezzi (le percentuali sono differenze tra due letture) */
/* null = iw non ha risposto (diverso da nessun dispositivo collegato) */
function stations(i) {
	let r = [], o = sh('iw dev ' + q(i) + ' station dump 2>/dev/null; echo "@@$?"'), m0 = match(o, /@@([0-9]+)\n?$/);
	if (!m0 || m0[1] != '0') return null;
	for (let b in split(substr(o, 0, rindex(o, '@@')), /\n?Station /)) {
		let m = match(b, /^([0-9a-fA-F:]{17})/);
		if (!m) continue;
		let n = (k) => { let x = match(b, regexp('\n[ \t]*' + k + ':[ \t]*(-?[0-9.]+)')); return x ? +x[1] : null; };
		push(r, { mac: lc(m[1]), sig: n('signal'), avg: n('signal avg'), txr: n('tx bitrate'), rxr: n('rx bitrate'), txpk: n('tx packets'), retry: n('tx retries'),
			fail: n('tx failed'), dur: (n('tx duration') ?? 0) + (n('rx duration') ?? 0), hasdur: index(b, 'x duration:') >= 0, conn: n('connected time'), inact: n('inactive time') });
	}
	return r;
}

/* un solo lavoro alla volta per tipo (cartella di blocco; si riprende se è vecchia: processo finito male) */
function lock(k, maxage) {
	let d = P + '.' + k + '.lock';
	if (mkdir(d)) return true;
	let s = stat(d);
	if (s && time() - s.mtime > maxage) { rmdir(d); return mkdir(d); }
	return false;
}
function unlock(k) { rmdir(P + '.' + k + '.lock'); }

/* riassunti di 5 minuti per radio (24 ore): media dei campioni dell'intervallo; disturbi = canale occupato da altri */
function hist(S) {
	let A = rj(P + '.acc') ?? { b: 0, r: {}, hi: {} }, b = int(S.t / 300);
	let add = (o, k, v) => { if (v != null) { o[k] = (o[k] ?? 0) + v; o['n' + k] = (o['n' + k] ?? 0) + 1; } };
	if (A.b && A.b != b) {
		let out = '';
		for (let rn in A.r) {
			let a = A.r[rn], av = (k) => a['n' + k] ? sprintf('%.1f', a[k] / a['n' + k]) : '-';
			out += sprintf('%d %s %s %s %s %s %s %s\n', A.b * 300, rn, av('busy'), av('txp'), av('noise'), av('nsta'), av('sig'), av('retry'));
			/* disturbi: canale occupato al 70% o più, per almeno il 60% non dalle reti del router, per 2 intervalli di fila */
			let bu = a.nbusy ? a.busy / a.nbusy : null, tx = a.ntxp ? a.txp / a.ntxp : 0;
			A.hi[rn] = (bu != null && bu >= 70 && bu - tx >= 60) ? (A.hi[rn] ?? 0) + 1 : 0;
			let x = S.radios[rn];
			if (A.hi[rn] >= 2 && x && once('busy.' + rn, 21600))
				ev('wifi_busy', L('📶 Wi-Fi ' + blabel(x.band) + ': canale ' + x.ch + ' molto occupato da altre reti (' + int(bu) + '%). Prova Canale Automatico',
					'📶 Wi-Fi ' + replace(blabel(x.band), ',', '.') + ': channel ' + x.ch + ' very busy with other networks (' + int(bu) + '%). Try Auto Channel'));
		}
		let o = (readfile(P + '.h') ?? '') + out, lim = S.t - 86400;
		o = join('', map(filter(split(o, '\n'), (l) => length(l) && +split(l, ' ')[0] > lim), (l) => l + '\n'));
		writefile(P + '.h', o);
		A.r = {};
		/* dispositivi non visti da 24 ore: file tolti */
		for (let f in (lsdir(P + '.d') ?? [])) { let s = stat(P + '.d/' + f); if (s && s.mtime < lim) unlink(P + '.d/' + f); }
	}
	A.b = b;
	for (let rn in S.radios) {
		let x = S.radios[rn], a = A.r[rn] ?? (A.r[rn] = {});
		add(a, 'busy', x.busy); add(a, 'txp', x.txp); add(a, 'noise', x.noise); add(a, 'nsta', x.nsta); add(a, 'sig', x.sig); add(a, 'retry', x.retry);
	}
	writefile(P + '.acc', sprintf('%J', A));
}

function tick() {
	let st0 = rj(P + '.json');
	if (st0 && time() - st0.t < 20) return;	/* lettura appena fatta (l'app e notify.sh possono chiederla insieme) */
	if (!lock('tick', 120)) return;
	let now = time(), u = up(), R = radios(), prev = rj(P + '.prev') ?? {}, cur = { u: u, s: {}, d: {} };
	let S = { t: now, u: u, radios: {}, devs: {} };
	mkdir(P + '.d');
	for (let rn in R) {
		let r = R[rn];
		if (!length(r.ifs)) continue;
		let i0 = r.ifs[0].ifname, inf = ifinfo(i0);
		let x = { band: r.band, up: r.up, ch: inf.ch, freq: inf.freq, width: inf.width, txpow: inf.txpow, cfg: r.cfgch, ifs: map(r.ifs, (i) => ({ ifname: i.ifname, ssid: i.ssid })), nsta: 0 };
		let sv = inf.freq ? survey(i0, inf.freq) : null;
		if (sv) {
			x.noise = sv.noise;
			cur.s[rn] = sv;
			let p = prev.s?.[rn];
			if (p && p.freq == sv.freq && sv.active > p.active && sv.busy >= p.busy) {
				let da = sv.active - p.active;
				x.busy = pct(sv.busy - p.busy, da); x.txp = pct(sv.tx - p.tx, da); x.rxp = pct(sv.rx - p.rx, da);
			}
		}
		let ss = 0, sn = 0, rs = 0, rn2 = 0, okd = false;
		for (let I in r.ifs) { let St = stations(I.ifname); if (St != null) okd = true; for (let s in (St ?? [])) {
			let p = prev.d?.[s.mac], b0 = hex(substr(s.mac, 0, 2));
			let d = { if: I.ifname, radio: rn, band: r.band, ssid: I.ssid, sig: s.sig, avg: s.avg, txr: s.txr, rxr: s.rxr, conn: s.conn, inact: s.inact, priv: (b0 & 2) == 2 };
			cur.d[s.mac] = { if: I.ifname, tp: s.txpk, rt: s.retry, fl: s.fail, ad: s.hasdur ? s.dur : null, u: u };
			if (p && p.if == I.ifname && s.txpk != null && s.txpk >= p.tp && s.retry >= p.rt) {
				let dp = s.txpk - p.tp;
				if (dp > 0) { d.retry = pct(s.retry - p.rt, dp + s.retry - p.rt); d.fail = pct(s.fail - p.fl, dp); }
				if (s.hasdur && p.ad != null && u > p.u && s.dur >= p.ad) d.air = pct((s.dur - p.ad) / 1000.0, (u - p.u) * 1000);
			}
			S.devs[s.mac] = d; x.nsta++;
			if (s.sig != null) { ss += s.sig; sn++; }
			if (d.retry != null) { rs += d.retry; rn2++; }
			/* ultime letture del dispositivo: t segnale velocità ripetizioni% airtime% */
			let f = P + '.d/' + replace(s.mac, /:/g, ''), o = readfile(f) ?? '';
			o += sprintf('%d %s %s %s %s\n', now, s.sig ?? '-', s.txr ?? '-', d.retry ?? '-', d.air ?? '-');
			if (length(o) > 9000) o = join('\n', slice(split(o, '\n'), -240));
			writefile(f, o);
		} }
		if (!okd) x.nsta = null;	/* station dump non ha risposto: numero sconosciuto, non zero */
		if (sn) x.sig = int(ss / sn);
		if (rn2) x.retry = int(rs * 10 / rn2) / 10.0;
		S.radios[rn] = x;
	}
	writefile(P + '.prev', sprintf('%J', cur));
	S.iv = u - (+trim(readfile(P + '.want') ?? '0')) < 600 ? 30 : 300;
	wj(P + '.json', S);
	hist(S);
	unlock('tick');
}
/* ---------- radar (DFS) ---------- */
const MON = { Jan: 1, Feb: 2, Mar: 3, Apr: 4, May: 5, Jun: 6, Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12 };
function radar() {
	if (!lock('radar', 60)) return;
	let last = +(trim(readfile(P + '.rlast') ?? '0')), first = !last, mx = last, E = [], now = time();
	for (let l in split(sh("logread -l 500 -e 'DFS-' 2>/dev/null"), '\n')) {
		let m = match(l, /^[A-Za-z]{3} ([A-Za-z]{3}) +([0-9]{1,2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) ([0-9]{4}) .*: ([A-Za-z0-9_.-]{1,32}): (DFS-[A-Z-]{3,40})(.*)$/);
		if (!m || !MON[m[1]]) continue;
		let t = timelocal({ sec: +m[5], min: +m[4], hour: +m[3], mday: +m[2], mon: MON[m[1]], year: +m[6] });
		if (t <= last) continue;
		if (t > mx) mx = t;
		let f = match(m[9], /freq=([0-9]+)/), c = match(m[9], /chan=([0-9]+)/), ct = match(m[9], /cac_time=([0-9]+)/);
		push(E, { t: t, ifn: m[7], k: m[8], ch: c ? +c[1] : (f ? fch(+f[1]) : null), cac: ct ? +ct[1] : null, ok: index(m[9], 'success=1') >= 0 });
	}
	writefile(P + '.rlast', '' + (mx || now));
	let dfs = readfile(P + '.dfs') ?? '', prevt = {};
	for (let i = 0; i < length(E); i++) {
		let e = E[i];
		if (e.k == 'DFS-CAC-START') wj(P + '.cac', { if: e.ifn, ch: e.ch, t: e.t, end: e.t + (e.cac ?? 60), done: false });
		else if (e.k == 'DFS-CAC-COMPLETED' || e.k == 'DFS-CAC-ABORTED') wj(P + '.cac', { if: e.ifn, ch: e.ch, t: e.t, done: true, ok: e.ok });
		if (e.k != 'DFS-RADAR-DETECTED' || (prevt[e.ifn] && e.t - prevt[e.ifn] < 60)) continue;
		prevt[e.ifn] = e.t;
		/* stesso episodio: il canale nuovo arriva subito dopo il radar */
		let to = null;
		for (let j = i + 1; j < length(E); j++) if (E[j].ifn == e.ifn && E[j].k == 'DFS-NEW-CHANNEL' && E[j].t - e.t <= 60) { to = E[j].ch; break; }
		dfs += sprintf('%d %s %s %s\n', e.t, e.ifn, e.ch ?? '-', to ?? '-');
		/* avviso solo per gli episodi recenti (alla prima lettura il registro può avere episodi vecchi) */
		if (!first && now - e.t < 900)
			ev('wifi_radar', to ? L('📡 Radar sul canale ' + e.ch + ': Wi-Fi 5 GHz spostato sul canale ' + to, '📡 Radar on channel ' + e.ch + ': 5 GHz Wi-Fi moved to channel ' + to)
				: L('📡 Radar sul canale ' + e.ch + ': il Wi-Fi 5 GHz cambia canale', '📡 Radar on channel ' + e.ch + ': 5 GHz Wi-Fi is changing channel'));
	}
	let D = filter(split(dfs, '\n'), length);
	writefile(P + '.dfs', length(D) ? join('\n', slice(D, -50)) + '\n' : '');
	unlock('radar');
}

/* ---------- canali ---------- */
/* canali permessi dalla radio (iw phy <phy> info, solo quelli della banda: un phy può avere più radio) */
function phychans(i0, band) {
	let ph = trim(readfile('/sys/class/net/' + i0 + '/phy80211/name') ?? ''), r = [];
	if (!match(ph, /^[A-Za-z0-9_.-]{1,32}$/)) return r;
	let o = sh('iw phy ' + q(ph) + ' info 2>/dev/null'), cur = null;
	for (let l in split(o, '\n')) {
		let m = match(l, /^[ \t]*\* ([0-9]+)(\.[0-9]+)? MHz \[([0-9]+)\](.*)$/);
		if (m) {
			cur = null;
			let f = +m[1];
			if (fband(f) != band || index(m[4], 'disabled') >= 0) continue;
			cur = { ch: +m[3], freq: f, dfs: index(m[4], 'radar detection') >= 0, noir: index(m[4], 'no IR') >= 0 };
			push(r, cur);
		}
		else if (cur && index(l, 'Radar detection') >= 0) cur.dfs = true;
		else if (cur && index(l, 'No IR') >= 0) cur.noir = true;
	}
	return r;
}
/* primo canale del blocco di larghezza w (5 e 6 GHz): i canali di un blocco cambiano insieme */
function blockof(band, ch, w) {
	let n = w >= 160 ? 8 : w >= 80 ? 4 : w >= 40 ? 2 : 1;
	if (band == '6g') return 1 + int((ch - 1) / (4 * n)) * 4 * n;
	let base = ch >= 149 ? 149 : 36;
	return base + int((ch - base) / (4 * n)) * 4 * n;
}
/* argomenti di switch_chan per hostapd */
function csa(band, ch, w, ht) {
	let f = chfreq(band, ch), a = { freq: f, bcn_count: 10, ht: true, vht: band != '2g' && match(ht, /^(VHT|HE|EHT)/) != null, he: match(ht, /^(HE|EHT)/) != null, bandwidth: w ?? 20 };
	if (band == '2g') {
		if (w >= 40) { a.sec_channel_offset = ch <= 7 ? 1 : -1; a.center_freq1 = f + a.sec_channel_offset * 10; a.bandwidth = 40; }
		else { a.center_freq1 = f; a.bandwidth = 20; }
		return a;
	}
	if (!(w >= 40)) { a.center_freq1 = f; a.bandwidth = 20; return a; }
	let s = blockof(band, ch, w), n = w >= 160 ? 8 : w >= 80 ? 4 : 2, two = blockof(band, ch, 40);
	a.sec_channel_offset = two == ch ? 1 : -1;
	a.center_freq1 = chfreq(band, s + (n - 1) * 2);
	return a;
}
/* reti vicine per canale e punteggio (somma dei segnali che si sovrappongono: più basso = più libero) */
function scan(rn) {
	let R = radios(), r = R[rn], out = P + '.plan.' + rn;
	if (!r || !length(r.ifs)) return wj(out, { t: time(), radio: rn, error: 'radio spenta o senza reti' });
	if (!lock('scan.' + rn, 90)) return;
	wj(out, { t: time(), radio: rn, run: true });
	let i0 = r.ifs[0].ifname, inf = ifinfo(i0), w = inf.width ?? 20, C = phychans(i0, r.band), N = [];
	let o = sh('iwinfo ' + q(i0) + ' scan 2>/dev/null'), own = {};
	for (let I in r.ifs) own[lc(trim(readfile('/sys/class/net/' + I.ifname + '/address') ?? ''))] = true;
	for (let b in split(o, /Cell [0-9]+ - Address: /)) {
		let a = match(b, /^([0-9A-Fa-f:]{17})/), c = match(b, /Channel: ([0-9]+)/), s = match(b, /Signal: (-?[0-9]+) dBm/), e = match(b, /ESSID: "([^"]{0,64})"/);
		if (a && c && !own[lc(a[1])]) push(N, { ch: +c[1], sig: s ? +s[1] : -95, ssid: e ? e[1] : '' });
	}
	let wt = (s) => s > -100 ? s + 100 : 0, dfsrec = {}, now = time();
	/* canali con un radar da meno di 30 minuti: non si possono usare */
	for (let l in split(readfile(P + '.dfs') ?? '', '\n')) { let f = split(l, ' '); if (length(f) > 2 && now - +f[0] < 1800) dfsrec[+f[2]] = true; }
	let cand = [], seen = {};
	for (let c in C) {
		if (c.noir && !c.dfs) continue;
		let k = r.band == '2g' ? c.ch : blockof(r.band, c.ch, w);
		if (r.band == '2g' && index([1, 6, 11], c.ch) < 0) continue;	/* 2,4 GHz: solo i canali che non si sovrappongono */
		/* canali meteo (120–128): attesa radar fino a 10 minuti, mai scelti come migliori */
		let wx = r.band == '5g' && c.ch >= 120 && c.ch <= 128;
		if (seen[k]) { if (c.dfs) seen[k].dfs = true; if (wx) seen[k].weather = true; continue; }
		let x = { ch: r.band == '2g' ? c.ch : k, dfs: c.dfs, nets: 0, best: null, score: 0 };
		if (wx) x.weather = true;
		seen[k] = x; push(cand, x);
	}
	for (let x in cand) {
		for (let n in N) {
			let ov = r.band == '2g' ? (n.ch - x.ch < 5 && x.ch - n.ch < 5) : blockof(r.band, n.ch, w) == x.ch;
			if (!ov) continue;
			x.nets++; x.score += wt(n.sig) * (r.band == '2g' && n.ch != x.ch ? 0.5 : 1);
			if (x.best == null || n.sig > x.best) x.best = n.sig;
		}
		x.score = int(x.score);
		if (dfsrec[x.ch]) x.radar = true;
	}
	let curk = r.band == '2g' ? inf.ch : blockof(r.band, inf.ch ?? 0, w);
	let ok = filter(cand, (x) => !x.radar && !x.weather), pick = (L2) => length(L2) ? sort([...L2], (a, b) => a.score - b.score || (a.dfs ? 1 : 0) - (b.dfs ? 1 : 0))[0].ch : null;
	wj(out, { t: time(), radio: rn, band: r.band, width: w, cur: inf.ch, curblock: curk, cfg: r.cfgch, nets: length(N), chans: cand,
		best: pick(ok), bestnodfs: pick(filter(ok, (x) => !x.dfs)) });
	unlock('scan.' + rn);
}
/* cambio di canale: switch_chan (niente riavvio) dove si può, poi uci; ritorno automatico se la radio non risale */
function chan(rn, ch, uval, night) {
	ch = +ch;
	let R = radios(), r = R[rn], J = P + '.chan';
	if (!r || !length(r.ifs) || !(ch > 0)) return wj(J, { t: time(), radio: rn, ch: ch, step: 'error', msg: 'radio spenta o canale non valido' });
	if (!lock('chan', 900)) return wj(J, { t: time(), radio: rn, ch: ch, step: 'error', msg: 'un cambio di canale è già in corso' });
	let i0 = r.ifs[0].ifname, inf = ifinfo(i0), w = inf.width ?? 20, C = phychans(i0, r.band), c = filter(C, (x) => x.ch == ch)[0];
	if (!c) { wj(J, { t: time(), radio: rn, ch: ch, step: 'error', msg: 'canale non permesso su questa radio' }); return unlock('chan'); }
	let dfs = length(filter(C, (x) => x.dfs && (r.band == '2g' ? x.ch == ch : blockof(r.band, x.ch, w) == blockof(r.band, ch, w)))) > 0;
	let old = { radio: rn, cfg: r.cfgch, ch: inf.ch, t: time() };
	if (uval == null || uval == '') uval = '' + ch;
	if (!match('' + uval, /^(auto|[0-9]{1,3})$/)) uval = '' + ch;
	if (inf.ch == ch) {
		sh('uci set ' + q('wireless.' + rn + '.channel=' + uval) + '; uci commit wireless');
		wj(J, { t: time(), radio: rn, ch: ch, from: ch, step: 'ok', live: true, reloadpending: true });
		return unlock('chan');
	}
	wj(P + '.undo.' + rn, old);
	wj(J, { t: time(), radio: rn, ch: ch, from: inf.ch, step: 'switch', dfs: dfs });
	/* annuncio del cambio ai dispositivi (CSA): niente riavvio. Sui canali DFS serve l'attesa radar: lo fa il riavvio */
	let live = !dfs && inf.ch != null && ubok('hostapd.' + i0, 'switch_chan', csa(r.band, ch, w, r.htmode));
	if (live) for (let k = 0; k < 6; k++) { sh('sleep 1'); if (ifinfo(i0).ch == ch) break; }
	live = live && ifinfo(i0).ch == ch;
	sh('uci set ' + q('wireless.' + rn + '.channel=' + uval) + '; uci commit wireless');
	if (live) {
		wj(J, { t: time(), radio: rn, ch: ch, from: inf.ch, step: 'ok', live: true, reloadpending: true });
		if (night) ev('wifi_chan', L('📶 Wi-Fi ' + blabel(r.band) + ': canale cambiato di notte ' + inf.ch + ' → ' + ch + ' (meno reti vicine)', '📶 Wi-Fi ' + replace(blabel(r.band), ',', '.') + ': channel changed overnight ' + inf.ch + ' → ' + ch + ' (fewer nearby networks)'));
		return unlock('chan');
	}
	/* riavvio della sola radio cambiata (wifi reload applica solo quello che è cambiato) e attesa */
	sh('wifi reload >/dev/null 2>&1');
	let lim = 120 + (dfs ? (c.ch >= 120 && c.ch <= 128 ? 600 : 60) : 0), t0 = time(), okk = false;
	wj(J, { t: time(), radio: rn, ch: ch, from: inf.ch, step: 'wait', end: t0 + lim, dfs: dfs });
	while (time() - t0 < lim) {
		sh('sleep 5');
		let R2 = radios()[rn];
		if (R2?.up && length(R2.ifs) && ifinfo(R2.ifs[0].ifname).ch == ch) { okk = true; break; }
	}
	if (okk) { wj(J, { t: time(), radio: rn, ch: ch, from: inf.ch, step: 'ok', live: false }); return unlock('chan'); }
	sh('uci set ' + q('wireless.' + rn + '.channel=' + old.cfg) + '; uci commit wireless; wifi reload >/dev/null 2>&1');
	wj(J, { t: time(), radio: rn, ch: ch, from: inf.ch, step: 'back', msg: 'la radio non è ripartita: canale di prima rimesso' });
	ev('wifi_chan_back', L('↩️ Wi-Fi ' + blabel(r.band) + ': il canale ' + ch + ' non è partito, rimesso il ' + (old.ch ?? old.cfg), '↩️ ' + replace(blabel(r.band), ',', '.') + ' Wi-Fi: channel ' + ch + ' did not start, back to ' + (old.ch ?? old.cfg)));
	unlock('chan');
}
/* di notte: per le radio scelte nell'app, il canale più libero se è chiaramente meglio; mai DFS (attesa radar, rischio) */
function night() {
	let A = filter(split(trim(sh('uci -q get wrtfreedom.wifichan.auto')), ' '), length), R = radios();
	for (let rn in A) {
		if (!match(rn, /^[A-Za-z0-9_]{1,32}$/) || !R[rn]) continue;
		scan(rn);
		/* solo un piano appena fatto e completo (scansione saltata o non finita = niente cambio) */
		let p = rj(P + '.plan.' + rn);
		if (!p || p.error || p.run || !(time() - p.t < 600) || !p.bestnodfs) continue;
		let cur = filter(p.chans, (x) => x.ch == p.curblock)[0], best = filter(p.chans, (x) => x.ch == p.bestnodfs)[0];
		if (!best || best.ch == p.curblock) continue;
		/* solo se il canale in uso è chiaramente peggiore (almeno 20 punti e un terzo in più) */
		if (cur && !(cur.score - best.score >= 20 && cur.score > best.score * 1.33)) continue;
		chan(rn, best.ch, p.cfg == 'auto' ? 'auto' : '' + best.ch, true);
	}
}

/* WPS rimasto a metà (riavvio, lavoro fermato): toglie wps_pushbutton messo dal pacchetto e il segno */
function wpsclean(force) {
	let sec = trim(sh('uci -q get wrtfreedom.wifi.wpsadd'));
	if (!length(sec)) return;
	let lk = stat(P + '.wps.lock');
	if (lk && !force && time() - lk.mtime < 600) return;	/* lavoro in corso: lo toglie lui alla fine (force: lavoro fermo da più di 300 s) */
	if (lk) rmdir(P + '.wps.lock');
	sh((match(sec, /^[]A-Za-z0-9_@[-]{1,64}$/) ? 'uci -q delete ' + q('wireless.' + sec + '.wps_pushbutton') + '; uci commit wireless; ' : '') +
		'uci -q delete wrtfreedom.wifi.wpsadd; uci commit wrtfreedom; wifi reload >/dev/null 2>&1');
	let S = rj(P + '.wps');
	if (S) { S.step = 'off'; S.added = false; S.t = time(); wj(P + '.wps', S); }
}

/* ---------- WPS a tempo ---------- */
/* wps_pushbutton mancava: lo mette (la rete riparte), avvia il WPS per 2 minuti, poi lo toglie (la rete riparte) */
function wps(ifn, sec) {
	let J = P + '.wps';
	let S = rj(J) ?? {};
	if (!match(ifn, /^[A-Za-z0-9_.-]{1,32}$/) || !match(sec, /^[]A-Za-z0-9_@[-]{1,64}$/) || !lock('wps', 600)) {
		S.step = 'error'; S.t = time(); wj(J, S);
		return wpsclean();
	}
	S.step = 'restart'; S.t = time(); wj(J, S);
	/* segno in wrtfreedom.wifi.wpsadd (lo mette il metodo prima di questo lavoro): se il lavoro si interrompe,
	   wpsclean all'avvio del servizio o in uninstall.sh toglie wps_pushbutton */
	sh('uci set ' + q('wireless.' + sec + '.wps_pushbutton=1') + '; uci commit wireless; wifi reload >/dev/null 2>&1');
	let ok = false;
	for (let k = 0; k < 30 && !stat(J + '.stop'); k++) { sh('sleep 2'); if (ub('hostapd.' + ifn, 'wps_status') != null && ubok('hostapd.' + ifn, 'wps_start', {})) { ok = true; break; } }
	S.step = ok ? 'on' : 'error'; S.t0 = time(); S.end = time() + 120; wj(J, S);
	for (let k = 0; ok && k < 62 && !stat(J + '.stop'); k++) {
		sh('sleep 2');
		/* finito: collegato (Success) oppure scaduto o fermato */
		let s = ub('hostapd.' + ifn, 'wps_status') ?? {};
		if (s.pbc_status && s.pbc_status != 'Active') {
			if (s.last_wps_result == 'Success') { S.res = 'ok'; ev('wifi_wps', L('📶 Nuovo dispositivo collegato con il WPS', '📶 New device joined with WPS')); }
			break;
		}
	}
	ubok('hostapd.' + ifn, 'wps_cancel', {});
	S.step = 'restore'; wj(J, S);
	sh('uci -q delete ' + q('wireless.' + sec + '.wps_pushbutton') + '; uci -q delete wrtfreedom.wifi.wpsadd; uci commit wireless; uci commit wrtfreedom; wifi reload >/dev/null 2>&1');
	S.step = 'off'; S.added = false; S.t = time(); wj(J, S);
	unlink(J + '.stop');
	unlock('wps');
}
/* ---------- Riavvia Wi-Fi ---------- */
/* «wifi» (giù e su di tutte le radio), dopo 30 s controllo: una radio non ripartita = secondo «wifi up» ed evento */
function restart() {
	if (!lock('restart', 120)) return;
	sh('sleep 1; wifi >/dev/null 2>&1; sleep 30');
	let R = radios(), down = filter(keys(R), (k) => !R[k].up);
	if (length(down)) {
		sh('wifi up >/dev/null 2>&1');
		ev('wifi_restart', L('📶 Wi-Fi: ' + join(', ', down) + ' non ripartita dopo il riavvio, riavviata di nuovo', '📶 Wi-Fi: ' + join(', ', down) + ' did not come back after the restart, restarted again'));
	}
	unlock('restart');
}

/* ---------- Limite Di Velocità della rete ospiti ---------- */
/* per tutta la rete ospiti (non per ospite): CAKE sull'interfaccia della rete ospiti letta da netifd (verso gli ospiti =
   download) e CAKE su una ifb a parte (wfg0, wfg1… dal traffico in entrata = upload). Valori in wrtfreedom.guest.dl/ul
   (kbit/s, 0 = nessun limite). Le interfacce con una regola SQM accesa non si toccano. Stato in /tmp/wf-glimit.json.
   glimit = applica (all'avvio, a ogni ifup, dall'app); glimit check = solo se mancano le code; glimit off = toglie tutto */
function gdevs() {
	let F = {}, nets = {}, D = [];
	/* reti ospiti: le stesse di wrtfreedom.uc (rete «guest» o zona del firewall con «guest» nel nome) */
	let fw = sh('uci -q show firewall'), wl = sh('uci -q show wireless');
	for (let l in split(fw, '\n')) { let m = match(l, /^firewall\.([^.=]+)\.name='([^']*)'$/); if (m && match(m[2], /guest/i)) F[m[1]] = true; }
	for (let l in split(fw, '\n')) { let m = match(l, /^firewall\.([^.=]+)\.network='([^']*)'$/); if (m && F[m[1]]) for (let n in split(m[2], ' ')) if (length(n)) nets[n] = true; }
	for (let l in split(wl, '\n')) { let m = match(l, /^wireless\.[^.=]+\.network='([^']*)'$/); if (m) for (let n in split(m[1], ' ')) if (n == 'guest') nets[n] = true; }
	for (let n in nets) {
		let st = ub('network.interface.' + n, 'status'), d = st?.l3_device ?? st?.device;
		if (d && match(d, /^[A-Za-z0-9_.@-]{1,15}$/) && index(D, d) < 0) push(D, d);
	}
	return D;
}
function gcan() {
	let tc = stat('/sbin/tc') || stat('/usr/sbin/tc') || stat('/usr/bin/tc');
	let ck = stat('/sys/module/sch_cake') || length(trim(sh('find /lib/modules -name sch_cake.ko 2>/dev/null | head -n 1')));
	return !tc ? 'manca tc' : !ck ? 'manca sch_cake' : null;
}
function glimit(mode) {
	if (!lock('glimit', 60)) return;
	let dl = int(+trim(sh('uci -q get wrtfreedom.guest.dl')) || 0), ul = int(+trim(sh('uci -q get wrtfreedom.guest.ul')) || 0);
	let D = gdevs(), err = gcan(), sqm = sh('uci -q show sqm'), out = { t: time(), dl: dl, ul: ul, devs: D, ok: false };
	if (mode == 'off') { dl = 0; ul = 0; }
	if (err && (dl || ul)) { out.err = err; wj('/tmp/wf-glimit.json', out); return unlock('glimit'); }
	let old = rj('/tmp/wf-glimit.json') ?? {}, c = '';
	/* code tolte dalle interfacce di prima (anche quelle che non sono più della rete ospiti) */
	for (let i = 0; i < length(old.devs ?? []); i++) {
		let d = old.devs[i];
		if (!match(d, /^[A-Za-z0-9_.@-]{1,15}$/) || old.skip?.[d]) continue;
		if (mode != 'check') c += 'tc qdisc del dev ' + q(d) + ' root 2>/dev/null; tc qdisc del dev ' + q(d) + ' ingress 2>/dev/null; ';
	}
	if (mode != 'check') c += 'for i in $(ls /sys/class/net | grep -E "^wfg[0-9]+$"); do ip link del $i 2>/dev/null; done; ';
	/* interfacce con una regola SQM accesa */
	let SI = {}, SE = {}, busy = {};
	for (let l in split(sqm, '\n')) {
		let m = match(l, /^sqm\.([^.=]+)\.(interface|enabled)='([^']*)'$/);
		if (m && m[2] == 'interface') SI[m[1]] = m[3]; else if (m) SE[m[1]] = m[3];
	}
	for (let s in SI) if (SE[s] == '1') busy[SI[s]] = true;
	out.skip = {};
	for (let i = 0; i < length(D) && (dl || ul); i++) {
		let d = D[i], ifb = 'wfg' + i;
		/* regola SQM accesa sulla stessa interfaccia: non si tocca */
		if (busy[d]) { out.skip[d] = true; out.err = 'SQM usa già ' + d; continue; }
		if (mode == 'check') { let o = sh('tc qdisc show dev ' + q(d) + ' 2>/dev/null'); if ((!dl || index(o, 'cake') >= 0) && (!ul || index(o, 'ingress') >= 0)) continue; }
		if (mode == 'check') c += 'tc qdisc del dev ' + q(d) + ' root 2>/dev/null; tc qdisc del dev ' + q(d) + ' ingress 2>/dev/null; ip link del ' + ifb + ' 2>/dev/null; ';
		if (dl) c += 'tc qdisc replace dev ' + q(d) + ' root cake bandwidth ' + dl + 'kbit besteffort; ';
		if (ul) c += 'ip link add ' + ifb + ' type ifb 2>/dev/null; ip link set ' + ifb + ' up; tc qdisc replace dev ' + ifb + ' root cake bandwidth ' + ul + 'kbit besteffort ingress; ' +
			'tc qdisc add dev ' + q(d) + ' handle ffff: ingress 2>/dev/null; tc filter replace dev ' + q(d) + ' parent ffff: protocol all prio 10 matchall action mirred egress redirect dev ' + ifb + '; ';
	}
	if (length(c)) sh('( ' + c + ' ) >/dev/null 2>&1');
	/* esito controllato sulle interfacce: coda CAKE (download) e ingresso (upload) presenti */
	out.ok = true;
	if (dl || ul) {
		let n = 0;
		for (let d in D) {
			if (out.skip[d]) continue;
			let o = sh('tc qdisc show dev ' + q(d) + ' 2>/dev/null');
			if ((dl && index(o, 'cake') < 0) || (ul && index(o, 'ingress') < 0)) { out.ok = false; out.err = out.err ?? ('limite non applicato su ' + d); } else n++;
		}
		if (!n) out.ok = false;
	}
	if ((dl || ul) && !length(D)) out.err = 'rete ospiti non trovata';
	if (mode != 'off') wj('/tmp/wf-glimit.json', out); else unlink('/tmp/wf-glimit.json');
	unlock('glimit');
}

let a = ARGV[0] ?? '';
if (a == 'tick') tick();
else if (a == 'radar') radar();
else if (a == 'scan' && match(ARGV[1] ?? '', /^[A-Za-z0-9_]{1,32}$/)) scan(ARGV[1]);
else if ((a == 'chan' || a == 'undo') && match(ARGV[1] ?? '', /^[A-Za-z0-9_]{1,32}$/)) {
	/* lo stato dice sempre come è finita, anche quando il lavoro non parte */
	let u = a == 'undo' ? rj(P + '.undo.' + ARGV[1]) : null;
	if (a == 'undo' && !(u && u.ch)) wj(P + '.chan', { t: time(), radio: ARGV[1], step: 'error', msg: 'niente da annullare' });
	else if (a == 'undo') chan(ARGV[1], u.ch, u.cfg);
	else if (match(ARGV[2] ?? '', /^[0-9]{1,3}$/)) chan(ARGV[1], ARGV[2], ARGV[3]);
	else wj(P + '.chan', { t: time(), radio: ARGV[1], step: 'error', msg: 'canale non valido' });
}
else if (a == 'night') night();
else if (a == 'wps') wps(ARGV[1] ?? '', ARGV[2] ?? '');
else if (a == 'wpsclean') wpsclean(ARGV[1] == 'force');
else if (a == 'restart') restart();
else if (a == 'glimit') glimit(ARGV[1] ?? '');
else { warn('uso: wifi.uc tick|radar|scan <radio>|chan <radio> <canale> [uci]|undo <radio>|night|wps <iface> <sezione>|wpsclean|restart|glimit [check|off]\n'); exit(1); }
