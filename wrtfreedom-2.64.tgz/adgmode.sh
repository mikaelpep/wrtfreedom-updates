#!/bin/sh
# WrtFreedom 2.51: chi risponde al DNS dei dispositivi e DNS di riserva (sempre in sottofondo, mai dentro rpcd)
# uso: adgmode.sh direct | back | check | rebind | recover
#  - schema «std» (quello di OpenWrt): dnsmasq sulla 53 inoltra ad AdGuard (es. 127.0.0.1#3053): AdGuard vede solo il router
#  - schema «direct»: AdGuard sulla 53 (bind sugli indirizzi delle reti di casa letti dal router, più 127.0.0.1 e ::1),
#    dnsmasq su una porta libera solo per DHCP e nomi di casa; AdGuard chiede a dnsmasq il dominio di casa
#    e i nomi che dnsmasq risolve da sé (address=, host…: LDOM in $S/orig) con [/<nome>/]127.0.0.1:<porta>, poi gli
#    indirizzi inversi locali (local_ptr_upstreams). handle_ddr non si tocca.
#  direct: copia di dhcp e del file di AdGuard, cambio, verifica (AdGuard deve rispondere sulla 53 e dare per i nomi
#    di dnsmasq la stessa risposta di dnsmasq, altrimenti ritorno
#    immediato), poi attesa della conferma (adgmode confirm → /tmp/wf-adgmode.ok) per 120 s: senza, tutto torna com'era.
#    Stato in /etc/wrtfreedom/adgmode (valori di prima, per «back» anche dopo mesi e per la disinstallazione).
#  back: torna allo schema std (con i valori di prima se ci sono, altrimenti AdGuard su 127.0.0.1 e una porta libera).
#  check (notify.sh, ogni minuto con il DNS di riserva acceso): se AdGuard non risponde due volte di fila e i server
#    pubblici sì, il DNS di casa passa ai server dell'operatore (o pubblici): std = server di dnsmasq verso AdGuard
#    tolto; direct = AdGuard fermato e dnsmasq sulla 53. Torna ad AdGuard quando risponde (direct: prova ogni 10 minuti,
#    dopo 6 prove ogni ora). Eventi cron_adg_down / cron_adg_up. Stato in /etc/wrtfreedom/dnsfb.state.
#  rebind (event.sh, rete di casa accesa con lo schema direct): indirizzi cambiati o AdGuard fermo → bind rifatto;
#    opzione 6 del DHCP anche per le reti di casa nuove (aggiunte in ADD6 di $S/orig, tolte da «back»).
#  recover (avvio del servizio, disinstallazione) e inizio di check: cambio interrotto a metà (adgmode.new rimasto, nessun
#    adgmode vivo) → tutto rimesso dalla copia (mai casa senza DNS dopo un crash o una mancanza di corrente).
# Stato per l'app in /tmp/wf-adgmode.json {st: run|wait|ok|back|err, msg, t, until}.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
set -f	# niente glob: i server come [/lan/]… restano com'erano
W=/usr/share/wrtfreedom; S=/etc/wrtfreedom/adgmode; N=/etc/wrtfreedom/adgmode.new; FB=/etc/wrtfreedom/dnsfb.state
J=/tmp/wf-adgmode.json; LK=/tmp/wf-adgmode.lock; PD=/tmp/wf-adgmode.pend; CNT=/tmp/wf-dnsfb.n
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1; }
st() { printf '{"st":"%s","msg":"%s","t":%s,"until":%s}\n' "$1" "$2" "$(date +%s)" "${3:-0}" > $J.t && mv $J.t $J; }
TMO=; command -v timeout >/dev/null 2>&1 && TMO="timeout 8"
# il server risponde? (anche «nome non trovato» o SERVFAIL sono risposte: solo il silenzio vuol dire fermo)
ans() { o=$($TMO nslookup openwrt.org "$1" 2>&1) && return 0
	case "$o" in *"can't find"*|*NXDOMAIN*|*SERVFAIL*|*REFUSED*) return 0 ;; esac; return 1; }
waitans() { i=0; while [ $i -lt "${2:-10}" ]; do ans "$1" && return 0; sleep 2; i=$((i+1)); done; return 1; }
yaml() { for y in $(uci -q get adguardhome.config.config_file) $(uci -q get adguardhome.config.config) /etc/adguardhome/adguardhome.yaml /etc/adguardhome.yaml /opt/AdGuardHome/AdGuardHome.yaml; do [ -f "$y" ] && { echo "$y"; return; }; done; }
ainit() { for s in adguardhome AdGuardHome; do [ -x /etc/init.d/$s ] && { echo $s; return; }; done; }
dsec() { uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=dnsmasq$/\1/p"; }
# blocco «dns:» del file di AdGuard: valore semplice, righe di una chiave, sostituzione delle chiavi con un file di blocchi
yval() { awk -v k="$2" '/^[^ #]/{d=($0 ~ /^dns:/)} d && $0 ~ "^  "k":" {sub("^  "k":[ \t]*",""); gsub(/["\047]/,""); print; exit}' "$1"; }
yblk() { awk -v k="$2" '/^[^ #]/{d=($0 ~ /^dns:/); p=0; next} d{ if (p && ($0 ~ /^    / || $0 ~ /^  - /)) {print; next} p=0; if ($0 ~ "^  "k":") {print; p=1} }' "$1"; }
yitems() { yblk "$1" "$2" | sed -n 's/^ *- *//p'; }
yset() {	# yset <file di AdGuard> <blocchi>: chiavi sostituite (le mancanti in fondo al blocco dns), il resto com'è
	awk -v R="$2" '
	BEGIN { while ((getline l < R) > 0) { if (l ~ /^  [a-z_]+:/) { k = l; sub(/^  /, "", k); sub(/:.*/, "", k); o[++n] = k; b[k] = l } else b[k] = b[k] "\n" l } }
	function rest() { for (i = 1; i <= n; i++) if (!(o[i] in done)) print b[o[i]] }
	/^[^ #]/ { if (d) rest(); d = ($0 ~ /^dns:/); s = 0; print; next }
	d { if (s) { if ($0 ~ /^    / || $0 ~ /^  - /) next; s = 0 }
		if (match($0, /^  [a-z_]+:/)) { k = substr($0, 3, RLENGTH - 3); if (k in b) { print b[k]; done[k] = 1; s = 1; next } } }
	{ print }
	END { if (d) rest() }' "$1" > "$1.wf" && mv "$1.wf" "$1"
}
ydel() {	# ydel <file di AdGuard> <chiavi>: chiavi tolte dal blocco dns (con le loro righe)
	awk -v K=" $2 " '
	/^[^ #]/ { d = ($0 ~ /^dns:/); s = 0; print; next }
	d { if (s) { if ($0 ~ /^    / || $0 ~ /^  - /) next; s = 0 }
		if (match($0, /^  [a-z_]+:/)) { k = substr($0, 3, RLENGTH - 3); if (index(K, " " k " ")) { s = 1; next } } }
	{ print }' "$1" > "$1.wf" && mv "$1.wf" "$1"
}
# porta libera (UDP e TCP in ascolto) tra quelle proposte
freeport() { u=" $(awk 'NR>1{split($2,a,":");print a[2]}' /proc/net/udp /proc/net/udp6 2>/dev/null; awk 'NR>1&&$4=="0A"{split($2,a,":");print a[2]}' /proc/net/tcp /proc/net/tcp6 2>/dev/null) "
	u=$(echo $u); for p; do case " $u " in *" $(printf '%04X' $p) "*) ;; *) echo $p; return 0 ;; esac; done; return 1; }
# reti di casa: interfacce accese che non stanno in una zona con il NAT (linee, VPN in uscita) e non sono loopback.
# Riga 1: indirizzi (IPv4 e IPv6 locali fc00::/7); riga 2: «rete=IPv4» per l'opzione DNS del DHCP
homeips() {
	WANN=" $(for z in $(uci -q show firewall | sed -n "s/^firewall\.\([^.]*\)\.masq='1'$/\1/p"); do uci -q get firewall.$z.network; done | tr '\n' ' ') " ucode -e '
let u = require("ubus").connect(), d = u ? u.call("network.interface", "dump") : null, w = getenv("WANN"), r = [], m = [];
for (let i in d?.interface ?? []) {
	let n = i.interface;
	if (!i.up || n == "loopback" || index(w, " " + n + " ") >= 0 || match(n, /^wgo(ut|[0-9]+)$/)) continue;
	for (let a in i["ipv4-address"] ?? []) { push(r, a.address); push(m, n + "=" + a.address); }
	for (let a in [ ...(i["ipv6-address"] ?? []), ...map(i["ipv6-prefix-assignment"] ?? [], (p) => p["local-address"] ?? {}) ])
		if (match(a.address ?? "", /^f[cd]/i)) push(r, a.address);
}
print(join(" ", uniq(r)) + "\n" + join(" ", uniq(m)) + "\n");' 2>/dev/null
}
# un altro adgmode che cambia qualcosa è vivo? (esclusi questo processo e chi l'ha lanciato)
alive() { for p in $(pgrep -f 'adgmode\.sh (direct|back|rebind)' 2>/dev/null); do [ "$p" != $$ ] && [ "$p" != $PPID ] && return 0; done; return 1; }
lock() { i=0; while ! mkdir $LK 2>/dev/null; do
		# lucchetto rimasto da un giro interrotto: più vecchio di 5 minuti senza adgmode vivo, oppure di 15 minuti
		a=$(( $(date +%s) - $(date -r $LK +%s 2>/dev/null || date +%s) ))
		if { [ $a -gt 300 ] && ! alive; } || [ $a -gt 900 ]; then rmdir $LK; continue; fi
		[ "$1" = try ] && exit 0; [ $i -ge 30 ] && exit 1; sleep 1; i=$((i+1)); done
	trap 'rmdir $LK 2>/dev/null' EXIT; }
# schema attuale: MODE = std | direct | other; Y, A, D, AP (porta di AdGuard), DP (porta di dnsmasq)
detect() {
	MODE=other; Y=$(yaml); A=$(ainit); D=$(dsec | head -n 1); AP=; DP=
	[ -n "$Y" ] && [ -n "$A" ] && [ -n "$D" ] || return 1
	AP=$(yval "$Y" port); DP=$(uci -q get dhcp.$D.port); DP=${DP:-53}
	if [ "$AP" = 53 ] && [ "$DP" != 53 ]; then MODE=direct
	elif [ "$DP" = 53 ] && uci -q get dhcp.$D.server | tr ' ' '\n' | grep -qxE "(127\.0\.0\.1|::1|localhost)#$AP"; then MODE=std; fi
	return 0
}
svc() { /etc/init.d/$A "$1" >/dev/null 2>&1; }
dnsm() { uci commit dhcp; /etc/init.d/dnsmasq restart >/dev/null 2>&1; }
pubneed() {	# servono server pubblici? (nessun server di dnsmasq e niente server dell'operatore)
	[ -n "$(uci -q get dhcp.$D.server)" ] && return 1
	[ "$(uci -q get dhcp.$D.noresolv)" = 1 ] && return 0
	rf=$(uci -q get dhcp.$D.resolvfile); grep -q '^nameserver' "${rf:-/tmp/resolv.conf.d/resolv.conf.auto}" 2>/dev/null && return 1; return 0; }
v6lo() { grep -q '^00000000000000000000000000000001 ' /proc/net/if_inet6 2>/dev/null && echo '::1'; }

# ---------- DNS di riserva ----------
fbsave() { printf "MODE='%s'\nSRVD='%s'\nNR='%s'\nNP='%s'\nPUB='%s'\nT='%s'\nTRY='%s'\nNEXT='%s'\n" "$MODE" "$SRVD" "$NR" "$NP" "$PUB" "${T:-$(date +%s)}" "${TRY:-0}" "${NEXT:-0}" > $FB.t && mv $FB.t $FB; }
fbpub() { PUB=; pubneed && { PUB='9.9.9.9 1.1.1.1'; for s in $PUB; do uci add_list dhcp.$D.server=$s; done; }; }
fb_down() {	# AdGuard fermo: il DNS di casa ai server dell'operatore (o pubblici)
	SRVD=; NR=$(uci -q get dhcp.$D.noresolv); NP=; T=; TRY=0; NEXT=0
	if [ $MODE = std ]; then
		for s in $(uci -q get dhcp.$D.server); do case "$s" in 127.0.0.1#$AP|::1#$AP|localhost#$AP) SRVD="$SRVD $s"; uci -q del_list dhcp.$D.server="$s" ;; esac; done
		[ "$NR" = 1 ] && uci set dhcp.$D.noresolv=0
	else
		svc stop; NP=$DP; uci -q delete dhcp.$D.port; NEXT=$(( $(date +%s) + 600 ))
	fi
	fbpub; SRVD=${SRVD# }; fbsave; dnsm; rm -f $CNT
	ev adg_down "🛡️ $(t "AdGuard non risponde: il DNS di casa usa i server dell'operatore" "AdGuard is not answering: home DNS uses the provider's servers")"
}
fb_later() { TRY=$((TRY+1)); NEXT=$(( $(date +%s) + ( TRY < 6 ? 600 : 3600 ) )); fbsave; }	# prossima prova più tardi
fb_up() {	# AdGuard di nuovo pronto: DNS di casa rimesso com'era
	. $FB; D=$(dsec | head -n 1)
	if [ "$MODE" = std ]; then
		for s in $PUB; do uci -q del_list dhcp.$D.server=$s; done
		for s in $SRVD; do uci -q del_list dhcp.$D.server="$s"; uci add_list dhcp.$D.server="$s"; done
		if [ -n "$NR" ]; then uci set dhcp.$D.noresolv="$NR"; else uci -q delete dhcp.$D.noresolv; fi
		dnsm
	else
		# dnsmasq resta sulla 53 finché AdGuard non è partito (processo vivo, al massimo 3 prove)
		svc start; i=1
		while ! pidof AdGuardHome adguardhome >/dev/null 2>&1; do
			[ $i -ge 3 ] && { svc stop; fb_later; return 1; }; sleep 2; i=$((i+1))
		done
		# poi la 53 ad AdGuard: risposta entro 3 prove, altrimenti di nuovo dnsmasq sulla 53
		for s in $PUB; do uci -q del_list dhcp.$D.server=$s; done
		uci set dhcp.$D.port="$NP"; dnsm; svc restart
		if ! waitans 127.0.0.1 3; then
			svc stop; uci -q delete dhcp.$D.port; fbpub; dnsm; fb_later; return 1
		fi
	fi
	rm -f $FB $CNT
	ev adg_up "🛡️ $(t "AdGuard risponde di nuovo: DNS di casa protetto" "AdGuard is answering again: home DNS protected")"
}
do_check() {
	lock try
	recover && exit 0
	if [ -f $FB ]; then
		detect || exit 0; . $FB
		if [ "$MODE" = std ]; then ans "127.0.0.1:$AP" && fb_up
		elif [ "$(date +%s)" -ge "${NEXT:-0}" ]; then fb_up; fi
		exit 0
	fi
	[ "$(uci -q get wrtfreedom.dnsfb.on)" = 1 ] || exit 0
	[ -f $PD ] && exit 0
	detect || exit 0
	case $MODE in std) tg="127.0.0.1:$AP" ;; direct) tg=127.0.0.1 ;; *) exit 0 ;; esac
	ans "$tg" && { rm -f $CNT; exit 0; }
	# linea assente (nemmeno i server pubblici rispondono): cambiare non servirebbe
	ans 9.9.9.9 || ans 1.1.1.1 || exit 0
	n=$(( $(cat $CNT 2>/dev/null || echo 0) + 1 )); echo $n > $CNT
	[ $n -ge 2 ] && fb_down
}

# ---------- AdGuard risponde ai dispositivi ----------
# nomi che dnsmasq risolve da sé (uci dhcp: address, nomi con il punto di host/domain/cname; con «all» anche local e server
# /dom/…, e nftset/ipset /dom/…: dnsmasq deve vedere la richiesta per riempire l'insieme, es. Eccezioni Per Sito del
# Servizio VPN; rebind li segue quando cambiano), il dominio di casa escluso: nello schema diretto AdGuard li chiede a dnsmasq ([/<nome>/]127.0.0.1:<porta>).
# address=/dom/, local e server valgono per il dominio e tutti i suoi sottodomini (regola di dnsmasq): resta il dominio.
# Un host o cname con il punto è solo quel nome: esce come «=nome» e AdGuard manda a dnsmasq solo il nome esatto
# ([/nome/]… più [/*.nome/]# = sottodomini ai server normali). Un nome anche in address= resta dominio.
# Solo nomi validi (mai con «-» in testa: nslookup lo prenderebbe come opzione)
ldoms() {
	{ for x in $(uci -q get dhcp.$D.address) $([ "$1" = all ] && uci -q get dhcp.$D.local) $([ "$1" = all ] && uci -q get dhcp.$D.server) \
		$([ "$1" = all ] && uci -q get dhcp.$D.nftset) $([ "$1" = all ] && uci -q get dhcp.$D.ipset); do
		case "$x" in /*/*) x=${x#/}; echo "${x%/*}" | tr '/' '\n' ;; esac; done
	  uci -q show dhcp | sed -n -e "s/^dhcp\.[^.]*\.name='\(.*\)'$/+\1/p" -e "s/^dhcp\.[^.]*\.cname='\(.*\)'$/+\1/p"
	} | awk -v d="$DOM" '{ $0 = tolower($0); p = sub(/^\+/, ""); sub(/^\*\./, ""); gsub(/^\.+|\.+$/, "") }
		p && !index($0, ".") { next }
		!/^[a-z0-9_][a-z0-9_-]*(\.[a-z0-9_][a-z0-9_-]*)*$/ || $0 == d || substr($0, length($0) - length(d)) == "." d { next }
		!($0 in s) { o[++n] = $0; s[$0] = p }
		!p { s[$0] = 0 }
		END { for (i = 1; i <= n; i++) print (s[o[i]] ? "=" : "") o[i] }' | tr '\n' ' '
}
# indirizzi IPv4 della risposta (server escluso), in ordine: nsa <nome> <server>
# (nome dopo le opzioni; un nome che inizia con «-» non si chiede mai: nslookup di BusyBox non accetta «--»)
nsa() { case "$1" in -*|"") return ;; esac; $TMO nslookup -type=a "$1" "$2" 2>/dev/null | sed '1,/^Address/d' | sed -n 's/^Address[^:]*: *\([0-9][0-9.]*\)\( .*\)\{0,1\}$/\1/p' | sort | tr '\n' ' '; }
# nome con una sua voce in AdGuard? ([/a/b/]… dell'utente: resta la sua)
yhas() { for u in $YUP; do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; case "$v" in "[/"*) case "${v%%]*}" in *"/$1/"*) return 0 ;; esac ;; esac; done; return 1; }
# voce messa dal pacchetto? ([/<nome>/]127.0.0.1:$NP con il nome in DOM o LDOM, [/*.<nome>/]# con «=nome» in LDOM)
ours() { case "$1" in
		"[/*."*"/]#") ox=${1#"[/*."}; ox="=${ox%"/]#"}" ;;
		"[/"*"/]127.0.0.1:$NP") ox=${1#"[/"}; ox=${ox%"/]127.0.0.1:$NP"} ;;
		*) return 1 ;; esac
	case " $DOM $LDOM " in *" $ox "*|*" =$ox "*) return 0 ;; esac; return 1; }
# voci di AdGuard del pacchetto per DOM e LDOM (nome esatto: i sottodomini ai server normali)
lent() { for lx in $DOM $LDOM; do case "$lx" in =*) echo "    - '[/${lx#=}/]127.0.0.1:$NP'"; echo "    - '[/*.${lx#=}/]#'" ;; *) echo "    - '[/$lx/]127.0.0.1:$NP'" ;; esac; done; }
# nomi di $1 senza quelli che l'utente ha già in AdGuard (usa YUP)
lfree() { lf=; for lx in $1; do yhas "${lx#=}" || lf="$lf $lx"; done; echo "${lf# }"; }
# valori di $S/orig: oget <chiave>; oput <chiave> <valore>
oget() { sed -n "s/^$1='\(.*\)'$/\1/p" $S/orig; }
oput() { awk -v k="$1" -v v="$2" 'BEGIN { q = sprintf("%c", 39) } index($0, k "=") == 1 { print k "=" q v q; f = 1; next } { print } END { if (!f) print k "=" q v q }' $S/orig > $S/orig.t && mv $S/orig.t $S/orig; }
newblocks() {	# blocchi del file di AdGuard per lo schema diretto ($1 = file di uscita); LDOM = nomi aggiunti davvero
	YUP=$(yitems "$Y" upstream_dns); LDOM=$(lfree "$LDOM")
	{ echo "  bind_hosts:"; for a in 127.0.0.1 $(v6lo) $IPS; do echo "    - '$a'"; done
	  echo "  port: 53"
	  echo "  upstream_dns:"; g=0
	  for u in $YUP; do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; case "$v" in "[/$DOM/]"*|"127.0.0.1:$NP") continue ;; "[/"*) ;; *) g=1 ;; esac; echo "    - $u"; done
	  [ $g = 1 ] || echo "    - https://dns10.quad9.net/dns-query"
	  lent
	  echo "  local_ptr_upstreams:"; echo "    - 127.0.0.1:$NP"
	  echo "  use_private_ptr_resolvers: true"; } > "$1"
}
# opzione 6 del DHCP (DNS = indirizzo del router) per ogni rete di casa con il DHCP acceso, se l'utente non ne ha una sua:
# con dnsmasq fuori dalla 53 non la annuncia più. ADD6 = «sezione|6,ip» messe dal pacchetto; indirizzo cambiato = rifatta.
# Usa MAP («rete=IPv4» di homeips); CH=1 se qualcosa è cambiato
opt6() {
	CH=0; NA=
	for s in $(uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=dhcp$/\1/p"); do
		[ "$(uci -q get dhcp.$s.ignore)" = 1 ] && continue
		n=$(uci -q get dhcp.$s.interface); ip=
		for x in $MAP; do [ "${x%%=*}" = "$n" ] && { ip=${x#*=}; break; }; done; [ -n "$ip" ] || continue
		o=; for x in $ADD6; do [ "${x%%|*}" = "$s" ] && o=${x#*|}; done
		if [ -n "$o" ]; then
			[ "$o" = "6,$ip" ] || { uci -q del_list dhcp.$s.dhcp_option="$o"; uci add_list dhcp.$s.dhcp_option="6,$ip"; CH=1; }
		else
			case " $(uci -q get dhcp.$s.dhcp_option) " in *" 6,"*|*" option:dns-server,"*) continue ;; esac
			uci add_list dhcp.$s.dhcp_option="6,$ip"; CH=1
		fi
		NA="$NA $s|6,$ip"
	done
	for x in $ADD6; do case " $NA " in *" ${x%%|*}|"*) ;; *) NA="$NA $x" ;; esac; done	# reti spente: restano com'erano
	ADD6=${NA# }
}
rb_full() {	# ritorno completo alla copia (entro i 120 s, oppure dopo un cambio interrotto)
	svc stop; uci -q revert dhcp; cp $N/dhcp /etc/config/dhcp; cp $N/yaml "$Y"; /etc/init.d/dnsmasq restart >/dev/null 2>&1; svc start
	rm -rf $N $PD /tmp/wf-adgmode.ok /tmp/wf-adgmode.no
	st back "$1"; ev adg_mode "↩️ $1"
}
recover() {	# cambio interrotto a metà (adgmode.new rimasto, nessun adgmode vivo): 0 = sistemato, 1 = niente da fare
	[ -d $N ] && ! alive || return 1
	detect
	if [ -f $N/dhcp ] && [ -f $N/yaml ] && [ -n "$Y" ] && [ -n "$A" ]; then
		rb_full "$(t "Cambio interrotto: DNS rimesso com'era" "Change interrupted: DNS restored")"
	elif [ ! -f $N/dhcp ] && [ ! -f $N/yaml ] && [ -f $N/orig ]; then
		rm -rf $S; mv $N $S; rm -f $PD	# interrotto subito dopo la conferma: lo schema diretto resta
	else
		rm -rf $N $PD	# interrotto durante la copia: niente era ancora cambiato
	fi
	return 0
}
do_recover() { alive && exit 0; [ -d $N ] || exit 0; rmdir $LK 2>/dev/null; lock try; recover; }
do_direct() {
	lock; recover; st run "$(t "Cambio in corso" "Switching")"
	detect || { st err "$(t "AdGuard Home o dnsmasq non trovati" "AdGuard Home or dnsmasq not found")"; exit 1; }
	[ -f $FB ] && { st err "$(t "DNS di riserva in uso: AdGuard non risponde" "Backup DNS in use: AdGuard is not answering")"; exit 1; }
	[ "$MODE" = std ] || { st err "$(t "Schema del DNS non riconosciuto (serve dnsmasq sulla 53 che inoltra ad AdGuard)" "Unknown DNS layout (needs dnsmasq on 53 forwarding to AdGuard)")"; exit 1; }
	[ "$(dsec | wc -l)" = 1 ] || { st err "$(t "Più istanze di dnsmasq: cambio non gestito" "Several dnsmasq instances: not supported")"; exit 1; }
	NP=$(freeport 54 5354 1053 10053) || { st err "$(t "Nessuna porta libera per dnsmasq" "No free port for dnsmasq")"; exit 1; }
	H=$(homeips); IPS=$(echo "$H" | sed -n 1p); MAP=$(echo "$H" | sed -n 2p)
	[ -n "$IPS" ] || { st err "$(t "Reti di casa non trovate" "Home networks not found")"; exit 1; }
	DOM=$(uci -q get dhcp.$D.domain); DOM=${DOM:-lan}
	# copia di tutto prima del cambio
	rm -rf $N; mkdir -p $N && cp /etc/config/dhcp $N/dhcp && cp "$Y" $N/yaml || { st err "$(t "Copia non riuscita (spazio pieno?)" "Backup failed (storage full?)")"; rm -rf $N; exit 1; }
	for k in bind_hosts port local_ptr_upstreams use_private_ptr_resolvers; do yblk "$Y" $k; done > $N/orig.y
	# chiavi che prima non c'erano: «back» le toglie
	YNO=; for k in local_ptr_upstreams use_private_ptr_resolvers; do [ -n "$(yblk "$Y" $k)" ] || YNO="$YNO $k"; done
	SRVD=; NR=$(uci -q get dhcp.$D.noresolv); ADD6=; LDOM=$(ldoms all)
	newblocks $N/new.y
	svc stop; yset "$Y" $N/new.y
	uci set dhcp.$D.port=$NP
	for s in $(uci -q get dhcp.$D.server); do case "$s" in 127.0.0.1#$AP|::1#$AP|localhost#$AP) SRVD="$SRVD $s"; uci -q del_list dhcp.$D.server="$s" ;; esac; done
	# dnsmasq resta con i server dell'operatore (servono al DNS di riserva)
	[ -z "$(uci -q get dhcp.$D.server)" ] && [ "$NR" = 1 ] && uci set dhcp.$D.noresolv=0
	opt6	# con una porta diversa dalla 53 dnsmasq non annuncia più il DNS nel DHCP
	printf "DP='%s'\nAP='%s'\nNP='%s'\nSRVD='%s'\nNR='%s'\nADD6='%s'\nDOM='%s'\nLDOM='%s'\nYNO='%s'\n" "$DP" "$AP" "$NP" "${SRVD# }" "$NR" "$ADD6" "$DOM" "$LDOM" "${YNO# }" > $N/orig
	dnsm; svc start
	# mai senza DNS: AdGuard deve rispondere sulla 53 da 127.0.0.1 e dal primo IPv4 di casa (5 prove), altrimenti ritorno immediato
	IP4=; for a in $IPS; do case "$a" in *.*) IP4=$a; break ;; esac; done
	if ! waitans 127.0.0.1 5 || { [ -n "$IP4" ] && ! waitans "$IP4" 5; }; then rb_full "$(t "AdGuard non risponde sulla porta 53: DNS rimesso com'era" "AdGuard did not answer on port 53: DNS restored")"; exit 1; fi
	# i nomi che dnsmasq risolve da sé (DDNS su address=, host del dominio di casa…) attraverso AdGuard devono avere la
	# risposta di dnsmasq (al massimo 10 nomi, 3 prove): altrimenti ritorno immediato. dnsmasq deve rispondere sulla sua
	# porta; un nome senza risposta di dnsmasq non conta: con nomi da provare almeno uno va confrontato davvero
	waitans 127.0.0.1:$NP 3 || { rb_full "$(t "dnsmasq non risponde sulla porta $NP: DNS rimesso com'era" "dnsmasq did not answer on port $NP: DNS restored")"; exit 1; }
	HN=$(uci -q get system.@system[0].hostname); bad=; n=0; ok=0
	for x in ${HN:+$HN.$DOM} $(ldoms); do
		x=${x#=}; case "$x" in -*|*[!A-Za-z0-9_.-]*) continue ;; esac
		[ $n -ge 10 ] && break; n=$((n+1)); w=$(nsa "$x" 127.0.0.1:$NP); [ -n "$w" ] || continue; i=0
		while [ "$(nsa "$x" 127.0.0.1)" != "$w" ]; do [ $i -ge 2 ] && { bad=$x; break 2; }; sleep 2; i=$((i+1)); done
		ok=$((ok+1))
	done
	[ -z "$bad" ] && [ $n -gt 0 ] && [ $ok = 0 ] && { rb_full "$(t "dnsmasq non risponde per i suoi nomi: DNS rimesso com'era" "dnsmasq does not answer for its names: DNS restored")"; exit 1; }
	[ -n "$bad" ] && { rb_full "$(t "AdGuard non risponde come dnsmasq per $bad: DNS rimesso com'era" "AdGuard does not answer like dnsmasq for $bad: DNS restored")"; exit 1; }
	id=$(date +%s); echo $id > $PD; rm -f /tmp/wf-adgmode.ok /tmp/wf-adgmode.no
	st wait "$(t "AdGuard risponde ai dispositivi: conferma entro 120 s" "AdGuard answers devices: confirm within 120 s")" $((id + 120))
	i=0; while [ $i -lt 60 ]; do
		[ -f /tmp/wf-adgmode.ok ] && break
		[ -f /tmp/wf-adgmode.no ] && { rb_full "$(t "Cambio annullato: DNS rimesso com'era" "Change cancelled: DNS restored")"; exit 0; }
		sleep 2; i=$((i+1))
	done
	[ -f /tmp/wf-adgmode.ok ] || { rb_full "$(t "Nessuna conferma entro 120 s: DNS rimesso com'era" "No confirmation within 120 s: DNS restored")"; exit 0; }
	rm -f $N/dhcp $N/yaml $N/new.y; rm -rf $S; mv $N $S; rm -f $PD /tmp/wf-adgmode.ok
	# DNS di riserva acceso di serie con lo schema diretto (se l'utente non l'ha mai scelto)
	[ -z "$(uci -q get wrtfreedom.dnsfb.on)" ] && { uci -q get wrtfreedom.dnsfb >/dev/null || uci set wrtfreedom.dnsfb=dnsfb; uci set wrtfreedom.dnsfb.on=1; uci commit wrtfreedom; }
	st ok "$(t "AdGuard risponde ai dispositivi" "AdGuard answers devices")"
	ev adg_mode "🛡️ $(t "AdGuard risponde direttamente ai dispositivi (dnsmasq sulla porta $NP)" "AdGuard answers devices directly (dnsmasq on port $NP)")"
}
do_back() {
	lock; recover; st run "$(t "Cambio in corso" "Switching")"
	detect || { st err "$(t "AdGuard Home o dnsmasq non trovati" "AdGuard Home or dnsmasq not found")"; exit 1; }
	FBM=; [ -f $FB ] && FBM=$(sed -n "s/^MODE='\(.*\)'$/\1/p" $FB)
	[ "$MODE" = direct ] || [ "$FBM" = direct ] || { st err "$(t "AdGuard non risponde già direttamente" "AdGuard is not answering directly")"; exit 1; }
	SRVD=; NR=; ADD6=; DOM=; LDOM=; YNO=; NP=$DP
	# DNS di riserva in corso con lo schema diretto (dnsmasq già sulla 53, AdGuard fermo): server pubblici tolti
	if [ "$FBM" = direct ]; then NP=$(sed -n "s/^NP='\(.*\)'$/\1/p" $FB); PUB=$(sed -n "s/^PUB='\(.*\)'$/\1/p" $FB); for s in $PUB; do uci -q del_list dhcp.$D.server=$s; done; rm -f $FB $CNT; fi
	[ -f $S/orig ] && . $S/orig
	DOM=${DOM:-$(uci -q get dhcp.$D.domain)}; DOM=${DOM:-lan}
	TY=/tmp/wf-adgmode.y; : > $TY
	if [ -f $S/orig.y ] && [ -s $S/orig.y ]; then cat $S/orig.y > $TY
	else	# schema diretto non fatto dall'app: AdGuard su 127.0.0.1 e una porta libera
		AP=$(freeport 3053 5335 15353) || { st err "$(t "Nessuna porta libera per AdGuard" "No free port for AdGuard")"; exit 1; }
		DP=53; SRVD="127.0.0.1#$AP"; NR=1
		printf "  bind_hosts:\n    - '127.0.0.1'\n  port: %s\n  local_ptr_upstreams:\n    - 127.0.0.1:53\n  use_private_ptr_resolvers: true\n" "$AP" >> $TY
	fi
	{ echo "  upstream_dns:"; for u in $(yitems "$Y" upstream_dns); do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; echo "    - $u"; done; } >> $TY
	svc stop; yset "$Y" $TY; rm -f $TY; [ -n "$YNO" ] && ydel "$Y" "$YNO"
	if [ "${DP:-53}" = 53 ]; then uci -q delete dhcp.$D.port; else uci set dhcp.$D.port="$DP"; fi
	for s in $SRVD; do uci -q del_list dhcp.$D.server="$s"; uci add_list dhcp.$D.server="$s"; done
	if [ -n "$NR" ]; then uci set dhcp.$D.noresolv="$NR"; else uci -q delete dhcp.$D.noresolv; fi
	for x in $ADD6; do uci -q del_list "dhcp.${x%%|*}.dhcp_option=${x#*|}"; done
	dnsm; svc start; rm -rf $S
	# mai senza DNS: se AdGuard non risponde dietro a dnsmasq, i server dell'operatore finché non torna
	if ! waitans 127.0.0.1 10; then detect; [ "$MODE" = std ] && fb_down; fi
	st ok "$(t "DNS come prima: dnsmasq sulla 53 inoltra ad AdGuard" "DNS as before: dnsmasq on 53 forwards to AdGuard")"
	ev adg_mode "↩️ $(t "DNS come prima: dnsmasq sulla 53 inoltra ad AdGuard" "DNS as before: dnsmasq on 53 forwards to AdGuard")"
}
do_rebind() {
	sleep 3; lock try
	[ -f $S/orig ] && [ ! -f $FB ] && [ ! -f $PD ] || exit 0
	detect && [ "$MODE" = direct ] || exit 0
	H=$(homeips); IPS=$(echo "$H" | sed -n 1p); MAP=$(echo "$H" | sed -n 2p); [ -n "$IPS" ] || exit 0
	# opzione 6 del DHCP anche per le reti di casa nuove (o con l'indirizzo cambiato), segnata in $S/orig per «back»
	ADD6=$(oget ADD6); opt6
	if [ $CH = 1 ]; then oput ADD6 "$ADD6"; dnsm; fi
	# nomi di dnsmasq cambiati (address, host…): voci del pacchetto in AdGuard rifatte, quelle dell'utente restano
	DOM=$(oget DOM); NP=$(oget NP); LDOM=$(oget LDOM); YUP=$(yitems "$Y" upstream_dns); NL=$(lfree "$(ldoms all)")
	TY=/tmp/wf-adgmode.y; : > $TY
	if [ -n "$DOM" ] && [ -n "$NP" ] && [ "$NL" != "$LDOM" ]; then
		{ echo "  upstream_dns:"; for u in $YUP; do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; echo "    - $u"; done
		  LDOM=$NL; lent; } > $TY
		oput LDOM "$LDOM"
	fi
	cur=$(yitems "$Y" bind_hosts | tr -d "'\"" | sort | tr '\n' ' '); new=$(for a in 127.0.0.1 $(v6lo) $IPS; do echo $a; done | sort | tr '\n' ' ')
	[ "$cur" = "$new" ] && [ ! -s $TY ] && ans 127.0.0.1 && { rm -f $TY; exit 0; }
	{ echo "  bind_hosts:"; for a in 127.0.0.1 $(v6lo) $IPS; do echo "    - '$a'"; done; } >> $TY
	svc stop; yset "$Y" $TY; rm -f $TY; svc start
	waitans 127.0.0.1 10 && exit 0
	[ "$(uci -q get wrtfreedom.dnsfb.on)" = 1 ] && fb_down
}

case "$1" in
	direct) do_direct ;;
	back) do_back ;;
	check) do_check ;;
	rebind) do_rebind ;;
	recover) do_recover ;;
	*) echo "uso: adgmode.sh direct|back|check|rebind|recover"; exit 1 ;;
esac
exit 0
