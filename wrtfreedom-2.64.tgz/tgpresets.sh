#!/bin/sh
# WrtFreedom: Comandi Pronti del bot Telegram.
# uso: tgpresets.sh <comando>   (il valore scritto dopo il comando arriva in $ARG)
# Le righe "#%" sono le categorie, le righe "#@" il catalogo letto dall'app e dal bot:
#   nome|nome inglese|categoria|opzioni|requisiti|descrizione|descrizione inglese|valore richiesto|valore richiesto inglese
# opzioni: d = installato di serie · l = sempre presente · c = chiede conferma · a = chiede un valore · o = valore facoltativo
#          f = manda una foto o un file (serve curl)
# requisiti: modem wifi guest wg adg qr wol nlbw thermal ddns curl hostapd trace conntrack sqm
# Uscita: testo da mandare; una prima riga "@@PHOTO <file>" o "@@DOC <file>" manda il file con il resto come didascalia
# ("@@DOC <file> ttl=<secondi>" = il bot cancella il messaggio dopo quei secondi, 2.48).
#
#% stato|Stato|Status|📊
#% linea|Linea e Modem|Line and Modem|📡
#% wifi|Wi-Fi|Wi-Fi|📶
#% dev|Dispositivi|Devices|📱
#% vpn|VPN Per Fuori Casa|Away From Home VPN|🔐
#% dns|AdGuard e DNS|AdGuard and DNS|🛡
#% diag|Diagnostica|Diagnostics|🩺
#% sys|Sistema|System|⚙️
#
#@ stato|status|stato|d||Riepilogo: linea, IP, carico, dispositivi|Summary: line, IP, load, devices||
#@ uptime|uptime|stato|||Da quanto è acceso il router|How long the router has been on||
#@ carico|load|stato|||Carico e uso del processore|Processor load and usage||
#@ memoria|memory|stato|||Memoria usata e libera|Used and free memory||
#@ disco|disk|stato|||Spazio su memoria interna e dischi|Space on internal storage and drives||
#@ temperatura|temperature|stato||thermal|Temperatura del router|Router temperature||
#@ versione|version|stato|||Modello, firmware e versioni|Model, firmware and versions||
#@ ip|ip|stato|d||Indirizzo IP della linea e pubblico|Line and public IP address||
#@ ipv6|ipv6|stato|||Indirizzi IPv6 della linea|Line IPv6 addresses||
#@ velocita|speed|stato|||Velocità della linea in questo momento|Line speed right now||
#@ consumo|usage|stato|||Dati scaricati e inviati dall'accensione|Data downloaded and sent since boot||
#@ ora|time|stato|||Data, ora e fuso orario del router|Router date, time and time zone||
#@ linea|line|linea|||Stato della connessione internet|Internet connection status||
#@ riconnetti|reconnect|linea|c||Riconnette la linea internet|Reconnects the internet line||
#@ segnale|signal|linea||modem|Qualità del segnale mobile|Mobile signal quality||
#@ cella|cell|linea||modem|Cella a cui è collegato il modem|Cell the modem is connected to||
#@ bande|bands|linea||modem|Bande in uso e abilitate|Bands in use and enabled||
#@ operatore|operator|linea||modem|Operatore e tecnologia|Operator and technology||
#@ rete_mobile|mobile_network|linea||modem|Tecnologia, banda e canale|Technology, band and channel||
#@ sim|sim|linea||modem|Stato della SIM|SIM status||
#@ imei|imei|linea||modem|IMEI del modem|Modem IMEI||
#@ riavvia_modem|restart_modem|linea|c|modem|Riavvia il modem|Restarts the modem||
#@ solo4g|lte_only|linea|c|modem|Modem solo in 4G|Modem in 4G only||
#@ standard|standard|linea|c|modem|Modem in 4G + 5G NSA|Modem in 4G + 5G NSA||
#@ celle|cells|linea||modem|Celle vicine|Nearby cells||
#@ temp_modem|modem_temp|linea||modem|Temperatura del modem|Modem temperature||
#@ apn|apn|linea||modem|APN configurati nel modem|APNs set in the modem||
#@ sms|sms|linea||modem|SMS ricevuti sulla SIM|SMS received on the SIM||
#@ at|at|linea|a|modem|Manda un comando AT al modem|Sends an AT command to the modem|Comando AT (es. AT+CSQ)|AT command (e.g. AT+CSQ)
#@ sqm|line_control|linea||sqm|Controllo Della Linea: stato e limiti|Line Control: status and limits||
#@ sqm_on|line_control_on|linea||sqm|Accende il Controllo Della Linea|Turns Line Control on||
#@ sqm_off|line_control_off|linea|c|sqm|Spegne il Controllo Della Linea|Turns Line Control off||
#@ sqm_profilo|line_control_profile|linea|a|sqm|Profilo del Controllo Della Linea|Line Control profile|prudente, bilanciato, veloce, spento o un profilo per orario|cautious, balanced, fast, off or a scheduled profile
#@ wifi|wifi|wifi|d|wifi|Reti Wi-Fi e dispositivi collegati|Wi-Fi networks and connected devices||
#@ wifi_on|wifi_on|wifi|d|wifi|Accende il Wi-Fi|Turns Wi-Fi on||
#@ wifi_off|wifi_off|wifi|cd|wifi|Spegne il Wi-Fi|Turns Wi-Fi off||
#@ wifi_riavvia|wifi_restart|wifi|c|wifi|Riavvia il Wi-Fi|Restarts Wi-Fi||
#@ ospiti|guest|wifi||guest|Stato della rete ospiti|Guest network status||
#@ ospiti_on|guest_on|wifi||guest|Accende la rete ospiti|Turns the guest network on||
#@ ospiti_off|guest_off|wifi|c|guest|Spegne la rete ospiti|Turns the guest network off||
#@ password_wifi|wifi_password|wifi|of|wifi,curl|Nome e password delle reti|Network names and passwords|Nome della rete (facoltativo)|Network name (optional)
#@ qr_wifi|wifi_qr|wifi|of|wifi,qr,curl|QR per collegarsi al Wi-Fi|QR code to join Wi-Fi|Nome della rete (facoltativo)|Network name (optional)
#@ canali|channels|wifi||wifi|Reti vicine per canale|Nearby networks by channel||
#@ segnale_wifi|wifi_signal|wifi||wifi|Segnale dei dispositivi in Wi-Fi|Signal of Wi-Fi devices||
#@ potenza|tx_power|wifi||wifi|Canale e potenza delle radio|Radio channel and power||
#@ client|clients|dev|d||Dispositivi collegati|Connected devices||
#@ online|online|dev|||Dispositivi attivi adesso|Devices active right now||
#@ nuovi|new|dev|||Ultimi dispositivi nuovi|Latest new devices||
#@ cerca|find|dev|a||Cerca un dispositivo|Finds a device|Nome, IP o MAC|Name, IP or MAC
#@ dettagli|details|dev|a||Dettagli di un dispositivo|Device details|Nome, IP o MAC|Name, IP or MAC
#@ blocca|block|dev|ca||Blocca internet a un dispositivo|Blocks internet for a device|Nome, IP o MAC|Name, IP or MAC
#@ sblocca|unblock|dev|a||Sblocca un dispositivo|Unblocks a device|Nome, IP o MAC|Name, IP or MAC
#@ client_bloccati|blocked_clients|dev|||Dispositivi bloccati|Blocked devices||
#@ disconnetti|kick|dev|ca|hostapd|Scollega un dispositivo dal Wi-Fi|Kicks a device off Wi-Fi|Nome, IP o MAC|Name, IP or MAC
#@ sveglia|wake|dev|a|wol|Accende un computer dalla rete|Wakes a computer over the network|Nome o MAC|Name or MAC
#@ top_client|top_clients|dev|||Chi ha consumato più dati|Who used the most data||
#@ fasce|time_slots|dev|||Orari e velocità: limiti e fasce di oggi|Schedules and speed: limits and slots for today||
#@ limita|limit|dev|a||Limita la velocità di un dispositivo|Limits the speed of a device|Nome e Mbit/s (es. TV 20), off per togliere|Name and Mbit/s (e.g. TV 20), off to remove
#@ rallenta|slow_down|dev|a||Rallenta per qualche minuto un dispositivo, una persona o la casa|Slows down a device, a person or the house for a while|Nome, Mbit/s e minuti (es. TV 10 60), off per togliere|Name, Mbit/s and minutes (e.g. TV 10 60), off to remove
#@ ip_fissi|static_ips|dev|||Indirizzi IP riservati|Reserved IP addresses||
#@ vpn|vpn|vpn|d|wg|Stato della VPN Per Fuori Casa|Away From Home VPN status||
#@ vpn_on|vpn_on|vpn|d|wg|Accende la VPN Per Fuori Casa|Turns the Away From Home VPN on||
#@ vpn_off|vpn_off|vpn|cd|wg|Spegne la VPN Per Fuori Casa|Turns the Away From Home VPN off||
#@ vpn_riavvia|vpn_restart|vpn|c|wg|Riavvia la VPN Per Fuori Casa|Restarts the Away From Home VPN||
#@ vpn_peer|vpn_peers|vpn||wg|Chi è collegato alla VPN Per Fuori Casa|Who is connected to the Away From Home VPN||
#@ vpn_traffico|vpn_traffic|vpn||wg|Dati scambiati da ogni client|Data used by each client||
#@ vpn_qr|vpn_qr|vpn|af|wg,qr,curl|QR di un dispositivo della VPN Per Fuori Casa|QR code of an Away From Home VPN device|Nome del client|Client name
#@ vpn_nuovo|vpn_new|vpn|af|wg,qr,curl|Aggiunge un dispositivo alla VPN Per Fuori Casa con QR|Adds a device to the Away From Home VPN with QR|Nome del nuovo client|New client name
#@ vpn_indirizzo|vpn_address|vpn||wg|Indirizzo e porta per collegarsi|Address and port to connect||
#@ servizio_vpn|vpn_service|vpn|o|vpnsvc|Servizio VPN: stato, on o off|VPN Service: status, on or off|on oppure off (facoltativo)|on or off (optional)
#@ adguard|adguard|dns||adg|Stato e statistiche di AdGuard|AdGuard status and stats||
#@ adg_on|adg_on|dns||adg|Accende la protezione|Turns protection on||
#@ adg_off|adg_off|dns|c|adg|Spegne la protezione|Turns protection off||
#@ pausa|pause|dns|a|adg|Pausa della protezione|Pauses protection|Minuti di pausa|Minutes to pause
#@ top_bloccati|top_blocked|dns||adg|Domini più bloccati|Most blocked domains||
#@ top_domini|top_domains|dns||adg|Domini più richiesti|Most requested domains||
#@ top_client_dns|top_dns_clients|dns||adg|Dispositivi con più richieste|Devices with the most requests||
#@ filtri|filters|dns||adg|Liste di blocco attive|Active blocklists||
#@ risolvi|resolve|dns|a||Risolve un nome di dominio|Resolves a domain name|Dominio (es. google.com)|Domain (e.g. google.com)
#@ dns_svuota|dns_flush|dns|||Svuota la cache DNS|Clears the DNS cache||
#@ dns_server|dns_servers|dns|||Server DNS usati dal router|DNS servers used by the router||
#@ ping|ping|diag|a||Ping verso un indirizzo|Pings an address|Indirizzo o nome|Address or name
#@ traceroute|traceroute|diag|a|trace|Percorso verso un indirizzo|Route to an address|Indirizzo o nome|Address or name
#@ latenza|latency|diag|||Latenza verso gateway e internet|Latency to gateway and internet||
#@ speedtest|speedtest|diag|||Test di velocità della linea|Line speed test||
#@ porte|ports|diag|||Porte aperte verso i dispositivi|Ports forwarded to devices||
#@ interfacce|interfaces|diag|||Interfacce di rete e indirizzi|Network interfaces and addresses||
#@ route|routes|diag|||Tabella di routing|Routing table||
#@ ddns|ddns|diag||ddns|Stato del DNS dinamico|Dynamic DNS status||
#@ nat|nat|diag|||Verifica NAT e CGNAT della linea|Checks the line for NAT and CGNAT||
#@ connessioni|connections|diag||conntrack|Connessioni aperte|Open connections||
#@ porta|port|diag|a|curl|Prova se una porta risponde|Tests whether a port answers|Indirizzo e porta (es. 1.1.1.1 443)|Address and port (e.g. 1.1.1.1 443)
#@ riavvia|reboot|sys|cd||Riavvia il router|Restarts the router||
#@ riavvia_rete|restart_network|sys|c||Riavvia la rete|Restarts the network||
#@ log|log|sys|||Ultime righe del registro|Latest log lines||
#@ errori|errors|sys|||Errori e avvisi nel registro|Errors and warnings in the log||
#@ processi|processes|sys|||Programmi che usano più risorse|Programs using the most resources||
#@ servizi|services|sys|||Servizi attivi e fermi|Running and stopped services||
#@ servizio|service|sys|ca||Riavvia un servizio|Restarts a service|Nome del servizio|Service name
#@ aggiornamenti|updates|sys|||Pacchetti da aggiornare|Packages to update||
#@ aggiorna_pacchetto|update_package|sys|c||Aggiorna il Pacchetto Router dal server|Updates the Router Package from the server||
#@ backup|backup|sys|f|curl|Manda qui il backup delle impostazioni|Sends the settings backup here||
#@ eventi|events|sys|d||Ultimi eventi del router|Latest router events||
#@ usb|usb|sys|||Dispositivi USB collegati|Connected USB devices||
#@ cron|cron|sys|||Operazioni pianificate|Scheduled tasks||
#@ libera_ram|free_ram|sys|||Libera la memoria cache|Frees cached memory||
#@ sincronizza_ora|sync_time|sys|||Rimette l'orologio con internet|Syncs the clock with the internet||
#@ menu|menu|sys|l||Pulsanti dei comandi per categoria|Command buttons by category||
#@ aiuto|help|sys|l||Elenco dei comandi|List of commands||

W=/usr/share/wrtfreedom
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
A=$(printf '%s' "$ARG" | tr -d '\r\n' | sed 's/^ *//; s/ *$//')
LOG=/tmp/wf-events.log; [ "$(uci -q get wrtfreedom.ev.persist)" = 1 ] && LOG=/etc/wrtfreedom/events.log

# ---------- aiuti ----------
hb() { awk -v b="${1:-0}" 'BEGIN{split("B KB MB GB TB",u," ");i=1;while(b>=1024&&i<5){b/=1024;i++}if(i==1)printf "%d %s",b,u[i];else printf "%.1f %s",b,u[i]}'; }
dur() { awk -v s="${1:-0}" -v d="$(t g d)" 'BEGIN{s=int(s);x=int(s/86400);h=int(s%86400/3600);m=int(s%3600/60);if(x)printf "%d%s %dh %dm",x,d,h,m;else if(h)printf "%dh %dm",h,m;else printf "%dm %ds",m,s%60}'; }
export EN
J() { ucode -e "let EN=getenv('EN')=='1'; let d=json(require('fs').stdin.read('all')||'null'); if(d==null) exit(0); $1"; }
get() { if command -v curl >/dev/null 2>&1; then curl -s -m "${2:-15}" "$1"; else uclient-fetch -q -T "${2:-15}" -O - "$1"; fi 2>/dev/null; }
wanifs() { for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do [ "$(uci -q get firewall.$z.name)" = vpnout ] || uci -q get "firewall.$z.network"; done | tr ' ' '\n' | grep -v '^$'; }	# zona internet vera (con il NAT)
wgif() { for i in $(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)' | head -n 1; }
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
ifip() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null; }
wanip() { for i in $(wanifs); do ifip "$i"; done | head -n 1; }
wandevs() { for i in $(wanifs); do ifstatus "$i" 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null; done | sort -u; }
pubip() { get https://api.ipify.org 8 | grep -oE '^[0-9.]+$' || get https://ifconfig.me/ip 8 | grep -oE '^[0-9.]+$'; }
cgnat() { echo "$1" | grep -qE '^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.)'; }
ATR() { sh $W/at.sh "$1" 2>/dev/null | tr -d '\r'; }
leases() { f=$(uci -q get dhcp.@dnsmasq[0].leasefile); cat "${f:-/tmp/dhcp.leases}" 2>/dev/null; }
# dispositivi conosciuti: "mac ip nome" (contratti DHCP e indirizzi riservati)
devs() {
	leases | awk '{n=($4=="*")?"-":$4; print tolower($2), $3, n}'
	for h in $(uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=host$/\1/p"); do
		m=$(uci -q get dhcp.$h.mac | awk '{print tolower($1)}'); [ -n "$m" ] || continue
		echo "$m $(uci -q get dhcp.$h.ip || echo -) $(uci -q get dhcp.$h.name || echo -)"
	done
}
devname() { devs | awk -v m="$(echo "$1" | tr 'A-F' 'a-f')" '$1==m && $3!="-"{print $3; exit}'; }
# trova i dispositivi che corrispondono a $A (nome, IP o MAC); senza risultati spiega e esce
find_dev() {
	[ -n "$A" ] || { t "Scrivi anche il nome, l'IP o il MAC del dispositivo" "Also type the device name, IP or MAC"; exit 0; }
	R=$(devs | awk -v q="$(echo "$A" | tr 'A-Z' 'a-z')" '!s[$1]++ && (tolower($3)==q || $2==q || $1==q || index(tolower($3),q))')
	[ -n "$R" ] || { echo "$A" | grep -qiE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' && R="$(echo "$A" | tr 'A-F' 'a-f') - $A"; }
	[ -n "$R" ] || { t "Nessun dispositivo trovato per \"$A\"" "No device found for \"$A\""; exit 0; }
}
one_dev() {
	find_dev
	[ "$(echo "$R" | wc -l)" -gt 1 ] && { t "Più dispositivi corrispondono, scrivi il nome intero o il MAC:" "Several devices match, type the full name or MAC:"; echo; echo "$R" | awk '{print "• " $3 " · " $2 " · " $1}'; exit 0; }
	MAC=$(echo "$R" | awk '{print $1}'); IP=$(echo "$R" | awk '{print $2}'); NM=$(echo "$R" | awk '{print $3}'); [ "$NM" = - ] && NM=$MAC
}
online_macs() { ip neigh show 2>/dev/null | awk '/REACHABLE|STALE|DELAY|PROBE/ && /lladdr/{for(i=1;i<=NF;i++)if($i=="lladdr")print tolower($(i+1))}' | sort -u; }
wifi_ifs() { iwinfo 2>/dev/null | awk '/ESSID/{print $1}'; }
adgcred() { cat /etc/wrtfreedom/adguard 2>/dev/null; }
adgaddr() { a=$(awk '/^http:/{f=1} f&&/address:/{print $2; exit}' /etc/adguardhome/adguardhome.yaml 2>/dev/null); [ -n "$a" ] || a=$(awk '/^bind_port:/{print "127.0.0.1:" $2; exit}' /etc/adguardhome/adguardhome.yaml 2>/dev/null); echo "${a:-127.0.0.1:3000}" | sed 's/^0\.0\.0\.0:/127.0.0.1:/'; }
# adg METODO percorso [corpo]: API di AdGuard Home con le credenziali salvate nell'app
adg() {
	[ -n "$(adgcred)" ] || { t "Collega prima AdGuard Home nell'app (Altro › AdGuard)" "Link AdGuard Home in the app first (More › AdGuard)"; exit 0; }
	K=/tmp/wf-tga.$$; printf 'user = "%s"\n' "$(adgcred)" > $K; chmod 600 $K
	if [ -n "$3" ]; then curl -s -m 15 -K $K -X "$1" -H 'Content-Type: application/json' --data "$3" "http://$(adgaddr)/control/$2"
	else curl -s -m 15 -K $K -X "$1" "http://$(adgaddr)/control/$2"; fi
	rm -f $K
}
uerr() { e=$(echo "$1" | jsonfilter -e '@.error' 2>/dev/null); echo "${e:-${1:-$(t "Nessuna risposta dal router" "No answer from the router")}}"; }
okhost() { echo "$1" | grep -qE '^[A-Za-z0-9.:-]{1,253}$' || { t "Indirizzo non valido" "Invalid address"; exit 0; }; }
wgconf() { # $1 = sezione del client: stampa la configurazione completa (serve la chiave salvata dall'app)
	I=$(wgif); s=$1; pk=$(uci -q get wrtfreedom.peer_$s.priv)
	[ -n "$pk" ] || return 1
	sp=$(uci -q get network.$I.private_key | wg pubkey 2>/dev/null)
	h=$(uci -q get wrtfreedom.wg.host); [ -n "$h" ] || h=$(uci -q show ddns | sed -n "s/^ddns\.[^.]*\.lookup_host='\(.*\)'$/\1/p" | head -n 1); [ -n "$h" ] || h=$(wanip)
	d=$(uci -q get wrtfreedom.wg.dns); [ -n "$d" ] || d=$(uci -q get network.lan.ipaddr)
	ad=$(uci -q get network.$s.allowed_ips | awk '{print $1}')
	if [ "$(uci -q get wrtfreedom.peer_$s.full)" = 1 ]; then al="0.0.0.0/0, ::/0"; else
		eval "$(ipcalc.sh $(uci -q get network.$I.addresses | awk '{print $1}') 2>/dev/null)"; vn="$NETWORK/$PREFIX"
		eval "$(ipcalc.sh $(uci -q get network.lan.ipaddr) $(uci -q get network.lan.netmask) 2>/dev/null)"; al="$vn, $NETWORK/$PREFIX"; fi
	printf '[Interface]\nPrivateKey = %s\nAddress = %s\nDNS = %s\n\n[Peer]\nPublicKey = %s\n' "$pk" "$ad" "$d" "$sp"
	ps=$(uci -q get network.$s.preshared_key); [ -n "$ps" ] && printf 'PresharedKey = %s\n' "$ps"
	printf 'Endpoint = %s:%s\nAllowedIPs = %s\nPersistentKeepalive = 25\n' "$h" "$(uci -q get network.$I.listen_port)" "$al"
}
peer_find() { # sezione del client VPN con quel nome
	I=$(wgif)
	for s in $(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)=wireguard_$I$/\1/p"); do
		[ "$(uci -q get network.$s.description | tr 'A-Z' 'a-z')" = "$(echo "$1" | tr 'A-Z' 'a-z')" ] && { echo $s; return; }
	done
}
qrphoto() { # $1 testo, $2 didascalia
	f=/tmp/wf-tgqr.$$.png; qrencode -o $f -s 8 -m 2 "$1" 2>/dev/null || { t "QR non creato" "QR not created"; exit 0; }
	echo "@@PHOTO $f"; printf '%s' "$2"
}

# requisiti presenti su questo router: una riga "nome 1|0" (letta da app e bot, tenuta 60 s in /tmp)
if [ "$1" = --needs ]; then
	ok() { if "$@" >/dev/null 2>&1; then echo 1; else echo 0; fi; }
	echo "modem $( { [ "$(sh $W/at.sh --tool 2>/dev/null)" != none ] || mmcli -L 2>/dev/null | grep -q Modem; } && echo 1 || echo 0)"
	echo "wifi $( uci -q show wireless | grep -q '=wifi-iface' && command -v iwinfo >/dev/null && echo 1 || echo 0)"
	echo "guest $(ok sh -c "uci -q show wireless | grep -q \"network='guest'\"")"
	echo "wg $( command -v wg >/dev/null && [ -n "$(wgif)" ] && echo 1 || echo 0)"
	echo "adg $( { [ -x /etc/init.d/adguardhome ] || command -v AdGuardHome >/dev/null; } && [ -n "$(adgcred)" ] && command -v curl >/dev/null && echo 1 || echo 0)"
	echo "qr $(ok command -v qrencode)"
	echo "wol $( { command -v etherwake || command -v ether-wake; } >/dev/null && echo 1 || echo 0)"
	echo "nlbw $( command -v nlbw >/dev/null && pidof nlbwmon >/dev/null && echo 1 || echo 0)"
	echo "thermal $(ls /sys/class/thermal/thermal_zone*/temp >/dev/null 2>&1 && echo 1 || echo 0)"
	echo "ddns $(ok test -f /etc/config/ddns)"
	echo "curl $(ok command -v curl)"
	echo "hostapd $( [ -n "$(ubus list 'hostapd.*' 2>/dev/null)" ] && echo 1 || echo 0)"
	echo "trace $(ok command -v traceroute)"
	echo "conntrack $(ok test -r /proc/sys/net/netfilter/nf_conntrack_count)"
	echo "vpnsvc $(ok grep -q "^config vpntun" /etc/config/wrtfreedom)"
	echo "sqm $( [ -x /etc/init.d/sqm ] && uci -q show sqm | grep -q '=queue$' && echo 1 || echo 0)"
	exit 0
fi

case "$1" in
# ===================== STATO =====================
stato)
	ip=$(wanip); up=$(cut -d. -f1 /proc/uptime)
	w=$(ubus call network.wireless status 2>/dev/null | grep -c '"up": true')
	echo "📊 $(uci -q get system.@system[0].hostname)"
	echo "$(t Linea Line): $([ -n "$ip" ] && echo "🟢 $(t attiva up) · IP $ip" || echo "🔴 $(t giù down)")"
	echo "$(t "Acceso da" "Up for"): $(dur $up)"
	echo "$(t Carico Load): $(cut -d' ' -f1-3 /proc/loadavg)"
	echo "$(t "Memoria libera" "Free memory"): $(awk '/MemAvailable/{printf "%d MB",$2/1024}' /proc/meminfo)"
	echo "$(t Dispositivi Devices): $(leases | wc -l) · $(t "attivi" "active") $(online_macs | wc -l)"
	[ -f /etc/config/wireless ] && echo "Wi-Fi: $([ "$w" -gt 0 ] && t "acceso" "on" || t "spento" "off")"
	I=$(wgif); [ -n "$I" ] && echo "$(t "VPN Per Fuori Casa" "Away From Home VPN"): $(isup $I && t accesa on || t spenta off)"
	# Stato Della Casa (2.49): lo stesso calcolo della Dashboard e della notifica fissa
	ubus call wrtfreedom casa 2>/dev/null | J '
		print("\n" + (d.ok ? (EN ? "✅ All Good" : "✅ Tutto Bene") : (EN ? "⚠️ To Check: " : "⚠️ Da Vedere: ") + d.n) + "\n");
		for (let x in d.items) if (x.sev == "bad" || x.sev == "warn") print((x.sev == "bad" ? "🔴 " : "🟠 ") + x.text + "\n");
		if (d.today && d.today.b != null) print((EN ? "Today: " : "Oggi: ") + d.today.v + "\n");
	'
	;;
uptime)
	echo "⏱ $(t "Acceso da" "Up for") $(dur $(cut -d. -f1 /proc/uptime))"
	echo "$(t "Acceso il" "Started on") $(date -d @$(( $(date +%s) - $(cut -d. -f1 /proc/uptime) )) '+%d/%m/%Y %H:%M' 2>/dev/null)"
	;;
carico)
	set -- $(head -n 1 /proc/stat); a=$(( $2+$3+$4+$5+$6+$7+$8 )); b=$5
	sleep 1; set -- $(head -n 1 /proc/stat); c=$(( $2+$3+$4+$5+$6+$7+$8 )); d=$5
	echo "🧮 $(t Processore Processor): $(( 100 - 100 * (d - b) / (c - a + 1) ))% · $(grep -c ^processor /proc/cpuinfo) core"
	echo "$(t "Carico 1/5/15 min" "Load 1/5/15 min"): $(cut -d' ' -f1-3 /proc/loadavg)"
	echo "$(t Processi Processes): $(cut -d' ' -f4 /proc/loadavg | cut -d/ -f2)"
	;;
memoria)
	awk -v EN=$EN '/MemTotal/{t=$2}/MemAvailable/{a=$2}/^Cached/{c=$2}/SwapTotal/{st=$2}/SwapFree/{sf=$2}
	END{printf "🧠 %s %d MB · %s %d MB (%d%%)\n", EN?"Total":"Totale", t/1024, EN?"in use":"in uso", (t-a)/1024, (t-a)*100/t
	    printf "%s %d MB · cache %d MB\n", EN?"Available":"Disponibile", a/1024, c/1024
	    if(st>0) printf "Swap %d / %d MB\n", (st-sf)/1024, st/1024}' /proc/meminfo
	;;
disco)
	echo "💾 $(t "Spazio" "Space")"
	df -h 2>/dev/null | awk 'NR>1 && ($6=="/" || $6=="/overlay" || $6=="/tmp" || $6~/^\/mnt\// || $6~/^\/srv/){printf "• %s · %s/%s (%s)\n",$6,$3,$2,$5}'
	;;
temperatura)
	echo "🌡 $(t Temperatura Temperature)"
	for z in /sys/class/thermal/thermal_zone*; do
		[ -f $z/temp ] || continue
		awk -v n="$(cat $z/type 2>/dev/null)" '{v=$1; if(v>1000) v=v/1000; printf "• %s · %.0f °C\n", n, v}' $z/temp
	done
	for h in /sys/class/hwmon/hwmon*/temp1_input; do [ -f "$h" ] && awk -v n="$(cat ${h%/*}/name 2>/dev/null)" '{printf "• %s · %.0f °C\n", n, $1/1000}' $h; done 2>/dev/null
	;;
versione)
	[ -f /etc/openwrt_release ] && . /etc/openwrt_release
	echo "ℹ️ $(cat /tmp/sysinfo/model 2>/dev/null || uci -q get system.@system[0].hostname)"
	echo "Firmware: $DISTRIB_DESCRIPTION"
	echo "Kernel: $(uname -r) · $(uname -m)"
	echo "WrtFreedom: $(cat $W/VERSION 2>/dev/null)"
	;;
ip)
	ip=$(wanip); p=$(pubip)
	echo "🌍 $(t "IP della linea" "Line IP"): ${ip:-–}"
	echo "$(t "IP pubblico" "Public IP"): ${p:-$(t "non raggiungibile" "unreachable")}"
	[ -n "$ip" ] && [ -n "$p" ] && [ "$ip" != "$p" ] && t "La linea è dietro NAT dell'operatore" "The line is behind carrier NAT"
	;;
ipv6)
	echo "🌐 IPv6"
	o=$(for d in $(wandevs); do ip -6 addr show dev $d scope global 2>/dev/null | awk -v d=$d '/inet6/{print "• " d " · " $2}'; done)
	echo "${o:-$(t "Nessun indirizzo IPv6 sulla linea" "No IPv6 address on the line")}"
	;;
velocita)
	D=$(wandevs | head -n 1); [ -n "$D" ] || { t "Linea non attiva" "Line not active"; exit 0; }
	r1=$(cat /sys/class/net/$D/statistics/rx_bytes); t1=$(cat /sys/class/net/$D/statistics/tx_bytes); sleep 3
	r2=$(cat /sys/class/net/$D/statistics/rx_bytes); t2=$(cat /sys/class/net/$D/statistics/tx_bytes)
	awk -v r=$((r2-r1)) -v s=$((t2-t1)) -v EN=$EN 'BEGIN{printf "⚡ %s ↓ %.2f Mbit/s · ↑ %.2f Mbit/s\n", EN?"Now":"Adesso", r*8/3/1e6, s*8/3/1e6}'
	;;
consumo)
	echo "📈 $(t "Dall'accensione" "Since boot")"
	for D in $(wandevs); do echo "• $D · ↓ $(hb $(cat /sys/class/net/$D/statistics/rx_bytes)) · ↑ $(hb $(cat /sys/class/net/$D/statistics/tx_bytes))"; done
	;;
ora)
	echo "🕒 $(date '+%d/%m/%Y %H:%M:%S')"
	echo "$(t "Fuso" "Time zone"): $(uci -q get system.@system[0].zonename || uci -q get system.@system[0].timezone)"
	echo "NTP: $([ "$(uci -q get system.ntp.enabled)" = 0 ] && t spento off || t attivo on)"
	;;
# ===================== LINEA E MODEM =====================
linea)
	L=$(wanifs); [ -n "$L" ] || { t "Nessuna linea internet configurata" "No internet line configured"; exit 0; }
	for i in $L; do
		S=$(ifstatus $i 2>/dev/null) || continue
		if echo "$S" | jsonfilter -e '@.up' | grep -q true; then
			echo "🟢 $i · $(echo "$S" | jsonfilter -e '@.proto') · $(dur $(echo "$S" | jsonfilter -e '@.uptime'))"
			echo "   IP $(echo "$S" | jsonfilter -e '@["ipv4-address"][0].address') · gateway $(echo "$S" | jsonfilter -e '@.route[@.target="0.0.0.0"].nexthop' | head -n 1)"
			echo "   DNS $(echo "$S" | jsonfilter -e '@["dns-server"][*]' | tr '\n' ' ')"
		else echo "🔴 $i · $(t "giù" "down")"; fi
	done
	;;
riconnetti)
	t "🔄 Riconnetto la linea…" "🔄 Reconnecting the line…"
	( sleep 2; sh $W/event.sh act wan_reconnect ) >/dev/null 2>&1 </dev/null &
	;;
segnale)
	ucode $W/modemctl.uc tg segnale
	;;
# Controllo Della Linea (2.53): stessa strada di Pianificazioni ed Eventi (sqmctl.sh)
sqm) sh $W/sqmctl.sh state ;;
sqm_on) sh $W/sqmctl.sh on ;;
sqm_off) sh $W/sqmctl.sh off ;;
sqm_profilo) sh $W/sqmctl.sh pick "$A" ;;
cella)
	ucode $W/modemctl.uc tg cella
	;;
bande)
	ucode $W/modemctl.uc tg bande
	;;
operatore)
	ucode $W/modemctl.uc tg operatore
	;;
rete_mobile)
	ucode $W/modemctl.uc tg rete_mobile
	;;
sim)
	ucode $W/modemctl.uc tg sim
	;;
imei)
	echo "🔢 IMEI $(ATR 'AT+CGSN' | grep -oE '[0-9]{14,16}' | head -n 1)"
	;;
riavvia_modem)
	t "🔄 Riavvio il modem: la linea torna tra circa un minuto" "🔄 Restarting the modem: the line will be back in about a minute"
	( sleep 2; ucode $W/modemctl.uc restart ) >/dev/null 2>&1 </dev/null &
	;;
solo4g)
	ucode $W/modemctl.uc tg solo4g
	;;
standard)
	ucode $W/modemctl.uc tg standard
	;;
celle)
	ucode $W/modemctl.uc tg celle
	;;
temp_modem)
	ucode $W/modemctl.uc tg temp_modem
	;;
apn)
	echo "📶 APN"; ATR 'AT+CGDCONT?' | grep CGDCONT | sed 's/+CGDCONT: //; s/"//g' | awk -F, '{printf "• %s · %s · %s\n",$1,$2,($3==""?"-":$3)}'
	;;
sms)
	ATR 'AT+CMGF=1' >/dev/null; o=$(ATR 'AT+CMGL="ALL"' | grep -v '^OK$')
	[ -n "$(echo "$o" | grep CMGL)" ] || { t "Nessun SMS sulla SIM" "No SMS on the SIM"; exit 0; }
	echo "✉️ SMS"; echo "$o" | sed 's/+CMGL: [0-9]*,"[^"]*","\([^"]*\)",[^,]*,"\([^"]*\)".*/\n📨 \1 · \2/' | tail -n 40
	;;
at)
	echo "$A" | grep -qiE '^AT[A-Za-z0-9+&=?,";:_ .*#%-]*$' || { t "Scrivi un comando che inizi con AT" "Type a command starting with AT"; exit 0; }
	o=$(ATR "$A"); echo "${o:-$(t "Nessuna risposta" "No answer")}"
	;;
# ===================== WI-FI =====================
wifi)
	echo "📶 Wi-Fi"
	F=$(wifi_ifs)
	for i in $F; do
		iwinfo $i info 2>/dev/null | awk -v i=$i -v c="$(iwinfo $i assoclist 2>/dev/null | grep -c dBm)" -v EN=$EN '/ESSID/{gsub(/.*ESSID: "|"$/,""); s=$0} /Channel:/{for(k=1;k<=NF;k++) if($k=="Channel:") ch=$(k+1); if(match($0,/\([0-9.]+ GHz\)/)) g=substr($0,RSTART+1,RLENGTH-6)} END{printf "🟢 %s · %s GHz · %s %s · %d %s\n", s, g, EN?"ch":"can", ch, c, EN?"devices":"dispositivi"}'
	done
	for s in $(uci -q show wireless | sed -n "s/^wireless\.\([^.=]*\)=wifi-iface$/\1/p"); do
		[ "$(uci -q get wireless.$s.disabled)" = 1 ] && echo "⚪ $(uci -q get wireless.$s.ssid) · $(t spenta off)"
	done
	[ -n "$F" ] || t "Wi-Fi spento" "Wi-Fi off"
	;;
wifi_on)
	sh $W/event.sh act wifi_on >/dev/null 2>&1; t "📶 Wi-Fi acceso" "📶 Wi-Fi on"
	;;
wifi_off)
	t "📴 Spengo il Wi-Fi" "📴 Turning Wi-Fi off"
	( sleep 3; sh $W/event.sh act wifi_off ) >/dev/null 2>&1 </dev/null &
	;;
wifi_riavvia)
	t "🔄 Riavvio il Wi-Fi" "🔄 Restarting Wi-Fi"
	( sleep 3; ucode $W/wifi.uc restart ) >/dev/null 2>&1 </dev/null &	# 2.48: con il controllo dopo 30 s
	;;
ospiti)
	G=$(uci -q show wireless | sed -n "s/^wireless\.\([^.]*\)\.network='guest'$/\1/p")
	echo "👥 $(t "Rete ospiti" "Guest network")"
	for s in $G; do echo "• $(uci -q get wireless.$s.ssid) · $([ "$(uci -q get wireless.$s.disabled)" = 1 ] && t spenta off || t accesa on)"; done
	;;
ospiti_on|ospiti_off)
	o=$(ubus call wrtfreedom quick "{\"act\":\"guest_${1#ospiti_}\"}" 2>&1)
	echo "$o" | grep -q '"ok"' && { [ "$1" = ospiti_on ] && t "👥 Rete ospiti accesa" "👥 Guest network on" || t "👥 Rete ospiti spenta" "👥 Guest network off"; } || uerr "$o"
	;;
password_wifi)
	# 2.48: le password non restano in chiaro nella chat: file che il bot cancella dopo 5 minuti (come WireGuard nell'app)
	mkdir -p /tmp/wf-tgfile && chmod 700 /tmp/wf-tgfile
	f=/tmp/wf-tgfile/$(t Password-WiFi WiFi-Passwords).txt
	for s in $(uci -q show wireless | sed -n "s/^wireless\.\([^.=]*\)=wifi-iface$/\1/p"); do
		[ "$(uci -q get wireless.$s.mode)" = ap ] || continue
		n=$(uci -q get wireless.$s.ssid); [ -n "$A" ] && ! echo "$n" | grep -qiF "$A" && continue
		k=$(uci -q get wireless.$s.key); e=$(uci -q get wireless.$s.encryption)
		if [ "$e" = none ] || [ -z "$k" ]; then printf '%s · %s\n' "$n" "$(t "rete aperta" "open network")"; else printf '%s · %s\n' "$n" "$k"; fi
	done | awk '!s[$0]++' > "$f"
	[ -s "$f" ] || { rm -f "$f"; t "Nessuna rete Wi-Fi trovata" "No Wi-Fi network found"; exit 0; }
	echo "@@DOC $f ttl=300"; t "🔑 Password delle reti Wi-Fi: il messaggio si cancella tra 5 minuti" "🔑 Wi-Fi network passwords: this message is deleted in 5 minutes"
	;;
qr_wifi)
	for s in $(uci -q show wireless | sed -n "s/^wireless\.\([^.=]*\)=wifi-iface$/\1/p"); do
		[ "$(uci -q get wireless.$s.mode)" = ap ] && [ "$(uci -q get wireless.$s.disabled)" != 1 ] || continue
		n=$(uci -q get wireless.$s.ssid); [ -n "$A" ] && ! echo "$n" | grep -qiF "$A" && continue
		k=$(uci -q get wireless.$s.key); e=$(uci -q get wireless.$s.encryption)
		x() { printf '%s' "$1" | sed 's/[\\;,:"]/\\&/g'; }
		if [ "$e" = none ] || [ -z "$k" ]; then q="WIFI:T:nopass;S:$(x "$n");;"; else q="WIFI:T:WPA;S:$(x "$n");P:$(x "$k");;"; fi
		qrphoto "$q" "📶 $n"; exit 0
	done
	t "Nessuna rete Wi-Fi trovata" "No Wi-Fi network found"
	;;
canali)
	echo "📡 $(t "Reti vicine" "Nearby networks")"
	for i in $(wifi_ifs); do
		iwinfo $i scan 2>/dev/null | awk '/Channel:/{for(k=1;k<=NF;k++) if($k=="Channel:") print $(k+1)}' | sort -n | uniq -c | awk -v i=$i -v EN=$EN 'BEGIN{printf "%s:\n", i} {printf "• %s %s · %d %s\n", EN?"ch":"can", $2, $1, EN?"networks":"reti"}'
	done
	;;
segnale_wifi)
	echo "📶 $(t "Segnale dei dispositivi" "Device signal")"
	for i in $(wifi_ifs); do
		iwinfo $i assoclist 2>/dev/null | awk '/dBm/ && /^[0-9A-Fa-f][0-9A-Fa-f]:/{print tolower($1), $2}' | while read m s; do
			echo "$s $(devname $m || echo $m)"
		done
	done | sort -n | head -n 40 | while read s n; do echo "• $n · $s dBm"; done
	;;
potenza)
	for i in $(wifi_ifs); do
		iwinfo $i info 2>/dev/null | awk -v i=$i '/ESSID/{gsub(/.*ESSID: "|"$/,""); s=$0} /Tx-Power/{for(k=1;k<=NF;k++){if($k=="Tx-Power:") p=$(k+1) " " $(k+2)}} /Channel:/{for(k=1;k<=NF;k++){ if($k=="Channel:") c=$(k+1); if($k=="HT" && $(k+1)=="Mode:") h=$(k+2) }} END{printf "📻 %s · ch %s · %s · %s\n", s, c, h, p}'
	done
	;;
# ===================== DISPOSITIVI =====================
client)
	O=$(online_macs)
	echo "📱 $(t Dispositivi Devices) ($(leases | wc -l))"
	leases | awk '{print tolower($2), $3, ($4=="*"?$2:$4)}' | sort -k3 | while read m i n; do
		echo "$O" | grep -qx "$m" && d=🟢 || d=⚪; echo "$d $n · $i"
	done | head -n 60
	;;
online)
	O=$(online_macs); [ -n "$O" ] || { t "Nessun dispositivo attivo" "No active device"; exit 0; }
	echo "🟢 $(t "Attivi adesso" "Active now") ($(echo "$O" | wc -l))"
	for m in $O; do ip=$(ip neigh show | awk -v m=$m 'tolower($0)~m{print $1; exit}'); echo "• $(devname $m || echo $m) · $ip"; done | sort | head -n 60
	;;
nuovi)
	o=$(grep '|dev_new|' "$LOG" 2>/dev/null | tail -n 10)
	[ -n "$o" ] || { t "Nessun dispositivo nuovo nel registro" "No new device in the log"; exit 0; }
	echo "🆕 $(t "Ultimi dispositivi nuovi" "Latest new devices")"
	echo "$o" | awk -F'|' '{cmd="date -d @" $1 " \"+%d/%m %H:%M\""; cmd | getline d; close(cmd); sub(/^🆕 [^:]*: /,"",$4); print "• " d " · " $4}'
	;;
cerca)
	find_dev; O=$(online_macs)
	echo "$R" | while read m i n; do echo "$O" | grep -qx "$m" && d=🟢 || d=⚪; echo "$d $n · $i · $m"; done
	;;
dettagli)
	one_dev
	echo "📱 $NM"
	echo "IP: $IP"; echo "MAC: $MAC"
	online_macs | grep -qx "$MAC" && echo "$(t Stato Status): 🟢 $(t attivo active)" || echo "$(t Stato Status): ⚪ $(t "non attivo" "inactive")"
	e=$(leases | awk -v m=$MAC 'tolower($2)==m{print $1; exit}'); [ -n "$e" ] && [ "$e" != 0 ] && echo "$(t "Contratto fino a" "Lease until"): $(date -d @$e '+%d/%m %H:%M' 2>/dev/null)"
	uci -q show dhcp | grep -qi "mac='$MAC'" && t "IP riservato" "Reserved IP" && echo
	for i in $(wifi_ifs); do s=$(iwinfo $i assoclist 2>/dev/null | awk -v m=$MAC 'tolower($1)==m{print $2; exit}'); [ -n "$s" ] && echo "Wi-Fi: $i · $s dBm"; done
	uci -q get firewall.x3kb_$(echo $MAC | tr -d :) >/dev/null && t "⛔ Bloccato" "⛔ Blocked"
	;;
blocca|sblocca)
	one_dev
	[ "$MAC" = "$(echo "$MAC" | grep -E '^([0-9a-f]{2}:){5}[0-9a-f]{2}$')" ] || { t "MAC non valido" "Invalid MAC"; exit 0; }
	a=block; [ "$1" = sblocca ] && a=unblock
	o=$(ubus call wrtfreedom quick "{\"act\":\"$a\",\"mac\":\"$MAC\",\"name\":\"$(echo "$NM" | tr -d '"\\')\"}" 2>&1)
	echo "$o" | grep -q '"ok"' || { uerr "$o"; exit 0; }
	[ $a = block ] && echo "⛔ $NM $(t "bloccato" "blocked")" || echo "✅ $NM $(t "sbloccato" "unblocked")"
	;;
client_bloccati)
	B=$(uci -q show firewall | sed -n "s/^firewall\.\(x3kb_[0-9a-f]*\)=rule$/\1/p")
	[ -n "$B" ] || { t "Nessun dispositivo bloccato" "No blocked device"; exit 0; }
	echo "⛔ $(t Bloccati Blocked)"
	for b in $B; do m=$(uci -q get firewall.$b.src_mac | awk '{print $1}'); echo "• $(devname $m || uci -q get firewall.$b.name) · $m"; done
	;;
disconnetti)
	one_dev; n=0
	for o in $(ubus list 'hostapd.*' 2>/dev/null); do
		ubus call $o del_client "{\"addr\":\"$MAC\",\"reason\":5,\"deauth\":true,\"ban_time\":30000}" >/dev/null 2>&1 && n=1
	done
	[ $n = 1 ] && echo "📴 $NM $(t "scollegato dal Wi-Fi (può ricollegarsi dopo 30 s)" "kicked off Wi-Fi (can reconnect after 30 s)")" || t "Il dispositivo non è collegato al Wi-Fi" "The device is not on Wi-Fi"
	;;
sveglia)
	one_dev
	o=$(ubus call wrtfreedom wol "{\"mac\":\"$MAC\"}" 2>&1)
	echo "$o" | grep -q '"ok"' && echo "⏰ $(t "Pacchetto di accensione inviato a" "Wake packet sent to") $NM" || uerr "$o"
	;;
top_client)
	# stesso conteggio dell'app (2.59): contatori di Consumo Dei Dispositivi (metodo clusage), ultimi 30 giorni
	o=$(ubus call wrtfreedom clusage 2>/dev/null)
	[ -n "$o" ] || { t "Nessuna risposta dal router" "No answer from the router"; exit 0; }
	L=$(echo "$o" | J 'let L=[]; for(let m in d.devs ?? {}) { let x=d.devs[m].month ?? [0,0]; if(x[0]+x[1]>0) push(L,[m,x[0],x[1]]); } L=sort(L,(a,b)=>(b[1]+b[2])-(a[1]+a[2])); for(let i=0;i<length(L)&&i<15;i++) print(L[i][0]," ",L[i][1]," ",L[i][2],"\n");')
	[ -n "$L" ] || { echo "$o" | jsonfilter -e '@.ok' 2>/dev/null | grep -q true && t "Nessun consumo negli ultimi 30 giorni" "No usage in the last 30 days" || t "Conteggio non attivo: $(echo "$o" | jsonfilter -e '@.why' 2>/dev/null)" "Counting not active: $(echo "$o" | jsonfilter -e '@.why' 2>/dev/null)"; exit 0; }
	echo "📊 $(t "Consumo per dispositivo · 30 giorni" "Usage per device · 30 days")"
	echo "$L" | while read m r s; do
		echo "• $(devname $m || echo $m) · ↓ $(hb $r) · ↑ $(hb $s)"
	done
	;;
fasce)
	# Orari e Velocità (2.59): voci del metodo shaper con lo stato calcolato dal router (vale adesso, prossimo cambio)
	o=$(ubus call wrtfreedom shaper 2>/dev/null)
	echo "$o" | grep -q '"list"' || { uerr "$o"; exit 0; }
	echo "$o" | J 'let G=EN?["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]:["Dom","Lun","Mar","Mer","Gio","Ven","Sab"], hm=(x)=>{let n=localtime(x); return sprintf("%02d:%02d",n.hour,n.min);}, L=filter(d.list ?? [],(r)=>r.dl||r.ul);
		print("🕒 ", EN?"Schedules and Speed":"Orari e Velocità", "\n");
		if(d.can===false) print("⚠️ ", d.why ?? "", "\n");
		if(!length(L)) { print(EN?"No limits: internet is always fast":"Nessun limite: internet è sempre veloce", "\n"); exit(0); }
		for(let r in L) {
			let who=r.casa ? (EN?"The whole house":"Tutta la casa") : length(r.name ?? "") ? r.name : (r.mac ?? (EN?"person":"persona")), sp="↓ " + (r.dl ?? "—") + (r.ul ? " · ↑ " + r.ul : "") + " Mbit/s";
			let dd=length(r.days ?? "") ? join(", ", map(split(r.days,""),(c)=>G[+c])) : (EN?"every day":"tutti i giorni"), st=r.off ? (EN?" · paused":" · sospesa") : r.on===true ? " · 🟢 " + (EN?"active now":"attiva adesso") : "";
			if(r.kind=="slow") print("• 🐢 ", who, " · ", sp, " · ", EN?"until ":"fino alle ", hm(r.until), "\n");
			else if(r.kind=="fix") print("• ⚡ ", who, " · ", sp, " · ", EN?"always":"sempre", "\n");
			else print("• ", who, " · ", r.from ? r.from + "–" + r.to + " · " : "", dd, " · ", sp, st, r.next && !r.off ? " · " + (EN?"changes at ":"cambia alle ") + hm(r.next) : "", "\n");
		}
		print(EN?"Slots used: ":"Posti usati: ", d.used, "/", d.max, "\n");'
	;;
limita|rallenta)
	# Limita Velocità (sempre) e Rallenta Per Un Po' (2.59): «nome [Mbit/s] [invio Mbit/s | minuti]» o «nome off»;
	# per rallenta anche «casa» (Tutta La Casa Insieme) o il nome di una persona (tutti i suoi dispositivi)
	C=$1; OFF=0
	case "$(echo "$A" | tr 'A-Z' 'a-z')" in *" off") OFF=1; A=${A% *} ;; esac
	P=$(echo "$A" | awk '{n=0;for(i=NF;i>1&&$i~/^[0-9]+$/&&n<2;i--)n++;s="";for(j=1;j<=NF-n;j++)s=s (j>1?" ":"") $j;print s "|" (n>=1?$(NF-n+1):"") "|" (n==2?$NF:"")}')
	A=${P%%|*}; P=${P#*|}; V1=${P%%|*}; V2=${P#*|}
	[ $OFF = 1 ] || [ -n "$V1" ] || [ $C = rallenta ] || { t "Scrivi il nome e i Mbit/s (es. TV 20), oppure il nome e off" "Type the name and Mbit/s (e.g. TV 20), or the name and off"; exit 0; }
	WHO=; TG=; NM=
	if [ $C = rallenta ]; then
		case "$(echo "$A" | tr 'A-Z' 'a-z')" in casa|tutti|"tutta la casa"|home|house|all|everyone) WHO=casa; TG='"casa":true'; NM=$(t "Tutta la casa" "The whole house") ;; esac
		[ -n "$WHO" ] || for p in $(uci -q show wrtfreedom | sed -n "s/^wrtfreedom\.\(p_[a-z0-9]*\)=person$/\1/p"); do
			[ "$(uci -q get wrtfreedom.$p.name | tr 'A-Z' 'a-z')" = "$(echo "$A" | tr 'A-Z' 'a-z')" ] || continue
			M=$(for m in $(uci -q get wrtfreedom.$p.mac | tr 'A-F' 'a-f'); do echo "$m" | grep -qE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' && printf '"%s",' "$m"; done)
			[ -n "$M" ] || continue
			WHO="p:$p"; TG="\"macs\":[${M%,}]"; NM=$(uci -q get wrtfreedom.$p.name); break
		done
	fi
	[ -n "$WHO" ] || { one_dev; WHO="d:$(echo "$MAC" | tr -d :)"; TG="\"mac\":\"$MAC\""; }
	if [ $C = limita ]; then
		if [ $OFF = 1 ]; then X="{\"kind\":\"fix\",$TG,\"off\":true}"
		else
			echo "$V1" | grep -qE '^[0-9]{1,5}$' && [ "$V1" -ge 1 ] && [ "$V1" -le 10000 ] || { t "Velocità non valida (1…10000 Mbit/s)" "Invalid speed (1…10000 Mbit/s)"; exit 0; }
			U=${V2:-$V1}; [ "$U" -ge 1 ] && [ "$U" -le 10000 ] || { t "Velocità non valida (1…10000 Mbit/s)" "Invalid speed (1…10000 Mbit/s)"; exit 0; }
			X="{\"kind\":\"fix\",$TG,\"dl\":$V1,\"ul\":$U}"
		fi
		o=$(ubus call wrtfreedom shaper "{\"add\":\"$(echo "$X" | sed 's/"/\\"/g')\"}" 2>&1)
		echo "$o" | grep -q '"ok"' || { uerr "$o"; exit 0; }
		if [ $OFF = 1 ]; then echo "✅ $NM: $(t "di nuovo alla velocità piena" "back to full speed")"
		else echo "⚡ $NM: $(t "al massimo" "at most") ↓ $V1 · ↑ $U Mbit/s · $(t "posti liberi" "free slots") $(echo "$o" | jsonfilter -e '@.left' 2>/dev/null)"; fi
		exit 0
	fi
	K=${WHO#d:}; K=${K#p:}
	if [ $OFF = 1 ]; then
		o=$(ubus call wrtfreedom shaper "{\"del\":\"slow_$K\"}" 2>&1)
		echo "$o" | grep -q '"ok"' && echo "✅ $NM: $(t "di nuovo alla velocità piena" "back to full speed")" || t "$NM non era rallentato" "$NM was not slowed down"
		exit 0
	fi
	V1=${V1:-10}; V2=${V2:-60}
	echo "$V1" | grep -qE '^[0-9]{1,5}$' && [ "$V1" -ge 1 ] && [ "$V1" -le 10000 ] || { t "Velocità non valida (1…10000 Mbit/s)" "Invalid speed (1…10000 Mbit/s)"; exit 0; }
	echo "$V2" | grep -qE '^[0-9]{1,4}$' && [ "$V2" -ge 1 ] && [ "$V2" -le 1440 ] || { t "Minuti non validi (1…1440)" "Invalid minutes (1…1440)"; exit 0; }
	X="{\"kind\":\"slow\",\"who\":\"$WHO\",$TG,\"dl\":$V1,\"min\":$V2}"
	o=$(ubus call wrtfreedom shaper "{\"add\":\"$(echo "$X" | sed 's/"/\\"/g')\"}" 2>&1)
	echo "$o" | grep -q '"ok"' || { uerr "$o"; exit 0; }
	echo "🐢 $NM: $(t "al massimo" "at most") $V1 Mbit/s $(t "fino alle" "until") $(date -d @$(( $(date +%s) + V2 * 60 )) +%H:%M 2>/dev/null), $(t "poi torna veloce da solo" "then back to full speed by itself")"
	;;
ip_fissi)
	H=$(uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=host$/\1/p")
	[ -n "$H" ] || { t "Nessun IP riservato" "No reserved IP"; exit 0; }
	echo "📌 $(t "IP riservati" "Reserved IPs")"
	for h in $H; do echo "• $(uci -q get dhcp.$h.name || echo -) · $(uci -q get dhcp.$h.ip) · $(uci -q get dhcp.$h.mac)"; done
	;;
# ===================== VPN =====================
vpn)
	I=$(wgif); [ -n "$I" ] || { t "VPN Per Fuori Casa non configurata" "Away From Home VPN not set up"; exit 0; }
	now=$(date +%s); D=$(wg show $I dump 2>/dev/null)
	echo "🔐 $(t "VPN Per Fuori Casa" "Away From Home VPN") · $(isup $I && t accesa on || t spenta off)"
	echo "$(t Porta Port) $(uci -q get network.$I.listen_port) · $(t Client Clients) $(echo "$D" | tail -n +2 | grep -c .)"
	echo "$(t "Collegati adesso" "Connected now"): $(echo "$D" | tail -n +2 | awk -v n=$now '$5>0 && n-$5<180' | wc -l)"
	;;
vpn_on)
	sh $W/event.sh act vpn_on >/dev/null 2>&1; t "🔐 VPN Per Fuori Casa accesa" "🔐 Away From Home VPN on"
	;;
vpn_off)
	sh $W/event.sh act vpn_off >/dev/null 2>&1; t "🔓 VPN Per Fuori Casa spenta" "🔓 Away From Home VPN off"
	;;
vpn_riavvia)
	sh $W/event.sh act vpn_restart >/dev/null 2>&1; t "🔄 VPN Per Fuori Casa riavviata" "🔄 Away From Home VPN restarted"
	;;
vpn_peer|vpn_traffico)
	I=$(wgif); now=$(date +%s)
	D=$(wg show $I dump 2>/dev/null | tail -n +2); [ -n "$D" ] || { t "Nessun dispositivo nella VPN Per Fuori Casa" "No Away From Home VPN device"; exit 0; }
	[ $1 = vpn_peer ] && echo "👥 $(t "Dispositivi della VPN Per Fuori Casa" "Away From Home VPN devices")" || echo "📊 $(t "Traffico della VPN Per Fuori Casa" "Away From Home VPN traffic")"
	echo "$D" | while read pub psk ep ips hs rx tx ka; do
		n=$(uci -q show network | grep -F "public_key='$pub'" | head -n 1 | cut -d. -f2); nm=$(uci -q get network.$n.description); nm=${nm:-${ips%%/*}}
		if [ $1 = vpn_peer ]; then
			if [ "$hs" -gt 0 ] && [ $((now - hs)) -lt 180 ]; then echo "🟢 $nm · ${ep%:*} · $(t "ultimo contatto" "last seen") $((now - hs)) s"
			elif [ "$hs" -gt 0 ]; then echo "⚪ $nm · $(t "visto" "seen") $(dur $((now - hs))) $(t fa ago)"
			else echo "⚪ $nm · $(t "mai collegato" "never connected")"; fi
		else echo "• $nm · ↓ $(hb $tx) · ↑ $(hb $rx)"; fi
	done
	;;
vpn_qr)
	[ -n "$A" ] || { t "Scrivi anche il nome del client" "Also type the client name"; exit 0; }
	s=$(peer_find "$A"); [ -n "$s" ] || { t "Nessun dispositivo della VPN Per Fuori Casa si chiama \"$A\"" "No Away From Home VPN device named \"$A\""; exit 0; }
	c=$(wgconf $s) || { t "Il client è stato creato fuori dall'app: la sua chiave privata non è sul router, quindi il QR non si può rifare" "This client was created outside the app: its private key is not on the router, so the QR cannot be rebuilt"; exit 0; }
	qrphoto "$c" "🔐 $A"
	;;
vpn_nuovo)
	n=$(printf '%s' "$A" | tr -d '"\\' | cut -c1-40); [ -n "$n" ] || { t "Scrivi anche il nome del nuovo client" "Also type the new client name"; exit 0; }
	[ -n "$(peer_find "$n")" ] && { t "Esiste già un client \"$n\": usa /vpn_qr $n" "A client \"$n\" already exists: use /vpn_qr $n"; exit 0; }
	o=$(ubus call wrtfreedom wgpeer "{\"action\":\"add\",\"name\":\"$n\",\"full\":false}" 2>&1)
	s=$(echo "$o" | jsonfilter -e '@.id' 2>/dev/null); [ -n "$s" ] || { uerr "$o"; exit 0; }
	qrphoto "$(wgconf $s)" "🔐 $(t "Nuovo client" "New client") $n · IP $(echo "$o" | jsonfilter -e '@.ip')"
	;;
vpn_indirizzo)
	I=$(wgif); h=$(uci -q get wrtfreedom.wg.host); how=$(t "impostato nell'app" "set in the app")
	[ -n "$h" ] || { h=$(uci -q show ddns | sed -n "s/^ddns\.[^.]*\.lookup_host='\(.*\)'$/\1/p" | head -n 1); how="DDNS"; }
	[ -n "$h" ] || { h=$(wanip); how=$(t "IP della linea" "line IP"); }
	echo "🌍 $h:$(uci -q get network.$I.listen_port) ($how)"
	p=$(pubip); [ -n "$p" ] && echo "$(t "IP pubblico" "Public IP"): $p"
	w=$(wanip); cgnat "$w" && t "⚠️ La linea è dietro CGNAT: da fuori la VPN Per Fuori Casa non è raggiungibile" "⚠️ The line is behind CGNAT: the Away From Home VPN is not reachable from outside"
	;;
servizio_vpn)
	# Servizio VPN (2.42): con «on» o «off» lo accende o spegne (stessa strada dell'app), poi lo stato
	case "$(echo "$A" | tr 'A-Z' 'a-z')" in
		on|si|sì|accendi) ubus call wrtfreedom vpnout '{"action":"onoff","on":true}' >/dev/null 2>&1; sleep 8 ;;
		off|no|spegni) ubus call wrtfreedom vpnout '{"action":"onoff","on":false}' >/dev/null 2>&1; sleep 3 ;;
	esac
	# stato unico (2.52, come Stato Della Casa e la notifica del telefono): acceso = almeno un collegamento, paese e chi lo usa
	ubus call wrtfreedom vpnout '{"action":"state"}' 2>/dev/null | J '
		if (d.none || d.on == null) exit(0);
		let w = EN ? d.where : d.wherei, lt = d.pause ? localtime(d.pause) : null;
		print((d.on && d.ok ? "🔐 " : "🔓 ") + (EN ? "VPN Service: " : "Servizio VPN: ") + lc(d.v) + (d.on && length(w) ? " · " + w : "") + (d.on ? " · " + lc(d.who) : "") + "\n");
		if (lt) print((EN ? "   paused until " : "   in pausa fino alle ") + sprintf("%02d:%02d", lt.hour, lt.min) + "\n");
	'
	ubus call wrtfreedom vpnout 2>/dev/null | J '
		if (d.none) { print(EN ? "🔓 VPN Service not configured: connect it from the app (More › VPN)\n" : "🔓 Servizio VPN non configurato: collegalo nell" + chr(39) + "app (Altro › VPN)\n"); exit(0); }
		for (let t in d.tunnels) {
			let s = t.srv ?? {}, ip = t.ip ?? {}, hs = (t.st ?? {}).hs ?? 0, ok = t.on && hs > 0 && d.now - hs < 180;
			let where = (ip.country && ok ? ip.country : s.city || s.name || s.host) + (ok && ip.city ? " · " + ip.city : "");
			print((ok ? "🔐 " : "🔓 ") + where + ": " + (!t.on ? (EN ? "off" : "spento") : ok ? (EN ? "connected" : "collegato") : (EN ? "not responding" : "non risponde")) + "\n");
			print("   " + (t.n == 0 ? (t.mode == "dev" ? (EN ? "chosen devices" : "dispositivi scelti") : t.mode == "except" ? (EN ? "all except some devices" : "tutti tranne alcuni") : (EN ? "whole home" : "tutta la casa")) : length(t.devs) + (EN ? " devices" : " dispositivi")) +
				(ok && ip.ip ? " · IP " + ip.ip : "") + "\n");
		}
	'
	;;
# ===================== ADGUARD E DNS =====================
adguard)
	s=$(adg GET status); [ -n "$s" ] || { t "AdGuard Home non risponde" "AdGuard Home is not answering"; exit 0; }
	echo "$s" | grep -q '"protection_enabled":true' && p="🟢 $(t "Protezione attiva" "Protection on")" || p="🔴 $(t "Protezione spenta" "Protection off")"
	echo "🛡 AdGuard Home $(echo "$s" | jsonfilter -e '@.version')"; echo "$p"
	adg GET stats | J 'let q=d.num_dns_queries||0,b=d.num_blocked_filtering||0; printf("%s %d · %s %d (%.1f%%)\n%s %.0f ms\n", EN?"Queries":"Richieste", q, EN?"blocked":"bloccate", b, q?b*100/q:0, EN?"Average time":"Tempo medio", (d.avg_processing_time||0)*1000);' 
	;;
adg_on|adg_off)
	v=true; [ $1 = adg_off ] && v=false
	adg POST protection "{\"enabled\":$v}" >/dev/null
	[ $v = true ] && t "🛡 Protezione AdGuard accesa" "🛡 AdGuard protection on" || t "⚪ Protezione AdGuard spenta" "⚪ AdGuard protection off"
	;;
pausa)
	m=$(echo "$A" | grep -oE '^[0-9]{1,4}'); [ -n "$m" ] && [ "$m" -gt 0 ] || { t "Scrivi i minuti di pausa (es. /pausa 10)" "Type the pause minutes (e.g. /pause 10)"; exit 0; }
	adg POST protection "{\"enabled\":false,\"duration\":$((m * 60000))}" >/dev/null
	echo "⏸ $(t "Protezione in pausa per" "Protection paused for") $m min"
	;;
top_bloccati|top_domini|top_client_dns)
	k=top_blocked_domains; h="⛔ $(t "Domini più bloccati" "Most blocked domains")"
	[ $1 = top_domini ] && { k=top_queried_domains; h="🔎 $(t "Domini più richiesti" "Most requested domains")"; }
	[ $1 = top_client_dns ] && { k=top_clients; h="📱 $(t "Dispositivi con più richieste" "Devices with the most requests")"; }
	echo "$h"
	adg GET stats | J "for(let i=0;i<length(d.$k)&&i<15;i++){let o=d.$k[i]; for(let n in o) print(n,' ',o[n],'\n');}" | while read n c; do
		[ $1 = top_client_dns ] && { x=$(devs | awk -v i=$n '$2==i && $3!="-"{print $3; exit}'); n=${x:-$n}; }
		echo "• $n · $c"
	done
	;;
filtri)
	echo "📋 $(t "Liste di blocco" "Blocklists")"
	adg GET filtering/status | J 'for(let f in (d.filters||[])) print(f.enabled?"🟢 ":"⚪ ", f.name, " · ", f.rules_count, "\n");'
	;;
risolvi)
	okhost "$A"
	echo "🔎 $A"; nslookup "$A" 2>&1 | awk '/^Name:/{n=1;next} n&&/^Address/{sub(/^Address[ 0-9]*: */,""); print "• " $0}' | head -n 10
	;;
dns_svuota)
	/etc/init.d/dnsmasq restart >/dev/null 2>&1
	[ -n "$(adgcred)" ] && command -v curl >/dev/null 2>&1 && adg POST cache_clear >/dev/null 2>&1
	t "🧹 Cache DNS svuotata" "🧹 DNS cache cleared"
	;;
dns_server)
	echo "🧭 DNS"
	u=$(uci -q get dhcp.@dnsmasq[0].server); [ -n "$u" ] && echo "dnsmasq → $u"
	grep nameserver /tmp/resolv.conf.d/resolv.conf.auto 2>/dev/null | awk '{print "• " $2}' | sort -u
	[ -n "$(adgcred)" ] && command -v curl >/dev/null 2>&1 && adg GET dns_info | J 'for(let u in (d.upstream_dns||[])) print("AdGuard → ", u, "\n");'
	;;
# ===================== DIAGNOSTICA =====================
ping)
	okhost "$A"; echo "🏓 $A"; ping -c 4 -W 2 "$A" 2>&1 | tail -n 3
	;;
traceroute)
	okhost "$A"; echo "🧭 $A"; traceroute -n -w 2 -q 1 -m 20 "$A" 2>&1 | tail -n +2 | head -n 20
	;;
latenza)
	g=$(ip route show default 2>/dev/null | awk '{print $3; exit}')
	echo "⏱ $(t Latenza Latency)"
	for h in $g 1.1.1.1 8.8.8.8; do
		r=$(ping -c 3 -W 2 $h 2>/dev/null | awk -F/ '/min\/avg/{print $4}'); echo "• $h · ${r:-–} ms"
	done
	;;
speedtest)
	# Un Solo Test Di Velocità (2.55): lo stesso test e lo stesso risultato della pagina e delle Pianificazioni
	ucode $W/speed.uc text
	;;
porte)
	R=$(uci -q show firewall | sed -n "s/^firewall\.\([^.=]*\)=redirect$/\1/p")
	[ -n "$R" ] || { t "Nessuna porta aperta" "No forwarded port"; exit 0; }
	echo "🚪 $(t "Porte aperte" "Forwarded ports")"
	for r in $R; do
		[ "$(uci -q get firewall.$r.target)" = SNAT ] && continue
		echo "$([ "$(uci -q get firewall.$r.enabled)" = 0 ] && echo ⚪ || echo 🟢) $(uci -q get firewall.$r.name) · $(uci -q get firewall.$r.src_dport) → $(uci -q get firewall.$r.dest_ip):$(uci -q get firewall.$r.dest_port) $(uci -q get firewall.$r.proto)"
	done
	;;
interfacce)
	echo "🔌 $(t Interfacce Interfaces)"
	ubus call network.interface dump 2>/dev/null | J 'for(let i in d.interface){ if(i.interface=="loopback") continue; let a=i["ipv4-address"]; print(i.up?"🟢 ":"⚪ ", i.interface, " · ", i.proto, (i.l3_device?" · "+i.l3_device:""), (a&&length(a)?" · "+a[0].address+"/"+a[0].mask:""), "\n"); }'
	;;
route)
	echo "🧭 $(t Routing Routing)"; ip route show 2>/dev/null | head -n 20
	r6=$(ip -6 route show default 2>/dev/null | head -n 3); [ -n "$r6" ] && { echo; echo "IPv6"; echo "$r6"; }
	;;
ddns)
	S=$(uci -q show ddns | sed -n "s/^ddns\.\([^.=]*\)=service$/\1/p")
	[ -n "$S" ] || { t "Nessun servizio DNS dinamico" "No dynamic DNS service"; exit 0; }
	echo "🌍 DDNS"
	for s in $S; do
		ip=$(cat /var/run/ddns/$s.ip 2>/dev/null)
		echo "$([ "$(uci -q get ddns.$s.enabled)" = 1 ] && echo 🟢 || echo ⚪) $(uci -q get ddns.$s.lookup_host) · ${ip:-–}"
		tail -n 1 /var/log/ddns/$s.log 2>/dev/null | cut -c1-120
	done
	;;
nat)
	w=$(wanip); p=$(pubip)
	echo "🔍 NAT"; echo "$(t "IP della linea" "Line IP"): ${w:-–}"; echo "$(t "IP pubblico" "Public IP"): ${p:-–}"
	if [ -z "$w" ] || [ -z "$p" ]; then t "Non riesco a verificare" "Cannot check"
	elif [ "$w" = "$p" ]; then t "✅ IP pubblico diretto: porte e VPN raggiungibili da fuori" "✅ Direct public IP: ports and VPN reachable from outside"
	elif cgnat "$w"; then t "⚠️ CGNAT dell'operatore: da fuori non si raggiungono porte né VPN" "⚠️ Carrier CGNAT: ports and VPN are not reachable from outside"
	else t "⚠️ Doppio NAT: c'è un altro router davanti" "⚠️ Double NAT: there is another router in front"; fi
	;;
connessioni)
	c=$(cat /proc/sys/net/netfilter/nf_conntrack_count); m=$(cat /proc/sys/net/netfilter/nf_conntrack_max)
	echo "🔗 $(t Connessioni Connections): $c / $m"
	[ -r /proc/net/nf_conntrack ] && { echo "$(t "Per dispositivo" "Per device"):"; awk '{for(i=1;i<=NF;i++) if($i~/^src=/){sub(/src=/,"",$i); print $i; break}}' /proc/net/nf_conntrack | sort | uniq -c | sort -rn | head -n 8 | while read n i; do x=$(devs | awk -v i=$i '$2==i && $3!="-"{print $3; exit}'); echo "• ${x:-$i} · $n"; done; }
	;;
porta)
	h=$(echo "$A" | awk '{print $1}' | sed 's/:[0-9]*$//'); p=$(echo "$A" | grep -oE '[0-9]{1,5}$')
	okhost "$h"; [ -n "$p" ] && [ "$h" != "$p" ] || { t "Scrivi indirizzo e porta (es. 1.1.1.1 443)" "Type address and port (e.g. 1.1.1.1 443)"; exit 0; }
	c=$(curl -s -o /dev/null -m 5 --connect-timeout 5 -w '%{time_connect}' "telnet://$h:$p" </dev/null 2>/dev/null); r=$?
	if awk -v c="${c:-0}" 'BEGIN{exit !(c+0>0)}'; then echo "🟢 $h:$p $(t "risponde" "is open")"
	elif [ $r = 7 ]; then echo "🔴 $h:$p $(t "chiusa" "closed")"; else echo "🔴 $h:$p $(t "non risponde" "not answering")"; fi
	;;
# ===================== SISTEMA =====================
riavvia)
	t "🔄 Riavvio il router…" "🔄 Restarting the router…"
	( sleep 5; reboot ) >/dev/null 2>&1 </dev/null &
	;;
riavvia_rete)
	t "🔄 Riavvio la rete: il router torna raggiungibile tra poco" "🔄 Restarting the network: the router will be back shortly"
	( sleep 3; /etc/init.d/network restart ) >/dev/null 2>&1 </dev/null &
	;;
log)
	echo "🗒 $(t Registro Log)"; logread 2>/dev/null | tail -n 25 | cut -c1-160 | sed 's/^[A-Z][a-z][a-z] \([A-Z][a-z][a-z] *[0-9]* [0-9:]*\) [0-9]* /\1 /'
	;;
errori)
	# Registro In Parole Semplici (2.55): righe Da Vedere (avvisi ed errori) raggruppate per programma, lo stesso conto
	# della pagina Registro e della notifica
	ubus call wrtfreedom logsum '{"see":true}' 2>/dev/null | J '
		print("⚠️ " + (EN ? "Errors and warnings" : "Errori e avvisi") + ": " + d.see + "\n");
		if (!d.see) { print(EN ? "None\n" : "Nessuno\n"); exit(0); }
		for (let g in slice(d.groups, 0, 8)) {
			print("\n" + (g.lv == "warn" ? "🟠 " : "🔴 ") + g.name + " · " + g.see + "\n");
			for (let m in slice(g.msgs, 0, 2)) print("• " + substr(m.text, 0, 140) + (m.n > 1 ? " (×" + m.n + ")" : "") + "\n");
		}
	'
	;;
processi)
	echo "⚙️ $(t Processi Processes)"
	top -b -n 1 2>/dev/null | head -n 16 | cut -c1-110 | grep . || ps w | head -n 15 | cut -c1-110
	;;
servizi)
	# Un Solo Stato Dei Servizi (2.55): lo stesso elenco e lo stesso conto dei fermi della pagina e di Stato Della Casa
	ubus call wrtfreedom svc 2>/dev/null | J '
		let on = filter(d.list, (x) => x.on), off = filter(d.list, (x) => !x.on && x.boot);
		print("🟢 " + (EN ? "Running" : "Attivi") + " (" + length(on) + "): " + join(", ", map(on, (x) => x.name)) + "\n");
		if (length(off)) print("🔴 " + (EN ? "Stopped but enabled at boot" : "Fermi ma attivati all’avvio") + ": " + join(", ", map(off, (x) => x.name + " (" + x.id + ")")) + "\n");
	'
	;;
servizio)
	n=$(echo "$A" | awk '{print $1}'); echo "$n" | grep -qE '^[A-Za-z0-9_.-]+$' && [ -x /etc/init.d/$n ] || { t "Servizio non trovato: scrivi il nome esatto (vedi /servizi)" "Service not found: type the exact name (see /services)"; exit 0; }
	# Protezione Dei Servizi Vitali (2.55): stesso metodo della pagina (i vitali con il ritorno automatico dopo 2 minuti)
	o=$(ubus call wrtfreedom svc "{\"action\":\"restart\",\"name\":\"$n\"}" 2>&1)
	case "$o" in *'"pend": true'*)
		# vitale: riavvio andato bene (di nuovo acceso, modifica in attesa ancora sua) = confermato subito, niente
		# ritorno dopo 2 minuti e niente blocco delle altre modifiche; altrimenti torna com'era da solo
		i=0; s=
		while [ $i -lt 10 ]; do sleep 3; i=$((i+1))
			s=$(ubus call wrtfreedom svc 2>/dev/null | J 'let n = "'"$n"'", x = filter(d.list, (y) => y.id == n)[0]; print(x?.on && d.what?.name == n ? "on" : "");')
			[ "$s" = on ] && break; done
		if [ "$s" = on ] && ubus call wrtfreedom svc '{"action":"confirm"}' 2>/dev/null | grep -q '"ok": true'; then echo "🔄 $n $(t riavviato restarted)"
		else echo "🔄 $n $(t "riavviato ma non risponde: è un servizio vitale, torna com’era da solo tra 2 minuti" "restarted but not answering: it is a vital service, it goes back by itself in 2 minutes")"; fi;;
		*'"ok": true'*) echo "🔄 $n $(t riavviato restarted)";;
		*'non trovato'*) t "Servizio non trovato: scrivi il nome esatto (vedi /servizi)" "Service not found: type the exact name (see /services)";;
		*'in attesa'*) t "C'è già una modifica in attesa di conferma nell'app: riprova tra 2 minuti" "A change is already waiting for confirmation in the app: try again in 2 minutes";;
		*) t "Servizio non riavviato" "Service not restarted";; esac
	;;
aggiornamenti)
	if command -v apk >/dev/null 2>&1; then apk update >/dev/null 2>&1; L=$(apk list -u 2>/dev/null | awk '{print $1}')
	else opkg update >/dev/null 2>&1; L=$(opkg list-upgradable 2>/dev/null | awk '{print $1 " " $3 " → " $5}'); fi
	if [ -n "$L" ]; then echo "📦 $(t "Da aggiornare" "To update"): $(echo "$L" | wc -l)"; echo "$L" | head -n 30 | sed 's/^/• /'
	else t "✅ Tutti i pacchetti sono aggiornati" "✅ All packages are up to date"; echo; fi
	# WrtFreedom: versione installata e quella sul server degli aggiornamenti
	echo; sh $W/upd.sh status
	;;
aggiorna_pacchetto)
	# in sottofondo: l'installazione riavvia il servizio del bot; l'esito arriva con un messaggio a parte
	( sh $W/upd.sh install tg > /tmp/wf-upd.log 2>&1 ) >/dev/null 2>&1 </dev/null &
	t "⏳ Controllo e installo l'aggiornamento: ti scrivo quando ho finito" "⏳ Checking and installing the update: I'll write when done"
	;;
backup)
	h=$(uci -q get system.@system[0].hostname); f=/tmp/backup-${h:-router}-$(date +%Y%m%d).tar.gz
	# copia per Telegram (2.62): senza chiavi dell'Assistente IA né Cose Da Ricordare
	if [ -f /usr/share/wrtfreedom/backup.sh ]; then sh /usr/share/wrtfreedom/backup.sh create "$f" tg >/dev/null 2>&1; else sysupgrade -b "$f" >/dev/null 2>&1; fi
	[ -f "$f" ] || { t "Backup non creato" "Backup not created"; exit 0; }
	echo "@@DOC $f"; echo "💾 $(t "Backup di" "Backup of") $h"
	;;
eventi)
	o=$(tail -n 15 "$LOG" 2>/dev/null)
	[ -n "$o" ] || { t "Nessun evento" "No events"; exit 0; }
	echo "🗒 $(t "Ultimi eventi" "Latest events")"
	echo "$o" | awk -F'|' '{cmd="date -d @" $1 " \"+%d/%m %H:%M\""; cmd | getline d; close(cmd); print d " " $4}'
	;;
usb)
	o=$(for d in /sys/bus/usb/devices/*; do [ -f $d/idVendor ] || continue; [ -f $d/product ] || continue; echo "• $(cat $d/manufacturer 2>/dev/null) $(cat $d/product) · $(cat $d/idVendor):$(cat $d/idProduct)"; done | grep -viE 'host controller|root hub')
	echo "🔌 USB"; echo "${o:-$(t "Nessun dispositivo" "No device")}"
	;;
cron)
	o=$(grep -v '^#' /etc/crontabs/root 2>/dev/null | grep .)
	echo "🕓 $(t "Operazioni pianificate" "Scheduled tasks")"; echo "${o:-$(t "Nessuna" "None")}" | cut -c1-150
	;;
libera_ram)
	b=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo); sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
	a=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)
	echo "🧹 $(t "Memoria disponibile" "Available memory"): $b → $a MB"
	;;
sincronizza_ora)
	S=$(uci -q get system.ntp.server | awk '{print $1}'); ntpd -q -n -p ${S:-pool.ntp.org} >/dev/null 2>&1
	echo "🕒 $(date '+%d/%m/%Y %H:%M:%S')"
	;;
*)
	t "Comando sconosciuto" "Unknown command"
	;;
esac
exit 0
