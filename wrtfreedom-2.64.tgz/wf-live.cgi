#!/usr/bin/ucode
'use strict';
/* WrtFreedom: lettura in diretta (pacchetto 2.39), /cgi-bin/wf-live?sid=<sessione>&dev=<interfaccia della linea>
   Durante il Test Di Velocità la linea è piena e le domande del telefono (una al secondo) restano in coda dietro al
   test. Qui invece il telefono apre UN collegamento all'inizio e il router gli spedisce ogni `iv` ms (200…1000, di serie 1 s) una riga JSON
   {rx, tx, ms, o}: contatori della linea, orologio in millisecondi e le righe nuove del lavoro (/tmp/.wf-job). I dati
   escono dal router verso il telefono: durante il Download quella direzione è libera, e fq_codel sulla linea dà
   spazio ai flussi piccoli anche durante l'Upload. Solo con una sessione valida (stesso permesso di wrtfreedom.job).
   Finisce con il lavoro (__FINE__) o dopo 55 s (uhttpd ferma gli script a 60 s: l'app ne riapre un altro). */
import { readfile, popen, stdout } from 'fs';

function out(s) { stdout.write(s); stdout.flush(); }
function param(k) { let m = match(getenv('QUERY_STRING') ?? '', regexp('(^|&)' + k + '=([^&]*)')); return m ? m[2] : ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }

let sid = param('sid'), dev = param('dev'), iv = +param('iv') || 1000;
if (iv < 200 || iv > 1000) iv = 1000;
if (!match(sid, /^[0-9a-f]{32}$/) || !match(dev, /^[A-Za-z0-9._-]{1,32}$/)) {
	out('Status: 400 Bad Request\r\nContent-Type: text/plain\r\n\r\nparametri non validi\n');
	exit(0);
}
let p = popen('ubus call session access ' + q(sprintf('%J', { ubus_rpc_session: sid, scope: 'ubus', object: 'wrtfreedom', 'function': 'job' })) + ' 2>/dev/null', 'r');
let a = null;
if (p) { try { a = json(p.read('all')); } catch (e) {} p.close(); }
if (!a || !a.access) {
	out('Status: 403 Forbidden\r\nContent-Type: text/plain\r\n\r\naccesso negato\n');
	exit(0);
}
out('Status: 200 OK\r\nContent-Type: application/x-ndjson\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nX-Accel-Buffering: no\r\n\r\n');
let pos = 0, c0 = clock(), base = '/sys/class/net/' + dev + '/statistics/';
while (true) {
	let c = clock(), ms = (c[0] - c0[0]) * 1000 + int((c[1] - c0[1]) / 1000000);
	let j = readfile('/tmp/.wf-job') ?? '';
	if (length(j) < pos) pos = 0;
	let o = substr(j, pos);
	pos = length(j);
	out(sprintf('%J\n', { rx: +trim(readfile(base + 'rx_bytes') ?? '0'), tx: +trim(readfile(base + 'tx_bytes') ?? '0'), ms: ms, o: o }));
	if (index(j, '__FINE__') >= 0 || ms > 55000)
		break;
	sleep(iv);
}
