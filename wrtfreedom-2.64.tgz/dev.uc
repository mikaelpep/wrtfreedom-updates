'use strict';
/* WrtFreedom: Dispositivi in sottofondo (pacchetto 2.49). Qui il lavoro con processi (nft, ip, curl); i metodi di rpcd
   leggono solo i file di stato.
   uso: ucode dev.uc setup        insiemi e catena «wf_dev» nel firewall (fw4, /usr/share/nftables.d), fw4 check prima
                                  della ricarica; il firewall si ricarica solo se il file cambia
        ucode dev.uc remove       toglie il file e ricarica il firewall
        ucode dev.uc tick         un giro al minuto (notify.sh): consumo per dispositivo, Tempo Con Traffico, quote,
                                  persone (tempo, fasce, pause), Pausa Per Tutti, insiemi del firewall ricostruiti
        ucode dev.uc apply        solo gli insiemi e lo stato (dopo una modifica dall'app: niente ricarica del firewall)
        ucode dev.uc save         riassunti in /etc/wrtfreedom (spegnimento del servizio)
        ucode dev.uc forget <mac> parte lenta di Dimentica: AdGuard Home, consumo e presenza del dispositivo
        ucode dev.uc reset <mac|all> azzera il consumo contato di un dispositivo o di tutti (2.59, clusage reset)
        ucode dev.uc monthly <n>  Consumo Del Mese Su Telegram: i primi n dispositivi del mese (2.59)
   Conteggio (catena forward, priorità filter - 2, prima di fw4): upload = pacchetti da un'interfaccia di casa per MAC
   esatto (wf_up), download = pacchetti verso un'interfaccia di casa per IP v4/v6 (wf_dn4/wf_dn6) tradotto in MAC con la
   tabella dei vicini. Il traffico tra dispositivi della stessa rete (bridge) non passa dal router e non si conta. Gli
   insiemi si leggono e si svuotano a ogni giro. Pause: wf_pause (MAC), Pausa Per Tutti con wf_pall (interfacce di casa
   mentre è attiva) e le eccezioni in wf_exc; gli elementi di wf_pause e wf_pall scadono dopo 3 minuti e ogni giro li
   rinnova (se i giri si fermano, le pause finiscono da sole). Un riavvio del firewall svuota gli insiemi: il giro dopo li
   ricostruisce. Pause in /tmp/wf-dpause.json, copia in /etc/wrtfreedom/dpause.json a ogni modifica (ricaricata dopo un
   riavvio). Stato in /tmp/wf-dev.json (giorni, ultimo minuto, persone, quote), copia in /etc/wrtfreedom/devuse.json ogni
   30 minuti e allo spegnimento; presenza (righe di notify.sh in /tmp/wf-presl) scaricata ogni ora in
   /etc/wrtfreedom/pres.log (60 giorni, al massimo 20000 righe). Ricariche del firewall una alla volta con fwstat.uc
   (/tmp/wf-fw.lock). Dimentica con il blocco occupato: in coda (/tmp/wf-dev.fq) per il giro dopo. */
import { readfile, writefile, popen, open, stat, mkdir, rmdir, unlink, rename, lsdir } from 'fs';

const W = '/usr/share/wrtfreedom', NFF = '/usr/share/nftables.d/table-pre/91-wrtfreedom-dev.nft';
const TMP = '/tmp/wf-dev.json', ETC = '/etc/wrtfreedom/devuse.json', DP = '/tmp/wf-dpause.json', LOCK = '/tmp/wf-dev.lock';
const PRESL = '/tmp/wf-presl', PLOG = '/etc/wrtfreedom/pres.log', SHJ = '/etc/wrtfreedom/shaper.json', SHF = '/etc/nftables.d/90-wrtfreedom.nft';
const DPE = '/etc/wrtfreedom/dpause.json', SHBAK = '/etc/wrtfreedom/shaper.bak', FWL = '/tmp/wf-fw.lock', FQ = '/tmp/wf-dev.fq', PMAX = 20000;
/* byte in un minuto sopra i quali il minuto conta come «Tempo Con Traffico» (circa 16 kbit/s: notifiche e sincronizzazioni
   di un telefono fermo restano sotto) */
const THR = 120000, KEEP = 35;
const NFT = 'set wf_lan { type ifname; }\n' +
	'set wf_up { type ether_addr; flags dynamic; size 1024; counter; }\n' +
	'set wf_dn4 { type ipv4_addr; flags dynamic; size 4096; counter; }\n' +
	'set wf_dn6 { type ipv6_addr; flags dynamic; size 4096; counter; }\n' +
	'set wf_pause { type ether_addr; flags timeout; }\n' +
	'set wf_pall { type ifname; flags timeout; }\n' +
	'set wf_exc { type ether_addr; }\n' +
	'chain wf_dev {\n' +
	'\ttype filter hook forward priority filter - 2; policy accept;\n' +
	'\tiifname @wf_pall ether saddr != @wf_exc drop\n' +
	'\tether saddr @wf_pause drop\n' +
	'\tiifname @wf_lan add @wf_up { ether saddr }\n' +
	'\toifname @wf_lan meta nfproto ipv4 add @wf_dn4 { ip daddr }\n' +
	'\toifname @wf_lan meta nfproto ipv6 add @wf_dn6 { ip6 daddr }\n' +
	'}\n';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rj(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function okmac(m) { return match(m, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) != null; }
function day(t) { let n = localtime(t); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
function hm(t) { let n = localtime(t); return n.hour * 60 + n.min; }
function arr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }

/* /etc/config/<nome> letto dal file (sezioni con .type, liste come array), come ucfile di wrtfreedom.uc */
function uv(v) { v = trim(v ?? ''); let m = match(v, /^'([^']*)'/) ?? match(v, /^"([^"]*)"/); return m ? m[1] : (split(v, /[ \t]+/)[0] ?? ''); }
function ucf(name) {
	let r = {}, cur = null, cnt = {};
	for (let l in split(readfile('/etc/config/' + name) ?? '', '\n')) {
		let m = match(l, /^[ \t]*(config|option|list)[ \t]+([^ \t]+)[ \t]*(.*)$/);
		if (!m) continue;
		if (m[1] == 'config') {
			let t = uv(m[2]), n = length(m[3]) ? uv(m[3]) : '';
			cnt[t] = (cnt[t] ?? -1) + 1;
			if (!length(n)) n = '@' + t + '[' + cnt[t] + ']';
			cur = r[n] = r[n] ?? { '.type': t };
		}
		else if (cur) {
			let k = uv(m[2]), v = uv(m[3]);
			if (m[1] == 'list') { if (type(cur[k]) != 'array') cur[k] = []; push(cur[k], v); }
			else cur[k] = v;
		}
	}
	return r;
}
const WC = ucf('wrtfreedom');
const EN = (WC.ui?.lang ?? '') == 'en';
function t(it, en) { return EN ? en : it; }
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' dev ' + q(txt) + ' >/dev/null 2>&1 </dev/null &'); }
function gb(b) { return sprintf('%.1f GB', b / 1e9); }
/* nome del dispositivo per gli avvisi: IP fisso (dhcp host), poi assegnazione DHCP, altrimenti il MAC */
let NM = null;
function devname(m) {
	if (NM == null) {
		NM = {};
		let D = ucf('dhcp'), lf = '/tmp/dhcp.leases';
		for (let k in D) if (D[k]['.type'] == 'dnsmasq' && length(D[k].leasefile ?? '')) lf = D[k].leasefile;
		for (let l in split(readfile(lf) ?? '', '\n')) { let p = split(l, ' '); if (length(p) >= 4 && p[3] != '*') NM[lc(p[1])] = p[3]; }
		for (let k in D) if (D[k]['.type'] == 'host' && length(D[k].name ?? '')) for (let x in split(lc(join(' ', arr(D[k].mac))), ' ')) NM[x] = D[k].name;
	}
	return NM[m] ?? m;
}

let UB = null;
function ub(obj, m, a) {
	if (UB == null) { try { UB = require('ubus').connect() ?? false; } catch (e) { UB = false; } }
	if (UB) { let r = UB.call(obj, m, a ?? {}); if (r != null) return r; }
	try { return json(sh('ubus call ' + obj + ' ' + m + ' 2>/dev/null') || 'null'); } catch (e) { return null; }
}
/* interfacce di casa: interfacce accese con un indirizzo, non nelle zone con il mascheramento (internet), non WireGuard
   (i client VPN restano fuori dalle pause) e non loopback; nomi veri da netifd */
function lanifs() {
	let F = ucf('firewall'), wn = {}, L = [];
	for (let k in F) if (F[k]['.type'] == 'zone' && F[k].masq == '1') for (let n in split(join(' ', arr(F[k].network)), ' ')) if (length(n)) wn[n] = true;
	for (let i in (ub('network.interface', 'dump') ?? {}).interface ?? []) {
		let d = i.l3_device ?? i.device ?? '';
		if (!i.up || wn[i.interface] || i.interface == 'loopback' || i.proto == 'wireguard' || !match(d, /^[A-Za-z0-9_.@-]{1,15}$/)) continue;
		/* linea verso internet anche senza zona con masq: l'interfaccia con la rotta predefinita */
		if (length(filter(i.route ?? [], (x) => (x.target == '0.0.0.0' || x.target == '::') && +x.mask == 0))) continue;
		if (!length(i['ipv4-address'] ?? []) && !length(i['ipv6-address'] ?? []) && !length(i['ipv6-prefix-assignment'] ?? [])) continue;
		if (index(L, d) < 0) push(L, d);
	}
	return L;
}
/* elementi di un insieme da «nft -j list set»: [{ v, b }] (b = byte del contatore); null = insieme assente */
function elems(o) {
	let J = null;
	try { J = json(o); } catch (e) { return null; }
	let R = null;
	for (let x in J?.nftables ?? []) if (x.set) {
		R = [];
		for (let e in x.set.elem ?? []) { let v = e?.elem ?? e; push(R, { v: '' + (v?.val ?? v), b: +(v?.counter?.bytes ?? 0) }); }
	}
	return R;
}
/* stato: /tmp, altrimenti la copia in /etc (dopo un riavvio) */
function load() {
	/* dopo un riavvio: pause delle persone e Pausa Per Tutti dalla copia in /etc */
	if (!stat(DP) && stat(DPE)) { let P = rj(DPE); if (P) wj(DP, P); }
	let S = rj(TMP);
	if (!S) { let E = rj(ETC) ?? {}; S = { days: E.days ?? {}, q: E.q ?? {}, pb: E.pb ?? {}, ip: {}, rate: {} }; }
	S.days = S.days ?? {}; S.q = S.q ?? {}; S.pb = S.pb ?? {}; S.ip = S.ip ?? {}; S.rate = S.rate ?? {};
	return S;
}
/* pause: /tmp e la copia in /etc, solo quando cambiano */
function dpset(P) { wj(DP, P); mkdir('/etc/wrtfreedom'); wj(DPE, P); }
function save(S) {
	S.st = time();
	mkdir('/etc/wrtfreedom');
	wj(ETC, { days: S.days, q: S.q, pb: S.pb, st: S.st });
}
/* inizio del periodo di una quota: giorno 0 = oggi (quota giornaliera), 1…28 = dal giorno del mese */
function qstart(d) {
	if (!(d > 0)) return day(time());
	let n = localtime(time()), y = n.year, m = n.mon;
	if (n.mday < d) { m--; if (m < 1) { m = 12; y--; } }
	return sprintf('%04d-%02d-%02d', y, m, d);
}
function used(S, mac, since) {
	let u = 0;
	for (let d in S.days) if (d >= since) { let x = S.days[d][mac]; if (x) u += x[0] + x[1]; }
	return u;
}
/* giorni della settimana di una persona: cifre 0…6 (0 = domenica); vuoto = tutti */
function dayok(days, t) { return !length(days) || index(days, '' + localtime(t).wday) >= 0; }
function inslot(sl, days, now) {
	let m = match(sl, /^([01][0-9]|2[0-3]):([0-5][0-9])-([01][0-9]|2[0-3]):([0-5][0-9])$/);
	if (!m) return false;
	let a = +m[1] * 60 + +m[2], b = +m[3] * 60 + +m[4], c = hm(now);
	if (a < b) return c >= a && c < b && dayok(days, now);
	/* fascia che passa la mezzanotte (22:00-07:00): dopo mezzanotte vale il giorno prima */
	return (c >= a && dayok(days, now)) || (c < b && dayok(days, now - 86400));
}

/* stato voluto: pause per persona (a mano, fasce, tempo finito), quote con blocco, Pausa Per Tutti */
function want(S, now) {
	let P = rj(DP) ?? {}, pz = {}, ps = {}, qs = {}, d = day(now), T = S.days[d] ?? {}, rmp = [], rma = null;
	for (let k in WC) {
		let c = WC[k];
		if (c['.type'] == 'person') {
			let macs = filter(arr(c.mac), okmac), days = c.days ?? '', bud = +(c.budget ?? 0), u = 0, why = '', pu = P.p?.[k];
			for (let m in macs) u += T[m]?.[2] ?? 0;
			if (pu != null && pu > 0 && pu <= now) { push(rmp, [k, pu]); pu = null; }
			if (pu != null) why = 'pause';
			else if (length(filter(arr(c.slot), (s) => inslot(s, days, now)))) why = 'slot';
			else if (bud > 0 && u >= bud && dayok(days, now)) {
				why = 'budget';
				if (S.pb[k] != d) { S.pb[k] = d; ev('dev_budget', '⏳ ' + (c.name ?? k) + ': ' + t('tempo di oggi finito', 'time for today is over') + ' (' + bud + ' min)'); }
			}
			if (length(why)) for (let m in macs) pz[m] = true;
			ps[k] = { used: u, why: why, until: pu };
		}
		else if (c['.type'] == 'quota' && okmac(c.mac ?? '') && +(c.gb ?? 0) > 0) {
			let m = c.mac, st = qstart(+(c.day ?? 0)), u = used(S, m, st), lim = +c.gb * 1e9, over = u >= lim, Q = S.q[m] ?? {};
			if (Q.p != st) Q = { p: st, al: 0 };
			if (over && !Q.al) {
				Q.al = 1;
				ev('dev_quota', (c.act == 'block' ? '⛔ ' : '📊 ') + devname(m) + ': ' + t('quota raggiunta', 'quota reached') + ' ' + gb(u) + ' / ' + gb(lim) + (c.act == 'block' ? ' · ' + t('internet bloccato', 'internet blocked') : ''));
			}
			S.q[m] = Q;
			let bl = over && c.act == 'block';
			if (bl) pz[m] = true;
			qs[m] = { used: u, start: st, over: over, blocked: bl };
		}
	}
	/* Pausa Per Tutti: finita (scadenza) = evento e stato tolto */
	let all = P.all, on = false;
	if (all && all.until > 0 && all.until <= now) { rma = all; ev('dev_pause_end', '▶️ ' + t('Pausa per tutti finita', 'Pause for everyone ended')); }
	else if (all) on = true;
	/* pause scadute tolte dal file solo se nel frattempo l'app non le ha cambiate */
	if (length(rmp) || rma) {
		let P2 = rj(DP) ?? {};
		for (let x in rmp) if (P2.p?.[x[0]] == x[1]) delete P2.p[x[0]];
		if (rma && P2.all?.t0 == rma.t0) P2.all = null;
		dpset(P2);
	}
	S.ps = ps; S.qs = qs;
	return { pause: keys(pz), all: on, exc: on ? filter(arr(all.except), okmac) : [] };
}
/* indirizzi IP attuali di ogni MAC dalla tabella dei vicini delle interfacce di casa (v4 e v6) */
function neigh(lan, S, now, o) {
	let M = {};
	for (let l in split(o ?? sh('ip neigh show 2>/dev/null'), '\n')) {
		let m = match(l, /^([0-9a-fA-F.:]+) dev ([^ ]+) lladdr ([0-9a-fA-F:]{17})/);
		if (!m || index(lan, m[2]) < 0) continue;
		let mac = lc(m[3]), ip = lc(m[1]);
		if (!okmac(mac) || mac == '00:00:00:00:00:00') continue;
		S.ip[ip] = [mac, now];
		push(M[mac] = M[mac] ?? [], ip);
	}
	for (let ip in S.ip) if (now - S.ip[ip][1] > 86400) delete S.ip[ip];
	return M;
}
/* insiemi del firewall in una sola transazione (svuota e riempie insieme: nessun istante senza pause); tmo = elementi che
   scadono dopo 3 minuti (rinnovati a ogni giro) */
function nftset(name, L, quote, tmo) {
	let c = 'flush set inet fw4 ' + name + '\n';
	if (length(L)) c += 'add element inet fw4 ' + name + ' { ' + join(', ', map(L, (x) => (quote ? '"' + x + '"' : x) + (tmo ? ' timeout 3m' : ''))) + ' }\n';
	return c;
}
/* fasce e Rallenta Per Un Po' (2.59): bersagli descritti da wrtfreedom.uc shapergen nella riga «# wf:gates» del file
   delle regole ({n, i = voce, m = MAC o c = Tutta La Casa, f/t = dalle/alle, d = giorni 0…6, u = scadenza}) */
function gates(sf) {
	let k = index(sf, '# wf:gates ');
	if (k < 0) return [];
	let l = substr(sf, k + 11), e = index(l, '\n'), G = null;
	try { G = json(e >= 0 ? substr(l, 0, e) : l); } catch (x) {}
	return type(G) == 'array' ? G : [];
}
function hhmm(s) { let m = match('' + (s ?? ''), /^([0-9]{2}):([0-9]{2})$/); return m ? +m[1] * 60 + +m[2] : 0; }
/* la voce vale al momento t? (ora di casa; fascia che passa la mezzanotte come le persone, inslot) */
function gwin(g, t) {
	if (g.u > 0 && t >= g.u) return false;
	if (g.f && g.t) return inslot(g.f + '-' + g.t, g.d ?? '', t);
	return dayok(g.d ?? '', t);
}
/* prossimo cambio (inizio o fine) entro 8 giorni, null = nessuno */
function gnext(g, now) {
	let cur = gwin(g, now), n = localtime(now), C = [];
	if (g.u > now) push(C, g.u);
	/* ora di casa di ogni giorno (nei giorni del cambio dell'ora un giorno non dura 86400 s): la stessa ora letta come UTC,
	   meno la differenza tra ora di casa e UTC in quel momento, riletta per il cambio (come logtime di wrtfreedom.uc; timelocal
	   senza isdst la legge come ora solare) */
	for (let d = 0; d < 9; d++) for (let x in [hhmm(g.f), hhmm(g.t)]) {
		let u = timegm({ year: n.year, mon: n.mon, mday: n.mday + d, hour: int(x / 60), min: x % 60, sec: 0 }), o = timegm(localtime(u)) - u;
		o = timegm(localtime(u - o)) - (u - o);
		if (u - o > now) push(C, u - o);
	}
	for (let c in sort(C, (a, b) => a - b)) if (gwin(g, c) != cur) return c;
	return null;
}
/* copia di sicurezza di Limita Velocità rimasta da un salvataggio interrotto (wrtfreedom.uc shaperfile): file di prima */
function shback() {
	let B = rj(SHBAK);
	if (type(B) == 'object') {
		if (B.nft != null) writefile(SHF, B.nft); else unlink(SHF);
		if (B.json != null) writefile(SHJ, B.json); else unlink(SHJ);
	}
	unlink(SHBAK);
}
function sync(S, D, lan, M, counters) {
	let c = counters ? 'flush set inet fw4 wf_up\nflush set inet fw4 wf_dn4\nflush set inet fw4 wf_dn6\n' : '';
	c += nftset('wf_lan', lan, true) + nftset('wf_pause', D.pause, false, true) + nftset('wf_pall', D.all ? lan : [], true, true) + nftset('wf_exc', D.exc);
	writefile('/tmp/wf-dev.nft', c);
	let ok = system('nft -f /tmp/wf-dev.nft >/dev/null 2>&1') == 0;
	/* Limita Velocità per dispositivo: indirizzi IP (v4 e v6) dei MAC negli insiemi wfl4_/wfl6_ che il file delle regole
	   dichiara (shaper) */
	let sf = readfile(SHF) ?? '', s = '', now = time(), on = {}, nx = {}, sst = stat(SHF);
	for (let x in match(sf, /set wfl4_([0-9a-f]+) /g) ?? []) {
		let id = x[1], mac = join(':', map([0, 2, 4, 6, 8, 10], (i) => substr(id, i, 2))), ips = M[mac] ?? [];
		if (length(id) == 12) s += nftset('wfl4_' + id, filter(ips, (y) => index(y, ':') < 0)) + nftset('wfl6_' + id, filter(ips, (y) => index(y, ':') >= 0));
	}
	/* fasce e Rallenta Per Un Po' (2.59): insiemi riempiti solo mentre la voce vale (elementi che scadono dopo 3 minuti,
	   rinnovati a ogni giro); stato di ogni voce (vale adesso, prossimo cambio) per il metodo shaper: un solo calcolo */
	for (let g in gates(sf)) {
		let a = gwin(g, now), i = '' + g.i, ips = a && g.m ? (M[g.m] ?? []) : [];
		if (on[i] == null) { on[i] = a; nx[i] = gnext(g, now); }
		if (g.c) { s += nftset('wfti_' + g.n, a ? lan : [], true, true); continue; }
		if (!okmac(g.m ?? '')) continue;
		s += nftset('wft4_' + g.n, filter(ips, (y) => index(y, ':') < 0), false, true) + nftset('wft6_' + g.n, filter(ips, (y) => index(y, ':') >= 0), false, true) +
			nftset('wftm_' + g.n, a ? [g.m] : [], false, true);
	}
	S.shp = { t: now, f: sst ? sst.mtime : null, on: on, next: nx };
	if (length(s)) { writefile('/tmp/wf-dev.shp.nft', s); if (system('nft -f /tmp/wf-dev.shp.nft >/dev/null 2>&1') != 0) ok = false; }
	/* tre giri di fila senza riuscire: un evento (una volta finché non torna a funzionare) */
	S.nfe = ok ? 0 : (S.nfe ?? 0) + 1;
	if (S.nfe == 3) ev('dev_nft', '⚠️ ' + t('Dispositivi: pause e limiti non aggiornati nel firewall', 'Devices: pauses and limits not updated in the firewall'));
	return ok;
}
/* ricariche del firewall una alla volta (stesso blocco di fwstat.uc); blocco rimasto da un processo interrotto tolto
   dopo 2 minuti */
function fwlock() {
	for (let i = 0; i < 60; i++) {
		if (mkdir(FWL)) return true;
		let s = stat(FWL);
		if (s && time() - s.mtime > 120) rmdir(FWL); else sh('sleep 1');
	}
	return false;
}
function setup() {
	if (!stat('/sbin/fw4')) return { error: 'serve firewall4' };
	if (readfile(NFF) == NFT) return { ok: true, changed: false };
	if (!fwlock()) return { error: 'firewall occupato' };
	sh("mkdir -p '" + substr(NFF, 0, rindex(NFF, '/')) + "'");
	writefile(NFF, NFT);
	if (system('fw4 check >/dev/null 2>&1') != 0) { unlink(NFF); rmdir(FWL); return { error: 'fw4 check' }; }
	sh('/etc/init.d/firewall reload >/dev/null 2>&1');
	rmdir(FWL);
	return { ok: true, changed: true };
}
/* presenza: righe «ora mac 1|0» di notify.sh aggiunte a /etc/wrtfreedom/pres.log; una volta al giorno restano gli
   ultimi 60 giorni */
function presflush(S, now) {
	/* rinominato prima di leggerlo: le righe che notify.sh aggiunge nel frattempo vanno in un file nuovo */
	if (stat(PRESL) && rename(PRESL, PRESL + '.f')) {
		let o = readfile(PRESL + '.f'), f = null;
		mkdir('/etc/wrtfreedom');
		if (length(o) && (f = open(PLOG, 'a'))) { f.write(o); f.close(); }
		unlink(PRESL + '.f');
	}
	/* una volta al giorno, o prima se il file supera le PMAX righe (circa 32 byte l'una): ultimi 60 giorni, al massimo
	   PMAX righe */
	let d = day(now), st = stat(PLOG);
	if (S.prot != d || (st && st.size > PMAX * 32)) {
		S.prot = d;
		let lim = now - 60 * 86400, L = filter(split(readfile(PLOG) ?? '', '\n'), length), K = filter(L, (l) => +split(l, ' ')[0] >= lim);
		if (length(K) > PMAX) K = slice(K, length(K) - PMAX);
		if (length(K) < length(L)) { writefile(PLOG + '.t', length(K) ? join('\n', K) + '\n' : ''); rename(PLOG + '.t', PLOG); }
	}
	S.pt = now;
}
function lock(wait) {
	let lk = mkdir(LOCK);
	for (let i = 0; !lk && i < wait; i++) { sh('sleep 1'); lk = mkdir(LOCK); }
	if (!lk) { let s = stat(LOCK); if (s && time() - s.mtime < 300) return false; rmdir(LOCK); lk = mkdir(LOCK); }
	return lk;
}
/* AdGuard Home: il MAC tolto dai client personalizzati (client con altri ID aggiornato, altrimenti cancellato).
   false = AdGuard non ha risposto o ha rifiutato (si riprova al giro dopo) */
function adgforget(mac) {
	let cred = trim(readfile('/etc/wrtfreedom/adguard') ?? '');
	if (!length(cred)) return true;
	let a = '192.168.1.1:8080', f = false, K = '/tmp/.wf-adgf';
	for (let l in split(readfile('/etc/adguardhome/adguardhome.yaml') ?? '', '\n')) {
		if (substr(l, 0, 5) == 'http:') f = true;
		if (f && index(l, 'address:') >= 0) { a = trim(split(trim(l), /[ \t]+/)[1] ?? '') || a; break; }
	}
	/* credenziali leggibili solo da root fin dalla creazione del file; «\» e «"» con l'escape del file di curl */
	sh('umask 077; rm -f ' + K + '; : > ' + K);
	writefile(K, 'user = "' + replace(cred, /[\\"]/g, (m) => '\\' + m) + '"\n');
	let c = 'curl -s -m 8 -K ' + K + ' ', u = 'http://' + a + '/control/', J = null, ok = true;
	try { J = json(sh(c + u + 'clients 2>/dev/null') || 'null'); } catch (e) {}
	if (type(J) != 'object') ok = false;
	for (let x in J?.clients ?? []) {
		let ids = x.ids ?? [], rest = filter(ids, (i) => lc('' + i) != mac);
		if (length(rest) == length(ids)) continue;
		let body = length(rest) ? { name: x.name, data: { ...x, ids: rest } } : { name: x.name };
		let r = sh(c + "-o /dev/null -w '%{http_code}' -X POST -H 'Content-Type: application/json' --data " + q(sprintf('%J', body)) + ' ' + u + 'clients/' + (length(rest) ? 'update' : 'delete') + ' 2>/dev/null');
		if (trim(r) != '200') ok = false;
	}
	unlink(K);
	return ok;
}
/* parte lenta di Dimentica: consumo, quote, IP e presenza del dispositivo, poi AdGuard Home; false = AdGuard da riprovare */
function forgetmac(S, mac) {
	for (let d in S.days) delete S.days[d][mac];
	delete S.q[mac]; delete S.rate[mac];
	for (let ip in S.ip) if (S.ip[ip][0] == mac) delete S.ip[ip];
	/* presenza del dispositivo tolta da /tmp e da /etc */
	for (let f in [PRESL, PLOG]) if (stat(f)) { let K = filter(split(readfile(f) ?? '', '\n'), (l) => length(l) && split(l, ' ')[1] != mac); writefile(f + '.t', length(K) ? join('\n', K) + '\n' : ''); rename(f + '.t', f); }
	save(S);
	return adgforget(mac);
}
/* coda di Dimentica: righe «mac tentativi»; AdGuard riprovato al massimo 5 volte */
function fqadd(mac, n) { let f = open(FQ, 'a'); if (f) { f.write(mac + ' ' + n + '\n'); f.close(); } }
function fqrun(S) {
	if (!stat(FQ) || !rename(FQ, FQ + '.w')) return;
	let L = split(readfile(FQ + '.w') ?? '', '\n');
	unlink(FQ + '.w');
	for (let l in L) {
		let p = split(trim(l), ' '), n = +(p[1] ?? 0);
		if (okmac(p[0]) && !forgetmac(S, p[0]) && n < 4) fqadd(p[0], n + 1);
	}
}

/* Rallenta Per Un Po' finito: un evento per voce e il posto liberato con il metodo shaper (del, in sottofondo; il limite
   è già finito con gli insiemi), al massimo un tentativo ogni 5 minuti. Voci con scadenza segnate in S.shxd
   ({id: {u = scadenza, n = nome, e = evento mandato}}): l'evento parte una sola volta anche se il del fallisce o se la
   voce la toglie un altro salvataggio; voce tolta prima della scadenza (spenta dall'utente) = nessun evento */
function shexp(S, now) {
	let R = rj(SHJ), X = [], c = '', W = S.shxd ?? {}, ids = {};
	if (type(R) != 'array') R = [];
	for (let r in R) {
		let id = '' + (r?.id ?? '');
		if (type(r) != 'object' || !(+(r.until ?? 0) > 0) || !match(id, /^[A-Za-z0-9_]{1,32}$/)) continue;
		let u = int(+r.until), w = '' + (r.who ?? '');
		ids[id] = true;
		if (W[id]?.u != u) W[id] = { u: u, e: 0, n: r.casa === true ? t('Tutta la casa', 'The whole house') : substr(w, 0, 2) == 'p:' ? (WC[substr(w, 2)]?.name ?? substr(w, 2)) : devname(lc('' + (r.mac ?? r.macs?.[0] ?? ''))) };
		if (u <= now) push(X, id);
	}
	for (let id in keys(W)) {
		if (W[id].u <= now && !W[id].e) { W[id].e = 1; ev('dev_slow_end', '▶️ ' + W[id].n + ': ' + t('di nuovo veloce', 'back to full speed')); }
		if (!ids[id]) delete W[id];
	}
	S.shxd = W;
	if (!length(X) || now - (S.shx ?? 0) < 300) return;
	S.shx = now;
	for (let id in X) c += 'ubus call wrtfreedom shaper ' + q(sprintf('%J', { del: id })) + '; ';
	sh('( ' + c + ') >/dev/null 2>&1 </dev/null &');
}
/* azzera il consumo contato (clusage reset): giorni e stato delle quote del MAC o di tutti; un solo salvataggio */
function resetuse(S, mac) {
	if (mac == 'all') { S.days = {}; S.qs = {}; }
	else if (okmac(mac)) { for (let d in S.days) delete S.days[d][mac]; if (S.qs) delete S.qs[mac]; }
	else return;
	save(S);
}
/* Consumo Del Mese Su Telegram (2.59, cron.sh monthly): i primi n dispositivi del mese con i contatori di Consumo Dei
   Dispositivi (35 giorni: il giorno 1 c'è tutto il mese finito; gli altri giorni il mese in corso fino a oggi) */
function monthly(n) {
	if (!length(WC.tg?.token ?? '') || !length(WC.tg?.chat ?? '')) return;
	if (!(n >= 1 && n <= 10)) n = 5;
	let S = load(), now = time(), x = localtime(now), y = x.year, m = x.mon, part = x.mday != 1, B = {}, tot = 0, first = null, T = [];
	if (!part) { m--; if (m < 1) { m = 12; y--; } }
	let pre = sprintf('%04d-%02d-', y, m), G = (b) => { let v = sprintf('%.1f', b / 1e9); return (EN ? v : replace(v, '.', ',')) + ' GB'; };
	for (let d in S.days) if (substr(d, 0, 8) == pre) {
		if (first == null || d < first) first = d;
		for (let k in S.days[d]) { let v = S.days[d][k]; B[k] = (B[k] ?? 0) + v[0] + v[1]; tot += v[0] + v[1]; }
	}
	let L = sort(keys(B), (a, b) => B[b] - B[a]), mesi = EN ? ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] :
		['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
	push(T, '📊 ' + t('Consumo di ', 'Usage in ') + mesi[m - 1] + (part ? t(' (fino a oggi)', ' (so far)') : '') + ' · ' + (ucf('system')['@system[0]']?.hostname ?? 'OpenWrt'));
	if (!length(L)) push(T, t('Nessun consumo contato', 'No usage counted'));
	for (let i = 0; i < length(L) && i < n; i++) push(T, (i + 1) + '. ' + devname(L[i]) + ' · ' + G(B[L[i]]));
	if (length(L)) push(T, t('Totale', 'Total') + ': ' + G(tot));
	if (first != null && first > pre + '01') push(T, t('Contato dal giorno ', 'Counted from day ') + +substr(first, 8, 2));
	mkdir('/tmp/wf-tgq');
	writefile('/tmp/wf-tgq/' + now + '-mo', join('\n', T));
	sh('( ucode ' + W + '/tgq.uc flush ) </dev/null >/dev/null 2>&1 &');
}

let cmd = ARGV[0];
if (cmd == 'setup') { print(setup(), '\n'); exit(0); }
if (cmd == 'monthly') { monthly(+(ARGV[1] ?? 5)); exit(0); }
if (cmd == 'remove') {
	if (stat(NFF) && fwlock()) { unlink(NFF); sh('/etc/init.d/firewall reload >/dev/null 2>&1'); rmdir(FWL); }
	exit(0);
}
if (index(['tick', 'apply', 'save', 'forget', 'reset'], cmd) < 0) { print('uso: dev.uc setup | remove | tick | apply | save | forget <mac> | reset <mac|all> | monthly <quanti>\n'); exit(1); }
if (!lock(cmd == 'tick' ? 0 : 10)) {
	/* blocco occupato: Dimentica in coda per il giro dopo; allo spegnimento la copia in /etc si scrive comunque */
	let mac = lc('' + (ARGV[1] ?? ''));
	if (cmd == 'forget' && okmac(mac)) fqadd(mac, 0);
	if (cmd == 'save') save(load());
	exit(0);
}
let S = load(), now = time();

if (cmd == 'save') {
	/* spegnimento o riavvio: chi è collegato esce adesso (altrimenti il tempo da spento conterebbe come presenza) */
	let up = int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])), o = '';
	for (let f in lsdir('/tmp/wf-pres') ?? []) {
		let p = split(trim(readfile('/tmp/wf-pres/' + f) ?? ''), ' ');
		if (match(f, /^[0-9a-f]{12}$/) && p[0] == 'on' && up - +p[1] < 240) o += now + ' ' + join(':', map([0, 2, 4, 6, 8, 10], (i) => substr(f, i, 2))) + ' 0\n';
	}
	if (length(o)) { let f = open(PRESL, 'a'); if (f) { f.write(o); f.close(); } }
	presflush(S, now); wj(TMP, S); save(S); rmdir(LOCK); exit(0);
}

/* Dimentica rimasti in coda, poi quello chiesto adesso */
fqrun(S);
if (cmd == 'forget') {
	let mac = lc('' + (ARGV[1] ?? ''));
	if (okmac(mac) && !forgetmac(S, mac)) fqadd(mac, 1);
	cmd = 'apply';
}
/* azzeramento, poi lo stato voluto rifatto (una quota con blocco si sblocca subito) */
if (cmd == 'reset') { resetuse(S, lc('' + (ARGV[1] ?? ''))); cmd = 'apply'; }

let lan = lanifs();
if (cmd == 'apply') {
	let M = neigh(lan, S, now);
	let D = want(S, now);
	sync(S, D, lan, M, false);
	wj(TMP, S);
	rmdir(LOCK);
	exit(0);
}

/* ---- tick ---- */
let o = sh("for s in wf_up wf_dn4 wf_dn6; do nft -j list set inet fw4 $s 2>/dev/null || echo null; echo '@@WF@@'; done; ip neigh show 2>/dev/null"), p = split(o, '@@WF@@\n');
let U = elems(p[0]), D4 = elems(p[1]), D6 = elems(p[2]);
let M = neigh(lan, S, now, p[3]);
if (U == null) {
	/* insiemi assenti (firewall ricaricato senza il file, aggiornamento del firmware, primo avvio): setup al massimo ogni ora */
	if (now - (S.setupAt ?? 0) > 3600) { S.setupAt = now; setup(); }
	S.t = null;
}
else {
	let d = day(now), T = S.days[d] = S.days[d] ?? {}, B = {};
	for (let e in U) { let m = lc(e.v); if (okmac(m)) { B[m] = B[m] ?? [0, 0]; B[m][1] += e.b; } }
	for (let e in [...(D4 ?? []), ...(D6 ?? [])]) {
		let m = S.ip[lc(e.v)]?.[0];
		if (m) { B[m] = B[m] ?? [0, 0]; B[m][0] += e.b; }
	}
	/* minuti dall'ultimo giro (di solito 1; i contatori tengono anche i giri saltati) */
	let dt = S.t ? now - S.t : 60, dm = int((dt + 30) / 60);
	if (dm < 1) dm = 1;
	if (dm > 5) dm = 5;
	S.rate = {};
	for (let m in B) {
		let x = T[m] = T[m] ?? [0, 0, 0], b = B[m][0] + B[m][1];
		x[0] += B[m][0]; x[1] += B[m][1];
		if (b >= THR * dm) x[2] += dm;
		if (b > 0) S.rate[m] = [int(B[m][0] / (dt > 0 ? dt : 60)), int(B[m][1] / (dt > 0 ? dt : 60))];
	}
	S.t = now;
	/* giorni tenuti: gli ultimi KEEP */
	let K = sort(keys(S.days));
	while (length(K) > KEEP) delete S.days[shift(K)];
}
let Dw = want(S, now);
sync(S, Dw, lan, M, U != null);
shexp(S, now);
/* Limita Velocità salvato a metà da un processo interrotto (copia di sicurezza più vecchia di 2 minuti): file di prima */
let sb = stat(SHBAK);
if (sb && now - sb.mtime > 120) shback();
if (!S.pt || now - S.pt >= 3600) presflush(S, now);
wj(TMP, S);
if (!S.st || now - S.st >= 1800) save(S);
rmdir(LOCK);
