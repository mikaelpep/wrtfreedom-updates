'use strict';
/* WrtFreedom 2.55: Un Solo Test Di Velocità (pagina, widget, bot, Pianificazioni: lo stesso strumento e lo stesso risultato)
   uso: ucode speed.uc run [partenza] [collegamento]   test con l'uscita dal vivo nello stile di speedtest-go (lavoro di
                                                       diag/speed start in /tmp/.wf-job, letto anche da wf-live.cgi)
        ucode speed.uc text                            test senza uscita dal vivo e riepilogo in parole (bot, Pianificazioni)
        ucode speed.uc save                            copia del risultato in /etc/wrtfreedom/speed.json (allo spegnimento)
   speedtest-go se c'è; altrimenti (o se non riesce) Cloudflare con curl o uclient-fetch, dichiarato nel risultato:
   via = 'speedtest-go' | 'cloudflare', why = 'nogo' (speedtest-go non installato) | 'fail' (speedtest-go non riuscito).
   Risultato in /tmp/wf-speed.json {last {t, down, up, ping, jitter, via, why, server, vpn}, list (ultimi 10), fail};
   in /etc al massimo ogni 6 ore e allo spegnimento. Un test alla volta (blocco /tmp/wf-speed.lock: «c» = processo del
   ripiego in corso, «stop» = annullato da jobstop, niente salvataggio) */
import { popen, readfile, writefile, unlink, stat, rename, mkdir, rmdir, lsdir, stdout } from 'fs';

const F = '/tmp/wf-speed.json', FE = '/etc/wrtfreedom/speed.json', O = '/tmp/wf-speed.out', LK = '/tmp/wf-speed.lock';
const CFD = 'https://speed.cloudflare.com/__down?bytes=25000000', CFU = 'https://speed.cloudflare.com/__up';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
/* lingua dell'app (wrtfreedom.ui.lang) letta dal file, senza processi */
function uo(sec, opt) {
	let s = false;
	for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
		if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
		let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
		if (m && m[1] == opt) return m[2];
	}
	return '';
}
const EN = uo('ui', 'lang') == 'en';
function L(it, en) { return EN ? en : it; }
function out(s) { stdout.write(s + '\n'); stdout.flush(); }
function r1(x) { return x == null ? null : int(x * 10 + 0.5) / 10; }
/* Mbps da «123.45Mbps», «1.2Gbps», «900Kbps» */
function mbps(n, u) { let v = +n; return u == 'G' ? v * 1000 : u == 'K' ? v / 1000 : v; }
function stopped() { return has(LK + '/stop'); }

/* blocco: un test alla volta (scade dopo 180 s, test rimasto a metà) */
function lock() {
	if (mkdir(LK)) return true;
	let s = stat(LK);
	if (s && time() - s.mtime > 180) { sh('rm -rf ' + LK); return mkdir(LK) == true; }
	return false;
}

/* speedtest-go: valori finali dalle righe «✓ Latency/Download/Upload» (l'ultima di ognuna) */
function parsego(o) {
	let r = {}, last = (re) => { let a = match(o, re); return a && length(a) ? a[length(a) - 1] : null; };
	let d = last(/Download: *([0-9.]+) *([GMK]?)bps/g), u = last(/Upload: *([0-9.]+) *([GMK]?)bps/g);
	let l = match(o, /Latency: *([0-9.]+) *ms/), j = match(o, /Jitter: *([0-9.]+) *ms/), s = match(o, /Test Server: *\[[0-9]{1,12}\] *[0-9.]*km *(.{1,120})/);
	if (d) r.down = r1(mbps(d[1], d[2]));
	if (u) r.up = r1(mbps(u[1], u[2]));
	if (l) r.ping = r1(+l[1]);
	if (j) r.jitter = r1(+j[1]);
	if (s) r.server = trim(split(s[1], /[\r\n]/)[0]);  /* solo la prima riga (dopo vengono le misure) */
	return r;
}
/* al massimo 90 s (timeout se c'è, altrimenti un controllo con sleep/kill): il test resta dentro il blocco di 180 s,
   così non ne parte un secondo insieme al primo */
function rungo(src, live) {
	let c = 'speedtest-go' + (length(src) ? ' --source ' + q(src) : '');
	if (length(trim(sh('command -v timeout 2>/dev/null')))) c = 'timeout 90 ' + c + ' 2>&1';
	else c = '( ' + c + ' 2>&1 & p=$!; ( sleep 90; kill $p ) >/dev/null 2>&1 </dev/null & w=$!; wait $p; kill $w ) 2>/dev/null';
	if (live) { system(c + ' | tee ' + O); }
	else sh(c + ' > ' + O + ' 2>&1');
	let o = readfile(O) ?? '';
	unlink(O);
	return parsego(o);
}
/* Cloudflare: [byte, secondi] da curl -w (anche se si ferma per il tempo: vale quello scaricato) o da uclient-fetch */
function cfget(cmd) {
	let o = trim(sh('( ' + cmd + ' ) & echo $! > ' + LK + '/c; wait $! 2>/dev/null; rm -f ' + LK + '/c'));
	let m = match(o, /([0-9]+) ([0-9.]+)$/);
	return m ? [ +m[1], +m[2] ] : null;
}
function curlhas() { return has('/usr/bin/curl'); }
function runcf(src, live) {
	let r = { server: 'Cloudflare' }, ci = length(src) ? ' --interface ' + q(src) : '';
	/* tempo di risposta e variazione da 4 ping verso il server dei nomi di Cloudflare */
	let T = [];
	for (let l in split(sh('ping -4 -c 4 -W 2 1.1.1.1 2>/dev/null'), '\n')) { let m = match(l, /time=([0-9.]+) *ms/); if (m) push(T, +m[1]); }
	if (length(T)) {
		let s = 0, jt = 0;
		for (let x in T) s += x;
		for (let i = 1; i < length(T); i++) jt += T[i] > T[i - 1] ? T[i] - T[i - 1] : T[i - 1] - T[i];
		r.ping = r1(s / length(T)); r.jitter = length(T) > 1 ? r1(jt / (length(T) - 1)) : 0;
		if (live) out('✓ Latency: ' + sprintf('%.2f', r.ping) + 'ms Jitter: ' + sprintf('%.2f', r.jitter) + 'ms');
	}
	if (stopped()) return r;
	let D = null;
	if (curlhas()) D = cfget('curl -s -m 30' + ci + " -o /dev/null -w '%{size_download} %{time_total}' " + q(CFD));
	else if (has('/bin/uclient-fetch')) {
		/* senza curl: durata misurata qui (centesimi di secondo dall'accensione) */
		let u0 = +(split(readfile('/proc/uptime') ?? '0', ' ')[0]);
		let b = +trim(sh('( uclient-fetch -q -T 30 -O - ' + q(CFD) + ' 2>/dev/null | wc -c ) & echo $! > ' + LK + '/c; wait $! 2>/dev/null; rm -f ' + LK + '/c'));
		let u1 = +(split(readfile('/proc/uptime') ?? '0', ' ')[0]);
		D = [ b, u1 - u0 ];
	}
	if (D && D[0] > 100000 && D[1] > 0) {
		r.down = r1(D[0] * 8 / D[1] / 1e6);
		if (live) out('✓ Download: ' + sprintf('%.2f', r.down) + 'Mbps (Used: ' + sprintf('%.2f', D[0] / 1e6) + 'MB)');
	}
	if (stopped() || !curlhas() || r.down == null) return r;
	let U = cfget('head -c 8000000 /dev/zero | curl -s -m 30' + ci + " -o /dev/null -w '%{size_upload} %{time_total}' --data-binary @- " + q(CFU));
	if (U && U[0] > 100000 && U[1] > 0) {
		r.up = r1(U[0] * 8 / U[1] / 1e6);
		if (live) out('✓ Upload: ' + sprintf('%.2f', r.up) + 'Mbps (Used: ' + sprintf('%.2f', U[0] / 1e6) + 'MB)');
	}
	return r;
}
/* salvataggio: ultimo risultato, ultimi 10, copia in /etc se quella che c'è ha più di 6 ore */
function save(R) {
	let S = rjs(F) ?? rjs(FE) ?? {};
	if (R.down == null) S.fail = { t: time(), why: R.why ?? 'fail' };
	else {
		S.last = R; S.fail = null;
		let Ls = type(S.list) == 'array' ? S.list : [];
		unshift(Ls, { t: R.t, down: R.down, up: R.up, ping: R.ping, via: R.via });
		S.list = slice(Ls, 0, 10);
	}
	wjs(F, S);
	let e = stat(FE);
	if (R.down != null && (!e || time() - e.mtime > 21600)) { mkdir('/etc/wrtfreedom'); wjs(FE, S); }
}
function test(src, vpn, live) {
	let go = has('/usr/bin/speedtest-go'), R = null, why = null;
	if (go) {
		R = rungo(src, live);
		if (R.down == null && !stopped()) why = 'fail';
	}
	else why = 'nogo';
	if (why && !stopped()) {
		if (live) out('✓ Test Server: Cloudflare (' + (why == 'nogo' ? L('ripiego: speedtest-go non installato', 'fallback: speedtest-go not installed') : L('ripiego: speedtest-go non riuscito', 'fallback: speedtest-go failed')) + ')');
		sh('touch ' + LK);
		R = runcf(src, live);
	}
	R = R ?? {};
	R.t = time(); R.via = why ? 'cloudflare' : 'speedtest-go'; R.why = why; R.vpn = length(vpn) ? vpn : null;
	for (let k in [ 'down', 'up', 'ping', 'jitter', 'server' ]) if (!(k in R)) R[k] = null;
	if (!stopped()) save(R);
	return R;
}
function num(x) { return x == null ? '—' : EN ? sprintf('%.1f', x) : replace(sprintf('%.1f', x), '.', ','); }

let A = ARGV[0] ?? '';
if (A == 'save') {
	/* in /etc solo se il risultato è più nuovo della copia (niente scritture inutili a ogni spegnimento) */
	let S = rjs(F), E = rjs(FE);
	if (S?.last && +(S.last.t ?? 0) > +(E?.last?.t ?? 0)) { mkdir('/etc/wrtfreedom'); wjs(FE, S); }
}
else if (A == 'run' || A == 'text') {
	let src = '' + (ARGV[1] ?? ''), vpn = '' + (ARGV[2] ?? '');
	if (!match(src, /^([0-9.]{7,15})?$/) || !match(vpn, /^(wgo(ut|[1-5]))?$/)) { out(L('Parametri non validi', 'Invalid parameters')); exit(0); }
	if (!lock()) { out(L('Un test di velocità è già in corso', 'A speed test is already running')); exit(0); }
	let R = test(src, vpn, A == 'run'), st = stopped();
	sh('rm -rf ' + LK);
	if (A == 'text') {
		if (R.down == null) out(L('Test di velocità non riuscito: il router non raggiunge i server', 'Speed test failed: the router cannot reach the servers'));
		else {
			out('🚀 ' + L('Test Di Velocità', 'Speed Test'));
			out('Download ' + num(R.down) + ' Mbit/s · Upload ' + num(R.up) + ' Mbit/s');
			out('Ping ' + num(R.ping) + ' ms' + (R.via == 'cloudflare' ? ' · ' + L('con Cloudflare (ripiego)', 'with Cloudflare (fallback)') : length(R.server ?? '') ? ' · ' + R.server : ''));
		}
	}
	else if (R.down == null && !st) out(L('Test di velocità non riuscito', 'Speed test failed'));
}
