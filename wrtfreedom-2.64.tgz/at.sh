#!/bin/sh
# WrtFreedom: invia un comando AT al modem con lo strumento presente sul router
# uso: at.sh 'AT+CSQ'   ·   at.sh --tool (dice quale strumento userebbe)
C="$1"
port() {
	P=$(uci -q get wrtfreedom.modem.atport)
	[ -n "$P" ] && [ -c "$P" ] && { echo "$P"; return; }
	for P in /dev/ttyUSB2 /dev/ttyUSB3 /dev/wwan0at0 /dev/wwan0at1 /dev/ttyACM0 /dev/ttyUSB1; do
		[ -c "$P" ] && { echo "$P"; return; }
	done
}
mm() { mmcli -L 2>/dev/null | grep -o '/Modem/[0-9]*' | head -n 1 | cut -d/ -f3; }
# sceglie lo strumento una volta sola: T = strumento, PORT = porta seriale, MMI = numero del modem in ModemManager
tool() {
	T=none; PORT=; MMI=
	command -v quectel-at >/dev/null 2>&1 && { T=quectel-at; return; }
	PORT=$(port)
	command -v sms_tool >/dev/null 2>&1 && [ -n "$PORT" ] && { T=sms_tool; return; }
	command -v gl_modem >/dev/null 2>&1 && { T=gl_modem; return; }
	command -v atinout >/dev/null 2>&1 && [ -n "$PORT" ] && { T=atinout; return; }
	command -v mmcli >/dev/null 2>&1 && { MMI=$(mm); [ -n "$MMI" ]; } && { T=mmcli; return; }
}
[ "$C" = "--tool" ] && { tool; echo "$T"; exit 0; }
[ -n "$C" ] || { echo "uso: at.sh 'AT...'"; exit 1; }
# un comando alla volta: due accessi insieme alla porta del modem danno risposte vuote
# (il flock di BusyBox non ha -w: si riprova con -n una volta al secondo, al massimo 15 secondi)
if command -v flock >/dev/null 2>&1; then exec 9>/var/lock/wf-at.lock; i=0; until flock -n 9; do i=$((i+1)); [ $i -ge 15 ] && break; sleep 1; done; fi
tool
case "$T" in
	quectel-at) quectel-at "$C" ;;
	sms_tool) sms_tool -d "$PORT" at "$C" ;;
	gl_modem) gl_modem AT "$C" ;;
	atinout) echo "$C" | atinout - "$PORT" - ;;
	mmcli) mmcli -m "$MMI" --command="$C" 2>&1 | sed "s/^response: '//;s/'\$//" ;;
	*) echo "ERROR: nessuno strumento per i comandi AT (installa sms-tool)"; exit 2 ;;
esac
