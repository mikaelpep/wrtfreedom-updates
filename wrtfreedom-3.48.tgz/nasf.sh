#!/bin/sh
R=/tmp/wf-nas; J=$R/jobs; SC=$R/scan; MNTS=${WF_MOUNTS:-/proc/mounts}
U=${WF_NASFUC:-/usr/share/wrtfreedom/nasf.uc}
EVSH=${WF_EVENTSH:-/usr/share/wrtfreedom/event.sh}
SPD=${WF_NASPEED:-/usr/share/wrtfreedom/naspeed.uc}
EN=0; [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh "$EVSH" cron "$1" nas "$2" >/dev/null 2>&1; }
jsv() { JV=$1; case "$JV" in *[\\\"]*|*[[:cntrl:]]*) JV=$(printf '%s' "$JV" | sed 's/\\/\\\\/g; s/"/\\"/g; s/[[:cntrl:]]/?/g') ;; esac; }
hs() { awk -v b="$1" -v en=$EN 'BEGIN { u = "B"; if (b >= 1073741824) { b /= 1073741824; u = "GB" } else if (b >= 1048576) { b /= 1048576; u = "MB" } else if (b >= 1024) { b /= 1024; u = "KB" }
	s = (u == "B" || b >= 10) ? sprintf("%d", b + 0.5) : sprintf("%.1f", b); if (!en) sub(/\./, ",", s); print s " " u }'; }
spd() { [ -n "$1" ] && [ $# -gt 1 ] && [ -f "$SPD" ] && ucode "$SPD" add "$@" </dev/null >/dev/null 2>&1; true; }
okid() { case "$1" in ''|*[!A-Za-z0-9-]*) return 1 ;; esac; return 0; }

case "$1" in
scan)
id=$2; k=${3:-all}; by=${4:-night}; okid "$id" || exit 2
case "$k" in index|all) ;; *) exit 2 ;; esac; case "$by" in night|hand) ;; *) exit 2 ;; esac
mkdir -p $SC; L=$SC/$id.run
p=$(cat "$L" 2>/dev/null); [ -n "$p" ] && [ -d "/proc/$p" ] && exit 0
c=; echo $$ > "$L"; trap '[ -n "$c" ] && kill $c 2>/dev/null; rm -f "$L"; exit 1' HUP INT TERM
WFS_ID=$id WFS_K=$k WFS_BY=$by ucode -e "loadfile('$U')().scan(getenv('WFS_ID'), getenv('WFS_K'), getenv('WFS_BY'));" </dev/null >/dev/null 2>&1 & c=$!
spd "$id" "$c"; wait $c
rm -f "$L"; exit 0 ;;
night)
[ -f "$U" ] || exit 0
ucode -e "print(join('\n', loadfile('$U')().plan()), '\n');" </dev/null 2>/dev/null | while read -r id k; do
okid "$id" && sh "$0" scan "$id" "$k" night </dev/null >/dev/null 2>&1
done
exit 0 ;;
log)
[ -f "$U" ] && ucode -e "loadfile('$U')().logtick();" </dev/null >/dev/null 2>&1
exit 0 ;;
trown)
[ -f "$U" ] || exit 0
mkdir -p $R; L=$R/trown.run; A=$R/trown.again
p=$(cat "$L" 2>/dev/null); [ -n "$p" ] && [ -d "/proc/$p" ] && { : > "$A"; exit 0; }
echo $$ > "$L"; trap 'rm -f "$L"' EXIT
i=0; while [ $i -lt 5 ]; do rm -f "$A"
ucode -e "loadfile('$U')().trashown(false, true);" </dev/null >/dev/null 2>&1
[ -f "$A" ] || break; i=$((i+1)); done
exit 0 ;;
run) ;;
*) echo "uso: nasf.sh run|scan|night|log|trown"; exit 2 ;;
esac

ID=$2; case "$ID" in ''|*[!0-9a-f]*) exit 2 ;; esac
IN=$J/$ID.in; JS=$J/$ID.json; [ -f "$IN" ] || exit 1
echo $$ > $J/$ID.pid
DISK=; TOT=0; BT=0; ROOT=; NAME=; OWN=; N=0
while IFS= read -r l; do
case "$l" in
disk=*) DISK=${l#disk=} ;; total=*) TOT=${l#total=} ;; bytes_total=*) BT=${l#bytes_total=} ;;
root=*) ROOT=${l#root=} ;; name=*) NAME=${l#name=} ;;
own=*) OWN=${l#own=} ;;
src=*) N=$((N + 1)); eval "S$N=\${l#src=}" ;;
esac
done < "$IN"
case "$TOT" in ''|*[!0-9]*) TOT=0 ;; esac; case "$BT" in ''|*[!0-9]*) BT=0 ;; esac
rootok() {
[ -n "$ROOT" ] && [ "$ROOT" != / ] || return 1
WFR=$ROOT awk 'BEGIN { r = ENVIRON["WFR"] } { m = $2; gsub(/\\040/, " ", m); gsub(/\\011/, "\t", m); gsub(/\\012/, "\n", m); gsub(/\\134/, "\\", m); if (m == r) f = 1 }
		END { exit f ? 0 : 1 }' "$MNTS" 2>/dev/null
}
DONE=0; BY=0; FILE=; ST=run; ERR=; ERREN=; T0=$(date +%s); T1=0
jw() {
jsv "$FILE"; f_=$JV; e_=
[ -n "$ERR" ] && { jsv "$ERR"; e_=",\"error\":\"$JV\""; jsv "$ERREN"; e_="$e_,\"error_en\":\"$JV\""; }
[ -n "$OWN" ] && { jsv "$OWN"; e_="$e_,\"own\":\"$JV\""; }
printf '{"id":"%s","op":"delete","forever":true,"disk":"%s","to_disk":"","done":%s,"total":%s,"bytes":%s,"bytes_total":%s,"file":"%s","state":"%s"%s,"t0":%s,"t1":%s}\n' \
		"$ID" "$DISK" "$DONE" "$TOT" "$BY" "$BT" "$f_" "$ST" "$e_" "$T0" "$T1" > "$JS.t$$" && mv -f "$JS.t$$" "$JS"
}
finish() {
ST=$1; ERR=$2; ERREN=$3; T1=$(date +%s); FILE=; jw
rm -f $J/$ID.pid $J/$ID.stop
case "$1" in
ok) [ "$BY" -gt 0 ] && ev nas_freed "💾 ${NAME:-NAS} ¦ $(t "Liberati" "Freed") $(hs $BY) ¦ $DONE $(t "eliminati definitivamente" "permanently deleted")" ;;
err) ev nas_job_err "⚠️ $(t "Elimina Definitivamente" "Delete Permanently") ¦ $(t "Non riuscita" "Failed") ¦ $(t "$2" "$3")" ;;
esac
exit 0
}
trap 'finish stop' HUP INT TERM
jw
rootok || finish err "Disco non collegato" "Drive not mounted"
i=0
while [ $i -lt $N ]; do
i=$((i + 1)); eval "S=\$S$i"; FILE=${S##*/}
[ -f $J/$ID.stop ] && finish stop
case "$S" in "$ROOT"/?*) ;; *) DONE=$((DONE + 1)); continue ;; esac
[ -e "$S" ] || [ -L "$S" ] || { DONE=$((DONE + 1)); continue; }
z=$(du -sk "$S" 2>/dev/null | cut -f1); case "$z" in ''|*[!0-9]*) z=0 ;; esac
jw
rm -rf "$S" 2>/dev/null
[ -e "$S" ] || [ -L "$S" ] && finish err "Non eliminato: $FILE" "Not deleted: $FILE"
BY=$((BY + z * 1024)); DONE=$((DONE + 1)); jw
done
finish ok
