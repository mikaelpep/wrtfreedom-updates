#!/bin/sh
R=/tmp/wf-nas; J=$R/jobs
MOUNTS=${WF_MOUNTS:-/proc/mounts}; SYS=${WF_SYS:-/sys}; INITD=${WF_INITD:-/etc/init.d}
EVSH=${WF_EVENTSH:-/usr/share/wrtfreedom/event.sh}
MT=${WF_MOUNT:-mount}; UM=${WF_UMOUNT:-umount}
CP=${WF_CP:-cp}; SY=${WF_SYNC:-sync}
EN=0; [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh "$EVSH" cron "$1" usb "$2" >/dev/null 2>&1; }
jsv() { JV=$1; case "$JV" in *[\\\"]*|*[[:cntrl:]]*) JV=$(printf '%s' "$JV" | sed 's/\\/\\\\/g; s/"/\\"/g; s/[[:cntrl:]]/?/g') ;; esac; }
hs() { awk -v b="$1" -v en=$EN 'BEGIN { u = "B"; if (b >= 1073741824) { b /= 1073741824; u = "GB" } else if (b >= 1048576) { b /= 1048576; u = "MB" } else if (b >= 1024) { b /= 1024; u = "KB" }
	s = (u == "B" || b >= 10) ? sprintf("%d", b + 0.5) : sprintf("%.1f", b); if (!en) sub(/\./, ",", s); print s " " u }'; }
SPD=${WF_NASPEED:-/usr/share/wrtfreedom/naspeed.uc}
spd() { [ -n "$1" ] && [ $# -gt 1 ] && [ -f "$SPD" ] && ucode "$SPD" add "$@" </dev/null >/dev/null 2>&1; true; }
mounted() { awk -v m="$1" '{ gsub(/\\040/, " ", $2) } $2 == m { f = 1 } END { exit !f }' "$MOUNTS" 2>/dev/null; }
mntdev() { awk -v m="$1" '{ d = $1; gsub(/\\040/, " ", $2) } $2 == m { r = d } END { print r }' "$MOUNTS" 2>/dev/null; }
reopen() { [ -d $R/ntfsopen.lock ] || return 1; p_=$(cat $R/ntfsopen.lock/pid 2>/dev/null)
[ -n "$(find $R/ntfsopen.lock -maxdepth 0 -mmin -10 2>/dev/null)" ] || return 1
[ -z "$p_" ] || kill -0 "$p_" 2>/dev/null; }
EJ=${WF_NASETC:-/etc/wrtfreedom}/nas-jobs
rp() { (cd -P -- "$1" 2>/dev/null && pwd -P); }
svcstop() { STOPPED=; for s_ in $1; do case "$s_" in *[!A-Za-z0-9_.-]*|'') continue ;; esac
[ -x "$INITD/$s_" ] || continue; "$INITD/$s_" running >/dev/null 2>&1 || continue
"$INITD/$s_" stop >/dev/null 2>&1; STOPPED="$STOPPED $s_"; done; }
svcstart() { for s_ in $STOPPED; do "$INITD/$s_" start >/dev/null 2>&1; done; STOPPED=; }
umountall() { o_=$IFS; IFS='|'; set -f; for m_ in $1; do IFS=$o_; [ -n "$m_" ] && mounted "$m_" && { sync; $UM "$m_" 2>/dev/null || { set +f; IFS=$o_; return 1; }; }; done; set +f; IFS=$o_; return 0; }
MSAVE=
savemnt() { MSAVE=$J/$ID.mnt; awk -v l="$1" 'BEGIN { n = split(l, a, "|"); for (i = 1; i <= n; i++) if (a[i] != "") w[a[i]] = 1 }
	{ d = $1; m = $2; gsub(/\\040/, " ", d); gsub(/\\040/, " ", m) } (m in w) && !(m in s) { s[m] = 1; print d "\t" m "\t" $3 "\t" $4 }' "$MOUNTS" > "$MSAVE" 2>/dev/null; }
csop() { case "$1" in ntfs3|ntfs|exfat|vfat) ;; *) printf '%s' "$2"; return ;; esac
awk -v o="$2" 'BEGIN { n = split(o, a, ","); s = ""; m = 0
		for (i = 1; i <= n; i++) { if (a[i] == "" || a[i] == "utf8" || a[i] ~ /^(iocharset|nls)=/) continue; if (a[i] ~ /^(umask|dmask|fmask)=/) m = 1; s = s (s == "" ? "" : ",") a[i] }
		s = s (s == "" ? "" : ",") "iocharset=utf8"; if (!m) s = s ",umask=0000"; printf "%s", s }'; }
mnt1() {
if mounted "$2"; then [ "$(mntdev "$2")" = "$1" ]; return; fi
mkdir -p "$2" 2>/dev/null
op_=$4; [ "$FIXOK" = 1 ] || op_=$(printf '%s' "$op_" | awk -F, '{ s = ""; for (i = 1; i <= NF; i++) if ($i != "force") s = s (s == "" ? "" : ",") $i; printf "%s", s }')
[ -n "$op_" ] && op_=$(csop "$3" "$op_"); o2_=$(csop "$3" "")
[ -n "$op_" ] && $MT ${3:+-t "$3"} -o "$op_" "$1" "$2" </dev/null >/dev/null 2>&1 && mounted "$2" && return 0
if [ -z "$o2_" ]; then $MT ${3:+-t "$3"} "$1" "$2" </dev/null >/dev/null 2>&1 && mounted "$2" && return 0
elif [ "$o2_" != "$op_" ]; then $MT -t "$3" -o "$o2_" "$1" "$2" </dev/null >/dev/null 2>&1 && mounted "$2" && return 0; fi
case "$3" in ntfs3|ntfs|ntfs-3g|fuseblk)
[ "$FIXOK" = 1 ] && $MT -t ntfs3 -o "$(csop ntfs3 force)" "$1" "$2" </dev/null >/dev/null 2>&1 && mounted "$2" && return 0
command -v ntfs-3g >/dev/null 2>&1 && ntfs-3g "$1" "$2" </dev/null >/dev/null 2>&1 && mounted "$2" && return 0 ;;
esac
[ "$RM" = 1 ] && command -v block >/dev/null 2>&1 && block mount </dev/null >/dev/null 2>&1; [ "$(mntdev "$2")" = "$1" ]
}
remountall() { NOTM=; [ -n "$MSAVE" ] && [ -f "$MSAVE" ] || return 0
while IFS="$(printf '\t')" read -r md_ mm_ mt_ mo_ <&3; do
[ -n "$mm_" ] && { mnt1 "$md_" "$mm_" "$mt_" "$mo_" || NOTM="$NOTM${NOTM:+, }$mm_"; }
done 3< "$MSAVE"
rm -f "$MSAVE"; [ -z "$NOTM" ]; }
wiped() { [ -n "$MSAVE" ] && [ -f "$MSAVE" ] || return 0
awk -F '\t' -v l="$*" 'BEGIN { n = split(l, a, " ") } { for (i = 1; i <= n; i++) if (a[i] != "" && ($1 == a[i] || index($1, a[i]) == 1 && substr($1, length(a[i]) + 1) ~ /^p?[0-9]+$/)) next; print }' \
		"$MSAVE" > "$MSAVE.t" 2>/dev/null; mv -f "$MSAVE.t" "$MSAVE"; }
ferr() { remountall && finish err "$1" "$2"; finish err "$1. Disco non rimontato: staccalo e riattaccalo" "$2. Drive not remounted: unplug it and plug it back in"; }
cktool() { CK=; case "$1" in ext2|ext3|ext4) l_=e2fsck; CKP=e2fsprogs ;; fat32) l_="fsck.fat fsck.vfat"; CKP=dosfstools ;;
exfat) l_="fsck.exfat exfatfsck"; CKP=exfat-fsck ;; ntfs) l_=ntfsfix; CKP=ntfs-3g-utils ;; *) l_=; CKP= ;; esac
for c_ in $l_; do command -v "$c_" >/dev/null 2>&1 && { CK=$c_; return 0; }; done; return 1; }

lim() { l_=$1; shift; "$@" & p_=$!; i_=0
while kill -0 $p_ 2>/dev/null; do
[ $i_ -ge "$l_" ] && { kill -9 $p_ 2>/dev/null; return 124; }
sleep 1; i_=$((i_ + 1))
done
wait $p_; }
EJL=${WF_EJLIM:-20}
lnk() { l_=$(readlink "$SYS/class/block/$1" 2>/dev/null); printf '%s' "${l_:-?}"; }
hung() { [ -f "$R/hung/$1" ] || return 1; [ "$(cat "$R/hung/$1" 2>/dev/null)" = "$(lnk "$1")" ] && return 0; rm -f "$R/hung/$1"; return 1; }
sethung() { mkdir -p "$R/hung"; lnk "$1" > "$R/hung/$1.t$$" && mv -f "$R/hung/$1.t$$" "$R/hung/$1"; }
wbase() { case "$1" in nvme*n*p[0-9]*|mmcblk*p[0-9]*) printf '%s' "${1%p[0-9]*}" ;; sd*|hd*|vd*|xvd*) printf '%s' "${1%%[0-9]*}" ;; *) printf '%s' "$1" ;; esac; }
DST=${WF_DSTALL:-90}; DWX=; DWSPD=
dw() { b_=$1; l_=$2; shift 2; DWX=; k_=$(lnk "$b_"); "$@" & p_=$!; i_=0; s_=; z_=0
[ -n "$DWSPD" ] && spd "$DWSPD" "$p_"
while kill -0 $p_ 2>/dev/null; do
case "$(cut -d ' ' -f 3 /proc/$p_/stat 2>/dev/null)" in Z|'') break ;; esac
sleep 1; i_=$((i_ + 1))
kill -0 $p_ 2>/dev/null || break
case "$(cut -d ' ' -f 3 /proc/$p_/stat 2>/dev/null)" in Z|'') break ;; esac
[ "$(lnk "$b_")" = "$k_" ] || { kill -9 $p_ 2>/dev/null; DWX=gone; return 125; }
n_=$(cat "$SYS/class/block/$b_/stat" 2>/dev/null); f_=$(cat "$SYS/class/block/$b_/inflight" 2>/dev/null)
case "$f_" in *[1-9]*) if [ "$n_" = "$s_" ]; then z_=$((z_ + 1)); else z_=0; fi ;; *) z_=0 ;; esac; s_=$n_
{ [ $z_ -ge "$DST" ] || { [ "$l_" -gt 0 ] && [ $i_ -ge "$l_" ]; }; } && { kill -9 $p_ 2>/dev/null; sethung "$b_"; DWX=hung; return 124; }
done
wait $p_; }
tw() { t_=$1; shift; trap ':' USR1; ( sleep "$t_"; kill -USR1 $$ ) </dev/null >/dev/null 2>&1 & tm_=$!
wait "$@"; kill $tm_ 2>/dev/null; trap - USR1; }

case "$1" in
eject)
b=$2; S=$3; shift 3
case "$b" in *[!A-Za-z0-9]*|'') echo busy; exit 1 ;; esac
reopen && { echo busy; exit 1; }
svcstop "$S"; lim "$EJL" sync
for m in "$@"; do mounted "$m" || continue; e_=1
while :; do
lim "$EJL" $UM "$m" 2>/dev/null && break; r_=$?
{ [ $r_ = 124 ] || [ $e_ -ge 3 ]; } && { svcstart; echo busy; exit 1; }
sleep 1; e_=$((e_ + 1)); mounted "$m" || break
done
done
case "$b" in md[0-9]*) [ -w "$SYS/block/$b/md/array_state" ] && echo clear > "$SYS/block/$b/md/array_state" 2>/dev/null ;; esac
mkdir -p $R/ejected; date +%s > $R/ejected/$b
u=$(readlink -f "$SYS/class/block/$b/device" 2>/dev/null)
[ -w "$SYS/class/block/$b/device/delete" ] && echo 1 > "$SYS/class/block/$b/device/delete" 2>/dev/null
while [ -n "$u" ] && [ "$u" != / ]; do
case "${u##*/}" in [0-9]*-[0-9]*) case "${u##*/}" in *:*) ;; *) [ -w "$u/remove" ] && echo 1 > "$u/remove" 2>/dev/null; break ;; esac ;; esac
u=${u%/*}
done
GO=${WF_EJGO:-}
( sleep 2; svcstart; [ -n "$GO" ] && rm -f "$GO" ) </dev/null >/dev/null 2>&1 &
echo ok; exit 0 ;;
smart)
b=$2; case "$b" in *[!A-Za-z0-9]*|'') exit 1 ;; esac
mkdir -p $R/smart; f=$R/smart/$b.json
id_=$(readlink "$SYS/class/block/$b" 2>/dev/null); id_=${id_:-?}
na() { [ -f "$f" ] && grep -q '"smart_status"\|"temperature"' "$f" && { touch "$f"; return; }
printf '{"na":true,%s"t":%s}' "${1:+\"z\":$1,}" "$(date +%s)" > "$f.n"; mv -f "$f.n" "$f"; }
if [ -f "$R/smart/$b.na" ]; then [ "$(cat "$R/smart/$b.na" 2>/dev/null)" = "$id_" ] && { na; exit 0; }; rm -f "$R/smart/$b.na"; fi
hung "$b" && exit 0
echo run > "$R/smart/$b.q"
SL=${WF_SMLIM:-30}
dw "$b" "$SL" smartctl -n standby -H -A -c -l selftest -j "/dev/$b" > "$f.t" 2>/dev/null </dev/null
[ -n "$DWX" ] && { rm -f "$f.t"; date +%s > "$R/smart/$b.q"; exit 0; }
grep -q '"smart_status"' "$f.t" || grep -qi '"string": *"Device is in \(standby\|sleep\|idle\)' "$f.t" 2>/dev/null || {
dw "$b" "$SL" smartctl -d sat -n standby -H -A -c -l selftest -j "/dev/$b" > "$f.t" 2>/dev/null </dev/null
[ -n "$DWX" ] && { rm -f "$f.t"; date +%s > "$R/smart/$b.q"; exit 0; }; }
date +%s > "$R/smart/$b.q"
if grep -q '"smart_status"\|"temperature"' "$f.t"; then mv -f "$f.t" "$f"
else
z=; grep -qi '"string": *"Device is in \(standby\|sleep\|idle\)' "$f.t" 2>/dev/null && z=1
[ -n "$z" ] && { zp=$(sed -n 's/.*"z":\([0-9]*\).*/\1/p' "$f" 2>/dev/null); z=$((${zp:-0} + 1)); }
grep -q '"smart_status"\|"temperature"' "$f" 2>/dev/null || [ -n "$z" ] || printf '%s' "$id_" > "$R/smart/$b.na"
rm -f "$f.t"; na $z
fi
exit 0 ;;
smarttest)
b=$2; case "$b" in *[!A-Za-z0-9]*|'') exit 1 ;; esac
d=; grep -q '"type": *"sat"' $R/smart/$b.json 2>/dev/null && d="-d sat"
hung "$b" && exit 1
mkdir -p $R/smart; echo run > $R/smart/$b.q
dw "$b" "${WF_SMLIM:-30}" smartctl $d -t short "/dev/$b" >/dev/null 2>&1 </dev/null; r_=$?
date +%s > $R/smart/$b.q
[ $r_ = 0 ] && [ -z "$DWX" ] || exit 1
date +%s > $R/smart/$b.run
i=0; while [ $i -lt 15 ]; do
sleep 60; i=$((i + 1))
sh "$0" smart "$b"
grep -q '"remaining_percent"\|"current_self_test_completion_percent"' $R/smart/$b.json 2>/dev/null || break
done
exit 0 ;;
usage)
id=$2; m=$3; mkdir -p $R/usage; f=$R/usage/$id.json
tot=0; o=; n=0; sy=0
ub=$(mntdev "$m"); ub=$(wbase "${ub#/dev/}")
[ -n "$ub" ] && hung "$ub" && { rm -f $R/usage/$id.run; exit 1; }
DWSPD=$id; dw "${ub:-?}" 0 du -k -d 1 "$m" 2>/dev/null > "$f.du" </dev/null; DWSPD=
[ -n "$DWX" ] && { rm -f "$f.du" $R/usage/$id.run; exit 1; }
while IFS="$(printf '\t')" read -r k p; do
case "$k" in ''|*[!0-9]*) continue ;; esac
if [ "$p" = "$m" ]; then tot=$((k * 1024)); continue; fi
b=${p##*/}; bl=$(printf '%s' "$b" | tr 'A-Z' 'a-z')
case "$bl" in .*|lost+found|'$recycle.bin'|'system volume information'|recycler|'$windows.~bt'|'$windows.~ws') sy=$((sy + k * 1024)); n=$((n + k * 1024)); continue ;; esac
jsv "${p#"$m"}"; o="$o${o:+,}{\"path\":\"$JV\",\"size\":$((k * 1024))}"; n=$((n + k * 1024))
done < "$f.du"
rm -f "$f.du"
ot=$((tot - n)); [ $ot -lt 0 ] && ot=0
printf '{"dirs":[%s],"other":%s,"sys":%s,"total":%s,"t":%s}\n' "$o" "$ot" "$sy" "$tot" "$(date +%s)" > "$f.t" && mv -f "$f.t" "$f"
rm -f $R/usage/$id.run; exit 0 ;;
keep)
[ -f $R/keep.list ] || exit 0
SA=; SF=
read -r SF < $R/sync.f 2>/dev/null || { SF=0; $SY -h 2>&1 | grep -q '\[-[a-z]*f' && SF=1; mkdir -p $R; echo $SF > $R/sync.f; }
while IFS= read -r m; do
[ -n "$m" ] && awk -v m="$m" '{ gsub(/\\040/, " ", $2) } $2 == m && $4 ~ /^rw/ { f = 1 } END { exit !f }' "$MOUNTS" 2>/dev/null &&
date +%s > "$m/.wf-sveglio" 2>/dev/null && { [ "$SF" = 1 ] && $SY -f "$m" 2>/dev/null || SA=1; }
done < $R/keep.list
[ -n "$SA" ] && $SY; exit 0 ;;
wake)
b=$2; case "$b" in *[!A-Za-z0-9]*|'') exit 1 ;; esac
s=$(cat "$SYS/class/block/$b/size" 2>/dev/null); s=${s:-2048}; k=$(( ($(date +%s) * 7919) % (s / 8 + 1) ))
dd if="/dev/$b" of=/dev/null bs=4096 count=1 skip=$k 2>/dev/null; exit 0 ;;
ntfsopen)
U=${WF_NASUC:-/usr/share/wrtfreedom/nas.uc}; V=${WF_NASVCSH:-/usr/share/wrtfreedom/nasvc.sh}
{ [ -f "$U" ] && ucode -e "let N = loadfile('$U')(); print(sprintf('%J', N.ntfsopen()), '\n');" </dev/null 2>/dev/null; } ||
block mount </dev/null >/dev/null 2>&1
[ -f "$V" ] && sh "$V" follow </dev/null >/dev/null 2>&1
exit 0 ;;
blk)
BL=${WF_BLKLIM:-5}; B=$R/blk.$$; rm -rf "$B"; mkdir -p "$B" || exit 1
bi() { ( block info $1 > "$B/$2" 2>/dev/null && : > "$B/$2.ok" ) </dev/null >/dev/null 2>&1 & }
H=; for h in "$R"/hung/*; do [ -f "$h" ] && case "${h##*/}" in *.t*) ;; *) hung "${h##*/}" && H=1 ;; esac; done
if [ -z "$H" ]; then bi "" all; tw "$BL" $!; [ -f "$B/all.ok" ] && { cat "$B/all"; rm -rf "$B"; exit 0; }; fi
P=; D=
for p in "$SYS"/class/block/*; do d=${p##*/}; [ -e "$p" ] || continue; hung "$(wbase "$d")" && continue
bi "/dev/$d" "$d"; P="$P $!"; D="$D $d"; done
[ -n "$P" ] && tw "$BL" $P
for d in $D; do if [ -f "$B/$d.ok" ]; then cat "$B/$d"; else sethung "$(wbase "$d")"; fi; done | awk '!s[$0]++'
rm -rf "$B"; exit 0 ;;
run) ;;
*) echo "uso: nasjob.sh run|eject|smart|smarttest|usage|keep|wake|ntfsopen|blk"; exit 2 ;;
esac

ID=$2; case "$ID" in ''|*[!0-9a-f]*) exit 2 ;; esac
IN=$J/$ID.in; JS=$J/$ID.json; [ -f "$IN" ] || exit 1
echo $$ > $J/$ID.pid
rec() { mkdir -p "$EJ" 2>/dev/null || return 0; : > "$EJ/.$ID.t"; for kv_ in "$@"; do printf '%s\n' "$kv_" >> "$EJ/.$ID.t"; done; mv -f "$EJ/.$ID.t" "$EJ/$ID"; }
trap 'remountall; svcstart; exit 1' HUP INT TERM
OP=; DISK=; TOD=; OWN=; TOT=0; BT=0; DST=; DROOT=; DREL=; CF=ask; SAME=0; ROOT=; N=0
while IFS= read -r l; do
case "$l" in
op=*) OP=${l#op=} ;; disk=*) DISK=${l#disk=} ;; to_disk=*) TOD=${l#to_disk=} ;;
total=*) TOT=${l#total=} ;; bytes_total=*) BT=${l#bytes_total=} ;;
dst=*) DST=${l#dst=} ;; droot=*) DROOT=${l#droot=} ;; drel=*) DREL=${l#drel=} ;; root=*) ROOT=${l#root=} ;;
conflict=*) CF=${l#conflict=} ;; same=*) SAME=${l#same=} ;; mk=*) MK=${l#mk=} ;;
dev=*) DEV=${l#dev=} ;; base=*) BASE=${l#base=} ;; part=*) PART=${l#part=} ;; whole=*) WHOLE=${l#whole=} ;;
fs=*) FS=${l#fs=} ;; ktype=*) KT=${l#ktype=} ;; mnt=*) MNT=${l#mnt=} ;; mnts=*) MNTS=${l#mnts=} ;;
svc=*) SVC=${l#svc=} ;; label=*) LABEL=${l#label=} ;; name=*) NAME=${l#name=} ;;
remount=*) RM=${l#remount=} ;;
own=*) OWN=${l#own=} ;;
model=*) MODEL=${l#model=} ;; bsize=*) BSIZE=${l#bsize=} ;;
src=*) N=$((N + 1)); eval "S$N=\${l#src=}" ;;
rel=*) eval "R$N=\${l#rel=}" ;;
nr=1) eval "NR$N=1" ;;
esac
done < "$IN"
case "$TOT" in ''|*[!0-9]*) TOT=0 ;; esac; case "$BT" in ''|*[!0-9]*) BT=0 ;; esac
DONE=0; BY=0; PART_=0; FILE=; ST=run; ASKF=; ERR=; ERREN=; T0=$(date +%s); T1=0; W=0; ALLA=; TC=0; RES=
jw() {
jsv "$FILE"; f_=$JV; a_=; e_=; x_=
[ "$ST" = ask ] && { jsv "$ASKF"; a_=",\"ask\":{\"file\":\"$JV\"}"; }
[ -n "$ERR" ] && { jsv "$ERR"; e_=",\"error\":\"$JV\""; jsv "$ERREN"; e_="$e_,\"error_en\":\"$JV\""; }
[ -n "$RES" ] && x_=",\"result\":\"$RES\""
[ -n "$OWN" ] && { jsv "$OWN"; x_="$x_,\"own\":\"$JV\""; }
printf '{"id":"%s","op":"%s","disk":"%s","to_disk":"%s","done":%s,"total":%s,"bytes":%s,"bytes_total":%s,"file":"%s","state":"%s"%s%s%s,"t0":%s,"t1":%s}\n' \
		"$ID" "$OP" "$DISK" "$TOD" "$DONE" "$TOT" "$((BY + PART_))" "$BT" "$f_" "$ST" "$a_" "$e_" "$x_" "$T0" "$T1" > "$JS.t$$" && mv -f "$JS.t$$" "$JS"
}
tick() { W=$((W + 1)); [ $W -ge 25 ] && { W=0; jw; }; }
stopped() { [ -f $J/$ID.stop ]; }
opname() { case "$OP" in copy) t "Copia" "Copy" ;; move) t "Spostamento" "Move" ;; backup) t "Backup Al Volo" "Quick Backup" ;;
delete) t "Cestino" "Trash" ;; format) t "Formatta" "Format" ;; check) t "Controlla e Ripara" "Check and Repair" ;; esac; }
finish() { # $1 stato, $2 errore it, $3 errore en
svcstart
ownrun
ST=$1; ERR=$2; ERREN=$3; T1=$(date +%s); [ "$1" = ok ] && [ "$TOT" -gt 0 ] && DONE=$TOT; FILE=; jw
rm -f "$EJ/$ID"
if [ "$OP" = format ] && [ "$1" = ok ] && [ -d "$EJ" ]; then
for f_ in "$EJ"/*; do [ -f "$f_" ] && grep -qx 'op=format' "$f_" && grep -qxF "model=$MODEL" "$f_" && grep -qxF "size=$BSIZE" "$f_" && rm -f "$f_"; done
fi
rm -f $J/$ID.pid $J/$ID.stop $J/$ID.ans
case "$1" in
ok) case "$OP" in delete) ;; copy|move|backup) ev nas_job_ok "💾 $(opname) ¦ $(t "Finita" "Done") ¦ $DONE $(t "file" "files") · $(hs $BY)" ;;
check) if [ "$FS" = ntfs ]; then ev nas_job_ok "💾 ${NAME:-$(opname)} ¦ $(opname) ¦ $(t "Riparazione base: fai chkdsk su Windows" "Basic repair: run chkdsk on Windows")"
else ev nas_job_ok "💾 ${NAME:-$(opname)} ¦ $(opname) ¦ $(t "Finito" "Done")"; fi ;;
*) ev nas_job_ok "💾 ${NAME:-$(opname)} ¦ $(opname) ¦ $(t "Finito" "Done")" ;; esac ;;
err) ev nas_job_err "⚠️ $(opname) ¦ $(t "Non riuscita" "Failed") ¦ $2" ;;
esac
exit 0
}
cperr() {
if [ -n "$DROOT" ] && ! mounted "$DROOT"; then finish err "Disco staccato durante il lavoro" "Drive removed during the job"; fi
if [ -n "$DROOT" ]; then a_=$(df -k "$DROOT" 2>/dev/null | awk 'NR > 1 { print $4; exit }'); [ -n "$a_" ] && [ "$a_" -lt 1024 ] && finish err "Disco pieno" "Drive full"; fi
jsv "$1"; finish err "Non riuscita: ${1##*/}" "Failed: ${1##*/}"
}
askq() {
[ -n "$ALLA" ] && { ANS=$ALLA; return; }
[ "$CF" != ask ] && { ANS=$CF; return; }
ASKF=$1; ST=ask; rm -f $J/$ID.ans; jw; w_=0
while :; do
stopped && { ANS=stop; break; }
if [ -f $J/$ID.ans ]; then read -r a_ b_ < $J/$ID.ans; rm -f $J/$ID.ans
case "$a_" in replace|keep|skip) ANS=$a_; [ "$b_" = 1 ] && ALLA=$a_; break ;; esac; fi
sleep 1; w_=$((w_ + 1)); [ $w_ -gt 86400 ] && { ANS=stop; break; }
done
ST=run; ASKF=; jw
}
uniqn() { b_=$2; x_=; case "$b_" in ?*.*) x_=.${b_##*.}; b_=${b_%.*} ;; esac
i_=2; while [ -e "$1/$b_ ($i_)$x_" ] || [ -L "$1/$b_ ($i_)$x_" ]; do i_=$((i_ + 1)); done; UN="$b_ ($i_)$x_"; }
totrash() {
T_=$2/.wf-trash; mkdir -p "$T_/files" "$T_/info" || return 1
TC=$((TC + 1)); n_=$(date +%s)-$$-$TC
z_=$(ls -lnRA -- "$1" 2>/dev/null | awk '$1 ~ /^-/ { s += $5 } END { printf "%.0f", s }'); case "$z_" in ''|*[!0-9]*) z_=0 ;; esac
mv "$1" "$T_/files/$n_" || return 1
printf 'from=%s\nwhen=%s\nsize=%s\n' "$3" "$(date +%s)" "$z_" > "$T_/info/$n_.info"
}
tovers() {
case "$(WFV_F=${WF_NASFUC:-/usr/share/wrtfreedom/nasf.uc} WFV_M=$1 WFV_P=$2 ucode -e "print(loadfile(getenv('WFV_F'))().vsave(getenv('WFV_M'), getenv('WFV_P')));" 2>/dev/null)" in
*'"ok": true'*) return 0 ;; esac
return 1
}
ownadd() { printf '%s\n' "$1" >> $J/$ID.nw; }
ownrun() {
[ -f $J/$ID.nw ] || return 0
[ -n "$DROOT" ] && mounted "$DROOT" && WFO_F=${WF_NASFUC:-/usr/share/wrtfreedom/nasf.uc} WFO_M=$DROOT WFO_W=$OWN WFO_L=$J/$ID.nw \
		ucode -e "loadfile(getenv('WFO_F'))().ownfix();" </dev/null >/dev/null 2>&1
rm -f $J/$ID.nw
}
cpfile() {
s_=$1; d_=$2; FILE=${s_##*/}; n_=${d_##*/}; w_=${d_%/*}/.$n_.wfcp
[ ${#n_} -gt 249 ] && w_=${d_%/*}/.wf$$.$DONE.wfcp
{ [ -L "$d_" ] || [ -L "$w_" ]; } && return 1
set -f
set -- $(ls -ln "$s_" 2>/dev/null); set +f; z_=${5:-0}
case "$z_" in *[!0-9]*) z_=0 ;; esac
if [ "$z_" -gt 33554432 ]; then
jw; $CP "$s_" "$w_" & p_=$!; spd "$DISK" "$p_@$J/$ID.stop"; k_=0
while kill -0 $p_ 2>/dev/null; do
sleep 1; k_=$((k_ + 1))
if stopped; then kill $p_ 2>/dev/null; wait $p_ 2>/dev/null; rm -f "$w_"; PART_=0; return 2; fi
if [ $((k_ % 5)) = 0 ] && [ -n "$DROOT" ] && ! mounted "$DROOT"; then kill $p_ 2>/dev/null; wait $p_ 2>/dev/null; PART_=0; return 1; fi
set -f
set -- $(ls -ln "$w_" 2>/dev/null); set +f; PART_=${5:-0}; case "$PART_" in *[!0-9]*) PART_=0 ;; esac; jw
done
wait $p_ || { rm -f "$w_"; PART_=0; return 1; }
PART_=0
else
$CP "$s_" "$w_" 2>/dev/null || { rm -f "$w_"; return 1; }
fi
touch -r "$s_" "$w_" 2>/dev/null
mv -f "$w_" "$d_" 2>/dev/null || { rm -f "$w_"; return 1; }
BY=$((BY + z_)); DONE=$((DONE + 1)); tick; return 0
}
cpitem() {
local s=$1 d=$2 f r
stopped && return 2
if [ -L "$s" ]; then [ -e "$d" ] || [ -L "$d" ] || cp -P "$s" "$d" 2>/dev/null; DONE=$((DONE + 1)); return 0
elif [ -d "$s" ]; then
mkdir -p "$d" && [ ! -L "$d" ] || return 1
for f in "$s"/* "$s"/.[!.]* "$s"/..?*; do
[ -e "$f" ] || [ -L "$f" ] || continue
cpitem "$f" "$d/${f##*/}"; r=$?; [ $r = 0 ] || { FAIL=${FAIL:-$f}; return $r; }
done
touch -r "$s" "$d" 2>/dev/null; return 0
elif [ -f "$s" ]; then cpfile "$s" "$d" || { r=$?; FAIL=$s; return $r; }
fi
return 0
}
jw

case "$OP" in
copy|move|backup)
spd "$DISK" "${$}@$J/$ID.stop"
[ -n "$DROOT" ] && ! mounted "$DROOT" && finish err "Disco staccato durante il lavoro" "Drive removed during the job"
[ "$MK" = 1 ] && [ ! -e "$DST" ] && [ ! -L "$DST" ] && ownadd "$DST"
[ "$MK" = 1 ] && { mkdir -p "$DST" || finish err "Cartella di arrivo non creata" "Destination folder not created"; }
[ -d "$DST" ] || finish err "Cartella di arrivo non trovata" "Destination folder not found"
DSTR=$(rp "$DST"); DRR=$(rp "${DROOT:-$DST}")
case "$DSTR/" in "$DRR"/*) ;; *) finish err "Cartella di arrivo non valida" "Invalid destination folder" ;; esac
rec "op=$OP" "disk=$DISK" "to_disk=$TOD" "dst=$DST" "droot=$DROOT" "drel=$DREL" "t=$T0"
i=0
while [ $i -lt $N ]; do
i=$((i + 1)); eval "S=\$S$i"; nm=${S##*/}; D=$DST/$nm; KN=
stopped && finish stop
[ -n "$DROOT" ] && ! mounted "$DROOT" && finish err "Disco staccato durante il lavoro" "Drive removed during the job"
[ "$(rp "$DST")" = "$DSTR" ] || finish err "Cartella di arrivo cambiata durante il lavoro" "Destination folder changed during the job"
[ -e "$S" ] || [ -L "$S" ] || continue
SL=0; [ -L "$S" ] && SL=1; SPR=$(rp "${S%/*}")
if [ -e "$D" ] || [ -L "$D" ]; then
askq "$nm"
eval "NRI=\${NR$i:-0}"; [ "$ANS" = replace ] && [ "$NRI" = 1 ] && ANS=keep
case "$ANS" in
stop) finish stop ;;
skip) continue ;;
keep) uniqn "$DST" "$nm"; D=$DST/$UN; [ -n "$OWN" ] && [ "$OWN" != admin ] && KN=$DREL/$UN ;;
replace) [ "$D" = "$S" ] && continue; [ "$(rp "$DST")" = "$DSTR" ] || cperr "$D"; tovers "$DROOT" "$DREL/$nm" || totrash "$D" "$DROOT" "$DREL/$nm" || cperr "$D" ;;
esac
fi
if [ "$OP" = move ] && [ "$SAME" = 1 ]; then
FILE=$nm; [ "$(rp "${S%/*}")" = "$SPR" ] || cperr "$S"; mv "$S" "$D" || cperr "$S"; DONE=$((DONE + 1)); tick
else
FAIL=; cpitem "$S" "$D"; r=$?
[ $r = 2 ] && { [ ! -L "$D" ] && rm -rf "$D"; finish stop; }
[ $r = 0 ] || { [ -d "$S" ] && [ ! -L "$S" ] && [ ! -L "$D" ] && rm -rf "$D"; cperr "${FAIL:-$S}"; }
if [ "$OP" = move ]; then
[ "$(rp "${S%/*}")" = "$SPR" ] || cperr "$S"
if [ -L "$S" ]; then rm -f "$S"; elif [ $SL = 0 ]; then rm -rf "$S"; fi
fi
fi
[ -n "$KN" ] && printf '%s\n' "$KN" >> $J/$ID.kn
ownadd "$D"
done
FILE=; jw; $SY -f "$DST" 2>/dev/null || $SY
finish ok ;;
delete)
i=0
while [ $i -lt $N ]; do
i=$((i + 1)); eval "S=\$S$i; RL=\$R$i"; FILE=${S##*/}
stopped && finish stop
[ -e "$S" ] || [ -L "$S" ] || { DONE=$((DONE + 1)); continue; }
RR=$(rp "$ROOT"); [ -n "$RR" ] || { DROOT=$ROOT; cperr "$S"; }
case "$(rp "${S%/*}")/" in "$RR"/*) ;; *) DROOT=$ROOT; cperr "$S" ;; esac
totrash "$S" "$ROOT" "$RL" || { DROOT=$ROOT; cperr "$S"; }
DONE=$((DONE + 1)); jw
done
finish ok ;;
check)
TOT=3; FILE=$NAME
if ! cktool "$FS"; then
RES=missing
[ -n "$CKP" ] || finish err "Questo tipo di disco non si può controllare" "This drive type cannot be checked"
finish err "Manca il programma di controllo: installa $CKP" "The check tool is missing: install $CKP"
fi
reopen && finish err "Il router sta ricollegando i dischi: riprova tra poco" "The router is reconnecting the drives: try again shortly"
savemnt "$MNTS"; svcstop "$SVC"
umountall "$MNTS" || ferr "Disco in uso: chiudi i file aperti e riprova" "Drive in use: close open files and try again"
DONE=1; jw
CB=$(wbase "${DEV#/dev/}")
case "$FS" in
ext2|ext3|ext4) dw "$CB" 0 "$CK" -fy "$DEV" >/dev/null 2>&1 </dev/null ;;
fat32) dw "$CB" 0 "$CK" -a "$DEV" >/dev/null 2>&1 </dev/null ;;
exfat) dw "$CB" 0 "$CK" -y "$DEV" >/dev/null 2>&1 </dev/null ;;
ntfs) dw "$CB" 0 "$CK" "$DEV" >/dev/null 2>&1 </dev/null ;;
esac
rc=$?; FIXOK=
[ -n "$DWX" ] && { rm -f "$MSAVE"; MSAVE=; finish err "Disco staccato durante il controllo" "Drive removed during the check"; }
if [ "$FS" = ntfs ]; then case "$rc" in 0) RES=clean; FIXOK=1 ;; 127) RES=missing ;; *) RES=errors ;; esac
else case "$rc" in 0) RES=clean ;; 1|2|3) RES=fixed ;; 127) RES=missing ;; *) RES=errors ;; esac; fi
DONE=2; jw
if [ -s "$MSAVE" ]; then remountall || finish err "Disco non rimontato: staccalo e riattaccalo" "Drive not remounted: unplug it and plug it back in"
else rm -f "$MSAVE"; [ "$RM" = 1 ] && [ -n "$MNT" ] && mnt1 "$DEV" "$MNT" "$KT" ""; fi
svcstart
case "$RES" in
missing) finish err "Manca il programma di controllo per questo disco" "The check tool for this drive is missing" ;;
errors) finish err "Errori non riparati: fai un backup" "Errors not repaired: back up the drive" ;;
esac
finish ok ;;
format)
TOT=4; FILE=$NAME
reopen && finish err "Il router sta ricollegando i dischi: riprova tra poco" "The router is reconnecting the drives: try again shortly"
savemnt "$MNTS"; WASM=; [ -s "$MSAVE" ] && WASM=1; svcstop "$SVC"
umountall "$MNTS" || ferr "Disco in uso: chiudi i file aperti e riprova" "Drive in use: close open files and try again"
DONE=1; jw
rec "op=format" "disk=$DISK" "base=$BASE" "model=$MODEL" "size=$BSIZE" "name=$NAME" "t=$T0"
FB=$(wbase "$BASE"); FB=${FB:-$(wbase "$PART")}
fgone() { wiped "/dev/$BASE"; wiped "/dev/$PART"; rm -f "$MSAVE"; MSAVE=; rm -f "$R/blk.json"
finish err "Disco staccato durante la formattazione" "Drive removed during formatting"; }
hung "$FB" && fgone
if [ "$WHOLE" = 1 ]; then
ty=83; [ "$FS" = exfat ] && ty=7
wiped "/dev/$BASE"
gb_=$(cat "$SYS/class/block/$BASE/size" 2>/dev/null); gb_=${gb_:-0}
if [ "$gb_" -gt 4294967295 ] 2>/dev/null; then
gt_=L; [ "$FS" = exfat ] && gt_=EBD0A0A2-B9E5-4433-87C0-68B6B72699C7
printf 'label: gpt\ntype=%s\n' "$gt_" > "$J/$ID.sf"
else printf 'type=%s\n' "$ty" > "$J/$ID.sf"; fi
dw "$FB" 120 sh -c 'sfdisk -q --wipe always "$1" < "$2"' _ "/dev/$BASE" "$J/$ID.sf" >/dev/null 2>&1; r_=$?; [ -n "$DWX" ] && fgone
[ $r_ = 0 ] || { dw "$FB" 120 sh -c 'sfdisk -q "$1" < "$2"' _ "/dev/$BASE" "$J/$ID.sf" >/dev/null 2>&1; r_=$?; [ -n "$DWX" ] && fgone; }
rm -f "$J/$ID.sf"
[ $r_ = 0 ] || { wiped "/dev/$BASE"; ferr "Partizione non creata. Disco da preparare di nuovo" "Partition not created. Drive must be prepared again"; }
i=0; while [ ! -b "/dev/$PART" ] && [ $i -lt 10 ]; do sleep 1; i=$((i + 1)); done
fi
DONE=2; jw
[ "$WHOLE" = 1 ] || wiped "/dev/$PART"
if [ "$FS" = ext4 ]; then dw "$FB" 0 mkfs.ext4 -F -q -m 1 -L "$LABEL" "/dev/$PART" >/dev/null 2>&1 </dev/null
else dw "$FB" 0 mkfs.exfat -L "$LABEL" "/dev/$PART" >/dev/null 2>&1 </dev/null || { [ -z "$DWX" ] && dw "$FB" 0 mkexfatfs -n "$LABEL" "/dev/$PART" >/dev/null 2>&1 </dev/null; }; fi
r_=$?; [ -n "$DWX" ] && fgone
[ $r_ = 0 ] || [ "$(lnk "$FB")" != '?' ] || fgone
[ $r_ = 0 ] || { if [ "$WHOLE" = 1 ]; then wiped "/dev/$BASE"; else wiped "/dev/$PART"; fi
ferr "Disco non preparato. Disco da preparare di nuovo" "Drive not prepared. Drive must be prepared again"; }
DONE=3; jw
if [ "$WHOLE" = 1 ]; then : > "$MSAVE"; else grep -v "^$DEV	" "$MSAVE" > "$MSAVE.t" 2>/dev/null; mv -f "$MSAVE.t" "$MSAVE"; fi
NOK=; remountall || NOK=1
{ [ "$RM" = 1 ] || [ -n "$WASM" ]; } && { mnt1 "/dev/$PART" "$MNT" "$FS" "" || NOK=1; }
dw "$FB" 10 block info "/dev/$PART" > "$J/$ID.bi" 2>/dev/null </dev/null
u=$(sed -n 's/.* UUID="\([^"]*\)".*/\1/p' "$J/$ID.bi" 2>/dev/null | tr -cd 'A-Za-z0-9-'); rm -f "$J/$ID.bi"
[ -n "$u" ] && printf '%s\n%s\n' "$NAME" "$DISK" > "$R/rename.$u"
rm -f "$R/blk.json"; svcstart
[ -n "$NOK" ] && finish err "Disco preparato, ma non rimontato: staccalo e riattaccalo" "Drive prepared, but not remounted: unplug it and plug it back in"
finish ok ;;
*) finish err "Lavoro non valido" "Invalid job" ;;
esac
