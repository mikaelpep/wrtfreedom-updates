#!/bin/sh
umask 022
D=$(cd "$(dirname "$0")" && pwd)
say() { echo "## $*"; }
[ -f /etc/openwrt_release ] || { say "ERRORE questo non è un router OpenWrt"; exit 1; }
PM=
command -v apk >/dev/null 2>&1 && PM=apk
[ -z "$PM" ] && command -v opkg >/dev/null 2>&1 && PM=opkg
LK=/tmp/wf-install.lock
if ! mkdir $LK 2>/dev/null; then
a_=$(( $(date +%s) - $(date -r $LK +%s 2>/dev/null || date +%s) ))
{ [ $a_ -gt 600 ] && rm -rf $LK && mkdir $LK 2>/dev/null; } || { say "ERRORE un'altra installazione di WrtFreedom è in corso: riprova tra poco"; exit 3; }
fi
trap 'rmdir $LK 2>/dev/null' EXIT
trap 'exit 1' HUP INT TERM

U=; [ -d /overlay/upper ] && U=/overlay/upper
SPF=$(df -kP /overlay 2>/dev/null | awk 'NR==2{print $4}'); [ -n "$SPF" ] || SPF=$(df -kP / 2>/dev/null | awk 'NR==2{print $4}')
SPN=$(du -sk "$D" 2>/dev/null | cut -f1); SPO=$(du -sk $U/usr/share/wrtfreedom $U/www/wrtfreedom $U/usr/share/rpcd/ucode/wrtfreedom.uc 2>/dev/null | awk '{s+=$1} END{print s+0}')
SPD=$(( ${SPN:-0} - SPO )); [ $SPD -lt 0 ] && SPD=0
case "$(awk '$2=="/overlay"{o=$3} $2=="/"{r=$3} END{print o?o:r}' /proc/mounts 2>/dev/null)" in jffs2|ubifs) SPD=$((SPD / 2)) ;; esac
SPS=$((SPD + ${SPN:-0} / 2 + 512))
case "$SPF" in ''|*[!0-9]*) ;; *) [ "$SPF" -lt "$SPS" ] && { say "ERRORE spazio insufficiente sul router: servono $SPS KB liberi, ce ne sono $SPF. Niente è cambiato: libera spazio (Software: togli i pacchetti che non usi) e riprova"; exit 6; } ;; esac

need=
[ -e /usr/lib/rpcd/ucode.so ] || need="$need rpcd-mod-ucode"
[ -e /usr/lib/rpcd/file.so ] || need="$need rpcd-mod-file"
[ -e /usr/lib/uhttpd_ubus.so ] || need="$need uhttpd-mod-ubus"
[ -x /usr/libexec/cgi-io ] || need="$need cgi-io"
[ -x /usr/bin/ucode ] || need="$need ucode"
if [ -n "$need" ]; then
say "Installo i componenti mancanti:$need"
case "$PM" in
apk) apk update >/dev/null 2>&1; apk add $need ;;
opkg) opkg update >/dev/null 2>&1; opkg install $need ;;
*) say "ERRORE nessun gestore pacchetti (apk o opkg)"; exit 2 ;;
esac || { say "ERRORE componenti non installati: il router è collegato a internet?"; exit 3; }
fi

if ! command -v usign >/dev/null 2>&1; then
case "$PM" in apk) apk add usign >/dev/null 2>&1 ;; opkg) opkg install usign >/dev/null 2>&1 || { opkg update >/dev/null 2>&1; opkg install usign >/dev/null 2>&1; } ;; esac
fi

say "Copio i file"
mkdir -p /usr/share/rpcd/ucode /usr/share/rpcd/acl.d /usr/share/wrtfreedom /etc/wrtfreedom || exit 4
acp() {
eval "a_=\${$#}"; n_=$#
while [ $n_ -gt 1 ]; do
s_=$1; t_=$a_; [ -d "$a_" ] && t_=${a_%/}/${s_##*/}
cp "$s_" "$t_.new" && mv -f "$t_.new" "$t_" || { rm -f "$t_.new"; return 1; }
shift; n_=$((n_ - 1))
done
}
acp "$D/wrtfreedom.uc" /usr/share/rpcd/ucode/wrtfreedom.uc &&
acp "$D/wrtfreedom.json" /usr/share/rpcd/acl.d/wrtfreedom.json &&
acp "$D/uninstall.sh" "$D/adgsetup.sh" "$D/cakeinst.sh" "$D/cakedel.sh" "$D/sqmline.sh" "$D/sqmlive.sh" "$D/at.sh" "$D/notify.sh" "$D/event.sh" "$D/tgbot.uc" "$D/tgpresets.sh" "$D/watchdog.sh" "$D/cron.sh" "$D/lib.sh" "$D/ucfg.uc" "$D/backup.sh" "$D/bakenc.uc" "$D/sms.uc" "$D/usage.uc" "$D/ussd.uc" "$D/sighist.uc" "$D/sigfast.uc" "$D/slow.sh" "$D/sim.uc" "$D/cbs.uc" "$D/fwstat.uc" "$D/wifi.uc" "$D/dev.uc" "$D/netx.uc" "$D/adgmode.sh" "$D/oui.txt" "$D/line.sh" "$D/bb.sh" "$D/tgq.uc" "$D/vpnctl.uc" "$D/wgx.uc" "$D/svc.uc" "$D/health.uc" "$D/custode.uc" "$D/fastck.uc" "$D/tick.uc" "$D/mem.uc" "$D/riordina.uc" "$D/speed.uc" "$D/assist.uc" "$D/ai.uc" "$D/sqmctl.sh" "$D/sqm.uc" "$D/pia-ca.crt" "$D/modem.uc" "$D/same.uc" "$D/modemctl.uc" "$D/nas.uc" "$D/nasjob.sh" "$D/naspeed.uc" "$D/nasu.uc" "$D/nasvc.uc" "$D/nasvc.sh" "$D/nasx.uc" "$D/nasx.sh" "$D/nasf.uc" "$D/nasf.sh" "$D/nasdl.uc" "$D/nasdl.sh" "$D/nasrec.uc" "$D/nasrec.sh" "$D/nasbk.uc" "$D/nasbk.sh" "$D/nastipi.uc" "$D/cloud.uc" "$D/cloud.sh" "$D/cloudline.sh" "$D/cloudx.sh" "$D/cloudcr.sh" "$D/cloudmnt.sh" "$D/fwupd.uc" "$D/upd.sh" "$D/wrtfreedom-upd.pub" "$D/VERSION" "$D/MINAPP" /usr/share/wrtfreedom/ && rm -f /usr/share/wrtfreedom/tgbot.sh /usr/share/wrtfreedom/failover.sh /tmp/wf-tg.needs || { say "ERRORE copia non riuscita (spazio pieno?)"; exit 4; }
printf '%s\n' '#!/bin/sh' 'exec /bin/sh /usr/share/wrtfreedom/cloudmnt.sh dfree "$@"' > /usr/share/wrtfreedom/nasdfree && chmod 755 /usr/share/wrtfreedom/nasdfree || { say "ERRORE copia non riuscita (spazio pieno?)"; exit 4; }
if [ -d /root/.wf-cloud-cache ]; then
if command -v setsid >/dev/null 2>&1; then setsid sh /usr/share/wrtfreedom/cloudmnt.sh check </dev/null >/dev/null 2>&1 &
elif command -v start-stop-daemon >/dev/null 2>&1; then start-stop-daemon -S -b -x /bin/sh -- /usr/share/wrtfreedom/cloudmnt.sh check </dev/null >/dev/null 2>&1
else ( sh /usr/share/wrtfreedom/cloudmnt.sh check ) </dev/null >/dev/null 2>&1 &
fi
fi
mkdir -p /usr/share/wrtfreedom/custode && acp "$D/custode/funzioni.json" /usr/share/wrtfreedom/custode/funzioni.json || { say "ERRORE copia non riuscita (spazio pieno?)"; exit 4; }
acp "$D/custode/memoria.json" /usr/share/wrtfreedom/custode/memoria.json || { say "ERRORE copia non riuscita (spazio pieno?)"; exit 4; }
cpfail() { say "ERRORE copia non riuscita (spazio pieno?)"; exit 4; }
mkdir -p /usr/libexec/rpcd && acp "$D/wrtfreedom.wait" /usr/libexec/rpcd/wrtfreedom.wait && chmod 755 /usr/libexec/rpcd/wrtfreedom.wait || cpfail
mkdir -p /www/cgi-bin && acp "$D/wf-live.cgi" /www/cgi-bin/wf-live && chmod 755 /www/cgi-bin/wf-live || cpfail
acp "$D/wf-me.cgi" /www/cgi-bin/wf-me && chmod 755 /www/cgi-bin/wf-me || cpfail
acp "$D/wf-ai.cgi" /www/cgi-bin/wf-ai && chmod 755 /www/cgi-bin/wf-ai || cpfail
acp "$D/nasx.cgi" /www/cgi-bin/wf-nasx && chmod 755 /www/cgi-bin/wf-nasx && ln -sf /www/cgi-bin/wf-nasx /usr/share/wrtfreedom/nasx.cgi || cpfail
if [ ! -e /www/nas ] || grep -qs 'wf-nas-alias' /www/nas/index.html; then
{ mkdir -p /www/nas && printf '%s\n' '<!DOCTYPE html><!-- wf-nas-alias --><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><meta http-equiv="refresh" content="0;url=/wrtfreedom/#nas"><title>NAS</title></head><body><a href="/wrtfreedom/#nas">NAS</a></body></html>' > /www/nas/index.html && chmod -R a+rX /www/nas; } || cpfail
fi
if [ ! -e /www/pc ] || grep -qs 'wf-pc-alias' /www/pc/index.html; then
{ mkdir -p /www/pc && printf '%s\n' '<!DOCTYPE html><!-- wf-pc-alias --><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><meta http-equiv="refresh" content="0;url=/cgi-bin/wf-nasx/pc"><title>NAS</title><script>location.replace("/cgi-bin/wf-nasx/pc"+location.search)</script></head><body><a href="/cgi-bin/wf-nasx/pc">NAS</a></body></html>' > /www/pc/index.html && chmod -R a+rX /www/pc; } || cpfail
fi
if [ -f "$D/nasdns.sh" ]; then acp "$D/nasdns.sh" /usr/share/wrtfreedom/nasdns.sh || cpfail; fi
if [ -f /etc/exports ] && grep -qx '# wf-nas begin' /etc/exports; then
sed -i '/^# wf-nas begin$/,/^# wf-nas end$/d' /etc/exports
command -v exportfs >/dev/null 2>&1 && exportfs -ra >/dev/null 2>&1
fi
chmod 700 /etc/wrtfreedom
if [ -d "$D/www" ]; then { rm -rf /www/wrtfreedom && mkdir -p /www/wrtfreedom && cp -r "$D/www/." /www/wrtfreedom/ && chmod -R a+rX /www/wrtfreedom; } || cpfail; fi
T=/usr/share/ucode/luci/template/themes
if [ -f $T/bootstrap/header.ut ] && [ -d /www/luci-static/bootstrap ]; then
mkdir -p $T/wrtfreedom && cp "$D/luci-header.ut" $T/wrtfreedom/header.ut && cp "$D/luci-footer.ut" $T/wrtfreedom/footer.ut && cp "$D/luci-sysauth.ut" $T/wrtfreedom/sysauth.ut && chmod 644 $T/wrtfreedom/*.ut
ln -sfn bootstrap /www/luci-static/wrtfreedom; uci set luci.themes.WrtFreedom=/luci-static/wrtfreedom; uci commit luci
fi
acp "$D/wrtfreedom.init" /etc/init.d/wrtfreedom && chmod 755 /etc/init.d/wrtfreedom || cpfail
[ -f /etc/config/wrtfreedom ] || touch /etc/config/wrtfreedom
chmod 600 /etc/config/wrtfreedom
uci -q get wrtfreedom.wd >/dev/null || { uci set wrtfreedom.wd=watchdog; uci set wrtfreedom.wd.enabled=0; }
uci -q get wrtfreedom.wd.inet >/dev/null || uci set wrtfreedom.wd.inet=0
uci -q get wrtfreedom.wd.lastres >/dev/null || uci set wrtfreedom.wd.lastres=1
uci -q get wrtfreedom.lock >/dev/null || uci set wrtfreedom.lock=celllock
uci -q get wrtfreedom.modem >/dev/null || uci set wrtfreedom.modem=modem
uci -q get wrtfreedom.upd >/dev/null || { uci set wrtfreedom.upd=update; uci set wrtfreedom.upd.check=1; }
uci -q get wrtfreedom.guest >/dev/null || uci set wrtfreedom.guest=guest
uci -q get wrtfreedom.wifichan >/dev/null || uci set wrtfreedom.wifichan=wifichan
if [ "$(uci -q get wrtfreedom.ev.fwcat)" != 1 ]; then
uci -q get wrtfreedom.ev >/dev/null || uci set wrtfreedom.ev=ev
nc_=$(uci -q get wrtfreedom.ev.notify)
[ "$(uci -q get wrtfreedom.fw.tg)" = 0 ] || case " $nc_ " in *" fw "*) ;; *) uci set wrtfreedom.ev.notify="${nc_:+$nc_ }fw" ;; esac
qp_=$(uci -q get wrtfreedom.ev.qpass)
case " $qp_ " in *" fw "*) ;; *" net "*) uci set wrtfreedom.ev.qpass="$qp_ fw" ;; esac
uci set wrtfreedom.ev.fwcat=1
fi
if [ "$(uci -q get wrtfreedom.ev.cucat)" != 1 ]; then
uci -q get wrtfreedom.ev >/dev/null || uci set wrtfreedom.ev=ev
nc_=$(uci -q get wrtfreedom.ev.notify)
case " $nc_ " in *" custode "*) ;; *" sys "*) uci set wrtfreedom.ev.notify="$nc_ custode" ;; esac
qp_=$(uci -q get wrtfreedom.ev.qpass)
case " $qp_ " in *" custode "*) ;; *" sys "*) uci set wrtfreedom.ev.qpass="$qp_ custode" ;; esac
uci set wrtfreedom.ev.cucat=1
fi
if [ "$(uci -q get wrtfreedom.ev.nascat)" != 1 ]; then
uci -q get wrtfreedom.ev >/dev/null || uci set wrtfreedom.ev=ev
nc_=$(uci -q get wrtfreedom.ev.notify)
case " $nc_ " in *" nas "*) ;; *" usb "*) uci set wrtfreedom.ev.notify="$nc_ nas" ;; esac
qp_=$(uci -q get wrtfreedom.ev.qpass)
case " $qp_ " in *" nas "*) ;; *" usb "*) uci set wrtfreedom.ev.qpass="$qp_ nas" ;; esac
uci set wrtfreedom.ev.nascat=1
fi
if [ "$(uci -q get wrtfreedom.ev.cloudcat)" != 1 ]; then
uci -q get wrtfreedom.ev >/dev/null || uci set wrtfreedom.ev=ev
nc_=$(uci -q get wrtfreedom.ev.notify)
case " $nc_ " in *" cloud "*) ;; *" nas "*|*" nas! "*) uci set wrtfreedom.ev.notify="$nc_ cloud" ;; esac
qp_=$(uci -q get wrtfreedom.ev.qpass)
case " $qp_ " in *" cloud "*) ;; *" nas "*) uci set wrtfreedom.ev.qpass="$qp_ cloud" ;; esac
uci set wrtfreedom.ev.cloudcat=1
fi
nr_=0; g_="[ \"\$(jsonfilter -i /etc/wrtfreedom/nas.json -e '@.on' 2>/dev/null)\" = true ] && sh /usr/share/wrtfreedom"
for l in "*/5 * * * * sh /usr/share/wrtfreedom/nasvc.sh tick # wf:nas" "*/5 * * * * $g_/nasbk.sh tick # wf:nasbk" "*/5 * * * * $g_/nasrec.sh tick # wf:nasrec" "*/10 * * * * $g_/nasf.sh night # wf:nasf" "2-59/5 * * * * sh /usr/share/wrtfreedom/cloud.sh tick # wf:cloud"; do
grep -qsxF "$l" /etc/crontabs/root && continue
t_=${l##* # wf:}; grep -v " # wf:$t_\$" /etc/crontabs/root > /etc/crontabs/root.wf 2>/dev/null; echo "$l" >> /etc/crontabs/root.wf && mv /etc/crontabs/root.wf /etc/crontabs/root; nr_=1
done
[ $nr_ = 1 ] && /etc/init.d/cron restart >/dev/null 2>&1
case " $(uci -q get wrtfreedom.tg.preset) " in *" rimuovi "*)
uci -q del_list wrtfreedom.tg.preset=rimuovi
case " $(uci -q get wrtfreedom.tg.preset) " in *" espelli "*) ;; *) uci add_list wrtfreedom.tg.preset=espelli ;; esac ;;
esac
for f in /etc/wrtfreedom/nas-bak/b*.sh; do
[ -f "$f" ] && grep -q "^AT='[0-9]" "$f" && ! grep -q '^TIME=' "$f" && { sed -i "s/^AT=\('[0-9:]*'\)$/TIME=\1/" "$f" && echo "AT=''" >> "$f"; }
done
rm -rf /tmp/wf-nas/x/thumb /tmp/wf-nas/x/thumb.list /tmp/wf-nas/x/thumb.work
[ -f /etc/wrtfreedom/nas-rec.sh ] && sed -i 's/^REC_ON=1$/REC_ON=0/' /etc/wrtfreedom/nas-rec.sh
for f in /etc/wrtfreedom/nas-dl-ok.sh /etc/wrtfreedom/nas-dl-err.sh /etc/init.d/wf-nasdl; do
[ -f "$f" ] && sed -i -e 's#/usr/share/wrtfreedom/nasvc\.sh dldone#/usr/share/wrtfreedom/nasdl.sh dldone#' -e 's#/usr/share/wrtfreedom/nasvc\.sh dlprep#/usr/share/wrtfreedom/nasdl.sh dlprep#' "$f"
done
uci -q delete wrtfreedom.vpnout.al_fb
uci commit wrtfreedom
WF_WR=$(sh "$D/lib.sh" inact on 2>/dev/null)
H=/etc/hotplug.d/dhcp/90-wrtfreedom
if [ -x /etc/init.d/dnsmasq ] && command -v dnsmasq >/dev/null 2>&1; then
new=0; [ -f $H ] && grep -q wf-dhcpvc $H || new=1
mkdir -p /etc/hotplug.d/dhcp
cat > $H <<'EOF'
#!/bin/sh
# WrtFreedom: classe del fornitore DHCP (tipo del dispositivo, 2.49)
case "$ACTION" in add|old) ;; *) exit 0 ;; esac
[ -n "$DNSMASQ_VENDOR_CLASS" ] && [ -n "$MACADDR" ] || exit 0
F=/tmp/wf-dhcpvc; m=$(echo "$MACADDR" | tr 'A-F' 'a-f'); v=$(printf '%s' "$DNSMASQ_VENDOR_CLASS" | tr -cd 'A-Za-z0-9 ._:+-' | cut -c1-60)
grep -qxF "$m $v" $F 2>/dev/null && exit 0
{ grep -v "^$m " $F 2>/dev/null | tail -n 300; echo "$m $v"; } > $F.t && mv $F.t $F
EOF
[ $new = 1 ] && /etc/init.d/dnsmasq restart >/dev/null 2>&1
else
rm -f $H
fi
for s in iface usb block button ntp; do
case $s in
iface) c='[ "$INTERFACE" != loopback ] && case "$INTERFACE" in wgout) false;; wgo|wgo*[!0-9]*) true;; wgo*) false;; *) true;; esac && { [ "$ACTION" = ifup ] || [ "$ACTION" = ifdown ] || { [ "$ACTION" = ifupdate ] && [ "$IFUPDATE_ADDRESSES" = 1 ]; }; }' ;;
usb) c='[ "$DEVTYPE" = usb_device ] && { [ "$ACTION" = add ] || [ "$ACTION" = remove ]; }' ;;
block) c='case "$DEVNAME" in sd*[0-9]|sd[a-z]|sd[a-z][a-z]|mmcblk*p[0-9]*|nvme*p[0-9]*) true;; *) false;; esac && { [ "$ACTION" = add ] || [ "$ACTION" = remove ]; }' ;;
button) c='[ -n "$BUTTON" ] && { [ "$ACTION" = pressed ] || [ "$ACTION" = released ]; }' ;;
ntp) c='[ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ]' ;;
esac
mkdir -p /etc/hotplug.d/$s
{ printf '#!/bin/sh\n# WrtFreedom: registro eventi\nif %s && [ -f /usr/share/wrtfreedom/event.sh ]; then sh /usr/share/wrtfreedom/event.sh %s >/dev/null 2>&1 & fi\n' "$c" $s
if [ $s = iface ]; then printf '%s\n' '# WrtFreedom 3.42: nome nas.home.arpa rifatto al cambio dell'"'"'IP di casa' 'if [ -f /etc/wrtfreedom/nasdns.json ] && [ -f /usr/share/wrtfreedom/nasdns.sh ] && { [ "$ACTION" = ifup ] || { [ "$ACTION" = ifupdate ] && [ "$IFUPDATE_ADDRESSES" = 1 ]; }; }; then sh /usr/share/wrtfreedom/nasdns.sh check </dev/null >/dev/null 2>&1 & fi'
printf '%s\n' '# WrtFreedom: servizi della linea fermi ripartono quando internet sale' 'if [ "$ACTION" = ifup ] && [ -f /usr/share/wrtfreedom/cron.sh ]; then sh /usr/share/wrtfreedom/cron.sh wanup "$INTERFACE" </dev/null >/dev/null 2>&1 & fi'; fi
} > /etc/hotplug.d/$s/90-wrtfreedom
done
mkdir -p /etc/hotplug.d/acme
cat > /etc/hotplug.d/acme/91-wrtfreedom <<'EOF'
#!/bin/sh
# WrtFreedom: Rinnovo Dei Certificati (2.66), evento e Registro a ogni rilascio o rinnovo di acme; 3.22: causa vera di un
# rinnovo non riuscito
case "$ACTION" in
	issued|renewed) [ -f /usr/share/wrtfreedom/cron.sh ] && sh /usr/share/wrtfreedom/cron.sh certok "$main_domain" "$ACTION" >/dev/null 2>&1 </dev/null & ;;
	*-failed) [ -f /usr/share/wrtfreedom/cron.sh ] && sh /usr/share/wrtfreedom/cron.sh certerr "$main_domain" >/dev/null 2>&1 </dev/null & ;;
esac
EOF
L="/www/wrtfreedom/ /usr/share/ucode/luci/template/themes/wrtfreedom/ /www/luci-static/wrtfreedom /usr/share/rpcd/ucode/wrtfreedom.uc /usr/libexec/rpcd/wrtfreedom.wait /www/cgi-bin/wf-live /www/cgi-bin/wf-me /www/cgi-bin/wf-ai /usr/share/rpcd/acl.d/wrtfreedom.json /usr/share/wrtfreedom/ /etc/wrtfreedom/ /etc/config/wrtfreedom /etc/init.d/wrtfreedom /etc/init.d/wrtfreedom-ai /etc/init.d/wf-nasdav /etc/init.d/wf-nasdl /etc/init.d/wf-nasx /etc/init.d/wf-nasftp /etc/init.d/wf-nasdisc /etc/init.d/wf-phwatch /etc/avahi/services/wfnas.service /www/cgi-bin/wf-nasx /etc/hotplug.d/iface/90-wrtfreedom /etc/hotplug.d/dhcp/90-wrtfreedom /etc/hotplug.d/usb/90-wrtfreedom /etc/hotplug.d/block/90-wrtfreedom /etc/hotplug.d/button/90-wrtfreedom /etc/hotplug.d/ntp/90-wrtfreedom /etc/hotplug.d/acme/90-wrtfreedom /etc/hotplug.d/acme/91-wrtfreedom /etc/uci-defaults/99-wrtfreedom"
awk -v L="$L" '{ s[$0] = 1 } END { n = split(L, a, " "); for (i = 1; i <= n; i++) if (!(a[i] in s)) print a[i] }' /etc/sysupgrade.conf >> /etc/sysupgrade.conf
mkdir -p /lib/upgrade/keep.d && printf '/etc/wrtfreedom/\n/etc/config/wrtfreedom\n/etc/uci-defaults/99-wrtfreedom\n' > /lib/upgrade/keep.d/wrtfreedom
sh /usr/share/wrtfreedom/cron.sh adgkeep >/dev/null 2>&1 </dev/null
mkdir -p /etc/uci-defaults
cat > /etc/uci-defaults/99-wrtfreedom <<'EOF'
# WrtFreedom (2.85): ritorno dopo un aggiornamento del firmware (scritto da install.sh, tolto da uninstall.sh)
# 3.11 (prova in VM, n. 10): servizi di serie dei pacchetti del NAS (lighttpd che al riavvio prende la porta 80 di uhttpd,
# aria2, secondo server SMB…) spenti e tolti dall'avvio a ogni accensione, qui prima che partano (solo con il NAS usato,
# nas.json; mai quelli con impostazioni dell'utente: nasvc.uc spare). Al massimo 30 s, poi l'avvio va avanti
# 3.23 (guasto dell'11/11): prima, a ogni avvio, la regola della porta 80 (lib.sh port80): lighttpd di serie messo per il
# NAS e abilitato da solo spento prima che parta, così non fa a gara con uhttpd per la porta 80 dell'app
[ -f /usr/share/wrtfreedom/lib.sh ] && sh /usr/share/wrtfreedom/lib.sh port80 </dev/null >/dev/null 2>&1
# 3.34: memoria del router (mem.uc boot, solo file e uci): recinti del pacchetto e tetto di Go di AdGuard Home prima che
# partano i servizi
[ -f /usr/share/wrtfreedom/mem.uc ] && ucode /usr/share/wrtfreedom/mem.uc boot </dev/null >/dev/null 2>&1
if [ -f /etc/wrtfreedom/nas.json ] && [ -f /usr/share/wrtfreedom/nasvc.sh ]; then
	TO_=; command -v timeout >/dev/null 2>&1 && TO_="timeout 30"
	$TO_ sh /usr/share/wrtfreedom/nasvc.sh spare </dev/null >/dev/null 2>&1
fi
C=/etc/wrtfreedom/pacchetto.tgz; Q=/etc/wrtfreedom/pacchetto.ver
# 13/11 (spazio): senza un ritorno in attesa la riga di keep.d della copia prima del firmware (fwflash con «Mantieni») non
# serve più: tolta qui, così le copie dopo non se la portano dentro (con il ritorno la toglie upd.sh ritorno alla fine)
KC=/lib/upgrade/keep.d/wrtfreedom-copia
[ -s $C ] && [ -s $Q ] || { rm -f $KC; exit 1; }
PV=; PF=; { read -r PV; read -r PF; } < $Q
FV=$(. /etc/openwrt_release 2>/dev/null; echo "$DISTRIB_RELEASE $DISTRIB_REVISION")
# niente da fare: stesso firmware della copia, file di WrtFreedom al loro posto alla stessa versione e servizio abilitato
[ "$PF" = "$FV" ] && [ -f /usr/share/rpcd/ucode/wrtfreedom.uc ] && [ -x /etc/init.d/wrtfreedom ] &&
	[ "$(cat /usr/share/wrtfreedom/VERSION 2>/dev/null)" = "$PV" ] && ls /etc/rc.d/S*wrtfreedom >/dev/null 2>&1 && { rm -f $KC; exit 1; }
T=/tmp/wf-ritorno; rm -rf $T; mkdir -p $T && tar xzf $C -C $T 2>/dev/null && cp $T/upd.sh /tmp/wf-ritorno.sh || exit 1
( sh /tmp/wf-ritorno.sh ritorno $T ) </dev/null >/dev/null 2>&1 &
exit 1
EOF

if [ -z "$(uci -q get uhttpd.main.ubus_prefix)" ]; then
say "Attivo ubus sul server web"
mkdir -p /etc/wrtfreedom && touch /etc/wrtfreedom/ubus_prefix.wf
uci set uhttpd.main.ubus_prefix='/ubus' && uci commit uhttpd && /etc/init.d/uhttpd restart
fi

rpcd_restart() { /etc/init.d/rpcd stop; i=0; while pidof rpcd >/dev/null && [ $i -lt 5 ]; do sleep 1; i=$((i+1)); done
for p in $(pidof rpcd); do kill -9 $p 2>/dev/null; done; /etc/init.d/rpcd start; }
say "Riavvio rpcd"
rpcd_restart
i=0; while [ $i -lt 10 ]; do ubus list wrtfreedom >/dev/null 2>&1 && break; sleep 1; i=$((i+1)); done
rm -f /tmp/.wf-wpsclean
ucode /usr/share/wrtfreedom/mem.uc boot </dev/null >/dev/null 2>&1
/etc/init.d/wrtfreedom enable; /etc/init.d/wrtfreedom restart
[ -f /etc/wrtfreedom/nas.json ] && ubus -t 30 call wrtfreedom nas_users '{"act":"get"}' </dev/null >/dev/null 2>&1
[ -f /usr/share/wrtfreedom/nasdns.sh ] && ( sh /usr/share/wrtfreedom/nasdns.sh on ) </dev/null >/dev/null 2>&1 &
cat > /etc/init.d/wrtfreedom-ai <<'EOF'
#!/bin/sh /etc/rc.common
# WrtFreedom: Assistente IA sempre acceso (2.64), solo con l'Assistente acceso; senza, i lavori partono come processi a parte
START=99
STOP=10
USE_PROCD=1
start_service() {
	[ "$(uci -q get wrtfreedom.ai.on)" = 1 ] && [ -f /usr/share/wrtfreedom/ai.uc ] || return 0
	# moduli di ucode per l'attesa degli eventi e le chiamate dirette
	[ -e /usr/lib/ucode/uloop.so ] && [ -e /usr/lib/ucode/ubus.so ] || return 0
	procd_open_instance
	# umask 077 come i lavori lanciati da rpcd (file propri leggibili solo da root)
	procd_set_param command /bin/sh -c 'umask 077; exec /usr/bin/ucode /usr/share/wrtfreedom/ai.uc serve'
	# riavvio dopo 5 s senza un tetto di tentativi: le uscite volute (memoria oltre 12 MB, Ferma, servizio bloccato) non lo
	# fermano mai; niente ricarica a ogni cambio di configurazione (ucciderebbe le risposte in corso: lo spegnimento lo fa tick)
	procd_set_param respawn 300 5 0
	procd_close_instance
}
EOF
chmod 755 /etc/init.d/wrtfreedom-ai
if [ "$(uci -q get wrtfreedom.ai.on)" = 1 ]; then /etc/init.d/wrtfreedom-ai enable; /etc/init.d/wrtfreedom-ai restart
else /etc/init.d/wrtfreedom-ai stop >/dev/null 2>&1; /etc/init.d/wrtfreedom-ai disable; fi
if uci -q show wrtfreedom 2>/dev/null | grep -q '=vpntun$' && ubus call wrtfreedom vpnout '{"action":"migrate"}' 2>/dev/null | grep -q '"confirm"'; then
( sleep 25; ping -c 2 -W 3 1.1.1.1 >/dev/null 2>&1 || ping -c 2 -W 3 8.8.8.8 >/dev/null 2>&1 && ubus call wrtfreedom vpnout '{"action":"confirm"}' >/dev/null 2>&1 ) </dev/null >/dev/null 2>&1 &
fi
( sh /usr/share/wrtfreedom/cron.sh align ) >/dev/null 2>&1 </dev/null &
[ "$WF_WR" = 1 ] && ( sleep 10; wifi reload ) >/dev/null 2>&1 </dev/null &
[ -f /etc/wrtfreedom/svc.txt ] || { ls /etc/init.d; echo --; ls /etc/rc.d; } 2>/dev/null | awk '$0 == "--" { r = 1; next } !r { o[++n] = $0; next } /^S[0-9]/ { sub(/^S[0-9]+/, ""); e[$0] = 1 } END { for (i = 1; i <= n; i++) print o[i], ((o[i] in e) ? 1 : 0) }' > /etc/wrtfreedom/svc.txt
sh /usr/share/wrtfreedom/lib.sh port80 >/dev/null 2>&1 </dev/null
( sh /usr/share/wrtfreedom/nasvc.sh spare ) >/dev/null 2>&1 </dev/null &
( WF_CLOUDUC=/usr/share/wrtfreedom/cloud.uc sh /usr/share/wrtfreedom/cloud.sh migrate ) >/dev/null 2>&1 </dev/null &
[ -f /etc/wrtfreedom/pkgs.txt ] || { if command -v apk >/dev/null 2>&1; then cat /etc/apk/world; else awk '/^Package:/{p=$2} /^Status:.*user installed/{print p}' /usr/lib/opkg/status; fi 2>/dev/null | sort -u > /etc/wrtfreedom/pkgs.txt; }
if [ -d /tmp/wf-cloud/mnt ] && [ ! -d /root/.wf-cloud-cache ]; then
if command -v setsid >/dev/null 2>&1; then setsid sh /usr/share/wrtfreedom/cloudmnt.sh check </dev/null >/dev/null 2>&1 &
elif command -v start-stop-daemon >/dev/null 2>&1; then start-stop-daemon -S -b -x /bin/sh -- /usr/share/wrtfreedom/cloudmnt.sh check </dev/null >/dev/null 2>&1
else ( sh /usr/share/wrtfreedom/cloudmnt.sh check ) </dev/null >/dev/null 2>&1 &
fi
fi
if ubus list wrtfreedom >/dev/null 2>&1; then say "OK $(cat /usr/share/wrtfreedom/VERSION)"; else say "ERRORE il servizio wrtfreedom non si avvia"; logread | grep -iE 'rpcd|ucode' | tail -n 5; exit 5; fi
WC=/etc/wrtfreedom/pacchetto
WS=$(cd "$D" && find . -type f -exec sha256sum {} + 2>/dev/null | sort | sha256sum | cut -d' ' -f1)
WOK=0
if [ -n "$WS" ] && [ -f $WC.tgz ] && [ "$(cat $WC.sum 2>/dev/null)" = "$WS" ]; then WOK=1
elif tar czf $WC.tgz.t -C "$D" . 2>/dev/null && mv -f $WC.tgz.t $WC.tgz; then
WOK=1; if [ -n "$WS" ]; then echo "$WS" > $WC.sum; else rm -f $WC.sum; fi
else rm -f $WC.tgz.t; say "ATTENZIONE copia per il ritorno dopo il firmware non salvata (spazio pieno?)"
fi
if [ $WOK = 1 ]; then
printf '%s\n%s\n' "$(cat /usr/share/wrtfreedom/VERSION)" "$(. /etc/openwrt_release 2>/dev/null; echo "$DISTRIB_RELEASE $DISTRIB_REVISION")" > /tmp/wf-copia.ver
cmp -s /tmp/wf-copia.ver $WC.ver || cp /tmp/wf-copia.ver $WC.ver
fi
rm -f /tmp/wf-copia.tgz /tmp/wf-copia.ver
rm -rf "$D" /tmp/wf-pkg.tgz
