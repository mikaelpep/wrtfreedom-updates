'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, readlink, open } from 'fs';

const SYS = getenv('WF_SYS') ?? '/sys', MOUNTS = getenv('WF_MOUNTS') ?? '/proc/mounts', PROC = getenv('WF_PROC') ?? '/proc';
const RUN = '/tmp/wf-nas', JOBS = RUN + '/jobs', ETC = getenv('WF_NASETC') ?? '/etc/wrtfreedom', NASJ = ETC + '/nas.json';
const TRASH = '.wf-trash';
const JOB = getenv('WF_NASJOB') ?? '/usr/share/wrtfreedom/nasjob.sh', INITD = getenv('WF_INITD') ?? '/etc/init.d/';
const CFGD = getenv('WF_CFGDIR') ?? '/etc/config/', EVSH = getenv('WF_EVENTSH') ?? '/usr/share/wrtfreedom/event.sh';
const FATMAX = 4294967295, RDMAX = 524288, WALKMAX = +(getenv('WF_WALKMAX') ?? 20000) || 20000;
const BKDIR = 'Backup';
const SVCDEF = [ 'ksmbd', 'samba4', 'minidlna', 'wf-nasdav', 'wf-nasdl', 'aria2' ];
const PKGS = [ 'kmod-usb-storage', 'kmod-usb-storage-uas', 'block-mount', 'kmod-fs-ext4', 'kmod-fs-exfat', 'kmod-fs-ntfs3',
'kmod-fs-vfat', 'smartmontools', 'e2fsprogs', 'dosfstools', 'exfat-mkfs', 'exfat-fsck', 'ntfs-3g-utils', 'hd-idle', 'ksmbd-server', 'samba4-server',
'minidlna', 'aria2', 'openssh-sftp-server', 'lighttpd-mod-webdav', 'rsync', 'avahi-nodbus-daemon',
'rclone', 'ca-bundle', 'lighttpd', 'lighttpd-mod-cgi', 'vsftpd',
'sqlite3-cli', 'ucode-mod-socket', 'lighttpd-mod-openssl',
'inotifywait',
'libjpeg-turbo-utils', 'ffmpeg' ];
const PKGNTFS3G = 'ntfs-3g';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function bg(c) { sh('( ' + c + ' ) >/dev/null 2>&1 </dev/null &'); }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function rj(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function uniq(a) { let r = []; for (let x in a) if (index(r, x) < 0) push(r, x); return r; }
const ME = readlink('/proc/self') ?? 'x';
function wjr(f, o) { let t = f + '.t' + ME; writefile(t, sprintf('%J', o)); rename(t, f); }
function mkdirp(p) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c); } }
function lockon(d, age, ms) {
mkdirp(RUN);
for (let i = 0, w = 0; i < 200; i++) {
if (mkdir(d)) { writefile(d + '/pid', ME); return true; }
let p = trim(readfile(d + '/pid') ?? ''), s = stat(d);
if (!s) continue;
if ((match(p, /^[0-9]+$/) && !stat('/proc/' + p)) || time() - s.mtime > age) { unlink(d + '/pid'); rmdir(d); continue; }
if (w >= ms) return false;
sleep(50); w += 50;
}
return false;
}
function lockoff(d) { if (trim(readfile(d + '/pid') ?? '') == ME) { unlink(d + '/pid'); rmdir(d); } }
function locked(d, age) {
let p = trim(readfile(d + '/pid') ?? ''), s = stat(d);
return s != null && time() - s.mtime <= age && (!match(p, /^[0-9]+$/) || p == ME || stat('/proc/' + p) != null);
}
function bgwait(c, f, ms) {
unlink(f);
bg('( ' + c + ' ) > ' + q(f + '.t') + ' 2>/dev/null; mv -f ' + q(f + '.t') + ' ' + q(f));
for (let w = 0; w < ms; w += 100) { sleep(100); if (stat(f)) return trim(readfile(f) ?? ''); }
return null;
}
function bin(n) {
for (let d in [ getenv('WF_NASBIN'), '/usr/sbin', '/usr/bin', '/sbin', '/bin' ]) if (d && has(d + '/' + n)) return d + '/' + n;
return null;
}

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
const uval = UCFG.uvalq;
function cfg(n) { return UCFG.parse(readfile(CFGD + n) ?? '', false, uval); }
function nascfg() { let o = rj(NASJ); return type(o) == 'object' ? o : {}; }
const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function nasput(fn) { return UCFG.njset(nascfg, fn, (o) => { mkdirp(ETC); wjr(NASJ, o); }); }
function nbusy() { return { error: 'Impostazioni occupate: riprova', error_en: 'Settings busy: try again', code: 'busy' }; }
const SPM = [ 'auto', 'prudente', 'media', 'massima' ], SPOLD = { normale: 'media', veloce: 'massima' };
function spnew(m) { return SPOLD[m] ?? m; }
function spmode(o) { let m = spnew(o?.speed_mode); return index(SPM, m) > 0 ? m : 'auto'; }
function L(it, en) { return cfg('wrtfreedom').ui?.lang == 'en' ? en : it; }
function fmtnm(v) { return lc(trim(replace(replace(trim('' + (v ?? '')), /\s+/g, ' '), /\.+$/, ''))); }
function fmtok(c, D) { c = trim('' + (c ?? '')); return length(c) > 0 && (c == D.id || (fmtnm(c) != '' && fmtnm(c) == fmtnm(D.name))); }
function err(it, en, x) { let r = { error: it, error_en: en }; for (let k, v in x ?? {}) r[k] = v; return r; }
function gb(b) { let g = b / 1073741824.0; return g >= 10 ? int(g + 0.5) + ' GB' : replace(sprintf('%.1f', g), '.', L(',', '.')) + ' GB'; }
function cutn(s, n) { s = '' + s; if (length(s) <= n) return s; while (n > 0 && (ord(s, n) & 192) == 128) n--; return substr(s, 0, n); }

function baseof(d) {
let m = match(d, /^(nvme[0-9]+n[0-9]+|mmcblk[0-9]+)p[0-9]+$/);
if (m) return m[1];
m = match(d, /^((s|h|v|xv)d[a-z]+)[0-9]+$/);
return m ? m[1] : d;
}
function virt(d) { return !!match(d, /^(mtdblock|mtd|ubi|loop|zram|ram|dm-|sr|fd|nbd)/); }
function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
function mounts() {
let r = [];
for (let l in split(readfile(MOUNTS) ?? '', '\n')) {
let x = split(l, ' ');
if (length(x) < 4) continue;
push(r, { dev: x[0], mnt: unoct(x[1]), fs: x[2], ro: index(split(x[3], ','), 'ro') >= 0, opts: x[3] });
}
return r;
}
function sysr(p) { return trim(readfile(SYS + p) ?? ''); }
const NBLK = getenv('WF_NASBLK') ?? '/usr/share/wrtfreedom/nasjob.sh';
function blkold() {
let f = RUN + '/blk.json', t = stat(f)?.mtime;
if (t == null) return;
for (let n in lsdir(JOBS) ?? []) {
if (!match(n, /\.json$/) || (stat(JOBS + '/' + n)?.mtime ?? 0) < t || rj(JOBS + '/' + n)?.op != 'format') continue;
unlink(f);
return;
}
}
function blkinfo(M) { blkold(); return UCFG.blkinfo(M, { sys: SYS, run: RUN, sh: (c) => sh(has(NBLK) ? 'sh ' + q(NBLK) + ' blk 2>/dev/null </dev/null' : c), rj, wjr, bin, mkdirp }); }
const fsname = UCFG.fsname;
function statvfsf() { let f = null; try { f = getenv('WF_NOSTATVFS') ? null : require('fs').statvfs; } catch (e) { f = null; } return f; }
function dfall(P) {
let r = {};
if (!length(P) || statvfsf()) return r;
for (let l in split(sh('df -kP ' + join(' ', map(P, (p) => q(p))) + ' 2>/dev/null'), '\n')) {
let x = split(trim(l), /[ \t]+/);
if (length(x) < 6 || !match(x[1] ?? '', /^[0-9]+$/)) continue;
r[join(' ', slice(x, 5))] = { size: +x[1] * 1024, used: +x[2] * 1024, free: +x[3] * 1024 };
}
return r;
}
function vfs(p, DF) { return DF?.[p] ?? UCFG.vfs(p, null, statvfsf(), sh, q); }
const PCWARN = 90, PCFULL = 98, HOTC = 55;
function usbport(b) {
let l = readlink(SYS + '/class/block/' + b);
if (!l || index(l, '/usb') < 0) return null;
let r = null;
for (let x in split(l, '/')) if (match(x, /^[0-9]+-[0-9.]+$/)) r = x;
return r;
}
function hung(b) {
let f = RUN + '/hung/' + b, h = readfile(f);
if (h == null) return false;
if (trim(h) == (readlink(SYS + '/class/block/' + b) ?? '?')) return true;
unlink(f);
return false;
}
function lnkbad(b, t) {
if (hung(b)) return true;
let p = usbport(b);
if (!p) return false;
for (let id, o in rj(RUN + '/usb.json')?.ids ?? {}) if (o?.port == p) for (let x in o.list ?? []) if (!x.test && x.t >= t - 600 && x.t <= t + 120) return true;
return false;
}
function smartof(b) {
let f = RUN + '/smart/' + b + '.json', s = rj(f), w = (it, en) => ({ it: it, en: en });
let ts = +trim(readfile(RUN + '/smart/' + b + '.test') ?? '0') || null;
if (!s || s.na === true) {
let pk = !bin('smartctl'), hg = !pk && hung(b);
return { ok: null, temp: null, hours: null, bad: null, at: null, k: pk ? 'pkg' : 'na', why: pk ? w('Da installare', 'To install') : hg ? w('Il disco non risponde', 'The drive does not respond') :
s?.z ? w('Disco a riposo, letto al risveglio', 'Drive asleep, read when it wakes') : w('Il disco non dà la salute', 'The drive does not report its health'),
realloc: null, pend: null, unc: null, crc: null, via: null, test_ok: false, test: null, lk: hg };
}
let A = s.ata_smart_attributes?.table, N = s.nvme_smart_health_information_log;
let raw = (id) => { if (type(A) != 'array') return null; for (let a in A) if (a.id == id) return +(a.raw?.value ?? 0); return null; };
let re = raw(5), pe = raw(197), un = raw(198), cr = raw(199), bad = null;
if (type(A) == 'array') bad = (re ?? 0) + (pe ?? 0) + (un ?? 0);
else if (N) bad = +(N.media_errors ?? 0);
let ok = s.smart_status ? !!s.smart_status.passed : null, temp = s.temperature?.current ?? N?.temperature ?? null;
let st = s.ata_smart_data?.self_test?.status, T0 = s.ata_smart_self_test_log?.standard?.table?.[0] ?? s.nvme_self_test_log?.table?.[0], test = null;
let NS = s.nvme_self_test_log, nop = +(NS?.current_self_test_operation?.value ?? 0);
if (st && (+(st.value ?? 0) >> 4) == 15) test = { res: 'run', t: ts, pct: st.remaining_percent ?? null };
else if (nop != 0) test = { res: 'run', t: ts, pct: NS.current_self_test_completion_percent != null ? 100 - +NS.current_self_test_completion_percent : null };
else if (T0) test = { res: (T0.status?.passed ?? (+(T0.status?.value ?? 0) == 0)) ? 'ok' : 'fail', t: ts, pct: null };
else if (ts) test = { res: time() - ts < 1800 ? 'run' : null, t: ts, pct: null };
let k = 'ok', why = w('Nessun segno di guasto', 'No signs of failure');
if (ok === false) { k = 'bad'; why = w('Test S.M.A.R.T. non superato', 'S.M.A.R.T. check failed'); }
else if ((re ?? 0) > 0) { k = 'warn'; why = w('Settori riallocati: ' + re, 'Reallocated sectors: ' + re); }
else if ((pe ?? 0) > 0) { k = 'warn'; why = w('Settori in attesa: ' + pe, 'Pending sectors: ' + pe); }
else if ((un ?? 0) > 0 || (N && bad > 0)) { k = 'warn'; why = w('Errori di lettura: ' + (un ?? bad), 'Read errors: ' + (un ?? bad)); }
else if (temp != null && temp >= HOTC) { k = 'warn'; why = w('Temperatura alta: ' + temp + ' °C', 'High temperature: ' + temp + ' °C'); }
else if (test?.res == 'fail') { k = 'warn'; why = w('Ultimo test non riuscito', 'Last test failed'); }
let at = stat(f)?.mtime ?? time(), lk = false;
if (ok !== false && ((re ?? 0) > 0 || (pe ?? 0) > 0 || (un ?? 0) > 0 || (N && bad > 0)) && lnkbad(b, at)) {
lk = true; k = 'warn'; why = w('Problemi di collegamento USB', 'USB connection problems');
}
else if (hung(b)) { lk = true; if (k == 'ok') { k = 'warn'; why = w('Il disco non risponde', 'The drive does not respond'); } }
let cap = s.ata_smart_data?.capabilities;
return { ok: ok, temp: temp, hours: s.power_on_time?.hours ?? N?.power_on_hours ?? null, bad: bad, at: stat(f)?.mtime ?? null, k: k, why: why,
realloc: re, pend: pe, unc: un, crc: cr, via: s.device?.type ?? null,
test_ok: cap ? cap.self_tests_supported === true : (N ? s.nvme_self_test_log != null || +(s.nvme_controller_capabilities?.self_test ?? 0) > 0 : false), test: test, lk: lk };
}
function usbmax(b) {
let l = readlink(SYS + '/class/block/' + b);
if (!l || index(l, '/usb') < 0) return null;
let m = match(l, /\/(usb[0-9]+)\//);
if (!m) return null;
let s = trim(readfile(SYS + '/bus/usb/devices/' + m[1] + '/speed') ?? '');
if (!length(s)) return null;
let v = +s;
return v >= 20000 ? '3.2' : v >= 10000 ? '3.1' : v >= 5000 ? '3.0' : v >= 480 ? '2.0' : v > 0 ? '1.1' : null;
}
function usbver(b) {
let l = readlink(SYS + '/class/block/' + b);
if (!l || index(l, '/usb') < 0) return null;
let P = substr(l, 0, 1) == '/' ? [] : split(SYS + '/class/block', '/');
for (let x in split(l, '/')) { if (x == '..') pop(P); else if (length(x) && x != '.') push(P, x); }
for (let i = 0; i < 24 && length(P) > 1; i++) {
let n = P[length(P) - 1];
if (match(n, /^[0-9]+-[0-9.]+$/) || match(n, /^usb[0-9]+$/)) {
let s = trim(readfile(join('/', P) + '/speed') ?? '');
if (length(s)) { let v = +s; return v >= 20000 ? '3.2' : v >= 10000 ? '3.1' : v >= 5000 ? '3.0' : v >= 480 ? '2.0' : v > 0 ? '1.1' : null; }
}
pop(P);
}
return null;
}
function usbpwr(b) {
let l = readlink(SYS + '/class/block/' + b);
if (!l || index(l, '/usb') < 0) return null;
let P = substr(l, 0, 1) == '/' ? [] : split(SYS + '/class/block', '/');
for (let x in split(l, '/')) { if (x == '..') pop(P); else if (length(x) && x != '.') push(P, x); }
let dev = false, r = false;
for (let i = 0; i < 24 && length(P) > 1; i++) {
let n = P[length(P) - 1];
if (match(n, /^usb[0-9]+$/)) return dev ? r : null;
if (match(n, /^[0-9]+-[0-9.]+$/)) {
if (!dev) dev = true;
else {
let p = join('/', P), rm = trim(readfile(p + '/removable') ?? ''), v = hex(trim(readfile(p + '/bmAttributes') ?? ''));
if (rm == 'removable') { if (v != v) r = null; else if (v & 0x40) return true; }
else if (!length(rm) && v == v && (v & 0x40)) r = null;
}
}
pop(P);
}
return null;
}
function iostat(B) {
let P = rj(RUN + '/io.json') ?? {}, N = {}, D = {}, t = time(), r = 0, w = 0;
for (let b in uniq(B)) {
let x = split(trim(readfile(SYS + '/class/block/' + b + '/stat') ?? ''), /[ \t]+/);
if (length(x) < 7) continue;
let rs = +x[2] * 512, ws = +x[6] * 512, p = P[b], chg = t, dr = 0, dw = 0;
if (p) {
if (p.r == rs && p.w == ws) chg = p.chg;
let dt = t - p.t;
if (dt > 0 && dt < 120) { dr = (rs - p.r) / dt; dw = (ws - p.w) / dt; r += dr; w += dw; }
}
D[b] = { r: dr < 0 ? 0 : int(dr), w: dw < 0 ? 0 : int(dw) };
N[b] = { t: p && t - p.t < 2 ? p.t : t, r: p && t - p.t < 2 ? p.r : rs, w: p && t - p.t < 2 ? p.w : ws, chg: chg,
wk: p && chg != p.chg && p.chg != null && chg - p.chg >= 120 ? [ chg, chg - p.chg ] : p?.wk ?? null };
}
mkdirp(RUN);
wjr(RUN + '/io.json', N);
return { r: r < 0 ? 0 : int(r), w: w < 0 ? 0 : int(w), N: N, D: D };
}
const SPACEJ = RUN + '/space.json';
function disks(live) {
let M = mounts(), BI = blkinfo(M), C = lsdir(SYS + '/class/block') ?? [], sysd = {}, names = nascfg().disks ?? {}, R = [], members = {};
let SC = rj(SPACEJ) ?? {}, SN = {};
for (let m in M) if (index([ '/', '/rom', '/overlay', '/boot', '/boot/efi' ], m.mnt) >= 0 && substr(m.dev, 0, 5) == '/dev/') sysd[baseof(substr(m.dev, 5))] = 1;
let mmc = (b) => substr(b, 0, 6) == 'mmcblk' && sysr('/class/block/' + b + '/device/type') == 'MMC';
let ok = (d) => { let b = baseof(d); return !virt(d) && !sysd[b] && !mmc(b) && !match(d, /^mmcblk[0-9]+(boot|rpmb)/); };
let mnt = {};
for (let m in M) if (substr(m.dev, 0, 5) == '/dev/') { let d = substr(m.dev, 5); if (!mnt[d]) mnt[d] = m; }
let parts = {};
for (let d in C) if (d != baseof(d) || match(d, /^md[0-9]+$/)) parts[baseof(d)] = 1;
let blank = (b) => {
if (index(readlink(SYS + '/class/block/' + b) ?? '', '/usb') < 0 || hung(b)) return false;
for (let p in C) if (p != b && baseof(p) == b && (mnt[p] || length(BI[p]?.TYPE ?? ''))) return false;
return true;
};
let devs = [];
for (let d in C) {
if (!ok(d)) continue;
if (!mnt[d] && +sysr('/class/block/' + d + '/size') == 0) continue;
let I = BI[d] ?? {}, T = I.TYPE ?? (mnt[d]?.fs ?? '');
if (T == 'linux_raid_member') { members[baseof(d)] = 1; continue; }
if (T == 'swap' || T == 'squashfs' || T == 'ubifs' || T == 'jffs2') continue;
if (d == baseof(d) && !match(d, /^md[0-9]+$/) && parts[d] && !length(T) && !blank(d)) continue;
if (d != baseof(d) && !length(T) && !mnt[d]) continue;
push(devs, d);
}
let DF = {};
if (!statvfsf()) {
let P = [];
for (let d in devs) {
let m = mnt[d], u = lc(replace((BI[d] ?? {}).UUID ?? '', /[^A-Za-z0-9-]/g, '')), c = SC[length(u) ? u : d];
if (m && (live || type(c) != 'object' || c.mnt != m.mnt)) push(P, m.mnt);
}
DF = dfall(P);
}
for (let d in sort(devs)) {
let I = BI[d] ?? {}, m = mnt[d], b = baseof(d), u = lc(replace(I.UUID ?? '', /[^A-Za-z0-9-]/g, ''));
let id = length(u) ? u : d, c = SC[id], v = !m ? { size: +sysr('/class/block/' + d + '/size') * 512, used: null, free: null } :
!live && type(c) == 'object' && c.mnt == m.mnt ? { size: c.size, used: c.used, free: c.free } : vfs(m.mnt, DF);
if (m) SN[id] = { mnt: m.mnt, size: v.size, used: v.used, free: v.free };
let model = trim(sysr('/class/block/' + b + '/device/vendor') + ' ' + sysr('/class/block/' + b + '/device/model'));
push(R, { id: id, name: names[id]?.name ?? (length(I.LABEL) ? I.LABEL : (length(model) ? model : d)), dev: d, base: b,
label: I.LABEL ?? '', uuid: I.UUID ?? '', fs: fsname(m?.fs == 'fuseblk' && length(I.TYPE ?? '') ? I.TYPE : (m?.fs ?? I.TYPE)), ktype: m?.fs ?? '', mnt: m?.mnt ?? '', mounted: !!m,
size: v.size, used: v.used, free: v.free, ro: m ? m.ro : false, usb: index(readlink(SYS + '/class/block/' + b) ?? '', '/usb') >= 0,
md: !!match(b, /^md[0-9]+$/), model: model, opts: m?.opts ?? '' });
let st = names[id]?.ro, x = R[length(R) - 1];
x.lock = type(st) == 'bool' ? st : x.fs == 'ntfs';
x.new = type(names[id]) != 'object';
x.removable = sysr('/block/' + b + '/removable') == '1';
if (d == b && parts[d] && !length(I.TYPE ?? '') && !m) x.blank = true;
}
let BG = {};
for (let x in R) if (x.fs == 'btrfs' && length(x.uuid)) { if (!BG[x.id]) BG[x.id] = []; push(BG[x.id], x); }
for (let id, G in BG) {
if (length(G) < 2) continue;
let dv = lsdir(SYS + '/fs/btrfs/' + lc(G[0].uuid) + '/devices'), K = dv ? filter(G, (x) => index(dv, x.dev) >= 0) : G;
if (length(K) < 2) continue;
let keep = filter(K, (x) => x.mounted)[0] ?? K[0];
for (let x in K) if (x !== keep) { members[x.base] = 1; x.gone = true; }
}
R = filter(R, (x) => !x.gone);
let ni = {}, nn = {};
for (let x in R) { ni[x.id] = (ni[x.id] ?? 0) + 1; nn[x.name] = (nn[x.name] ?? 0) + 1; }
for (let x in R) { x.dup = ni[x.id] > 1; x.same_name = nn[x.name] > 1; }
if (live && sprintf('%J', SN) != sprintf('%J', SC)) { mkdirp(RUN); wjr(SPACEJ, SN); }
return { list: R, members: members, M: M };
}
function fsec(D) { return 'wf_nas_' + replace(D.id, /[^A-Za-z0-9_]/g, '_'); }
function tgtof(D) {
let F = cfg('fstab')[fsec(D)], u = substr(lc(replace(D.uuid ?? '', /[^A-Za-z0-9]/g, '')), 0, 8);
if (F && F.uuid == D.uuid && length(F.target ?? '')) return F.target;
if (length(D.mnt) && D.mnt != '/mnt/' + D.dev) return D.mnt;
return length(u) ? '/mnt/wf-' + u : '/mnt/' + D.dev;
}
function wantop(D, ro) { return (ro ? 'ro' : 'rw') + (D.fs == 'fat32' ? ',utf8,umask=0000' : (match(D.fs ?? '', /^(ntfs|exfat)$/) ? ',iocharset=utf8,umask=0000' : '')); }
function oldmask(D) {
if (D.ro || !match(D.fs ?? '', /^(ntfs|exfat|fat32)$/)) return false;
for (let o in split(D.opts ?? '', ',')) if (match(o, /^(dmask|umask)=/)) return !match(o, /=0*$/);
return false;
}
function anonmount() { for (let s, o in cfg('fstab')) if (o['.type'] == 'global') return o.anon_mount == '1'; return false; }
function fstabcmd(D, on) {
let s = 'fstab.' + fsec(D), F = cfg('fstab')[fsec(D)];
if (!length(D.uuid)) return F ? 'uci -q delete ' + s + '; uci -q commit fstab; ' : '';
let en = on || anonmount() ? '1' : '0', tg = tgtof(D);
if (D.dup) return '';
for (let m in mounts()) if (m.mnt == tg && m.dev != '/dev/' + D.dev) return '';
let op = wantop(D, D.lock);
if (F && F.uuid == D.uuid && F.options == op && F.enabled == en && F.target == tg) return '';
return 'uci -q set ' + s + '=mount; uci -q set ' + s + '.uuid=' + q(D.uuid) + '; uci -q set ' + s + '.target=' + q(tg) +
'; uci -q set ' + s + '.options=' + q(op) + '; uci -q set ' + s + '.enabled=' + en + '; uci -q commit fstab; ' +
(!F && en == '1' && !D.mounted ? 'block mount >/dev/null 2>&1; ' : '');
}
const MOUNTC = getenv('WF_MOUNT') ?? 'mount', UMOUNTC = getenv('WF_UMOUNT') ?? 'umount';
function canmount() { return nascfg().on === true || anonmount() ? '1' : '0'; }
function remount(D, ro, ms) {
if (!D.mounted) return true;
mkdirp(RUN + '/remount');
let o = bgwait(MOUNTC + ' -o remount,' + (ro ? 'ro' : 'rw') + ' ' + q(D.mnt) + ' >/dev/null 2>&1 </dev/null && echo ok || echo no',
RUN + '/remount/' + replace(D.id, /[^A-Za-z0-9_-]/g, '_'), ms ?? 8000);
return o == null ? null : o == 'ok';
}
const MNTJ = RUN + '/mnt.json', NVSH = getenv('WF_NASVCSH') ?? '/usr/share/wrtfreedom/nasvc.sh', NASUC = getenv('WF_NASUC') ?? '/usr/share/wrtfreedom/nas.uc';
function mntsync(Ls) {
let M = {}, X = {};
for (let d in Ls ?? disks().list) if (d.mounted && !d.dup) X[d.id] = d.mnt;
for (let k in sort(keys(X))) M[k] = X[k];
let o = rj(MNTJ);
if (type(o) == 'object' && sprintf('%J', o) == sprintf('%J', M)) return false;
mkdirp(RUN);
wjr(MNTJ, M);
if (has(NVSH)) bg('sh ' + q(NVSH) + ' follow');
return true;
}
function fixable(D) { return D.mounted && !D.dup && !D.md && length(D.uuid ?? '') && length(D.ktype) && D.ktype != 'fuseblk'; }
function badcs(D) {
if (!fixable(D) || !match(D.fs ?? '', /^(ntfs|exfat|fat32)$/)) return false;
let O = split(D.opts ?? '', ',');
return index(O, 'iocharset=utf8') < 0 && index(O, 'utf8') < 0;
}
function needfix(D) {
if (!fixable(D)) return false;
let tg = tgtof(D);
if (badcs(D)) return true;
if (oldmask(D)) return true;
if (tg != D.mnt) { for (let m in mounts()) if (m.mnt == tg) return false; return true; }
return false;
}
function fixcmd(D, ro) {
let tg = tgtof(D), to = bin('timeout') ? 'timeout 20 ' : '', up = 'grep -q ' + q('^/dev/' + D.dev + ' ') + ' ' + q(MOUNTS);
let O = split(D.opts ?? '', ','), op = wantop(D, ro) + (!ro && index(O, 'force') >= 0 ? ',force' : ''), dv = q('/dev/' + D.dev);
let back = length(D.opts ?? '') ? '{ mkdir -p ' + q(D.mnt) + '; ' + to + MOUNTC + ' -t ' + q(D.ktype) + ' -o ' + q(D.opts) + ' ' + dv + ' ' + q(D.mnt) + ' >/dev/null 2>&1 </dev/null; }; ' : '';
return to + UMOUNTC + ' ' + q(D.mnt) + ' >/dev/null 2>&1 </dev/null && { mkdir -p ' + q(tg) + '; ' + to + MOUNTC + ' -t ' + q(D.ktype) + ' -o ' + q(op) +
' ' + dv + ' ' + q(tg) + ' >/dev/null 2>&1 </dev/null || block mount >/dev/null 2>&1 </dev/null; ' + up + ' || { rmdir ' + q(tg) + ' 2>/dev/null; ' + back + '}; ' +
(tg != D.mnt ? up + ' && rmdir ' + q(D.mnt) + ' 2>/dev/null; ' : '') + '}; ucode -e ' + q('loadfile(' + sprintf('%J', NASUC) + ')().mntsync();') + ' >/dev/null 2>&1 </dev/null; ';
}
function seen(L, tick) {
let S = rj(RUN + '/seen.json') ?? {}, t = time(), ch = false, N = {}, K = {};
for (let d in L) { N[d.id] = { since: S[d.id]?.since ?? t, name: d.name, mnt: d.mnt, base: d.base }; if (!S[d.id] || S[d.id].miss) ch = true; }
for (let k, o in S) {
if (N[k]) continue;
let m = (o.miss ?? 0) + (tick ? 1 : 0);
if (m < 2) K[k] = { ...o, miss: m };
if (tick) ch = true;
}
if (ch) { mkdirp(RUN); wjr(RUN + '/seen.json', { ...K, ...N }); }
return { old: S, now: N };
}
function sleepcfg() {
let c = nascfg().sleep, set = type(c) == 'object';
if (!set) c = {};
let m = type(c.mins) == 'int' && c.mins >= 0 ? c.mins : 15, hh = (v) => match('' + (v ?? ''), /^([01][0-9]|2[0-3]):00$/) ? v : null;
let f = hh(c.from), t = hh(c.to);
if (f == null || t == null || f == t) { f = null; t = null; }
return { mins: m, keep: c.keep === true, from: f, to: t, set: set };
}
function cronhours(f, t) {
if (f == null || t == null) return '*';
let a = +substr(f, 0, 2), b = +substr(t, 0, 2) - 1;
if (b < 0) b = 23;
if (a <= b) return a == b ? '' + a : a + '-' + b;
return (a == 23 ? '23' : a + '-23') + ',' + (b == 0 ? '0' : '0-' + b);
}
function keepnow(c) {
if (!c.keep) return false;
if (c.from == null) return true;
let h = localtime().hour, a = +substr(c.from, 0, 2), b = +substr(c.to, 0, 2);
return a < b ? h >= a && h < b : h >= a || h < b;
}
function kall(c) { return c.keep && c.from == null; }
function idleb(Ls) { return uniq(map(filter(Ls, (d) => !d.md && trim(readfile(SYS + '/block/' + d.base + '/removable') ?? '') != '1'), (d) => d.base)); }
function hdidle(Ls, m, k) {
if (!bin('hd-idle')) return;
let B = idleb(Ls), c = '';
for (let s, o in cfg('hd-idle')) if (substr(s, 0, 6) == 'wfnas_') c += 'uci -q delete hd-idle.' + s + '; ';
for (let b in B) {
let s = 'hd-idle.wfnas_' + replace(b, /[^A-Za-z0-9_]/g, '_');
c += 'uci -q set ' + s + '=hd-idle; uci -q set ' + s + '.disk=' + q(b) + '; uci -q set ' + s + '.enabled=' + (m > 0 && !k ? '1' : '0') +
'; uci -q set ' + s + '.idle_time_unit=minutes; uci -q set ' + s + '.idle_time_interval=' + (m > 0 ? m : 15) + '; ';
}
mkdirp(RUN);
writefile(RUN + '/hdidle', join(' ', sort(B)) + ' ' + m + ' ' + (k ? 1 : 0));
bg(c + 'uci -q commit hd-idle; ' + q(INITD + 'hd-idle') + ' enable; ' + q(INITD + 'hd-idle') + ' restart');
}
function smartbg(L) {
if (!bin('smartctl')) return;
let go = [];
for (let d in L) {
if (d.md || index(go, d.base) >= 0 || hung(d.base)) continue;
let f = RUN + '/smart/' + d.base + '.json', s = stat(f), a = s ? time() - s.mtime : 0, z = s ? +(rj(f)?.z ?? 0) : 0;
if (!s || a > 1800 || (a > 120 && z > 0 && z <= 3)) push(go, d.base);
}
if (length(go)) bg('for b in ' + join(' ', go) + '; do sh ' + q(JOB) + ' smart $b; done');
}
function renames() {
let N = {}, any = false, F = [];
for (let f in lsdir(RUN) ?? []) {
let m = match(f, /^rename\.([A-Za-z0-9-]+)$/);
if (!m) continue;
let a = split(readfile(RUN + '/' + f) ?? '', '\n'), n = trim(a[0] ?? ''), od = lc(trim(a[1] ?? ''));
if (length(n)) { N[lc(m[1])] = { name: n, old: match(od, /^[a-z0-9][a-z0-9-]{0,63}$/) && od != lc(m[1]) ? od : null }; any = true; }
push(F, f);
}
if (any && nasput((o) => {
if (type(o.disks) != 'object') o.disks = {};
for (let k, v in N) {
let p = v.old && type(o.disks[v.old]) == 'object' ? o.disks[v.old] : null;
o.disks[k] = p ? { ...p, name: v.name } : { name: v.name };
delete o.disks[k].gone;
if (p) delete o.disks[v.old];
}
}) == null) return;
for (let f in F) unlink(RUN + '/' + f);
}
function diskby(id) {
for (let d in disks().list) if (d.id == '' + id) return d;
return null;
}
function duperr() { return err('Due dischi hanno lo stesso UUID (disco clonato): stacca uno dei due', 'Two drives have the same UUID (cloned drive): unplug one of them', { code: 'dup' }); }

function badname(n) { return UCFG.badname(n); }
function dname(a) { return replace(a, /\/[^\/]*$/, ''); }

function newid() { return substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time()), /-/g, ''), 0, 12); }
function alive(p) { return match('' + p, /^[0-9]+$/) && has(PROC + '/' + p); }
function jobget(id) {
let j = rj(JOBS + '/' + id + '.json');
if (!j) return null;
return UCFG.jobchk(JOBS, id, j, alive, wjr);
}
function jobs() { return UCFG.joblist(JOBS, jobget); }
function jobpub(NC, j) {
let o = type(j?.own) == 'string' ? j.own : 'admin';
if (o == 'admin' || !length(o)) return j;
let v = type(NC?.users?.[o]) == 'object' && length(NC.users[o].vis ?? '') ? '' + NC.users[o].vis : o;
return { id: j.id, op: j.op, state: j.state, done: j.done ?? 0, total: j.total ?? 0, bytes: j.bytes ?? 0, bytes_total: j.bytes_total ?? 0,
t: j.t, t0: j.t0, t1: j.t1, disk: j.disk, to_disk: j.to_disk, own: o, own_name: v, name: v, file: '' };
}
function busy(id) {
for (let j in jobs()) if ((j.state == 'run' || j.state == 'ask') && (j.disk == id || j.to_disk == id)) return j;
return null;
}
function jobstart(op, disk, todisk, kv, src, total, btotal) {
mkdirp(JOBS);
let id = newid(), L = [ 'op=' + op, 'disk=' + disk, 'to_disk=' + (todisk ?? ''), 'total=' + (total ?? 0), 'bytes_total=' + (btotal ?? 0) ];
for (let k, v in kv) push(L, k + '=' + v);
for (let s in src ?? []) push(L, 'src=' + s.abs, 'rel=' + s.rel);
writefile(JOBS + '/' + id + '.in', join('\n', L) + '\n');
wjr(JOBS + '/' + id + '.json', { id: id, op: op, disk: disk, to_disk: todisk ?? '', done: 0, total: total ?? 0, bytes: 0, bytes_total: btotal ?? 0, file: '', state: 'run', t0: time(), t1: 0 });
bg('sh ' + q(JOB) + ' run ' + id);
return { job: id };
}
function walk(p, A) {
if (A.over) return;
let s = lstat(p);
if (!s) return;
if (++A.n > WALKMAX) { A.over = true; return; }
if (s.type == 'directory') { for (let e in lsdir(p) ?? []) walk(p + '/' + e, A); return; }
A.files++;
if (s.type == 'file') { A.bytes += s.size; if (s.size > FATMAX && length(A.big) < 20) push(A.big, p); }
}
function svclist(strict) {
let v = nascfg().inits;
if (type(v) != 'array') v = nascfg().ours;
if (type(v) != 'array') v = cfg('wrtfreedom').nas?.svc;
let L = type(v) == 'array' ? v : split(type(v) == 'string' ? v : '', /[ \t]+/), R = [];
for (let s in (length(join('', L)) || strict ? L : SVCDEF)) if (match(s, /^[A-Za-z0-9_.-]+$/) && has(INITD + s) && index(R, s) < 0) push(R, s);
return R;
}
const HOLDSVC = { smbd: 'smb', 'ksmbd.mountd': 'smb', nmbd: 'smb', minidlnad: 'dlna', minidlna: 'dlna', aria2c: 'dl', lighttpd: 'link',
'sftp-server': 'remote', vsftpd: 'rec', rsync: 'backup', rclone: 'cloud' };
const SVCLAB = { smb: [ 'Cartelle In Rete', 'Network Folders' ], dlna: [ 'Server Multimediale', 'Media Server' ], dl: [ 'Download', 'Downloads' ],
link: [ 'Link Di Condivisione', 'Share Links' ], remote: [ 'Accesso Remoto', 'Remote Access' ], rec: [ 'Registrazioni Telecamere', 'Camera Recordings' ],
backup: [ 'Backup', 'Backup' ], cloud: [ 'Cloud', 'Cloud' ], other: [ 'Altri Programmi', 'Other Programs' ] };
function holders(mnts, since, PP) {
let R = [], inm = (l) => { for (let m in mnts) if (l == m || substr(l, 0, length(m) + 1) == m + '/') return true; return false; };
let boot = time() - +split(trim(readfile(PROC + '/uptime') ?? '0'), ' ')[0];
let late = (p) => {
if (!since) return false;
let s = readfile(PROC + '/' + p + '/stat') ?? '', i = rindex(s, ')');
if (i < 0) return false;
let f = split(substr(s, i + 2), ' ');
return length(f) > 19 && match(f[19], /^[0-9]+$/) != null && boot + +f[19] / 100 >= since;
};
for (let p in lsdir(PROC) ?? []) {
if (!match(p, /^[0-9]+$/) || late(p)) continue;
let hit = inm(readlink(PROC + '/' + p + '/cwd') ?? '');
if (!hit) for (let f in lsdir(PROC + '/' + p + '/fd') ?? []) if (inm(readlink(PROC + '/' + p + '/fd/' + f) ?? '')) { hit = true; break; }
if (hit) {
let c = trim(readfile(PROC + '/' + p + '/comm') ?? '');
if (length(c) && index(R, c) < 0) push(R, c);
if (length(c) && type(PP) == 'object') { if (!PP[c]) PP[c] = []; push(PP[c], p); }
}
}
return R;
}
const CLJOBS = '/tmp/wf-cloud/jobs';
const CLKIND = { backup: [ 'Backup Cloud', 'Cloud Backup' ], sync: [ 'Sincronizzazione Cloud', 'Cloud Sync' ], xfer: [ 'Trasferimento', 'Transfer' ],
media: [ 'Server Multimediale', 'Media Server' ], camup: [ 'Copia Fuori Casa', 'Off-Site Copy' ], router: [ 'Copia Del Router', 'Router Copy' ] };
function cloudjobs(pids) {
let W = {}, R = [], seen = {};
for (let p in pids) {
W[p] = 1;
let m = match(readfile(PROC + '/' + p + '/status') ?? '', /PPid:[ \t]*([0-9]+)/);
if (m) W[m[1]] = 1;
}
if (!length(keys(W))) return R;
for (let f in lsdir(CLJOBS) ?? []) {
if (!match(f, /^[A-Za-z0-9_-]+\.json$/)) continue;
let j = rj(CLJOBS + '/' + f);
if (type(j) != 'object' || !W['' + (j.pid ?? '')] || j.state != 'run') continue;
let n = cutn(replace('' + (j.name ?? ''), /[\n\r\t]/g, ' '), 60), k = CLKIND[j.kind];
let it = join(' · ', filter([ 'Cloud', n, k?.[0] ], length)), en = join(' · ', filter([ 'Cloud', n, k?.[1] ], length));
if (!seen[it]) { seen[it] = 1; push(R, [ it, en ]); }
}
return R;
}
function holdnames(H, PP) {
let K = uniq(map(H, (p) => HOLDSVC[p] ?? 'other')), I = [], E = [];
for (let k in K) {
let n = k == 'cloud' ? cloudjobs(PP?.rclone ?? []) : [];
if (length(n)) for (let x in n) { push(I, x[0]); push(E, x[1]); }
else { push(I, SVCLAB[k][0]); push(E, SVCLAB[k][1]); }
}
return { K: K, I: I, E: E };
}

function procnames() {
let R = {};
for (let p in lsdir(PROC) ?? []) if (match(p, /^[0-9]+$/)) { let c = trim(readfile(PROC + '/' + p + '/comm') ?? ''); if (length(c)) { if (!R[c]) R[c] = []; push(R[c], p); } }
return R;
}
function anyfile(d, re) { for (let f in lsdir(d) ?? []) if (match(f, re)) return true; return false; }
function hx(s) { let n = 0; s = uc(s); for (let i = 0; i < length(s); i++) { let c = index('0123456789ABCDEF', substr(s, i, 1)); if (c < 0) return 0; n = n * 16 + c; } return n; }
function bigend() { let f = open('/proc/self/exe', 'r'); if (!f) return false; let h = f.read(6) ?? ''; f.close(); return ord(h, 5) == 2; }
const BE = bigend();
function ipof(h) {
let B = (v) => BE ? [ (v >> 24) & 255, (v >> 16) & 255, (v >> 8) & 255, v & 255 ] : [ v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >> 24) & 255 ];
let w4 = (x) => { let b = B(hx(x)); return sprintf('%d.%d.%d.%d', b[0], b[1], b[2], b[3]); };
if (length(h) == 8) return w4(h);
if (length(h) != 32) return h;
if (substr(h, 0, 16) == '0000000000000000' && substr(h, 16, 8) == (BE ? '0000FFFF' : 'FFFF0000')) return w4(substr(h, 24, 8));
let G = [];
for (let i = 0; i < 4; i++) {
let b = B(hx(substr(h, i * 8, 8)));
push(G, sprintf('%x', (b[0] << 8) | b[1]), sprintf('%x', (b[2] << 8) | b[3]));
}
return replace(join(':', G), /(^|:)0(:0)+(:|$)/, '::');
}
function ip6n(s) {
s = lc('' + s);
if (index(s, ':') < 0) return s;
let p = split(s, '::'), a = length(p[0]) ? split(p[0], ':') : [], b = length(p) > 1 && length(p[1]) ? split(p[1], ':') : [], z = [];
for (let i = length(a) + length(b); i < 8; i++) push(z, '0');
return join(':', map([ ...a, ...z, ...b ], (g) => sprintf('%x', hx(g))));
}
function connmore(R, SP) {
if (!length(R)) return;
let A = {}, v6 = false;
for (let l in split(readfile(PROC + '/net/arp') ?? '', '\n')) { let x = split(trim(l), /[ \t]+/); if (length(x) >= 4 && match(x[3], /^[0-9a-fA-F:]+$/) && length(x[3]) == 17 && x[3] != '00:00:00:00:00:00') A[x[0]] = lc(x[3]); }
for (let c in R) if (index(c.ip, ':') >= 0) v6 = true;
if (v6) for (let l in split(sh('ip -6 neigh 2>/dev/null'), '\n')) { let m = match(l, /^([0-9a-fA-F:]+) .*lladdr ([0-9a-fA-F:]+)/); if (m && length(m[2]) == 17) A[ip6n(m[1])] = lc(m[2]); }
for (let c in R) c.mac = A[ip6n(c.ip)] ?? null;
let acct = trim(readfile(PROC + '/sys/net/netfilter/nf_conntrack_acct') ?? '') == '1', B = {}, t = time();
if (acct) {
let ports = join('|', keys(SP));
for (let l in split(sh('grep -E ' + q('dport=(' + ports + ') ') + ' ' + q(PROC + '/net/nf_conntrack') + ' 2>/dev/null'), '\n')) {
let m = match(l, /src=([^ ]+) dst=[^ ]+ sport=[0-9]+ dport=([0-9]+) .*bytes=([0-9]+) .*bytes=([0-9]+)/);
if (!m || !SP[+m[2]]) continue;
let k = ip6n(m[1]) + ' ' + SP[+m[2]];
B[k] = [ (B[k]?.[0] ?? 0) + +m[4], (B[k]?.[1] ?? 0) + +m[3] ];
}
}
let P = rj(RUN + '/connb.json') ?? {}, dt = t - (P.t ?? 0);
for (let c in R) {
let k = ip6n(c.ip) + ' ' + c.svc, b = B[k], p = P.B?.[k];
c.r = acct ? (b && p && dt > 0 && dt < 600 ? max(0, int((b[0] - p[0]) / dt)) : 0) : null;
c.w = acct ? (b && p && dt > 0 && dt < 600 ? max(0, int((b[1] - p[1]) / dt)) : 0) : null;
}
if (acct && dt >= 2) { mkdirp(RUN); wjr(RUN + '/connb.json', { t: t, B: B }); }
}
function clients(SP) {
let P = { '01BD': 1, '008B': 1, '2008': 1 }, S = {}, n = 0, C = {}, K = [];
for (let f in [ '/net/tcp', '/net/tcp6' ])
for (let l in split(readfile(PROC + f) ?? '', '\n')) {
let x = split(trim(l), /[ \t]+/);
if (length(x) < 4 || x[3] != '01') continue;
let lp = split(x[1], ':')[1], ra = split(x[2], ':')[0];
if (P[lp] && !S[ra]) { S[ra] = 1; n++; }
let sv = SP[hx(lp)];
if (!sv) continue;
let ip = ipof(ra), k = ip + ' ' + sv;
if (ip == '127.0.0.1' || ip == '::1' || C[k]) continue;
C[k] = { ip: ip, svc: sv, port: hx(lp) };
push(K, k);
}
let O = rj(RUN + '/conn.json') ?? {}, N = {}, t = time(), R = [];
for (let k in K) { N[k] = O[k] ?? t; C[k].since = N[k]; push(R, C[k]); }
if (sprintf('%J', N) != sprintf('%J', O)) { mkdirp(RUN); wjr(RUN + '/conn.json', N); }
R = slice(sort(R, (a, b) => a.since - b.since), 0, 32);
connmore(R, SP);
return { n: n, conn: R };
}
function sshport() {
for (let s, o in cfg('dropbear')) if (o['.type'] == 'dropbear') { let p = o.Port ?? o.port; if (match('' + (p ?? ''), /^[0-9]{1,5}$/)) return +p; }
return 22;
}
const SVCK = [ 'smb', 'dlna', 'dl', 'webdav', 'sftp' ];
function svcports(NC, sftp) {
let dl = match(readfile(ETC + '/nas-aria2.conf') ?? '', /(^|\n)rpc-listen-port=([0-9]{1,5})/), dp = 8200;
for (let s, o in cfg('minidlna')) if (o['.type'] == 'minidlna' && match('' + (o.port ?? ''), /^[0-9]{1,5}$/)) dp = +o.port;
return { smb: 445, dlna: dp, dl: dl ? +dl[2] : 6800, webdav: +(NC.remote?.port ?? 5005) || 5005, sftp: sftp ? sshport() : null };
}
function rss(p) { let m = match(readfile(PROC + '/' + p + '/status') ?? '', /VmRSS:[ \t]*([0-9]+)/); return m ? +m[1] : 0; }
function svcinfo(pn, svc, SP) {
let PR = { smb: [ 'ksmbd.mountd', 'smbd' ], dlna: [ 'minidlnad', 'minidlna' ], dl: [ 'aria2c' ], webdav: [ 'lighttpd' ], sftp: [ 'sftp-server' ] }, R = [];
for (let k in SVCK) {
let pr = null, kb = 0, any = false;
let dav = k == 'webdav' ? trim(readfile('/var/run/wf-nasdav.pid') ?? '') : null;
for (let x in PR[k]) {
let L = pn[x] ?? [];
if (dav != null) L = filter(L, (p) => p == dav);
if (!length(L)) continue;
if (pr == null) pr = x;
any = true;
for (let p in L) kb += rss(p);
}
push(R, { k: k, proc: pr ?? PR[k][0], port: SP[k], rss_kb: any ? kb : null, on: svc[k] === true });
}
return R;
}
const MODC = {};
function modof(f) { return UCFG.modof(MODC, f); }
function ntfs3k() {
if (index(readfile(PROC + '/filesystems') ?? '', 'ntfs3') >= 0) return true;
let v = match(readfile(PROC + '/sys/kernel/osrelease') ?? '', /^([0-9]+)\.([0-9]+)/);
return !!v && (+v[1] > 5 || (+v[1] == 5 && +v[2] >= 15));
}
function ntfsro() { return ntfs3k() ? ' -t ntfs3 -o ro,iocharset=utf8,umask=022 ' : ' -t ntfs-3g -o ro,umask=022 '; }
function pkgs() {
let oi = getenv('WF_OPKGINFO') ?? '/usr/lib/opkg/info', fp = (f) => { let s = stat(f); return s ? s.mtime + ':' + s.size + ':' + s.inode : '-'; };
let k = fp('/lib/apk/db/installed') + '|' + fp(oi);
let PKGC = global.wf_nas_pkgc;
if (PKGC?.k == k) return { ...PKGC.r };
let R = {}, db = readfile('/lib/apk/db/installed') ?? '';
for (let p in [ ...PKGS, ...(ntfs3k() ? [] : [ PKGNTFS3G ]) ]) R[p] = has(oi + '/' + p + '.control') || (length(db) > 0 && index(db, '\nP:' + p + '\n') >= 0) || substr(db, 0, length(p) + 3) == 'P:' + p + '\n';
global.wf_nas_pkgc = { k: k, r: { ...R } };
return R;
}
function caps(L) {
let mi = match(readfile(PROC + '/meminfo') ?? '', /MemTotal:[ \t]*([0-9]+)/), ram = mi ? int(+mi[1] / 1024) : 0;
let ci = readfile(PROC + '/cpuinfo') ?? '', n = length(match(ci, /(^|\n)processor[ \t]*:/g) ?? []), x86 = index(ci, 'vendor_id') >= 0;
if (n < 1) n = 1;
return { ram_mb: ram, cpu_cores: n, strong: ram >= 1900 && (n >= 4 || x86), raid: length(uniq(map(filter(L, (d) => d.mounted && !d.dup), (d) => d.base))) >= 2 ||
match(readfile(PROC + '/mdstat') ?? '', /(^|\n)md[0-9]+ :/) != null, ntfs3: ntfs3k() };
}
const SPNAME = [ null ], SPOLD7 = [ null, 2, 3, 5, 6, 7, 8, 10 ];
for (let i = 1; i <= 10; i++) push(SPNAME, i <= 3 ? [ 'Prudente', 'Safe' ] : i <= 7 ? [ 'Media', 'Medium' ] : [ 'Massima', 'Max' ]);
function speedof(id, NC) {
let f = RUN + '/speed-' + id + '.json', s = stat(f), R = s && time() - s.mtime <= 10 ? rj(f) : null;
let M = rj(RUN + '/speed-' + id + '.mem');
if (type(M) != 'object') M = NC?.disks?.[id]?.speed;
if (type(R) == 'object') R.run = true;
else if (type(M) == 'object' && +M.l0 > 0)
R = { run: false, level: null, name: null, name_en: null, ceiling: type(M.ceiling) == 'int' && M.v != 2 ? SPOLD7[M.ceiling] : M.ceiling,
l0: M.l0, p0: M.p0, lat: null, mbs: null, paused_for_user: false, hot: false };
else return null;
let c = type(R.ceiling) == 'int' && R.ceiling >= 2 && R.ceiling <= 10 ? R.ceiling : null, tested = +R.l0 > 0, sf = c ? c - 1 : tested ? 10 : null;
R.ceiling = c; R.tested = tested; R.safe = sf;
R.ceil_name = c ? SPNAME[c][0] : null; R.ceil_name_en = c ? SPNAME[c][1] : null;
R.safe_name = sf ? SPNAME[sf][0] : null; R.safe_name_en = sf ? SPNAME[sf][1] : null;
return R;
}
function speedforget(id) {
mkdirp(RUN);
writefile(RUN + '/speed-' + id + '.forget', '' + time());
unlink(RUN + '/speed-' + id + '.mem');
if (type(nascfg().disks?.[id]?.speed) == 'object') return nasput((o) => { delete o.disks[id].speed; }) != null;
return true;
}
const SVC6 = [ 'smb', 'dlna', 'dl', 'link', 'remote', 'rec' ];
function smbany(NC) { return NC.on === true || NC.tm?.on === true || NC.fh?.on === true || NC.rec?.on === true; }
function vpnsrv() {
for (let k, s in cfg('network')) if (s['.type'] == 'interface' && s.proto == 'wireguard' && !match(k, /^wgo(ut|[0-9]+)$/) &&
length('' + (s.listen_port ?? '')) > 0 && s.disabled != '1') return true;
for (let k, s in cfg('openvpn')) if (s['.type'] == 'openvpn' && s.enabled == '1' && (s.server != null || s.mode == 'server' || s.server_bridge != null)) return true;
return has('/usr/sbin/tailscaled') && has(SYS + '/class/net/tailscale0');
}
function remoteon(NC, vpn) {
let r = NC.remote ?? {};
return vpn && (r.webdav === true || r.sftp === true || (r.smbvpn === true && NC.smb_off !== true && smbany(NC)));
}
function svcsw(NC, PK) {
let pin = (a) => { for (let p in a) if (PK[p]) return true; return false; }, XL = rj(ETC + '/nasx.json')?.link;
let R = {
smb: { inst: pin([ 'ksmbd-server', 'samba4-server' ]), on: NC.smb_off !== true && smbany(NC) },
dlna: { inst: pin([ 'minidlna' ]), on: NC.media?.on === true },
dl: { inst: pin([ 'aria2' ]), on: NC.dl?.on === true },
link: { inst: pin([ 'lighttpd' ]) && pin([ 'lighttpd-mod-cgi' ]), on: XL?.on !== false },
remote: { inst: true, on: remoteon(NC, vpnsrv()) },
rec: { inst: pin([ 'ksmbd-server', 'samba4-server', 'vsftpd' ]) || NC.rec?.on === true, on: NC.rec?.on === true }
}, L = [], n = 0, of = 0;
for (let k in SVC6) {
let x = R[k];
x.on = NC.on === true && x.inst && x.on;
if (x.inst) of++;
if (x.on) n++;
push(L, { k: k, on: x.on, inst: x.inst });
}
return { n: { on: n, of: of }, list: L };
}
function a2port() { let m = match(readfile(ETC + '/nas-aria2.conf') ?? '', /(^|\n)rpc-listen-port=([0-9]{1,5})/); return m ? m[2] : '6800'; }
function a2rpc(body, ms) {
let port = a2port(), js = sprintf('%J', body), sec = int((ms + 999) / 1000), o = null, S = null;
let rq = 'POST /jsonrpc HTTP/1.1\r\nHost: 127.0.0.1:' + port + '\r\nContent-Type: application/json\r\nContent-Length: ' + length(js) +
'\r\nConnection: close\r\n\r\n' + js;
let bodyof = (r) => { let i = index(r ?? '', '\r\n\r\n'); return match(r ?? '', /^HTTP\/1\.[01] [0-9]/) && i >= 0 ? substr(r, i + 4) : null; };
try { S = getenv('WF_NOSOCKET') ? null : require('socket'); } catch (e) { S = null; }
if (S) {
let c = null, r = '';
try { c = S.connect('127.0.0.1', port, null, ms); } catch (e) { c = null; }
if (!c) return null;
try {
let end = time() + sec, want = -1, left = rq;
while (length(left) && time() <= end) {
let n = c.send(left);
if (n == null) break;
if (n > 0) left = substr(left, n);
else S.poll(500, [ c, S.POLLOUT ]);
}
while (!length(left) && time() <= end && length(r) < 4194304) {
let p = S.poll(500, [ c, S.POLLIN ]);
if (!length(p ?? [])) continue;
let d = c.recv(65536);
if (d == null || !length(d)) break;
r += d;
let i = index(r, '\r\n\r\n');
if (want < 0 && i >= 0) { let m = match(lc(substr(r, 0, i)), /content-length: *([0-9]+)/); if (m) want = i + 4 + +m[1]; }
if (want >= 0 && length(r) >= want) break;
}
} catch (e) {}
try { c.close(); } catch (e) {}
o = bodyof(r);
}
else {
let cu = bin('curl'), nc = cu ? null : bin('nc');
if (!cu && !nc) return null;
let dd = RUN + '/.sec', tf = dd + '/a2' + ME;
mkdirp(RUN); mkdir(dd, 448);
writefile(tf, cu ? js : rq);
if (cu) o = sh(q(cu) + ' -s -m ' + sec + ' -H ' + q('Content-Type: application/json') + ' -H Expect: --data-binary @' + q(tf) + ' ' +
q('http://127.0.0.1:' + port + '/jsonrpc') + ' 2>/dev/null');
else o = bodyof(sh((bin('timeout') ? 'timeout ' + (sec + 1) + ' ' : '') + q(nc) + ' 127.0.0.1 ' + port + ' <' + q(tf) + ' 2>/dev/null'));
unlink(tf);
}
if (!length(o)) return null;
try { return json(o); } catch (e) { return null; }
}
function a2(method, params, each) {
let sec = trim(readfile(ETC + '/nas-aria2.secret') ?? '');
if (!length(sec)) return null;
let P = each ? [ map(each, (p) => ({ methodName: method, params: [ 'token:' + sec, ...p ] })) ] : [ 'token:' + sec, ...(params ?? []) ];
return a2rpc({ jsonrpc: '2.0', id: 'wf', method: each ? 'system.multicall' : method, params: P }, 3000)?.result ?? null;
}
function dlpause() {
let A = a2('aria2.tellActive', [ [ 'gid' ] ]), W = a2('aria2.tellWaiting', [ 0, 1000, [ 'gid', 'status' ] ]);
if (type(A) != 'array') return null;
let G = map(A, (x) => x.gid);
for (let x in (type(W) == 'array' ? W : [])) if (x.status == 'waiting') push(G, x.gid);
if (a2('aria2.pauseAll', []) == null) return null;
return filter(G, (g) => match('' + g, /^[0-9a-f]{16}$/));
}
function dlresume(e) {
if (index(e?.stopped ?? [], 'dl') < 0) return;
if (type(e.gids) == 'array') { if (length(e.gids)) a2('aria2.unpause', null, map(e.gids, (g) => [ g ])); }
else a2('aria2.unpauseAll', []);
}
function dlsum(pn) {
let z = { run: 0, paused: false, eta: null };
if (!pn['aria2c']) return z;
let f = RUN + '/dlsum.json', c = rj(f), s = stat(f);
if (type(c) == 'object' && s && time() - s.mtime < 15) return c;
let sec = trim(readfile(ETC + '/nas-aria2.secret') ?? '');
if (!length(sec)) return z;
let tk = 'token:' + sec, K = [ 'status', 'totalLength', 'completedLength', 'downloadSpeed' ];
let j = a2rpc({ jsonrpc: '2.0', id: 'wf', method: 'system.multicall', params: [ [ { methodName: 'aria2.tellActive', params: [ tk, K ] },
{ methodName: 'aria2.tellWaiting', params: [ tk, 0, 100, [ 'status' ] ] } ] ] }, 2000)?.result;
if (type(j) != 'array') return z;
let A = j[0]?.[0] ?? [], W = j[1]?.[0] ?? [], eta = null, pz = 0;
for (let x in A) {
let sp = +(x.downloadSpeed ?? 0), left = +(x.totalLength ?? 0) - +(x.completedLength ?? 0);
if (sp > 0 && left > 0) { let e = int(left / sp); if (eta == null || e > eta) eta = e; }
}
for (let x in W) if (x.status == 'paused') pz++;
z = { run: length(A), paused: !length(A) && pz > 0, eta: eta };
wjr(f, z);
return z;
}
function hm(t) { let l = localtime(t); return sprintf('%02d:%02d', l.hour, l.min); }
function mins(s) {
if (s == null || s < 30) return null;
let m = int((s + 30) / 60);
if (m < 60) return L('circa ', 'about ') + max(1, m) + ' min';
return L('circa ', 'about ') + int((m + 30) / 60) + ' h';
}
const JOBNAME = { copy: [ 'Copia', 'Copy' ], move: [ 'Spostamento', 'Move' ], backup: [ 'Backup', 'Backup' ], delete: [ 'Cestino', 'Trash' ],
format: [ 'Formatta', 'Format' ], check: [ 'Controlla e Ripara', 'Check and Repair' ], raid: [ 'Disco Doppio', 'Mirrored Drive' ] };
function jobeta(j) {
let el = time() - (j.t0 ?? j.t ?? time());
if (el < 5) return null;
if (j.bytes_total > 0 && j.bytes > 0) return int((j.bytes_total - j.bytes) * el / j.bytes);
if (j.total > 0 && j.done > 0) return int((j.total - j.done) * el / j.done);
return null;
}
function nowline(H, P, J, dl) {
let r = null, pc = 0, bk = null;
for (let d in P) if (d.mounted && d.size > 0 && d.used != null) pc = max(pc, int(d.used * 100 / d.size));
for (let j in J) if (j.op == 'backup' && substr(j.id ?? '', 0, 4) == 'bak-' && (j.own ?? 'admin') == 'admin' && (j.state == 'ok' || j.state == 'err') && time() - (j.t1 ?? j.t ?? 0) < 86400) { bk = j; break; }
let btn = bk?.state == 'err' ? 'retry' : dl.run > 0 ? 'dlpause' : pc >= PCWARN ? 'free' : 'up';
let x = H.R[0];
if (x) {
let d = null;
for (let y in P) if (y.id == x.id) d = y;
let det = x.k == 'away' ? (x.n > 0 ? x.n + (x.n == 1 ? L(' cartella non in rete', ' folder offline') : L(' cartelle non in rete', ' folders offline')) : '') :
x.k == 'full' && d?.free != null ? gb(d.free) + L(' liberi', ' free') : (d ? d.name : '');
r = { k: x.h, kind: 'pb', t: L(x.it, x.en) + (length(det) ? ' · ' + det : ''), m: L(x.it, x.en), s: length(det) ? det : L(x.it, x.en), bar: null };
}
if (!r) for (let j in J) if (j.state == 'run' && JOBNAME[j.op] && j.op != 'delete') {
let nm = JOBNAME[j.op], p = j.bytes_total > 0 ? int(j.bytes * 100 / j.bytes_total) : (j.total > 0 ? int(j.done * 100 / j.total) : null), e = mins(jobeta(j));
let w = L(nm[0], nm[1]) + L(' in corso', ' in progress');
r = { k: 'ok', kind: 'job', t: w + (p != null ? ' · ' + p + '%' : '') + (e ? ' · ' + e : ''), m: w + (p != null ? ' · ' + p + '%' : ''), s: p != null ? p + '%' : w, bar: p };
break;
}
if (!r && dl.run > 0) {
let e = dl.eta != null && dl.eta >= 30 ? int((dl.eta + 30) / 60) : null, w = dl.run + ' download';
r = { k: 'ok', kind: 'dl', t: w + (e != null ? L(' · finiti tra ', ' · done in ') + max(1, e) + ' min' : ''), m: w, s: w, bar: null };
}
if (!r && bk) {
let ok = bk.state == 'ok', w = ok ? L('Backup finito alle ', 'Backup done at ') : L('Backup non riuscito alle ', 'Backup failed at ');
r = { k: ok ? 'ok' : 'warn', kind: 'bk', t: w + hm(bk.t1 ?? bk.t), m: w + hm(bk.t1 ?? bk.t), s: ok ? 'Backup ' + hm(bk.t1 ?? bk.t) : L('Backup non riuscito', 'Backup failed'), bar: null };
}
if (!r) {
let M = filter(P, (d) => d.mounted), z = length(M) > 0 && length(filter(M, (d) => d.sleeping)) == length(M);
r = { k: 'ok', kind: 'idle', t: L('Nessun lavoro', 'No jobs') + (z ? L(' · disco in ibernazione', ' · drive hibernating') : ''), m: L('Nessun lavoro', 'No jobs'), s: z ? L('In ibernazione', 'Hibernating') : L('Nessun lavoro', 'No jobs'), bar: null };
}
r.btn = btn;
return r;
}

function segof(dev, u) {
let a = split(trim(readfile(RUN + '/ntfs/' + dev) ?? ''), ' '), s = stat(SYS + '/class/block/' + dev);
if ((length(a) != 3 && length(a) != 5) || !s || a[2] != '' + s.inode || !match(a[0], /^(try|try2|rw|ro|no|win)$/)) return null;
if (length(u ?? '') && a[1] != '-' && a[1] != u) return null;
let n = length(a) == 5 ? +a[3] : (a[0] == 'try2' ? 2 : 1), t = length(a) == 5 ? +a[4] : 0;
return { how: a[0] == 'try2' ? 'try' : a[0], u: a[1], n: type(n) == 'int' && n > 0 ? n : 1, t: type(t) == 'int' ? t : 0 };
}
const RETRYW = [ 60, 180, 300, 900, 1800, 3600 ];
function segdue(g) {
if (!g || g.how == 'rw') return true;
let d = time() - g.t;
return d >= RETRYW[(g.n < length(RETRYW) ? g.n : length(RETRYW)) - 1] || d < -60;
}
function openmark(dev) { return segof(dev, '')?.how; }
function dirtyof(d) {
if (d.fs != 'ntfs') return null;
let om = openmark(d.dev);
if (om == 'ro' || om == 'win') return true;
let m = trim(readfile(RUN + '/dirty/' + d.dev) ?? ''), s = stat(SYS + '/class/block/' + d.dev);
return length(m) > 0 && s != null && m == '' + s.inode;
}
const WINFIX = { it: 'Collegalo a Windows, aprilo e fai Rimuovi In Sicurezza', en: 'Connect it to Windows, open it and use Eject Safely' };
function hibfile(mnt) {
for (let f in lsdir(mnt) ?? []) if (lc(f) == 'hiberfil.sys') {
let h = open(mnt + '/' + f, 'r');
if (!h) return false;
let s = h.read(4) ?? '';
h.close();
return lc(s) == 'hibr';
}
return false;
}
function hibof(dev) {
let a = split(trim(readfile(RUN + '/hib/' + dev) ?? ''), ' '), s = stat(SYS + '/class/block/' + dev);
return length(a) == 2 && s && a[1] == '' + s.inode ? a[0] == '1' : null;
}
function hibset(dev, v) {
let s = stat(SYS + '/class/block/' + dev);
if (!s) return;
mkdirp(RUN + '/hib');
writefile(RUN + '/hib/.' + dev + '.t', (v ? '1' : '0') + ' ' + s.inode);
rename(RUN + '/hib/.' + dev + '.t', RUN + '/hib/' + dev);
}
function stale(M) {
let R = [];
for (let m in M) {
let d = substr(m.dev, 0, 5) == '/dev/' ? substr(m.dev, 5) : '';
if (!match(d, /^((s|h|v)d[a-z]+[0-9]*|nvme[0-9]+n[0-9]+(p[0-9]+)?|mmcblk[0-9]+(p[0-9]+)?|md[0-9]+)$/)) continue;
if (index([ '/', '/rom', '/overlay', '/boot', '/boot/efi' ], m.mnt) >= 0 || has(SYS + '/class/block/' + d)) continue;
push(R, m);
}
return R;
}
const NOL = RUN + '/ntfsopen.lock';
function ntfsbusy() { return locked(NOL, 600); }
function opentodo(M, F) {
let BI = blkinfo(M), on = {}, T = [];
for (let m in M) if (substr(m.dev, 0, 5) == '/dev/') on[substr(m.dev, 5)] = true;
for (let d in sort(keys(BI))) {
let I = BI[d], u = lc(replace(I?.UUID ?? '', /[^A-Za-z0-9-]/g, ''));
if (on[d] || !length(u) || !match(d, /^[a-z0-9]+$/) || !has(SYS + '/class/block/' + d) || has(RUN + '/ejected/' + baseof(d))) continue;
if (!match(lc(I.TYPE ?? ''), /^(ext[234]|vfat|msdos|exfat|ntfs3?|btrfs|xfs|f2fs|hfsplus)$/)) continue;
let S = null;
for (let s, o in F) if (o['.type'] == 'mount' && lc(replace(o.uuid ?? '', /[^A-Za-z0-9-]/g, '')) == u && index([ '0', 'false', 'no', 'off' ], o.enabled ?? '1') < 0 && substr(o.target ?? '', 0, 1) == '/') S = o;
if (S) push(T, { d: d, I: I, u: u, S: S });
}
return T;
}
function fixon() {
let W = cfg('wrtfreedom'), c = W.custode ?? {}, r = c.ripara;
r = type(r) == 'array' ? r : split('' + (r ?? ''), /[ \t]+/);
return (c.on != '0' && index(r, 'nas') >= 0) || '' + (W.fastwd?.nas ?? '1') != '0';
}
const CUTD = ETC + '/nas-jobs/';
function cuts() {
let R = [];
for (let f in lsdir(CUTD) ?? []) {
if (!match(f, /^[0-9a-f]+$/)) continue;
let p = trim(readfile(JOBS + '/' + f + '.pid') ?? '');
if (match(p, /^[0-9]+$/) && stat('/proc/' + p)) continue;
let o = { id: f };
for (let l in split(readfile(CUTD + f) ?? '', '\n')) { let m = match(l, /^([a-z_0-9]+)=(.*)$/); if (m) o[m[1]] = m[2]; }
push(R, o);
}
return R;
}
function ejectof(id) { let e = rj(RUN + '/eject/' + id + '.json'); return type(e) == 'object' ? e : null; }
function ejectlast(id) { let e = rj(RUN + '/eject/' + id + '.last'); return type(e) == 'object' && time() - +(e.t ?? 0) < 120 ? e : null; }
function ejectfin(id, Ls) {
let ED = RUN + '/eject/', e = rj(ED + id + '.json'), rs = trim(readfile(ED + id + '.res') ?? '');
if (e?.now !== true || (rs != 'ok' && rs != 'busy')) return false;
let D = null, x = { res: rs, t: time(), users: [], users_en: [], svc: [] };
for (let d in Ls) if (d.id == id) D = d;
if (rs == 'busy' && D) { let PP = {}, N = holdnames(holders(map(filter(Ls, (y) => y.base == D.base && y.mounted), (y) => y.mnt), +(e.since ?? 0), PP), PP); x.svc = N.K; x.users = N.I; x.users_en = N.E; }
wjr(ED + id + '.last', x); unlink(ED + id + '.json'); unlink(ED + id + '.res');
return true;
}
function dayof(t) { let l = localtime(t ?? time()); return sprintf('%04d-%02d-%02d', l.year, l.mon, l.mday); }
const USBJ = ETC + '/nas-usb.json';
function usbdata() {
let u = rj(RUN + '/usb.json');
if (type(u) != 'object') { u = rj(USBJ); if (type(u) != 'object') u = {}; u.pos = null; }
if (type(u.ids) != 'object') u.ids = {};
return u;
}
function usbhub(o, td) {
for (let x in o?.list ?? []) if (x.wake === true) return 'wake';
return (o?.days?.[td] ?? 0) >= 3 ? 'many' : null;
}
function pub(d, S, io, slp, X) {
let s = d.md ? { ok: null, temp: null, hours: null, bad: null, at: null, k: 'na', why: null, realloc: null, pend: null, unc: null, crc: null, via: null, test_ok: false, test: null } : smartof(d.base), ch = io.N[d.base]?.chg;
let sg = d.mounted ? null : segof(d.dev, ''), om = sg?.how, U = X.U.ids[d.id] ?? {}, td = dayof(), ej = ejectof(d.id);
let one = length(filter(X.L, (x) => x.mounted)) <= 1, sh = {};
for (let c in X.NC.shares ?? []) if (c?.disk) sh[c.disk] = true;
let us = d.mounted ? map(filter(X.conn, (c) => one || c.svc != 'smb' || sh[d.id]), (c) => ({ ip: c.ip, svc: c.svc, mac: c.mac })) : [];
let last = null;
for (let x in U.list ?? []) last = x;
let hib = d.fs == 'ntfs' && hibof(d.dev) === true, fc = false;
for (let c in X.cuts ?? []) if (c.op == 'format' && c.model == d.model && c.size == sysr('/class/block/' + d.base + '/size')) fc = true;
return { id: d.id, name: d.name, dev: d.dev, label: d.label, fs: d.fs, size: d.size, used: d.used, free: d.free, ro: d.mounted ? d.ro || hib : d.lock || hib, ro_set: d.lock, usb: d.usb,
hib: hib, dup: d.dup, same_name: d.same_name, no_uuid: !length(d.uuid ?? ''), fmt_cut: fc,
since: S.now[d.id]?.since ?? time(), sleeping: slp.mins > 0 && !keepnow(slp) && ch != null && time() - ch >= slp.mins * 60, smart: s,
mounted: d.mounted, model: d.model, speed: speedof(d.id, X.NC), io: io.D[d.base] ?? { r: 0, w: 0 }, usb_ver: d.usb ? usbver(d.base) : null, usb_max: d.usb ? usbmax(d.base) : null,
dirty: dirtyof(d), win: d.fs == 'ntfs' && openmark(d.dev) == 'win', new: d.new, open: om, tries: sg && om != 'rw' ? sg.n : 0, users: us,
usb_port: d.usb ? usbport(d.base) : null, hub_pwr: d.usb ? usbpwr(d.base) : null, usb_today: U.days?.[td] ?? 0, usb_last: last?.t ?? null,
usb_reset: length(filter(U.list ?? [], (x) => !x.test && time() - x.t < 600)),
eject: ej ? { wait: true, since: ej.since, left_s: ej.left_s ?? null, waits: ej.waits ?? [], stopped: ej.stopped ?? [], now: ej.now === true } : null,
eject_last: ejectlast(d.id),
mnt: d.mnt };
}
function dhealth(d, can) {
let pc = d.size > 0 && d.used != null ? int(d.used * 100 / d.size) : 0, sm = d.smart ?? {}, R = [];
let r = (h, k, w, it, en, fx) => push(R, { h: h, k: k, why: w, it: it, en: en, ...(fx ? { fix: fx } : {}) });
if (d.mounted && pc >= PCFULL) r('bad', 'full', 'full', 'Spazio finito', 'Drive full');
if (sm.k == 'bad') r('bad', 'smart', 'smart', sm.why?.it ?? 'S.M.A.R.T.', sm.why?.en ?? 'S.M.A.R.T.');
if (d.win) r('warn', 'win', d.mounted ? 'ro' : 'unmounted', d.mounted ? 'Lavori di Windows a metà: sola lettura' : 'Lavori di Windows a metà',
d.mounted ? 'Windows work left unfinished: read-only' : 'Windows work left unfinished', WINFIX);
else if (!d.mounted && can && match(d.fs ?? '', /^(ext[234]|fat32|exfat|ntfs|btrfs|xfs|f2fs|hfsplus)$/) && time() - (d.since ?? 0) > 60)
r('warn', 'unopened', 'unmounted', 'Disco Non Montato', 'Drive Not Mounted');
if (d.fmt_cut) r('warn', 'fmt_cut', null, 'Preparazione interrotta', 'Preparation interrupted');
if (d.dup) r('warn', 'dup', null, 'Due dischi con lo stesso UUID', 'Two drives with the same UUID');
if (d.mounted && d.hib) r('warn', 'hib', 'ro', 'Avvio Rapido di Windows: sola lettura', 'Windows Fast Startup: read-only');
if (d.mounted && d.ro && !d.ro_set && !d.hib && !d.win) r('warn', 'ro_fail', 'ro', d.dirty ? 'Chiuso male: in sola lettura' : 'In sola lettura per un errore', d.dirty ? 'Closed badly: read-only' : 'Read-only after an error');
if (sm.temp != null && sm.temp >= HOTC) r('warn', 'hot', 'hot', 'Troppo caldo: ' + sm.temp + ' °C', 'Too hot: ' + sm.temp + ' °C');
if (sm.lk) r('warn', 'usblink', null, sm.why?.it ?? 'Problemi di collegamento USB', sm.why?.en ?? 'USB connection problems');
else if (sm.k == 'warn') r('warn', 'smart', 'smart', sm.why?.it ?? 'S.M.A.R.T.', sm.why?.en ?? 'S.M.A.R.T.');
if (d.usb_reset > 0) r('warn', 'usbreset', null, 'Porta USB riavviata', 'USB port restarted');
if (d.mounted && pc >= PCWARN && pc < PCFULL) r('warn', 'full', 'space', 'Spazio quasi finito', 'Space almost full');
let h = 'ok';
for (let x in R) if (x.h == 'bad') h = 'bad'; else if (h == 'ok') h = 'warn';
return { h: h, R: R };
}
function health(P, can) {
if (!length(P)) return { h: 'none', R: [] };
let h = 'ok', R = [];
for (let d in P) {
let x = dhealth(d, can);
d.health = x.h; d.reason = x.R[0]?.k ?? null; d.health_why = x.R[0] ? { k: x.R[0].k, it: x.R[0].it, en: x.R[0].en, ...(x.R[0].fix ? { fix: x.R[0].fix } : {}) } : null;
if (x.h == 'bad') h = 'bad'; else if (x.h == 'warn' && h == 'ok') h = 'warn';
for (let y in x.R) push(R, { ...y, id: d.id });
}
return { h: h, R: [ ...filter(R, (x) => x.h == 'bad'), ...filter(R, (x) => x.h != 'bad') ] };
}
function trashsum(P) {
let fp = '', T = [];
for (let d in P) {
if (!d.mounted || !length(d.mnt)) continue;
let t = d.mnt + '/' + TRASH, a = lstat(t + '/info'), b = lstat(t + '/files');
if (!a || !b || a.type != 'directory' || b.type != 'directory' || lstat(t)?.type != 'directory') continue;
fp += d.id + ':' + a.inode + ':' + a.mtime + ':' + b.inode + ':' + b.mtime + ';';
push(T, t);
}
let f = RUN + '/trashsum.json', c = rj(f);
if (type(c) == 'object' && c.fp == fp && type(c.n) == 'int') return { n: c.n, bytes: c.bytes };
let n = 0, by = 0;
for (let t in T) for (let x in lsdir(t + '/info') ?? []) {
let m = match(x, /^([0-9A-Za-z._-]+)\.info$/);
if (!m || !lstat(t + '/files/' + m[1])) continue;
let z = match(readfile(t + '/info/' + x) ?? '', /(^|\n)size=([0-9]+)/);
n++; by += z ? +z[2] : 0;
}
mkdirp(RUN);
wjr(f, { fp: fp, n: n, bytes: by });
return { n: n, bytes: by };
}
function usersn(NC) { let n = 0; for (let u, x in (type(NC.users) == 'object' ? NC.users : {})) if (!x?.cam) n++; return n; }
function useof(NC) {
let U = {}, u = (id) => { id = '' + (id ?? ''); if (!length(id)) return null; if (!U[id]) U[id] = { shares: 0, homes: 0, media: 0, run: false }; return U[id]; };
let mn = NC.main, x = NC.on === true && type(mn) == 'object' ? u(mn.id) : null;
if (x) {
x.shares += 2;
for (let k, p in (type(NC.users) == 'object' ? NC.users : {})) if (type(p) == 'object' && !p.cam) x.homes++;
}
for (let d in (type(NC.media?.dirs) == 'array' ? NC.media.dirs : [])) { let m = match('' + d, /^([^:]+):\//); if (m) { let y = u(m[1]); if (y) y.media++; } }
for (let k in [ 'dl', 'rec', 'tm', 'fh' ]) if (type(NC[k]) == 'object' && NC[k].on === true) { let y = u(NC[k].disk); if (y) y.run = true; }
for (let b in (type(NC.backups) == 'array' ? NC.backups : [])) if (type(b) == 'object') { u(b.what?.disk); if (b.dest?.kind == 'disk') u(b.dest.disk); }
return U;
}
function fmting(J) { let F = {}; for (let j in J) if ((j.state == 'run' || j.state == 'ask') && j.op == 'format' && length('' + (j.disk ?? ''))) F['' + j.disk] = true; return F; }
function awayof(NC, L, J) {
let U = useof(NC), here = fmting(J), R = [], DS = type(NC.disks) == 'object' ? NC.disks : {};
for (let d in L) here[d.id] = true;
for (let id in sort(keys(U))) {
let o = DS[id], g = type(o?.gone) == 'object' ? o.gone : {}, x = U[id];
if (here[id] || type(o) != 'object') continue;
push(R, { id: id, name: o.name ?? g.name ?? id, gone: type(g.t) == 'int' ? g.t : null, safe: g.safe === true,
warn: g.safe !== true && (x.shares + x.homes + x.media > 0 || x.run), shares: x.shares, homes: x.homes, media: x.media });
}
return R;
}
const MAINPJ = RUN + '/mainpause.json', PMAX = 32;
function mainok(d) { return !!d && d.mounted && !d.ro && !d.lock && !d.dup; }
function maindef(Ls) { let b = null; for (let d in Ls) if (mainok(d) && !d.removable && (!b || +(d.size ?? 0) > +(b.size ?? 0))) b = d; return b; }
function mainsaved(NC) { let m = NC?.main; return type(m) == 'object' && length('' + (m.id ?? '')) > 0 ? m : null; }
function maindisk(m, Ls) {
if (!m) return null;
let u = lc('' + (m.uuid ?? ''));
for (let d in Ls) if (d.id == m.id) return d;
if (length(u)) for (let d in Ls) if (lc(d.uuid ?? '') == u) return d;
return null;
}
function mstate(d, sm, p) {
let r = (st, it, k, wi, we) => ({ state: st, sev: st == 'ok' ? 'ok' : (st == 'check' ? 'warn' : 'bad'), text: it, why: k ? { k: k, it: wi, en: we } : null });
if (!d) return r('off', 'Disco Staccato', 'away', 'Il disco non è collegato', 'The drive is not connected');
if (!d.mounted) return r('off', 'Disco Staccato', 'unopened', 'Disco Non Montato', 'Drive Not Mounted');
if (d.dup) return r('bad', 'Disco Guasto', 'dup', 'Due dischi con lo stesso UUID', 'Two drives with the same UUID');
if (sm?.k == 'bad') return r('bad', 'Disco Guasto', 'smart', sm.why?.it ?? 'S.M.A.R.T.', sm.why?.en ?? 'S.M.A.R.T.');
if (d.ro || p?.ro) return r('bad', 'Disco Guasto', 'ro', p?.health_why?.it ?? 'In sola lettura: non si scrive', p?.health_why?.en ?? 'Read-only: nothing can be written');
if (sm?.k == 'warn') return r('check', 'Da Controllare', 'smart', sm.why?.it ?? 'S.M.A.R.T.', sm.why?.en ?? 'S.M.A.R.T.');
if (p && p.health != 'ok' && p.health_why) return r('check', 'Da Controllare', p.health_why.k, p.health_why.it, p.health_why.en);
if (!p && d.size > 0 && d.used != null && int(d.used * 100 / d.size) >= PCFULL) return r('check', 'Da Controllare', 'full', 'Spazio finito', 'Drive full');
if (match(d.fs ?? '', /^(ntfs|exfat|fat32)$/))
return r('check', 'Da Controllare', 'fs', uc(d.fs) + ': meglio ext4 per le cartelle delle persone', uc(d.fs) + ': ext4 is better for people\'s folders');
return r('ok', 'Pronto');
}
function mpause(st) { return st?.state == 'off' || st?.state == 'bad'; }
function mainpub(NC, L, P) {
let m = mainsaved(NC), auto = false;
if (!m) { let d = maindef(L); if (!d) return null; m = { id: d.id, uuid: d.uuid }; auto = true; }
let d = maindisk(m, L), p = d ? filter(P, (x) => x.id == d.id)[0] : null, st = mstate(d, p?.smart, p);
return { id: m.id, uuid: m.uuid ?? '', name: d?.name ?? (type(NC.disks?.[m.id]) == 'object' ? NC.disks[m.id].name : null) ?? m.id,
fs: d?.fs ?? null, state: st.state, sev: st.sev, text: st.text, why: st.why, doppio: !!d?.md || NC.doppio?.on === true, ...(auto ? { auto: true } : {}) };
}
function peopleof(NC) {
let U = type(NC.users) == 'object' ? NC.users : {}, Q = rj(RUN + '/quota.json') ?? {}, t = time();
let r = { n: 0, max: PMAX, new: 0, locked: 0, quota: 0, blocked: 0, list: [] };
for (let k in sort(keys(U))) {
let x = U[k];
if (type(x) != 'object' || x.cam) continue;
r.n++;
if (x.new === true) r.new++;
if (+(x.lock_until ?? 0) > t) r.locked++;
if (x.blocked === true) r.blocked++;
let qg = +(x.quota?.disk ?? 0), q = Q[k], b = type(q) == 'object' ? q.b : q, pc = type(q) == 'object' && q.pct != null ? q.pct :
(b != null && qg > 0 ? +b * 100 / (qg * 1073741824) : null);
if (pc != null && +pc >= 90) r.quota++;
push(r.list, { user: k, vis: x.vis || k, used: b != null ? +b : null, quota: qg, pct: pc != null ? int(+pc) : null });
}
return r;
}
function camsof(NC) {
let S = rj(RUN + '/rec.json');
return { on: NC.rec?.on === true, used: type(S) == 'object' && S.used != null ? +S.used : null, t: type(S) == 'object' ? (S.t ?? null) : null };
}
const CLSTJ = '/tmp/wf-cloud/state.json';
function cloudfree() {
let C = rj(ETC + '/cloud.json'), S = rj(CLSTJ)?.accts, f = null;
if (type(C?.accounts) != 'array' || type(S) != 'object') return null;
for (let a in C.accounts) {
if (type(a) != 'object' || (type(a.user) == 'string' && a.user != '' && a.user != 'admin')) continue;
let x = S['' + a.id];
if (type(x) == 'object' && +(x.total ?? 0) > 0 && x.free != null) f = (f ?? 0) + +x.free;
}
return f;
}
function evn(t, txt) { bg('sh ' + q(EVSH) + ' cron ' + t + ' nas ' + q(txt)); }
function mainstep(NC, Ls) {
let m = mainsaved(NC);
if (!m) {
let d = NC.on === true ? maindef(Ls) : null;
if (d) nasput((o) => { if (!mainsaved(o)) o.main = { id: d.id, uuid: d.uuid ?? '' }; });
return;
}
let d = maindisk(m, Ls), st = mstate(d, d && !d.md ? smartof(d.base) : null, null), p = rj(MAINPJ), nm = '🗄️ NAS ¦ ';
if (mpause(st) && type(p) != 'object') {
let G = dlpause();
mkdirp(RUN);
wjr(MAINPJ, { t: time(), state: st.state, why: st.why?.k ?? null, stopped: G != null ? [ 'dl' ] : [], gids: G ?? [] });
evn('nas_main_off', nm + (st.state == 'off' ? L('Disco Principale Staccato', 'Main Drive Unplugged') : L('Disco Principale Guasto', 'Main Drive Failing')) +
' ¦ ' + L('Funzioni personali in pausa', 'Personal features paused'));
}
else if (mpause(st) && p.state != st.state) { p.state = st.state; p.why = st.why?.k ?? null; wjr(MAINPJ, p); }
else if (!mpause(st) && type(p) == 'object') {
dlresume(p);
unlink(MAINPJ);
evn('nas_main_on', nm + L('Disco Principale Tornato', 'Main Drive Back') + ' ¦ ' + L('Funzioni personali ripartite', 'Personal features resumed'));
}
}
function riord(args) {
let rm = null;
try { rm = loadfile(getenv('WF_RIORDINAUC') ?? '/usr/share/wrtfreedom/riordina.uc')(); } catch (e) { rm = null; }
if (type(rm?.riordina?.call) != 'function') return err('Spostamento non disponibile: aggiorna il Pacchetto Router', 'Move not available: update the Router Package', { code: 'nomod' });
let r = null;
try { r = rm.riordina.call({ args: args }); } catch (e) { r = err('Non riuscito', 'Failed'); }
return r;
}
function hasusers(d) { return !!d?.mounted && length(filter(lsdir(d.mnt + '/' + UCFG.UDIR.root) ?? [], (x) => substr(x, 0, 4) != '.wf-')) > 0; }
const TIPIUC = getenv('WF_NASTIPIUC') ?? replace(sourcepath() ?? '', /[^\/]*$/, '') + 'nastipi.uc';
let TIPI = null;
function tipi() { if (TIPI == null) { try { TIPI = loadfile(TIPIUC)() ?? {}; } catch (e) { TIPI = {}; } } return TIPI; }
const NASVCUC = getenv('WF_NASVCUC') ?? replace(sourcepath() ?? '', /[^\/]*$/, '') + 'nasvc.uc';
const CLMNT = '/tmp/wf-cloud/mnt';
const SMBR = (getenv('WF_NASROOT') && stat('/etc/openwrt_release') == null) ? getenv('WF_NASROOT') : '';
let NASVC = null;
function nasvc() { if (NASVC == null) { try { NASVC = loadfile(NASVCUC)() ?? {}; } catch (e) { NASVC = {}; } } return NASVC; }
function sharelive(NC, L, smb, pn) {
let T = tipi(), f = nasvc().nas_shares?.call, M = {}, FX = null;
if (type(T.live) != 'function') return 0;
if (type(f) == 'function') { let r = null; try { r = f({ args: { act: 'list' } }); } catch (e) { r = null; } FX = type(r?.shares) == 'array' ? r.shares : []; }
for (let d in L) if (d.mounted && !d.dup) M[d.id] = true;
if (smb && type(T.smbsec) == 'function') smb = T.smbsec(pn, cfg, (f) => readfile(SMBR + f));
let lv = T.live(NC, M, rj(ETC + '/cloud.json'), smb, (id) => rj(CLMNT + '/' + id + '.json'), FX) ?? [], n = 0, SN = {};
for (let s in (FX ?? NC?.shares ?? []))
if (type(s) == 'object' && !s.cam && s.kind != 'cam' && M['' + s.disk] === true && index(lv, '' + (s.name ?? '')) >= 0) { n++; SN['' + s.name] = true; }
for (let x in lv) if (!SN[x]) n++;
return n;
}
function bklast() {
let B = ETC + '/nas-bak/', t = null;
for (let f in lsdir(B) ?? []) {
if (!match(f, /\.last$/)) continue;
let m = match(readfile(B + f) ?? '', /^([0-9]+) /);
if (m && (t == null || +m[1] > t)) t = +m[1];
}
return t;
}
function sysup() { return int(+split(trim(readfile(PROC + '/uptime') ?? '0'), ' ')[0]); }
function state() {
renames();
let NC = nascfg(), pn = procnames(), on = (a) => { for (let x in a) if (pn[x]) return true; return false; };
let D = disks(), L = D.list, S = seen(L), io = iostat(map(L, (d) => d.base)), slp = sleepcfg();
mntsync(L);
for (let f in lsdir(RUN + '/eject') ?? []) { let m = match(f, /^(.+)\.res$/); if (m) ejectfin(m[1], L); }
let usb = length(L) > 0 || anyfile(SYS + '/bus/usb/devices', /^usb[0-9]+$/) || length(lsdir(SYS + '/class/ata_port') ?? []) > 0;
let svc = { smb: on(tipi().smbp ?? [ 'ksmbd.mountd', 'smbd' ]), dlna: on([ 'minidlnad', 'minidlna' ]), dl: on([ 'aria2c' ]),
webdav: on([ 'lighttpd', 'nginx' ]) && (anyfile('/etc/lighttpd/conf.d', /webdav/) || anyfile('/etc/nginx/conf.d', /webdav/)),
sftp: NC.remote?.sftp === true };
let SP = svcports(NC, svc.sftp), PS = {};
for (let k in SVCK) if (k != 'dl' && SP[k] && (k != 'sftp' || pn['sftp-server'])) PS[SP[k]] = k;
if (PS[445] == 'smb') PS[139] = 'smb';
let cl = clients(PS), U = usbdata();
let CT = cuts(), P = map(L, (d) => pub(d, S, io, slp, { L: L, NC: NC, conn: cl.conn, U: U, cuts: CT }));
smartbg(L);
let J = jobs();
for (let d in P) if (d.speed?.run) for (let j in J) if (j.state == 'run' && (j.disk == d.id || j.to_disk == d.id)) {
if (j.total > 0) d.speed.pct = min(100, int(j.done * 100 / j.total));
d.speed.eta_s = jobeta(j);
break;
}
let can = canmount() == '1', H = health(P, can), PK = pkgs(), SW = svcsw(NC, PK), dl = dlsum(pn), AW = awayof(NC, L, J);
if (length(P)) for (let a in AW) if (a.warn) {
let nm = cutn(a.name, 24);
push(H.R, { h: 'warn', k: 'away', why: null, id: a.id, it: nm + ' staccato', en: nm + ' unplugged', n: a.shares });
if (H.h == 'ok') H.h = 'warn';
}
let x = H.R[0], xc = null;
for (let y in H.R) if (y.k != 'away') { xc = y; break; }
let why = null;
for (let y in H.R) if (y.why) { why = y.why; break; }
let t0 = null;
for (let d in P) if (d.mounted && (t0 == null || d.since < t0)) t0 = d.since;
let up = NC.on === true && t0 != null ? min(sysup(), time() - t0) : 0;
let last = rj(RUN + '/last.json'), ur = 0;
for (let d in P) ur += d.usb_reset;
let XC = rj(ETC + '/nasx.json');
let MN = mainpub(NC, L, P);
for (let d in P) d.main = MN != null && d.id == MN.id;
return { main: MN, pause: mpause(MN), reg: NC.reg !== false, people: peopleof(NC), on: NC.on === true, usb: usb, caps: caps(L), disks: P, io: { r: io.r, w: io.w }, clients: cl.n, conn: cl.conn, health: H.h, svc: svc,
svc_info: svcinfo(pn, svc, SP), jobs: map(J, (j) => jobpub(NC, j)), pkgs: PK, sleep: slp, speed_mode: spmode(NC),
reason: x?.k ?? null, rlabel: xc ? { it: xc.it, en: xc.en } : null, health_why: xc ? { k: xc.k, it: xc.it, en: xc.en, id: xc.id, ...(xc.fix ? { fix: xc.fix } : {}) } : null, why: why,
reasons: map(H.R, (y) => ({ k: y.k, h: y.h, id: y.id, it: y.it, en: y.en, ...(y.fix ? { fix: y.fix } : {}) })),
now: nowline(H, P, J, dl), svc_n: SW.n, svc_sw: SW.list, dl: dl, uptime: up, last: type(last) == 'object' ? last : null,
usb_reset: ur, bk: { on: NC.bk?.on !== false, photo_on: XC?.photo?.on !== false, last: bklast() },
trash: trashsum(P), users_n: usersn(NC),
away: AW, shares_live: sharelive(NC, L, svc.smb, pn),
cams: camsof(NC), cloud_free: cloudfree() };
}

function ev(t, txt) { bg('sh ' + q(EVSH) + ' cron ' + t + ' usb ' + q(txt)); }
const NTFSFIXT = +(getenv('WF_NTFSFIXT') ?? 300) || 300;
function unstale() {
let SM = stale(mounts());
if (!length(SM)) return [];
let S = filter(svclist(), (s) => trim(sh(q(INITD + s) + ' running >/dev/null 2>&1 && echo y')) == 'y'), P = uniq(map(SM, (m) => m.mnt)), MJ = rj(MNTJ) ?? {};
let CM = '/usr/share/wrtfreedom/cloudmnt.sh';
if (has(CM)) for (let id, mp in MJ) if (index(P, mp) >= 0) sh((bin('timeout') ? 'timeout 60 ' : '') + 'sh ' + q(CM) + ' disk ' + q(id) + ' >/dev/null 2>&1 </dev/null');
for (let s in S) sh(q(INITD + s) + ' stop >/dev/null 2>&1 </dev/null');
for (let p in P) for (let i = 0; i < 4 && length(filter(mounts(), (m) => m.mnt == p)); i++) sh(UMOUNTC + ' -l ' + q(p) + ' >/dev/null 2>&1 </dev/null');
if (bin('block')) sh('block mount >/dev/null 2>&1 </dev/null');
let MM = mounts();
for (let p in P) if (substr(p, 0, 5) == '/mnt/' && !length(filter(MM, (m) => m.mnt == p))) rmdir(p);
mntsync();
for (let s in S) sh(q(INITD + s) + ' start >/dev/null 2>&1 </dev/null');
return P;
}
function ntfsopen1() {
let gone = unstale();
let NT = RUN + '/ntfs/', ev2 = (t, txt) => bg('sh ' + q(EVSH) + ' cron ' + t + ' nas ' + q(txt)), WAIT = +(getenv('WF_NASRETRY') ?? 10);
let now = time();
let segw = (x, how) => {
let s = stat(SYS + '/class/block/' + x.d), t = RUN + '/.ntfs.' + x.d + '.t';
if (!s) return;
mkdirp(NT);
writefile(t, how + ' ' + (length(x.u) ? x.u : '-') + ' ' + s.inode + ' ' + x.n + ' ' + now + '\n');
rename(t, NT + x.d);
};
for (let f in lsdir(NT) ?? []) if (segof(f, '') == null) unlink(NT + f);
for (let f in lsdir(JOBS) ?? []) if (substr(f, -5) == '.json' && rj(JOBS + '/' + f)?.state == 'run') return { open: [], busy: true, unstale: gone };
let F = cfg('fstab'), R = [], N = nascfg().disks ?? {}, mk = null, lr = null;
let isup = (d) => { for (let m in mounts()) if (m.dev == '/dev/' + d) return true; return false; };
let bmount = () => {
mk = 'wf-ntfsopen ' + replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time())), /[^A-Za-z0-9-]/g, '');
lr = null;
sh('logger -t wrtfreedom ' + q(mk) + ' >/dev/null 2>&1 </dev/null');
if (bin('block')) sh('block mount >/dev/null 2>&1 </dev/null');
};
let logs = () => {
if (lr != null) return lr;
lr = [];
let seen = false;
for (let l in split(sh('logread 2>/dev/null | grep -F -e ' + q(mk) + ' -e ntfs3'), '\n')) {
if (index(l, mk) >= 0) { seen = true; lr = []; continue; }
if (seen) push(lr, l);
}
return lr;
};
let head = (x) => L('Disco «', 'Drive «') + cutn(N[x.u]?.name ?? (length(x.I.LABEL ?? '') ? x.I.LABEL : x.d), 18) + '»';
let noopen = (x, why) => ev2('nas_ntfsno', '⚠️ ' + head(x) + ' ¦ ' + L('Non aperto', 'Not opened') + ' ¦ ' + why);
let told = (x) => x.was && x.was.how != 'try' ? x.was.how : null;
let U0 = [];
for (let m in mounts()) {
let d = substr(m.dev, 0, 5) == '/dev/' ? substr(m.dev, 5) : '', g = length(d) && m.ro ? segof(d, '') : null;
if (!g || g.how != 'ro' || hibof(d) === true || !segdue(g) || has(RUN + '/ejected/' + baseof(d))) continue;
if (length(holders([ m.mnt ]))) { segw({ d: d, u: g.u == '-' ? '' : g.u, n: g.n + 1 }, 'ro'); continue; }
sh(UMOUNTC + ' ' + q(m.mnt) + ' >/dev/null 2>&1 </dev/null');
if (!isup(d)) push(U0, { d: d, mnt: m.mnt });
}
let T0 = [], cand = {};
for (let x in opentodo(mounts(), F)) {
cand[x.d] = true;
x.was = segof(x.d, x.u);
if (x.was == null && has(NT + x.d)) unlink(NT + x.d);
if (!segdue(x.was)) continue;
x.n = x.was && x.was.how != 'rw' ? x.was.n + 1 : 1;
segw(x, x.was && x.was.how != 'rw' ? x.was.how : 'try');
push(T0, x);
}
for (let f in lsdir(NT) ?? []) if (!cand[f] && !isup(f) && index(map(U0, (u) => u.d), f) < 0) unlink(NT + f);
bmount();
let left = [];
for (let round = 1; round <= 3; round++) {
left = [];
for (let x in T0) {
let d = x.d, S = x.S, H = head(x);
if (x.done || isup(d) || !has(SYS + '/class/block/' + d)) continue;
let last = '', lg = false;
if (match(lc(x.I.TYPE ?? ''), /^ntfs/)) for (let l in logs()) if (match(l, regexp('ntfs3[(: ]+' + d + '[):]'))) {
last = l;
if (index(lc(l), 'replay') >= 0) lg = true;
}
if (lg && index(lc(last), 'hibernat') < 0 && hibof(d) !== true) {
x.done = true;
segw(x, 'win');
if (told(x) != 'win') ev2('nas_ntfsno', '⚠️ ' + H + ' ¦ ' + L('Lavori di Windows a metà', 'Windows work left unfinished') + ' ¦ ' + L(WINFIX.it, WINFIX.en));
push(R, { dev: d, how: 'win' });
continue;
}
if (index(last, 'volume is dirty') < 0) { push(left, x); continue; }
x.done = true;
let how = 'no', to = bin('timeout') ? 'timeout ' + NTFSFIXT + ' ' : '';
let tfree = () => !length(filter(mounts(), (m) => m.mnt == S.target));
let rom = () => {
mkdirp(S.target);
sh(MOUNTC + ntfsro() + q('/dev/' + d) + ' ' + q(S.target) + ' >/dev/null 2>&1 </dev/null');
return isup(d);
};
let hb = index(lc(last), 'hibernat') >= 0 || hibof(d) === true, pre = false;
if (tfree()) {
pre = rom();
if (pre && !hb) hb = hibfile(S.target);
if (pre && !hb) { sh(UMOUNTC + ' ' + q(S.target) + ' >/dev/null 2>&1 </dev/null'); pre = isup(d); }
}
if (pre) how = 'ro';
else if (!hb && bin('ntfsfix') && trim(sh(to + 'ntfsfix -d ' + q('/dev/' + d) + ' >/dev/null 2>&1 </dev/null; echo $?')) == '0') {
if (bin('block')) sh('block mount >/dev/null 2>&1 </dev/null');
if (isup(d)) how = 'rw';
}
if (how == 'no' && tfree()) how = rom() ? 'ro' : hb ? 'no' : 'win';
if (hb) hibset(d, true);
segw(x, how);
let adv = hb ? L('Spegni l\'Avvio Rapido di Windows', 'Turn off Windows Fast Startup') : L('Controllalo da Windows', 'Check it on Windows');
if (told(x) != how) {
if (how == 'rw') ev2('nas_fixed', '🗄️ ' + H + ' ¦ ' + L('Riparato e ricollegato', 'Repaired and reconnected') + ' ¦ ' + L('Riparazione base: fai chkdsk su Windows', 'Basic repair: run chkdsk on Windows'));
else if (how == 'ro') ev2('nas_ntfsro', '⚠️ ' + H + ' ¦ ' + L('Aperto in sola lettura', 'Opened read-only') + ' ¦ ' + adv);
else if (how == 'win') ev2('nas_ntfsno', '⚠️ ' + H + ' ¦ ' + L('Lavori di Windows a metà', 'Windows work left unfinished') + ' ¦ ' + L(WINFIX.it, WINFIX.en));
else noopen(x, adv);
}
push(R, { dev: d, how: how });
}
if (!length(left) || round == 3) break;
if (WAIT > 0) sh('sleep ' + int(WAIT));
bmount();
}
for (let x in T0) {
if (x.done) continue;
if (isup(x.d)) {
if (told(x) != 'no' && told(x) != 'ro') unlink(NT + x.d);
else {
segw(x, 'rw');
ev2('nas_fixed', '🗄️ ' + head(x) + ' ¦ ' + L('Ricollegato', 'Reconnected') + ' ¦ ' + L('Aperto al tentativo ', 'Opened on try ') + x.n);
}
push(R, { dev: x.d, how: 'rw' });
continue;
}
if (!has(SYS + '/class/block/' + x.d)) continue;
segw(x, 'no');
if (told(x) != 'no') noopen(x, L('Staccalo e ricollegalo', 'Unplug it and plug it back'));
push(R, { dev: x.d, how: 'no' });
}
for (let u in U0) if (!isup(u.d) && has(SYS + '/class/block/' + u.d) && !length(filter(mounts(), (m) => m.mnt == u.mnt)))
sh(MOUNTC + ntfsro() + q('/dev/' + u.d) + ' ' + q(u.mnt) + ' >/dev/null 2>&1 </dev/null');
return { open: R, unstale: gone };
}
function ntfsopen() {
if (!lockon(NOL, 600, 0)) return { open: [], busy: true, locked: true };
let r = null;
try { r = ntfsopen1(); } catch (e) { r = { open: [], error: '' + e }; }
lockoff(NOL);
return r;
}
const DMESG = getenv('WF_DMESG');
function usbscan(Ls) {
let u = usbdata(), up = sysup(), ch = false, td = dayof(), J = null, NC = nascfg(), nw = {}, IO = rj(RUN + '/io.json') ?? {};
for (let d in Ls) if (d.usb) {
let p = usbport(d.base);
if (!p) continue;
if (type(u.ids[d.id]) != 'object') u.ids[d.id] = {};
if (u.ids[d.id].port != p) { u.ids[d.id].port = p; ch = true; }
}
let PM = {};
for (let id, o in u.ids) if (o.port) PM[o.port] = id;
let dmf = RUN + '/usbdm.json', dmo = rj(dmf) ?? {}, dmfp = '';
for (let d in Ls) if (d.usb) dmfp += d.id + ':' + d.base + ':' + (stat(SYS + '/class/block/' + d.base)?.inode ?? '') + ':' + (d.mounted ? 1 : 0) + ':' +
((IO[d.base]?.wk ?? [])[0] ?? '') + ':' + trim(readfile(SYS + '/class/block/' + d.base + '/device/ioerr_cnt') ?? '') + ',';
let dmgo = !DMESG && length(PM) && (u.pos == null || dmo.fp != dmfp || time() - (+(dmo.t ?? 0)) >= 120 || time() < +(dmo.t ?? 0));
if (dmgo) { mkdirp(RUN); wjr(dmf, { t: time(), fp: dmfp }); }
let txt = DMESG ? (readfile(DMESG) ?? '') : (dmgo ? sh('dmesg 2>/dev/null | grep -F ' + q(': reset ')) : '');
let pos = +(u.pos ?? 0), np = pos;
for (let l in split(txt, '\n')) {
let m = match(l, /^\[ *([0-9]+)\.[0-9]+\] usb ([0-9]+-[0-9.]+): reset /);
if (!m) continue;
let ts = +m[1];
if (ts <= pos) continue;
if (ts > np) np = ts;
let id = PM[m[2]];
if (!id || ts < 120) continue;
let o = u.ids[id], t = time() - up + ts;
if (type(o.days) != 'object') o.days = {};
if (type(o.list) != 'array') o.list = [];
if (J == null) J = jobs();
let jb = null;
for (let j in J) if (j.state == 'run' && (j.disk == id || j.to_disk == id)) { jb = j.op; break; }
let bs = null;
for (let d in Ls) if (d.id == id) bs = d.base;
let wk = IO[bs]?.wk, sm = sleepcfg().mins;
push(o.list, { t: t, job: jb, reopen_s: null, wake: sm > 0 && type(wk) == 'array' && t >= wk[0] - 30 && t - wk[0] <= 120 && wk[1] >= sm * 60 - 60 });
o.days[dayof(t)] = (o.days[dayof(t)] ?? 0) + 1;
nw[id] = true; ch = true;
}
if (np != pos || u.pos == null) { u.pos = np; ch = true; }
let mt = {};
for (let d in Ls) if (d.mounted) mt[d.id] = true;
for (let id, o in u.ids) {
for (let x in o.list ?? []) if (x.reopen_s == null && mt[id]) { x.reopen_s = max(0, time() - x.t); ch = true; }
let lim = time() - 7 * 86400, L2 = filter(o.list ?? [], (x) => x.t >= lim);
if (length(L2) > 50) L2 = slice(L2, length(L2) - 50);
if (length(L2) != length(o.list ?? [])) { o.list = L2; ch = true; }
for (let k in keys(o.days ?? {})) if (k < dayof(lim)) { delete o.days[k]; ch = true; }
}
if (NC.usb?.alert !== false) for (let id in keys(nw)) {
let nm = id;
for (let d in Ls) if (d.id == id) nm = d.name;
let n = u.ids[id].days?.[td] ?? 1, hub = usbhub(u.ids[id], td);
for (let d in Ls) if (d.id == id && usbpwr(d.base) === true) hub = null;
ev('nas_usbreset', '⚠️ ' + cutn(nm, 24) + ' ¦ ' + L('Porta USB riavviata', 'USB port restarted') + ' ¦ ' + n + (n == 1 ? L(' volta oggi', ' time today') : L(' volte oggi', ' times today')) +
(hub == 'wake' ? L(' · al risveglio: usa un hub USB alimentato', ' · on wake-up: use a powered USB hub') : hub == 'many' ? L(' · usa un hub USB alimentato', ' · use a powered USB hub') : ''));
}
if (ch) { mkdirp(RUN); wjr(RUN + '/usb.json', u); }
let es = stat(USBJ);
if (length(u.ids) && (!es || dayof(es.mtime) != td)) { mkdirp(ETC); wjr(USBJ, { ids: u.ids }); }
}
const HSTEP = 300, HN = 288;
function histstep(Ls) {
let f = RUN + '/hist.json', h = rj(f), t = time(), slot = t - t % HSTEP, zero = []; for (let i = 0; i < HN; i++) push(zero, 0);
if (type(h) != 'object' || type(h.r) != 'array' || length(h.r) != HN || type(h.w) != 'array' || length(h.w) != HN) h = { step: HSTEP, t: slot, r: [ ...zero ], w: [ ...zero ], b: null };
let r = 0, w = 0;
for (let b in uniq(map(filter(Ls, (d) => !d.md), (d) => d.base))) {
let x = split(trim(readfile(SYS + '/class/block/' + b + '/stat') ?? ''), /[ \t]+/);
if (length(x) >= 7) { r += +x[2] * 512; w += +x[6] * 512; }
}
if (h.t == slot && h.b) return;
let n = h.b ? int((slot - h.t) / HSTEP) : 0, dt = h.b ? t - h.b.t : 0;
let vr = dt > 0 && r >= h.b.r ? int((r - h.b.r) / dt) : 0, vw = dt > 0 && w >= h.b.w ? int((w - h.b.w) / dt) : 0;
if (n >= HN) { h.r = [ ...zero ]; h.w = [ ...zero ]; n = 1; }
for (let i = 0; i < n; i++) { shift(h.r); shift(h.w); push(h.r, i == n - 1 ? vr : 0); push(h.w, i == n - 1 ? vw : 0); }
h.t = slot; h.b = { t: t, r: r, w: w };
mkdirp(RUN);
wjr(f, h);
}
const HEALTHJ = ETC + '/nas-health.json';
function healthget() { let o = rj(HEALTHJ); if (type(o) != 'object') o = {}; if (type(o.ids) != 'object') o.ids = {}; if (type(o.month) != 'object') o.month = {}; return o; }
function smtest(b) {
mkdirp(RUN + '/smart');
writefile(RUN + '/smart/' + b + '.test', '' + time());
unlink(RUN + '/smart/' + b + '.testev');
unlink(RUN + '/smart/' + b + '.run');
bg('sh ' + q(JOB) + ' smarttest ' + q(b));
}
function healthday(Ls, io, slp) {
let f = RUN + '/health.json', h = rj(f), td = dayof(), NC = nascfg(), ch = false, E = null;
if (type(h) != 'object' || type(h.ids) != 'object') { h = { d: td, ids: {} }; ch = true; }
if (h.d != td) {
E = healthget();
for (let id, o in h.ids) {
if (type(E.ids[id]) != 'object') E.ids[id] = { temp: [], bad: [] };
let x = E.ids[id];
if (o.min != null) push(x.temp, [ h.d, o.min, o.max ]);
if (o.a) push(x.bad, [ h.d, ...o.a ]);
if (length(x.temp) > 30) x.temp = slice(x.temp, length(x.temp) - 30);
if (length(x.bad) > 30) x.bad = slice(x.bad, length(x.bad) - 30);
}
mkdirp(ETC); wjr(HEALTHJ, E);
let g = {};
for (let id, o in h.ids) g[id] = { g: o.g };
h = { d: td, ids: g }; ch = true;
}
let lt = localtime(), ym = sprintf('%04d-%02d', lt.year, lt.mon), hmn = lt.hour * 60 + lt.min, late = hmn >= 210 && hmn < 420;
for (let d in Ls) {
if (d.md) continue;
let s = smartof(d.base), o = h.ids[d.id];
if (type(o) != 'object') { o = h.ids[d.id] = {}; ch = true; }
if (s.temp != null) {
if (o.min == null || s.temp < o.min) { o.min = s.temp; ch = true; }
if (o.max == null || s.temp > o.max) { o.max = s.temp; ch = true; }
}
if (!s.lk && (s.realloc != null || s.pend != null)) {
let a = [ s.realloc, s.pend, s.unc, s.crc ];
if (sprintf('%J', a) != sprintf('%J', o.a)) { o.a = a; ch = true; }
if (o.g == null) { E = E ?? healthget(); let B = E.ids[d.id]?.bad ?? []; o.g = length(B) ? B[length(B) - 1][1] : s.realloc; }
if (s.realloc != null && o.g != null && s.realloc > o.g && NC.smart?.alert_grow !== false)
ev('nas_smartgrow', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + L('Settori riallocati in aumento', 'Reallocated sectors rising') + ' ¦ ' + o.g + ' → ' + s.realloc + L(' · fai un backup', ' · back it up'));
if (s.realloc != null && s.realloc != o.g) { o.g = s.realloc; ch = true; }
}
let tf = RUN + '/smart/' + d.base + '.test', te = RUN + '/smart/' + d.base + '.testev';
if (has(tf) && (s.test?.res == 'ok' || s.test?.res == 'fail') && trim(readfile(te) ?? '') != trim(readfile(tf) ?? '') && (s.at ?? 0) > +trim(readfile(tf) ?? '0') + 60) {
writefile(te, trim(readfile(tf) ?? ''));
ev('nas_test', (s.test.res == 'ok' ? '🗄️ ' : '⚠️ ') + cutn(d.name, 24) + ' ¦ ' + L('Test S.M.A.R.T.', 'S.M.A.R.T. test') + ' ¦ ' + (s.test.res == 'ok' ? L('Superato', 'Passed') : L('Non superato', 'Failed')));
}
let ch2 = io.N[d.base]?.chg, awake = ch2 != null && (slp.mins == 0 || time() - ch2 < slp.mins * 60);
if (NC.smart?.monthly !== false && late && s.test_ok && bin('smartctl')) {
E = E ?? healthget();
if (E.month[d.id] != ym) {
let rq = +trim(readfile(tf) ?? '0') || 0, ru = +trim(readfile(RUN + '/smart/' + d.base + '.run') ?? '0') || 0;
if (rq > 0 && ru >= rq && substr(dayof(rq), 0, 7) == ym) { E.month[d.id] = ym; mkdirp(ETC); wjr(HEALTHJ, E); }
else if (awake && s.test?.res != 'run' && time() - rq > 900) smtest(d.base);
}
}
}
if (ch) { mkdirp(RUN); wjr(f, h); }
}
const CMSH = '/usr/share/wrtfreedom/cloudmnt.sh';
function ejectgo(D, mn) {
let ED = RUN + '/eject/' + D.id;
mkdirp(RUN + '/eject');
writefile(ED + '.go', '' + time()); writefile(ED + '.run', '' + time());
bg('{ [ -f ' + q(CMSH) + ' ] && sh ' + q(CMSH) + ' disk ' + q(D.id) + ' >/dev/null 2>&1 </dev/null; true; }; WF_EJGO=' + q(ED + '.go') + ' sh ' + q(JOB) + ' eject ' + q(D.base) + ' ' + q(join(' ', svclist())) + ' ' + join(' ', map(mn, q)) + ' > ' + q(ED + '.res.t') + ' 2>/dev/null; mv -f ' + q(ED + '.res.t') + ' ' + q(ED + '.res') +
'; grep -q ok ' + q(ED + '.res') + ' || rm -f ' + q(ED + '.go') + '; rm -f ' + q(ED + '.run'));
}
function ejectstep(Ls) {
let ED = RUN + '/eject/';
for (let f in lsdir(ED) ?? []) {
let m = match(f, /^(.+)\.json$/);
if (!m) continue;
let id = m[1], e = rj(ED + f), rs = trim(readfile(ED + id + '.res') ?? ''), D = null;
for (let d in Ls) if (d.id == id) D = d;
let nm = cutn(e?.name ?? D?.name ?? id, 24);
if (ejectfin(id, Ls)) continue;
if (rs == 'ok') { ev('nas_eject_ok', '🗄️ ' + nm + ' ¦ ' + L('Puoi staccare il disco', 'You can unplug the drive') + ' ¦ ' + L('Lavori finiti', 'Jobs finished')); unlink(ED + f); unlink(ED + id + '.res'); continue; }
if (rs == 'busy') { dlresume(e); ev('nas_eject_err', '⚠️ ' + nm + ' ¦ ' + L('Espelli non riuscito', 'Eject failed') + ' ¦ ' + L('Il disco è ancora in uso', 'The drive is still in use')); unlink(ED + f); unlink(ED + id + '.res'); continue; }
if (has(ED + id + '.run')) continue;
if (type(e) != 'object' || !D || !D.mounted) { dlresume(e); unlink(ED + f); continue; }
let W = filter(jobs(), (j) => (j.state == 'run' || j.state == 'ask') && (j.disk == id || j.to_disk == id)), left = null;
for (let j in W) { let x = jobeta(j); if (x != null && (left == null || x > left)) left = x; }
e.waits = map(W, (j) => j.op); e.left_s = left;
wjr(ED + f, e);
if (length(W) || ntfsbusy()) continue;
ejectgo(D, map(filter(Ls, (x) => x.base == D.base && x.mounted), (x) => x.mnt));
}
}
function lastdisk(Ls) {
let o = rj(RUN + '/last.json'), d = null, n;
for (let x in Ls) if (x.mounted && !d) d = x;
if (d) n = { name: d.name, fs: d.fs, size: d.size, gone: null };
else if (type(o) == 'object') n = { ...o, gone: o.gone ?? time() };
else return;
if (sprintf('%J', n) != sprintf('%J', o)) { mkdirp(RUN); wjr(RUN + '/last.json', n); }
}
function cutstep(Ls) {
for (let c in cuts()) {
let jf = JOBS + '/' + c.id + '.json', j = rj(jf), nm = JOBNAME[c.op] ?? [ c.op, c.op ], w = RUN + '/cut-' + c.id;
let dead = !j || j.state == 'run' || j.state == 'ask';
if (c.op == 'format') {
if (has(w)) continue;
mkdirp(RUN); writefile(w, '' + time());
if (dead) { mkdirp(JOBS); wjr(jf, { id: c.id, op: 'format', disk: c.disk ?? '', to_disk: '', done: 0, total: 4, bytes: 0, bytes_total: 0, file: c.name ?? '', state: 'err',
error: 'Preparazione interrotta: Prepara di nuovo', error_en: 'Preparation interrupted: prepare it again', t0: +(c.t ?? 0), t1: time() }); }
ev('nas_job_err', '⚠️ ' + cutn(c.name ?? L('Disco', 'Drive'), 24) + ' ¦ ' + L('Preparazione interrotta', 'Preparation interrupted') + ' ¦ ' + L('Tocca Prepara di nuovo', 'Tap Prepare again'));
continue;
}
if (index([ 'copy', 'move', 'backup' ], c.op) < 0) { unlink(CUTD + c.id); continue; }
let tid = length(c.to_disk ?? '') ? c.to_disk : c.disk, on = false;
for (let d in Ls) if (d.id == tid && d.mounted && length(c.droot ?? '') && d.mnt == c.droot) on = true;
if (!on) { if (time() - +(c.t ?? 0) > 7 * 86400) unlink(CUTD + c.id); continue; }
if (dead) { mkdirp(JOBS); wjr(jf, { id: c.id, op: c.op, disk: c.disk ?? '', to_disk: c.to_disk ?? '', done: +(j?.done ?? 0), total: +(j?.total ?? 0), bytes: +(j?.bytes ?? 0),
bytes_total: +(j?.bytes_total ?? 0), file: '', state: 'err', error: 'Interrotta: controlla i file', error_en: 'Interrupted: check the files',
t0: +(c.t ?? 0), t1: time() }); }
if (length(c.dst ?? '') && (c.dst == c.droot || substr(c.dst, 0, length(c.droot) + 1) == c.droot + '/'))
bg('find ' + q(c.dst) + ' -xdev -type f -name ' + q('.*.wfcp') + ' -exec rm -f {} \\;');
ev('nas_job_err', '⚠️ ' + L(nm[0], nm[1]) + ' ¦ ' + L('Interrotta', 'Interrupted') + ' ¦ ' + L('Controlla i file in ', 'Check the files in ') + cutn(length(c.drel ?? '') ? c.drel : '/', 40));
unlink(CUTD + c.id);
}
}
function fixseg(dev) { let s = stat(SYS + '/class/block/' + dev); return s ? '' + s.inode : ''; }
function fixmark(dev) { mkdirp(RUN + '/fix'); writefile(RUN + '/fix/' + dev, fixseg(dev)); }
function fixok(d, S) {
if (!needfix(d)) return false;
let cs = badcs(d);
if (trim(readfile(RUN + '/fix/' + d.dev) ?? '') == fixseg(d.dev)) return cs ? { k: 'fail' } : false;
if (!cs && !d.new && time() - (S.now[d.id]?.since ?? 0) >= 120) return false;
if (busy(d.id)) return cs ? { k: 'job' } : false;
if (ntfsbusy() || has(RUN + '/eject/' + d.id + '.run') || has(RUN + '/eject/' + d.id + '.json')) return false;
let PP = {}, H = holders([ d.mnt ], null, PP);
if (!length(H)) return true;
return cs ? { k: 'hold', ...holdnames(H, PP) } : false;
}
function gonestep(NC, Ls, GW) {
let P = rj(RUN + '/gone.json'), U = useof(NC), DS = type(NC.disks) == 'object' ? NC.disks : {}, here = {}, add = {}, del = [], F = null;
if (type(P) != 'object') P = {};
for (let k, v in GW) P[k] = v;
for (let d in Ls) here[d.id] = true;
for (let k, v in P) if (!here[k] && U[k] && type(DS[k]) == 'object' && type(v) == 'object' && !(F ?? (F = fmting(jobs())))[k]) add[k] = v;
for (let k, o in DS) if (here[k] && type(o) == 'object' && o.gone != null) push(del, k);
if (!length(keys(add)) && !length(del)) { if (length(keys(P))) unlink(RUN + '/gone.json'); return; }
let ok = nasput((o) => {
if (type(o.disks) != 'object') return;
for (let k, v in add) if (type(o.disks[k]) == 'object') o.disks[k].gone = v;
for (let k in del) if (type(o.disks[k]) == 'object') delete o.disks[k].gone;
}) != null;
if (ok) unlink(RUN + '/gone.json');
else { mkdirp(RUN); wjr(RUN + '/gone.json', add); }
}
const MNTROOT = getenv('WF_MNTROOT') ?? '/mnt';
function mntclean(M) {
let st = stat(RUN + '/mntclean.t'), now = time();
if (st && now - st.mtime < 3600 && st.mtime <= now + 60) return [];
if (ntfsbusy() || anyfile(RUN + '/eject', /\.(json|run)$/) || length(filter(jobs(), (j) => j.state == 'run' || j.state == 'ask'))) return [];
mkdirp(RUN); writefile(RUN + '/mntclean.t', '' + now);
let keep = {}, R = [], rs = stat(MNTROOT);
if (!rs) return [];
for (let m in M) keep[m.mnt] = true;
for (let s, o in cfg('fstab')) if (type(o) == 'object' && length(o.target ?? '')) keep[o.target] = true;
for (let k, v in (rj(MNTJ) ?? {})) keep['' + v] = true;
for (let f in lsdir(MNTROOT) ?? []) {
if (!match(f, /^(sd[a-z]+[0-9]*|mmcblk[0-9]+p[0-9]+|nvme[0-9]+n[0-9]+p[0-9]+|md[0-9]+|wf-[0-9a-f]{1,8})$/) || lstat(SYS + '/class/block/' + f)) continue;
let p = MNTROOT + '/' + f, s = lstat(p), under = false;
if (!s || s.type != 'directory' || keep[p] || now - s.mtime < 600) continue;
if (s.dev?.major != rs.dev?.major || s.dev?.minor != rs.dev?.minor) continue;
for (let m in M) if (substr(m.mnt, 0, length(p) + 1) == p + '/') under = true;
if (under || length(lsdir(p) ?? [ 'x' ])) continue;
if (rmdir(p)) push(R, p);
}
return R;
}
const DDJ = RUN + '/doppio.json', DDLK = RUN + '/doppio.lk', DDSTOP = RUN + '/doppio.stop', DDREG = '.wf-doppio', DDH = 3600, DDMARG = 67108864;
function ddw(k, it, en) { return { k: k, it: it, en: en }; }
const DDMAIN = ddw('main', 'Disco Principale staccato', 'Main Drive unplugged'), DDGONE = ddw('gone', 'Secondo disco staccato', 'Second drive unplugged'),
DDFULL = ddw('full', 'Secondo disco pieno', 'Second drive full'), DDCUT = ddw('cut', 'Copia interrotta: riprende da sola', 'Copy interrupted: it resumes by itself');
function ddcfg(NC) { let o = (NC ?? nascfg()).doppio; return type(o) == 'object' ? o : {}; }
function ddst() { let o = rj(DDJ); return type(o) == 'object' ? o : {}; }
function ddput(o) { mkdirp(RUN); wjr(DDJ, o); }
function ddrun() { return locked(DDLK, 86400); }
function ddmain(NC, Ls) { let m = mainsaved(NC); return m ? maindisk(m, Ls) : maindef(Ls); }
function ddb(C, Ls) {
if (!length('' + (C.b ?? ''))) return null;
let u = lc('' + (C.buuid ?? ''));
for (let d in Ls) if (d.id == C.b) return d;
if (length(u)) for (let d in Ls) if (lc(d.uuid ?? '') == u) return d;
return null;
}
function ddaok(A) { return !!A && A.mounted && !A.dup; }
function ddwhy(x, A) {
if (!x || !x.mounted) return DDGONE;
if (A && x.base == A.base) return ddw('same', 'Stesso disco del Disco Principale', 'Same drive as the Main Drive');
if (x.dup) return ddw('dup', 'UUID doppio', 'Duplicate UUID');
if (x.ro || x.lock) return ddw('ro', 'In sola lettura', 'Read-only');
return null;
}
function ddmnt(d) { return length(filter(mounts(), (m) => m.mnt == d.mnt && m.dev == '/dev/' + d.dev)) > 0; }
function ddfree(d) { let v = vfs(d.mnt); return v?.free != null ? +v.free : 1e18; }
function ddev(e, nm) {
if (e.k == 'full') evn('nas_full', '⚠️ ' + cutn(nm ?? '', 24) + ' ¦ ' + L('Disco Doppio: spazio finito', 'Mirrored Drive: drive full') + ' ¦ ' + L('Copia ferma, niente cancellato', 'Copy stopped, nothing deleted'));
else evn('nas_job_err', '⚠️ ' + L('Disco Doppio', 'Mirrored Drive') + ' ¦ ' + L(e.it, e.en) + ' ¦ ' +
(e.k == 'gone' ? L('La copia riprende quando torna', 'The copy resumes when it is back') : L('Niente cancellato', 'Nothing deleted')));
}
function ddfail(S, e, nm) {
S.state = 'err'; S.err = e;
if (e.k != 'main' && S.ev != e.k) { ddev(e, nm); S.ev = e.k; }
return S;
}
function ddgo() { bg('umask 022; ucode -e ' + q('loadfile(' + sprintf('%J', NASUC) + ')().dcopy();')); }
function mdstat() {
let R = [], cur = null;
for (let l in split(readfile(PROC + '/mdstat') ?? '', '\n')) {
let h = match(l, /^(md[0-9]+) : ([a-z-]+)( \(auto-read-only\)| \(read-only\))? ?([a-z0-9]*)/);
if (h) { cur = { dev: h[1], level: length(h[4]) && !match(h[4], /^sd|^nvme|^mmc/) ? h[4] : '', n: 0, up: 0, state: h[2] == 'active' ? 'ok' : 'inactive', pct: null }; push(R, cur); continue; }
if (!cur) continue;
let c = match(l, /\[([0-9]+)\/([0-9]+)\] \[([U_]+)\]/);
if (c) { cur.n = +c[1]; cur.up = +c[2]; if (cur.state == 'ok' && cur.up < cur.n) cur.state = 'degraded'; }
let p = match(l, /(recovery|resync|reshape|check) *= *([0-9.]+)%/);
if (p) { cur.pct = +p[2]; if (p[1] != 'check' && cur.state != 'inactive') cur.state = 'rebuild'; }
if (!length(trim(l))) cur = null;
}
return R;
}
function ddget(NC, Ls) {
let C = ddcfg(NC), S = ddst(), on = C.on === true, A = ddmain(NC, Ls), now = time();
let run = ddrun() || (S.state == 'run' && now - +(S.t0 ?? 0) < 15), cand = [], okn = 0;
for (let d in Ls) {
if (A && d.id == A.id) continue;
let w = ddwhy(d, A);
push(cand, { id: d.id, ok: !w, why_it: w?.it ?? '', why_en: w?.en ?? '' });
if (!w) okn++;
}
let e = on && !run ? (S.state == 'run' ? DDCUT : (S.state == 'err' ? S.err : null)) : null, B = on ? ddb(C, Ls) : null, ok = ddaok(A) && okn > 0;
return { on: on, b: on ? (B?.id ?? C.b ?? null) : null, name: on ? (B?.name ?? C.name ?? null) : null, state: run ? 'run' : (e ? 'err' : 'idle'),
last: S.last ?? 0, next: on ? (+(S.next ?? 0) > now ? +S.next : (!run && +(S.wd ?? 0) > now ? +S.wd : now)) : 0, err_it: e?.it ?? '', err_en: e?.en ?? '',
n: S.n ?? 0, del: S.del ?? 0, skip: S.skip ?? 0, ok: ok,
why_it: ok ? '' : (ddaok(A) ? 'Collega un secondo disco scrivibile' : 'Scegli prima il Disco Principale'),
why_en: ok ? '' : (ddaok(A) ? 'Connect a second writable drive' : 'Choose the Main Drive first'), cand: cand, md: mdstat() };
}
const DDMAX = +(getenv('WF_DDMAX') ?? 100000) || 100000, DDLOGN = 200, DDHP = 1099511627689;
const DDMANY = ddw('many', 'Troppi file: copiati solo i primi ' + DDMAX, 'Too many files: only the first ' + DDMAX + ' copied');
function ddreg(RD, aid) {
let R = rj(RD + '/copie.json'), nl = 0;
if (type(R) != 'object' || R.a != aid || type(R.f) != 'object' || type(R.d) != 'object') return { R: { v: 2, a: aid, f: {}, d: {} }, base: true, nl: 0 };
for (let l in split(readfile(RD + '/copie.log') ?? '', '\n')) {
if (!length(l)) continue;
let x = null;
try { x = json(l); } catch (e) { x = null; }
if (type(x) != 'array' || type(x[1]) != 'string') continue;
nl++;
if (x[0] == 'f' && length(x) == 6) R.f[x[1]] = slice(x, 2);
else if (x[0] == '-f') delete R.f[x[1]];
else if (x[0] == 'd') R.d[x[1]] = 1;
else if (x[0] == '-d') delete R.d[x[1]];
}
return { R: R, base: false, nl: nl };
}
function ddsync(A, B, S) {
let ra = A.mnt, rb = B.mnt, RD = rb + '/' + DDREG, r = { n: 0, del: 0, skip: 0, fail: 0 };
let a0 = lstat(ra);
if (!a0 || !ddmnt(A)) return { ...r, e: DDMAIN };
if (!ddmnt(B)) return { ...r, e: DDGONE };
let same = (s, z) => s.dev?.major == z.dev?.major && s.dev?.minor == z.dev?.minor;
let F = [], DS = [], st = [ '' ], all = true, many = false, h = 0;
let hv = (v) => { h = (h * 1000003 + v % DDHP) % DDHP; };
while (length(st) && !many) {
let rel = pop(st), Lx = lsdir(length(rel) ? ra + '/' + rel : ra);
if (Lx == null) { all = false; continue; }
for (let n in sort(Lx)) {
if (!length(rel) && (substr(n, 0, 4) == '.wf-' || n == 'lost+found')) continue;
let p = length(rel) ? rel + '/' + n : n, s = lstat(ra + '/' + p);
if (!s || !same(s, a0)) continue;
if (s.type == 'directory') { push(DS, p); push(st, p); hv(s.mtime + length(p)); }
else if (s.type == 'file') {
if (length(F) >= DDMAX) { many = true; all = false; break; }
push(F, [ p, s.size, s.mtime ]); hv(s.size + s.mtime + length(p));
}
}
}
if (!ddmnt(A)) return { ...r, e: DDMAIN };
if (!ddmnt(B)) return { ...r, e: DDGONE };
let fp = sprintf('%s|%s|%d|%d|%d', A.id, B.id, length(F), length(DS), h), fz = +(S.fz ?? 0), now = time();
r.fp = fp;
if (S.fp == fp && fz <= now + 60 && now - fz < 86400) return { ...r, skip: S.skip ?? 0, same: true, ...(many ? { e: DDMANY } : {}) };
if (match(S.tmp ?? '', /\/\.wfdd-[0-9a-z]+\.tmp$/) && substr(S.tmp, 0, length(rb) + 1) == rb + '/') unlink(S.tmp);
let b0 = lstat(rb);
if (!b0) return { ...r, e: DDGONE };
let G = ddreg(RD, A.id), R = G.R, base = G.base, nl = G.nl, LB = [];
let flush = () => {
if (!length(LB) || !ddmnt(B)) return;
mkdirp(RD);
let n = nl + length(LB);
if (base || (n > 2000 && n > length(R.f))) { wjr(RD + '/copie.json', R); unlink(RD + '/copie.log'); base = false; nl = 0; }
else { let fh = open(RD + '/copie.log', 'a'); if (fh) { fh.write(join('\n', LB) + '\n'); fh.close(); } nl = n; }
LB = [];
};
let lg = (x) => { push(LB, sprintf('%J', x)); if (length(LB) >= DDLOGN) flush(); };
let bfat = B.fs == 'fat32' || B.fs == 'exfat';
let tq = (x, y) => { let d = x - y; if (d < 0) d = -d; return d == 0 || (bfat && (d <= 2 || (d >= 3598 && d <= 3602))); };
let isc = (b, e) => !!b && b.type == 'file' && b.size == e[2] && tq(b.mtime, e[3]);
if (all) {
let seen = {};
for (let f in F) seen[f[0]] = true;
for (let p in keys(R.f)) {
if (seen[p] || lstat(ra + '/' + p) != null) continue;
let e = R.f[p], b = lstat(rb + '/' + p);
if (isc(b, e) && unlink(rb + '/' + p)) r.del++;
delete R.f[p]; lg([ '-f', p ]);
}
for (let p in sort(keys(R.d), (x, y) => length(y) - length(x))) {
if (lstat(ra + '/' + p) != null) continue;
let b = lstat(rb + '/' + p);
if (b && b.type == 'directory') rmdir(rb + '/' + p);
delete R.d[p]; lg([ '-d', p ]);
}
}
let bad = {}, inbad = (p) => { for (let i = rindex(p, '/'); i > 0; i = rindex(substr(p, 0, i), '/')) if (bad[substr(p, 0, i)]) return true; return false; };
for (let p in DS) {
if (inbad(p)) { bad[p] = true; continue; }
let bp = rb + '/' + p, b = lstat(bp), e = R.f[p];
if (b && b.type != 'directory') {
if (e && isc(b, e) && unlink(bp)) { delete R.f[p]; lg([ '-f', p ]); b = null; }
else { bad[p] = true; r.skip++; continue; }
}
if (!b) {
if (!mkdir(bp)) { bad[p] = true; r.fail++; continue; }
R.d[p] = 1; lg([ 'd', p ]); b = lstat(bp);
}
if (!b || !same(b, b0)) bad[p] = true;
}
let fat = B.fs == 'fat32', free = ddfree(B);
for (let f in F) {
let p = f[0];
if (has(DDSTOP)) { r.stop = true; break; }
if (inbad(p)) { r.skip++; continue; }
let bp = rb + '/' + p, b = lstat(bp), e = R.f[p];
if (b) {
if (!(e && isc(b, e))) { if (e) { delete R.f[p]; lg([ '-f', p ]); } r.skip++; continue; }
if (e[0] == f[1] && e[1] == f[2]) continue;
}
if (fat && f[1] > FATMAX) { r.skip++; continue; }
if (f[1] + DDMARG > free) { r.e = DDFULL; break; }
let t = dname(bp) + '/.wfdd-' + ME + '.tmp', ap = ra + '/' + p;
S.tmp = t; ddput(S);
let ok = trim(sh('{ cp -p ' + q(ap) + ' ' + q(t) + ' || cp ' + q(ap) + ' ' + q(t) + '; } >/dev/null 2>&1 </dev/null && echo ok')) == 'ok', c = ok ? lstat(t) : null;
if (c && c.size != f[1]) { unlink(t); r.skip++; r.retry = true; continue; }
if (!c || !rename(t, bp)) {
unlink(t);
if (!ddmnt(A)) { r.e = DDMAIN; break; }
if (!ddmnt(B)) { r.e = DDGONE; break; }
free = ddfree(B);
if (f[1] + DDMARG > free) { r.e = DDFULL; break; }
r.fail++; continue;
}
R.f[p] = [ f[1], f[2], c.size, c.mtime ]; lg([ 'f', p, f[1], f[2], c.size, c.mtime ]);
free -= f[1];
if (++r.n % 200 == 0) free = ddfree(B);
}
delete S.tmp;
flush();
if (!r.e && !r.stop && r.fail) r.e = ddw('fail', r.fail + ' file non copiati', r.fail + ' files not copied');
if (!r.e && many) r.e = DDMANY;
return r;
}
function dcopy() {
if (!lockon(DDLK, 86400, 0)) return { busy: true };
let NC = nascfg(), C = ddcfg(NC);
if (C.on !== true) { unlink(DDSTOP); lockoff(DDLK); return { off: true }; }
unlink(DDSTOP);
let Ls = disks(true).list, A = ddmain(NC, Ls), B = ddb(C, Ls), S = ddst(), now = time();
S.state = 'run'; S.t0 = now; S.next = now + DDH; delete S.wd; ddput(S);
let r = !ddaok(A) ? { e: DDMAIN } : (ddwhy(B, A) ? { e: ddwhy(B, A) } : ddsync(A, B, S));
if (!r.same) {
S.n = r.n ?? 0; S.del = r.del ?? 0; S.skip = r.skip ?? 0;
if (r.fp && !r.stop && !r.fail && !r.retry && (!r.e || r.e.k == 'many')) { S.fp = r.fp; S.fz = time(); }
else { delete S.fp; delete S.fz; }
}
delete S.tmp;
if (r.stop) { S.state = 'idle'; S.next = 0; delete S.err; unlink(DDSTOP); }
else if (r.e) ddfail(S, r.e, B?.name ?? C.name);
else { S.state = 'idle'; S.last = time(); delete S.err; delete S.ev; }
ddput(S);
lockoff(DDLK);
return r;
}
function ddawake(A) {
let b = A.base, slp = sleepcfg();
if (trim(readfile(SYS + '/block/' + b + '/removable') ?? '') == '1' || slp.mins == 0 || keepnow(slp)) return true;
let p = rj(RUN + '/io.json')?.[b], x = split(trim(readfile(SYS + '/class/block/' + b + '/stat') ?? ''), /[ \t]+/);
if (type(p) != 'object' || p.chg == null || length(x) < 7) return false;
return +x[2] * 512 != p.r || +x[6] * 512 != p.w || time() - p.chg < slp.mins * 60;
}
function awake(k) {
let A = ddmain(nascfg(), disks().list);
if (!A || !A.mounted || !ddawake(A)) return false;
if (!length(k ?? '')) return true;
let x = split(trim(readfile(SYS + '/class/block/' + A.base + '/stat') ?? ''), /[ \t]+/);
return length(x) < 7 || trim(readfile(k) ?? '') != A.base + ' ' + x[2] + ' ' + x[6];
}
const DDDAY = 86400;
function doppiostep(NC, Ls) {
let C = ddcfg(NC);
if (C.on !== true || ddrun()) return;
let S = ddst(), now = time(), nx = +(S.next ?? 0);
if (nx > now && nx <= now + DDH + 60) return;
let A = ddmain(NC, Ls), B = ddb(C, Ls), e = !ddaok(A) ? DDMAIN : ddwhy(B, A), o = sprintf('%J', S);
if (e) { delete S.wd; ddfail(S, e, B?.name ?? C.name); if (sprintf('%J', S) != o) ddput(S); return; }
for (let d in [ A, B ]) if (busy(d.id) || has(RUN + '/eject/' + d.id + '.run') || has(RUN + '/eject/' + d.id + '.json')) return;
let t0 = +(S.t0 ?? S.last ?? 0), dl = t0 + DDDAY;
if (t0 > 0 && t0 <= now + 60 && dl > now && !ddawake(A)) {
if (S.state == 'err' && index([ 'main', 'gone', 'same', 'dup', 'ro' ], S.err?.k) >= 0) { S.state = 'idle'; delete S.err; }
S.wd = dl;
if (sprintf('%J', S) != o) ddput(S);
return;
}
S.state = 'run'; S.t0 = now; S.next = now + DDH; delete S.wd; ddput(S);
ddgo();
}
function watch() {
renames();
let D = disks(true), Ls = D.list, S = seen(Ls, true), A = rj(RUN + '/alert.json') ?? {}, N = {}, fc = '', FX = [], NC = nascfg(), on = NC.on === true, nt = NC.adv?.noatime === true, A0 = sprintf('%J', A);
let us = stat(RUN + '/unstale.t');
if (length(stale(D.M)) && (!us || time() - us.mtime > 120)) { mkdirp(RUN); writefile(RUN + '/unstale.t', '' + time()); bg('sh ' + q(JOB) + ' ntfsopen'); }
else if (fixon() && !ntfsbusy() && !length(filter(lsdir(JOBS) ?? [], (f) => substr(f, -5) == '.json' && rj(JOBS + '/' + f)?.state == 'run'))) {
let ot = stat(RUN + '/open.t');
if ((!ot || time() - ot.mtime >= 60 || ot.mtime > time() + 60) && length(filter(opentodo(D.M, cfg('fstab')), (x) => segof(x.d, x.u) == null))) {
mkdirp(RUN); writefile(RUN + '/open.t', '' + time()); bg('sh ' + q(JOB) + ' ntfsopen');
}
}
cutstep(Ls);
let GW = {}, EJ = [];
for (let id, o in S.old) {
if (S.now[id] || (o.miss ?? 0) < 1) continue;
let ej = RUN + '/ejected/' + (o.base ?? ''), sf = length(o.base ?? '') > 0 && has(ej);
GW[id] = { t: time(), safe: sf, name: o.name ?? id };
if (o.mnt && !sf) ev('nas_unsafe', '🗄️ ' + cutn(o.name, 24) + ' ¦ ' + L('Staccato senza Espelli', 'Unplugged without Eject') + ' ¦ ' + L('Prima tocca Espelli Disco', 'Tap Eject Drive first'));
push(EJ, ej);
}
for (let ej in EJ) unlink(ej);
gonestep(NC, Ls, GW);
mainstep(NC, Ls);
doppiostep(NC, Ls);
for (let d in Ls) {
let a = A[d.id] ?? {};
if (d.mounted && d.size > 0 && d.used != null) {
let pc = int(d.used * 100 / d.size), lv = pc >= PCFULL ? 2 : (pc >= PCWARN ? 1 : (pc < PCWARN - 5 ? 0 : (a.full ?? 0)));
if (lv > (a.full ?? 0)) ev(lv == 2 ? 'nas_full' : 'nas_almost', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + (lv == 2 ? L('Spazio finito', 'Drive full') : L('Spazio quasi finito', 'Space almost full')) + ' ¦ ' + pc + L('% usato · ', '% used · ') + gb(d.free) + L(' liberi', ' free'));
a.full = lv;
}
let s = d.md ? {} : smartof(d.base), lk = s.lk === true, bn = lk ? 0 : (s.bad ?? 0) - (s.realloc ?? 0), bad = s.ok === false || bn > 0;
if (bad && (!a.bad || bn > (a.badu ?? 0))) ev('nas_failing', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + L('Si sta rovinando', 'Drive is failing') + ' ¦ ' + L('Fai subito un backup', 'Back it up now'));
if (lk && !bad && !a.lnk) ev('nas_usbreset', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + L('Problemi di collegamento USB', 'USB connection problems') + ' ¦ ' + L('Cavo, box o alimentazione', 'Cable, enclosure or power'));
a.lnk = lk;
a.bad = bad; a.badn = lk ? 0 : s.bad ?? 0; a.badu = bn;
if (s.temp != null) {
if (s.temp >= HOTC && !a.hot) ev('nas_hot', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + L('Troppo caldo', 'Too hot') + ' ¦ ' + s.temp + ' °C');
a.hot = s.temp >= HOTC || (a.hot && s.temp >= HOTC - 5);
}
let hib = false;
if (d.fs == 'ntfs' && d.mounted) {
hib = hibof(d.dev);
if (hib == null) {
hib = hibfile(d.mnt);
hibset(d.dev, hib);
if (hib) ev('nas_ntfsro', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + L('Windows in ibernazione', 'Windows hibernated') + ' ¦ ' + L('Spegni l\'Avvio Rapido di Windows', 'Turn off Windows Fast Startup'));
}
}
d.hib = hib === true;
let fx = on && fixok(d, S);
if (type(fx) == 'object') {
let k = fx.k + ':' + fixseg(d.dev);
if (a.cs != k) ev('nas_ntfsno', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + L('Nomi dei file con accenti illeggibili', 'File names with accents unreadable') + ' ¦ ' +
(fx.k == 'hold' ? L('In uso da ' + join(', ', fx.I) + ': lo sistemo appena è libero', 'In use by ' + join(', ', fx.E) + ': fixed as soon as it is free') :
fx.k == 'job' ? L('Lavoro in corso: lo sistemo alla fine', 'Job running: fixed when it ends') : L('Non rimontato: staccalo e ricollegalo', 'Not remounted: unplug it and plug it back')));
a.cs = k;
fx = false;
}
else if (!badcs(d)) delete a.cs;
if (fx) push(FX, d);
if (!fx && (d.lock || hib) && d.mounted && !d.ro) {
let rn = +(a.rofn ?? 0), rd = time() - +(a.roft ?? 0);
if (!(a.rofail && rn > 0 && rd >= 0 && rd < RETRYW[(rn < length(RETRYW) ? rn : length(RETRYW)) - 1])) {
let ok = remount(d, true, 5000);
if (ok === false && !a.rofail) ev('nas_rofail', '⚠️ ' + cutn(d.name, 24) + ' ¦ ' + L('Sola Lettura non attiva', 'Read Only not active') + ' ¦ ' + L('Staccalo e ricollegalo', 'Unplug it and plug it back'));
a.rofail = ok === false;
if (a.rofail) { a.rofn = rn + 1; a.roft = time(); } else { delete a.rofn; delete a.roft; }
}
}
else { a.rofail = false; delete a.rofn; delete a.roft; }
if (nt && d.mounted && !d.ro && !d.lock && !d.hib && index(split(d.opts, ','), 'noatime') < 0) {
if (!a.noat) bg(MOUNTC + ' -o remount,noatime ' + q(d.mnt) + ' >/dev/null 2>&1');
a.noat = true;
}
else a.noat = false;
fc += fstabcmd(d, on);
N[d.id] = a;
}
if (length(fc)) {
let fl = RUN + '/fstab.last', fo = rj(fl) ?? {}, fd = time() - +(fo.t ?? 0);
if (fo.c == fc && fd >= 0 && fd < 3600) {
if (!fo.lg) { sh('logger -t wrtfreedom ' + q('NAS: sezione dei dischi in fstab cambiata da un altro programma, la riscrivo fra un\'ora') + ' >/dev/null 2>&1 </dev/null'); fo.lg = true; wjr(fl, fo); }
}
else { sh(fc); mkdirp(RUN); wjr(fl, { c: fc, t: time() }); }
}
for (let d in FX) { fixmark(d.dev); bg(fixcmd(d, d.lock || d.hib)); }
if (!length(FX)) mntsync(Ls);
let kl = join('\n', map(filter(Ls, (d) => d.mounted && !d.ro && !d.lock && !d.md && !d.hib), (d) => d.mnt));
if (kl != (readfile(RUN + '/keep.list') ?? '')) writefile(RUN + '/keep.list', kl);
if (sprintf('%J', N) != A0) { mkdirp(RUN); wjr(RUN + '/alert.json', N); }
smartbg(Ls);
let sc = nascfg().sleep;
if (type(sc) == 'object') {
let sl = sleepcfg(), B = idleb(Ls);
if (trim(readfile(RUN + '/hdidle') ?? '') != join(' ', sort(B)) + ' ' + sl.mins + ' ' + (kall(sl) ? 1 : 0)) hdidle(Ls, sl.mins, kall(sl));
}
lastdisk(Ls);
ejectstep(Ls);
usbscan(Ls);
histstep(Ls);
healthday(Ls, iostat(map(Ls, (d) => d.base)), sleepcfg());
let mc = mntclean(D.M);
return { disks: length(Ls), ...(length(mc) ? { mnt_clean: mc } : {}) };
}

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

if (global.ARGV?.[0] == 'awake') { print(awake(global.ARGV?.[1]) ? '1\n' : '0\n'); exit(0); }

return {
nas_state: { args: {}, call: function() { return state(); } },
nas_set: { args: { on: true, speed_mode: 'x', speed_forget: 'x' }, call: function(req) {
let sm = req.args?.speed_mode, sf = req.args?.speed_forget;
if (sf != null) {
if (!match('' + sf, /^[A-Za-z0-9][A-Za-z0-9-]*$/) || length('' + sf) > 64) return err('Disco non valido', 'Invalid drive');
if (!speedforget(sf)) return nbusy();
if (sm == null && req.args?.on == null) return { ok: true, speed_forget: sf };
}
if (sm != null) {
sm = spnew(sm);
if (index(SPM, sm) < 0) return err('Velocità non valida: auto, prudente, media o massima', 'Invalid speed: auto, prudente, media or massima');
if (spmode(nascfg()) != sm && nasput((o) => { if (sm == 'auto') delete o.speed_mode; else o.speed_mode = sm; }) == null) return nbusy();
if (req.args?.on == null) return sf != null ? { ok: true, speed_mode: sm, speed_forget: sf } : { ok: true, speed_mode: sm };
}
if (req.args?.on == null) return err('Scegli acceso o spento', 'Choose on or off');
let on = !!req.args.on, S = svclist(true), off = ETC + '/nas-off.list', c = '';
if (nasput((o) => { o.on = on; }) == null) return nbusy();
let fc = '', Ls = disks().list;
for (let d in Ls) fc += fstabcmd(d, on);
if (length(fc)) sh(fc);
if (on && !anonmount()) c += 'block mount >/dev/null 2>&1; ';
let FX = on && !ntfsbusy() ? filter(Ls, (d) => needfix(d) && !busy(d.id) && !has(RUN + '/eject/' + d.id + '.run') && !has(RUN + '/eject/' + d.id + '.json')) : [];
if (length(FX)) {
if (length(S)) c += 'for s in ' + join(' ', S) + '; do ' + q(INITD) + '$s running >/dev/null 2>&1 && ' + q(INITD) + '$s stop; done; ';
for (let d in FX) { fixmark(d.dev); c += fixcmd(d, d.lock || hibof(d.dev) === true); }
}
if (on) {
let W = filter(split(trim(readfile(off) ?? ''), /[ \t\n]+/), (s) => index(S, s) >= 0);
if (!length(W)) W = S;
for (let s in W) c += q(INITD + s) + ' enable; ' + q(INITD + s) + ' start; ';
c += 'rm -f ' + q(off);
}
else {
mkdirp(ETC);
if (length(S)) c += 'L=; for s in ' + join(' ', S) + '; do ' + q(INITD) + '$s running >/dev/null 2>&1 && L="$L $s"; ' + q(INITD) + '$s stop; ' + q(INITD) + '$s disable; done; echo $L > ' + q(off);
}
if (length(c)) bg(c);
let r = { ok: true, on: on };
if (sm != null) r.speed_mode = sm;
if (sf != null) r.speed_forget = sf;
return r;
} },
nas_disk: { args: { act: 'x', id: 'x', name: 'x', fs: 'x', confirm: 'x', on: true, ro: true, when: 'x', bg: true, move: true }, call: function(req) {
let a = req.args ?? {}, act = '' + (a.act ?? '');
if (act == 'main_state') return riord({ act: 'state' });
let D = diskby(a.id);
if (!D) return err('Disco non trovato', 'Drive not found');
if (D.dup) return duperr();
if (act == 'main' || act == 'main_plan') {
if (!mainok(D)) return err('Serve un disco collegato e scrivibile', 'Needs a connected, writable drive', { code: 'main_ro' });
let NC = nascfg(), Ls = disks().list, m = mainsaved(NC), old = maindisk(m, Ls), mv = !!old && old.id != D.id && hasusers(old);
if (m?.id == D.id) return act == 'main' ? { ok: true, main: D.id } : { ok: true, main: D.id, move: false, items: [] };
let DC = ddcfg(NC);
if (DC.on === true && ddb(DC, Ls)?.id == D.id)
return err('Spegni prima il Disco Doppio: questo disco tiene le sue copie', 'Turn off Mirrored Drive first: this drive holds its copies', { code: 'doppio', b: D.id });
if (act == 'main_plan') {
if (!mv) return { ok: true, main: m?.id ?? null, to: D.id, move: false, items: [] };
let p = riord({ act: 'plan', to: D.id, uuid: D.uuid ?? '' });
return type(p) == 'object' && p.error != null ? p : { ...(type(p) == 'object' ? p : {}), ok: true, main: m.id, to: D.id, move: true };
}
if (mv && type(a.move) != 'bool')
return err('Scegli se spostare Utenti sul nuovo Disco Principale', 'Choose whether to move Utenti to the new Main Drive', { code: 'move', from: old.id, to: D.id });
if (mv && a.move) {
if (busy(old.id) || busy(D.id)) return err('Il disco sta lavorando: aspetta la fine o ferma il lavoro', 'The drive is busy: wait or stop the job');
let r = riord({ act: 'go', to: D.id, uuid: D.uuid ?? '' });
return type(r) == 'object' && r.error != null ? r : { ...(type(r) == 'object' ? r : {}), ok: true, move: true, from: old.id, to: D.id };
}
if (nasput((o) => { o.main = { id: D.id, uuid: D.uuid ?? '' }; }) == null) return nbusy();
bg('sh ' + q(NVSH) + ' tick; sh ' + q(NVSH) + ' follow');
return { ok: true, main: D.id, move: false };
}
let dput = (x) => nasput((o) => { if (type(o.disks) != 'object') o.disks = {}; o.disks[D.id] = { ...(type(o.disks[D.id]) == 'object' ? o.disks[D.id] : {}), ...x }; });
if (act == 'ro') {
if (type(a.on) != 'bool') return err('Scegli acceso o spento', 'Choose on or off');
if (a.on && maindisk(mainsaved(nascfg()), [ D ]) != null)
return err('È il Disco Principale: prima scegline un altro', 'It is the Main Drive: choose another one first', { code: 'main' });
if (!a.on && busy(D.id)) return err('Il disco sta lavorando: aspetta la fine o ferma il lavoro', 'The drive is busy: wait or stop the job');
let dz = () => err('Windows non ha chiuso bene il disco: resta in sola lettura', 'Windows did not close the drive properly: it stays read-only', { code: 'dirty', ro: true });
if (!a.on && dirtyof(D) === true) return dz();
if (!a.on && D.fs == 'ntfs' && hibof(D.dev) === true)
return err('Windows è in ibernazione su questo disco: spegni l\'Avvio Rapido di Windows', 'Windows is hibernated on this drive: turn off Windows Fast Startup', { code: 'hib', ro: true });
if (dput({ ro: a.on }) == null) return nbusy();
D.lock = a.on;
let c = fstabcmd(D, nascfg().on === true);
if (length(c)) sh(c);
let fixed = false;
if (needfix(D) && !busy(D.id) && !length(holders([ D.mnt ]))) {
fixmark(D.dev); fixed = true;
mkdirp(RUN + '/remount');
bgwait(fixcmd(D, a.on) + 'echo ok', RUN + '/remount/fix-' + replace(D.id, /[^A-Za-z0-9_-]/g, '_'), 8000);
D = diskby(D.id) ?? D;
}
let ok = fixed && D.mounted && D.ro == a.on ? true : remount(D, a.on);
if (ok == null) return err('Scelta salvata, ma il disco non risponde: vale dal prossimo collegamento', 'Choice saved, but the drive is not responding: it applies from the next connection', { saved: true, code: 'slow' });
if (!ok && a.on) return err('Sola Lettura salvata, ma il disco è in uso: vale dal prossimo collegamento', 'Read Only saved, but the drive is busy: it applies from the next connection', { saved: true });
if (!ok && D.fs == 'ntfs' && length(filter(split(sh('dmesg 2>/dev/null | tail -n 30'), '\n'), (l) => index(l, 'ntfs3') >= 0 && (index(l, D.dev + ':') >= 0 || index(l, D.dev + ')') >= 0) && index(l, 'dirty') >= 0))) {
dput({ ro: true });
D.lock = true;
c = fstabcmd(D, nascfg().on === true);
if (length(c)) sh(c);
let s = stat(SYS + '/class/block/' + D.dev);
if (s) { mkdirp(RUN + '/dirty'); writefile(RUN + '/dirty/' + D.dev, '' + s.inode); }
return dz();
}
if (!ok) return err('Il disco non si può scrivere con questo router', 'This router cannot write to this drive', { saved: true });
return { ok: true, ro: a.on };
}
if (act == 'known') {
let x = { known: true }, n = trim('' + (a.name ?? ''));
if (length(n)) { if (length(n) > 40 || badname(n)) return err('Nome non valido', 'Invalid name'); x.name = n; }
if (dput(x) == null) return nbusy();
return { ok: true, new: false, ...(length(n) ? { name: n } : {}) };
}
if (act == 'mount' || act == 'retry' || act == 'mountro') {
if (D.mounted) return { ok: true, mounted: true };
unlink(RUN + '/ejected/' + D.base);
if (!(act == 'mountro' || (act == 'mount' && a.ro === true))) {
unlink(RUN + '/ntfs/' + D.dev);
bg('sh ' + q(JOB) + ' ntfsopen');
return { ok: true, bg: true };
}
let tg = tgtof(D);
for (let m in mounts()) if (m.mnt == tg) return err('Cartella di montaggio già in uso', 'Mount folder already in use');
mkdirp(tg);
let n3 = D.fs == 'ntfs' && !ntfs3k(), op = n3 ? 'ro,umask=0000' : wantop(D, true);
sh((bin('timeout') ? 'timeout 20 ' : '') + MOUNTC + (D.fs == 'ntfs' ? (n3 ? ' -t ntfs-3g' : ' -t ntfs3') : '') + ' -o ' + op + ' ' + q('/dev/' + D.dev) + ' ' + q(tg) + ' >/dev/null 2>&1 </dev/null');
let up = false;
for (let m in mounts()) if (m.dev == '/dev/' + D.dev) up = true;
if (!up) return err('Disco non montato: controllalo da un computer', 'Drive not mounted: check it on a computer');
mntsync();
return { ok: true, ro: true, mounted: true };
}
if (act == 'eject_cancel') {
let e = ejectof(D.id);
if (!e) return { ok: true };
unlink(RUN + '/eject/' + D.id + '.json');
dlresume(e);
return { ok: true };
}
if (act == 'eject' && a.when == 'end') {
if (!length(filter(disks().list, (x) => x.base == D.base && x.mounted))) return err('Disco già staccato', 'Drive already unmounted');
let W = filter(jobs(), (j) => (j.state == 'run' || j.state == 'ask') && (j.disk == D.id || j.to_disk == D.id));
if (length(W)) {
let e = ejectof(D.id) ?? { name: D.name, since: time(), waits: [], stopped: [], left_s: null }, left = null;
if (nascfg().dl?.disk == D.id && index(e.stopped, 'dl') < 0) { let G = dlpause(); if (G != null) { push(e.stopped, 'dl'); e.gids = G; } }
for (let j in W) { let x = jobeta(j); if (x != null && (left == null || x > left)) left = x; }
e.waits = map(W, (j) => j.op); e.left_s = left;
mkdirp(RUN + '/eject');
wjr(RUN + '/eject/' + D.id + '.json', e);
return { ok: true, wait: true, waits: e.waits, left_s: left, stopped: e.stopped };
}
}
if (act == 'name') {
let n = trim('' + (a.name ?? ''));
if (!length(n) || length(n) > 40 || badname(n)) return err('Nome non valido', 'Invalid name');
if (nasput((o) => { if (type(o.disks) != 'object') o.disks = {}; o.disks[D.id] = { ...(o.disks[D.id] ?? {}), name: n }; }) == null) return nbusy();
return { ok: true, name: n };
}
let J = busy(D.id);
if (J) return err('Il disco sta lavorando: aspetta la fine o ferma il lavoro', 'The drive is busy: wait or stop the job', { job: J.id });
if ((act == 'check' || act == 'format' || act == 'eject') && ntfsbusy())
return err('Il router sta ricollegando i dischi: riprova tra poco', 'The router is reconnecting the drives: try again shortly', { code: 'reopen' });
let P = filter(disks().list, (x) => x.base == D.base), mn = map(filter(P, (x) => x.mounted), (x) => x.mnt);
if ((act == 'check' || act == 'format') && length(filter(P, (x) => x.lock)))
return err('Disco in Sola Lettura: niente è cambiato. Per scrivere spegni Sola Lettura', 'Drive is Read Only: nothing changed. Turn off Read Only to write', { ro: true, code: 'ro' });
if (act == 'eject') {
if (!length(mn)) return err('Disco già staccato', 'Drive already unmounted');
if (a.bg === true) {
if (has(RUN + '/eject/' + D.id + '.run')) return { ok: true, bg: true };
unlink(RUN + '/eject/' + D.id + '.last');
mkdirp(RUN + '/eject');
wjr(RUN + '/eject/' + D.id + '.json', { name: D.name, since: time(), waits: [], stopped: [], left_s: null, now: true });
ejectgo(D, mn);
return { ok: true, bg: true };
}
let ED = RUN + '/eject/' + D.id, t0 = time();
if (has(ED + '.run')) return err('Espelli già in corso', 'Eject already running', { code: 'run' });
unlink(ED + '.last'); unlink(ED + '.res');
mkdirp(RUN + '/eject');
wjr(ED + '.json', { name: D.name, since: t0, waits: [], stopped: [], left_s: null, now: true });
ejectgo(D, mn);
let o = null;
for (let w = 0; w < 22000 && o == null; w += 200) {
sleep(200);
let rs = trim(readfile(ED + '.res') ?? ''), la = ejectlast(D.id);
if (rs == 'ok' || rs == 'busy') o = rs;
else if (la && +la.t >= t0) o = la.res;
}
if (o == null) return err('Il disco non risponde: Espelli continua da solo', 'The drive is not responding: Eject continues on its own', { code: 'slow', bg: true });
unlink(ED + '.json'); unlink(ED + '.res'); unlink(ED + '.last');
if (o == 'ok') return { ok: true };
let PP = {}, N = holdnames(holders(mn, t0, PP), PP), K = N.K, I = N.I, E = N.E;
return err('Disco in uso' + (length(K) ? ' da: ' + join(', ', I) : ': chiudi i file aperti e riprova'),
'Drive in use' + (length(K) ? ' by: ' + join(', ', E) : ': close open files and try again'), { users: I, users_en: E, svc: K });
}
if (act == 'check') {
if (D.md && !D.mounted) return err('Disco non collegato', 'Drive not mounted');
let ck = { ext2: [ 'e2fsprogs', 'e2fsck' ], ext3: [ 'e2fsprogs', 'e2fsck' ], ext4: [ 'e2fsprogs', 'e2fsck' ],
fat32: [ 'dosfstools', 'fsck.fat', 'fsck.vfat' ], exfat: [ 'exfat-fsck', 'fsck.exfat', 'exfatfsck' ], ntfs: [ 'ntfs-3g-utils', 'ntfsfix' ] }[D.fs];
if (!ck) return err('Questo tipo di disco non si può controllare', 'This drive type cannot be checked');
if (!length(filter(slice(ck, 1), (n) => bin(n))))
return err('Manca il programma di controllo: installa ' + ck[0], 'The check tool is missing: install ' + ck[0], { pkg: ck[0], code: 'tool' });
return jobstart('check', D.id, '', { dev: '/dev/' + D.dev, fs: D.fs, ktype: D.ktype, mnt: D.mnt, mnts: join('|', mn), svc: join(' ', svclist()), name: D.name, remount: canmount() }, [], 0, 0);
}
if (act == 'format') {
let fs = '' + (a.fs ?? 'ext4');
if (fs != 'ext4' && fs != 'exfat') return err('Tipo non valido', 'Invalid type');
if (!fmtok(a.confirm, D)) return err('Per preparare il disco scrivi il suo nome', 'Type the drive name to prepare it');
if (!bin(fs == 'ext4' ? 'mkfs.ext4' : 'mkfs.exfat') && !(fs == 'exfat' && bin('mkexfatfs')))
return err('Serve il pacchetto ' + (fs == 'ext4' ? 'e2fsprogs' : 'exfat-mkfs'), 'Needs the ' + (fs == 'ext4' ? 'e2fsprogs' : 'exfat-mkfs') + ' package', { pkg: fs == 'ext4' ? 'e2fsprogs' : 'exfat-mkfs' });
if (D.md) return err('Disco Doppio: prepara i dischi da Disco Doppio', 'Mirrored Drive: prepare the drives from Mirrored Drive');
let others = filter(lsdir(SYS + '/class/block') ?? [], (x) => x != D.base && x != D.dev && baseof(x) == D.base);
let whole = !!bin('sfdisk') && (!length(others) || D.blank === true), part = whole ? D.base + (match(D.base, /[0-9]$/) ? 'p1' : '1') : D.dev;
let mnt = length(D.mnt) ? D.mnt : tgtof(D);
return jobstart('format', D.id, '', { base: D.base, dev: '/dev/' + D.dev, part: part, whole: whole ? '1' : '0', fs: fs, label: cutn(replace(D.name, /[^A-Za-z0-9 _-]/g, ''), 11),
mnt: mnt, mnts: join('|', mn), svc: join(' ', svclist()), name: D.name, remount: canmount(), model: D.model, bsize: sysr('/class/block/' + D.base + '/size') }, [], 0, 0);
}
return err('Azione non valida', 'Invalid action');
} },
nas_sleep: { args: { mins: 0, keep: true, now: true, from: 'x', to: 'x' }, call: function(req) {
let a = req.args ?? {}, cur = sleepcfg();
let out = (c) => {
let R = [];
let NC = nascfg(), SP = svcports(NC, NC.remote?.sftp === true), PS = {}, pn = procnames();
for (let k in SVCK) if (k != 'dl' && SP[k] && (k != 'sftp' || pn['sftp-server'])) PS[SP[k]] = k;
if (PS[445] == 'smb') PS[139] = 'smb';
for (let x in clients(PS).conn) push(R, { who: x.ip, mac: x.mac, svc: x.svc, t: x.since });
for (let j in jobs()) if (j.state == 'run') push(R, { who: j.op, svc: 'job', t: j.t0 ?? j.t ?? null });
return { ...c, awake_by: R };
};
if (a.now) {
for (let b in uniq(map(filter(disks().list, (d) => d.mounted && !d.md), (d) => d.base))) bg('sh ' + q(JOB) + ' wake ' + q(b));
if (a.mins == null && a.keep == null && a.from == null && a.to == null) return { ok: true, ...out(cur) };
}
if (a.mins == null && a.keep == null && a.from == null && a.to == null) return out(cur);
let m = a.mins == null ? cur.mins : int(+a.mins), k = a.keep == null ? cur.keep : !!a.keep;
if (index([ 0, 5, 15, 30, 60 ], m) < 0) return err('Tempo non valido', 'Invalid time');
let f = a.from == null ? cur.from : (length('' + a.from) ? '' + a.from : null), t = a.to == null ? cur.to : (length('' + a.to) ? '' + a.to : null);
let hh = (v) => v == null || match(v, /^([01][0-9]|2[0-3]):00$/);
if (!hh(f) || !hh(t) || (f == null) != (t == null) || (f != null && f == t)) return err('Orari non validi', 'Invalid hours');
if (a.now && cur.set && m == cur.mins && k == cur.keep && f == cur.from && t == cur.to) return { ok: true, ...out(cur) };
if (m > 0 && !bin('hd-idle')) return err('Serve il pacchetto hd-idle', 'Needs the hd-idle package', { pkg: 'hd-idle' });
if (nasput((o) => { o.sleep = { ...(type(o.sleep) == 'object' ? o.sleep : {}), mins: m, keep: k, from: f, to: t }; }) == null) return nbusy();
let nc = sleepcfg();
hdidle(disks().list, m, kall(nc));
let CR = getenv('WF_CRONF') ?? '/etc/crontabs/root', o = readfile(CR) ?? '', Ls = filter(split(o, '\n'), (l) => length(l) && substr(l, -13) != ' # wf:naskeep');
if (k) push(Ls, '*/4 ' + cronhours(nc.from, nc.to) + ' * * * sh ' + JOB + ' keep # wf:naskeep');
let n = length(Ls) ? join('\n', Ls) + '\n' : '';
if (n != o) {
mkdir(dname(CR));
writefile(CR + '.wf', n); rename(CR + '.wf', CR);
bg('/etc/init.d/cron enabled || /etc/init.d/cron enable; /etc/init.d/cron restart');
}
return { ok: true, mins: m, keep: k, from: nc.from, to: nc.to, set: true };
} },
nas_raid: { args: { act: 'x', b: 'x' }, call: function(req) {
let x = req.args ?? {}, act = '' + (x.act ?? 'get'), NC = nascfg(), Ls = disks().list;
if (act == 'get') return ddget(NC, Ls);
if (act == 'on') {
let A = ddmain(NC, Ls), D = null;
for (let d in Ls) if (d.id == '' + (x.b ?? '')) D = d;
if (!ddaok(A)) return err('Scegli prima il Disco Principale', 'Choose the Main Drive first', { code: 'main' });
if (!D) return err('Secondo disco non trovato', 'Second drive not found', { code: 'gone' });
let w = ddwhy(D, A);
if (w) return err(w.it, w.en, { code: w.k });
let C = ddcfg(NC), S = ddst();
if (C.on === true && C.b == D.id) return { ok: true, ...ddget(NC, Ls) };
if (nasput((o) => { o.doppio = { on: true, b: D.id, buuid: D.uuid ?? '', name: D.name }; }) == null) return nbusy();
if (C.b != D.id) { delete S.last; delete S.n; delete S.del; delete S.skip; }
delete S.err; delete S.ev;
delete S.wd;
if (ddrun()) { writefile(DDSTOP, '' + time()); S.next = 0; ddput(S); }
else { unlink(DDSTOP); S.state = 'run'; S.t0 = time(); S.next = time() + DDH; ddput(S); ddgo(); }
return { ok: true, ...ddget(nascfg(), Ls) };
}
if (act == 'off') {
if (nasput((o) => { o.doppio = { on: false }; }) == null) return nbusy();
if (ddrun()) { mkdirp(RUN); writefile(DDSTOP, '' + time()); }
let S = ddst();
S.state = 'idle'; S.next = 0; delete S.err; delete S.ev; delete S.wd; delete S.fp; delete S.fz; ddput(S);
return { ok: true, ...ddget(nascfg(), Ls) };
}
return err('Azione non valida', 'Invalid action');
} },
nas_health: { args: { id: 'x', act: 'x', monthly: true, alert_grow: true }, call: function(req) {
let a = req.args ?? {}, D = diskby(a.id);
if (!D) return err('Disco non trovato', 'Drive not found');
if ((type(a.monthly) == 'bool' || type(a.alert_grow) == 'bool') &&
nasput((o) => { let s = type(o.smart) == 'object' ? o.smart : {}; if (type(a.monthly) == 'bool') s.monthly = a.monthly; if (type(a.alert_grow) == 'bool') s.alert_grow = a.alert_grow; o.smart = s; }) == null) return nbusy();
let s = D.md ? null : smartof(D.base);
if (a.act == 'test') {
if (D.dup) return duperr();
if (D.md || !s) return err('Questo disco non fa il test', 'This drive cannot run the test');
if (!bin('smartctl')) return err('Serve il pacchetto smartmontools', 'Needs the smartmontools package', { code: 'pkg', need: [ 'smartmontools' ] });
if (!s.test_ok) return err('Questo disco non accetta il test', 'This drive does not accept the test', { code: 'notest' });
if (s.test?.res == 'run') return err('Test già in corso', 'Test already running', { code: 'run' });
smtest(D.base);
}
else if (a.act != null && a.act != 'get') return err('Azione non valida', 'Invalid action');
let E = healthget(), H = E.ids[D.id] ?? {}, T = [ ...(H.temp ?? []) ], B = [ ...(H.bad ?? []) ], h = rj(RUN + '/health.json'), o = h?.ids?.[D.id];
if (o && h.d) { if (o.min != null) push(T, [ h.d, o.min, o.max ]); if (o.a) push(B, [ h.d, ...o.a ]); }
let NC = nascfg(), lt = localtime(), mo = NC.smart?.monthly !== false, ym = sprintf('%04d-%02d', lt.year, lt.mon);
let nx = null;
if (mo && s?.test_ok) {
let y = lt.year, m = lt.mon, hmn = lt.hour * 60 + lt.min;
if (E.month[D.id] == ym) {
m++; if (m > 12) { m = 1; y++; }
nx = timelocal({ year: y, mon: m, mday: 1, hour: 3, min: 30, sec: 0 });
}
else if (hmn >= 210 && hmn < 420) nx = time();
else nx = timelocal({ year: y, mon: m, mday: lt.mday, hour: 3, min: 30, sec: 0 }) + (hmn >= 420 ? 86400 : 0);
}
let r = { id: D.id, smart: s, temp: slice(T, -30), bad: slice(B, -30), alert_grow: NC.smart?.alert_grow !== false,
test: { last: s?.test?.t ?? null, res: s?.test?.res ?? null, next: nx, monthly: mo } };
if (a.act == 'test') r.ok = true;
return r;
} },
nas_usb: { args: { id: 'x', act: 'x', alert: true }, call: function(req) {
let a = req.args ?? {}, D = diskby(a.id);
if (!D) return err('Disco non trovato', 'Drive not found');
if (type(a.alert) == 'bool' && nasput((o) => { o.usb = { ...(type(o.usb) == 'object' ? o.usb : {}), alert: a.alert }; }) == null) return nbusy();
if (a.act == 'test') ev('nas_usbreset', '🗄️ ' + cutn(D.name, 24) + ' ¦ ' + L('Avviso Porta USB', 'USB Port Alert') + ' ¦ ' + L('Prova', 'Test'));
else if (a.act != null && a.act != 'get') return err('Azione non valida', 'Invalid action');
let U = usbdata().ids[D.id] ?? {}, days = [], last = null;
for (let i = 6; i >= 0; i--) push(days, U.days?.[dayof(time() - i * 86400)] ?? 0);
for (let x in U.list ?? []) last = x;
let dy = rj(RUN + '/speed-' + D.id + '.day.json');
let hp = D.usb ? usbpwr(D.base) : null, hw = hp === true ? null : usbhub(U, dayof());
let r = { id: D.id, today: days[6], days: days, last: last?.t ?? null, list: U.list ?? [], alert: nascfg().usb?.alert !== false, hint: hw ? 'hub' : null,
hint_why: hw, hub_pwr: hp,
port: D.usb ? usbport(D.base) : null, usb_ver: D.usb ? usbver(D.base) : null, diary: type(dy) == 'object' && dy.d == dayof() ? dy.ev ?? [] : [] };
if (a.act == 'test') r.ok = true;
return r;
} },
nas_hist: { args: {}, call: function() {
let h = rj(RUN + '/hist.json'), z = [];
if (type(h) == 'object' && type(h.r) == 'array' && length(h.r) == HN) return { step: HSTEP, t: h.t, r: h.r, w: h.w };
for (let i = 0; i < HN; i++) push(z, 0);
return { step: HSTEP, t: time() - time() % HSTEP, r: z, w: [ ...z ] };
} },
nas_svc: { args: { svc: 'x', on: true }, call: function(req) {
let a = req.args ?? {}, k = '' + (a.svc ?? '');
if (index(SVC6, k) < 0) return err('Servizio non valido', 'Invalid service');
if (type(a.on) != 'bool') return err('Scegli acceso o spento', 'Choose on or off');
let MT = { smb: 'nas_shares', dlna: 'nas_media', dl: 'nas_dl', link: 'nas_link', remote: 'nas_remote', rec: 'nas_rec' }[k], on = a.on, A;
if (on && k == 'smb' && !smbany(nascfg()))
return err('Prima crea una cartella o un utente', 'First create a folder or a user', { code: 'empty' });
if (k == 'smb' || k == 'link') A = { act: 'on', on: on };
else if (k == 'remote') {
let NC = nascfg(), r = NC.remote ?? {}, P = type(NC.svc_prev?.remote) == 'object' ? NC.svc_prev.remote : { smbvpn: true };
if (P.webdav !== true && P.smbvpn !== true && P.sftp !== true) P = { smbvpn: true };
if (on && !vpnsrv()) return err('Serve il Server VPN: attivalo in VPN', 'The VPN Server is needed: turn it on in VPN', { code: 'vpn', need_svc: 'vpn' });
if (on && !remoteon({ ...NC, remote: P }, true))
return err('Servono le Cartelle In Rete accese con una cartella o un utente', 'Network Folders must be on with a folder or a user', { code: 'smb', need_svc: 'smb' });
if (!on && (r.webdav === true || r.smbvpn === true || r.sftp === true) &&
nasput((o) => { o.svc_prev = { ...(type(o.svc_prev) == 'object' ? o.svc_prev : {}), remote: { webdav: r.webdav === true, smbvpn: r.smbvpn === true, sftp: r.sftp === true } }; }) == null) return nbusy();
A = { act: 'set', webdav: on && P.webdav === true, smbvpn: on && P.smbvpn === true, sftp: on && P.sftp === true };
}
else A = { act: 'set', on: on };
let M = null;
for (let f in [ getenv('WF_NASFUC') ?? '/usr/share/wrtfreedom/nasf.uc', getenv('WF_NASDLUC') ?? '/usr/share/wrtfreedom/nasdl.uc',
getenv('WF_NASRECUC') ?? '/usr/share/wrtfreedom/nasrec.uc', getenv('WF_NASBKUC') ?? '/usr/share/wrtfreedom/nasbk.uc',
getenv('WF_NASXUC') ?? '/usr/share/wrtfreedom/nasx.uc', getenv('WF_NASVCUC') ?? '/usr/share/wrtfreedom/nasvc.uc' ]) {
if (!has(f)) continue;
let m = modof(f);
if (type(m?.[MT]?.call) == 'function') { M = m[MT]; break; }
}
if (!M) return err('Servizio non disponibile: aggiorna il Pacchetto Router', 'Service not available: update the Router Package', { code: 'pkg' });
if (k == 'dlna' && on && !length(nascfg().media?.dirs ?? [])) {
let F = null;
try { F = M.call({ args: { act: 'find' } })?.found; } catch (e) { F = null; }
if (type(F) == 'array' && length(F)) {
A.dirs = map(F, (x) => x.dir); A.types = {};
for (let x in F) if (match('' + (x.type ?? ''), /^[VAP]$/)) A.types[x.dir] = x.type;
}
}
let r = null;
try { r = M.call({ args: A }); } catch (e) { r = err('Non riuscito', 'Failed'); }
if (type(r) == 'object' && r.error != null) return r;
let st = state();
return { ok: true, svc: k, on: on, svc_n: st.svc_n, svc_sw: st.svc_sw, conn: st.conn };
} },
watch: watch,
mntsync: mntsync,
ntfsopen: ntfsopen,
dcopy: dcopy,
awake: awake,
};
