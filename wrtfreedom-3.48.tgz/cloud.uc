'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, open } from 'fs';
const FS = require('fs');
const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());

const RT = getenv('WF_CLOUDROOT') ?? getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', CJ = ETC + '/cloud.json', RC = ETC + '/cloud-rclone.conf', LJ = ETC + '/cloud-links.json';
const NXJ = ETC + '/nasx.json', BAKPW = ETC + '/backup.pw';
const TMP = '/tmp/wf-cloud', REQ = TMP + '/req', RES = TMP + '/res', QD = TMP + '/q', JOBS = TMP + '/jobs', PH = TMP + '/ph';
const CSH = getenv('WF_CLOUDSH') ?? '/usr/share/wrtfreedom/cloud.sh', CLSH = getenv('WF_CLOUDLINE') ?? '/usr/share/wrtfreedom/cloudline.sh';
const CMSH = '/usr/share/wrtfreedom/cloudmnt.sh', MNTD = TMP + '/mnt', NASMNT = '/tmp/wf-nas/mnt.json', NASJ = ETC + '/nas.json';
const PHTOT = { A: 64, B: 1024, C: 1024 }, PHMEM = { A: 128, B: 64, C: 64 }, MEMJ = R + '/tmp/wf-mem.json';
const AMAX = 10, DAY = 86400, RESTTL = 60, REQTTL = 300, CHUNK = 524288;
const UD = UCFG.UDIR, RTROOT = '/' + UCFG.udir('admin', 'router');
const CROLD = [ '/WrtFreedom/Backup', '/WrtFreedom/Router', '/WrtFreedom Backup', '/WrtFreedom Router' ];
const RTOLD = [ '/WrtFreedom/Router', '/WrtFreedom Router' ];
let WO = 'admin';
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
const TIPIUC = getenv('WF_NASTIPIUC') ?? '/usr/share/wrtfreedom/nastipi.uc';
let TIPI = null;
function tipi() { if (TIPI == null) { try { TIPI = loadfile(TIPIUC)() ?? {}; } catch (e) { TIPI = {}; } } return TIPI; }
function extin(k, e) { let L = tipi()[k]; return type(L) == 'array' && index(L, e) >= 0; }
let CLI = false;
let SELF = '/usr/share/wrtfreedom/cloud.uc';
try { SELF = sourcepath() ?? SELF; } catch (e) {}

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function shq(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(R + p) != null; }
const PK = {
rclone: [ [ 'rclone', '/usr/bin/rclone' ], [ 'ca-bundle', '/etc/ssl/certs/ca-certificates.crt' ] ],
code: [ [ 'curl', '/usr/bin/curl' ] ]
};
function need(part) {
let r = [];
for (let p in PK[part]) { let ok = false; for (let i = 1; i < length(p); i++) if (has(p[i])) ok = true; if (!ok) push(r, p[0]); }
return r;
}
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function cutn(s, n) { s = '' + s; if (length(s) <= n) return s; while (n > 0 && (ord(s, n) & 192) == 128) n--; return substr(s, 0, n); }
function rid() { return substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10) || ('' + time()); }
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
function alive(p) { return match('' + p, /^[0-9]+$/) != null && stat('/proc/' + p) != null; }
function mkdirp(p, m) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c, m ?? 0755); } }
const hk = UCFG.hk;
function fpr(s) { return s ? s.inode + ':' + s.size + ':' + s.mtime : ''; }
function isnum(v) { return type(v) == 'int' || type(v) == 'double'; }
function memj() {
let J = rjs(MEMJ), now = time();
return type(J) == 'object' && type(J.t) == 'int' && now - J.t <= 180 && J.t - now <= 60 && type(J.ris) == 'int' && J.ris > 0 ? J : null;
}
function intin(v, a, b) { return type(v) == 'int' && v >= a && v <= b; }
function hhmm(s) { return type(s) == 'string' && match(s, /^([01][0-9]|2[0-3]):[0-5][0-9]$/) != null; }
const b64d = UCFG.b64d;
function perm(f) { return stat(f)?.mode ?? 511; }
function mk600(t) {
unlink(t);
if (CLI) sh('umask 077; : > ' + shq(t));
let f = open(t, 'w');
if (!f) return null;
if (type(FS.chmod) == 'function') FS.chmod(t, 0600);
if ((perm(t) & 63) != 0) { f.close(); unlink(t); return null; }
return f;
}
function wsec(f, s) {
let t = f + '.' + PID + '.t', h = mk600(t);
if (!h) return false;
h.write(s); h.close();
if (!rename(t, f)) { unlink(t); return false; }
return true;
}
function wjs(f, o) {
let t = f + '.' + PID + '.t';
writefile(t, sprintf('%J', o));
if (type(FS.chmod) == 'function') FS.chmod(t, 0644);
return rename(t, f);
}
function wjs600(f, o) { return wsec(f, sprintf('%J', o)); }
function begintmp() {
mkdirp(TMP, 0700);
if (type(FS.chmod) == 'function' && (perm(TMP) & 63) != 0) FS.chmod(TMP, 0700);
for (let d in [ REQ, RES, QD, JOBS, PH ]) if (!stat(d)) mkdir(d, 0700);
}

const uval = UCFG.uval;
function uilang() {
let sec = false;
for (let l in split(readfile((getenv('WF_CFGDIR') ?? '/etc/config/') + 'wrtfreedom') ?? '', '\n')) {
let m = match(l, /^[ \t]*config[ \t]+([^ \t]+)[ \t]*(.*)$/);
if (m) { sec = uval(m[2]) == 'ui'; continue; }
let o = match(l, /^[ \t]*option[ \t]+lang[ \t]+(.*)$/);
if (sec && o) return uval(o[1]) == 'en' ? 'en' : 'it';
}
return 'it';
}
let LG = 'it';

const ERR = {
pkg: [ 'Serve installare Cloud in Software', 'Install Cloud in Software first' ],
old: [ 'Aggiorna Cloud in Software per questo servizio', 'Update Cloud in Software for this service' ],
act: [ 'Azione sconosciuta', 'Unknown action' ],
none: [ 'Account non trovato', 'Account not found' ],
svc: [ 'Servizio cloud non valido', 'Invalid cloud service' ],
token: [ 'Collegamento non valido: riprova', 'Invalid connection: try again' ],
fields: [ "Controlla i dati dell'account", 'Check the account details' ],
warn: [ "Conferma l'avviso prima di collegare", 'Confirm the warning before connecting' ],
max: [ 'Al massimo 10 account', 'At most 10 accounts' ],
relink: [ 'Account da ricollegare', 'Account needs reconnecting' ],
full: [ 'Spazio nel cloud finito', 'Cloud storage full' ],
space: [ 'Spazio nel cloud finito', 'Cloud storage full' ],
mem: [ 'Memoria del router piena: riprova tra poco', 'Router memory full: try again shortly' ],
path: [ 'Cartella non valida', 'Invalid folder' ],
exists: [ "C'è già un file con questo nome", 'A file with this name already exists' ],
bk: [ 'Cartella di un backup: si apre da Ripristina', 'Backup folder: open it from Restore' ],
crypt: [ 'Le cartelle dei backup non si condividono', 'Backup folders cannot be shared' ],
caps: [ 'Questo servizio non lo permette', 'This service does not allow it' ],
trash: [ 'Servizio senza cestino: togli i file uno alla volta', 'Service without a trash: remove the files one at a time' ],
big: [ 'File troppo grande per questo router', 'File too large for this router' ],
disk: [ 'Collega il disco del NAS', 'Connect the NAS disk' ],
ro: [ 'Disco in sola lettura', 'Disk is read-only' ],
net: [ 'Internet non raggiungibile', 'Internet unreachable' ],
sim: [ 'Aspetta la linea fissa o le ore della SIM', 'Waiting for the fixed line or the SIM hours' ],
busy: [ 'Account occupato: riprova fra poco', 'Account busy: try again shortly' ],
pending: [ 'Sto ancora leggendo il cloud', 'Still reading the cloud' ],
bakpass: [ 'Scegli prima la Password Della Copia', 'Choose the Backup Password first' ],
line: [ 'Valori della linea non validi', 'Invalid line settings' ],
job: [ 'Trasferimento non trovato', 'Transfer not found' ],
link: [ 'Link non trovato', 'Link not found' ],
media: [ 'Questo file non si può riprodurre', 'This file cannot be played' ],
rev: [ 'Versione non trovata', 'Version not found' ],
fuse: [ 'Manca FUSE: reinstalla Cloud in Software', 'FUSE missing: reinstall Cloud in Software' ],
acct: [ 'Account da ricollegare', 'Account needs reconnecting' ],
name: [ "Nome già usato da un'altra cartella condivisa", 'Name already used by another shared folder' ],
smb: [ 'Installa Cartelle Condivise nel NAS', 'Install Shared Folders in the NAS' ],
many: [ 'Una sola Cartella Cloud su questo router', 'Only one Cloud Folder on this router' ],
users: [ 'Crea prima un utente del NAS', 'Create a NAS user first' ],
cache: [ 'In scrittura serve la cache: scegli il disco del NAS o la memoria interna', 'Writing needs a cache: choose the NAS disk or the internal storage' ],
unsent: [ "File non ancora nel cloud: togliendo l'account si perdono", 'Files not yet in the cloud: removing the account loses them' ],
who: [ 'Accesso scaduto: entra di nuovo', 'Access expired: sign in again' ],
blocked: [ "Accesso bloccato dall'Amministratore", 'Access blocked by the Administrator' ],
private: [ "Cartella di un'altra persona", "Another person's folder" ],
admin: [ "Solo l'Amministratore", 'Administrator only' ],
quota_full: [ 'Spazio finito: libera spazio o chiedi più spazio', 'Space used up: free some space or ask for more space' ],
cquota: [ 'Spazio Cloud finito: libera spazio o chiedi più spazio', 'Cloud space full: free some space or ask for more' ],
check: [ 'Copia non uguale: la partenza resta', 'Copy does not match: the source stays' ],
fail: [ 'Non riuscito', 'Failed' ],
nocode: [ 'Questo servizio si collega dal telefono', 'This service connects from the phone' ],
cpriv: [ 'Cartella con dentro le private cifrate: condividi un file o una cartella dentro', 'Folder with encrypted private folders inside: share a file or folder inside it' ],
cmig: [ 'Cartella in cifratura in questo momento: riprova fra poco', 'Folder being encrypted right now: try again shortly' ],
keybad: [ 'Chiave sbagliata: controlla il foglio della chiave', 'Wrong key: check the key sheet' ],
cron: [ 'Cifratura già accesa', 'Encryption already on' ],
wait: [ 'Troppi tentativi: riprova fra 10 minuti', 'Too many attempts: try again in 10 minutes' ],
croff: [ 'Cifratura non accesa', 'Encryption not on' ],
clong: [ 'Nome troppo lungo per le cartelle cifrate: accorcialo', 'Name too long for encrypted folders: shorten it' ],
crold: [ 'Cartelle già cifrate nel cloud: usa Ho Già Una Chiave', 'Folders already encrypted in the cloud: use I Already Have A Key' ],
nokey: [ 'Chiave mancante sul router: usa Ho Già Una Chiave', 'Key missing on the router: use I Already Have A Key' ],
nohash: [ 'Questo servizio non controlla i file: cifratura non possibile', 'This service cannot check files: encryption not possible' ],
pmany: [ 'Troppi cloud personali in rete per questo router', 'Too many personal clouds on the network for this router' ],
puser: [ 'La persona di questo cloud non è nel NAS', "This cloud's person is not on the NAS" ]
};
function E(code, x) {
let e = ERR[code] ?? ERR.act, r = { error: e[0], error_en: e[1], code: ERR[code] ? code : 'act' };
for (let k, v in x ?? {}) r[k] = v;
return r;
}
function pkgE() { return E('pkg', { need: need('rclone') }); }

const RCLK = TMP + '/rc.lock', CJLK = TMP + '/cj.lock', LKLK = TMP + '/links.lock', MIGLK = TMP + '/mig.lock', TKLK = TMP + '/tick.lock';
function lkstale(K) {
let s = stat(K), p = trim(readfile(K + '/pid') ?? '');
if (s == null) return false;
return p == PID || (match(p, /^[0-9]+$/) != null && stat('/proc/' + p) == null) || time() - s.mtime > 30 || s.mtime > time() + 60;
}
function lkget(K) {
begintmp();
let b = K + '.brk';
if (mkdir(K, 0700)) { writefile(K + '/pid', PID); return true; }
if (lkstale(K)) {
let bs = stat(b);
if (bs && (time() - bs.mtime > 30 || bs.mtime > time() + 60)) rmdir(b);
if (mkdir(b)) {
if (lkstale(K)) { unlink(K + '/pid'); rmdir(K); }
rmdir(b);
if (mkdir(K, 0700)) { writefile(K + '/pid', PID); return true; }
}
}
return false;
}
function lkput(K) { if (trim(readfile(K + '/pid') ?? '') == PID) { unlink(K + '/pid'); rmdir(K); } }
function migrating() {
let s = stat(MIGLK);
if (!s) return false;
let p = trim(readfile(MIGLK + '/pid') ?? '');
return length(p) ? alive(p) : time() - s.mtime < 600;
}

function rcok(W) {
if (type(W) != 'object') return false;
for (let sec, kv in W) {
if (!match(sec, /^[A-Za-z0-9_.-]+$/) || length(sec) > 64) return false;
if (kv == null) continue;
if (type(kv) != 'object') return false;
for (let k, v in kv) if (!match(k, /^[A-Za-z0-9_]+$/) || match(type(v) == 'string' ? v : sprintf('%J', v), /[\r\n]/)) return false;
}
return true;
}
function rcset(W) {
if (!rcok(W)) return false;
if (!lkget(RCLK)) return false;
let ok = false, t = RC + '.' + PID + '.t';
for (let n = 0; n < 10 && !ok; n++) {
let s0 = stat(RC), so = s0 ? null : stat(RC + '.old');
if (so) {
if (time() - so.mtime <= 10 && so.mtime <= time() + 60) break;
if (!rename(RC + '.old', RC)) break;
continue;
}
let out = [], skip = false, hit = false;
for (let l in split(readfile(RC) ?? '', '\n')) {
let m = match(l, /^\[(.*)\][ \t]*$/);
if (m) { skip = exists(W, m[1]); if (skip) hit = true; }
if (!skip && length(trim(l))) push(out, l);
}
let add = false;
for (let sec, kv in W) if (kv) {
add = true; push(out, '[' + sec + ']');
for (let k, v in kv) push(out, k + ' = ' + (type(v) == 'string' ? v : sprintf('%J', v)));
}
if (!add && !hit) { ok = true; break; }
mkdirp(ETC);
let f = mk600(t);
if (!f) break;
f.write(join('\n', out) + '\n'); f.close();
if (fpr(stat(RC)) != fpr(s0) || (!s0 && stat(RC + '.old'))) continue;
ok = rename(t, RC);
}
unlink(t);
lkput(RCLK);
return ok;
}
function rcsec(sec) {
let cur = null, r = null;
for (let l in split(readfile(RC) ?? '', '\n')) {
let m = match(l, /^\[(.*)\][ \t]*$/);
if (m) { cur = m[1]; if (cur == sec) r = {}; continue; }
let kv = match(l, /^([A-Za-z0-9_]+)[ \t]*=[ \t]*(.*)$/);
if (cur == sec && kv) r[kv[1]] = kv[2];
}
return r;
}
function rcnames() {
let r = {};
for (let l in split(readfile(RC) ?? '', '\n')) { let m = match(l, /^\[(.*)\][ \t]*$/); if (m) r[m[1]] = true; }
return r;
}
function rcnoref(s) {
return join('\n', map(split(s ?? '', '\n'), (l) => match(l, /^token[ \t]*=/) ?
replace(replace(l, /"refresh_token"[ \t]*:[ \t]*"[^"]*"[ \t]*,?[ \t]*/g, ''), /,[ \t]*}/g, '}') : l));
}
function acctok(id) { return type(id) == 'string' && match(id, /^a[0-9]{1,3}$/) != null; }
function rcname(id) { return acctok(id) ? 'wf' + id : null; }

function tierf() {
let t = trim(readfile(TMP + '/tier') ?? '');
if (match(t, /^[ABC]$/)) return t;
let k = stat(TMP + '/tier.kick');
if (stat(CLSH) && !(k && time() - k.mtime < 3 && k.mtime <= time())) {
begintmp();
writefile(TMP + '/tier.kick', '' + time());
detach('sh -c ' + shq('. ' + shq(CLSH) + '; cl_tier'));
}
return null;
}
function tier() { return tierf() ?? 'A'; }

function vnum(v) { let m = match('' + (v ?? ''), /([0-9]+)\.([0-9]+)(\.([0-9]+))?/); return m ? (+m[1]) * 1000000 + (+m[2]) * 1000 + (+(m[4] ?? 0)) : 0; }
function vstr(v) { let m = match('' + (v ?? ''), /[0-9]+\.[0-9]+(\.[0-9]+)?/); return m ? m[0] : ''; }
function pkgver(f, pk, vk) {
let on = false;
for (let l in split(readfile(f) ?? '', '\n')) {
if (!length(l)) { on = false; continue; }
if (substr(l, 0, length(pk)) == pk) { on = trim(substr(l, length(pk))) == 'rclone'; continue; }
if (on && substr(l, 0, length(vk)) == vk) return vstr(substr(l, length(vk)));
}
return '';
}
function rcver() {
if (!has('/usr/bin/rclone')) return null;
let A = R + '/lib/apk/db/installed', O = R + '/usr/lib/opkg/status';
let fp = fpr(stat(A)) + '|' + fpr(stat(O)) + '|' + fpr(stat(R + '/usr/bin/rclone')), c = rjs(TMP + '/rclone.json');
let v = type(c) == 'object' && c.fp == fp ? c.ver : null;
if (v == null) {
v = pkgver(A, 'P:', 'V:') || pkgver(O, 'Package:', 'Version:');
begintmp();
wjs(TMP + '/rclone.json', { fp: fp, ver: v });
}
return length(v) ? v : vstr(rjs(TMP + '/state.json')?.rclone_ver);
}

function FL(k, t, t_en, ty, x) { return { k: k, t: t, t_en: t_en, type: ty, req: x?.req !== false, ...(x?.opt ? { opt: x.opt } : {}) }; }
const FUSER = FL('user', 'Utente', 'User', 'text'), FPASS = FL('pass', 'Password', 'Password', 'pass');
const SV = [
{ id: 'pcloud', name: 'pCloud', auth: 'oauth', fields: [], caps: { about: true, link: true, link_exp: true, link_pass: true, link_max: true, upreq: true, url: true, trash: true, thumbs: true, revs: true, trash_list: true, stream: true, cleanup: true, forever: true } },
{ id: 'drive', name: 'Google Drive', auth: 'oauth', fields: [], caps: { about: true, link: true, trash: true, cleanup: true, forever: true } },
{ id: 'onedrive', name: 'OneDrive', auth: 'oauth', fields: [], caps: { about: true, link: true, link_exp: true, trash: true, cleanup: true, forever: true } },
{ id: 'dropbox', name: 'Dropbox', auth: 'oauth', fields: [], caps: { about: true, link: true, trash: true } },
{ id: 'box', name: 'Box', auth: 'oauth', fields: [], caps: { about: true, link: true } },
{ id: 'kdrive', name: 'kDrive', auth: 'key', need: '1.76', fields: [ FL('token', 'Chiave', 'Key', 'pass'), FL('drive', 'Numero Del Drive', 'Drive Number', 'text') ], caps: { about: true } },
{ id: 'koofr', name: 'Koofr', auth: 'pass', fields: [ FUSER, FL('pass', 'Password Per App', 'App Password', 'pass') ], caps: { about: true, link: true } },
{ id: 'jottacloud', name: 'Jottacloud', auth: 'code', fields: [ FL('code', 'Codice', 'Code', 'code') ], caps: { about: true } },
{ id: 'mega', name: 'MEGA', auth: 'pass', warn: 'pass', fields: [ FUSER, FPASS ], caps: { about: true } },
{ id: 'icloud', name: 'iCloud Drive', auth: 'pass', warn: 'relink30', need: '1.69', fields: [ FUSER, FPASS, FL('code', 'Codice', 'Code', 'code') ], caps: {} },
{ id: 'b2', name: 'Backblaze B2', auth: 'key', fields: [ FL('key_id', 'ID Della Chiave', 'Key ID', 'text'), FL('key', 'Chiave', 'Key', 'pass') ], caps: {} },
{ id: 's3', name: 'S3 (Wasabi, AWS…)', auth: 'key', keep_min: { Wasabi: 90 }, fields: [ FL('vendor', 'Servizio', 'Provider', 'sel', { opt: [ 'Wasabi', 'AWS', 'Cloudflare', 'Minio', 'Other' ] }), FL('endpoint', 'Indirizzo', 'Endpoint', 'url', { req: false }), FL('region', 'Regione', 'Region', 'text', { req: false }), FL('key_id', 'ID Della Chiave', 'Key ID', 'text'), FL('key', 'Chiave', 'Key', 'pass'), FL('bucket', 'Contenitore', 'Bucket', 'text') ], caps: {} },
{ id: 'hetzner', name: 'Hetzner Storage Box', auth: 'pass', fields: [ FUSER, FPASS, FL('host', 'Indirizzo', 'Host', 'text') ], caps: { about: true } },
{ id: 'webdav', name: 'WebDAV / Nextcloud', auth: 'pass', fields: [ FL('url', 'Indirizzo', 'Address', 'url'), FUSER, FPASS, FL('vendor', 'Tipo', 'Type', 'sel', { opt: [ 'nextcloud', 'owncloud', 'other' ], req: false }) ], caps: { about: true } },
{ id: 'sftp', name: 'SFTP', auth: 'pass', fields: [ FL('host', 'Indirizzo', 'Host', 'text'), FL('port', 'Porta', 'Port', 'num', { req: false }), FUSER, FPASS ], caps: {} }
];
const CAPK = [ 'about', 'link', 'link_exp', 'link_pass', 'link_max', 'upreq', 'url', 'trash', 'thumbs', 'revs', 'trash_list', 'stream', 'cleanup', 'forever' ];
const CAPALL = [ 'copy', 'flow' ];
push(CAPALL, 'search', 'space');
const WHY = {
trash_list: { drive: [ 'Google Drive non dà il cestino a WrtFreedom: recupera dal sito', 'Google Drive does not share its trash with WrtFreedom: restore on the website' ],
onedrive: [ "OneDrive non dà l'elenco del cestino: recupera dal sito", 'OneDrive does not list its trash: restore on the website' ],
dropbox: [ "Dropbox non dà l'elenco del cestino: recupera dal sito", 'Dropbox does not list its trash: restore on the website' ],
'*': [ 'Questo servizio non ha un cestino: i file tolti non tornano', 'This service has no trash: deleted files do not come back' ] },
cleanup: { dropbox: [ 'Dropbox svuota il cestino da sé dopo 30 giorni', 'Dropbox empties its trash by itself after 30 days' ],
'*': [ 'Questo servizio non ha un cestino', 'This service has no trash' ] },
forever: { dropbox: [ 'Dropbox tiene i file tolti nel cestino: si tolgono dal sito', 'Dropbox keeps deleted files in its trash: remove them on the website' ],
'*': [ 'Senza cestino ogni file tolto va via per sempre', 'Without a trash every deleted file is gone for good' ] },
upreq: { '*': [ 'Questo servizio non dà link per caricare', 'This service has no upload links' ] }
};
function svcof(id) { for (let s in SV) if (s.id == id) return s; return null; }
const WTDAYS = 30, WTCAPS = [ 'trash', 'trash_list', 'cleanup', 'forever' ];
function wtron(s) { return s != null && s.caps?.trash !== true; }
function wtpath(a) {
let L = [ a?.path, a?.to, a?.src, a?.file, ...(type(a?.paths) == 'array' ? a.paths : []) ];
for (let p in L) if (type(p) == 'string' && match('/' + replace(p, /^\/+/, ''), /^\/\.wf-trash(\/|$)/)) return true;
return false;
}
function svcok(s, ver) { return !s?.need || !length(ver ?? '') || vnum(ver) >= vnum(s.need); }
const DEVCID = { onedrive: '' };
const DEVP = { onedrive: { dc: 'https://login.microsoftonline.com/common/oauth2/v2.0/devicecode',
tk: 'https://login.microsoftonline.com/common/oauth2/v2.0/token', scope: 'Files.ReadWrite.All offline_access',
drive: 'https://graph.microsoft.com/v1.0/me/drive' } };
function devcid(svc) {
let c = (length(R) ? getenv('WF_DEVCID') : null) ?? DEVCID[svc] ?? '';
return DEVP[svc] && match(c, /^[A-Za-z0-9-]{8,64}$/) ? c : null;
}
function svcs(ver) {
return map(SV, (s) => {
let c = {};
for (let k in CAPK) c[k] = s.caps[k] === true;
for (let k in CAPALL) c[k] = true;
c.xcloud = true;
if (wtron(s)) { c.wftrash = true; c.trash_days = WTDAYS; for (let k in WTCAPS) c[k] = true; }
let w = {}, we = {};
for (let k, v in WHY) if (!c[k]) { let t = v[s.id] ?? v['*']; w[k] = t[0]; we[k] = t[1]; }
return { id: s.id, name: s.name, auth: s.auth, fields: s.fields, caps: c, warn: s.warn ?? null, need: s.need ?? null,
ok: ver != null && svcok(s, ver), code: devcid(s.id) != null, ...(s.keep_min ? { keep_min: s.keep_min } : {}), why: w, why_en: we };
});
}

function cget() {
let C = rjs(CJ);
if (type(C) != 'object') C = {};
C.v = 1;
if (type(C.accounts) != 'array') C.accounts = [];
C.accounts = filter(C.accounts, (a) => type(a) == 'object' && acctok(a.id) && svcof(a.svc));
let L = type(C.line) == 'object' ? C.line : {}, S = type(L.sim) == 'object' ? L.sim : {};
C.line = { ...L, sim: { gb: isnum(S.gb) ? S.gb : null, all: S.all === true, from: hhmm(S.from) ? S.from : '01:00', to: hhmm(S.to) ? S.to : '07:00' },
bw_up: intin(L.bw_up, 0, 1000000) ? L.bw_up : 0, bw_down: intin(L.bw_down, 0, 1000000) ? L.bw_down : 0,
bw_at: type(L.bw_at) == 'array' ? L.bw_at : [], parallel: intin(L.parallel, 0, 8) ? L.parallel : 0 };
let P = type(C.pause) == 'object' ? C.pause : {};
C.pause = { on: P.on === true, until: isnum(P.until) ? P.until : 0, by: P.by ?? 'user' };
let T = type(C.router) == 'object' ? C.router : {};
C.router = { ...T, on: T.on === true, acct: acctok(T.acct) ? T.acct : '', every: T.every == 'day' ? 'day' : 'week',
day: intin(T.day, 0, 6) ? T.day : 0, keep: intin(T.keep, 1, 52) ? T.keep : 8, before_fw: T.before_fw !== false,
last: isnum(T.last) ? T.last : 0, ok: T.ok !== false };
let M = type(C.lim) == 'object' ? C.lim : {};
C.lim = { ...M, phone_mb: intin(M.phone_mb, 0, 100000) ? M.phone_mb : 0, ls_max: intin(M.ls_max, 100, 1000000) ? M.ls_max : 50000 };
return C;
}
function csave(fn) {
if (!lkget(CJLK)) return null;
let C = null;
try { C = cget(); fn(C); mkdirp(ETC); if (!wjs(CJ, C)) C = null; } catch (e) { C = null; }
lkput(CJLK);
return C;
}
function facts() {
let S = rjs(TMP + '/state.json');
if (type(S) != 'object') S = {};
if (type(S.accts) != 'object') S.accts = {};
return S;
}
function line() { return cget().line; }
function pauseof(C, now) { return C.pause.on === true && (!C.pause.until || C.pause.until > now); }
function paused() { return pauseof(cget(), time()); }
function par(C) {
C = C ?? cget();
return C.line.parallel > 0 ? C.line.parallel : ({ A: 1, B: 2, C: 4 })[tier()];
}

function mask(m) {
m = '' + (m ?? '');
if (!length(m) || index(m, '*') >= 0) return m;
let p = match(m, /^([^@]+)@([^.]+)\.(.*)$/);
return p ? substr(p[1], 0, 1) + '***@' + substr(p[2], 0, 1) + '***.' + p[3] : substr(m, 0, 1) + '***';
}
function ownof(x) { return type(x?.own) == 'string' && length(x.own) ? x.own : 'admin'; }
function auser(x) { return type(x?.user) == 'string' && length(x.user) ? x.user : 'admin'; }
function usesof(C) {
let U = {}, X = rjs(NXJ), add = (id, kind, name, own) => { if (!acctok(id)) return; U[id] = U[id] ?? []; push(U[id], { kind: kind, name: '' + (name ?? ''), own: own }); };
for (let c in (type(X?.cloud) == 'array' ? X.cloud : [])) if (type(c) == 'object') add(c.acct, c.kind == 'backup' ? 'backup' : 'sync', c.name, ownof(c));
for (let id, p in (type(X?.photo?.phones) == 'object' ? X.photo.phones : {})) if (type(p) == 'object' && p.dest == 'cloud') add(p.acct, 'photo', p.name, ownof(p));
if (C.router.acct) add(C.router.acct, 'router', 'Copia Del Router', 'admin');
return U;
}
function padm(W) { return W?.adm === true && W.keep !== true; }
const PSTW = { none: 0, ok: 1, run: 2, warn: 3, bad: 4 };
const PSTT = { none: [ 'Niente In Corso', 'Nothing Running' ], ok: [ 'Tutto A Posto', 'All Good' ], run: [ 'In Corso', 'Running' ],
warn: [ 'Da Controllare', 'Check' ], bad: [ 'Non Riuscito', 'Failed' ] };
function pname(o, N) { let d = UCFG.udir(o, 'root', null, N); return d ? UCFG.bname(d) : o; }
function ppl(L, stv, add) {
let N = rjs(NASJ) ?? {}, P = {}, r = [];
for (let x in L) {
let o = x.own;
if (type(o) != 'string' || o == 'admin') continue;
let p = P[o];
if (!p) {
p = P[o] = { own: o, own_name: pname(o, N), n: 0 };
if (stv) p.st = 'none';
push(r, p);
}
p.n++;
if (stv) { let s = stv(x); if ((PSTW[s] ?? 0) > PSTW[p.st]) p.st = s; }
if (add) add(p, x);
}
for (let p in r) if (p.st) { p.st_t = PSTT[p.st][0]; p.st_t_en = PSTT[p.st][1]; }
return sort(r, (a, b) => a.own_name < b.own_name ? -1 : a.own_name > b.own_name ? 1 : 0);
}
const CRJ = ETC + '/cloud-cifra.json', CRLK = TMP + '/cr.lock', CRD = TMP + '/cr', CRKEY = TMP + '/.crkey';
const CRSH = '/usr/share/wrtfreedom/cloudcr.sh', CXSH = getenv('WF_CLOUDX') ?? '/usr/share/wrtfreedom/cloudx.sh';
function crget() {
let o = rjs(CRJ);
if (type(o) != 'object') o = {};
if (type(o.accts) != 'object') o.accts = {};
o.on = o.on === true; o.keyok = o.keyok === true;
return o;
}
function crsave(fn) {
if (!lkget(CRLK)) return null;
let o = null;
try { o = crget(); fn(o); mkdirp(ETC); if (!wjs600(CRJ, o)) o = null; } catch (e) { o = null; }
lkput(CRLK);
return o;
}
function crstof(A) { return type(A) == 'object' && match('' + A.st, /^(setup|mig|on|back|off)$/) ? A.st : 'off'; }
function crpct(A, st) {
if (st == 'on') return 100;
if (st != 'mig' && st != 'back') return 0;
return isnum(A?.done_b) && isnum(A?.tot_b) && A.tot_b > 0 ? min(99, int(A.done_b * 100 / A.tot_b)) : 0;
}
function crst(CR, id) { let A = CR.accts[id], st = crstof(A); return { st: st, pct: crpct(A, st) }; }
function cctx() {
let C = cget(), com = {};
for (let x in C.accounts) if (auser(x) == 'admin') com[x.id] = true;
return { CR: crget(), N: rjs(NASJ) ?? {}, X: rjs(NXJ) ?? {}, com: com };
}
function cfst(A, k) {
let F = type(A?.f) == 'object' ? A.f : {}, v = F[k];
if (v == null) for (let x, s in F) if (lc(x) == lc(k)) { v = s; break; }
if (match('' + v, /^(clear|mig|enc|back)$/)) return v;
return A.st == 'on' ? 'enc' : A.st;
}
function cmap(acct, p, K) {
let rel = trim(replace('' + (p ?? ''), /\/\/+/g, '/'), '/'), r = { sec: rcname(acct), path: rel, st: 'clear' };
if (r.sec == null) return null;
K = K ?? cctx();
let A = K.CR.accts[acct];
if (!K.com[acct] || !match(crstof(A), /^(mig|on|back)$/)) return r;
let P = split(rel, '/'), c = UCFG.cpriv(P, K.N, K.X);
if (c == null) {
c = length(P) == 2 ? UCFG.cpriv([ ...P, '.' ], K.N, K.X) : null;
return c ? { ...r, st: 'mix', own: c.own, vis: c.vis, csec: UCFG.crsec(acct, c.own) } : r;
}
let k = c.vis + '/' + c.top, fs = cfst(A, k), cs = { sec: UCFG.crsec(acct, c.own), path: c.rest }, o = { own: c.own, vis: c.vis, top: c.top, key: k, rest: c.rest };
if (fs == 'clear') return { ...r, st: fs, ...o };
if (fs == 'enc') return { ...cs, st: fs, ...o };
return fs == 'mig' ? { ...cs, st: fs, alt: { sec: r.sec, path: rel }, ...o } : { ...r, st: fs, alt: cs, ...o };
}
function cmigp(acct, p, K) {
K = K ?? cctx();
let m = cmap(acct, p, K);
if (m?.key == null || (m.st != 'mig' && m.st != 'back')) return false;
let L = split(readfile(CRD + '/' + acct + '.cur') ?? '', '\n');
if (lc(trim(L[0] ?? '')) != lc(m.key) || !alive(trim(readfile(CRD + '/' + acct + '.lk/pid') ?? ''))) return false;
let r = lc(m.rest ?? m.top);
for (let i = 1; i < length(L); i++) {
let f = lc(L[i]);
if (length(f) && (f == r || substr(f, 0, length(r) + 1) == r + '/')) return true;
}
return false;
}
function astate(a, S, N, now) {
let f = type(S.accts[a.id]) == 'object' ? S.accts[a.id] : {}, st = match(f.st ?? '', /^(ok|new|relink|err|busy)$/) ? f.st : (N[rcname(a.id)] ? 'ok' : 'new');
let tu = a.t_use ?? 0;
if (isnum(f.t_use) && f.t_use > tu) tu = f.t_use;
if (st != 'new' && a.svc == 'box' && tu > 0 && now - tu > 60 * DAY) st = 'relink';
if (st != 'new' && a.svc == 'icloud' && isnum(a.relink_at) && a.relink_at > 0 && now >= a.relink_at) st = 'relink';
return { st: st, f: f, tu: tu };
}
function rczone(a) {
if (a.svc != 'pcloud') return '';
let sec = false;
for (let l in split(readfile(RC) ?? '', '\n')) {
let m = match(l, /^\[([^\]]+)\]/);
if (m) { sec = m[1] == 'wf' + a.id; continue; }
if (!sec) continue;
let h = match(l, /^hostname *= *([A-Za-z0-9.-]+)/);
if (h) return h[1] == 'eapi.pcloud.com' ? 'eu' : h[1] == 'api.pcloud.com' ? 'us' : '';
}
return '';
}
function aout(a, S, N, U, ver, now) {
let x = astate(a, S, N, now), f = x.f, u = U[a.id] ?? [];
let used = isnum(f.used) ? f.used : 0, total = isnum(f.total) ? f.total : 0, s = svcof(a.svc);
let r = { id: a.id, svc: a.svc, svc_name: s.name, name: a.name, zone: f.zone || a.zone || rczone(a), mail: mask(f.mail ?? a.mail ?? ''),
t_link: a.t_link ?? 0, t_use: x.tu, own: a.own === true, user: auser(a), warn_ok: a.warn_ok === true, state: svcok(s, ver) ? x.st : 'old',
used: used, total: total, free: isnum(f.free) ? f.free : (total > used ? total - used : 0), pct: total > 0 ? int(used * 100 / total) : 0,
t_about: isnum(f.t_about) ? f.t_about : 0, used_by: length(u), uses: u };
if (a.host || f.host) r.host = f.host ?? a.host;
if (a.drive_type) r.drive_type = a.drive_type;
if (isnum(a.relink_at)) r.relink_at = a.relink_at;
if (x.st == 'err' || x.st == 'relink') { r.err = f.err ?? ERR[x.st == 'relink' ? 'relink' : 'net'][0]; r.err_en = f.err_en ?? ERR[x.st == 'relink' ? 'relink' : 'net'][1]; }
return r;
}
function accts(C, S, ver) {
C = C ?? cget(); S = S ?? facts();
let N = rcnames(), U = usesof(C), now = time(), CR = crget();
return map(C.accounts, (a) => { let r = aout(a, S, N, U, ver, now); if (r.user == 'admin' && type(CR.accts[a.id]) == 'object') r.crypt = crst(CR, a.id); return r; });
}
function acct(id) { for (let a in accts(null, null, rcver())) if (a.id == id) return a; return null; }

const JK = [ 'job', 'kind', 'name', 'from', 'to', 'acct', 'state', 'why', 'why_en', 'wc', 'pct', 'speed', 'bytes', 'size', 'err', 'err_en', 'code', 't' ];
function jobok(j) { return type(j) == 'string' && match(j, /^j[0-9a-z]{4,24}$/) != null; }
function jlist() {
let r = [];
for (let f in (lsdir(JOBS) ?? [])) {
let m = match(f, /^(j[0-9a-z]{4,24})\.json$/);
if (!m) continue;
let o = rjs(JOBS + '/' + f);
if (type(o) != 'object') continue;
let j = {};
for (let k in JK) if (exists(o, k)) j[k] = o[k];
j.job = m[1];
if (type(j.code) != 'string' || !match(j.code, /^[a-z0-9_]{1,20}$/)) delete j.code;
if (length(j.err ?? '') && !exists(j, 'code')) j.code = 'fail';
if (!exists(j, 'acct') && acctok(o.id)) j.acct = o.id;
j.own = ownof(o);
if (!match(j.state ?? '', /^(run|wait|pause|err|ok|stop)$/)) j.state = 'wait';
j.t = isnum(j.t) ? j.t : 0;
push(r, j);
}
return r;
}
function jcount(J) {
let run = 0, qn = 0, why = '', why_en = '';
for (let j in J) {
if (j.state == 'run') run++;
else if (j.state == 'wait' || j.state == 'pause') { qn++; if (!length(why) && length(j.why ?? '')) { why = j.why; why_en = j.why_en ?? j.why; } }
}
return { run: run, queue: qn, why: why, why_en: why_en };
}

function hm(t, now) {
let l = localtime(t), s = sprintf('%02d:%02d', l.hour, l.min);
return t - now >= DAY ? sprintf('%02d/%02d ', l.mday, l.mon) + s : s;
}
function sumof(C, S, ver, A, J, now, W) {
let r = (k, t, t_en, n, x) => ({ k: k, t: t, t_en: t_en, n: n, ...(x ?? {}) });
let vw = W && !W.adm ? W.own : 'admin', NJ = null, am = (a) => a.user == 'admin' || a.user == vw, jm = (j) => j.own == vw;
let pn = (o) => { if (NJ == null) NJ = rjs(NASJ) ?? {}; return pname(o, NJ); };
if (ver == null) return r('none', 'Da Installare', 'To Install', 0);
let old = filter(A, (a) => a.state == 'old');
if (length(old)) {
let s = svcof(old[0].svc);
return r('old', 'Aggiorna', 'Update', length(old), { why: 'Aggiorna Cloud in Software per ' + s.name, why_en: 'Update Cloud in Software for ' + s.name });
}
if (!length(A)) return r('setup', 'Da Configurare', 'To Set Up', 0);
let rl = filter(A, (a) => a.state == 'relink');
if (length(rl)) {
let it = [], en = [];
for (let a in rl) {
if (am(a)) { push(it, a.name); push(en, a.name); continue; }
let p = pn(a.user);
push(it, p + ': cloud da ricollegare'); push(en, p + ': cloud to reconnect');
}
return r('relink', 'Da Ricollegare', 'Reconnect Needed', length(rl), { why: join(', ', it), why_en: join(', ', en) });
}
let n = length(A);
if (pauseof(C, now)) {
let u = C.pause.until;
return r('pause', 'In Pausa', 'Paused', n, u ? { why: 'Pausa Cloud fino alle ' + hm(u, now), why_en: 'Cloud paused until ' + hm(u, now) } : { why: 'Pausa Cloud', why_en: 'Cloud paused' });
}
if (C.line.sim.gb == null && (S.simask === true || length(filter(J, (j) => j.wc == 'simask' && (j.state == 'wait' || j.state == 'pause')))))
return r('pause', 'In Pausa', 'Paused', n, { why: 'Scegli Per La SIM', why_en: 'Choose For The SIM' });
let run = filter(J, (j) => j.state == 'run');
if (length(run)) {
let j = run[0], t = jm(j) ? [ j.name ?? '', j.name ?? '' ] : [ pn(j.own) + ': trasferimento in corso', pn(j.own) + ': transfer running' ];
return r('run', 'In Corso', 'In Progress', length(run), { live: { t: t[0], t_en: t[1], pct: isnum(j.pct) ? j.pct : 0, speed: isnum(j.speed) ? j.speed : 0 } });
}
let w = [];
for (let a in A) {
let m = am(a), p = m ? '' : pn(a.user);
if (a.pct >= 90) push(w, m ? [ a.name + ' quasi pieno', a.name + ' almost full' ] : [ p + ': cloud quasi pieno', p + ': cloud almost full' ]);
if (a.state == 'err') push(w, m ? [ a.name + ' non riuscito', a.name + ' failed' ] : [ p + ': cloud non riuscito', p + ': cloud failed' ]);
}
for (let j in J) if (j.state == 'err' && now - j.t < DAY)
push(w, jm(j) ? [ (j.name ?? '') + ' non riuscito', (j.name ?? '') + ' failed' ] : [ pn(j.own) + ': un trasferimento non riuscito', pn(j.own) + ': a transfer failed' ]);
for (let x in (type(S.warn) == 'array' ? S.warn : [])) if (type(x) == 'object' && length(x.t ?? '')) push(w, [ x.t, x.t_en ?? x.t ]);
if (length(w)) return r('warn', 'Da Controllare', 'Check Needed', length(w), { why: join(' · ', map(w, (x) => x[0])), why_en: join(' · ', map(w, (x) => x[1])) });
let cap = filter(J, (j) => j.wc == 'cap' && (j.state == 'wait' || j.state == 'pause'));
if (length(cap)) {
let sm = type(C.line.sim) == 'object' ? C.line.sim : {}, at = sm.all === true || !length(sm.from ?? '') ? '00:00' : sm.from;
return r('warn', 'Tetto Della SIM', 'SIM Cap Reached', length(cap), { why: 'Tetto della SIM raggiunto: riprende alle ' + at, why_en: 'SIM cap reached: resumes at ' + at });
}
return r('ok', n == 1 ? '1 Collegato' : n + ' Collegati', n == 1 ? '1 Connected' : n + ' Connected', n);
}
function sum() {
let C = cget(), S = facts(), ver = rcver();
return sumof(C, S, ver, accts(C, S, ver), jlist(), time());
}

const SECK = /^(token|access_token|refresh_token|pass|password|password2|key|secret|client_secret)$/;
function clean(o) {
if (type(o) == 'array') return map(o, clean);
if (type(o) != 'object') return o;
let r = {};
for (let k, v in o) if (!match(k, SECK)) r[k] = clean(v);
return r;
}
function kick() {
if (alive(trim(readfile(TMP + '/work.pid') ?? ''))) return;
let k = stat(TMP + '/work.kick');
if (k && time() - k.mtime < 3 && k.mtime <= time()) return;
writefile(TMP + '/work.kick', '' + time());
if (stat(CSH)) detach('sh ' + shq(CSH) + ' work');
}
function ticking() {
let s = stat(TKLK);
if (!s) return false;
let p = trim(readfile(s.type == 'directory' ? TKLK + '/pid' : TKLK) ?? '');
if (length(p)) return alive(p);
return time() - s.mtime < 30 && s.mtime <= time() + 60;
}
function kicktick() { if (stat(CSH) && !ticking()) detach('sh ' + shq(CSH) + ' tick'); }
function reqid(act, a) { return 'r' + substr(hk(act + '|' + sprintf('%J', a)), 0, 14); }
const GENRD = { ls: true, trash: true, find: true, revs: true };
const GENWR = { mkdir: true, move: true, rm: true, restore: true, revert: true, upreq: true, link: true };
function genf(id) { return type(id) == 'string' && match(id, /^a[0-9]{1,3}$/) ? TMP + '/gen-' + id : null; }
function gen(id) {
let f = genf(id);
if (!f) return '';
let c = rjs(CRJ)?.accts?.[id];
return trim(readfile(f) ?? '') + (type(c) == 'object' ? '|' + (c.st ?? '') + sprintf('%J', c.f ?? null) : '');
}
function genup(id) {
let f = genf(id);
if (!f || !stat(TMP)) return;
let t = f + '.' + PID;
if (writefile(t, rid() + '\n') == null || !rename(t, f)) unlink(t);
}
function resof(id) {
let s = stat(RES + '/' + id + '.json');
if (!s || time() - s.mtime > RESTTL || s.mtime > time() + 60) return null;
let o = rjs(RES + '/' + id + '.json');
return type(o) == 'object' ? clean(o) : null;
}
function pend(act, a, id) {
id = id ?? reqid(GENRD[act] ? act + '|' + gen(a.id) : act, WO == 'admin' ? a : { ...a, own: WO });
let o = resof(id);
if (o) return o;
let qs = stat(REQ + '/' + id + '.json'), now = time();
if (!qs || now - qs.mtime > REQTTL || qs.mtime > now + 60) {
unlink(RES + '/' + id + '.json');
if (!wjs600(REQ + '/' + id + '.json', { ...a, act: act, req: id, t: now, lang: LG, own: a.own ?? WO })) return E('busy');
if (GENWR[act]) genup(a.id);
}
kick();
return stat(REQ + '/' + id + '.wait') ? { pending: id, wait: true } : { pending: id };
}

function rpath(p) {
p = '' + (p ?? '');
if (!length(p)) p = '/';
if (substr(p, 0, 1) != '/') p = '/' + p;
p = replace(p, /\/\/+/g, '/');
if (length(p) > 1 && substr(p, -1) == '/') p = substr(p, 0, length(p) - 1);
if (length(p) > 1024 || match(p, /[[:cntrl:]]/)) return null;
for (let x in split(p, '/')) if (x == '.' || x == '..') return null;
return p;
}
function nameok(n) { return type(n) == 'string' && length(n) >= 1 && length(n) <= 255 && n != '.' && n != '..' && !match(n, /[\/[:cntrl:]]/); }
function under(p, root) { return p == root || substr(p, 0, length(root) + 1) == root + '/'; }
function incr(p) {
if (under(p, RTROOT)) return true;
for (let r in CROLD) if (under(p, r)) return true;
let m = match(p, /^\/([^\/]+)\/([^\/]+)\/([^\/]+)(\/|$)/);
return m != null && m[1] == UD.root && m[3] == UD.backup;
}
function cdir(own, k, sub) {
if (k == 'tm' || k == 'fh' || (k == 'dl' && sub != null)) return null;
let p = UCFG.udir(own, k, sub);
return p == null ? null : '/' + p;
}
function proots(W) { return [ cdir(W.own, 'root'), cdir('shared', 'root') ]; }
function pin(p, W, top) {
if (p == null) return false;
for (let r in proots(W)) if (r != null && (top !== false ? under(p, r) : substr(p, 0, length(r) + 1) == r + '/')) return true;
return false;
}
const SOWNMAX = 2000;
function insh(p) { let r = cdir('shared', 'root'); return r != null && p != null && substr(p, 0, length(r) + 1) == r + '/'; }
function sownof(C, id, p) {
let O = C.sown?.[id];
if (type(O) != 'object') return null;
for (let x = p; insh(x); x = replace(x, /\/[^\/]*$/, '')) if (O[x] != null) return O[x];
return null;
}
function mayedit(C, id, p, W) { return W.adm || !insh(p) || sownof(C, id, p) == W.own; }
function sownother(C, id, p, W) { let v = C.sown?.[id]?.[p]; return !W.adm && insh(p) && v != null && v != W.own; }
function sownset(id, W, add, del, mv) {
add = W.adm ? [] : filter(add ?? [], insh); del = filter(del ?? [], insh);
mv = filter(mv ?? [], (x) => W.adm ? insh(x[0]) : (insh(x[0]) || insh(x[1])));
if (!length(add) && !length(del) && !length(mv)) return true;
let fix = (O) => {
let n = 0;
for (let k in keys(O)) {
for (let d in del) if (O[k] != null && under(k, d)) { delete O[k]; n++; }
for (let m in mv) if (O[k] != null && under(k, m[0])) {
let v = O[k]; delete O[k]; n++;
if (insh(m[1])) O[m[1] + substr(k, length(m[0]))] = v;
}
}
for (let m in mv) if (!insh(m[0]) && O[m[1]] == null) { O[m[1]] = W.own; n++; }
for (let p in add) if (O[p] == null) { O[p] = W.own; n++; }
return n;
};
let O0 = cget().sown?.[id];
if (!fix(type(O0) == 'object' ? { ...O0 } : {})) return true;
return csave((X) => {
if (type(X.sown) != 'object') X.sown = {};
let O = type(X.sown[id]) == 'object' ? X.sown[id] : {};
fix(O);
let K = keys(O);
if (length(K) > SOWNMAX) for (let k in slice(K, 0, length(K) - SOWNMAX)) delete O[k];
X.sown[id] = O;
}) != null;
}
function jsown() {
for (let f in (lsdir(JOBS) ?? [])) {
if (!match(f, /^j[0-9a-z]{4,24}\.json$/)) continue;
let o = rjs(JOBS + '/' + f), u = type(o) == 'object' ? ownof(o) : 'admin';
let oid = o?.to_id ?? o?.id;
let S = type(o?.sown) == 'string' ? [ o.sown ] : (type(o?.sown) == 'array' ? filter(o.sown, (x) => type(x) == 'string') : null);
if (o?.state != 'ok' || !S || !length(S) || u == 'admin' || !acctok(oid)) continue;
if (!sownset(oid, { adm: false, own: u }, S)) continue;
delete o.sown; wjs600(JOBS + '/' + f, o);
}
}
function ulock(p) {
if (type(UCFG.upriv) == 'function') return UCFG.upriv(null, p, rjs(NASJ) ?? {}) != null;
let N = rjs(NASJ), U = N?.users;
for (let u, x in (type(U) == 'object' ? U : {})) {
if (type(x) != 'object' || x.cam) continue;
let r = UCFG.udir(u, 'root', null, N);
if (r != null && (under(p, '/' + r) || under('/' + r, p))) return true;
}
return false;
}
function upeople() {
let N = rjs(NASJ) ?? {}, r = [];
for (let u, x in (type(N.users) == 'object' ? N.users : {})) {
if (type(x) != 'object' || x.cam) continue;
let b = UCFG.udir(u, 'root', null, N);
if (b != null) push(r, b);
}
return sort(r);
}
function qfull(W) { return !W.adm && index(split(readfile('/tmp/wf-nas/full.list') ?? '', '\n'), W.own) >= 0; }
function pls(p, W) {
let d = (n) => ({ name: n, dir: true, size: 0, mtime: 0, shared: false, base: true });
if (p == '/') return { items: [ d(UD.root) ], path: p, more: false };
if (p == '/' + UD.root) return { items: [ d(W.vis), d(UD.shared) ], path: p, more: false };
return null;
}
function paths(a) {
let L = type(a.paths) == 'array' ? a.paths : (length(a.path ?? '') ? [ a.path ] : []), r = [];
if (!length(L) || length(L) > 500) return null;
for (let p in L) { let x = rpath(p); if (x == null || x == '/') return null; push(r, x); }
return r;
}
function diskof(id) {
for (let d in (rjs('/tmp/wf-nas/x/disks.json')?.list ?? [])) if (type(d) == 'object' && d.id == id) return d;
return null;
}
const SYSMNT = /^\/(|overlay|rom|boot|tmp|proc|sys|dev)$/;
function nodisk() {
for (let l in split(readfile(R + '/proc/mounts') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) >= 3 && match(p[0], /^\/dev\/(sd|nvme|mmcblk|md|mapper|dm-)/) && !match(p[1], SYSMNT) && !match(p[2], /^(squashfs|ubifs|jffs2|swap)$/)) return false;
}
return true;
}

function shmap(C) { return type(C.share) == 'object' ? C.share : {}; }
function shcache(S) {
if (match('' + (S?.cache ?? ''), /^(disk|int|none)$/)) return S.cache;
if (length('' + (S?.disk ?? ''))) return 'disk';
let M = rjs(NASMNT);
return type(M) == 'object' && length(keys(M)) ? 'disk' : 'none';
}
function intdir() { let d = trim(readfile(MNTD + '/intdir') ?? ''); return length(d) && substr(d, 0, 1) == '/' ? d : null; }
function intfree() {
let d = intdir(), p = d ? replace(d, /\/[^\/]*$/, '') : R + (stat(R + '/overlay') ? '/overlay' : '/');
while (length(p) > 1 && !stat(p)) p = replace(p, /\/[^\/]*$/, '');
if (!length(p)) p = '/';
if (!getenv('WF_NOSTATVFS') && type(FS.statvfs) == 'function') { let s = FS.statvfs(p); if (s && isnum(s.bavail)) return s.bavail * s.frsize; }
let l = split(trim(sh('df -kP ' + shq(p) + ' 2>/dev/null')), '\n'), x = split(l[length(l) - 1] ?? '', /[ \t]+/);
return length(x) >= 4 && match(x[3] ?? '', /^[0-9]+$/) ? +x[3] * 1024 : 0;
}
function shcdir(S, id) {
let c = shcache(S);
if (c == 'int') { let d = intdir(); return d ? d + '/' + id : null; }
let d = '' + (S?.disk ?? ''), m = match(d, /^[A-Za-z0-9_.:-]+$/) ? rjs(NASMNT)?.[d] : null;
return c == 'disk' && type(m) == 'string' ? m + '/.wf-cloud-cache/' + id : null;
}
function shdirs(S, id) {
let L = [], d = S?.rw === true ? shcdir(S, id) : null;
if (d) push(L, d);
else if (S?.rw === true && shcache(S) == 'int' && !intdir())
for (let c in [ '/overlay', '/srv', '/opt', '/usr/share' ]) { let x = R + c + '/wf-cloud-cache/' + id; if (stat(x)) push(L, x); }
push(L, R + '/root/.wf-cloud-cache/' + id);
return L;
}
function acdirs(S, id) {
let L = shdirs(S, id), k = split(trim(readfile(MNTD + '/' + id + '.key') ?? ''), '|'), M = rjs(NASMNT), d = intdir();
push(L, k[length(k) - 1]);
for (let n, m in (type(M) == 'object' ? M : {})) if (type(m) == 'string') push(L, m + '/.wf-cloud-cache/' + id);
if (d) push(L, d + '/' + id);
for (let c in [ '/overlay', '/srv', '/opt', '/usr/share' ]) push(L, R + c + '/wf-cloud-cache/' + id);
let U = {}, r = [];
for (let x in L) if (type(x) == 'string' && substr(x, 0, 1) == '/' && substr(x, -length(id) - 1) == '/' + id && !U[x]) { U[x] = 1; push(r, x); }
return r;
}
let DMORE = false;
function dirtyin(L) {
let n = 0, k = 0, Q = [];
DMORE = false;
for (let d in L) if (stat(d + '/vfsMeta')) push(Q, d + '/vfsMeta');
while (length(Q) && k < 3000) {
let p = pop(Q);
for (let f in (lsdir(p) ?? [])) {
if (++k > 3000) { DMORE = true; break; }
let x = p + '/' + f, t = lstat(x)?.type;
if (t == 'directory') push(Q, x);
else if (t == 'file' && match(readfile(x, 4096) ?? '', /"Dirty": *true/)) n++;
}
}
return n;
}
const PENDTTL = 30;
function shpdrop(id) { unlink(MNTD + '/' + id + '.pend'); }
function shpend(S, id) {
let L = shdirs(S, id), k = join('|', map(L, (d) => d + '=' + fpr(stat(d + '/vfsMeta')))), f = MNTD + '/' + id + '.pend', now = time();
let o = rjs(f);
if (type(o) == 'object' && o.k === k && type(o.n) == 'int' && isnum(o.t) && o.t <= now && now - o.t < PENDTTL) { DMORE = o.m === true; return o.n; }
let n = dirtyin(L);
if (stat(MNTD)?.type == 'directory') wjs(f, { t: now, k: k, n: n, ...(DMORE ? { m: true } : {}) });
return n;
}
function shout(C, id) {
let S = shmap(C)[id], M = rjs(MNTD + '/' + id + '.json');
if (type(S) != 'object') S = {};
if (type(M) != 'object') M = {};
let on = S.on === true, raw = match('' + M.st, /^(on|wait|err|off)$/) ? M.st : 'off', cs = tipi().cloudst, st = type(cs) == 'function' ? cs(S, M) : raw;
let r = { id: id, on: on, path: S.path ?? '', name: S.name ?? '', disk: S.disk ?? '', cache_gb: intin(S.cache_gb, 0, 500) ? S.cache_gb : 0, st: st,
why: M.why ?? '', why_en: M.why_en ?? '', why_code: M.why_code ?? '', mode: M.mode ?? '' };
if (st != raw && st == 'wait') { r.why = 'Accensione in corso'; r.why_en = 'Starting'; r.why_code = 'start'; }
else if (st != raw) { r.why = ''; r.why_en = ''; r.why_code = ''; r.mode = ''; }
r.cache = shcache(S); r.warn_ok = S.warn_ok === true; r.rw = S.rw === true; r.pending = shpend(S, id);
if (DMORE) r.pending_more = true;
let live = r.st == 'on';
r.speed = match('' + S.speed, /^(light|fast)$/) ? S.speed : 'auto';
r.speed_now = live && match('' + M.speed_now, /^(light|fast)$/) ? M.speed_now : '';
r.cache_used = live && isnum(M.cache_used) ? M.cache_used : 0; r.cache_max = live && isnum(M.cache_max) ? M.cache_max : 0;
r.cache_capped = live && M.cache_capped === true;
return r;
}
function shares(C) { let r = []; for (let id in sort(keys(shmap(C)))) if (acctok(id)) push(r, shout(C, id)); return r; }
function shname(n) { return type(n) == 'string' && length(n) >= 1 && length(n) <= 40 && !match(n, /[]["\/\\:;|=,+*?<>[:cntrl:]]/) && !match(n, /^[ .]|[ .]$/); }
function shpath(p) {
p = trim(replace(replace('' + (p ?? ''), /\/+/g, '/'), /^\/|\/$/g, ''));
if (length(p) > 1024 || match(p, /[[:cntrl:]]/) || incr('/' + p)) return null;
for (let x in split(p, '/')) if (x == '.' || x == '..') return null;
return p;
}
function inpath(n) { for (let d in [ '/usr/bin/', '/usr/sbin/', '/bin/', '/sbin/' ]) if (has(d + n)) return true; return false; }
function nasusers() { let U = rjs(NASJ)?.users; return filter(keys(type(U) == 'object' ? U : {}), (u) => match(u, /^[A-Za-z0-9_.-]+$/) != null); }
function shnet(id, W) {
let N = rjs(NASJ) ?? {}, u = W?.adm === true ? (type(UCFG.smbadm) == 'function' ? '' + (UCFG.smbadm(N) ?? '') : '') : '' + (W?.own ?? '');
let inl = (l, x) => length(x) > 0 && index(split(trim('' + (l ?? '')), ' '), x) >= 0, net = '', dav = null;
for (let l in split(readfile(MNTD + '/' + id + '.smb') ?? '', '\n')) {
let x = split(l, '|');
if (match(x[0], /^wfcloud_/) && x[6] !== '1' && inl(x[3], u)) { net = x[1]; break; }
}
for (let l in split(readfile(MNTD + '/' + id + '.dav') ?? '', '\n')) {
let x = split(l, '|');
if (length(x) < 4 || !length(x[0]) || !inl(x[2], u)) continue;
let p = N.remote?.port;
dav = { path: '/' + x[0], port: intin(p, 1, 65535) ? p : 5005, on: N.remote?.webdav === true, rw: inl(x[3], u) };
break;
}
return { net: net, dav: dav };
}
function share(a, ver, W) {
if (!acctok(a.id)) return E('none');
let id = a.id, C0 = cget(), A0 = null;
for (let x in accts(C0, facts(), ver)) if (x.id == id) A0 = x;
if (!A0) return E('none');
if (A0.user != 'admin' && (W == null || W.adm || A0.user != W.own)) return E('private');
let only = true;
for (let k in [ 'on', 'path', 'name', 'disk', 'cache_gb', 'cache', 'rw', 'speed' ]) if (exists(a, k)) only = false;
if (only) return { ...shout(C0, id), ...shnet(id, W) };
let O = shmap(C0)[id];
if (type(O) != 'object') O = {};
let on = exists(a, 'on') ? a.on : O.on === true;
if (type(on) != 'bool') return E('act');
let path = shpath(exists(a, 'path') ? a.path : (O.path ?? ''));
let name = exists(a, 'name') ? trim('' + (a.name ?? '')) : ('' + (O.name ?? cutn(trim('Cloud ' + replace('' + A0.name, /[]["\/\\:;|=,+*?<>[:cntrl:]]/g, '')), 40)));
let disk = '' + (exists(a, 'disk') ? (a.disk ?? '') : (O.disk ?? ''));
let cache = exists(a, 'cache') ? a.cache : shcache(O);
if (!match('' + cache, /^(disk|int|none)$/) || type(cache) != 'string') return E('act');
let gb = exists(a, 'cache_gb') ? a.cache_gb : (intin(O.cache_gb, 0, 500) && shcache(O) == cache ? O.cache_gb : 0);
if (!intin(gb, 0, 500)) return E('act');
let rw = exists(a, 'rw') ? a.rw : O.rw === true;
if (type(rw) != 'bool') return E('act');
if (rw && cache == 'none') return E('cache');
let speed = exists(a, 'speed') ? a.speed : (match('' + O.speed, /^(light|fast)$/) ? O.speed : 'auto');
if (type(speed) != 'string' || !match(speed, /^(auto|light|fast)$/)) return E('act');
let wok = a.ok_warn === true || O.warn_ok === true;
if (on) {
let t = tierf(), n = 0;
if (t == null) return { ...shout(C0, id), st: 'wait', why: 'Sto ancora valutando il router: riprova fra poco',
why_en: 'Still checking the router: try again shortly', why_code: 'tier', mode: '' };
if (t == 'A' && !wok) return E('warn', { error: 'Questo router ha poca memoria: la Cartella Cloud può rallentarlo',
error_en: 'This router has little memory: the Cloud Folder may slow it down', warn: true });
if (ver == null) return pkgE();
let pers = A0.user != 'admin', PU = {}, na = 0;
for (let x in (C0.accounts ?? [])) if (type(x) == 'object') PU[x.id] = auser(x) != 'admin';
for (let k, v in shmap(C0)) if (k != id && v?.on === true) { na++; if ((PU[k] === true) == pers) n++; }
if (t == 'A' && na >= 1) return E('many');
if (pers && n >= (t == 'C' ? 4 : 2)) return E('pmany');
if (!pers && (t == 'C' ? n >= 3 : n >= 1))
return E('many', t != 'C' ? null : { error: 'Al massimo tre Cartelle Cloud su questo router', error_en: 'At most three Cloud Folders on this router' });
if (A0.state != 'ok' && A0.state != 'err' && A0.state != 'busy') return E('acct');
if (path == null) return E('path');
if (!shname(name)) return E('name');
let ln = lc(name);
for (let k, v in shmap(C0)) if (k != id && lc('' + (v?.name ?? '')) == ln) return E('name');
for (let s in (rjs(NASJ)?.shares ?? [])) if (lc('' + (s?.name ?? '')) == ln) return E('name');
if (cache == 'disk' && (!match(disk, /^[A-Za-z0-9_.:-]+$/) || type(rjs(NASMNT)?.[disk]) != 'string')) return E('disk');
if (cache == 'int') {
let f = intfree(), G = 1073741824;
if (f < 2 * G || gb * G > f - G) return E('space', { error: 'Poco spazio nella memoria interna del router',
error_en: 'Not enough space in the router internal storage', int_free: f });
}
if (!inpath('fusermount3') && !inpath('fusermount')) return E('fuse');
if (!has('/etc/init.d/ksmbd') && !has('/etc/init.d/samba4')) return E('smb');
if (!length(nasusers())) return E('users');
}
else if (path == null) path = O.path ?? '';
let C = csave((X) => {
if (type(X.share) != 'object') X.share = {};
X.share[id] = { on: on, path: path, name: name, disk: disk, cache: cache, cache_gb: gb, rw: rw, speed: speed, ...(wok ? { warn_ok: true } : {}) };
});
if (!C) return E('busy');
shpdrop(id);
if (stat(R + CMSH)) detach('sh ' + R + CMSH + ' ' + (on ? 'start ' : 'stop ') + id);
return { ...shout(C, id), ...shnet(id, W) };
}

function pout(C, now) { return { on: pauseof(C, now), until: pauseof(C, now) ? C.pause.until : 0, by: C.pause.by }; }
function rout(C) { let T = C.router; return { on: T.on, acct: T.acct, every: T.every, day: T.day, keep: T.keep, before_fw: T.before_fw, last: T.last, ok: T.ok, pass: stat(BAKPW)?.size > 0 }; }
function simof(C, S) {
let L = C.line.sim;
return { on: S.sim_on === true, gb_today: isnum(S.sim_bytes) ? int(S.sim_bytes / 10000000) / 100 : 0, gb_cap: L.gb, from: L.from, to: L.to, all: L.all };
}
function crmap(A) { let r = {}; for (let a in A) if (a.crypt) r[a.id] = a.crypt; return r; }
function stateout() {
jsown();
let C = cget(), S = facts(), ver = rcver(), A = accts(C, S, ver), J = jlist(), c = jcount(J), now = time();
return { sum: sumof(C, S, ver, A, J, now), tier: tier(), today_bytes: isnum(S.today_bytes) ? S.today_bytes : 0, sim: simof(C, S),
n_acct: length(A), run: c.run, queue: c.queue, pause: pout(C, now), crypt: crmap(A) };
}
function avis(A, W) {
if (W.adm) return map(filter(A, (a) => a.user == 'admin'), (a) => ({ ...a, uses: filter(a.uses, (u) => u.own == 'admin'), people: ppl(a.uses) }));
let r = [];
for (let a in A) {
if (a.user == W.own) push(r, a);
else if (a.user == 'admin') { let x = { ...a, mail: '', used_by: 0, uses: [] }; push(r, x); }
}
return r;
}
function getout(W) {
jsown();
let C = cget(), S = facts(), ver = rcver(), A = accts(C, S, ver), J = jlist(), now = time();
let need = null;
for (let a in A) if (a.state == 'old') { let s = svcof(a.svc); if (vnum(s.need) > vnum(need)) need = s.need; }
let r = { rclone: { ok: ver != null && need == null, ver: ver ?? '', ...(need ? { need: need } : {}) }, tier: tier(), par: par(C),
svcs: svcs(ver), accounts: avis(A, W), sum: sumof(C, S, ver, A, J, now, W), line: C.line, pause: pout(C, now), router: rout(C),
jobs: jcount(W.adm ? J : filter(J, (j) => j.own == W.own)), today_bytes: isnum(S.today_bytes) ? S.today_bytes : 0, sim: simof(C, S),
nodisk: nodisk(), lim: C.lim, shares: shares(C), int_free: intfree() };
if (!W.adm) for (let k in [ 'router', 'shares', 'line', 'lim', 'int_free' ]) delete r[k];
if (!W.adm) r.pause_own = C.ppause?.[W.own] === true;
else { let U = []; for (let a in A) push(U, ...a.uses); r.people = ppl(U); r.n_all = length(A); }
return r;
}

function qput(o, name, from) {
let job = o.job ?? ('j' + rid()), now = time();
o = { ...o, job: job, name: o.name ?? name, t: now, own: o.own ?? WO };
if (!wjs600(QD + '/' + job + '.json', o) || !wjs600(JOBS + '/' + job + '.q.json', o)) return E('busy');
wjs600(JOBS + '/' + job + '.json', { ...o, from: from ?? '', to: o.to ?? '', state: 'wait',
wc: 'queue', why: 'In coda', why_en: 'Queued', pct: 0, speed: 0, bytes: 0, size: 0 });
unlink(JOBS + '/' + job + '.stop');
genup(o.id); if (o.to_id != o.id) genup(o.to_id);
kicktick();
return { job: job };
}
function base(p) { return replace(p, /^.*\//, '') || p; }

function lget() { let o = rjs(LJ); return type(o?.items) == 'array' ? o.items : []; }
function lout(now, W) {
return map(filter(lget(), (x) => type(x) == 'object' && (W.adm || ownof(x) == W.own)), (x) => ({ req: x.req, id: x.id, path: x.src ?? x.path, own: ownof(x), kind: x.kind == 'upreq' || x.kind == 'pub' ? x.kind : 'link',
...(x.kind == 'pub' ? { mode: x.mode == 'rw' ? 'rw' : 'r' } : {}),
...(type(x.copy) == 'string' && length(x.copy) ? { copy: true } : {}),
expire: isnum(x.expire) ? x.expire : 0, hits: isnum(x.hits) ? x.hits : 0, ...(x.kind == 'upreq' ? { files: isnum(x.files) ? x.files : 0 } : {}),
state: isnum(x.expire) && x.expire > 0 && x.expire < now ? 'old' : 'on' }));
}
function lres(now, W) {
let L = lout(now, W);
if (!padm(W)) return { items: L };
return { items: filter(L, (x) => x.own == 'admin'), people: ppl(L, (x) => x.state == 'old' ? 'warn' : 'ok',
(p, x) => { if (x.kind == 'pub' && x.state != 'old') p.inv = (p.inv ?? 0) + 1; }) };
}

function tokok(svc, t) {
if (type(t) != 'string' || length(t) > 16384 || match(t, /[\r\n]/)) return null;
let o = null;
try { o = json(t); } catch (e) { return null; }
if (type(o) != 'object' || type(o.access_token) != 'string' || !length(o.access_token)) return null;
return o;
}
function fieldsok(s, F) {
if (type(F) != 'object') return null;
let r = {};
for (let f in s.fields) {
let v = F[f.k];
if (v == null || v === '') { if (f.req) return null; continue; }
v = '' + v;
if (length(v) > 1024 || match(v, /[[:cntrl:]]/)) return null;
if (f.type == 'url' && !match(v, /^https?:\/\/[^ ]+$/)) return null;
if (f.type == 'num' && !match(v, /^[0-9]{1,5}$/)) return null;
if (f.opt && index(f.opt, v) < 0) return null;
r[f.k] = v;
}
return r;
}
function newid(C) {
let N = rcnames();
for (let n = 1; n <= 99; n++) {
let id = 'a' + n, used = false;
for (let a in C.accounts) if (a.id == id) used = true;
if (!used && !stat(TMP + '/.new-' + id) && !N[rcname(id)]) return id;
}
return null;
}
function newname(C, s) {
for (let n = 1; n <= 99; n++) {
let nm = n == 1 ? s.name : s.name + ' ' + n, used = false;
for (let a in C.accounts) if (a.name == nm) used = true;
if (!used) return nm;
}
return s.name;
}
function auth(a, C, ver, W, xcid) {
if (length(a.id ?? '')) {
for (let x in C.accounts) if (x.id == a.id && auser(x) != W.own) return W.adm ? E('private') : E('none');
}
else if (!W.adm && length(filter(C.accounts, (x) => auser(x) == W.own)))
return E('max', { error: 'Un solo cloud personale per persona', error_en: 'One personal cloud per person' });
let s = svcof(a.svc);
if (!s) return E('svc');
if (!svcok(s, ver)) return E('old');
let D = { svc: s.id };
if (s.auth == 'oauth') {
if (!tokok(s.id, a.token)) return E('token');
D.token = a.token;
let F = type(a.fields) == 'object' ? a.fields : {}, ok1 = (v, re) => type(v) == 'string' && match(v, re) != null;
let own = s.id == 'drive' && (a.own === true || (F.client_id != null && F.client_secret != null));
if (own) {
if (!ok1(F.client_id, /^[A-Za-z0-9._~-]{8,200}$/) || !ok1(F.client_secret, /^[A-Za-z0-9._~-]{8,200}$/)) return E('fields');
D.own = true; D.client_id = F.client_id; D.client_secret = F.client_secret;
}
if (s.id == 'onedrive') {
if (!ok1(F.drive_id, /^[A-Za-z0-9!._~-]{1,200}$/) || (F.drive_type != null && !ok1(F.drive_type, /^(personal|business|documentLibrary)$/)))
return E('fields', { error: "Manca l'ID dell'unità di OneDrive", error_en: 'OneDrive drive ID missing' });
D.drive_id = F.drive_id; D.drive_type = F.drive_type ?? 'personal';
}
if (!own && match(s.id, /^(drive|onedrive|dropbox|box)$/) && F.client_id != null && F.client_id !== '') {
if (!ok1(F.client_id, /^[A-Za-z0-9._~-]{8,200}$/) || (F.client_secret != null && F.client_secret !== '' && !ok1(F.client_secret, /^[A-Za-z0-9._~-]{8,200}$/))) return E('fields');
D.client_id = F.client_id;
if (F.client_secret != null && F.client_secret !== '') D.client_secret = F.client_secret;
}
if (xcid != null) D.client_id = xcid;
}
else { let F = fieldsok(s, a.fields); if (!F) return E('fields'); D.fields = F; }
if (s.warn && a.ok_warn !== true) return E('warn', { warn: s.warn });
let H = rjs(TMP + '/newh.json');
if (type(H) != 'object') H = {};
let h = hk(W.own + '|' + sprintf('%J', D)), now = time();
for (let k, v in H) if (type(v) != 'object' || now - v.t > 600) delete H[k];
if (H[h] && (!length(a.id ?? '') || a.id == H[h].id) && stat(TMP + '/.new-' + H[h].id)) {
let id = H[h].id, o = resof(reqid('auth', { id: id }));
return o ? { ...o, id: id } : { id: id, pending: reqid('auth', { id: id }) };
}
let id = null, relink = false;
if (length(a.id ?? '')) {
for (let x in C.accounts) if (x.id == a.id) id = x.id;
if (!id) return E('none');
relink = true;
for (let x in C.accounts) if (x.id == id && x.svc != s.id) return E('svc');
}
else {
if (length(C.accounts) >= AMAX) return E('max');
id = newid(C);
if (!id) return E('max');
}
D.id = id; D.relink = relink; D.t = now;
if (!wjs600(TMP + '/.new-' + id, D)) return E('busy');
if (!relink) {
let CW = csave((X) => {
if (length(X.accounts) >= AMAX) die('max');
push(X.accounts, { id: id, svc: s.id, name: newname(X, s), zone: '', mail: '', t_link: now, t_use: now,
own: D.own === true, ...(W.adm ? {} : { user: W.own }), warn_ok: s.warn ? true : false, ...(s.id == 'icloud' ? { relink_at: now + 30 * DAY } : {}),
...(D.drive_id ? { drive_id: D.drive_id, drive_type: D.drive_type } : {}) });
});
if (!CW) { unlink(TMP + '/.new-' + id); return E('busy'); }
}
else if (s.id == 'drive' || s.id == 'onedrive') {
if (!csave((X) => { for (let x in X.accounts) if (x.id == id) { x.t_link = now; if (s.id == 'drive') x.own = D.own === true;
if (D.drive_id) { x.drive_id = D.drive_id; x.drive_type = D.drive_type; } } })) { unlink(TMP + '/.new-' + id); return E('busy'); }
}
else if (s.id == 'icloud') {
if (!csave((X) => { for (let x in X.accounts) if (x.id == id) { x.relink_at = now + 30 * DAY; x.t_link = now; } })) { unlink(TMP + '/.new-' + id); return E('busy'); }
}
H[h] = { id: id, t: now };
wjs600(TMP + '/newh.json', H);
let rq = reqid('auth', { id: id });
unlink(RES + '/' + rq + '.json'); unlink(REQ + '/' + rq + '.json');
let p = pend('auth', { id: id }, rq);
return { id: id, ...p };
}

const DL = TMP + '/dl', NST = '/tmp/wf-nas/x/st', SIDLE = 1800, SMAX = 43200, DLMAX = 3600;
const B64U = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
function token() {
let s = readfile('/dev/urandom', 24) ?? '', o = '';
if (length(s) < 24) s = rid() + rid() + rid();
for (let i = 0; i + 2 < 24; i += 3) {
let v = (ord(s, i) << 16) | (ord(s, i + 1) << 8) | ord(s, i + 2);
o += substr(B64U, (v >> 18) & 63, 1) + substr(B64U, (v >> 12) & 63, 1) + substr(B64U, (v >> 6) & 63, 1) + substr(B64U, v & 63, 1);
}
return o;
}
function dltok(t) { return type(t) == 'string' && match(t, /^[A-Za-z0-9_-]{16,64}$/) != null; }
function urlenc(s) {
s = '' + s; let o = '';
for (let i = 0; i < length(s); i++) { let c = substr(s, i, 1); o += match(c, /^[A-Za-z0-9._~-]$/) ? c : sprintf('%%%02X', ord(s, i)); }
return o;
}
function stlive(e, j, now) { return type(e) == 'object' && e.cloud === j && now - (e.a ?? 0) < SIDLE && now - (e.t ?? 0) < SMAX && now < (e.x ?? 0); }
function dlsweep(now) {
for (let f in (lsdir(DL) ?? [])) {
let m = match(f, /^(j[0-9a-z]{4,24})(\.tok)?$/);
if (!m) continue;
let F = DL + '/' + m[1], K = rjs(F + '.tok'), tk = dltok(K?.tk) ? K.tk : null, s = lstat(F);
let gone = m[2] ? !s : (!s ? false : (K ? (now >= (K.x ?? 0) || !stlive(tk ? rjs(NST + '/' + tk + '.json') : null, m[1], now)) : now - s.mtime >= DLMAX));
if (!gone) continue;
if (tk) unlink(NST + '/' + tk + '.json');
if (s) unlink(F);
unlink(F + '.tok');
}
}
function dl(a, now, W) {
if (!jobok(a.job)) return E('job');
let o = rjs(JOBS + '/' + a.job + '.json');
if (type(o) != 'object' || o.kind != 'down' || (!W.adm && ownof(o) != W.own)) return E('job');
let F = DL + '/' + a.job, s = lstat(F);
if (o.state != 'ok' || s?.type != 'file') return E('fail');
let nm = type(o.paths) == 'array' && type(o.paths[0]) == 'string' ? base(o.paths[0]) : '' + (o.name ?? '');
if (!nameok(nm)) nm = 'file';
let K = rjs(F + '.tok'), x = now + DLMAX;
if (type(K) == 'object') { if (isnum(K.x) && K.x > now) x = K.x; if (dltok(K.tk)) unlink(NST + '/' + K.tk + '.json'); }
mkdirp(NST);
let S = filter(lsdir(NST) ?? [], (f) => match(f, /^[A-Za-z0-9_-]+\.json$/) != null);
S = sort(S, (p, q) => (rjs(NST + '/' + p)?.a ?? 0) - (rjs(NST + '/' + q)?.a ?? 0));
while (length(S) >= 50) unlink(NST + '/' + shift(S));
let tk = token();
if (!wjs600(NST + '/' + tk + '.json', { p: F, n: nm, t: now, a: now, dl: true, cloud: a.job, x: x }) || !wjs600(F + '.tok', { tk: tk, x: x })) {
unlink(NST + '/' + tk + '.json');
return E('fail');
}
let u = '/t/' + tk + '/' + urlenc(nm);
return { url: u, path: '/cgi-bin/wf-nasx' + u + '?dl=1', size: s.size, name: nm, tok: tk, until: x };
}

const DEVJ = TMP + '/dev', DEVMAX = 5;
function devok(id) { return type(id) == 'string' && match(id, /^d[0-9a-z]{4,24}$/) != null; }
function devls() {
let r = [];
for (let f in (lsdir(DEVJ) ?? [])) { let m = match(f, /^(d[0-9a-z]{4,24})\.json$/), o = m ? rjs(DEVJ + '/' + f) : null; if (type(o) == 'object' && o.id == m[1]) push(r, o); }
return r;
}
function devlive(o, now) {
if (o.st != 'start' && o.st != 'wait') return false;
if (isnum(o.until) && o.until > 0 && now >= o.until) return false;
return length(o.pid ?? '') ? alive(o.pid) : now - (o.t ?? 0) < 30;
}
function devsweep(now) {
for (let f in (lsdir(DEVJ) ?? [])) {
let F = DEVJ + '/' + f, s = stat(F);
if (!s) continue;
if (match(f, /^\./)) { if (now - s.mtime > 120) unlink(F); continue; }
let o = rjs(F);
if (type(o) != 'object' || (!devlive(o, now) && now - s.mtime > 600)) unlink(F);
}
}
function devans(o) { return o.st == 'wait' && length(o.code ?? '') ? { id: o.id, code: o.code, url: o.url, until: o.until } : { id: o.id, pending: o.id }; }
function devcode(a, W, ver) {
let s = svcof(a.svc);
if (!s) return E('svc');
if (devcid(s.id) == null) return E('nocode');
if (!svcok(s, ver)) return E('old');
let nd = need('code');
if (length(nd)) return E('pkg', { need: nd });
let C = cget(), rel = length(a.id ?? '') ? '' + a.id : '';
if (length(rel)) {
let x = null;
for (let y in C.accounts) if (y.id == rel) x = y;
if (!x) return E('none');
if (auser(x) != W.own) return W.adm ? E('private') : E('none');
if (x.svc != s.id) return E('svc');
}
else if (!W.adm && length(filter(C.accounts, (x) => auser(x) == W.own)))
return E('max', { error: 'Un solo cloud personale per persona', error_en: 'One personal cloud per person' });
else if (length(C.accounts) >= AMAX) return E('max');
let now = time();
mkdirp(DEVJ, 0700);
devsweep(now);
let L = devls(), n = 0;
for (let o in L) if (o.own == W.own && o.svc == s.id && (o.rel ?? '') == rel && devlive(o, now)) return devans(o);
for (let o in L) { if (o.own == W.own) unlink(DEVJ + '/' + o.id + '.json'); else if (devlive(o, now)) n++; }
if (n >= DEVMAX) return E('busy');
let id = 'd' + rid();
if (!wjs600(DEVJ + '/' + id + '.json', { id: id, svc: s.id, own: W.own, adm: W.adm === true, rel: rel, st: 'start', t: now, pid: '' })) return E('busy');
detach('ucode ' + shq(SELF) + ' devflow ' + id);
return { id: id, pending: id };
}
function devpoll(a, W) {
let o = devok(a.id) ? rjs(DEVJ + '/' + a.id + '.json') : null, now = time();
if (type(o) != 'object' || o.id != a.id || o.own != W.own) return { state: 'expired' };
if (o.st == 'ok') {
let A = acct(o.acct);
return { state: 'ok', acct: A ? { id: A.id, name: A.name, svc: A.svc, state: A.state } : { id: o.acct, name: '', svc: o.svc, state: 'new' } };
}
if (o.st == 'denied') return { state: 'denied' };
if (o.st == 'err') return { state: 'expired', why: o.why ?? 'fail' };
if (!devlive(o, now)) return { state: 'expired' };
return o.st == 'wait' && length(o.code ?? '') ? { state: 'wait', code: o.code, url: o.url, until: o.until } : { state: 'wait' };
}
function devjs(o) { try { let j = json(o); return type(j) == 'object' ? j : null; } catch (e) { return null; } }
function hpost(url, body) {
let f = DEVJ + '/.b-' + PID + '-' + rid();
if (!wsec(f, body)) return null;
let o = sh('curl -s -m 20 --connect-timeout 10 -H "Expect:" -H "Accept: application/json" --data-binary @' + shq(f) + ' ' + shq(url) + ' </dev/null 2>/dev/null');
unlink(f);
return devjs(o);
}
function kfile(s) { let f = DEVJ + '/.h-' + PID + '-' + rid(); return wsec(f, s) ? f : null; }
function hget(url, at) {
if (!match(at, /^[A-Za-z0-9._~+\/=-]+$/)) return null;
let f = kfile('header = "Authorization: Bearer ' + at + '"\n');
if (f == null) return null;
let o = sh('curl -s -m 20 --connect-timeout 10 -K ' + shq(f) + ' -H "Accept: application/json" ' + shq(url) + ' </dev/null 2>/dev/null');
unlink(f);
return devjs(o);
}
function rfc3339(t) { let g = gmtime(t); return sprintf('%04d-%02d-%02dT%02d:%02d:%02dZ', g.year, g.mon, g.mday, g.hour, g.min, g.sec); }
function cl(v, a, b, d) { v = type(v) == 'int' ? v : (type(v) == 'string' && match(v, /^[0-9]{1,6}$/) ? +v : d); return v < a ? a : v > b ? b : v; }
function devflow(id) {
CLI = true; LG = uilang(); begintmp();
let F = DEVJ + '/' + id + '.json', o = rjs(F);
if (type(o) != 'object' || o.id != id || o.st != 'start') return 1;
let P = DEVP[o.svc], cid = devcid(o.svc);
let put = (x) => { let c = rjs(F); if (type(c) != 'object' || c.id != id) return false; for (let k, v in x) o[k] = v; return wjs600(F, o); };
if (!put({ pid: PID })) return 0;
if (!P || cid == null) { put({ st: 'err', why: 'fail' }); return 1; }
let r = hpost(P.dc, 'client_id=' + urlenc(cid) + '&scope=' + urlenc(P.scope));
let url = '' + (r?.verification_uri ?? r?.verification_url ?? '');
if (type(r?.device_code) != 'string' || type(r?.user_code) != 'string' || !match(url, /^https:\/\/[^ ]+$/)) {
put({ st: 'err', why: r == null ? 'net' : 'fail' });
return 1;
}
let now = time(), until = now + cl(r.expires_in, 60, 1800, 900), iv = cl(r.interval, 1, 60, 5);
if (!put({ st: 'wait', code: cutn(r.user_code, 24), url: cutn(url, 200), until: until })) return 0;
let body = 'grant_type=' + urlenc('urn:ietf:params:oauth:grant-type:device_code') + '&client_id=' + urlenc(cid) + '&device_code=' + urlenc(r.device_code);
r = null;
while (time() < until) {
sh('sleep ' + iv);
if (rjs(F)?.id != id) return 0;
let t = hpost(P.tk, body);
if (t == null) continue;
if (type(t.access_token) == 'string' && length(t.access_token)) {
body = null;
let d = hget(P.drive, t.access_token);
if (type(d?.id) != 'string' || !length(d.id)) { put({ st: 'err', why: 'fail', code: '' }); return 1; }
let tk = { access_token: t.access_token, token_type: 'Bearer', refresh_token: '' + (t.refresh_token ?? ''),
expiry: rfc3339(time() + cl(t.expires_in, 60, 86400, 3600)) };
let W = { adm: o.adm === true, own: o.own };
WO = W.own;
let x = auth({ svc: o.svc, token: sprintf('%J', tk), fields: { drive_id: d.id, drive_type: d.driveType ?? 'personal' }, ...(length(o.rel ?? '') ? { id: o.rel } : {}) },
cget(), rcver(), W, cid);
t = null; tk = null;
if (x?.error) { put({ st: 'err', why: x.code, code: '' }); return 1; }
put({ st: 'ok', acct: x.id, code: '' });
return 0;
}
let e = '' + (t.error ?? '');
if (e == 'authorization_pending') continue;
if (e == 'slow_down') { iv += 5; continue; }
if (e == 'authorization_declined' || e == 'access_denied') { put({ st: 'denied', code: '' }); return 0; }
if (e == 'expired_token' || e == 'code_expired' || e == 'bad_verification_code') break;
put({ st: 'err', why: 'fail', code: '' });
return 1;
}
put({ st: 'expired', code: '' });
return 0;
}

const HOMEJ = TMP + '/home.json', HOMEAGE = 1800, HOMED = TMP + '/home.dirty';
function homekick(now, gap) {
if (!has('/usr/bin/rclone')) return;
if (alive(trim(readfile(TMP + '/home.pid') ?? ''))) { if (gap < 600) writefile(TMP + '/home.again', '' + now); return; }
let k = stat(TMP + '/home.kick');
if (k && now - k.mtime < gap && k.mtime <= now + 60) {
let l = stat(TMP + '/home.later');
if (gap < 600 && !(l && now - l.mtime < 120 && l.mtime <= now + 60)) {
writefile(TMP + '/home.later', '' + now);
detach('sleep ' + (gap - (now - k.mtime) + 1) + '; ucode ' + shq(SELF) + ' ukick');
}
return;
}
unlink(TMP + '/home.later');
writefile(TMP + '/home.kick', '' + now);
detach('ucode ' + shq(SELF) + ' usize');
}
function homedirty() {
let o = {};
for (let l in split(readfile(HOMED) ?? '', '\n')) if (length(l = trim(l))) o[l] = true;
return o;
}
function ukick() { CLI = true; begintmp(); homekick(time(), 60); return 0; }
function uhome(own) {
begintmp();
let H = rjs(HOMEJ), now = time(), D = homedirty();
let old = type(H) != 'object' || !isnum(H.t) || now - H.t >= HOMEAGE || H.t > now + 60;
if (old || length(D)) homekick(now, 600);
let u = H?.users?.[own];
if (type(u) != 'object' || !isnum(u.used)) return null;
let stale = old || D['*'] === true || D[own] === true || alive(trim(readfile(TMP + '/home.pid') ?? ''));
return { used: u.used, t: H.t, stale: stale, others: isnum(H.tot) && u.ok === true ? (H.tot > u.used ? H.tot - u.used : 0) : null };
}
function cqfull(W) {
if (W.adm) return false;
let q = +(rjs(NASJ)?.users?.[W.own]?.quota?.cloud ?? 0), u = rjs(HOMEJ)?.users?.[W.own]?.used;
return q > 0 && isnum(u) && u >= q * 1073741824;
}
function cqev(U, N) {
let ev = getenv('WF_EVENTSH') ?? R + '/usr/share/wrtfreedom/event.sh', F = TMP + '/qev.json', S = rjs(F) ?? {}, S2 = {}, en = LG == 'en', any = false;
for (let u, x in U) {
let q = +(N?.users?.[u]?.quota?.cloud ?? 0);
if (q <= 0 || type(x) != 'object' || !isnum(x.used) || x.ok !== true) continue;
let p = int(x.used * 100 / (q * 1073741824)), lv = p >= 100 ? 2 : p >= 90 ? 1 : 0, old = +(S[u] ?? 0);
if (lv) S2[u] = lv;
if (lv != old) any = true;
if (lv <= old || !stat(ev)) continue;
let ty = lv == 2 ? 'cloud_full' : 'cloud_quota', vis = '' + (N.users[u].vis ?? u);
let me = lv == 2 ? (en ? '⚠️ Cloud ¦ Cloud Full ¦ Free some space or ask for more' : '⚠️ Cloud ¦ Cloud Pieno ¦ Libera spazio o chiedi più spazio')
: (en ? '⚠️ Cloud ¦ Cloud At ' + p + '% ¦ Almost full' : '⚠️ Cloud ¦ Cloud Al ' + p + '% ¦ Quasi pieno');
let ad = '⚠️ Cloud ¦ ' + vis + ': ' + (lv == 2 ? (en ? 'Cloud Full' : 'Cloud Pieno') : (en ? 'Cloud At ' : 'Cloud Al ') + p + '%');
detach('WF_SOLO=1 sh ' + shq(ev) + ' cron ' + ty + ' cloud ' + shq(me) + ' ' + shq(u) + '; sh ' + shq(ev) + ' cron ' + ty + ' cloud ' + shq(ad));
}
for (let u in keys(S)) if (S2[u] == null && U[u] == null && S[u] != null) S2[u] = S[u];
if (any) wjs(F, S2);
}
function usize() {
CLI = true; begintmp();
let pf = TMP + '/home.pid', ag = TMP + '/home.again';
if (alive(trim(readfile(pf) ?? ''))) { writefile(ag, '' + time()); return 1; }
let up = length(R) ? (getenv('WF_UPTIME') != null ? +getenv('WF_UPTIME') : 600) : +(split(readfile('/proc/uptime') ?? '600', ' ')[0]);
if (up < 600) return 0;
let so = stat(CSH) ? sh('sh ' + shq(CSH) + ' slot get usize - ' + PID + ' </dev/null 2>/dev/null') : '', sl = match(so, /^ok /) != null;
if (match(so, /^wait/)) { sh('sh ' + shq(CSH) + ' slot put usize </dev/null >/dev/null 2>&1'); return 0; }
let slput = () => { if (sl) sh('sh ' + shq(CSH) + ' slot put usize </dev/null >/dev/null 2>&1'); };
writefile(pf, PID);
unlink(ag);
let C = cget(), S = facts(), ver = rcver(), N = rjs(NASJ), now = time(), d0 = stat(HOMED)?.size ?? 0;
if (ver == null || pauseof(C, now) || migrating()) { unlink(pf); slput(); return 0; }
let A = filter(accts(C, S, ver), (a) => a.user == 'admin' && a.state == 'ok'), U = {};
let tc = TMP + '/.home-' + PID + '.conf';
for (let f in (lsdir(TMP) ?? [])) if (match(f, /^\.home-[0-9]+\.conf$/) && TMP + '/' + f != tc) unlink(TMP + '/' + f);
if (length(A) && !wsec(tc, rcnoref(readfile(RC) ?? ''))) { unlink(pf); slput(); return 1; }
let rc = (c, to) => devjs(sh('T=; command -v timeout >/dev/null 2>&1 && T="timeout ' + to + '"; RCLONE_CONFIG=' + shq(tc) + ' $T rclone ' + c + ' </dev/null 2>/dev/null'));
for (let u in nasusers()) {
let p = UCFG.udir(u, 'root', null, N);
if (p == null) continue;
let b = 0, ok = false;
for (let a in A) {
let o = rc('size --json ' + shq(rcname(a.id) + ':' + p), 300);
if (o != null) ok = true;
if (isnum(o?.bytes) && o.bytes > 0) b += o.bytes;
}
U[u] = { used: b, ok: ok };
}
let AB = filter(A, (a) => svcof(a.svc)?.caps?.about === true), tot = length(AB) ? 0 : null;
for (let a in AB) {
let o = rc('about --json ' + shq(rcname(a.id) + ':'), 60);
if (!isnum(o?.used)) { tot = null; break; }
let n = o.used - (isnum(o.trashed) && o.trashed > 0 ? o.trashed : 0);
if (n > 0) tot += n;
}
unlink(tc);
wjs(HOMEJ, { t: time(), tot: tot, users: U });
cqev(U, N);
let dm = stat(HOMED);
if (dm && dm.size <= d0) unlink(HOMED);
else if (dm) writefile(ag, '' + time());
unlink(pf); slput();
if (stat(ag)) { unlink(ag); detach('ucode ' + shq(SELF) + ' usize'); }
return 0;
}

const READ = { get: 1, devpoll: 1, about: 1, ls: 1, jobs: 1, find: 1, res: 1, dl: 1, thumbs: 1, revs: 1, trash: 1, stream: 1, photo: 1, crypt: 1, size: 1 };
const NEEDRC = { auth: 1, devcode: 1, about: 1, ls: 1, mkdir: 1, move: 1, rm: 1, xfer: 1, put: 1, link: 1, upreq: 1, find: 1, rtget: 1,
thumbs: 1, revs: 1, revert: 1, trash: 1, restore: 1, stream: 1, photo: 1, empty: 1, size: 1 };
function ready(id, ver) {
if (!acctok(id)) return E('none');
let C = cget(), S = facts(), A = null;
for (let x in accts(C, S, ver)) if (x.id == id) A = x;
if (!A) return E('none');
if (A.state == 'old') return E('old');
if (A.state == 'relink') return E('relink');
if (A.state == 'new' || A.state == 'busy') return E('busy');
return A;
}
const ADMONLY = { line: 1, pause: 1, router: 1, share: 1, rtget: 1 };
function tppl() {
let N = rjs(NASJ) ?? {}, r = [];
for (let u, x in (type(N.users) == 'object' ? N.users : {})) {
if (type(x) != 'object' || x.cam) continue;
let b = UCFG.udir(u, 'root', null, N);
if (b != null) push(r, { own: u, own_name: UCFG.bname(b), dir: '/' + b });
}
return { l: sort(r, (a, b) => a.own < b.own ? -1 : a.own > b.own ? 1 : 0) };
}
function tpx(AP, W) { if (!AP || !padm(W)) return {}; let p = tppl(); return length(p.l) ? { ppl: p } : {}; }
const CRLOSS = [
[ 'Niente link di pCloud diretti sulle cartelle private: Condividi di WrtFreedom ne mette una copia in Link Condivisi', 'No direct pCloud links on private folders: Share in WrtFreedom puts a copy in Shared Links' ],
[ "Nell'app e nel sito di pCloud nomi illeggibili, niente anteprime né ricerca: usa Sfoglia di WrtFreedom", 'In the pCloud app and website names are unreadable, no previews or search: use Browse in WrtFreedom' ],
[ 'Caricare e scaricare è più lento', 'Uploading and downloading is slower' ]
];
const CRKA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function knorm(k) {
k = replace(uc('' + (k ?? '')), /[^A-Z0-9]/g, '');
if (length(k) != 24) return null;
let r = '';
for (let i = 0; i < 24; i++) { let c = substr(k, i, 1); if (index(CRKA, c) < 0) return null; r += c + (i % 4 == 3 && i < 23 ? '-' : ''); }
return r;
}
function crpaused(A) { return A?.pause === true; }
function crkick() { if (stat(CSH)) detach('sh ' + shq(CSH) + ' crtick'); }
function crfresh(CA) {
for (let x in CA) {
if (alive(trim(readfile(CRD + '/' + x.id + '.lk/pid') ?? ''))) continue;
for (let k in [ 'todo', 'res', 'skip', 'nid' ]) unlink(CRD + '/' + x.id + '.' + k);
}
}
function crnum(v) { return isnum(v) ? v : 0; }
function crout(id, W, CR) {
CR = CR ?? crget();
let A = type(CR.accts[id]) == 'object' ? CR.accts[id] : {}, s = crst(CR, id), now = time(), nt = 0, why = [ '', '' ];
let pz = (s.st == 'mig' || s.st == 'back') && crpaused(A);
if (s.st == 'mig' || s.st == 'back') {
if (pz) why = [ 'In pausa: tocca Riprendi per continuare', 'Paused: tap Resume to continue' ];
else {
nt = now;
why = s.st == 'mig' ? [ 'In corso in sottofondo, con le regole della linea del cloud', 'Running in the background, with the cloud line rules' ]
: [ 'Torna in chiaro in sottofondo, con le regole della linea del cloud', 'Going back to plain in the background, with the cloud line rules' ];
if (type(A.err) == 'string' && ERR[A.err]) why = ERR[A.err];
}
}
else if (s.st == 'setup') why = [ 'Salva la chiave per cominciare', 'Save the key to start' ];
else if (s.st == 'on') why = [ 'Tutte le cartelle private sono cifrate', 'All private folders are encrypted' ];
let r = { on: CR.on, st: s.st, keyok: CR.keyok, pause: pz, pct: s.pct, done_b: crnum(A.done_b), tot_b: crnum(A.tot_b), fail_n: crnum(A.fail_n),
next_t: nt, why: why[0], why_en: why[1], loss: map(CRLOSS, (x) => ({ t: x[0], t_en: x[1] })) };
let LF = rjs(CRD + '/' + id + '.left');
if (type(LF) == 'object' && type(LF.n) == 'int' && type(LF.bad) == 'int') { r.todo_n = LF.n > 0 ? LF.n : 0; r.bad_n = LF.bad > 0 ? LF.bad : 0; }
let ln = 0;
for (let k, v in (type(A.long) == 'object' ? A.long : {})) if (isnum(v) && v > 0) ln += int(v);
if (type(LF) == 'object' && type(LF.fail) == 'int' && type(LF.long) == 'int') { r.fail_n = LF.fail > 0 ? LF.fail : 0; ln = LF.long > 0 ? LF.long : 0; }
r.long_n = ln;
r.keyok_t = CR.keyok ? crnum(CR.keyok_t) : 0;
let CK = rjs(ETC + '/cloud-cifra-ck.json'), ck = type(CK?.[id]) == 'object' ? CK[id] : {};
r.ck_t = crnum(ck.t); r.ck_n = crnum(ck.n); r.ck_bad = crnum(ck.bad);
let kb = crnum(CR.keytest_at) || crnum(CR.keyok_t) || crnum(CR.t_on);
r.keytest_at = crnum(CR.keytest_at);
r.keytest_due = CR.on && CR.keyok && match(s.st, /^(mig|on)$/) != null && kb > 0 && now - kb > 90 * DAY;
let N = rjs(NASJ) ?? {}, V = {}, L = [], tg = s.st == 'back' || s.st == 'off' ? 'clear' : 'enc';
for (let u, x in (type(N.users) == 'object' ? N.users : {})) {
let d = type(x) == 'object' && !x.cam ? UCFG.udir(u, 'root', null, N) : null;
if (d != null) V[lc(UCFG.bname(d))] = u;
}
for (let k, v in (type(A.f) == 'object' ? A.f : {})) {
let o = V[lc(split(k, '/')[0])];
if (o == null || (!W.adm && o != W.own)) continue;
push(L, { own: o, st: v == tg ? 'ok' : s.st == 'setup' || s.st == 'off' ? 'none' : 'run' });
}
r.people = ppl(L, (x) => x.st);
return r;
}
function crset(CA) { if (length(CA)) detach(join('; ', map(CA, (x) => 'sh ' + shq(CSH) + ' cryptset ' + x.id))); }
const CRSHOW = CRD + '/.show';
function crshput(k) { let h = ''; for (let i = length(k) - 1; i >= 0; i--) h += sprintf('%02x', ord(k, i)); return wsec(CRSHOW, h + '\n'); }
function crshget() {
let h = trim(readfile(CRSHOW) ?? ''), k = '';
if (!match(h, /^([0-9a-f][0-9a-f])+$/)) return null;
for (let i = length(h) - 2; i >= 0; i -= 2) k += chr(hex(substr(h, i, 2)));
return knorm(k);
}
function crhalt(id) {
if (!alive(trim(readfile(CRD + '/' + id + '.lk/pid') ?? ''))) return false;
writefile(JOBS + '/crmig-' + id + '.stop', '' + time());
if (stat(CRSH)) detach('sh ' + shq(CRSH) + ' halt ' + id);
return true;
}
function crnohash(a) { return match('' + a?.svc, /^(mega|icloud)$/) != null || trim(readfile(CRD + '/' + a.id + '.hs') ?? '') == 'no'; }
function crcall(a, W, ver) {
let id = a.id, now = time();
if (!acctok(id)) return E('none');
let C0 = cget(), CA = filter(C0.accounts, (x) => auser(x) == 'admin');
if (!length(filter(C0.accounts, (x) => x.id == id))) return E('none');
if (!length(filter(CA, (x) => x.id == id))) return E('caps', { error: 'Solo nel cloud comune', error_en: 'Shared cloud only' });
begintmp(); mkdirp(CRD, 0700);
let ks = stat(CRKEY);
if (ks && (now - ks.mtime > 600 || ks.mtime > now + 60)) unlink(CRKEY);
let CR = crget(), st = crstof(CR.accts[id]);
let ad = CRD + '/' + id + '.adopt', av = trim(readfile(ad) ?? ''), as_ = stat(ad);
if (W.adm && match(av, /^(ok|keybad|bad|nokey|retry)$/)) {
unlink(ad);
if (av == 'keybad' || av == 'bad') {
let ev = getenv('WF_EVENTSH') ?? R + '/usr/share/wrtfreedom/event.sh', en = LG == 'en';
if (stat(ev)) detach('sh ' + shq(ev) + ' cron cloud_crypt_keybad cloud ' + shq('⚠️ Cloud ¦ ' + (en ? 'Wrong Key ¦ The private folders stay locked' : 'Chiave Sbagliata ¦ Le cartelle private restano chiuse')));
return E('keybad');
}
if (av != 'ok') return E('busy');
CR = crsave((X) => {
X.on = true; X.keyok = true; X.t_on = X.t_on || now; X.keyok_t = now;
let Y = type(X.accts[id]) == 'object' ? X.accts[id] : {};
if (Y.st != 'on') Y.st = 'mig';
X.accts[id] = Y;
});
if (CR) crkick();
return CR ? crout(id, W, CR) : E('busy');
}
let adr = av == 'run' && as_ != null && now - as_.mtime < 600, aq = 'r' + substr(hk('cradopt|' + id), 0, 14);
if (!length(filter([ 'on', 'keyok', 'rekey', 'key', 'stop', 'resume', 'show' ], (k) => exists(a, k)))) return { ...crout(id, W, CR), ...(adr && W.adm ? { pending: aq } : {}) };
if (!W.adm) return E('admin');
if (adr) return { pending: aq };
if (ver == null) return pkgE();
if (a.on === true) {
let SS = map(CA, (x) => crstof(CR.accts[x.id]));
if (length(filter(SS, (x) => x != 'off' && x != 'back'))) return E('cron');
let R0 = ready(id, ver);
if (R0.error) return R0;
if (length(filter(C0.accounts, (x) => auser(x) == 'admin' && crnohash(x)))) return E('nohash');
if (index(SS, 'back') >= 0) {
CR = crsave((X) => { X.on = true; for (let x in CA) { X.accts[x.id] = { ...(X.accts[x.id] ?? {}), st: 'mig' }; delete X.accts[x.id].pause; } });
if (!CR) return E('busy');
for (let x in CA) crhalt(x.id);
crset(filter(CA, (x) => crstof(CR.accts[x.id]) == 'mig' && !rcnames()[UCFG.crsec(x.id, 'admin')]));
crfresh(CA);
crkick();
return { st: 'mig' };
}
let k = UCFG.newkey();
if (!k || !wsec(CRKEY, k + '\n')) return E('busy');
CR = crsave((X) => { X.on = true; X.t_on = now; X.keyok = false; delete X.keytest_at; delete X.keyok_t; for (let x in CA) X.accts[x.id] = { st: 'setup', f: {} }; });
if (!CR) { unlink(CRKEY); return E('busy'); }
crshput(k);
crset(CA);
return { key: k, st: 'setup' };
}
if (a.show === true) {
if (st != 'setup' || CR.keyok) return E('cron');
let k = crshget();
return k ? { key: k, st: 'setup' } : E('nokey');
}
if (a.keyok === true) {
if (st != 'setup') return crout(id, W, CR);
if (stat(CRKEY)) return E('busy');
let NM = rcnames();
if (length(filter(CA, (x) => !NM[UCFG.crsec(x.id, 'admin')]))) return E('busy');
unlink(CRSHOW);
CR = crsave((X) => { X.keyok = true; X.keyok_t = now; for (let x in CA) if (X.accts[x.id]?.st == 'setup') X.accts[x.id].st = 'mig'; });
if (CR) { crfresh(CA); crkick(); }
return CR ? crout(id, W, CR) : E('busy');
}
if (a.rekey === true) {
if (st != 'setup' || CR.keyok) return E('cron');
let k = UCFG.newkey();
if (!k || !wsec(CRKEY, k + '\n')) return E('busy');
crshput(k);
crset(CA);
return { key: k, st: 'setup' };
}
if (a.on === false) {
unlink(CRSHOW);
for (let x in CA) unlink(CRD + '/' + x.id + '.left');
if (st == 'back') {
let busy = alive(trim(readfile(CRD + '/' + id + '.lk/pid') ?? ''));
if (crpaused(CR.accts[id]) || !busy) {
CR = crsave((X) => { if (type(X.accts[id]) == 'object') { delete X.accts[id].pause; delete X.accts[id].err; } });
if (!CR) return E('busy');
unlink(CRKEY);
unlink(JOBS + '/crmig-' + id + '.stop');
if (!busy) for (let x in [ 'todo', 'res', 'skip' ]) unlink(CRD + '/' + id + '.' + x);
crkick();
}
return { st: 'back' };
}
if (st == 'off') return { st: st };
unlink(CRKEY);
CR = crsave((X) => { X.on = false; for (let x in CA) { let Y = X.accts[x.id]; if (match(crstof(Y), /^(setup|mig|on)$/)) { Y.st = 'back'; delete Y.pause; } } });
if (CR) { for (let x in CA) crhalt(x.id); crfresh(CA); crkick(); }
return CR ? { st: 'back' } : E('busy');
}
if (exists(a, 'key')) {
let k = knorm(a.key);
if (k == null) return E('keybad');
if (!wsec(CRKEY, k + '\n')) return E('busy');
writefile(ad, 'run'); writefile(CRD + '/' + aq + '.ad', id);
detach('sh ' + shq(CSH) + ' cryptadopt ' + id);
return { pending: aq };
}
if (a.stop === true) {
if (st == 'mig' || st == 'back') {
CR = crsave((X) => { if (type(X.accts[id]) == 'object') X.accts[id].pause = true; });
if (!CR) return E('busy');
writefile(JOBS + '/crmig-' + id + '.stop', '' + now);
if (stat(CRSH)) detach('sh ' + shq(CRSH) + ' stop ' + id);
}
return crout(id, W, CR);
}
if (a.resume === true) {
if (crpaused(CR.accts[id])) {
CR = crsave((X) => { if (type(X.accts[id]) == 'object') delete X.accts[id].pause; });
if (!CR) return E('busy');
unlink(JOBS + '/crmig-' + id + '.stop');
crkick();
}
return crout(id, W, CR);
}
return E('act');
}
const KTMAX = 5, KTWIN = 600;
function ktid(id) { return 'r' + substr(hk('crkt|' + id), 0, 14); }
function crkt(a, W, ver) {
let id = a.id, now = time();
if (!acctok(id)) return E('none');
if (!W.adm) return E('admin');
let C0 = cget();
if (!length(filter(C0.accounts, (x) => x.id == id))) return E('none');
if (!length(filter(C0.accounts, (x) => x.id == id && auser(x) == 'admin'))) return E('caps', { error: 'Solo nel cloud comune', error_en: 'Shared cloud only' });
begintmp(); mkdirp(CRD, 0700);
let ko = CRD + '/' + id + '.kt', kq = CRD + '/' + ktid(id) + '.kq', ks = stat(ko), v = ks ? trim(readfile(ko) ?? '') : '';
let kn = exists(a, 'key') ? knorm(a.key) : null, kfp = exists(a, 'key') ? (kn ? hk('crktf|' + kn) : '-') : null;
let same = kfp == null || kfp == (split(trim(readfile(kq) ?? ''), '\t')[1] ?? '');
if (same && v == 'run' && now - ks.mtime < 180 && ks.mtime <= now + 60) return { pending: ktid(id) };
if (same && match(v, /^(ok|bad|retry)$/) && now - ks.mtime < 120 && ks.mtime <= now + 60) {
unlink(ko); unlink(kq);
if (v == 'retry') return E('busy');
let CR = crget();
return { ok: v == 'ok', keytest_at: crnum(CR.keytest_at) };
}
if (ks) unlink(ko);
unlink(CRD + '/' + id + '.ktk');
if (!exists(a, 'key')) { unlink(kq); return E('pending', { gone: true }); }
if (ver == null) return pkgE();
let CR = crget();
if (!CR.on || !CR.keyok || !match(crstof(CR.accts[id]), /^(mig|on|back)$/)) return E('croff');
if (!rcnames()[UCFG.crsec(id, 'admin')]) return E('croff');
let tf = CRD + '/kt.n', T = filter(map(split(readfile(tf) ?? '', '\n'), (x) => +x), (x) => x > 0 && now - x < KTWIN && x <= now + 60);
if (length(T) >= KTMAX) return E('wait');
push(T, now);
writefile(tf, join('\n', T) + '\n');
let k = kn;
if (k == null) { unlink(kq); return { ok: false, keytest_at: crnum(CR.keytest_at) }; }
if (!wsec(CRD + '/' + id + '.ktk', k)) return E('busy');
writefile(ko, 'run'); writefile(kq, id + '\t' + kfp);
detach('ucode ' + shq(SELF) + ' keytest ' + id);
return { pending: ktid(id) };
}
function crktrun(id) {
CLI = true; begintmp();
let ko = CRD + '/' + id + '.kt', kf = CRD + '/' + id + '.ktk', k = knorm(trim(readfile(kf) ?? ''));
unlink(kf);
let kq = CRD + '/' + ktid(id) + '.kq', fp0 = k ? hk('crktf|' + k) : '-';
let fin = (v) => { if ((split(trim(readfile(kq) ?? ''), '\t')[1] ?? '') == fp0) writefile(ko, v); return v == 'retry' ? 2 : 0; };
if (k == null) return fin('bad');
let S = rcsec(UCFG.crsec(id, 'admin'));
if (S?.type != 'crypt' || !length(S.password ?? '')) return fin('retry');
let d = TMP + '/.kt-' + PID, f1 = d + '.1', f2 = d + '.2', o1 = d + '.o1', o2 = d + '.o2', cf = d + '.conf', ld = d + '.d';
let clean = () => { for (let f in [ f1, f2, o1, o2, cf ]) unlink(f); rmdir(ld); };
if (!wsec(f1, k) || !wsec(f2, 'wfh' + k)) { clean(); return fin('retry'); }
k = null;
sh('umask 077; rclone obscure - < ' + shq(f1) + ' > ' + shq(o1) + ' 2>/dev/null; sha256sum < ' + shq(f2) + ' | cut -c1-64 | rclone obscure - > ' + shq(o2) + ' 2>/dev/null');
unlink(f1); unlink(f2);
let p1 = trim(readfile(o1) ?? ''), p2 = trim(readfile(o2) ?? '');
unlink(o1); unlink(o2);
if (!length(p1) || (length(S.password2 ?? '') && !length(p2))) { clean(); return fin('retry'); }
mkdirp(ld, 0700);
let sec = (n, pw, pw2) => '[' + n + ']\ntype = crypt\nremote = ' + ld + '\nfilename_encryption = ' + (S.filename_encryption ?? 'standard') +
'\ndirectory_name_encryption = ' + (S.directory_name_encryption ?? 'true') + (length(S.filename_encoding ?? '') ? '\nfilename_encoding = ' + S.filename_encoding : '') +
'\npassword = ' + pw + (length(pw2 ?? '') ? '\npassword2 = ' + pw2 : '') + '\n';
if (!wsec(cf, sec('wfkth', S.password, S.password2) + sec('wfktc', p1, length(S.password2 ?? '') ? p2 : null))) { clean(); return fin('retry'); }
p1 = null; p2 = null;
let rc = (c) => sh('T=; command -v timeout >/dev/null 2>&1 && T="timeout 60"; RCLONE_CONFIG=' + shq(cf) + ' $T rclone ' + c + ' </dev/null 2>/dev/null');
let m = match(rc('cryptdecode --reverse wfkth: wfprobe'), /wfprobe \t ([0-9A-Za-z_=-]+)/);
if (!m) { clean(); return fin('retry'); }
let o = rc('cryptdecode wfktc: ' + shq(m[1]));
clean();
if (!length(o)) return fin('retry');
let ok = length(filter(split(o, '\n'), (l) => trim(l) == m[1] + ' \t wfprobe')) > 0;
if (ok) crsave((X) => { X.keytest_at = time(); });
return fin(ok ? 'ok' : 'bad');
}
function cruser(own) {
if (type(own) != 'string' || !match(own, /^[A-Za-z0-9._-]{1,64}$/) || own == 'admin' || own == 'shared') return E('path');
let CR = crget(), NM = rcnames(), L = [];
if (!CR.keyok || !stat(CSH)) return { n: 0 };
for (let x in cget().accounts) {
if (auser(x) != 'admin' || !match(crstof(CR.accts[x.id]), /^(mig|on)$/)) continue;
let s = UCFG.crsec(x.id, own);
if (s != null && !NM[s]) push(L, x.id);
}
if (!length(L)) return { n: 0 };
begintmp();
let q = shq(CRKEY), c = 'i=0; while [ -e ' + q + ' ] && [ $i -lt 132 ]; do sleep 5; i=$((i + 1)); done; [ -e ' + q + ' ] && exit 0';
let MSH = getenv('WF_CLOUDMNT') ?? '/usr/share/wrtfreedom/cloudmnt.sh';
for (let id in L) c += (stat(CXSH) ? '; sh ' + shq(CXSH) + ' cbroot ' + id + ' ' + shq(own) : '') + '; sh ' + shq(CSH) + ' cryptset ' + id +
(stat(CXSH) ? '; WF_CBWAIT=1 sh ' + shq(CXSH) + ' cbase ' + id : '') + (stat(MSH) ? '; sh ' + shq(MSH) + ' check ' + id : '');
detach(c);
return { n: length(L) };
}
function lenc(r, acct) {
if (type(r?.items) != 'array' || !length(r.items)) return r;
let K = cctx();
if (!K.com[acct] || !match(crstof(K.CR.accts[acct]), /^(mig|on|back)$/)) return r;
let P = '' + (r.path ?? ''), one = length(split(P, '/')) >= 3 ? cmap(acct, P, K) : null;
for (let x in r.items) {
if (type(x) != 'object' || type(x.name) != 'string') continue;
let m = one ?? cmap(acct, (length(P) ? P + '/' : '') + x.name, K);
if (m?.st == 'enc' || m?.st == 'mig') x.enc = true;
}
return r;
}
const FAVMAX = 12;
function favcall(a, W) {
let C = cget(), ok = {};
for (let x in C.accounts) { let u = auser(x); if (u == 'admin' ? true : (!W.adm && u == W.own)) ok[x.id] = true; }
let mine = () => filter(type(C.fav?.[W.own]) == 'array' ? C.fav[W.own] : [], (x) => type(x) == 'object' && ok[x.id] && type(x.path) == 'string');
let d = '' + (a.do ?? 'list');
if (d == 'list') return { items: mine() };
if (d != 'add' && d != 'del') return E('act');
if (!acctok(a.id) || !length(filter(C.accounts, (x) => x.id == a.id))) return E('none');
if (!ok[a.id]) return E('private');
let p = rpath(a.path);
if (p == null || p == '/') return E('path');
if (!W.adm && !pin(p, W)) {
let pers = false;
for (let x in C.accounts) if (x.id == a.id && auser(x) == W.own) pers = true;
if (!pers) return E('private');
}
let nm = length(a.name ?? '') ? '' + a.name : base(p);
if (!nameok(nm)) return E('path');
let C2 = csave((X) => {
if (type(X.fav) != 'object') X.fav = {};
let L = filter(type(X.fav[W.own]) == 'array' ? X.fav[W.own] : [], (x) => type(x) == 'object' && !(x.id == a.id && x.path == p));
if (d == 'add') L = [ { id: a.id, path: p, name: nm, t: time() }, ...L ];
X.fav[W.own] = slice(L, 0, FAVMAX);
});
if (!C2) return E('busy');
C = C2;
return { items: mine() };
}
function favfix(id, mv, del) {
let hit = (F) => { for (let o, L in (type(F) == 'object' ? F : {})) for (let x in (type(L) == 'array' ? L : [])) {
if (type(x) != 'object' || x.id != id || type(x.path) != 'string') continue;
for (let m in mv ?? []) if (under(x.path, m[0])) return true;
for (let d in del ?? []) if (under(x.path, d)) return true;
} return false; };
if (!hit(cget().fav)) return;
csave((X) => {
for (let o, L in (type(X.fav) == 'object' ? X.fav : {})) {
if (type(L) != 'array') continue;
let K = [];
for (let x in L) {
if (type(x) == 'object' && x.id == id && type(x.path) == 'string') {
let gone = false;
for (let d in del ?? []) if (under(x.path, d)) gone = true;
if (gone) continue;
for (let m in mv ?? []) if (under(x.path, m[0])) {
let np = m[1] + substr(x.path, length(m[0]));
if (x.path == m[0] && x.name == base(m[0])) x.name = base(m[1]);
x.path = np; break;
}
}
push(K, x);
}
X.fav[o] = K;
}
});
}
function cmx(id, p, K) { let m = cmap(id, p, K); return m != null && m.st != 'clear' && m.st != 'mix' ? m : null; }
const CIX = TMP + '/idx', CSP = TMP + '/space', CIXAGE = 172800, CIXGAP = 600;
const CIXT = { photo: 'img', video: 'vid', music: 'mus', doc: 'doc' };
const SLOWMV = { s3: true, b2: true };
const CIXW = { ram: [ 'Memoria del router troppo piccola: collega un disco per la Ricerca Veloce', 'Router memory too small: connect a disk for Fast Search' ],
line: [ 'Linea che non lo permette stanotte: riprova domani', 'Line did not allow it tonight: tomorrow again' ],
fail: [ 'Indice non riuscito stanotte: riprova domani', 'Index failed tonight: tomorrow again' ] };
function cixsee(A, W) {
if (A.user != 'admin') return !W.adm && A.user == W.own ? (p) => 'ok' : null;
if (!W.adm) return (p) => pin(p, W) ? 'ok' : null;
let N = rjs(NASJ) ?? {};
return (p) => { let v = type(UCFG.upriv) == 'function' ? UCFG.upriv(W, p, N) : null; return v == null || v == 'up' ? 'ok' : (v == 'lock' ? 'lock' : null); };
}
function cixget(id) {
let m = rjs(CIX + '/' + id + '.json');
if (type(m) != 'object' || !isnum(m.at) || time() - m.at > CIXAGE) return null;
if (m.off) return m;
return type(m.f) == 'string' && stat(m.f) ? m : null;
}
function cixfs(m) { let o = shq(m.f); if (type(m.fe) == 'string' && stat(m.fe)) o += ' ' + shq(m.fe); return o; }
function cixgrep(m, q, n) { return slice(filter(split(sh('grep -h -i -F -m ' + n + ' -- ' + shq(q) + ' ' + cixfs(m) + ' 2>/dev/null'), '\n'), (l) => length(l)), 0, n); }
function cixkind(m, k, n) {
let X = filter(tipi()[k] ?? [], (e) => type(e) == 'string' && match(e, /^[a-z0-9]+$/) && length(e) <= 8);
if (!length(X)) return [];
return filter(split(sh("awk -F '\\t' -v n=" + n + " 'tolower($1) ~ /\\.(" + join('|', X) + ")$/ { print; if (++c >= n) exit }' " + cixfs(m) + ' 2>/dev/null'), '\n'), (l) => length(l));
}
function cixls(A, W, p, q, mx) {
let m = cixget(A.id), see = cixsee(A, W);
if (!m || m.off || !see) return null;
let P = substr(p, 1), ql = lc(q), it = [], more = false, sh0 = {};
for (let l in lget()) if (l.id == A.id) sh0[l.path] = true;
let k = mx > 20000 ? 20000 : mx + 1, L = cixgrep(m, q, k);
if (length(L) >= k) more = true;
for (let l in L) {
let c = split(l, '\t'), x = c[0], d = substr(x, -1) == '/';
if (d) x = substr(x, 0, length(x) - 1);
if (length(P) && substr(x, 0, length(P) + 1) != P + '/') continue;
let rel = length(P) ? substr(x, length(P) + 1) : x;
if (index(lc(rel), ql) < 0 || see('/' + x) != 'ok') continue;
if (length(it) >= mx) { more = true; break; }
let o = { name: rel, dir: d, size: d ? 0 : int(c[1] ?? 0), mtime: c[2] ?? '', shared: !!sh0['/' + x] };
if (c[3] == 'e') o.enc = true;
push(it, o);
}
return { items: it, path: P, more: more || m.partial === true, idx: m.at };
}
function cixrun(A, W) {
if (A.user == 'admin' ? !W.adm : A.user != W.own || W.adm) return E('admin');
if (alive(trim(readfile(CIX + '/run.lk/pid') ?? ''))) return { run: true, busy: true };
let m = rjs(CIX + '/' + A.id + '.json');
if (isnum(m?.at) && time() - m.at < CIXGAP && time() >= m.at) return { run: false, at: m.at };
detach('sh ' + shq(CXSH) + ' cidx ' + A.id);
return { run: true };
}
function cixwhy(m) { let w = CIXW[m?.off]; return w ? { why: m.off, why_t: w[LG == 'en' ? 1 : 0] } : {}; }
function cixsearch(a, W) {
let ver = rcver();
if (a.do == 'run') { let A = ready(a.id, ver); return A.error ? A : cixrun(A, W); }
let q = trim('' + (a.q ?? '')), ql = lc(q), tk = CIXT[a.kind] ?? null, lim = int(+(a.max ?? 0));
if (!length(q) && !tk) return E('path');
if (length(q) > 100 || match(q, /[[:cntrl:]]/)) return E('path');
if (lim < 1 || lim > 500) lim = 100;
let It = [], at = 0, part = false, none = [], why = null;
for (let A in accts(null, null, ver)) {
if (length(a.id ?? '') && A.id != a.id) continue;
let see = cixsee(A, W);
if (!see) continue;
let m = cixget(A.id);
if (!m || m.off) { push(none, A.id); if (m?.off) why = why ?? m; continue; }
let L = length(q) ? cixgrep(m, q, 20000) : cixkind(m, tk, 20000);
if (length(L) >= 20000) part = true;
for (let l in L) {
let c = split(l, '\t'), x = c[0], d = substr(x, -1) == '/';
if (d) x = substr(x, 0, length(x) - 1);
let n = replace(x, /^.*\//, ''), e = match(lc(n), /\.([a-z0-9]{1,8})$/);
if (length(ql) && index(lc(n), ql) < 0) continue;
if (tk && (d || !e || !extin(tk, e[1]))) continue;
if (see('/' + x) != 'ok') continue;
let o = { id: A.id, acct: A.name, path: '/' + x, name: n, dir: d, size: d ? 0 : int(c[1] ?? 0), mtime: c[2] ?? '' };
if (c[3] == 'e') o.enc = true;
push(It, o);
if (length(It) > 5000) { part = true; break; }
}
if (m.partial === true) part = true;
if (!at || m.at < at) at = m.at;
}
if (length(It) > lim) part = true;
return { items: slice(sort(It, (x, y) => x.mtime < y.mtime ? 1 : (x.mtime > y.mtime ? -1 : 0)), 0, lim), at: at, partial: part, none: none, ...cixwhy(why) };
}
function cixspace(a, W) {
let A = ready(a.id, rcver());
if (A.error) return A;
if (a.do == 'run') return cixrun(A, W);
let see = cixsee(A, W);
if (!see) return A.user != 'admin' ? E('private') : E('none');
let p = length(a.path ?? '') ? rpath(a.path) : (A.user == 'admin' && !W.adm ? cdir(W.own, 'root') : '/');
if (p == null) return E('path');
if (A.user == 'admin' && !W.adm && !pin(p, W)) return E('private');
if (p != '/' && see(p) == null) return E('private');
let S = rjs(CSP + '/' + A.id + '.json'), m = rjs(CIX + '/' + A.id + '.json');
if (type(S) != 'object' || !isnum(S.at)) return { none: true, ...cixwhy(m) };
let D = type(S.dirs) == 'object' ? S.dirs : {}, pre = p == '/' ? '/' : p + '/', ds = [];
for (let k, v in D) {
if (substr(k, 0, length(pre)) != pre || index(substr(k, length(pre)), '/') >= 0) continue;
let s = see(k);
if (s == null) continue;
let o = { name: substr(k, length(pre)), path: k, size: v[0], files: v[1] };
if (s == 'lock') o.lock = true;
push(ds, o);
}
let ok = (x) => type(x?.path) == 'string' && (p == '/' || under(x.path, p)) && see(x.path) == 'ok';
let G = [];
for (let g in (S.dup?.list ?? [])) {
if (!ok(g.keep)) continue;
let cp = filter(g.copies ?? [], ok);
if (length(cp)) push(G, { ...g, copies: cp });
}
let dn = 0, db = 0;
for (let g in G) { dn += length(g.copies); db += length(g.copies) * g.keep.size; }
let tot = p == '/' ? [ S.bytes, S.files ] : D[p];
return { at: S.at, path: p, bytes: tot?.[0] ?? null, files: tot?.[1] ?? null, dirs: sort(ds, (x, y) => y.size - x.size),
big: filter(S.big ?? [], ok), old: filter(S.old ?? [], ok),
dup: { n: dn, groups: length(G), bytes: db, sure: S.dup?.sure === true, list: G }, partial: S.partial === true };
}
function cloudcall(a, W) {
let act = '' + (a.act ?? 'get'), now = time();
if (act == 'get') return getout(W);
if (act == 'search') return cixsearch(a, W);
if (act == 'space') return cixspace(a, W);
if (!match(act,/^(auth|devcode|devpoll|rename|del|about|ls|mkdir|move|rm|xfer|put|jobs|job|link|links|upreq|line|pause|router|find|rtget|res|dl|share|thumbs|revs|revert|trash|restore|stream|photo|crypt|keytest|empty|fav|size)$/)) return E('act');
if (wtpath(a)) return E('path');
let pown = act == 'pause' && (a.do == 'pause_own' || a.do == 'resume_own');
let pshr = act == 'share' && !W.adm && length(filter(cget().accounts, (x) => x.id == a.id && auser(x) == W.own)) > 0;
if (!W.adm && ADMONLY[act] && !pown && !pshr) return E('admin');
if (pown) {
if (W.adm) return E('act');
let on = a.do == 'pause_own';
let C = csave((X) => { if (type(X.ppause) != 'object') X.ppause = {}; if (on) X.ppause[W.own] = true; else delete X.ppause[W.own]; });
if (!C) return E('busy');
kicktick();
return { pause_own: on };
}
if (act == 'fav') return favcall(a, W);
if (act == 'share' && padm(W)) for (let x in cget().accounts) if (x.id == a.id && auser(x) != 'admin') return E('private');
if (act == 'share' && !length(filter([ 'on', 'path', 'name', 'disk', 'cache_gb', 'cache', 'rw', 'speed' ], (k) => exists(a, k)))) return share(a, rcver(), W);
if (!READ[act] && !(act == 'links' && a.do != 'del') && migrating()) return E('busy');
let ver = rcver();
if (NEEDRC[act] && ver == null) return pkgE();
if (act == 'auth') return auth(a, cget(), ver, W);
if (act == 'devcode') return devcode(a, W, ver);
if (act == 'devpoll') return devpoll(a, W);
if (act == 'dl') return dl(a, now, W);
if (act == 'share') return share(a, ver, W);
if (act == 'crypt') return crcall(a, W, ver);
if (act == 'keytest') return crkt(a, W, ver);
if (act == 'res') {
if (type(a.req) != 'string' || !match(a.req, /^r[0-9a-f]{14}$/)) return E('pending', { gone: true });
let ka = split(trim(readfile(CRD + '/' + a.req + '.kq') ?? ''), '\t')[0];
if (acctok(ka)) return crkt({ id: ka }, W, ver);
let ca = trim(readfile(CRD + '/' + a.req + '.ad') ?? '');
if (acctok(ca)) {
let c = crcall({ id: ca }, W, ver);
if (c.pending == null) unlink(CRD + '/' + a.req + '.ad');
return c.pending != null ? { pending: a.req } : c;
}
let o = resof(a.req);
if (o) return o;
if (stat(REQ + '/' + a.req + '.json')) { kick(); return { pending: a.req }; }
return E('pending', { gone: true });
}
if (act == 'rename' || act == 'del') {
let ow = null;
for (let x in cget().accounts) if (x.id == a.id) ow = auser(x);
if (ow != null && !W.adm && ow != W.own) return E('none');
if (ow != null && W.adm && ow != 'admin' && act == 'rename') return E('private');
if (ow != null && padm(W) && ow != 'admin') return E('private');
}
if (act == 'rename') {
if (!acctok(a.id)) return E('none');
let nm = trim('' + (a.name ?? ''));
if (!length(nm) || length(nm) > 40 || match(nm, /[[:cntrl:]]/)) return E('fields');
let hit = false;
let C = csave((X) => { for (let x in X.accounts) if (x.id == a.id) { x.name = nm; hit = true; } });
if (!C) return E('busy');
if (!hit) return E('none');
return acct(a.id);
}
if (act == 'del') {
if (!acctok(a.id)) return E('none');
let C0 = cget(), A0 = null;
for (let x in C0.accounts) if (x.id == a.id) A0 = x;
if (!A0) return E('none');
let SH0 = C0.share?.[a.id], nun = dirtyin(acdirs(type(SH0) == 'object' ? SH0 : {}, a.id));
let kp = W.keep === true;
if (nun > 0 && a.force !== true && !kp) return E('unsent', { unsent: nun });
let pa = padm(W), pv = (o) => !pa || o == 'admin';
let U = usesof(C0)[a.id] ?? [], stopped = map(filter(U, (u) => u.kind != 'router' && pv(u.own)), (u) => u.name);
let SEC = rcsec(rcname(a.id));
let C = csave((X) => {
X.accounts = filter(X.accounts, (x) => x.id != a.id);
if (type(X.sown) == 'object') delete X.sown[a.id];
if (X.router.acct == a.id) { X.router.on = false; X.router.acct = ''; }
if (type(X.share) == 'object' && X.share[a.id]) delete X.share[a.id];
});
if (!C) return E('busy');
let W = {};
W[rcname(a.id)] = null;
rcset(W);
if (stat(R + CMSH)) detach('sh ' + shq(R + CMSH) + ' gone ' + a.id + ' ' + (nun > 0 && !kp ? 'lose' : 'keep') + ' ' +
shq(type(SH0) == 'object' && length('' + (SH0.name ?? '')) ? SH0.name : A0.name ?? a.id));
unlink(TMP + '/.new-' + a.id);
unlink(ETC + '/cloud-kh-' + a.id);
let J = jlist(), any = false;
for (let j in J) if (j.acct == a.id && (j.state == 'run' || j.state == 'wait' || j.state == 'pause')) {
writefile(JOBS + '/' + j.job + '.stop', '' + now); unlink(QD + '/' + j.job + '.json'); any = true;
if (pv(j.own) && (!length(j.name ?? '') || index(stopped, j.name) < 0)) push(stopped, j.name ?? j.job);
}
let gone = [];
if (lkget(LKLK)) {
let L = lget(), K = filter(L, (x) => x?.id != a.id);
gone = filter(L, (x) => type(x) == 'object' && x.id == a.id);
if (length(K) != length(L) && !wsec(LJ, sprintf('%J', { items: K }))) gone = [];
lkput(LKLK);
}
for (let x in gone) {
let rq = 'r' + substr(hk('unlink|' + (x.req ?? '') + '|' + now), 0, 14);
let o = { act: 'unlink', link: x, req: rq, t: now, lang: LG };
if (SEC) { o.rc = {}; o.rc[rcname(a.id)] = SEC; }
wjs600(REQ + '/' + rq + '.json', o);
}
if (length(gone)) kick();
if (any) kicktick();
let left = length(C.accounts), X = rjs(NXJ), r = { stopped: stopped, left: left };
let mine = C.rclone_mine === true || X?.rclone_mine === true, nojobs = !length(X?.cloud ?? []) && !length(filter(jlist(), (j) => j.state == 'run' || j.state == 'wait'));
if (!left && nojobs && mine && (type(a.drop) != 'array' || !length(a.drop) || index(a.drop, 'rclone') >= 0)) r.drop = [ 'rclone' ];
return r;
}
if (act == 'jobs' || act == 'job') jsown();
if (act == 'jobs') {
let J = filter(jlist(), (j) => W.adm || j.own == W.own), act_ = filter(J, (j) => j.state == 'run' || j.state == 'wait' || j.state == 'pause'),
done = filter(J, (j) => !(j.state == 'run' || j.state == 'wait' || j.state == 'pause') && now - j.t < 7 * DAY);
act_ = sort(act_, (x, y) => (x.state == 'run' ? 0 : 1) - (y.state == 'run' ? 0 : 1) || x.t - y.t);
done = slice(sort(done, (x, y) => y.t - x.t), 0, 50);
let I = [ ...act_, ...done ];
if (!padm(W)) return { items: I };
let jst = (j) => j.state == 'err' ? 'bad' : j.state == 'stop' ? 'warn' : j.state == 'ok' ? 'ok' : 'run';
return { items: filter(I, (j) => j.own == 'admin'), people: ppl(I, jst, (p, j) => { p.bytes = (p.bytes ?? 0) + (isnum(j.size) && j.size > 0 ? j.size : isnum(j.bytes) ? j.bytes : 0); }) };
}
if (act == 'job') {
if (!jobok(a.job) || !stat(JOBS + '/' + a.job + '.json')) return E('job');
let j = null;
for (let x in jlist()) if (x.job == a.job) j = x;
if (!j || (!W.adm && j.own != W.own)) return E('job');
if (padm(W) && j.own != 'admin') return E('private');
let JF = JOBS + '/' + a.job + '.json', o = rjs(JF) ?? {};
if (a.do == 'stop') {
writefile(JOBS + '/' + a.job + '.stop', '' + now);
if (j.state == 'wait' || j.state == 'pause') { unlink(QD + '/' + a.job + '.json'); o.state = 'stop'; o.t = now; wjs600(JF, o); }
kicktick();
return { ok: true };
}
if (a.do == 'retry') {
if (j.state != 'err' && j.state != 'stop') return E('busy');
let Q = rjs(JOBS + '/' + a.job + '.q.json');
if (type(Q) != 'object') return E('job');
unlink(JOBS + '/' + a.job + '.stop');
if (!wjs600(QD + '/' + a.job + '.json', { ...Q, t: now })) return E('busy');
o.state = 'wait'; o.wc = 'queue'; o.why = 'In coda'; o.why_en = 'Queued'; o.err = ''; o.err_en = ''; o.pct = 0; o.t = now;
wjs600(JF, o);
kicktick();
return { ok: true };
}
if (a.do == 'del') {
if (j.state == 'run') return E('busy');
for (let x in [ JF, JOBS + '/' + a.job + '.q.json', JOBS + '/' + a.job + '.stop', QD + '/' + a.job + '.json', PH + '/' + a.job + '.part', PH + '/' + a.job + '.ok' ]) unlink(x);
return { ok: true };
}
return E('act');
}
if (act == 'line') {
let I = a.line;
if (type(I) != 'object') return E('line');
let N = {}, bad = false;
if (exists(I, 'sim')) {
let s = I.sim;
if (type(s) != 'object') return E('line');
N.sim = {};
if (exists(s, 'gb')) { if (!isnum(s.gb) || !(s.gb == 0 || (s.gb >= 0.5 && s.gb <= 500))) bad = true; else N.sim.gb = s.gb; }
if (exists(s, 'all')) { if (type(s.all) != 'bool') bad = true; else N.sim.all = s.all; }
for (let k in [ 'from', 'to' ]) if (exists(s, k)) { if (!hhmm(s[k])) bad = true; else N.sim[k] = s[k]; }
}
for (let k in [ 'bw_up', 'bw_down' ]) if (exists(I, k)) { if (!intin(I[k], 0, 1000000)) bad = true; else N[k] = I[k]; }
if (exists(I, 'parallel')) { if (!intin(I.parallel, 0, 8)) bad = true; else N.parallel = I.parallel; }
if (exists(I, 'bw_at')) {
if (type(I.bw_at) != 'array' || length(I.bw_at) > 8) bad = true;
else {
N.bw_at = [];
for (let x in I.bw_at) {
if (type(x) != 'object' || !hhmm(x.from) || !hhmm(x.to) || !intin(x.up ?? 0, 0, 1000000) || !intin(x.down ?? 0, 0, 1000000)) { bad = true; break; }
push(N.bw_at, { from: x.from, to: x.to, up: x.up ?? 0, down: x.down ?? 0 });
}
}
}
if (bad) return E('line');
let C = csave((X) => {
if (N.sim) X.line.sim = { ...X.line.sim, ...N.sim };
for (let k in [ 'bw_up', 'bw_down', 'parallel', 'bw_at' ]) if (exists(N, k)) X.line[k] = N[k];
});
if (!C) return E('busy');
kicktick();
return { line: C.line };
}
if (act == 'pause') {
let P = null;
if (a.do == 'resume') P = { on: false, until: 0 };
else {
let u = a.until ?? 0;
if (!isnum(u) || u < 0) return E('act');
if (u > 0 && u <= 720) u = now + int(u * 3600);
else if (u > 720 && (u <= now || u > now + 31 * DAY)) return E('act');
P = { on: true, until: int(u) };
}
P.by = match('' + (a.kind ?? ''), /^(user|sched|ia|bot)$/) ? a.kind : 'user';
let C = csave((X) => { X.pause = P; });
if (!C) return E('busy');
kicktick();
return { pause: pout(C, now), sum: sum() };
}
if (act == 'router') {
let C0 = cget(), has_ = (id) => length(filter(C0.accounts, (x) => x.id == id && auser(x) == 'admin')) > 0;
if (a.do == 'now') {
let id = C0.router.acct;
if (!id || !has_(id)) return E('none');
if (!(stat(BAKPW)?.size > 0)) return E('bakpass');
if (ver == null) return pkgE();
let A = ready(id, ver);
if (A.error) return A;
return qput({ kind: 'router', id: id }, 'Copia Del Router', 'Router');
}
let I = a.router;
if (type(I) != 'object') return E('act');
let N = {};
if (exists(I, 'on')) { if (type(I.on) != 'bool') return E('act'); N.on = I.on; }
if (exists(I, 'acct')) { if (I.acct !== '' && !has_(I.acct)) return E('none'); N.acct = I.acct; }
if (exists(I, 'every')) { if (!match('' + I.every, /^(week|day)$/)) return E('act'); N.every = I.every; }
if (exists(I, 'day')) { if (!intin(I.day, 0, 6)) return E('act'); N.day = I.day; }
if (exists(I, 'keep')) { if (!intin(I.keep, 1, 52)) return E('act'); N.keep = I.keep; }
if (exists(I, 'before_fw')) { if (type(I.before_fw) != 'bool') return E('act'); N.before_fw = I.before_fw; }
let T = { ...C0.router, ...N };
if (T.on && !T.acct) return E('none');
if (T.on && !(stat(BAKPW)?.size > 0)) return E('bakpass');
let C = csave((X) => { for (let k, v in N) X.router[k] = v; });
if (!C) return E('busy');
return { router: rout(C) };
}
if (act == 'links') {
if (padm(W) && length(a.req ?? '')) for (let x in lget()) if (x?.req == a.req && ownof(x) != 'admin') return E('private');
if (a.do == 'del') {
if (type(a.req) != 'string' || !length(a.req)) return E('link');
if (!lkget(LKLK)) return E('busy');
let L = lget(), x = null, K = [];
for (let i in L) { if (i?.req == a.req && (W.adm || ownof(i) == W.own)) x = i; else push(K, i); }
let ok = !x || wsec(LJ, sprintf('%J', { items: K }));
lkput(LKLK);
if (!x) return E('link');
if (!ok) return E('busy');
let rq = 'r' + substr(hk('unlink|' + a.req + '|' + now), 0, 14);
wjs600(REQ + '/' + rq + '.json', { act: 'unlink', link: x, req: rq, t: now, lang: LG });
kick();
return lres(now, W);
}
if (a.do == 'del_own') {
if (!W.adm) return E('admin');
if (a.kind != 'pub' || type(a.own) != 'string' || !match(a.own, /^[A-Za-z0-9._-]{1,64}$/) || a.own == 'admin') return E('act');
if (!lkget(LKLK)) return E('busy');
let L = lget(), X = [], K = [];
for (let i in L) { if (type(i) == 'object' && i.kind == 'pub' && ownof(i) == a.own) push(X, i); else push(K, i); }
let ok = !length(X) || wsec(LJ, sprintf('%J', { items: K }));
lkput(LKLK);
if (!ok) return E('busy');
for (let x in X) {
let rq = 'r' + substr(hk('unlink|' + (x.req ?? '') + '|' + now), 0, 14);
wjs600(REQ + '/' + rq + '.json', { act: 'unlink', link: x, req: rq, t: now, lang: LG });
}
if (length(X)) kick();
return { ...lres(now, W), n: length(X) };
}
if (length(a.req ?? '')) {
for (let x in lget()) if (x?.req == a.req && type(x.url) == 'string' && (W.adm || ownof(x) == W.own))
return { req: a.req, url: x.url, ...(x.kind == 'pub' && type(x.upurl) == 'string' && length(x.upurl) ? { upurl: x.upurl } : {}) };
return E('link');
}
return lres(now, W);
}
if (act == 'put') {
if (length(a.job ?? '') && !jobok(a.job)) return E('job');
let job = length(a.job ?? '') ? a.job : 'j' + rid(), pf = PH + '/' + job + '.part', cur = stat(pf)?.size ?? 0, off = a.off ?? 0;
if (!intin(off, 0, 4294967295) || type(a.data) != 'string') return E('act');
if (off != cur) return { ok: false, off: cur, job: job };
if (length(a.data) > int(CHUNK * 4 / 3) + 4) return E('big');
let d = b64d(a.data), C = cget(), mb = C.lim.phone_mb > 0 ? C.lim.phone_mb : (tier() == 'A' ? 32 : 256), n = cur + length(d);
if (length(d) > CHUNK || n > mb * 1048576) { unlink(pf); return E('big'); }
let V = type(FS.statvfs) == 'function' ? FS.statvfs('/tmp') : null;
if (V && isnum(V.bavail) && isnum(V.frsize) && V.bavail * V.frsize < 2 * length(d) + cur) { unlink(pf); return E('big'); }
let t = tier(), tot = length(d), MJ = memj(), cap = (PHTOT[t] > mb ? PHTOT[t] : mb) * 1048576, low = PHMEM[t] * 1048576;
if (MJ) { let rb = MJ.ris * 1024; low = max(low, min(rb, cap)); if (rb < cap) cap = rb > mb * 1048576 ? rb : mb * 1048576; }
for (let f in (lsdir(PH) ?? [])) if (match(f, /\.part$/)) tot += stat(PH + '/' + f)?.size ?? 0;
let mm = match(readfile(R + '/proc/meminfo') ?? '', /MemAvailable:[ \t]*([0-9]+)/);
if (tot > cap || (mm && +mm[1] * 1024 - length(d) < low)) return E('mem');
let f = cur ? open(pf, 'r+') : mk600(pf);
if (!f) return E('busy');
if (cur) f.seek(cur, 0);
f.write(d); f.close();
n = stat(pf)?.size ?? n;
if (a.last === true) writefile(PH + '/' + job + '.ok', '' + n);
return { ok: true, off: n, job: job };
}
let A = ready(a.id, ver);
if (A.error) return A;
let mine = A.user != 'admin', PR = !W.adm && !mine;
if (mine && W.adm && (act != 'about' || padm(W))) return E('private', { error: "Cloud personale di un'altra persona", error_en: "Another person's personal cloud" });
if (mine && !W.adm && A.user != W.own) return E('none');
let s = svcof(A.svc), C = cget();
let WT = wtron(s), CW = {};
if (WT) { for (let k in WTCAPS) CW[k] = true; s = { ...s, caps: { ...s.caps, ...CW } }; }
let NE = () => E('private', { error: "File di un'altra persona", error_en: "Another person's file" });
let AP = W.adm && !mine, NJ0 = AP ? (rjs(NASJ) ?? {}) : null;
let AV = (p, whole) => {
let v = AP && type(UCFG.upriv) == 'function' && p != null ? UCFG.upriv(W, p, NJ0) : null;
return v != null && (whole === true || v != 'up');
};
let APE = () => E('private', { error: 'Cartella di una persona', error_en: "A person's folder" });
let CK = null, CMG = (L) => {
if (!match(crstof(crget().accts[A.id]), /^(mig|back)$/)) return false;
CK = CK ?? cctx();
for (let p in L) if (p != null && cmigp(A.id, p, CK)) return true;
return false;
};
let LNG = (L) => {
if (mine || !match(crstof(crget().accts[A.id]), /^(mig|on|back)$/)) return false;
CK = CK ?? cctx();
for (let p in L) {
let m = p != null ? cmap(A.id, p, CK) : null;
if (m == null || (m.st != 'enc' && m.st != 'mig')) continue;
for (let x in split(m.path ?? '', '/')) if (length(x) > 143) return true;
}
return false;
};
if (act == 'about') {
if (A.t_about > 0 && now - A.t_about < 600 && A.total > 0) return { used: A.used, total: A.total, free: A.free, t: A.t_about };
return pend('about', { id: A.id });
}
if (act == 'find') return pend('find', { id: A.id });
if (act == 'empty') {
if (s.caps.cleanup !== true) return E('caps');
if (!mine && !W.adm) return E('admin');
return pend('rm', { id: A.id, paths: [], empty: true });
}
if (act == 'rtget') {
let p = rpath(a.file);
let rd = match(p ?? '', /^(.*)\/[^\/]+\.wfbak$/);
if (p == null || !rd || (rd[1] != RTROOT && index(RTOLD, rd[1]) < 0)) return E('path');
if (!(stat(BAKPW)?.size > 0)) return E('bakpass');
if (stat(R + '/tmp/wf-restore.pending')) return E('busy');
return qput({ kind: 'rtget', id: A.id, file: substr(p, 1) }, base(p), A.name);
}
if (act == 'ls') {
let p = rpath(a.path);
if (p == null) return E('path');
let qs = trim('' + (a.q ?? ''));
if (length(qs) > 100 || match(qs, /[[:cntrl:]]/)) return E('path');
if (PR && !pin(p, W)) return pls(p, W) ?? E('private');
if (AV(p)) return APE();
let hide = AP && AV(p, true) ? upeople() : null;
if (length(qs) && a.force !== true) { let ix = cixls(A, W, p, qs, C.lim.ls_max); if (ix) return ix; }
return lenc(pend('ls', { id: A.id, path: p, q: qs, max: C.lim.ls_max, ...(hide ? { hide: hide } : {}) }), A.id);
}
if (act == 'size') {
let p = rpath(a.path);
if (p == null) return E('path');
if (PR && !pin(p, W)) return E('private');
if (AV(p, true)) return APE();
return pend('ls', { id: A.id, path: p, du: true });
}
if (act == 'mkdir') {
let p = rpath(a.path);
if (p == null || !nameok(a.name)) return E('path');
if (PR && !pin(p, W)) return E('private');
if (AV(p)) return APE();
let d = (p == '/' ? '' : p) + '/' + a.name;
if (PR && sownother(C, A.id, d, W)) return NE();
if (!mine && cqfull(W)) return E('cquota');
if (CMG([ d ])) return E('cmig');
if (LNG([ d ])) return E('clong');
let r = pend('mkdir', { id: A.id, path: p, name: a.name });
if (PR && r.ok === true && !sownset(A.id, W, [ d ])) return E('busy');
return r;
}
if (PR && (act == 'move' || act == 'rm')) {
let L = paths(a);
if (!L) return E('path');
for (let p in L) if (!pin(p, W, false)) return E('private');
if (act == 'move' && !length(a.name ?? '') && !pin(rpath(a.to), W)) return E('private');
for (let p in L) if (!mayedit(C, A.id, p, W)) return NE();
}
if (AP && (act == 'move' || act == 'rm')) {
let L = paths(a);
if (!L) return E('path');
for (let p in L) if (AV(p, true)) return APE();
if (act == 'move' && !length(a.name ?? '') && AV(rpath(a.to))) return APE();
}
if (act == 'move') {
let P = paths(a);
if (!P) return E('path');
let o = { id: A.id, paths: P };
if (length(a.name ?? '')) {
if (!nameok(a.name) || length(P) != 1) return E('path');
o.name = a.name;
}
else {
let t = rpath(a.to);
if (t == null) return E('path');
o.to = t;
}
let M = map(P, (p) => [ p, o.name ? replace(p, /[^\/]*$/, '') + o.name : (o.to == '/' ? '' : o.to) + '/' + base(p) ]);
for (let m in M) if (PR && sownother(C, A.id, m[1], W)) return NE();
if (CMG([ ...P, ...map(M, (m) => m[1]) ])) return E('cmig');
if (LNG(map(M, (m) => m[1]))) return E('clong');
if (!mine && match(crstof(crget().accts[A.id]), /^(mig|on|back)$/)) {
CK = CK ?? cctx();
let cross = false;
for (let m in M) {
let a_ = cmap(A.id, m[0], CK), b_ = cmap(A.id, m[1], CK), S = [ a_.sec, ...(a_.alt ? [ a_.alt.sec ] : []) ];
if (length(filter(S, (x) => x != b_.sec))) cross = true;
}
if (cross) return qput({ kind: 'mv', ...o, ...(PR && length(M) == 1 && insh(M[0][1]) ? { sown: M[0][1] } : {}) },
base(P[0]) + (length(P) > 1 ? ' +' + (length(P) - 1) : ''), A.name);
}
if (SLOWMV[A.svc]) {
if (!mine && !sownset(A.id, W, null, null, M)) return E('busy');
favfix(A.id, M, null);
return qput({ kind: 'mv', ...o }, base(P[0]) + (length(P) > 1 ? ' +' + (length(P) - 1) : ''), A.name);
}
let r = pend('move', o), n = r.ok === true ? length(M) : (isnum(r.done) ? r.done : 0);
if (!mine && n > 0 && !sownset(A.id, W, null, null, slice(M, 0, n))) return E('busy');
if (n > 0) favfix(A.id, slice(M, 0, n), null);
return r;
}
if (act == 'rm') {
let P = paths(a);
if (!P) return E('path');
if (CMG(P)) return E('cmig');
let fv = a.forever === true && s.caps.trash === true;
if (fv && s.caps.forever !== true) return E('caps');
if (!fv && s.caps.trash !== true && SLOWMV[A.svc]) {
if (!mine && !sownset(A.id, W, null, P)) return E('busy');
favfix(A.id, null, P);
return qput({ kind: 'wtrm', id: A.id, paths: P }, base(P[0]) + (length(P) > 1 ? ' +' + (length(P) - 1) : ''), A.name);
}
let r = pend('rm', { id: A.id, paths: P, trash: s.caps.trash === true && !fv, ...(fv ? { forever: true } : {}) }), n = r.ok === true ? length(P) : (isnum(r.done) ? r.done : 0);
if (!mine && n > 0 && !sownset(A.id, W, null, slice(P, 0, n))) return E('busy');
if (n > 0) favfix(A.id, null, slice(P, 0, n));
return r;
}
if (act == 'link' && a.pub === true) {
if (W.adm) return E('admin', { error: "L'Amministratore non ha una Cartella Pubblica", error_en: 'The Administrator has no Public Folder' });
if (mine) return E('path');
let p = cdir(W.own, 'pub'), md = a.mode ?? 'r', h = a.hours ?? 24;
if (p == null) return E('path');
if ((md != 'r' && md != 'rw') || (h !== 24 && h !== 168)) return E('act');
if (s.caps.link !== true || s.caps.link_exp !== true || (md == 'rw' && s.caps.upreq !== true)) return E('caps');
let cm = cmap(A.id, p);
if (incr(p) || (cm != null && cm.st != 'clear')) return E('crypt');
if (CMG([ p ])) return E('cmig');
return pend('link', { id: A.id, path: p, expire: h == 24 ? 1 : 7, pub: true, mode: md });
}
if (act == 'link') {
let p = rpath(a.path);
if (p == null || p == '/') return E('path');
if (PR && !pin(p, W)) return E('private');
if (AV(p, true)) return APE();
if (s.caps.link !== true) return E('caps');
if (incr(p)) return E('crypt');
let ex = a.expire ?? 0, mx = a.max ?? 0, pw = '' + (a.pass ?? '');
if (!intin(ex, 0, 3650) || !intin(mx, 0, 100000) || length(pw) > 128 || match(pw, /[[:cntrl:]]/)) return E('act');
if ((ex > 0 && s.caps.link_exp !== true) || (length(pw) && s.caps.link_pass !== true) || (mx > 0 && s.caps.link_max !== true)) return E('caps');
let cm = cmap(A.id, p);
if (cm?.st == 'mix') return E('cpriv');
if (cm != null && cm.st != 'clear') {
let lm = intin(C.lim.lcopy_mb, 1, 100000) ? C.lim.lcopy_mb : (tier() == 'A' ? 256 : 2048);
let lo = cm.own == 'shared' ? (W.adm ? 'admin' : W.own) : cm.own, ld = cdir(lo, 'lnk');
if (ld == null) return E('path');
return qput({ kind: 'lcopy', id: A.id, src: p, to: ld, lown: lo, mb: lm,
expire: ex, max: mx, ...(length(pw) ? { pass: pw } : {}) }, base(p), A.name);
}
return pend('link', { id: A.id, path: p, expire: ex, max: mx, ...(length(pw) ? { pass: pw } : {}) });
}
if (act == 'upreq') {
if (W.adm) return E('admin', { error: "L'Amministratore non ha File Ricevuti: le richieste sono delle persone", error_en: 'The Administrator has no Received Files: requests belong to people' });
if (s.caps.upreq !== true) return E('caps');
let nm = trim('' + (a.name ?? '')) || sprintf('Richiesta %d', now % 100000);
if (!nameok(nm)) return E('path');
let p = cdir(W.own, 'recv');
if (p == null) return E('path');
let msg = '' + (a.msg ?? ''), ex = a.expire ?? 0, mb = a.max_mb ?? 0;
if (length(msg) > 500 || match(replace(msg, /[\n\t]/g, ' '), /[[:cntrl:]]/) || !intin(ex, 0, 3650) || !intin(mb, 0, 1000000)) return E('act');
return pend('upreq', { id: A.id, path: p, msg: msg, expire: ex, max_mb: mb, to_nas: a.to_nas !== false });
}
if (act == 'thumbs') {
if (s.caps.thumbs !== true) return E('caps');
let L = a.paths, P = [], K = [], sz = a.size ?? 256;
if (type(L) != 'array' || !length(L) || length(L) > 50) return E('path');
for (let x in L) { let p = type(x) == 'string' ? rpath(x) : null; if (p == null || p == '/') return E('path'); if (PR && !pin(p, W)) return E('private'); if (AV(p)) return APE(); push(P, p); push(K, x); }
if (!intin(sz, 16, 1024) || (sz % 4 && sz % 5)) return E('act');
let CMP = {}, ck = cctx();
for (let p in P) { let m = cmx(A.id, p, ck); if (m) CMP[p] = m; }
return pend('thumbs', { id: A.id, paths: P, keys: K, size: sz, ...(length(CMP) ? { cm: CMP } : {}) });
}
if (act == 'revs' || act == 'revert' || act == 'stream') {
let p = rpath(a.path);
if (act != 'stream' && s.caps.revs !== true) return E('caps');
if (p == null || p == '/') return E('path');
if (PR && !pin(p, W)) return E('private');
if (AV(p)) return APE();
if (incr(p)) return E('bk');
let cm = cmx(A.id, p), cx = cm ? { cm: cm } : {};
if (act == 'revs') return pend('revs', { id: A.id, path: p, ...cx });
if (act == 'revert') {
if (!intin(a.rev, 1, 9007199254740991)) return E('rev');
if (PR && !mayedit(C, A.id, p, W)) return NE();
if (CMG([ p ])) return E('cmig');
return pend('revert', { id: A.id, path: p, rev: a.rev, ...cx });
}
let k = '' + (a.kind ?? 'video');
if (k != 'video' && k != 'audio') return E('act');
return pend('stream', { id: A.id, path: p, kind: k, ...cx });
}
if (act == 'photo') {
let p = rpath(a.path), m = match(p ?? '', /\.([A-Za-z0-9]{1,8})$/);
if (p == null || p == '/') return E('path');
if (PR && !pin(p, W)) return E('private');
if (AV(p)) return APE();
if (incr(p)) return E('bk');
if (m && !extin('imgweb', lc(m[1])) && extin('img', lc(m[1]))) return E('media', { error: 'Questa foto si apre solo in anteprima', error_en: 'This photo opens only as a preview' });
if (!m || !extin('imgweb', lc(m[1]))) return E('media', { error: 'Questo file non è una foto', error_en: 'This file is not a photo' });
let cm = cmx(A.id, p);
return pend('photo', { id: A.id, path: p, ...(cm ? { cm: cm } : {}) });
}
if (act == 'trash') {
if (s.caps.trash_list !== true) return E('caps');
let off = a.off ?? 0;
if (!intin(off, 0, 1000000)) return E('act');
return pend('trash', { id: A.id, off: off, ...tpx(AP, W) });
}
if (act == 'restore' && WT) {
let L = a.tids, T = [], seen = {};
if (type(L) != 'array' || !length(L) || length(L) > 50) return E('path');
for (let t in L) {
if (type(t) != 'string' || !match(t, /^w[0-9]{10,24}$/)) return E('path');
if (!seen[t]) { seen[t] = true; push(T, t); }
}
return pend('restore', { id: A.id, tids: T, ...tpx(AP, W) });
}
if (act == 'restore') {
if (s.caps.trash_list !== true) return E('caps');
let L = a.tids;
if (type(L) != 'array' || !length(L) || length(L) > 50) return E('path');
let T = [], seen = {};
for (let t in L) {
if (type(t) != 'string' || !match(t, /^[fd][1-9][0-9]{0,19}$/)) return E('path');
if (!seen[t]) { seen[t] = true; push(T, t); }
}
return pend('restore', { id: A.id, tids: T, ...tpx(AP, W) });
}
if (act == 'xfer') {
let k = '' + (a.kind ?? '');
let dok = (d, p) => W.adm || (d.id == rjs(NASJ)?.main?.id && pin(p, W));
if (k == 'down' || k == 'nas') {
let P = paths(a);
if (!P) return E('path');
if (PR) for (let p in P) if (!pin(p, W)) return E('private');
for (let p in P) if (AV(p, true)) return APE();
let o = { kind: k, id: A.id, paths: P };
if (k == 'nas' && a.move === true) {
for (let p in P) {
if (PR && (!pin(p, W, false) || !mayedit(C, A.id, p, W))) return NE();
if (AP && AV(p, true)) return APE();
}
if (CMG(P)) return E('cmig');
o.move = true;
}
if (k == 'nas') {
let d = diskof(a.disk);
if (!d) return E('disk');
if (d.ro === true) return E('ro');
let t = rpath(a.to);
if (t == null) return E('path');
if (!dok(d, t) || (W.adm && ulock(t))) return E('private');
if (qfull(W)) return E('quota_full');
o.disk = d.id; o.to = t;
}
return qput(o, base(P[0]) + (length(P) > 1 ? ' +' + (length(P) - 1) : ''), A.name);
}
if (k == 'up') {
let d = diskof(a.disk), src = rpath(a.src), t = rpath(a.to);
if (!d) return E('disk');
if (src == null || src == '/' || t == null) return E('path');
if (!dok(d, src) || (W.adm && ulock(src)) || (PR && !pin(t, W))) return E('private');
if (AV(t)) return APE();
let sp = (t == '/' ? '' : t) + '/' + base(src);
if (PR && sownother(C, A.id, sp, W)) return NE();
if (LNG([ sp ])) return E('clong');
if (!mine && cqfull(W)) return E('cquota');
let mv = a.move === true;
if (mv && !W.adm && (insh(src) || !pin(src, W, false))) return E('private');
return qput({ kind: 'up', id: A.id, disk: d.id, src: src, to: t, ...(mv ? { move: true } : {}), ...(PR && insh(sp) ? { sown: sp } : {}) }, base(src), d.name ?? d.id);
}
if (k == 'copy' && a.to_id != null && a.to_id != A.id) {
let P = paths(a), t = rpath(a.to), mv = a.move === true;
if (!P || t == null || !acctok(a.to_id)) return E('path');
for (let p in P) {
if (PR && !pin(p, W, mv ? false : null)) return E('private');
if (PR && mv && !mayedit(C, A.id, p, W)) return NE();
if (AV(p, true)) return APE();
}
if (CMG(P)) return E('cmig');
let B = ready(a.to_id, ver);
if (B.error) return B;
let bmine = B.user != 'admin';
if (bmine && W.adm) return E('private', { error: "Cloud personale di un'altra persona", error_en: "Another person's personal cloud" });
if (bmine && !W.adm && B.user != W.own) return E('none');
if (!W.adm && !bmine && !pin(t, W)) return E('private');
let bv = W.adm && !bmine && type(UCFG.upriv) == 'function' ? UCFG.upriv(W, t, rjs(NASJ) ?? {}) : null;
if (bv != null && bv != 'up') return APE();
if (!bmine && cqfull(W)) return E('cquota');
let BK = null, bst = crstof(crget().accts[B.id]);
if (match(bst, /^(mig|back)$/) && cmigp(B.id, t, BK = BK ?? cctx())) return E('cmig');
let M = map(P, (p) => (t == '/' ? '' : t) + '/' + base(p));
if (!bmine && match(bst, /^(mig|on|back)$/)) for (let m in M) {
let c = cmap(B.id, m, BK = BK ?? cctx());
if (c == null || (c.st != 'enc' && c.st != 'mig')) continue;
for (let x in split(c.path ?? '', '/')) if (length(x) > 143) return E('clong');
}
if (!bmine && !W.adm) for (let m in M) if (sownother(C, B.id, m, W)) return NE();
let SO = !bmine && !W.adm ? filter(M, (m) => insh(m)) : [];
return qput({ kind: 'copy', id: A.id, paths: P, to_id: B.id, to: t, ...(mv ? { move: true } : {}),
...(length(SO) ? { sown: SO } : {}) },
base(P[0]) + (length(P) > 1 ? ' +' + (length(P) - 1) : ''), B.name ?? A.name);
}
if (k == 'copy') {
let P = paths(a), t = rpath(a.to);
if (!P || t == null) return E('path');
for (let p in P) {
if (PR && !pin(p, W)) return E('private');
if (AV(p, true)) return APE();
if (under(t, p)) return E('path');
}
if (PR && !pin(t, W)) return E('private');
if (AV(t)) return APE();
let M = map(P, (p) => (t == '/' ? '' : t) + '/' + base(p));
for (let m in M) if (PR && sownother(C, A.id, m, W)) return NE();
if (CMG([ ...P, ...M ])) return E('cmig');
if (LNG(M)) return E('clong');
if (!mine && cqfull(W)) return E('cquota');
return qput({ kind: 'copy', id: A.id, paths: P, to: t, ...(PR && length(M) == 1 && insh(M[0]) ? { sown: M[0] } : {}) },
base(P[0]) + (length(P) > 1 ? ' +' + (length(P) - 1) : ''), A.name);
}
if (k == 'phone') {
let t = rpath(a.to);
if (!jobok(a.job) || !stat(PH + '/' + a.job + '.ok')) return E('job');
if (t == null) return E('path');
if (PR && !pin(t, W)) return E('private');
if (AV(t)) return APE();
let nm = length(a.name ?? '') && nameok(a.name) ? a.name : 'file';
if (!mine && t == cdir(W.own, 'root') && type(UCFG.utype) == 'function') t = cdir(W.own, 'up', UCFG.utype(nm)) ?? t;
let sp = (t == '/' ? '' : t) + '/' + nm;
if (PR && sownother(C, A.id, sp, W)) return NE();
if (LNG([ sp ])) return E('clong');
if (!mine && cqfull(W)) return E('cquota');
return qput({ job: a.job, kind: 'phone', id: A.id, to: t, name: nm, ...(PR && insh(sp) ? { sown: sp } : {}) }, nm, 'Telefono');
}
if (k == 'url') {
let u = '' + (a.url ?? ''), t = cdir(W.own, 'dl'), here = false;
if (a.here === true && length(a.to ?? '')) {
let t2 = rpath(a.to);
if (t2 == null) return E('path');
if (PR && !pin(t2, W)) return E('private');
if (AV(t2)) return APE();
if (LNG([ t2 ])) return E('clong');
t = t2; here = true;
}
if (t == null) return E('path');
if (length(u) > 2048 || !match(u, /^https?:\/\/[^ ]+$/) || match(u, /[[:cntrl:]]/)) return E('path');
if (qfull(W)) return E('quota_full');
if (!mine && cqfull(W)) return E('cquota');
return qput({ kind: 'url', id: A.id, url: u, to: t, ...(here ? { here: true } : {}) }, base(replace(u, /[?#].*$/, '')) || 'Link', 'Link');
}
return E('act');
}
return E('act');
}

function crfix(L, own, ov, nv) {
let W = {}, NM = rcnames(), any = false;
for (let id in L) {
let s = UCFG.crsec(id, own);
if (s == null || !NM[s]) continue;
if (nv == null) W[s] = null;
else { let S = rcsec(s); S.remote = rcname(id) + ':' + UD.root + '/' + nv; W[s] = S; }
}
if (length(W)) rcset(W);
let CR = crget(), pf = lc(ov) + '/';
for (let id in L) for (let k in keys(CR.accts[id]?.f ?? {})) if (substr(lc(k), 0, length(pf)) == pf) any = true;
if (any) crsave((X) => {
for (let id in L) {
let F = X.accts[id]?.f;
if (type(F) != 'object') continue;
for (let k in keys(F)) if (substr(lc(k), 0, length(pf)) == pf) { let v = F[k]; delete F[k]; if (nv != null) F[nv + substr(k, length(ov))] = v; }
}
});
}
function udel(own, N) {
if (type(own) != 'string' || own == 'admin' || own == 'shared') return E('path');
let p = UCFG.udir(own, 'root', null, N);
if (p == null) return E('path');
begintmp();
let ver = rcver(), r = { n: 0, skip: [] }, D = [];
if (ver == null) return pkgE();
for (let x in cget().accounts) {
if (auser(x) != 'admin') continue;
let A = ready(x.id, ver);
if (A.error) { push(r.skip, x.id); continue; }
let o = pend('rm', { id: A.id, paths: [ '/' + p ], trash: svcof(A.svc).caps.trash === true, own: 'admin' });
if (o.error) push(r.skip, x.id); else { r.n++; push(D, x.id); }
}
crfix(D, own, UCFG.bname(p), null);
return r;
}
function cvis(own, ov, nv) {
if (type(own) != 'string' || !length(own) || own == 'shared' || !nameok(ov) || !nameok(nv) || ov == nv) return E('path');
begintmp();
let ver = rcver(), r = { n: 0, skip: [] }, D = [];
if (ver == null) return pkgE();
for (let x in cget().accounts) {
if (auser(x) != 'admin') continue;
let A = ready(x.id, ver);
if (A.error) { push(r.skip, x.id); continue; }
let o = pend('move', { id: A.id, paths: [ '/' + UD.root + '/' + ov ], name: nv, own: 'admin' });
if (o.error) push(r.skip, x.id); else { r.n++; push(D, x.id); }
}
crfix(D, own, ov, nv);
return r;
}

function udetach(own) {
if (type(own) != 'string' || !length(own) || own == 'admin' || own == 'shared') return E('path');
LG = uilang(); begintmp();
let r = { n: 0, skip: [] };
for (let x in cget().accounts) {
if (auser(x) != own) continue;
let o = cloudcall({ act: 'del', id: x.id }, { adm: true, own: 'admin', keep: true });
if (type(o) != 'object' || o.error) push(r.skip, x.id); else r.n++;
}
return r;
}
function upreq_close(own) {
if (type(own) != 'string' || !length(own) || own == 'admin' || own == 'shared') return E('path');
LG = uilang(); begintmp();
if (!lkget(LKLK)) return E('busy');
let L = lget(), now = time(), gone = filter(L, (x) => type(x) == 'object' && x.kind == 'upreq' && ownof(x) == own);
let ok = !length(gone) || wsec(LJ, sprintf('%J', { items: filter(L, (x) => index(gone, x) < 0) }));
lkput(LKLK);
if (!ok) return E('busy');
for (let x in gone) {
let rq = 'r' + substr(hk('unlink|' + (x.req ?? '') + '|' + now), 0, 14);
wjs600(REQ + '/' + rq + '.json', { act: 'unlink', link: x, req: rq, t: now, lang: LG });
}
if (length(gone)) kick();
return { n: length(gone) };
}
function uorphan() {
let N = rjs(NASJ), r = { n: 0, skip: [] };
if (type(N?.users) != 'object') return r;
if (migrating() || (stat(CJLK) != null && !lkstale(CJLK))) return { ...r, busy: true };
let seen = {};
for (let x in cget().accounts) {
let u = auser(x);
if (u == 'admin' || u == 'shared' || N.users[u] != null || seen[u]) continue;
seen[u] = true;
let o = udetach(u);
if (o?.error) push(r.skip, x.id);
else { r.n += o.n; for (let s in o.skip) push(r.skip, s); }
}
return r;
}

function rcparse(s) {
if (substr(trim(s), 0, 1) == '{') { try { return json(s); } catch (e) { return null; } }
let W = {}, cur = null;
for (let l in split(s, '\n')) {
l = replace(l, /\r$/, '');
if (!length(trim(l)) || match(l, /^[ \t]*[#;]/)) continue;
let m = match(l, /^\[(-?)([^\]]+)\][ \t]*$/);
if (m) { cur = m[2]; W[cur] = m[1] == '-' ? null : (W[cur] ?? {}); if (m[1] == '-') cur = null; continue; }
let kv = match(l, /^([A-Za-z0-9_]+)[ \t]*=[ \t]?(.*)$/);
if (!kv || cur == null) return null;
W[cur][kv[1]] = kv[2];
}
return length(W) ? W : null;
}
function rcput(f) {
CLI = true;
let s = lstat(f);
if (!s || s.type != 'file') { warn('rcput: file non valido\n'); return 2; }
let W = rcparse(readfile(f) ?? '');
if (!W || !rcok(W)) { unlink(f); warn('rcput: file non valido\n'); return 2; }
if (!rcset(W)) { print('busy\n'); return 1; }
unlink(f);
return 0;
}
if (global.ARGV?.[0] == 'rcput' && type(global.ARGV?.[1]) == 'string') exit(rcput(global.ARGV[1]));
if (global.ARGV?.[0] == 'devflow' && devok(global.ARGV?.[1])) exit(devflow(global.ARGV[1]));
if (global.ARGV?.[0] == 'usize') exit(usize());
if (global.ARGV?.[0] == 'ukick') exit(ukick());
if (global.ARGV?.[0] == 'cruser' && type(global.ARGV?.[1]) == 'string') { CLI = true; let o = cruser(global.ARGV[1]); print(sprintf('%J\n', o)); exit(o?.error ? 1 : 0); }
if (global.ARGV?.[0] == 'keytest' && acctok(global.ARGV?.[1])) {
let r = 2;
try { r = crktrun(global.ARGV[1]); } catch (e) {
unlink(CRD + '/' + global.ARGV[1] + '.ktk');
for (let f in (lsdir(TMP) ?? [])) if (substr(f, 0, length('.kt-' + PID + '.')) == '.kt-' + PID + '.') { unlink(TMP + '/' + f); rmdir(TMP + '/' + f); }
writefile(CRD + '/' + global.ARGV[1] + '.kt', 'retry'); warn('keytest: ' + e + '\n'); }
exit(r);
}
if (global.ARGV?.[0] == 'orphans') { CLI = true; let o = uorphan(); print(sprintf('%J\n', o)); exit(o.busy ? 1 : 0); }

const ARGS = { act: 'x', id: 'x', svc: 'x', token: 'x', fields: {}, name: 'x', path: 'x', to: 'x', paths: [], kind: 'x', src: 'x', dst: 'x',
disk: 'x', url: 'x', expire: 0, pass: 'x', max: 0, msg: 'x', max_mb: 0, to_nas: true, job: 'x', do: 'x', req: 'x', drop: [],
ok_warn: true, own: true, as: 'x', line: {}, router: {}, until: 0, off: 0, data: 'x', last: true, q: 'x', file: 'x', on: true, cache_gb: 0, cache: 'x', rw: true, speed: 'x',
size: 0, rev: 0, tids: [], keyok: true, rekey: true, key: 'x', stop: true, resume: true, force: true, pub: true, mode: 'x', hours: 0, show: true,
move: true, forever: true, here: true, ubus_rpc_session: 'x',
to_id: 'x' };

return {
cloud: {
args: ARGS,
call: function(req) {
LG = uilang(); begintmp(); dlsweep(time());
let a = type(req?.args) == 'object' ? req.args : {};
let O = {}, W = UCFG.who(req, O);
if (W == null) return E(O.why == 'blocked' ? 'blocked' : 'who');
WO = W.own;
let r = null;
try { r = cloudcall(a, W); } catch (e) { warn('cloud: ' + e + '\n'); r = E('busy'); }
WO = 'admin';
return r;
}
},
cloud_state: {
args: {},
call: function(req) { LG = uilang(); begintmp(); dlsweep(time()); return stateout(); }
},
_rc: {
rcset: rcset, rcsec: rcsec, rcname: rcname, acct: acct, accts: () => accts(null, null, rcver()), sum: sum, line: line, tier: tier,
par: () => par(), paused: paused, svcs: () => svcs(rcver()), err: E, udel: udel, udetach: udetach, uorphan: uorphan, upreq_close: upreq_close, uhome: uhome,
cmap: (acct, p) => cmap(acct, p), cvis: cvis
}
};
