#!/usr/bin/ucode
'use strict';
import { readfile, popen, stdout, stat, mkdir, rmdir } from 'fs';

function out(s) { stdout.write(s); stdout.flush(); }
function param(k) { let m = match(getenv('QUERY_STRING') ?? '', regexp('(^|&)' + k + '=([^&]*)')); return m ? m[2] : ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function cutn(s, n) { s = '' + s; if (length(s) <= n) return s; while (n > 0 && (ord(s, n) & 192) == 128) n--; return substr(s, 0, n); }
function sess() { let m = match(getenv('HTTP_AUTHORIZATION') ?? '', /^Bearer ([0-9a-f]{32})$/); return m ? m[1] : param('sid'); }
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }

let sid = sess(), mac = lc(replace(param('mac'), /%3[Aa]/g, ':')), iv = +param('iv') || 1000, once = param('once') == '1';
if (iv < 500 || iv > 2000) iv = 1000;
if (!match(sid, /^[0-9a-f]{32}$/) || (length(mac) && !match(mac, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/))) {
out('Status: 400 Bad Request\r\nContent-Type: text/plain\r\n\r\nparametri non validi\n');
exit(0);
}
function acc(f) { let a = null; try { a = json(sh('ubus call session access ' + q(sprintf('%J', { ubus_rpc_session: sid, scope: 'ubus', object: 'wrtfreedom', 'function': f })) + ' 2>/dev/null')); } catch (e) {} return a?.access === true; }
if (!acc('wifi')) {
if (!acc('nas_me')) {
out('Status: 403 Forbidden\r\nContent-Type: text/plain\r\n\r\naccesso negato\n');
exit(0);
}
once = true; mac = '';
}
let ip = replace(getenv('REMOTE_ADDR') ?? '', /^::ffff:/, ''), me = '';
if (match(ip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) {
for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) {
let f = split(trim(l), /[ \t]+/);
if (f[0] == ip && match(f[3] ?? '', /^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$/) && f[3] != '00:00:00:00:00:00') { me = lc(f[3]); break; }
}
}
else if (match(ip, /^[0-9a-fA-F:]{2,39}$/)) {
let m = match(sh('ip -6 neigh show ' + q(ip) + ' 2>/dev/null'), /lladdr ([0-9a-fA-F:]{17})/);
if (m) me = lc(m[1]);
}
let peer = null;
if (!length(me) && length(ip)) {
for (let l in split(sh('wg show all allowed-ips 2>/dev/null'), '\n')) {
let f = split(trim(l), /[ \t]+/);
if (length(f) < 3 || !match(f[1], /^[A-Za-z0-9+\/]{42,43}=?$/)) continue;
for (let k = 2; k < length(f); k++) if (f[k] == ip + '/32' || f[k] == ip + '/128') {
let nm = '';
for (let c in split(sh('uci -q show network 2>/dev/null'), '\n')) {
let m = match(c, /^network\.([A-Za-z0-9_@\[\]-]+)\.public_key='(.*)'$/);
if (m && m[2] == f[1]) { let d = match(sh('uci -q get ' + q('network.' + m[1] + '.description') + ' 2>/dev/null'), /^([^\n]*)/); nm = d ? d[1] : ''; break; }
}
peer = { id: 'w' + replace(replace(replace(f[1], /=+$/, ''), /\+/g, '-'), /\//g, '_'), name: cutn(nm, 40) };
break;
}
if (peer) break;
}
}
if (!length(mac)) mac = me;
let head = sprintf('%J\n', { me: me || null, ip: ip, mac: mac || null, own: length(mac) > 0 && mac == me, ...(peer ? { peer: peer } : {}) });
if (once || !length(mac)) {
out('Status: 200 OK\r\nContent-Type: application/json\r\nCache-Control: no-store\r\n\r\n' + head);
exit(0);
}
const LK = '/tmp/wf-me.lock';
if (!mkdir(LK)) {
let s = stat(LK);
if (!(s && time() - s.mtime > 70 && rmdir(LK) && mkdir(LK))) {
out('Status: 429 Too Many Requests\r\nContent-Type: text/plain\r\nRetry-After: 5\r\n\r\nlettura già in corso\n');
exit(0);
}
}
out('Status: 200 OK\r\nContent-Type: application/x-ndjson\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nX-Accel-Buffering: no\r\n\r\n' + head);

let IFS = [];
try {
let S = json(sh('ubus call network.wireless status 2>/dev/null'));
for (let r in S) for (let i in (S[r].interfaces ?? [])) if (i.ifname && (i.config?.mode ?? 'ap') == 'ap' && match(i.ifname, /^[A-Za-z0-9_.-]{1,32}$/)) push(IFS, i.ifname);
} catch (e) {}
function sta(i) { let o = sh('iw dev ' + q(i) + ' station get ' + mac + ' 2>/dev/null'); return index(o, 'Station') >= 0 ? o : null; }
function num(o, k) { let m = match(o, regexp('\n[ \t]*' + k + ':[ \t]*(-?[0-9.]+)')); return m ? +m[1] : null; }
let cur = null, inf = null, c0 = clock();
while (true) {
let c = clock(), ms = (c[0] - c0[0]) * 1000 + int((c[1] - c0[1]) / 1000000), o = cur ? sta(cur) : null;
if (!o) {
cur = null;
for (let i in IFS) { o = sta(i); if (o) { cur = i; break; } }
if (cur) {
let m = match(sh('iw dev ' + q(cur) + ' info 2>/dev/null'), /channel ([0-9]+) \(([0-9]+) MHz\)/);
inf = m ? { ch: +m[1], band: +m[2] < 2500 ? '2g' : +m[2] >= 5925 ? '6g' : '5g' } : { ch: null, band: null };
}
}
let r = { t: ms, mac: mac, on: o != null };
if (o) { r.if = cur; r.band = inf.band; r.ch = inf.ch; r.sig = num(o, 'signal'); r.avg = num(o, 'signal avg'); r.txr = num(o, 'tx bitrate'); r.rxr = num(o, 'rx bitrate'); }
out(sprintf('%J\n', r));
if (ms > 55000) break;
sleep(o ? iv : 2500);
}
rmdir(LK);
