#!/usr/bin/ucode
import { readfile, writefile, unlink, mkdir, rmdir, lsdir, stat, popen } from "fs";

const Q = '/tmp/wf-tgq', LOCK = '/tmp/wf-tgq.lock', MAXAGE = 86400, MAXN = 100, MIDF = '/tmp/wf-tgmid.json';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function cutb(s, n) {
s = '' + s;
if (length(s) <= n) return s;
while (n > 0 && (ord(s, n) & 192) == 128) n--;
return substr(s, 0, n);
}
function cut(s, n) {
s = '' + s;
if (length(s) <= n) return s;
let c = cutb(s, n - 3), sp = rindex(c, ' '), lf = rindex(c, '\n');
if (lf > sp) sp = lf;
if (sp > length(c) * 0.8) c = substr(c, 0, sp);
return rtrim(c) + '…';
}
function cutc(s, n) {
s = '' + s;
let u = 0, p = -1;
for (let i = 0; i < length(s); i++) {
let b = ord(s, i);
if ((b & 192) == 128) continue;
u += b >= 240 ? 2 : 1;
if (u > n - 1 && p < 0) p = i;
if (u > n) return rtrim(substr(s, 0, p)) + '…';
}
return s;
}
function tgfit(s, mx) {
s = '' + s; mx = mx ?? 4096;
let u = 0, p = -1;
for (let i = 0; i < length(s); i++) {
let c = ord(s, i);
if ((c & 192) == 128) continue;
let w = c >= 240 ? 2 : 1;
if (p < 0 && u + w > mx - 6) p = i;
u += w;
}
return u <= mx || p < 0 ? s : cut(s, p + 3);
}
function u16(s) { let n = 0; for (let i = 0; i < length(s); i++) { let c = ord(s, i); if ((c & 192) != 128) n += c >= 240 ? 2 : 1; } return n; }
function hesc(s) { return replace(replace(replace('' + s, '&', '&amp;'), '<', '&lt;'), '>', '&gt;'); }
function uo(sec, opt) {
let s = false;
for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
if (m && m[1] == opt) return m[2];
}
return '';
}
function urlenc(s) {
let o = '';
for (let i = 0; i < length(s); i++) {
let c = ord(s, i);
o += ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 46 || c == 95 || c == 126) ? chr(c) : sprintf('%%%02X', c);
}
return o;
}

const ACC = /^[a-z][a-z0-9]{0,19}$/;
function chats() {
let R = [], cur = null;
for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { cur = match(l, /^config tgchat /) ? {} : null; if (cur) push(R, cur); continue; }
let m = cur ? match(l, /^[[:blank:]]*option (id|role|own) '?([^']*)'?[[:blank:]]*$/) : null;
if (m) cur[m[1]] = m[2];
}
for (let x in R) if (!length(x.own)) x.own = 'admin';
return filter(R, (x) => match(x.id ?? '', /^-?[0-9]{1,20}$/) && (x.own == 'admin' || match(x.own, ACC)));
}
let NJ = null;
function pok(acc) {
if (NJ == null) { try { NJ = json(readfile((getenv('WF_NASETC') ?? '/etc/wrtfreedom') + '/nas.json') ?? '{}'); } catch (e) {} if (type(NJ) != 'object') NJ = {}; }
let u = NJ.users?.[acc];
return type(u) == 'object' && !u.cam && !u.blocked;
}
const TGU = (getenv('WF_NASETC') ?? '/etc/wrtfreedom') + '/tg-u';
let UB = null;
function ubots(ach) {
if (UB != null) return UB;
UB = {};
for (let f in sort(lsdir(TGU) ?? [])) {
let m = match(f, /^([a-z0-9]+)\.json$/), j = null;
if (!m || !match(m[1], ACC)) continue;
try { j = json(readfile(TGU + '/' + f) ?? ''); } catch (e) { j = null; }
if (type(j) != 'object') continue;
let c = '' + (j.chat ?? '');
if (match(c, /^-?[0-9]{1,20}$/) && index(ach, c) < 0) UB[m[1]] = { ch: c, ao: type(j.aoff) == 'array' ? map(j.aoff, (x) => '' + x) : [] };
}
return UB;
}
function acnt(a) {
let lt = localtime(time()), d = sprintf('%04d%02d%02d', lt.year, lt.mon, lt.mday), f = '/tmp/wf-tg-u/' + a + '.acnt', j = null;
try { j = json(readfile(f) ?? 'null'); } catch (e) { j = null; }
let n = type(j) == 'object' && j.d == d ? +j.n || 0 : 0;
mkdir('/tmp/wf-tg-u', 0700);
writefile(f, sprintf('%J', { d: d, n: n + 1 }));
}
function acat(ty, txt) {
ty = replace('' + ty, /^cron_/, '');
if (match(ty, /^nas_(bk|backup|cloudbk)/)) return 'backup';
if (match(ty, /^nas_cloud_(ok|err)$/) && match('' + (txt ?? ''), /Backup Cloud|Cloud Backup|Controllo Integrit|Integrity Check/)) return 'backup';
if (match(ty, /^nas_photo/)) return 'photo';
if (match(ty, /^nas_dl/)) return 'dl';
if (match(ty, /^nas_(link|req|invite)/) || match(ty, /^cloud_(upreq|link|req|invite)/)) return 'link';
if (match(ty, /^nas_quota/) || match(ty, /^cloud_(full|space|quota)/)) return 'space';
if (match(ty, /^cloud_(trash_restore|rev_revert)/)) return '';
if (match(ty, /^(cloud|nas_cloud)/)) return 'cloud';
if (match(ty, /^nas_(user_locked|login)/)) return 'safe';
return '';
}
let EO = null;
function evtype(t0, own, txt) {
if (EO == null) {
EO = {};
for (let l in split(readfile('/tmp/wf-evown') ?? '', '\n')) {
let p = split(l, '|', 4);
if (length(p) == 4) { EO[p[0] + '|' + p[2] + '|' + p[3]] = p[1]; EO['|' + p[2] + '|' + p[3]] = p[1]; }
}
}
return EO[t0 + '|' + own + '|' + txt] ?? EO['|' + own + '|' + txt] ?? '';
}
function rname() {
let U = null, v = '';
try { U = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')(); } catch (e) { U = null; }
if (type(U?.uiname) == 'function') v = U.uiname('/etc/config/');
return length(v) ? v : (trim(readfile('/proc/sys/kernel/hostname') ?? '') || 'OpenWrt');
}
function hm(s) { let m = match(s, /^([0-9]{1,2}):([0-9]{2})$/); return m ? +m[1] * 60 + +m[2] : null; }
function hhmm(t) { let lt = localtime(t); return sprintf('%02d:%02d', lt.hour, lt.min); }

if (ARGV[0] != 'flush') { warn('uso: ucode tgq.uc flush\n'); exit(1); }
function lkfresh() { unlink(LOCK + '/a'); writefile(LOCK + '/a', ''); }
function lkfree() { unlink(LOCK + '/a'); rmdir(LOCK); }
if (!mkdir(LOCK)) {
let s = stat(LOCK);
if (s && time() - s.mtime < 120) exit(0);
lkfree(); if (!mkdir(LOCK)) exit(0);
}
let tk = uo('tg', 'token'), chat = uo('tg', 'chat'), en = uo('ui', 'lang') == 'en', bot = uo('tg', 'cmd') == '1', CH = chats();
const HOME = length(tk) > 0 && length(chat) > 0, ACH = [ chat, ...map(filter(CH, (x) => x.own == 'admin'), (x) => x.id) ];
const TL = '\n<i>' + hesc(rname()) + '</i>';
function lines(s) { return split(replace('' + s, ' ¦ ', '\n'), '\n'); }
function fmt(s) {
let o = [], R = lines(s);
for (let i = 0; i < length(R); i++) {
let e = hesc(R[i]);
push(o, i == 0 ? '<b>' + e + '</b>' : replace(e, /([0-9]{1,3}\.){3}[0-9]{1,3}/g, (m) => '<code>' + m + '</code>'));
}
return join('\n', o);
}
function first(s) { return lines(s)[0]; }
const UP = int(+split(readfile('/proc/uptime') ?? '0', ' ')[0]);
function age(t0) { let a = time() - t0; return UP > 0 && a > UP ? UP : a; }
function late(t0) { return age(t0) > 60 && (UP <= 0 || time() - t0 <= UP) ? '\n🕒 ' + (en ? 'at ' : 'alle ') + hhmm(t0) : ''; }
let L = sort(filter(lsdir(Q) ?? [], (f) => match(f, /^[0-9]+-/)));
while (length(L) > MAXN) unlink(Q + '/' + shift(L));
const KD = '/tmp/wf-tg.k', CURL = length(filter([ '/usr/bin/curl', '/usr/sbin/curl', '/bin/curl', '/sbin/curl' ], (f) => stat(f) != null)) > 0;
function kq(s) { return '"' + replace(replace('' + s, '\\', () => '\\\\'), '"', () => '\\"') + '"'; }
function send(ch, txt, kb, rid, nu) {
if (!CURL) return null;
lkfresh();
let k = '';
if (rid) k += '&reply_parameters=' + urlenc(sprintf('%J', { message_id: +rid, allow_sending_without_reply: true }));
if (kb) {
let id = replace(kb, /:/g, '');
k += '&reply_markup=' + urlenc(sprintf('%J', { inline_keyboard: [[{ text: en ? '✅ I Know It' : '✅ Lo Conosco', callback_data: 'dk:' + id }, { text: en ? '⛔ Block' : '⛔ Blocca', callback_data: 'db:' + id }]] }));
}
else if (nu) k += '&reply_markup=' + urlenc(sprintf('%J', { inline_keyboard: [[{ text: en ? '✅ Approve' : '✅ Va Bene', callback_data: 'nu:o:' + nu }, { text: en ? '⛔ Block' : '⛔ Blocca', callback_data: 'nu:b:' + nu }]] }));
mkdir(KD, 448);
let f = KD + '/q-' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time()), /[^0-9a-f]/g, ''), 0, 10);
let room = 4096 - u16(TL), b = tgfit(txt, room), e = fmt(b);
for (let i = 0; i < 3 && u16(e) > room; i++) { b = tgfit(txt, room - (u16(e) - u16(b))); e = fmt(b); }
writefile(f, 'url = ' + kq('https://api.telegram.org/bot' + tk + '/sendMessage') + '\ndata = ' + kq('chat_id=' + urlenc(ch) + '&parse_mode=HTML&text=' + urlenc(e + TL) + k) + '\n');
let o = sh('curl -s -m 15 -K ' + f + ' 2>/dev/null');
unlink(f);
try { return json(o); } catch (e) {}
return null;
}
let REJ = false;
const REJF = '/tmp/wf-tgrej';
function rej(r) {
if (!r || r.ok || !(+r.error_code >= 400 && +r.error_code < 429)) return;
let d = cutb('' + (r.description ?? ''), 200);
if (match(d, /chat not found/i)) return;
sh('logger -t wrtfreedom-tg ' + q('Telegram ' + r.error_code + ': ' + d) + ' >/dev/null 2>&1');
if (REJ) return;
REJ = true;
let h = 0;
for (let i = 0; i < length(tk); i++) h = (h * 31 + ord(tk, i)) % 1000000007;
let key = h + ' ' + r.error_code + ' ' + d;
if (readfile(REJF) == key) return;
writefile(REJF, key);
sh('WF_NOTG=1 sh /usr/share/wrtfreedom/event.sh cron tgrej sys ' + q('⚠️ Bot ¦ ' + (en ? 'Message refused by Telegram' : 'Messaggio rifiutato') + ' ¦ ' + r.error_code + ': ' + d) + ' >/dev/null 2>&1 </dev/null');
}
let MID = null;
function midl() { if (MID == null) { try { MID = json(readfile(MIDF) ?? '[]'); } catch (e) {} if (type(MID) != 'array') MID = []; } return MID; }
function midof(re) {
let sp = index(re, ' '), t = sp > 0 ? +substr(re, 0, sp) : 0, p = sp > 0 ? substr(re, sp + 1) : '';
if (!t || !length(p)) return null;
let L0 = midl();
for (let i = length(L0) - 1; i >= 0; i--) {
let e = L0[i];
if (type(e) == 'object' && +e.t >= t - 5 && +e.t <= t + 3600 && substr('' + e.x, 0, length(p)) == p) return e.m;
}
return null;
}
function usmark(F, us) {
let v = join(',', map(keys(us), (a) => a + '.' + (+us[a] || 0)));
for (let x in F) {
let s = readfile(Q + '/' + x.f);
if (s != null) writefile(Q + '/' + x.f, '#us:' + v + '\n' + replace(s, /^#us:[^\n]*\n/, ''));
}
}
function usread(s) {
let U = {};
for (let p in split(s ?? '', ',')) { let m = match(p, /^([a-z][a-z0-9]{0,19})\.([0-9]{1,20})$/); if (m) U[m[1]] = +m[2]; }
return U;
}
function deliver(o, txt) {
let R = (length(o.reh) ? midof(o.reh) : null) ?? {};
o.mid = {};
if (length(o.to)) {
if (o.own != 'all' && length(o.own)) {
let B = ubots(ACH)[o.own];
if (!B || B.ch != o.to || !pok(o.own)) return true;
let r = send(o.to, txt, '', R['u:' + o.own]);
if (r?.ok && r.result?.message_id) o.mid['u:' + o.own] = r.result.message_id;
return r == null ? null : (r.ok || (+r.error_code >= 400 && +r.error_code < 429)) ? true : null;
}
if (index(ACH, o.to) < 0) return true;
let r = send(o.to, txt, '', R[o.to]);
rej(r);
return r == null ? null : (r.ok || (+r.error_code >= 400 && +r.error_code < 429)) ? true : null;
}
let so = o.so == '1', r = so ? null : send(chat, txt, bot ? o.kb : '', R[chat], bot ? o.nu : '');
if (!so) rej(r);
let hok = so || (r != null && (r.ok || (+r.error_code >= 400 && +r.error_code < 429)));
if (r?.ok && r.result?.message_id) o.mid[chat] = r.result.message_id;
if (hok && !so) for (let x in CH) if (x.id != chat && x.own == 'admin') {
let pb = bot && x.role == 't';
let r2 = send(x.id, txt, pb ? o.kb : '', R[x.id], pb ? o.nu : '');
rej(r2);
if (r2?.ok && r2.result?.message_id) o.mid[x.id] = r2.result.message_id;
}
if (length(o.own)) {
let U = ubots(ACH), us = o.us ?? {}, nw = false;
let want = (a, x) => !length(x.ac) || index(U[a].ao, x.ac) < 0;
for (let a in keys(U)) if ((o.own == 'all' || o.own == a) && pok(a)) {
let t2 = txt;
if (o.pt) {
let sel = filter(o.fs, (x) => want(a, x));
if (!length(sel)) continue;
if (length(sel) < length(o.fs)) t2 = o.pt(sel);
}
else if (!want(a, o)) continue;
if (us[a] != null) { if (+us[a]) o.mid['u:' + a] = +us[a]; continue; }
let r3 = send(U[a].ch, t2, '', R['u:' + a]);
us[a] = r3?.ok && r3.result?.message_id ? r3.result.message_id : 0; nw = true;
if (us[a]) { o.mid['u:' + a] = us[a]; acnt(a); }
}
if (!hok && nw) usmark(o.fs ?? [ o ], us);
}
return hok ? true : null;
}
function midsave(o, mid) {
if (!length(o.c) || length(o.reh) || length(o.to) || !length(keys(mid ?? {}))) return;
let L0 = midl();
push(L0, { t: o.t0, x: cutb(o.txt, 400), m: mid });
MID = slice(L0, -40);
writefile(MIDF, sprintf('%J', MID));
}
let M = [], lt = localtime(), nm = lt.hour * 60 + lt.min, qf = hm(uo('ev', 'qfrom') || '23:00'), qt = hm(uo('ev', 'qto') || '07:00');
let quiet = uo('ev', 'quiet') == '1' && qf != null && qt != null && qf != qt && (qf < qt ? (nm >= qf && nm < qt) : (nm >= qf || nm < qt));
let qpass = split(uo('ev', 'qpass') || 'net sys fw custode nas!', ' '), grp = +(uo('ev', 'group') || '0');
let qok = (c) => length(c) && (index(qpass, c) >= 0 || (c == 'nas!' && index(qpass, 'nas') >= 0));
let offtg = uo('ev', 'tg') == '0';
for (let f in L) {
let t0 = +split(f, '-')[0], txt = readfile(Q + '/' + f);
if (txt == null || age(t0) > MAXAGE) { unlink(Q + '/' + f); continue; }
let o = { f: f, t0: t0, kb: '', c: '', to: '', reh: '', nu: '', own: '', us: '', ty: '', so: '' };
for (let nl = index(txt, '\n'); nl > 0 && substr(txt, 0, 1) == '#'; nl = index(txt, '\n')) {
if (substr(txt, 0, 4) == '#re:') { o.reh = substr(txt, 4, nl - 4); txt = substr(txt, nl + 1); continue; }
let h = match(substr(txt, 0, nl), /^#(kb|c|to|nu|own|us|ty|so):([^ ]*)$/);
if (!h) break;
o[h[1]] = h[2]; txt = substr(txt, nl + 1);
}
o.us = usread(o.us);
if (length(o.kb) && !match(o.kb, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/)) o.kb = '';
if (length(o.nu) && !match(o.nu, ACC)) o.nu = '';
if (o.own == 'admin' || (o.own != 'all' && !match(o.own, ACC))) o.own = '';
if (o.so != '1' || !length(o.own) || o.own == 'all' || length(o.to) || length(o.nu)) o.so = '';
if (!HOME) { unlink(Q + '/' + f); continue; }
if (offtg && length(o.c) && !length(o.to)) { unlink(Q + '/' + f); continue; }
if (!length(trim(txt))) { let s = stat(Q + '/' + f); if (!s || time() - s.mtime > 10) unlink(Q + '/' + f); continue; }
o.txt = txt;
o.ac = length(o.own) && !length(o.to) ? acat(match(o.ty, /^[A-Za-z0-9_]{1,64}$/) ? o.ty : evtype(t0, o.own, txt), txt) : '';
if (quiet && !length(o.to) && !qok(o.c)) continue;
push(M, o);
}
let stop = false;
let old = grp <= 0;
let GO = {};
for (let o in M) if (!length(o.kb) && !length(o.nu) && !length(o.to) && (old ? age(o.t0) > 60 : !qok(o.c))) { o.g = true; let k = o.own + (o.so == '1' ? '|so' : ''); if (!GO[k]) GO[k] = []; push(GO[k], o); }
function group(G) {
if (length(G) == 1) { let o = G[0]; if (deliver(o, o.txt + late(o.t0)) == null) return false; midsave(o, o.mid); unlink(Q + '/' + o.f); return true; }
let part = [], size = 0;
let flush = () => {
if (!length(part)) return true;
let pt = (P) => { let np = length(P); return '🔔 ' + (en ? (np == 1 ? '1 alert' : np + ' alerts') : (np == 1 ? '1 avviso' : np + ' avvisi')) + '\n' + join('\n', map(P, (o) => ((UP <= 0 || time() - o.t0 <= UP) ? hhmm(o.t0) + ' ' : '') + cutc(first(o.txt), (UP <= 0 || time() - o.t0 <= UP) ? 23 : 29))); };
let us = {};
for (let a in keys(part[0].us)) if (length(filter(part, (o) => o.us[a] == null)) == 0) us[a] = part[0].us[a];
let d = { kb: '', to: '', nu: '', own: part[0].own, so: part[0].so, us: us, fs: part, pt: pt };
if (deliver(d, pt(part)) == null) return false;
for (let o in part) { midsave(o, d.mid); unlink(Q + '/' + o.f); }
part = []; size = 0;
return true;
};
for (let o in G) {
let n = (length(first(o.txt)) > 300 ? 300 : length(first(o.txt))) + 12;
if (size + n > 3800 && !flush()) return false;
push(part, o); size += n;
}
return flush();
}
if (old) for (let w in keys(GO)) if (!group(GO[w])) { stop = true; break; }
if (!stop) for (let o in M) {
if (o.g) continue;
let txt = o.txt + late(o.t0);
let r = deliver(o, txt);
if (r == null) { stop = true; break; }	/* nessuna risposta: si riprova più tardi, nello stesso ordine */
midsave(o, o.mid);
unlink(Q + '/' + o.f);
}
if (!old && !stop) for (let w in keys(GO)) if (age(GO[w][0].t0) >= grp && !group(GO[w])) break;
lkfree();
