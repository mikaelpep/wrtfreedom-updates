'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, readlink, open } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', XJ = ETC + '/nasx.json', NJ = ETC + '/nas.json';
const TMP = '/tmp/wf-nas', X = TMP + '/x';
const SH = getenv('WF_NASXSH') ?? '/usr/share/wrtfreedom/nasx.sh';
const WEBCONF = ETC + '/nasx-web.conf', INIT = R + '/etc/init.d/wf-nasx', PIDF = R + '/var/run/wf-nasx.pid';
const PORT = 5006, LMAX = 100, SIDLE = 1800, SMAX = 43200;
const NPORT = 5007, RMAX = 20, XCH = 4194304, LKEEP = 2592000;
const LHOURS = [ 24, 168, 720 ], RHOURS = [ 24, 72, 168 ], LMAXS = [ 0, 1, 5, 10 ], RGB = [ 1, 5, 20 ], NOTI = [ 'first', 'each', 'never' ];
const KEYF = ETC + '/nasx.key', NFTD = R + '/usr/share/nftables.d/chain-pre', NFTF = 'wf-nasx-allow.nft';
const PHOURS = [ 24, 168 ], PMODES = [ 'r', 'rw' ], SESSJ = TMP + '/sess.json';
const ACLF = getenv('WF_ACLF') ?? (R + '/usr/share/rpcd/acl.d/wrtfreedom.json'), NGRP = 'wrtfreedom-nas', NBAD = 5, NLOCK = 900;
const NASVCUC = getenv('WF_NASVCUC') ?? '/usr/share/wrtfreedom/nasvc.uc';
const NASUUC = getenv('WF_NASUUC') ?? '/usr/share/wrtfreedom/nasu.uc';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(R + p) != null; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function rid() { return substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10) || ('' + time()); }
function wjs(f, o) { let t = f + '.t' + rid(); writefile(t, sprintf('%J', o)); rename(t, f); }
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
function mkdirp(p) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c); } }
function uniq(a) { let s = {}, r = []; for (let x in a) { x = '' + x; if (length(x) && !s[x]) { s[x] = 1; push(r, x); } } return r; }
function alive(p) { return match('' + p, /^[0-9]+$/) != null && stat('/proc/' + p) != null; }

const B64U = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
function token() {
let s = readfile('/dev/urandom', 24) ?? '', o = '';
if (length(s) < 24) s = rid() + rid() + rid();
for (let i = 0; i + 2 < 24; i += 3) {
let v = (ord(s, i) << 16) | (ord(s, i + 1) << 8) | ord(s, i + 2);
o += substr(B64U, (v >> 18) & 63, 1) + substr(B64U, (v >> 12) & 63, 1) + substr(B64U, (v >> 6) & 63, 1) + substr(B64U, v & 63, 1);
}
return o;
}
function hexr(n) { let s = readfile('/dev/urandom', n) ?? '', o = ''; for (let i = 0; i < length(s); i++) o += sprintf('%02x', ord(s, i)); return length(o) ? o : rid(); }
function sha256(s) {
let d = null; try { d = require('digest'); } catch (e) { d = null; }
if (type(d?.sha256) == 'function') return d.sha256(s);
mkdirp(X);
let f = X + '/.h' + rid(), p = popen('sha256sum > ' + q(f), 'w');
if (!p) return '';
p.write(s); p.close();
let o = substr(readfile(f) ?? '', 0, 64);
unlink(f);
return o;
}
const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
const hk = UCFG.hk, b64d = UCFG.b64d;
function urlenc(s) {
s = '' + s; let o = '';
for (let i = 0; i < length(s); i++) { let c = substr(s, i, 1); o += match(c, /^[A-Za-z0-9._~-]$/) ? c : sprintf('%%%02X', ord(s, i)); }
return o;
}

function cfg(name) { return UCFG.read((getenv('WF_CFGDIR') ?? '/etc/config/') + name, false); }
function uset(c, s, o, v) { return 'uci -q set ' + q(c + '.' + s + '.' + o + '=' + v) + '; '; }

let LG = 'it';
function L(it, en) { return LG == 'en' ? en : it; }
function err(code, it, en, x) { let r = { error: it, error_en: en, code: code }; for (let k, v in x ?? {}) r[k] = v; return r; }
function begin() { LG = cfg('wrtfreedom')?.ui?.lang == 'en' ? 'en' : 'it'; mkdirp(X); mkdir(ETC); }
function ev(t, txt) { detach('sh ' + q(R + '/usr/share/wrtfreedom/event.sh') + ' cron ' + t + ' nas ' + q(txt)); }

const XLK = TMP + '/cmig.lock';
let XSN = [];
function xsnap(o) {
let s = json(sprintf('%J', o));
for (let e in XSN) if (e[0] === o) { e[1] = s; return s; }
push(XSN, [ o, s ]);
while (length(XSN) > 16) shift(XSN);
return s;
}
function xmrg(D, o, S) {
for (let k, v in o) {
let s = S[k];
if (type(v) == 'object' && type(s) == 'object' && type(D[k]) == 'object') xmrg(D[k], v, s);
else if (s == null || sprintf('%J', v) != sprintf('%J', s)) D[k] = v;
}
let K = keys(o);
for (let k in keys(S)) if (index(K, k) < 0) delete D[k];
}
function xget() {
let o = rjs(XJ) ?? {};
if (type(o.cloud) != 'array') o.cloud = [];
if (type(o.link) != 'object') o.link = {};
if (type(o.link.list) != 'array') o.link.list = [];
if (type(o.photo) != 'object') o.photo = {};
if (type(o.photo.phones) != 'object') o.photo.phones = {};
if (type(o.req) != 'array') o.req = [];
if (type(o.link.days) != 'object') o.link.days = {};
for (let l in o.link.list) {
if (l.where != 'net' && l.where != 'home') { l.where = 'home'; o.mig = true; }
if (!((l.exp ?? 0) > 0)) { l.exp = time() + 720 * 3600; o.mig = true; }
if (index(LMAXS, l.max) < 0) l.max = 0;
if (index(NOTI, l.notify) < 0) l.notify = 'never';
}
if (o.link.out != null) { delete o.link.out; o.mig = true; }
let S = xsnap(o);
if (o.mig === true) S.link = null;
return o;
}
function nason() { return (rjs(NJ) ?? {}).on !== false; }
function ownof(o) { return o?.own ?? 'admin'; }
function mine(w, o) { return w.adm || ownof(o) == w.own; }
const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function xlock() { return UCFG.pidlock(XLK, TMP, 30); }
function xunlock() { UCFG.pidunlock(XLK); }
function xput(o) {
if (!xlock()) return false;
let S = null, ok = true;
for (let e in XSN) if (e[0] === o) S = e[1];
try {
delete o.mig;
let D = o;
if (S) { D = rjs(XJ); if (type(D) != 'object') D = {}; xmrg(D, o, S); delete D.mig; }
o.saved = D.saved = time(); mkdirp(ETC); wjs(XJ, D);
xsnap(o);
} catch (e) { ok = false; }
xunlock();
return ok;
}
function njput(fn) {
if (!njlock()) return null;
let o = rjs(NJ);
if (type(o) != 'object') o = {};
try { fn(o); mkdirp(ETC); let t = NJ + '.t' + NJPID; writefile(t, sprintf('%J', o)); rename(t, NJ); } catch (e) { o = null; }
njunlock();
return o;
}
function BUSY() { return err('busy', 'Impostazioni del NAS occupate: riprova', 'NAS settings busy: try again'); }
function allowclean() {
let ch = false;
for (let d in lsdir(NFTD) ?? []) { let f = NFTD + '/' + d + '/' + NFTF; if (stat(f)) { unlink(f); ch = true; } }
if (ch) detach('sh ' + q(SH) + ' fw');
if ((rjs(NJ) ?? {}).remote?.allow != null) njput((o) => { if (type(o.remote) == 'object') delete o.remote.allow; });
return ch;
}

const SYS = getenv('WF_SYS') ?? '/sys';
function blkinfo(ML) { return UCFG.blkinfo(ML, { sys: SYS, run: TMP, sh, rj: rjs, wjr: wjs, mkdirp }); }
function disks() {
let D = UCFG.nasdisks(R, rjs(NJ) ?? {}, blkinfo);
let s = sprintf('%J', { fp: hk(sprintf('%J', D)), list: D });
if (readfile(X + '/disks.json') != s) { mkdirp(X); let t = X + '/disks.json.t' + rid(); writefile(t, s); rename(t, X + '/disks.json'); }
return D;
}
function diskof(D, id) { for (let d in D) if (d.id == id) return d; return null; }
function badname(n) { return UCFG.badname(n); }
function relp(p) { return UCFG.relp(p, true); }
function absp(d, p) { return UCFG.absp(d, p); }
function bname(a) { return UCFG.bname(a); }
function freeb(p) {
let f = null; try { f = require('fs').statvfs; } catch (e) { f = null; }
if (f) { let s = null; try { s = f(p); } catch (e) {} if (s) return (s.bavail ?? 0) * (s.frsize ?? s.bsize ?? 4096); }
let l = split(trim(sh('df -kP ' + q(p) + ' 2>/dev/null')), '\n'), x = split(l[length(l) - 1] ?? '', /[ \t]+/);
return match(x[3] ?? '', /^[0-9]+$/) ? +x[3] * 1024 : 0;
}
function dsk(D, id, write) {
let d = diskof(D, '' + (id ?? ''));
if (!d) return err('disk', 'Disco non collegato', 'Drive not connected');
if (write && d.ro) return err('ro', 'Disco in sola lettura: qui si può solo leggere', 'Drive is read-only: only reading is possible here', { ro: true });
return d;
}

const PK = {
rclone: [ [ 'rclone', '/usr/bin/rclone' ], [ 'ca-bundle', '/etc/ssl/certs/ca-certificates.crt' ] ],
web: [ [ 'lighttpd', '/usr/sbin/lighttpd' ], [ 'lighttpd-mod-cgi', '/usr/lib/lighttpd/mod_cgi.so' ] ],
https: [ [ 'lighttpd-mod-openssl', '/usr/lib/lighttpd/mod_openssl.so' ] ]
};
function need(part) {
let r = [];
for (let p in PK[part]) { let ok = false; for (let i = 1; i < length(p); i++) if (has(p[i])) ok = true; if (!ok) push(r, p[0]); }
return r;
}
function pkgerr(P) { return err('pkg', 'Serve installare: ' + join(', ', P), 'Needs to be installed: ' + join(', ', P), { need: P }); }

const VPNIF = /^wgo(ut|[0-9]+)$/;
function zarr(z) { return type(z.network) == 'array' ? z.network : split(z.network ?? '', ' '); }
function wgsrv(N, i) { return N[i]?.proto == 'wireguard' && !match(i, VPNIF) && length('' + (N[i].listen_port ?? '')) > 0; }
function wgcli(N, i) { return N[i]?.proto == 'wireguard' && !wgsrv(N, i); }
function ifdump() {
let s = stat((getenv('WF_CFGDIR') ?? '/etc/config/') + 'network'), fp = s ? s.mtime + ':' + s.size + ':' + s.inode : '', C = rjs(X + '/ifs.json');
if (type(C?.I) == 'object' && C.fp == fp && time() - (C.t ?? 0) < 30) return C.I;
let D = null, I = {};
try { D = json(sh('ubus -S call network.interface dump 2>/dev/null') || '{}'); } catch (e) { D = null; }
for (let i in (D?.interface ?? [])) if (type(i?.interface) == 'string')
I[i.interface] = { up: i.up === true, dev: '' + (i.l3_device ?? i.device ?? ''), v4: map(filter(i['ipv4-address'] ?? [], (a) => type(a?.address) == 'string'), (a) => a.address) };
mkdirp(X);
wjs(X + '/ifs.json', { fp: fp, t: time(), I: I });
return I;
}
function zones() {
let F = cfg('firewall'), N = cfg('network'), home = null, alt = null, wans = [], Z = {}, out = {};
for (let k in F) {
let z = F[k];
if (z['.type'] != 'zone' || !z.name || !match(z.name, /^[A-Za-z0-9_]{1,15}$/)) continue;
let masq = z.masq == '1' || z.masq == 'true';
Z[z.name] = { nets: zarr(z), input: uc(z.input ?? 'REJECT'), masq: masq };
for (let i in Z[z.name].nets) if (wgcli(N, i)) out[z.name] = 1;
if (out[z.name]) continue;
if (!home && index(Z[z.name].nets, 'lan') >= 0) home = z.name;
if (!alt && !masq && uc(z.input ?? '') == 'ACCEPT') alt = z.name;
if (masq) push(wans, z.name);
}
home = home ?? alt;
wans = filter(wans, (n) => n != home);
let vpn = [], wan = wans[0];
for (let n, z in Z) {
if (n == home || index(wans, n) >= 0 || out[n]) continue;
for (let i in z.nets) if (wgsrv(N, i)) { push(vpn, n); break; }
}
let ip = '', I = ifdump();
for (let n in (Z[home]?.nets ?? [])) if (I[n]?.up && length(I[n].v4)) { ip = I[n].v4[0]; break; }
if (!length(ip)) for (let n in (Z[home]?.nets ?? [])) {
let a = N[n]?.ipaddr, s = '' + (type(a) == 'array' ? a[0] : (a ?? ''));
let m = match(s, /^([0-9]{1,3}(\.[0-9]{1,3}){3})/);
if (m) { ip = m[1]; break; }
}
if (length(ip) && readfile(X + '/lanip') != ip) { mkdirp(X); writefile(X + '/lanip', ip); }
return { home: home, wan: wan, wans: wans, vpn: vpn, Z: Z, ip: ip, out: out };
}
function ddnsname() {
let D = cfg('ddns');
for (let k, s in D) if (s['.type'] == 'service' && s.enabled == '1') {
let h = s.lookup_host ?? s.domain ?? '';
if (match(h, /^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$/)) return h;
}
return '';
}
function listening() {
let P = {};
for (let f in [ '/proc/net/tcp', '/proc/net/tcp6' ])
for (let l in split(readfile(f) ?? '', '\n')) {
let m = match(l, /^[ \t]*[0-9]+: [0-9A-Fa-f]+:([0-9A-Fa-f]{4}) [0-9A-Fa-f]+:[0-9A-Fa-f]{4} 0A /);
if (m) { let h = lc(m[1]), v = 0; for (let i = 0; i < 4; i++) { let c = ord(h, i); v = v * 16 + (c >= 97 ? c - 87 : c - 48); } P[v] = 1; }
}
return P;
}
function portbad(p) {
let N = rjs(NJ) ?? {}, ssh = 22, D = cfg('dropbear');
for (let k, s in D) if (s['.type'] == 'dropbear' && match('' + (s.Port ?? s.port ?? ''), /^[0-9]{1,5}$/)) { ssh = +(s.Port ?? s.port); break; }
return p < 1024 || p > 65535 || index([ 5005, +(N.remote?.port ?? 5005), 6800, 8200, 1900, 2049, 111, ssh, 8080, 8443 ], p) >= 0;
}

const XINIT = '#!/bin/sh /etc/rc.common\n# WrtFreedom: Link Di Condivisione e video del NAS (lighttpd in sola lettura), scritto da nasx.uc e tolto da nasx.sh uninstall\nSTART=99\nUSE_PROCD=1\n' +
'start_service() {\n\t[ -f /etc/wrtfreedom/nasx-web.conf ] || return 0\n\tsh /usr/share/wrtfreedom/nasx.sh prep || return 0\n\tprocd_open_instance\n' +
'\tprocd_set_param command /usr/sbin/lighttpd -D -f /etc/wrtfreedom/nasx-web.conf\n\tprocd_set_param respawn\n\tprocd_close_instance\n}\n';
function running() { return alive(trim(readfile(PIDF) ?? '')); }
const ST = X + '/st', CDL = '/tmp/wf-cloud/dl';
function cloudtok(v) { return type(v) == 'object' && type(v.cloud) == 'string' && match(v.cloud, /^j[0-9a-z]{4,24}$/) != null && v.p === CDL + '/' + v.cloud; }
function streams(purge) {
let n = time(), o = {};
for (let f in lsdir(ST) ?? []) {
let m = match(f, /^([A-Za-z0-9_-]+)\.json$/), v = m ? rjs(ST + '/' + f) : null;
if (type(v) == 'object' && n - (v.a ?? 0) < SIDLE && n - (v.t ?? 0) < SMAX && (v.cloud == null || n < (v.x ?? 0))) o[m[1]] = v;
else if (purge && m) { unlink(ST + '/' + f); if (cloudtok(v)) { unlink(v.p); unlink(v.p + '.tok'); } }
}
return o;
}
function streamadd(e) {
let S = streams(true), K = sort(keys(S), (x, y) => (S[x].a ?? 0) - (S[y].a ?? 0)), tk = token();
while (length(K) >= 50) unlink(ST + '/' + shift(K) + '.json');
mkdirp(ST);
wjs(ST + '/' + tk + '.json', e);
return tk;
}
function ups(purge) {
let U = rjs(X + '/up.json') ?? {}, n = time(), o = {}, ch = false;
for (let k, v in U) { if (type(v) == 'object' && n - (v.t ?? 0) < SMAX) o[k] = v; else ch = true; }
if (ch && purge) wjs(X + '/up.json', o);
return o;
}
function invites() { let I = rjs(TMP + '/invite.json') ?? {}, n = 0; for (let k, v in I) if (type(v) == 'object' && (v.until ?? 0) > time()) n++; return n; }
function people(N) { let c = 0; for (let k, u in (type(N?.users) == 'object' ? N.users : {})) if (type(u) == 'object' && u.cam !== true) c++; return c; }
function appout() { let N = rjs(NJ) ?? {}; return N.on !== false && N.remote?.app === true && N.remote?.on !== false && people(N) > 0; }
function srvneed(Xc) {
return nason() && ((Xc.link.on !== false && (length(Xc.link.list) > 0 || length(Xc.req) > 0)) || length(filter(values(streams(false)), (v) => v.cloud == null)) > 0 || length(keys(ups(false))) > 0 || invites() > 0 || appout() || (Xc.link.on !== false && Xc.photo?.on !== false));
}

function privip(ip) { return match('' + ip, /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.)/) != null; }
function wanst(Zs) {
let C = rjs(X + '/wan.json');
if (C && time() - (C.t ?? 0) < 60) return C;
let I = ifdump(), ip = '';
for (let n in (Zs.Z[Zs.wan]?.nets ?? [])) if (I[n]?.up && length(I[n].v4)) { ip = I[n].v4[0]; break; }
C = { t: time(), ip: ip, cgnat: length(ip) > 0 && privip(ip) };
wjs(X + '/wan.json', C);
return C;
}
function certna(f) { return UCFG.certdates(f, b64d)?.na ?? 0; }
function tlsinfo() {
let dd = ddnsname(), r = { ddns: dd, ready: false, why: '', exp: 0, crt: '', key: '' };
if (!length(dd)) { r.why = 'ddns'; return r; }
let bn = -1;
for (let p in [ [ '/etc/ssl/acme/' + dd + '.fullchain.crt', '/etc/ssl/acme/' + dd + '.key' ], [ '/etc/acme/' + dd + '_ecc/fullchain.cer', '/etc/acme/' + dd + '_ecc/' + dd + '.key' ],
[ '/etc/acme/' + dd + '/fullchain.cer', '/etc/acme/' + dd + '/' + dd + '.key' ], [ '/etc/ssl/acme/' + dd + '.crt', '/etc/ssl/acme/' + dd + '.key' ] ]) {
if (!has(p[0]) || !has(p[1])) continue;
let n = certna(R + p[0]);
if (n > bn) { r.crt = p[0]; r.key = p[1]; bn = n; }
}
if (!length(r.crt) || !length(r.key)) { r.why = 'cert'; return r; }
r.exp = certna(R + r.crt);
if (r.exp > 0 && r.exp <= time()) { r.why = 'cert'; return r; }
if (length(need('https'))) { r.why = 'pkg'; return r; }
r.ready = true;
return r;
}
function lhits(l) { return (l.hits ?? 0) + (stat(X + '/hits/' + l.tok)?.size ?? 0); }
function lalive(l, n) { return (l.exp ?? 0) > n && !((l.max ?? 0) > 0 && lhits(l) >= l.max); }
function ralive(r, n) { return r.on !== false && (r.exp ?? 0) > n; }
function netinfo(Xc, T) {
let n = time(), until = 0, cnt = 0;
if (Xc.link.on !== false && nason()) {
for (let l in Xc.link.list) if (l.where == 'net' && lalive(l, n)) { cnt++; if (l.exp > until) until = l.exp; }
for (let r in Xc.req) if (r.where == 'net' && ralive(r, n)) { cnt++; if (r.exp > until) until = r.exp; }
}
let app = appout();
return { n: cnt, until: app ? 0 : until, app: app, open: (cnt > 0 || app) && T.ready };
}
const APPCONF = '\tserver.document-root = "' + X + '/wwwr"\n\tindex-file.names = ( "index.html", "n" )\n' +
'\tmimetype.assign = ( ".html" => "text/html; charset=utf-8", ".js" => "text/javascript; charset=utf-8", ".css" => "text/css; charset=utf-8", ' +
'".json" => "application/json", ".png" => "image/png", ".svg" => "image/svg+xml", ".ico" => "image/x-icon", ".woff2" => "font/woff2" )\n' +
'\t$HTTP["url"] =~ "^/app/" {\n\t\tcgi.assign = ( )\n\t}\n';
function webwrite(Xc, T) {
let p = Xc.link.port ?? PORT, np = Xc.link.nport ?? NPORT, a = (k) => '"/' + k + '" => "/usr/bin/ucode"';
let c = 'server.modules = ( "mod_cgi"' + (T.ready ? ', "mod_openssl"' : '') + ' )\nserver.document-root = "' + X + '/www"\nserver.port = ' + p +
'\nserver.pid-file = "/var/run/wf-nasx.pid"\nserver.errorlog-use-syslog = "enable"\nserver.tag = "NAS"\n' +
'server.stream-response-body = 2\nserver.stream-request-body = 2\nserver.max-request-size = 4200\nserver.upload-dirs = ( "' + X + '/up" )\n' +
'server.max-connections = 16\nserver.max-keep-alive-idle = 15\ndir-listing.activate = "disable"\nindex-file.names = ( )\n' +
'cgi.assign = ( ' + join(', ', map([ ...UCFG.LKIND, 'n', 'foto' ], a)) + ' )\n' +
'$HTTP["url"] =~ "^/foto(/|$)" {\n\tserver.max-request-size = 2147483647\n}\n' +
(T.ready ? '$SERVER["socket"] == ":' + np + '" {\n\tssl.engine = "enable"\n\tssl.pemfile = "' + T.crt + '"\n\tssl.privkey = "' + T.key + '"\n' + APPCONF + '}\n' : '');
let ch = readfile(WEBCONF) != c;
if (ch) writefile(WEBCONF, c);
if (readfile(INIT) != XINIT) { writefile(INIT, XINIT); sh('chmod 755 ' + q(INIT) + ' 2>/dev/null'); }
return ch;
}
function fwcmd(Xc, on, open) {
let F = cfg('firewall'), Zs = zones(), c = '', p = '' + (Xc.link.port ?? PORT), np = '' + (Xc.link.nport ?? NPORT);
for (let k in F) if (match(k, /^wf_nasx_/)) c += 'uci -q delete ' + q('firewall.' + k) + '; ';
let rule = (id, name, src, ports, tgt) => src ? 'uci -q set ' + q('firewall.' + id + '=rule') + '; ' + uset('firewall', id, 'name', name) + uset('firewall', id, 'src', src) +
uset('firewall', id, 'proto', 'tcp') + uset('firewall', id, 'dest_port', ports) + uset('firewall', id, 'target', tgt) + uset('firewall', id, 'wf', '1') : '';
if (on) {
if (Zs.home && Zs.Z[Zs.home].input != 'ACCEPT') c += rule('wf_nasx_home', 'wf-nas-link-home', Zs.home, p + ' ' + np, 'ACCEPT');
for (let z in Zs.vpn) c += rule('wf_nasx_vpn_' + z, 'wf-nas-link-vpn-' + z, z, p + ' ' + np, 'ACCEPT');
for (let i = 0; i < length(Zs.wans); i++) {
let z = Zs.wans[i], sx = i ? '_' + z : '', nx = i ? '-' + z : '';
if (open) c += rule('wf_nasx_link' + sx, 'wf-nas-link' + nx, z, np, 'ACCEPT');
c += rule('wf_nasx_lock' + sx, 'wf-nas-link-lock' + nx, z, open ? p : p + ' ' + np, 'REJECT');
}
}
return { c: c + 'uci -q commit firewall; ', fp: sprintf('%J', [ on, open, p, np, Zs.home, Zs.Z[Zs.home]?.input, Zs.vpn, Zs.wans ]) };
}
function farwrite(T, ni, open, np) {
let can = T.ready && !wanst(zones()).cgnat, on = ni.app === true;
let o = { on: on, open: on && open, url: on && T.ready ? 'https://' + T.ddns + ':' + np + '/' : '', can: can };
if (sprintf('%J', o) != sprintf('%J', rjs(TMP + '/far.json'))) { mkdirp(TMP); wjs(TMP + '/far.json', o); }
}
function srvapply(Xc, force, why) {
let on = srvneed(Xc), run = running(), T = tlsinfo(), ni = netinfo(Xc, T), ch = false;
if (on) ch = webwrite(Xc, T);
let open = on && ni.open, F = fwcmd(Xc, on, open), bad = stat(X + '/fw.fp.bad');
let fw = F.fp != (readfile(X + '/fw.fp.new') ?? readfile(X + '/fw.fp')) && !(bad && time() - bad.mtime < 3600 && readfile(X + '/fw.fp.bad') == F.fp);
if (fw) { sh(F.c + 'true'); writefile(X + '/fw.fp.new', F.fp); }
let tail = fw ? '; sh ' + q(SH) + ' fw' : '';
if (on && (!run || force || ch)) detach('sh ' + q(SH) + ' svc on' + tail);
else if (!on && (run || stat(INIT))) detach('sh ' + q(SH) + ' svc off' + tail);
else if (fw) detach('sh ' + q(SH) + ' fw');
let was = stat(X + '/net.open') != null, np = Xc.link.nport ?? NPORT;
farwrite(T, ni, open, np);
if (open && !was) { writefile(X + '/net.open', '' + time()); ev('nas_link_out', L('🗄️ Link Di Condivisione ¦ Porta aperta verso internet ¦ Porta ' + np, '🗄️ Sharing Links ¦ Port open to the internet ¦ Port ' + np)); }
else if (!open && was) {
unlink(X + '/net.open');
if (why == 'exp') ev('nas_link_exp', L('🗄️ Link Di Condivisione ¦ Link scaduto ¦ Porta chiusa', '🗄️ Sharing Links ¦ Link expired ¦ Port closed'));
}
return on && !run;
}
function cnt(f) { return stat(f)?.size ?? 0; }
function tlog(tok) {
let r = [];
for (let l in split(readfile(X + '/log/' + tok) ?? '', '\n')) { if (!length(l)) continue; try { let o = json(l); if (type(o) == 'object') push(r, o); } catch (e) {} }
return r;
}
function dkey(t) { let x = localtime(t); return sprintf('%04d%02d%02d', x.year, x.mon, x.mday); }
function reqtmp(r, f) {
let o = { used: 0, files: 0, refused: 0, last: 0, arr: [] };
for (let l in split(readfile(f ?? (X + '/req/' + r.tok + '.log')) ?? '', '\n')) {
if (!length(l)) continue;
let e = null; try { e = json(l); } catch (x) { e = null; }
if (type(e) != 'object') continue;
if (e.refused) { o.refused++; continue; }
o.used += e.size ?? 0; o.files++;
if ((e.t ?? 0) > o.last) o.last = e.t;
push(o.arr, { name: e.name ?? '', size: e.size ?? 0, t: e.t ?? 0 });
}
o.arr = slice(o.arr, -20);
return o;
}
function hitsfold(Xc) {
let n = 0;
for (let l in Xc.link.list) {
let h = cnt(X + '/hits/' + l.tok), d = cnt(X + '/dl/' + l.tok), f = cnt(X + '/fail/' + l.tok), G = tlog(l.tok);
if (stat(X + '/seen/' + l.tok) && l.seen !== true) { l.seen = true; n++; }
if (!h && !d && !f && !length(G)) continue;
if (h) { l.hits = (l.hits ?? 0) + h; l.last = stat(X + '/hits/' + l.tok).mtime; writefile(X + '/hits/' + l.tok, ''); }
if (d) { l.dl = (l.dl ?? 0) + d; writefile(X + '/dl/' + l.tok, ''); }
if (f) { l.fails = (l.fails ?? 0) + f; writefile(X + '/fail/' + l.tok, ''); }
for (let e in G) { let k = dkey(e.t ?? time()); Xc.link.days[k] = (Xc.link.days[k] ?? 0) + 1; }
if (length(G)) { l.log = slice([ ...(type(l.log) == 'array' ? l.log : []), ...G ], -50); unlink(X + '/log/' + l.tok); }
n++;
}
for (let r in Xc.req) {
let f = X + '/req/' + r.tok + '.log', g = f + '.f' + rid();
if (!stat(f) || !rename(f, g)) continue;
let t = reqtmp(r, g);
unlink(g);
if (!t.files && !t.refused) continue;
r.used = (r.used ?? 0) + t.used; r.files = (r.files ?? 0) + t.files; r.refused = (r.refused ?? 0) + t.refused;
if (t.last > (r.last ?? 0)) r.last = t.last;
r.arr = slice([ ...(type(r.arr) == 'array' ? r.arr : []), ...t.arr ], -20);
n++;
}
let K = sort(keys(Xc.link.days));
while (length(K) > 8) delete Xc.link.days[shift(K)];
return n;
}
function hitsof(l) {
let s = stat(X + '/hits/' + l.tok);
return { hits: (l.hits ?? 0) + (s?.size ?? 0), last: s?.size ? s.mtime : (l.last ?? 0), dl: (l.dl ?? 0) + cnt(X + '/dl/' + l.tok), fails: (l.fails ?? 0) + cnt(X + '/fail/' + l.tok) };
}

const MIME = { mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', mkv: 'video/x-matroska', webm: 'video/webm', avi: 'video/x-msvideo',
ts: 'video/mp2t', mts: 'video/mp2t', m2ts: 'video/mp2t', '3gp': 'video/3gpp', mpg: 'video/mpeg', mpeg: 'video/mpeg', wmv: 'video/x-ms-wmv',
mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', wav: 'audio/wav', ogg: 'audio/ogg', opus: 'audio/ogg', wma: 'audio/x-ms-wma',
jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', heic: 'image/heic', pdf: 'application/pdf', txt: 'text/plain; charset=utf-8' };
function mimeof(n) { let m = match(lc(n), /\.([a-z0-9]{1,5})$/); return (m ? MIME[m[1]] : null) ?? 'application/octet-stream'; }

function ctxof(Xc) {
let Zs = zones(), T = tlsinfo();
return { Zs: Zs, T: T, W: wanst(Zs), n: time(), p: Xc.link.port ?? PORT, np: Xc.link.nport ?? NPORT };
}
function homeurl(C, u) { return C.T.ready && !C.W.cgnat ? 'https://' + C.T.ddns + ':' + C.np + u : (length(C.Zs.ip) ? 'http://' + C.Zs.ip + ':' + C.p + u : ''); }
function neturl(C, u) { return C.T.ready ? 'https://' + C.T.ddns + ':' + C.np + u : ''; }
function netok(C) {
if (!length(C.T.ddns)) return err('ddns', 'Da internet serve un nome DDNS', 'From the internet a DDNS name is needed');
if (C.W.cgnat) return err('cgnat', 'La linea non ha un IP pubblico (CGNAT): da internet non si raggiunge', 'The line has no public IP (CGNAT): not reachable from the internet');
if (C.T.why == 'pkg') return pkgerr(need('https'));
if (!C.T.ready) return err('https', 'HTTPS non pronto: manca il certificato del nome DDNS', 'HTTPS not ready: the DDNS name certificate is missing');
return null;
}
function linkout(Xc, l, C) {
let h = hitsof(l), u = '/s/' + l.tok + (l.dir ? '/' : '/' + urlenc(l.name)), exp = (l.exp ?? 0) <= C.n, used = (l.max ?? 0) > 0 && h.hits >= l.max;
return { tok: l.tok, name: l.name, disk: l.disk, path: l.path, ...(type(l.paths) == 'array' ? { paths: l.paths } : {}), dir: l.dir === true, t: l.t ?? 0,
exp: l.exp ?? 0, expired: exp, used_up: used, on: !exp && !used && Xc.link.on !== false, where: l.where ?? 'home', max: l.max ?? 0,
notify: l.notify ?? 'never', pass: type(l.pw) == 'object', hits: h.hits, last: h.last, dl: h.dl, fails: h.fails,
own: ownof(l), kind: l.kind == 'pub' ? 'pub' : 'link', ...(l.kind == 'pub' ? { mode: l.mode == 'rw' ? 'rw' : 'r' } : {}),
...(l.dir !== true ? { size: l.size ?? 0 } : {}),
...(type(l.cl) == 'object' ? { to: 'cloud', acc: l.cl.id, router: true } : {}),
url: homeurl(C, u), url_out: l.where == 'net' ? neturl(C, u) : '' };
}
function blocked(n) {
let r = [];
for (let f in lsdir(X + '/bad') ?? []) {
let m = match(readfile(X + '/bad/' + f) ?? '', /^([0-9]+) ([0-9]+) ([0-9A-Fa-f.:]+)/);
if (m && +m[1] >= 5 && n - +m[2] < 600) push(r, { ip: m[3], until: +m[2] + 600, tok: split(f, '-')[0] });
}
return r;
}
function failstoday(n) {
let t = localtime(n), d0 = n - (t.hour * 3600 + t.min * 60 + t.sec), c = 0;
for (let l in split(readfile(X + '/fails.log') ?? '', '\n')) if (length(l) && +l >= d0) c++;
return c;
}
function days7(Xc, n) {
let D = { ...Xc.link.days }, r = [];
for (let l in Xc.link.list) for (let e in tlog(l.tok)) { let k = dkey(e.t ?? n); D[k] = (D[k] ?? 0) + 1; }
for (let i = 6; i >= 0; i--) push(r, D[dkey(n - i * 86400)] ?? 0);
return r;
}
const PST = { none: 0, ok: 1, run: 2, warn: 3, bad: 4 }, PSTT = { ok: [ 'Tutto A Posto', 'All Good' ], run: [ 'In Corso', 'In Progress' ],
warn: [ 'Da Controllare', 'To Check' ], bad: [ 'Errore', 'Error' ], none: [ 'Nessuno Attivo', 'None Active' ] };
function admsee(w, o) { return w.adm ? ownof(o) == 'admin' : mine(w, o); }
function ovis(own) { let p = UCFG.udir(own, 'root'); return p ? bname(p) : own; }
function peopleof(L, f) {
let P = {};
for (let x in L) {
let o = ownof(x);
if (o == 'admin') continue;
let v = f(x);
if (!P[o]) P[o] = { own: o, own_name: ovis(o), n: 0, st: 'none' };
P[o].n++;
for (let k, n in v) if (k != 'st') P[o][k] = (P[o][k] ?? 0) + n;
if (PST[v.st] > PST[P[o].st]) P[o].st = v.st;
}
return map(sort(keys(P)), (k) => ({ ...P[k], st_t: PSTT[P[k].st][0], st_t_en: PSTT[P[k].st][1] }));
}
function linkst(Xc, l, n, run, bt) {
let h = hitsof(l), on = (l.exp ?? 0) > n && !((l.max ?? 0) > 0 && h.hits >= l.max) && Xc.link.on !== false;
return { st: !on ? 'none' : !run ? 'bad' : bt[l.tok] ? 'warn' : 'ok', opens: h.hits, act: (l.exp ?? 0) > n ? 1 : 0 };
}
function linkget(Xc, w) {
let C = ctxof(Xc), P = need('web'), ni = netinfo(Xc, C.T), run = running(), open = ni.open && srvneed(Xc);
let L = map(filter(Xc.link.list, (l) => admsee(w, l)), (l) => linkout(Xc, l, C));
if (!w.adm) return { on: Xc.link.on !== false, list: L, ddns: C.T.ddns, running: run, out: open, net: { open: open, https: C.T.ready, can: netok(C) == null },
...(length(P) ? { need: P } : {}) };
let B = blocked(C.n), bt = {}, mt = {};
for (let b in B) bt[b.tok] = 1;
for (let l in Xc.link.list) if (ownof(l) == 'admin') mt[l.tok] = 1;
return { on: Xc.link.on !== false, list: L, port: C.p, ddns: C.T.ddns, running: run, out: open,
people: peopleof(Xc.link.list, (l) => linkst(Xc, l, C.n, run, bt)),
net: { open: open, app: ni.app, port: C.np, https: C.T.ready, https_why: C.T.why, cert_exp: C.T.exp, until: open ? ni.until : 0, cgnat: C.W.cgnat === true,
can: netok(C) == null, fails_today: failstoday(C.n), blocked: map(B, (b) => mt[b.tok] ? b : { ip: b.ip, until: b.until }) },
days: days7(Xc, C.n), ...(length(P) ? { need: P } : {}),
...(open ? { warn: 'Porta ' + C.np + ' aperta verso internet', warn_en: 'Port ' + C.np + ' open to the internet' } : {}) };
}
function accdel(tok) { for (let f in lsdir(X + '/acc') ?? []) if (split(f, '@')[1] == tok) unlink(X + '/acc/' + f); }
const CLIN = '.wf-incloud', CPH = '/tmp/wf-cloud/ph';
function clmb() {
let C = rjs(ETC + '/cloud.json') ?? {}, m = C.lim?.phone_mb, t = trim(readfile('/tmp/wf-cloud/tier') ?? '');
return type(m) == 'int' && m > 0 ? m : (t == 'B' || t == 'C' ? 256 : 32);
}
function clmain(D) { let id = (rjs(NJ) ?? {}).main?.id; return id != null ? diskof(D ?? disks(), '' + id) : null; }
function clvia(r, D) {
let m = clmain(D), o = ownof(r), full = o != 'admin' && index(split(readfile(TMP + '/full.list') ?? '', '\n'), o) >= 0;
return m && !m.ro && !stat(TMP + '/mainpause.json') && !full ? 'disk' : 'ram';
}
function clsweep(Xc, n) {
for (let f in lsdir(CPH) ?? []) {
let mm = match(f, /^(jr[0-9a-f]{16})\.(part|res)$/), s = mm ? lstat(CPH + '/' + mm[1] + '.part') : null;
if (mm && (!s || n - s.mtime > 3600) && !stat(CPH + '/' + mm[1] + '.ok')) unlink(CPH + '/' + f);
}
let O = {};
for (let r in Xc.req) if (type(r.cl) == 'object') O[ownof(r)] = 1;
let m = clmain(null);
if (!m || m.ro || !length(O)) return;
for (let o in keys(O)) {
let rb = UCFG.udir(o, 'root'), a = rb != null ? m.mnt + '/' + rb + '/' + CLIN : null, s = a ? lstat(a) : null;
if (s?.type != 'directory') continue;
for (let f in lsdir(a) ?? []) {
let x = lstat(a + '/' + f);
if (x?.type != 'file' || substr(f, 0, 1) == '.' || n - x.mtime < 172800) continue;
let td = UCFG.umkdir(m.mnt, UCFG.udir(o, 'recv', UCFG.utype(f)));
if (td && !lstat(td + '/' + f)) rename(a + '/' + f, td + '/' + f);
}
}
}
function clshl(p, N) {
let s = UCFG.udir('shared', 'root', null, N), P = filter(split(p, '/'), length);
if (s == null) return p;
let S = split(s, '/'), sr = join('/', slice(S, 0, -1)), sn = S[-1];
if (length(P) < 3 || P[0] != sr || P[2] != sn || P[1] == sn || P[1] == 'Amministratore') return p;
for (let u, x in (type(N?.users) == 'object' ? N.users : {}))
if (type(x) == 'object' && !x.cam && UCFG.udir(u, 'root', null, N) == sr + '/' + P[1]) return '/' + s + (length(P) > 3 ? '/' + join('/', slice(P, 3)) : '');
return p;
}
function clmod() { let m = null; try { m = loadfile(getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc')(); } catch (e) { m = null; } return m; }
function cladd(a, w) {
let CM = clmod();
if (type(CM?._rc?.acct) != 'function' || type(CM._rc.cmap) != 'function') return err('svc', 'Cloud non disponibile', 'Cloud not available');
if (a.pub === true) return err('path', 'L\'invito della Cartella Pubblica nel cloud si fa dal cloud', 'The Public Folder invitation in the cloud is made from the cloud');
let A = CM._rc.acct('' + a.acc);
if (!A || (!w.adm && A.user != 'admin' && A.user != w.own)) return err('none', 'Account non trovato', 'Account not found');
if (w.adm && A.user != 'admin') return err('private', 'Cloud di un\'altra persona', 'Another person\'s cloud');
if (A.state == 'relink') return err('relink', 'Cloud da ricollegare', 'Cloud to reconnect');
if (A.state == 'old' || A.state == 'new' || A.state == 'busy') return err('busy', 'Cloud non pronto: riprova fra poco', 'Cloud not ready: try again shortly');
let N = rjs(NJ) ?? {}, com = A.user == 'admin', PS = type(a.paths) == 'array' && length(a.paths) ? a.paths : [ a.path ], out = [], names = {};
if (length(PS) > 50) return err('path', 'Al massimo 50 elementi in un link', 'At most 50 items in a link');
let roots = !w.adm && com ? [ UCFG.udir(w.own, 'root', null, N), UCFG.udir('shared', 'root', null, N) ] : null;
let NOP = () => err('private', 'Cartella di un\'altra persona', 'Another person\'s folder'), inr = (p, b) => p == '/' + b || substr(p, 0, length(b) + 2) == '/' + b + '/';
if (roots && (roots[0] == null || roots[1] == null)) return err('who', 'Accesso scaduto: entra di nuovo', 'Access expired: sign in again');
for (let x in PS) {
let P = type(x) == 'string' ? filter(split(x, '/'), length) : null;
if (!P || !length(P) || length(x) > 1024 || match(x, /[[:cntrl:]]/)) return err('path', 'Percorso non valido', 'Invalid path');
for (let y in P) if (y == '.' || y == '..' || substr(y, 0, 3) == '.wf') return err('path', 'Percorso non valido', 'Invalid path');
let p = '/' + join('/', P);
if (com) p = clshl(p, N);
let rel = substr(p, 1);
if (roots && !inr(p, roots[0]) && !inr(p, roots[1])) return NOP();
if (com && w.adm && UCFG.upriv(null, rel, N) != null) return NOP();
if (CM._rc.cmap(A.id, rel)?.st == 'mix') return err('path', 'Scegli una cartella dentro la tua cartella', 'Choose a folder inside your folder');
let nm = bname(p);
if (length(PS) > 1 && names[nm]) return err('path', 'Elementi con lo stesso nome', 'Items with the same name');
names[nm] = 1;
push(out, p);
}
let o = { cl: { id: A.id, svc: A.svc }, path: out[0], name: bname(out[0]), dir: a.dir === true, size: type(a.size) == 'int' && a.size > 0 ? a.size : 0 };
if (length(out) > 1) {
let par = replace(out[0], /\/[^\/]*$/, ''), same = length(filter(out, (x) => replace(x, /\/[^\/]*$/, '') == par)) == length(out);
o.paths = out; o.dir = true; o.path = length(par) ? par : '/';
o.name = same && length(par) ? bname(par) : o.name + ' +' + (length(out) - 1);
}
return o;
}
function clwait(tok) {
let c = 0;
for (let f in lsdir(CPH) ?? []) if (match(f, /^jr[0-9a-f]{16}\.wait$/) && (rjs(CPH + '/' + f) ?? {}).tok == tok) c++;
return c;
}
function clretry(Xc, n) {
let W = filter(lsdir(CPH) ?? [], (f) => match(f, /^jr[0-9a-f]{16}\.wait$/));
if (!length(W)) return;
let CM = clmod();
for (let f in W) {
let job = substr(f, 0, 18), o = rjs(CPH + '/' + f), p = CPH + '/' + job + '.part', s = lstat(p), r = null;
if (type(o) != 'object' || s?.type != 'file') { unlink(CPH + '/' + f); continue; }
for (let x in Xc.req) if (x.tok == o.tok && type(x.cl) == 'object') r = x;
if (!r) {
let m = clmain(null), td = m && !m.ro ? UCFG.umkdir(m.mnt, UCFG.udir(o.own, 'recv', UCFG.utype('' + o.name))) : null;
if (td) { let nm = '' + o.name; for (let i = 2; lstat(td + '/' + nm) && i < 1000; i++) nm = replace('' + o.name, /(\.[^.]+)?$/, ' (' + i + ')$1'); if (!lstat(td + '/' + nm)) sh('mv ' + q(p) + ' ' + q(td + '/' + nm) + ' 2>/dev/null'); }
unlink(p); unlink(CPH + '/' + job + '.ok'); unlink(CPH + '/' + f);
continue;
}
if (type(CM?.cloud?.call) != 'function') return;
let res = null;
try { res = CM.cloud.call({ args: { act: 'xfer', kind: 'phone', job: job, to: o.to, name: o.name, id: r.cl.id, as: ownof(r) } }); } catch (e) { res = null; }
if (res?.job) unlink(CPH + '/' + f);
else { o.n = (o.n ?? 0) + 1; o.last = n; wjs(CPH + '/' + f, o); }
}
}
const PARTS = ETC + '/nasx-parts';
function partadd(a) {
let R = filter(split(readfile(PARTS) ?? '', '\n'), (x) => length(x));
if (index(R, a) >= 0) return;
push(R, a);
if (length(R) > 200) R = slice(R, length(R) - 200);
let t = PARTS + '.t' + (readlink('/proc/self') ?? 'x');
writefile(t, join('\n', R) + '\n'); rename(t, PARTS);
}
function partsweep(n) {
if (!stat(PARTS) || n - (stat(X + '/parts.t')?.mtime ?? 0) < 21600) return;
writefile(X + '/parts.t', '' + n);
let D = disks(), dirs = {}, keep = {};
for (let l in split(readfile(PARTS) ?? '', '\n')) if (substr(l, 0, 1) == '/') dirs[l] = 1;
for (let a in keys(dirs)) {
let d = null;
for (let x in D) if (!x.ro && substr(a, 0, length(x.mnt) + 1) == x.mnt + '/') d = x;
let s = d ? lstat(a) : null;
if (!d) { keep[a] = 1; continue; }
if (!s || s.type != 'directory') continue;
let left = false;
for (let f in lsdir(a) ?? []) {
if (!match(f, /^\..+\.wfpart$/)) continue;
let x = lstat(a + '/' + f);
if (x?.type != 'file') continue;
if (n - x.mtime > 86400) unlink(a + '/' + f); else left = true;
}
if (left) keep[a] = 1;
}
let K = keys(keep);
if (length(K)) writefile(PARTS, join('\n', K) + '\n'); else unlink(PARTS);
}
function linktick() {
let Xc = xget(), n = time(), nl = length(Xc.link.list), nr = length(Xc.req), mig = Xc.mig === true;
let fold = n - (Xc.saved ?? 0) >= 1800 ? hitsfold(Xc) : 0;
Xc.link.list = filter(Xc.link.list, (l) => (l.exp ?? 0) + LKEEP > n);
Xc.req = filter(Xc.req, (r) => (r.exp ?? 0) + LKEEP > n);
let T = {};
for (let l in Xc.link.list) T[l.tok] = 1;
for (let r in Xc.req) T[r.tok] = 1;
for (let d in [ 'hits', 'dl', 'fail', 'log', 'seen' ]) for (let f in lsdir(X + '/' + d) ?? []) if (!T[f]) unlink(X + '/' + d + '/' + f);
for (let f in lsdir(X + '/req') ?? []) if (!T[replace(f, /\.(json|log)(\.f.*)?$/, '')]) unlink(X + '/req/' + f);
for (let f in lsdir(X + '/bad') ?? []) { let s = stat(X + '/bad/' + f); if (s && n - s.mtime > 3600) unlink(X + '/bad/' + f); }
for (let f in lsdir(X + '/ipz') ?? []) { let s = stat(X + '/ipz/' + f); if (s && n - s.mtime > 3600) unlink(X + '/ipz/' + f); }
for (let d in [ 'put', 'uh' ]) for (let f in lsdir(X + '/' + d) ?? []) {
let a = X + '/' + d + '/' + f, s = stat(a), p = trim(readfile(a + '/pid') ?? '');
if (s && !alive(p) && n - s.mtime > 120) { unlink(a + '/pid'); rmdir(a); }
}
for (let f in lsdir(X + '/acc') ?? []) { let s = stat(X + '/acc/' + f); if (!T[split(f, '@')[1] ?? ''] || !s || n - s.mtime >= 43200) unlink(X + '/acc/' + f); }
partsweep(n);
clsweep(Xc, n);
clretry(Xc, n);
allowclean();
for (let f in lsdir(X + '/nbad') ?? []) { let s = stat(X + '/nbad/' + f); if (s && n - s.mtime >= NLOCK) unlink(X + '/nbad/' + f); }
let FL = filter(split(readfile(X + '/fails.log') ?? '', '\n'), (l) => length(l) && n - +l < 86400);
if (stat(X + '/fails.log')) writefile(X + '/fails.log', length(FL) ? join('\n', FL) + '\n' : '');
streams(true); ups(true);
disks();
let changed = length(Xc.link.list) != nl || length(Xc.req) != nr;
if (changed || fold || mig) xput(Xc);
let t = tlsinfo(), mt = '' + (t.ready ? (stat(R + t.crt)?.mtime ?? 0) : 0), force = false;
if (mt != trim(readfile(X + '/cert.mt') ?? '')) { writefile(X + '/cert.mt', mt); force = running(); }
srvapply(Xc, force, 'exp');
return { ok: true, removed: nl - length(Xc.link.list), running: srvneed(Xc) };
}
function reqout(Xc, r, C) {
let t = reqtmp(r), u = '/r/' + r.tok + '/', exp = (r.exp ?? 0) <= C.n;
return { id: r.id, name: r.name, disk: r.disk, path: r.path, where: r.where ?? 'home', gb: r.gb, used: (r.used ?? 0) + (t.used ?? 0),
files: (r.files ?? 0) + (t.files ?? 0), refused: (r.refused ?? 0) + (t.refused ?? 0), last: (t.last ?? 0) > (r.last ?? 0) ? t.last : (r.last ?? 0),
exp: r.exp ?? 0, expired: exp, pass: type(r.pw) == 'object', on: r.on !== false && !exp && Xc.link.on !== false, own: ownof(r), to: type(r.cl) == 'object' ? 'cloud' : 'disk',
...(type(r.cl) == 'object' ? { acc: r.cl.id, router: true, pub: r.cl.pub === true, via: clvia(r, null), max_mb: clmb(), wait: clwait(r.tok) } : {}),
arr: slice([ ...(type(r.arr) == 'array' ? r.arr : []), ...(type(t.arr) == 'array' ? t.arr : []) ], -20),
url: homeurl(C, u), url_out: r.where == 'net' ? neturl(C, u) : '' };
}
function reqget(Xc, w) {
let C = ctxof(Xc), P = need('web'), run = running();
let rst = (r) => { let t = reqtmp(r), on = r.on !== false && (r.exp ?? 0) > C.n && Xc.link.on !== false;
return { st: !on ? 'none' : !run ? 'bad' : 'ok', open: on ? 1 : 0, arr: (r.files ?? 0) + t.files }; };
return { list: map(filter(Xc.req, (r) => admsee(w, r)), (r) => reqout(Xc, r, C)), on: Xc.link.on !== false, running: run,
...(w.adm ? { people: peopleof(Xc.req, rst) } : {}), ...(length(P) ? { need: P } : {}) };
}
function pwmake(x) {
x = '' + x;
if (length(x) < 4 || length(x) > 64 || match(x, /[[:cntrl:]]/)) return err('pass', 'Password da 4 a 64 caratteri', 'Password from 4 to 64 characters');
let salt = hexr(8), pw = { salt: salt, h: sha256(salt + ':' + x) };
if (length(pw.h) != 64) return err('pass', 'Password non salvata: riprova', 'Password not saved: try again');
if (!match(trim(readfile(KEYF) ?? ''), /^[0-9a-f]{32,}$/)) {
mkdirp(ETC);
let t = KEYF + '.t' + rid();
writefile(t, hexr(32) + '\n'); sh('chmod 600 ' + q(t) + ' 2>/dev/null'); rename(t, KEYF);
}
return pw;
}
function whereset(o, w, C) {
if (w == null) return null;
if (w != 'home' && w != 'net') return err('where', 'Dove si apre: Casa e VPN o Anche Da Internet', 'Where it opens: Home and VPN or Also From The Internet');
if (w == 'net') { let e = netok(C); if (e) return e; }
o.where = w;
return null;
}

function arr(v) { return type(v) == 'array' ? v : (v == null || v == '' ? [] : split('' + v, /[ \t]+/)); }
function wgpeers(N) {
let r = [];
for (let k, s in N) {
let m = match(s['.type'] ?? '', /^wireguard_(.+)$/);
if (!m || !wgsrv(N, m[1]) || !length(s.public_key ?? '')) continue;
let ip = '', ip6 = '';
for (let a in arr(s.allowed_ips)) {
let x = match(a, /^([0-9]{1,3}(\.[0-9]{1,3}){3})(\/32)?$/), y = match(a, /^([0-9A-Fa-f:]*:[0-9A-Fa-f:]*)(\/128)?$/);
if (x && !length(ip)) ip = x[1];
if (y && !length(ip6)) ip6 = lc(y[1]);
}
push(r, { id: s.public_key, name: s.description ?? '', ip: ip, ip6: ip6, vpn: m[1], on: s.disabled != '1' });
}
return r;
}
function vpnlist(N) {
let r = [], P = wgpeers(N);
for (let k, s in N) if (s['.type'] == 'interface' && wgsrv(N, k))
push(r, { kind: 'wireguard', name: k, on: s.disabled != '1', peers: length(filter(P, (p) => p.vpn == k)), addr: split(arr(s.addresses)[0] ?? '', '/')[0], inst: true });
let ts = has('/usr/sbin/tailscaled'), tson = ts && stat(R + '/sys/class/net/tailscale0') != null;
let tsa = tson ? match(sh('ip -4 -o addr show dev tailscale0 2>/dev/null'), /inet ([0-9.]+)/) : null;
push(r, { kind: 'tailscale', name: 'Tailscale', on: tson, peers: null, addr: tsa ? tsa[1] : '', inst: ts });
let O = cfg('openvpn'), oi = has('/usr/sbin/openvpn');
for (let k, s in O) {
if (s['.type'] != 'openvpn' || !(s.server != null || s.mode == 'server' || s.server_bridge != null)) continue;
let dev = '' + (s.dev ?? ''), m = match('' + (s.server ?? ''), /^([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})\.[0-9]{1,3}/);
push(r, { kind: 'openvpn', name: k, on: s.enabled == '1' && length(dev) > 0 && match(dev, /^[A-Za-z0-9_.-]{1,15}$/) != null && stat(R + '/sys/class/net/' + dev) != null,
peers: null, addr: m ? m[1] + '.1' : '', inst: oi });
}
return r;
}
function outnow(N) {
if (!has('/usr/bin/wg')) return 0;
let S = {}, c = 0, n = time();
for (let p in wgpeers(N)) S[p.vpn + '\t' + p.id] = 1;
for (let l in split(sh('wg show all latest-handshakes 2>/dev/null'), '\n')) {
let f = split(l, '\t');
if (length(f) >= 3 && S[f[0] + '\t' + f[1]] && +f[2] > 0 && n - +f[2] < 180) c++;
}
return c;
}
function WHO() { return err('who', 'Accesso scaduto: entra di nuovo', 'Access expired: sign in again'); }
function whoof(req) {
let O = {}, w = UCFG.who(req, O);
if (w) return w;
return O.why == 'blocked' ? err('blocked', 'Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator') : WHO();
}
function ADM() { return err('admin', 'Solo l\'Amministratore', 'Administrator only'); }
function PRIV() { return err('private', 'Cartella di un\'altra persona', 'Another person\'s folder'); }
function NOMAIN() { return err('nomain', 'Manca il Disco Principale', 'The Main Drive is missing'); }
function maindisk(D) { let id = (rjs(NJ) ?? {}).main?.id; return id != null ? diskof(D, '' + id) : null; }
function under(rel, b) { b = '/' + b; return rel == b || substr(rel, 0, length(b) + 1) == b + '/'; }
function scopeok(w, d, m, rel, whole) {
if (w.adm && type(UCFG.upriv) == 'function') { let v = UCFG.upriv(w, rel, rjs(NJ) ?? {}); return v == null || (v == 'up' && !whole); }
let ci = match(UCFG.fsname(d?.fs ?? ''), /^(fat32|ntfs|exfat)$/) != null;
let un = (r, b) => ci ? under(lc(r), lc(b)) : under(r, b);
if (!w.adm) {
let me = UCFG.udir(w.own, 'root'), cs = UCFG.udir('shared', 'root');
return m != null && d.id == m.id && ((me != null && un(rel, me)) || un(rel, cs));
}
if (m == null || d.id != m.id) return true;
let N = rjs(NJ) ?? {};
for (let k, u in (type(N.users) == 'object' ? N.users : {})) {
if (type(u) != 'object' || u.cam === true) continue;
let p = UCFG.udir(k, 'root');
if (p != null && un(rel, p)) return false;
}
return true;
}
function wdisk(w, D, id, write) {
if (w.adm) return dsk(D, id, write);
let m = maindisk(D);
if (!m) return NOMAIN();
if (id != null && id != '' && '' + id != m.id) return PRIV();
return dsk(D, m.id, write);
}
function qfull(w) { return !w.adm && index(split(readfile(TMP + '/full.list') ?? '', '\n'), w.own) >= 0; }
function QFULL() { return err('quota_full', 'Spazio finito: libera spazio o chiedi più spazio', 'Space used up: free some space or ask for more', { pct: 100 }); }

function nasgrp() {
let A = rjs(ACLF)?.[NGRP], r = {};
for (let k in [ 'read', 'write' ]) for (let o, L in (type(A?.[k]?.ubus) == 'object' ? A[k].ubus : {})) {
if (!match(o, /^[a-z_]{2,32}$/) || type(L) != 'array') continue;
for (let m in L) if (type(m) == 'string' && match(m, /^[a-z_]{2,32}$/)) r[o] = uniq([ ...(r[o] ?? []), m ]);
}
return r;
}
function nbadf(ip) { return X + '/nbad/' + hk('n|' + ip); }
function nbadget(ip, n) { let m = match(readfile(nbadf(ip)) ?? '', /^([0-9]+) ([0-9]+)/); return m && n - +m[2] < NLOCK ? { c: +m[1], t: +m[2] } : { c: 0, t: 0 }; }
function LOCKED(u) {
let mn = int((u - time() + 59) / 60);
return err('locked', 'Troppi tentativi: riprova tra ' + mn + ' minuti', 'Too many attempts: try again in ' + mn + ' minutes', { until: u });
}
function SVC() { return err('svc', 'Servizi del router non disponibili', 'Router services not available'); }

const MODC = {};
function modof(f) { return UCFG.modof(MODC, f); }

const M = {
nas_link: {
args: { act: 'x', disk: 'x', path: 'x', paths: [], hours: 0, pass: 'x', tok: 'x', out: true, port: 0, on: true, where: 'x', max: 0, notify: 'x', pub: true, mode: 'x',
own: 'x', acc: 'x', dir: true, size: 0, as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let a = req.args ?? {}, act = a.act ?? 'get', w = whoof(req);
if (w.error) return w;
let Xc = xget(), t = '' + (a.tok ?? '');
if (act == 'tick') return w.adm ? linktick() : ADM();
if (act == 'get') return linkget(Xc, w);
if (act == 'on') {
if (!w.adm) return ADM();
if (type(a.on) != 'bool') return err('on', 'Manca acceso o spento', 'On or off missing');
Xc.link.on = a.on;
if (!xput(Xc)) return BUSY(); srvapply(Xc, false);
return linkget(Xc, w);
}
if (act == 'del_own') {
if (!w.adm) return ADM();
let o = a.own;
if (type(o) != 'string' || !match(o, /^[A-Za-z0-9._-]{1,32}$/) || o == 'admin' || o == 'shared') return err('own', 'Persona non valida', 'Invalid person');
let LT = map(filter(Xc.link.list, (l) => ownof(l) == o), (l) => l.tok), RT = map(filter(Xc.req, (r) => ownof(r) == o), (r) => r.tok);
if (!length(LT) && !length(RT)) return err('none', 'Nessun link di questa persona', 'No links of this person');
hitsfold(Xc);
Xc.link.list = filter(Xc.link.list, (l) => ownof(l) != o);
Xc.req = filter(Xc.req, (r) => ownof(r) != o);
if (!xput(Xc)) return BUSY();
for (let k in LT) { for (let d in [ 'hits', 'dl', 'fail', 'log', 'seen' ]) unlink(X + '/' + d + '/' + k); accdel(k); }
for (let k in RT) unlink(X + '/req/' + k + '.log');
srvapply(Xc, false);
return { ...linkget(Xc, w), removed: length(LT) + length(RT) };
}
let li = -1, pv = false;
for (let k = 0; k < length(Xc.link.list); k++) if (Xc.link.list[k].tok == t) { if (admsee(w, Xc.link.list[k])) li = k; else if (w.adm) pv = true; }
if (pv) return err('private', 'Link di un\'altra persona', 'Another person\'s link');
if (act == 'del') {
if (li < 0) return err('none', 'Link non trovato', 'Link not found');
hitsfold(Xc);
splice(Xc.link.list, li, 1);
for (let d in [ 'hits', 'dl', 'fail', 'log', 'seen' ]) unlink(X + '/' + d + '/' + t);
accdel(t);
if (!xput(Xc)) return BUSY(); srvapply(Xc, false);
let P = srvneed(Xc) || !w.adm ? [] : [ 'lighttpd-mod-cgi', ...((rjs(NJ) ?? {}).remote?.webdav === true ? [] : [ 'lighttpd' ]) ];
return { ...linkget(Xc, w), ...(length(P) ? { drop: P } : {}) };
}
if (act == 'log') {
if (li < 0) return err('none', 'Link non trovato', 'Link not found');
let l = Xc.link.list[li], G = [ ...(type(l.log) == 'array' ? l.log : []), ...tlog(t) ];
return { list: reverse(map(slice(G, -50), (e) => ({ t: e.t ?? 0, what: e.what ?? 'open', from: e['from'] ?? 'home', who: e.who ?? '', bytes: e.bytes ?? 0 }))) };
}
if (act == 'close' || (act == 'set' && a.out === false && a.tok == null)) {
if (!w.adm) return ADM();
for (let l in Xc.link.list) l.where = 'home';
for (let r in Xc.req) r.where = 'home';
if (!xput(Xc)) return BUSY(); srvapply(Xc, false);
return linkget(Xc, w);
}
if (act == 'probe') {
if (!w.adm) return ADM();
let C = ctxof(Xc), ni = netinfo(Xc, C.T), P = rjs(X + '/probe.json'), n = C.n;
if (!ni.open) return err('closed', 'Porta chiusa: serve un link da internet valido', 'Port closed: a valid internet link is needed');
if (!P || (!P.ok && n >= (P.until ?? 0)) || (P.ok && n - (P.ok_t ?? 0) > 60)) {
P = { t: n, until: n + 180, ok: false, tok: token() };
wjs(X + '/probe.json', P);
detach('sh ' + q(SH) + ' probe ' + q(neturl(C, '/p/' + P.tok)));
}
return { ok: P.ok === true, t: P.ok ? P.ok_t : P.t, armed: !P.ok && n < P.until, until: P.until, from: P['from'] ?? '', url: neturl(C, '/p/' + P.tok) };
}
if (act == 'set') {
let C = ctxof(Xc), force = false;
if (a.tok != null) {
if (li < 0) return err('none', 'Link non trovato', 'Link not found');
if (a.max != null) hitsfold(Xc);
let l = { ...Xc.link.list[li] }, e = whereset(l, a.where, C);
if (e) return e;
if (a.hours != null) {
if (l.kind == 'pub' && index(PHOURS, a.hours) < 0) return err('hours', 'Scade dopo 1 o 7 giorni', 'Expires after 1 or 7 days');
if (index(LHOURS, a.hours) < 0) return err('hours', 'Scade dopo 1, 7 o 30 giorni', 'Expires after 1, 7 or 30 days');
l.exp = C.n + a.hours * 3600;
}
if (a.mode != null) { if (l.kind != 'pub' || index(PMODES, a.mode) < 0) return err('mode', 'Scegli Solo Prendere o Anche Mettere File', 'Choose Only Take or Also Add Files'); l.mode = a.mode; }
if (a.max != null) { if (index(LMAXS, a.max) < 0) return err('max', 'Accessi consentiti: illimitati, 1, 5 o 10', 'Allowed accesses: unlimited, 1, 5 or 10'); l.max = a.max; }
if (a.notify != null) { if (index(NOTI, a.notify) < 0) return err('notify', 'Avvisami non valido', 'Invalid notify choice'); l.notify = a.notify; }
if (a.pass != null) {
if (!length('' + a.pass)) l.pw = null;
else { let pw = pwmake(a.pass); if (pw.error) return pw; l.pw = pw; }
}
if (a.max != null) { l.hits = 0; accdel(t); }
Xc.link.list[li] = l;
if (!xput(Xc)) return BUSY(); srvapply(Xc, false);
return { ...linkget(Xc, w), link: linkout(Xc, l, ctxof(Xc)) };
}
if (!w.adm) return ADM();
if (a.port != null) {
let p = a.port;
if (type(p) != 'int' || portbad(p) || p == (Xc.link.port ?? PORT)) return err('port', 'Porta non valida: da 1024 a 65535, non usata dal router', 'Invalid port: 1024 to 65535, not used by the router');
if (p != C.np && listening()[p]) return err('port', 'Porta già usata da un altro servizio', 'Port already used by another service');
force = p != C.np; Xc.link.nport = p;
}
if (type(a.on) == 'bool') Xc.link.on = a.on;
if (a.out === true) return err('out', 'Da internet si sceglie per ogni link (Dove Si Apre)', 'The internet is chosen for each link (Where It Opens)');
if (!xput(Xc)) return BUSY(); srvapply(Xc, force);
return linkget(Xc, w);
}
if (act != 'add') return err('act', 'Azione sconosciuta', 'Unknown action');
let P = need('web'); if (length(P)) return pkgerr(P);
if (!nason()) return err('off', 'Il NAS è spento', 'The NAS is off');
if (length(Xc.link.list) >= LMAX) return err('max', 'Al massimo ' + LMAX + ' link', 'At most ' + LMAX + ' links');
if (a.acc != null) {
let CL = cladd(a, w);
if (CL.error) return CL;
let C = ctxof(Xc), h = a.hours ?? 168, mx = a.max ?? 0, nt = a.notify ?? 'first', pw = null;
if (index(LHOURS, h) < 0) return err('hours', 'Scade dopo 1, 7 o 30 giorni', 'Expires after 1, 7 or 30 days');
if (index(LMAXS, mx) < 0) return err('max', 'Accessi consentiti: illimitati, 1, 5 o 10', 'Allowed accesses: unlimited, 1, 5 or 10');
if (index(NOTI, nt) < 0) return err('notify', 'Avvisami non valido', 'Invalid notify choice');
if (a.pass != null && length('' + a.pass)) { pw = pwmake(a.pass); if (pw.error) return pw; }
let l = { tok: token(), disk: null, cl: CL.cl, path: CL.path, name: CL.name, dir: CL.dir, t: C.n, exp: C.n + h * 3600, pw: pw, hits: 0,
where: 'home', max: mx, notify: nt, own: w.own, ...(CL.paths ? { paths: CL.paths } : {}), ...(CL.dir ? {} : { size: CL.size }) };
let e = whereset(l, a.where ?? (w.adm ? null : (netok(C) == null ? 'net' : 'home')), C);
if (e) return e;
hitsfold(Xc);
push(Xc.link.list, l);
if (!xput(Xc)) return BUSY();
let st = srvapply(Xc, false);
return { ...linkget(Xc, w), link: linkout(Xc, l, ctxof(Xc)), starting: st };
}
let D = disks(), m = maindisk(D), pub = a.pub === true, d = null;
if (!w.adm && !m) return NOMAIN();
if (pub) {
if (w.adm) return err('admin', 'L\'Amministratore non ha una Cartella Pubblica', 'The Administrator has no Public Folder');
if (!m) return NOMAIN();
if (a.paths != null || a.path != null) return err('path', 'L\'invito apre solo la Cartella Pubblica', 'The invitation opens only the Public Folder');
if (index(PMODES, a.mode ?? 'r') < 0) return err('mode', 'Scegli Solo Prendere o Anche Mettere File', 'Choose Only Take or Also Add Files');
if (index(PHOURS, a.hours ?? 168) < 0) return err('hours', 'Scade dopo 1 o 7 giorni', 'Expires after 1 or 7 days');
let pp = UCFG.udir(w.own, 'pub');
if (pp == null) return WHO();
if ((a.mode ?? 'r') == 'rw' && m.ro) return dsk(D, m.id, true);
if ((a.mode ?? 'r') == 'rw' && qfull(w)) return QFULL();
d = m; a.path = '/' + pp;
}
else d = w.adm ? dsk(D, a.disk, false) : m;
if (d.error) return d;
let PS = type(a.paths) == 'array' && length(a.paths) ? a.paths : [ a.path ], items = [], names = {};
if (length(PS) > 50) return err('path', 'Al massimo 50 elementi in un link', 'At most 50 items in a link');
for (let x in PS) {
let p = absp(d, x), s = p ? lstat(p.abs) : null;
if (!p) return err('path', 'Percorso non valido', 'Invalid path');
if (!scopeok(w, d, m, p.rel, true)) return PRIV();
if (!s || (s.type != 'file' && s.type != 'directory')) return err('path', 'File o cartella non trovati', 'File or folder not found');
if (length(PS) > 1 && (!length(p.parts) || names[p.name])) return err('path', 'Elementi con lo stesso nome', 'Items with the same name');
names[p.name] = 1;
push(items, { p: p, s: s });
}
let C = ctxof(Xc), h = a.hours ?? 168;
if (index(LHOURS, h) < 0) return err('hours', 'Scade dopo 1, 7 o 30 giorni', 'Expires after 1, 7 or 30 days');
let mx = a.max ?? 0, nt = a.notify ?? 'first';
if (index(LMAXS, mx) < 0) return err('max', 'Accessi consentiti: illimitati, 1, 5 o 10', 'Allowed accesses: unlimited, 1, 5 or 10');
if (index(NOTI, nt) < 0) return err('notify', 'Avvisami non valido', 'Invalid notify choice');
let pw = null;
if (a.pass != null && length('' + a.pass)) { pw = pwmake(a.pass); if (pw.error) return pw; }
let i0 = items[0], l = { tok: token(), disk: d.id, path: i0.p.rel, name: i0.p.name, dir: i0.s.type == 'directory', t: C.n, exp: C.n + h * 3600,
pw: pw, hits: 0, where: 'home', max: mx, notify: nt, ...(i0.s.type == 'file' ? { size: i0.s.size } : {}), own: w.own,
...(pub ? { kind: 'pub', mode: a.mode ?? 'r' } : {}) };
if (pub && i0.s.type != 'directory') return err('path', 'Cartella Pubblica non trovata', 'Public Folder not found');
let e = whereset(l, a.where ?? (w.adm ? null : (netok(C) == null ? 'net' : 'home')), C);
if (e) return e;
if (length(items) > 1) {
let par = replace(i0.p.rel, /\/[^\/]*$/, ''), same = length(filter(items, (x) => replace(x.p.rel, /\/[^\/]*$/, '') == par)) == length(items);
l.paths = map(items, (x) => x.p.rel); l.dir = true; l.path = length(par) ? par : '/'; delete l.size;
l.name = same && length(par) ? bname(par) : i0.p.name + ' +' + (length(items) - 1);
}
hitsfold(Xc);
push(Xc.link.list, l);
if (!xput(Xc)) return BUSY();
let st = srvapply(Xc, false);
return { ...linkget(Xc, w), link: linkout(Xc, l, ctxof(Xc)), starting: st };
}
},
nas_request: {
args: { act: 'x', id: 'x', where: 'x', open: 'x', gb: 0, hours: 0, pass: 'x', on: true, name: 'x', acc: 'x', pub: true, as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let a = req.args ?? {}, act = a.act ?? 'get', w = whoof(req);
if (w.error) return w;
let Xc = xget(), id = '' + (a.id ?? ''), ri = -1;
if (act == 'get') return reqget(Xc, w);
let pv = false;
for (let k = 0; k < length(Xc.req); k++) if (Xc.req[k].id == id) { if (admsee(w, Xc.req[k])) ri = k; else if (w.adm) pv = true; }
if (pv) return err('private', 'Richiesta di un\'altra persona', 'Another person\'s request');
let to = a.where == 'cloud' || a.where == 'disk' ? a.where : null, op = a.open ?? (to ? null : a.where);
if (a.where != null && to == null && a.where != 'home' && a.where != 'net') return err('where', 'Dove: disco o cloud', 'Where: drive or cloud');
let CR = null;
if (act == 'add' && to == 'cloud') {
let CM = modof(getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc'), h = a.hours ?? 168;
if (type(CM?.cloud?.call) != 'function') return err('svc', 'Cloud non disponibile', 'Cloud not available');
if (index(a.pub === true ? PHOURS : RHOURS, h) < 0) return a.pub === true ? err('hours', 'Scade dopo 1 o 7 giorni', 'Expires after 1 or 7 days') : err('hours', 'Scade dopo 1, 3 o 7 giorni', 'Expires after 1, 3 or 7 days');
let A = type(CM._rc?.acct) == 'function' ? CM._rc.acct('' + (a.acc ?? '')) : null, S = null;
if (A && type(CM._rc?.svcs) == 'function') for (let s in CM._rc.svcs()) if (s.id == A.svc) S = s;
if (a.pub === true || (S && S.caps?.upreq !== true)) {
if (w.adm) return err('admin', 'L\'Amministratore non ha File Ricevuti: le richieste sono delle persone', 'The Administrator has no Received Files: requests belong to people');
if (!A || (A.user != 'admin' && A.user != w.own)) return err('none', 'Account non trovato', 'Account not found');
if (A.state == 'old' || A.state == 'relink' || A.state == 'new' || A.state == 'busy') return err(A.state == 'relink' ? 'relink' : 'busy', 'Cloud da ricollegare o non pronto', 'Cloud to reconnect or not ready');
if (a.pub === true && A.user != 'admin') return err('path', 'La Cartella Pubblica è solo nel cloud comune', 'The Public Folder is only in the shared cloud');
CR = { id: A.id, svc: A.svc, ...(a.pub === true ? { pub: true } : {}) };
}
}
if (act == 'add' && to == 'cloud' && CR == null) {
let CM = modof(getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc'), h = a.hours ?? 168;
let ca = { act: 'upreq', id: '' + (a.acc ?? ''), expire: h / 24, ...(a.name != null ? { name: '' + a.name } : {}) };
for (let k in [ 'ubus_rpc_session', 'as' ]) if (a[k] != null) ca[k] = a[k];
let r = CM.cloud.call({ args: ca, info: req.info });
return type(r) == 'object' ? { ...r, to: 'cloud' } : SVC();
}
if (act == 'del') {
if (ri < 0) return err('none', 'Richiesta non trovata', 'Request not found');
hitsfold(Xc);
let tk = Xc.req[ri].tok;
splice(Xc.req, ri, 1); unlink(X + '/req/' + tk + '.log');
if (!xput(Xc)) return BUSY(); srvapply(Xc, false);
return reqget(Xc, w);	/* i file arrivati restano sul disco */
}
let C = ctxof(Xc), old = ri >= 0 ? Xc.req[ri] : null;
if (act == 'set' && !old) return err('none', 'Richiesta non trovata', 'Request not found');
if (act != 'set' && act != 'add') return err('act', 'Azione sconosciuta', 'Unknown action');
let r = old ? { ...old } : null;
if (act == 'add') {
if (w.adm) return err('admin', 'L\'Amministratore non ha File Ricevuti: le richieste sono delle persone', 'The Administrator has no Received Files: requests belong to people');
let P = need('web'); if (length(P)) return pkgerr(P);
if (!nason()) return err('off', 'Il NAS è spento', 'The NAS is off');
if (length(Xc.req) >= RMAX) return err('max', 'Al massimo ' + RMAX + ' richieste', 'At most ' + RMAX + ' requests');
if (CR) {
let nm = trim('' + (a.name ?? '')) || (CR.pub ? 'Cartella Pubblica' : sprintf('Richiesta %d', C.n % 100000));
if (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/) || substr(nm, 0, 1) == '.') return err('name', 'Nome non valido', 'Invalid name');
if (UCFG.udir(w.own, CR.pub ? 'pub' : 'recv') == null) return WHO();
r = { id: 'r' + rid(), tok: token(), name: nm, disk: null, path: null, where: 'home', gb: 5, exp: C.n + 168 * 3600, pw: null, on: true, t: C.n,
used: 0, files: 0, refused: 0, last: 0, arr: [], own: w.own, cl: CR };
}
}
if (act == 'add' && !CR) {
let D = disks(), m = maindisk(D);
if (!m) return NOMAIN();
if (qfull(w)) return QFULL();
let d = dsk(D, m.id, true);
if (d.error) return d;
let nm = trim('' + (a.name ?? '')) || sprintf('Richiesta %d', C.n % 100000);
if (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/) || substr(nm, 0, 1) == '.') return err('name', 'Nome non valido', 'Invalid name');
let rp = UCFG.udir(w.own, 'recv');
if (rp == null) return WHO();
let p = UCFG.umkdir(d.mnt, rp) ? absp(d, rp) : null;
if (!p || stat(p.abs)?.type != 'directory') return err('path', 'La cartella non esiste', 'The folder does not exist');
r = { id: 'r' + rid(), tok: token(), name: nm, disk: d.id, path: p.rel, where: 'home', gb: 5, exp: C.n + 168 * 3600, pw: null, on: true, t: C.n,
used: 0, files: 0, refused: 0, last: 0, arr: [], own: w.own };
}
let e = whereset(r, op ?? (act == 'add' && !w.adm ? (netok(C) == null ? 'net' : 'home') : null), C);
if (e) return e;
if (a.gb != null) { if (index(RGB, a.gb) < 0) return err('gb', 'Spazio massimo: 1, 5 o 20 GB', 'Maximum space: 1, 5 or 20 GB'); r.gb = a.gb; }
if (a.hours != null) {
if (r.cl?.pub === true && index(PHOURS, a.hours) < 0) return err('hours', 'Scade dopo 1 o 7 giorni', 'Expires after 1 or 7 days');
if (index(RHOURS, a.hours) < 0) return err('hours', 'Scade dopo 1, 3 o 7 giorni', 'Expires after 1, 3 or 7 days');
r.exp = C.n + a.hours * 3600;
}
if (a.name != null) {
let nm = trim('' + a.name);
if (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/)) return err('name', 'Nome non valido', 'Invalid name');
r.name = nm;
}
if (type(a.on) == 'bool') r.on = a.on;
if (a.pass != null) {
if (!length('' + a.pass)) r.pw = null;
else { let pw = pwmake(a.pass); if (pw.error) return pw; r.pw = pw; }
}
if (old) Xc.req[ri] = r; else push(Xc.req, r);
if (!xput(Xc)) return BUSY();
let st = srvapply(Xc, false);
return { ...reqget(Xc, w), item: reqout(Xc, r, ctxof(Xc)), starting: st };
}
},
nas_xfer: {
args: { act: 'x', disk: 'x', path: 'x', name: 'x', size: 0, mtime: 0, tok: 'x', as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let a = req.args ?? {}, act = a.act ?? '', w = whoof(req);
if (w.error) return w;
let Xc = xget();
if (act == 'stop') {
let t = '' + (a.tok ?? ''), U = ups(true), S = streams(false);
if ((U[t] && !mine(w, U[t])) || (S[t] && !mine(w, S[t]))) return err('none', 'Token non trovato', 'Token not found');
if (U[t]) { let u = U[t], s = lstat(u.part); if (s?.type == 'file') unlink(u.part); delete U[t]; wjs(X + '/up.json', U); }
else if (S[t]) unlink(ST + '/' + t + '.json');
else return err('none', 'Token non trovato', 'Token not found');
if (!srvneed(Xc) && running()) srvapply(Xc, false);
return { ok: true };
}
if (act != 'up' && act != 'down') return err('act', 'Azione sconosciuta', 'Unknown action');
let P = need('web'); if (length(P)) return pkgerr(P);
if (!nason()) return err('off', 'Il NAS è spento', 'The NAS is off');
let D = disks(), Zs = zones(), port = Xc.link.port ?? PORT, base = length(Zs.ip) ? 'http://' + Zs.ip + ':' + port : '';
let m = maindisk(D);
if (act == 'down') {
let d = wdisk(w, D, a.disk, false);
if (d.error) return d;
let p = absp(d, a.path), s = p ? lstat(p.abs) : null;
if (p && !scopeok(w, d, m, p.rel)) return PRIV();
if (!p || !length(p.parts) || s?.type != 'file') return err('path', 'File non trovato', 'File not found');
let n = time(), tk = streamadd({ p: p.abs, t: n, a: n, dl: true, own: w.own });
let st = srvapply(Xc, false), u = '/t/' + tk + '/' + urlenc(p.name) + '?dl=1';
return { tok: tk, url: length(base) ? base + u : '', path: '/cgi-bin/wf-nasx' + u, name: p.name, size: s.size, mime: mimeof(p.name), starting: st };
}
let d = wdisk(w, D, a.disk, true);
if (d.error) return d;
let p = absp(d, a.path);
if (p && !scopeok(w, d, m, p.rel)) return PRIV();
if (qfull(w)) return QFULL();
if (!p || stat(p.abs)?.type != 'directory') return err('path', 'Cartella non valida', 'Invalid folder');
let n = '' + (a.name ?? ''), sz = a.size, mt = a.mtime ?? 0;
if (badname(n) || substr(n, 0, 1) == '.' || index(n, '\\') >= 0) return err('name', 'Nome del file non valido', 'Invalid file name');
if (type(sz) != 'int' || sz < 0 || type(mt) != 'int' || mt < 0) return err('val', 'Dati del file non validi', 'Invalid file data');
if (match(d.fs, /^(vfat|msdos)$/) && sz > 4294967295) return err('fat', 'Il disco è FAT32: un file al massimo 4 GB', 'The drive is FAT32: one file at most 4 GB');
let ut = m && d.id == m.id && type(UCFG.uup) == 'function' ? UCFG.uup(w.own, p.rel, n) : null;
if (ut != null && UCFG.umkdir(d.mnt, ut)) p = absp(d, ut) ?? p;
let part = p.abs + '/.' + hk(n + '|' + sz + '|' + mt) + '.wfpart', ps = lstat(part), off = 0;
if (ps && ps.type != 'file') return err('path', 'Percorso non valido', 'Invalid path');
if (ps) { if (ps.size <= sz) off = ps.size; else { unlink(part); off = 0; } }
let fr = freeb(d.mnt);
if (sz - off + 16777216 > fr) return err('space', 'Non c\'è abbastanza spazio sul disco', 'Not enough space on the drive', { need: sz - off, free: fr });
let U = ups(true), tk = token(), K = sort(keys(U), (x, y) => (U[x].t ?? 0) - (U[y].t ?? 0));
while (length(K) >= 50) delete U[shift(K)];
U[tk] = { dir: p.abs, rel: p.rel, name: n, size: sz, mtime: mt, part: part, t: time(), disk: d.id, own: w.own };
mkdirp(X + '/up');
wjs(X + '/up.json', U);
partadd(p.abs);
let st = srvapply(Xc, false);
return { tok: tk, url: length(base) ? base + '/u/' + tk : '', path: '/cgi-bin/wf-nasx/u/' + tk, off: off, chunk: XCH, starting: st };
}
},
nas_remote: {
args: { act: 'x', on: true, webdav: true, smbvpn: true, sftp: true, app: true, secs: 0 },
call: function(req) {
begin();
let a = req.args ?? {}, w = whoof(req);
if (w.error) return w;
if (!w.adm) return ADM();
allowclean();
let V = modof(NASVCUC), fn = V?._remote ?? V?.nas_remote;
if (type(fn?.call) != 'function') return err('svc', 'Servizi del NAS non disponibili', 'NAS services not available');
let PR = [ 'webdav', 'smbvpn', 'sftp' ], set = filter(PR, (k) => type(a[k]) == 'bool');
let act = a.act ?? ((length(set) || type(a.on) == 'bool' || type(a.app) == 'bool') ? 'set' : 'get');
let N = rjs(NJ) ?? {}, W = cfg('network');
let out = (r) => {
let M = rjs(NJ) ?? {}, rm = M.remote ?? {}, Xc = xget(), C = ctxof(Xc), ni = netinfo(Xc, C.T);
return { ...r, on: rm.on === false ? false : (rm.webdav === true || rm.smbvpn === true || rm.sftp === true), vpns: vpnlist(W), out_now: outnow(W),
app: { on: rm.app === true, open: ni.app && ni.open && running(), port: C.np, ddns: C.T.ddns, can: netok(C) == null, people: people(M) } };
};
if (act == 'get') return out(fn.call({ args: { act: 'get' } }));
if (act == 'confirm' || act == 'back') { let r = fn.call({ args: { act: act } }); srvapply(xget(), false); return out(r); }
if (act != 'set') return err('act', 'Azione sconosciuta', 'Unknown action');
let r = null, rm = N.remote ?? {};
if (type(a.app) == 'bool') {
if (a.app) {
let e = netok(ctxof(xget()));
if (e) return e;
let P = need('web'); if (length(P)) return pkgerr(P);
}
if (!njput((M) => { M.remote = { ...(type(M.remote) == 'object' ? M.remote : {}), app: a.app }; })) return BUSY();
}
if (type(a.on) == 'bool') {
let kp = type(rm.keep) == 'object' && length(filter(PR, (k) => rm.keep[k] === true)) ? rm.keep : { smbvpn: true };
let keep = a.on ? kp : null, args = { act: 'set', secs: a.secs ?? 60 };
for (let k in PR) args[k] = a.on ? keep[k] === true : false;
let was = {}; for (let k in PR) was[k] = rm[k] === true;
r = fn.call({ args: args });
if (r?.error) return r;
if (!njput((M) => {
M.remote = { ...(type(M.remote) == 'object' ? M.remote : {}), on: a.on };
if (a.on) delete M.remote.keep; else M.remote.keep = was;
})) return BUSY();
if (!a.on) delete r.drop;
}
else if (length(set)) {
let args = { act: 'set', secs: a.secs ?? 60 };
for (let k in set) args[k] = a[k];
r = fn.call({ args: args });
if (r?.error) return r;
if (!njput((M) => {
let x = type(M.remote) == 'object' ? M.remote : {};
M.remote = { ...x, on: x.webdav === true || x.smbvpn === true || x.sftp === true };
delete M.remote.keep;
})) return BUSY();
}
else r = fn.call({ args: { act: 'get' } });
srvapply(xget(), false);
return out(r);
}
},
nas_stream: {
args: { disk: 'x', path: 'x', act: 'x', tok: 'x', as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let a = req.args ?? {}, w = whoof(req);
if (w.error) return w;
let Xc = xget();
if (a.act == 'stop') {
let S = streams(false), t = '' + (a.tok ?? '');
if (!S[t] || !mine(w, S[t])) return err('none', 'Token non trovato', 'Token not found');
unlink(ST + '/' + t + '.json');
if (!srvneed(Xc) && running()) srvapply(Xc, false);
return { ok: true };
}
let P = need('web'); if (length(P)) return pkgerr(P);
if (!nason()) return err('off', 'Il NAS è spento', 'The NAS is off');
let D = disks(), d = wdisk(w, D, a.disk, false);
if (d.error) return d;
let p = absp(d, a.path);
if (!p || !length(p.parts)) return err('path', 'Percorso non valido', 'Invalid path');
if (!scopeok(w, d, maindisk(D), p.rel)) return PRIV();
let s = lstat(p.abs);
if (!s || s.type != 'file') return err('path', 'File non trovato', 'File not found');
let n = time(), tk = streamadd({ p: p.abs, t: n, a: n, own: w.own });
let st = srvapply(Xc, false), Zs = zones(), port = Xc.link.port ?? PORT, u = '/t/' + tk + '/' + urlenc(p.name);
return { tok: tk, path: '/cgi-bin/wf-nasx' + u, port: port, url: length(Zs.ip) ? 'http://' + Zs.ip + ':' + port + u : '', mime: mimeof(p.name), size: s.size,
idle: SIDLE, max: SMAX, starting: st };
}
},
relay: function(b, ip, zone, remote) {
begin();
if (!length(getenv('GATEWAY_INTERFACE') ?? '') || trim(readfile('/proc/self/comm') ?? '') == 'rpcd') return SVC();
b = type(b) == 'object' ? b : {};
ip = lc(replace('' + (ip ?? ''), /^::ffff:/, ''));
let act = '' + (b.act ?? ''), n = time();
if (zone == 'guest') return err('lan_only', 'Dal Wi-Fi ospiti il NAS non si apre', 'The NAS does not open from the guest Wi-Fi');
if (index([ 'lan', 'vpn', 'net' ], zone) < 0 || (zone == 'net' && (remote !== true || !appout())))
return err('lan_only', 'Solo da casa, dalla VPN o dall\'Accesso Remoto', 'Home, VPN or Remote Access only');
let NU = (act == 'login' || act == 'logout' || (act == 'call' && b.object == 'session' && b.method == 'destroy')) ? modof(NASUUC) : null;
if (act == 'login' || act == 'recover') {
let B = nbadget(ip, n), r = null;
if (B.c >= NBAD) return LOCKED(B.t + NLOCK);
if (act == 'login') {
if (type(NU?.login) != 'function') return SVC();
let a = { user: '' + (b.user ?? ''), pass: '' + (b.pass ?? ''), ip: ip };
if (type(b.dev) == 'string' && length(b.dev)) a.dev = b.dev;
if (zone == 'net') a.via = 'remote';
if (b.pc === true) a.pc = true;
try { r = NU.login(a, zone); } catch (e) { r = null; }
}
else {
let u0 = null;
try { u0 = require('ubus').connect(); } catch (e) { u0 = null; }
let a = { act: 'recover', user: '' + (b.user ?? ''), code: '' + (b.code ?? ''), 'new': '' + (b['new'] ?? ''), ip: ip };
if (zone == 'net') a.via = 'remote';
try { r = u0?.call('wrtfreedom', 'nas_me', a); } catch (e) { r = null; }
}
if (type(r) != 'object') return SVC();
if (r.code == (act == 'login' ? 'login' : 'code')) {
mkdirp(X + '/nbad');
let t = nbadf(ip) + '.t' + rid();
writefile(t, (B.c + 1) + ' ' + n + '\n'); rename(t, nbadf(ip));
if (B.c + 1 >= NBAD) return LOCKED(n + NLOCK);
}
else if (act == 'login' ? type(r.sid) == 'string' : r.ok === true) unlink(nbadf(ip));
return r;
}
let sid = '' + (b.sid ?? ''), S = rjs(SESSJ) ?? {}, u = S[sid]?.u, x = (rjs(NJ) ?? {}).users?.[u];
if (!match(sid, /^[0-9a-f]{32}$/) || type(u) != 'string' || type(x) != 'object' || x.cam === true) return WHO();
let ub = null;
try { ub = require('ubus').connect(); } catch (e) { ub = null; }
let clean = () => { if (type(NU?.sess_clean) == 'function') { try { NU.sess_clean(); } catch (e) {} } };
if (act == 'logout') { if (ub) ub.call('session', 'destroy', { ubus_rpc_session: sid }); clean(); return { ok: true }; }
if (x.blocked === true) return err('blocked', 'Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator');
if (act != 'call') return err('act', 'Azione sconosciuta', 'Unknown action');
let o = '' + (b.object ?? ''), m = '' + (b.method ?? '');
if (index(nasgrp()[o] ?? [], m) < 0) return err('denied', 'Azione non permessa', 'Action not allowed');
if (!ub) return SVC();
if (ub.call('session', 'access', { ubus_rpc_session: sid, scope: 'ubus', object: o, 'function': m })?.access !== true) return WHO();
let A = type(b.params) == 'object' ? { ...b.params } : {};
delete A.as;
A.ubus_rpc_session = sid;
let r = ub.call(o, m, A);
if (o == 'session' && m == 'destroy') clean();
return type(r) == 'object' ? r : err('busy', 'Router occupato: riprova', 'Router busy: try again');
},
invite_ready: function() {
begin();
let P = need('web');
if (length(P)) return pkgerr(P);
if (!nason()) return err('off', 'Il NAS è spento', 'The NAS is off');
if (!invites()) return err('none', 'Invito non trovato', 'Invitation not found');
let Xc = xget(), st = srvapply(Xc, false), Zs = zones();
return { ok: true, starting: st, base: length(Zs.ip) ? 'http://' + Zs.ip + ':' + (Xc.link.port ?? PORT) : '' };
},
outok: function(own, p) {
begin();
if (type(own) != 'string' || own == 'admin' || type(p) != 'string' || !appout()) return false;
let x = (rjs(NJ) ?? {}).users?.[own];
if (type(x) != 'object' || x.cam === true || x.blocked === true) return false;
let m = maindisk(disks());
if (!m || type(m.mnt) != 'string' || substr(p, 0, length(m.mnt) + 1) != m.mnt + '/') return false;
let P = split(substr(p, length(m.mnt) + 1), '/'), c = m.mnt;
for (let s in P) {
if (badname(s) || substr(s, 0, 1) == '.') return false;
c += '/' + s;
let st = lstat(c);
if (st?.type == 'link') return false;
}
return scopeok({ own: own, adm: false }, m, m, '/' + join('/', P));
}
};

return M;
