#!/bin/sh
W=/usr/share/wrtfreedom
P=/tmp/wf-pres; PL=/tmp/wf-presl; PLMAX=2000; pl=0; first=0; [ -d $P ] || { mkdir -p $P; first=1; }
GONE=75   # non visto da 75 s = il router lo cerca (probe); non risponde = uscito (5/11 sera; 4/11 30 s, prima 3 minuti)
OUT=87	# 5/11 sera: uscito solo dopo almeno 87 s di assenza (anche staccato dal Wi-Fi: chi si stacca da solo torna entro 76 s)
DL=87	# 5/11: silenzio da 87 s = uscito anche senza l'esito della prova e per i sensori (primo giro oltre DL: < 97 s)
PR=/tmp/wf-probe PK=/tmp/wf-pingok PQ=' ' IM=' ' DS=' ' WA=' '	# esiti, chi ha risposto almeno una volta a un ping (5/11), prove in corso, IP dei dispositivi, Wi-Fi staccati, inactive time (5/11)
PM=; PT=   # Persone: dispositivi di ognuna e ora dell'ultimo avviso (punto 14)
c=0
VT=0; BC=   # banda Wi-Fi di ogni interfaccia (" phy0-ap0=Wi-Fi_5_GHz …"), riletta con la configurazione e ogni 10 minuti
NA=' ' BX=' '
any() { for f; do [ -e "$f" ] && return 0; done; return 1; }	# almeno un file (glob senza fork)
hm() { local h=${1%%:*} m=${1#*:}; echo $(( (${h#0}+0) * 60 + ${m#0}+0 )); }	# HH:MM → minuti
nocol() { NC=; local x=$1; while [ -n "$x" ]; do NC=$NC${x%%:*}; case "$x" in *:*) x=${x#*:} ;; *) x= ;; esac; done; }	# MAC senza «:» in NC (senza fork)
tgqgo() {
local f l n
[ "$QU" = 1 ] || return 0
nd=$(date '+%H %M'); set -- $nd; n=$(( ${1#0} * 60 + ${2#0} ))
if [ $QF -lt $QT ]; then { [ $n -ge $QF ] && [ $n -lt $QT ]; } || return 0
else { [ $n -ge $QF ] || [ $n -lt $QT ]; } || return 0; fi
for f in /tmp/wf-tgq/[0-9]*; do
[ -f "$f" ] || continue
while IFS= read -r l; do case "$l" in
'#to:'*) return 0 ;;
'#c:'*) case " $QP " in *" ${l#??:} "*) return 0 ;; esac; [ "${l#??:}" = 'nas!' ] && case " $QP " in *" nas "*) return 0 ;; esac ;;	# 3.11: «nas» fa passare anche «nas!»
'#kb:'*|'#re:'*) ;;
*) break ;;
esac; done < "$f"
done
return 1
}
DM=/tmp/wf-ddnswd DRE=/tmp/wf-cron.ddnsre
ddnsip() {
local f s v o
if [ "$DW" = 1 ]; then
if [ -f "$DRE" ] && read -r v < "$DRE" && [ "$(date +%s)" -ge "$v" ] 2>/dev/null; then sh $W/cron.sh ddnswd re >/dev/null 2>&1 & fi
for f in "$DR"/*.ip; do
[ -f "$f" ] || continue
s=${f##*/}; s=${s%.ip}; v=; o=
read -r v < "$f"; [ -n "$v" ] || continue
[ -f "$DM/$s" ] && read -r o < "$DM/$s"
[ "$v" = "$o" ] && continue
[ -d "$DM" ] || mkdir -p "$DM"
echo "$v" > "$DM/$s"
[ -n "$o" ] || continue
echo "$s $v" > "$DM/.chg"; sh $W/cron.sh ddnswd chg "$s" >/dev/null 2>&1 &
done
elif [ -d "$DM" ]; then
rm -rf "$DM"; sh $W/cron.sh ddnswd clr >/dev/null 2>&1 &
fi
if [ -z "$DW" ] && { [ ! -f $DM.d5 ] || [ /etc/config/ddns -nt $DM.d5 ]; }; then : > $DM.d5; sh $W/cron.sh ddnswd d5 >/dev/null 2>&1 & fi
}
RT=10 FULL=60 EF=/tmp/wf-devev.fifo EP=/tmp/wf-devev.pid TF=/tmp/wf-notify.t RTF=/proc/net/route
CM=/tmp/wf-notify.cm CT=/tmp/wf-notify.ct	# date della configurazione letta e della lettura (2.91)
UD=/tmp/.uci/wrtfreedom CU=/tmp/wf-notify.cu UX=	# 13/11: modifiche di uci non salvate e data di quelle lette
rm -f $CM $CT $CU
WE=''; NE=''; ES=''; FT=''; FDT=''; FD=" "; WI=" "; NB=" "; PON=" "
H='[0-9A-Fa-f]'
lc() { local x=$1 ch; LC=; while [ -n "$x" ]; do ch=${x%"${x#?}"}; x=${x#?}
case $ch in A) ch=a;; B) ch=b;; C) ch=c;; D) ch=d;; E) ch=e;; F) ch=f;; esac; LC=$LC$ch; done; }
col() { local x=$1; CO=; while [ -n "$x" ]; do CO=$CO${CO:+:}${x%"${x#??}"}; x=${x#??}; done; }
evstop() { [ -n "$WE$NE" ] && kill $WE $NE 2>/dev/null; WE=''; NE=''; }
evstart() {
evstop; ES=$now
[ -f $EP ] && { read -r a b < $EP; for x in $a $b; do e_=; [ -r /proc/$x/cmdline ] && read -r e_ < /proc/$x/cmdline; case "$e_" in iwevent|ip-4monitorneigh) kill "$x" 2>/dev/null ;; esac; done; }
[ $FF = 1 ] || return 0
command -v iw >/dev/null 2>&1 && { iw event 3>&- >$EF 2>/dev/null & WE=$!; }
ip -4 monitor neigh 3>&- >$EF 2>/dev/null & NE=$!
echo "$WE $NE" > $EP
}
wparse() {
local m x t o rt=$now
MH=$now
while read -r m x; do case "$m" in
@) rt=$x ;;
$H$H:$H$H:$H$H:$H$H:$H$H:$H$H) lc "$m"; WI="$WI$LC|$1 "
t=0; case "$x" in *" ms ago"*) t=${x%%" ms ago"*}; t=${t##* }; case "$t" in ''|*[!0-9]*) t=0 ;; esac ;; esac
t=$((rt - t / 1000)); [ $t -lt $MH ] && MH=$t
case "$WA" in *" $LC="*) o=${WA#*" $LC="}; o=${o%% *}; [ $t -gt "$o" ] && WA="${WA%%" $LC="*} ${WA#*" $LC="*" "}$LC=$t " ;; *) WA="$WA$LC=$t " ;; esac ;;
esac; done < "$2"
}
wscan() {
local f=$TF.$1 w=$WI v=$WA
if [ "$2" != 1 ] && [ -f "$f" ]; then
wparse "$1" "$f"
[ $((now - MH)) -lt $GONE ] && return 0
WI=$w; WA=$v
fi
{ echo "@ $now"; iwinfo "$1" assoclist 2>/dev/null; } > "$f"
wparse "$1" "$f"
}
nbl() {
local dl=0 a dv mc='' st x
[ "$1" = Deleted ] && { dl=1; shift; }
a=$1; [ "$2" = dev ] || return 1; dv=$3; [ "$4" = lladdr ] && mc=$5
eval "st=\${$#}"	# ultima parola: lo stato
case "$NB" in *" $a|"*) x=${NB#*" $a|"}; [ -n "$mc" ] || { mc=${x#*|}; mc=${mc%%|*}; }; NB="${NB%%" $a|"*} ${x#* }" ;; esac
[ $dl = 1 ] && return 1
case "$st" in REACHABLE|DELAY|PROBE|STALE) ;; *) return 1 ;; esac
NB="$NB$a|$dv|$mc|$st "
[ "$st" = STALE ]
}
nping() {
case "$WD" in *" $3 "*) return ;; esac
[ "$4" = lladdr ] && case "$WI" in *" $5|"*) x_=${WI#*" $5|"}; x_=${x_%% *}; case "$NA" in *" $x_ "*) ;; *) return ;; esac ;; esac
ping -c 1 -W 1 -I "$3" "$1" >/dev/null 2>&1 &
}
nscan() { NB=" "; ip -4 neigh show > $TF 2>/dev/null; while read -r l; do set -- $l; nbl "$@" && nping "$@"; done < $TF; }
fdb() {
local b q n PN
FD=" "; FDT=$now
for b in /sys/class/net/*/bridge; do b=${b%/bridge}; b=${b##*/}; PN=
for q in /sys/class/net/$b/brif/*; do [ -f "$q/port_no" ] && read n < "$q/port_no" && PN="$PN $((n))=${q##*/}"; done
FD="$FD$(brctl showmacs "$b" 2>/dev/null | awk -v pn="$PN" 'BEGIN{k=split(pn,a," ");for(i=1;i<=k;i++){split(a[i],x,"=");P[x[1]]=x[2]}} $3=="no"&&P[$1]!=""{printf "%s=%s ",tolower($2),P[$1]}')"
done
}
dsdel() { case "$DS" in *" $1 "*) DS="${DS%%" $1 "*} ${DS#*" $1 "}" ;; esac; }
imdel() { case "$IM" in *" $1="*) x_=${IM#*" $1="}; IM="${IM%%" $1="*} ${x_#* }" ;; esac; }
pqdel() { case "$PQ" in *" $1="*) x_=${PQ#*" $1="}; PQ="${PQ%%" $1="*} ${x_#* }"; rm -f $PR/$1 ;; esac; }
dsat() {
local t x s y
nocol "$1"; [ -f "$P/$NC" ] || return 0; read -r s x y < "$P/$NC"; [ "$s" = on ] || return 0
read -r t x < /proc/uptime; echo "on ${t%.*} $y" > "$P/$NC"
}
RQ=' '
rq() { case "$RQ" in *" $1 "*) ;; *) RQ="$RQ$1 " ;; esac; }
evl() {
case "$1" in
*": new station "*) set -- ${1%%" "*} ${1##*" "}; set -- "${1%:}" "$2"; dsdel "$2"; rq "$1"; case "$WI" in *" $2|$1 "*) ;; *) WI="$WI$2|$1 " ;; esac ;;
*": del station "*) set -- ${1%%" "*} ${1##*" "}; set -- "${1%:}" "$2"; rq "$1"; case "$WI" in *" $2|$1 "*) WI="${WI%%" $2|$1 "*} ${WI#*" $2|$1 "}" ;; esac
case "$DS" in *" $2 "*) ;; *) DS="$DS$2 " ;; esac; dsat "$2" ;;
*" dev "*) set -- $1; nbl "$@" && nping "$@" ;;
esac
}
nap() {
local t x l c
[ $FF = 1 ] || { sleep $RT; return; }
while :; do
read -r t x </proc/uptime; t=$((now + RT - ${t%.*}))
[ $t -gt 0 ] || break
[ $t -gt 1 ] && t=1
IFS= read -r -n 1 -t $t c <&3 && [ -n "$c" ] && IFS= read -r l <&3 && evl "$c$l"
done
}
probe() {
local m=$1 n=$2 a='' d='' r=no x e mc ip
case "$IM" in *" $m="*) x=${IM#*" $m="}; x=${x%% *}; a=${x%%|*}; d=${x#*|} ;; esac
if [ -z "$a" ]; then
x=$(uci -q get 'dhcp.@dnsmasq[0].leasefile'); x=${x:-/tmp/dhcp.leases}
[ -f "$x" ] && while read -r e mc ip x; do [ "$mc" = "$m" ] && a=$ip; done < "$x"
[ -n "$a" ] && { x=$(ip -4 route get "$a" 2>/dev/null); case "$x" in *" dev "*) d=${x#*" dev "}; d=${d%%[ 	]*} ;; esac; }
fi
if [ -n "$a" ]; then case "$WD" in *" $d "*) ;; *)
if [ -n "$d" ]; then set -- -I "$d"; else set --; fi
ping -c 1 -W 2 "$@" "$a" >/dev/null 2>&1 || ping -c 1 -W 2 "$@" "$a" >/dev/null 2>&1 && r=ok ;;
esac; fi
[ -d $PR ] || mkdir -p $PR
echo $r > $PR/$n
}
TQ=''; TK=''
tq() { case " $TQ " in *" $1 "*) ;; *) TQ="$TQ $1" ;; esac; }
memlow() {
local j='' r k v x
[ -f /tmp/wf-mem.json ] || return 1
read -r j < /tmp/wf-mem.json
case "$j" in *'"ris":'*) ;; *) return 1 ;; esac
r=${j#*\"ris\":}; r=${r# }; r=${r%%[!0-9]*}
[ -n "$r" ] || return 1
while read -r k v x; do [ "$k" = MemAvailable: ] && { [ "$v" -lt "$r" ] 2>/dev/null; return; }; done < /proc/meminfo
return 1
}
ML=''
TMAX=150; TS=0; TJ=''; TB=''; TE=/tmp/wf-tick.err
tkup() { local c_=; [ -n "$TK" ] && [ -r /proc/$TK/cmdline ] && read -r c_ < /proc/$TK/cmdline; case "$c_" in *tick.uc*) return 0 ;; esac; return 1; }
NPF=/tmp/wf-notify.pid
tkhung() {
local l c=''
[ -f /tmp/wf-tick.cur ] && read -r c < /tmp/wf-tick.cur
{ [ -f $TE ] && while IFS= read -r l; do case "$l" in "tick: "*|'') ;; *) echo "$l" ;; esac; done < $TE
echo "tick: $1 s, appeso: ${c:-?}, fermato:$TJ"; } > $TE.n && mv -f $TE.n $TE
[ -n "$TB" ] && return; TB=1
m_=$((TMAX / 60)); [ $m_ -ge 1 ] || m_=1
if [ "$LG" = en ]; then l="🛡️ Timed Tasks ¦ Stuck over $m_ min: restarted${c:+ ¦ Stuck: $c} ¦$TJ"
else l="🛡️ Lavori A Tempo ¦ Fermi oltre $m_ min: ripartiti${c:+ ¦ Fermo: $c} ¦$TJ"; fi
sh $W/event.sh cron tick_hung sys "$l" >/dev/null 2>&1 &
}
[ -p $EF ] || { rm -f $EF; mkfifo $EF 2>/dev/null; }
FF=0; [ -p $EF ] && exec 3<>$EF && FF=1
trap 'evstop; exit 0' INT TERM
mkdir -p /tmp/wf-batt; echo "$$" > $NPF
while true; do
PN=${now:-0}	# 5/11 sera: ora del giro prima (stacco dal Wi-Fi senza l'evento)
read now x </proc/uptime; now=${now%.*}
{ [ $((c % 6)) = 0 ] || [ -z "$BT" ] || { [ -z "$NT" ] && [ -f /tmp/.wf-ntp ]; }; } && { [ -f /tmp/.wf-ntp ] && NT=1; BT=$(( $(date +%s) - now )); }
echo $((now + BT)) > /tmp/wf-batt/notify
if [ ! -f /etc/config/wrtfreedom ] || { [ -e $UD ] && { [ ! -f $CU ] || [ $UD -nt $CU ] || [ $UD -ot $CU ] || [ ! $CT -nt $UD ]; }; } || { [ -n "$UX" ] && [ ! -e $UD ]; } || [ ! -f $CM ] || [ /etc/config/wrtfreedom -nt $CM ] || [ /etc/config/wrtfreedom -ot $CM ] || [ ! $CT -nt /etc/config/wrtfreedom ]; then
: > $CT; touch -r /etc/config/wrtfreedom $CM 2>/dev/null; BC=; NA=' '; BX=' '
UX=; [ -e $UD ] && { UX=1; touch -r $UD $CU 2>/dev/null; }
WM=$(uci -q get wrtfreedom.notify.mac | tr 'A-F' 'a-f')
PM=$(uci -q show wrtfreedom | awk -F= '$2 == "person" { split($1, a, "."); S[a[2]] = 1; next }
			{ split($1, a, ".") } a[3] == "mac" && (a[2] in S) { g = tolower($2); gsub(/\047/, "", g); n = split(g, b, " "); for (i = 1; i <= n; i++) if (b[i] != "") printf " %s=%s", b[i], a[2] }
			END { print " " }')
VT=0; grep -q "^config vpntun" /etc/config/wrtfreedom 2>/dev/null && VT=1	# Client VPN configurato
NS=0; [ "$(jsonfilter -q -i /etc/wrtfreedom/nas.json -e '@.on' 2>/dev/null)" = true ] && NS=1	# NAS acceso (6/11): avvisi dei dischi di nas.uc, ogni 30 s
GU=$(uci -q get wrtfreedom.guest.until)	# Ospiti A Tempo (2.48): ora di spegnimento della rete ospiti
GL=$(uci -q get wrtfreedom.guest.dl)$(uci -q get wrtfreedom.guest.ul)	# Limite Di Velocità della rete ospiti (2.48)
DF=$(uci -q get wrtfreedom.dnsfb.on)	# DNS di riserva (2.50)
LG=$(uci -q get wrtfreedom.ui.lang)	# 13/11 (A19): lingua per adgmode.sh check (WF_LANG) e per l'Evento di tkhung
VP=$(uci -q get wrtfreedom.vpnout.pause_until)	# Pausa Del Client VPN (2.52): ora della ripresa
WG=	# riletto qui sotto insieme alla configurazione
QU=$(uci -q get wrtfreedom.ev.quiet); QP=$(uci -q get wrtfreedom.ev.qpass); [ -n "$QP" ] || QP="net sys fw custode nas!"	# Ore Silenziose (2.53; custode 2.94; urgenti del NAS 3.11)
x=$(uci -q get wrtfreedom.ev.qfrom); QF=$(hm "${x:-23:00}"); x=$(uci -q get wrtfreedom.ev.qto); QT=$(hm "${x:-07:00}")
case "$QF$QT" in *[!0-9]*|'') QU=0 ;; esac; [ "$QF" = "$QT" ] && QU=0
DW=$(uci -q get wrtfreedom.ddnswd.on)	# Controllo Del Nome Di Casa (2.68): '1', '0' o assente (D5)
fi
{ [ -z "$DR" ] || [ $((c % 60)) = 0 ]; } && { DR=-; [ -x /etc/init.d/ddns ] && { DR=$(uci -q get ddns.global.ddns_rundir); DR=${DR:-/var/run/ddns}; }; }
{ [ -z "$WG" ] || [ /etc/config/network -nt /tmp/wf-wgnet ] || [ $((c % 60)) = 0 ]; } && { WG=0; grep -q "listen_port" /etc/config/network 2>/dev/null && WG=1; : > /tmp/wf-wgnet; }
[ /etc/wrtfreedom/nas.json -nt /tmp/wf-nasns ] && { NS=0; [ "$(jsonfilter -q -i /etc/wrtfreedom/nas.json -e '@.on' 2>/dev/null)" = true ] && NS=1; : > /tmp/wf-nasns; }
ON=""	# ora dall'accensione (now) letta all'inizio del giro
[ $((c % 60)) = 0 ] && { BC=; NA=' '; BX=' '; }
EW=0; [ -n "$WE" ] && kill -0 "$WE" 2>/dev/null && EW=1
EN_=0; [ -n "$NE" ] && kill -0 "$NE" 2>/dev/null && EN_=1
if [ -z "$ES" ] || { { { [ -n "$WE" ] && [ $EW = 0 ]; } || { [ -n "$NE" ] && [ $EN_ = 0 ]; }; } && [ $((now - ES)) -ge 60 ]; }; then
evstart; FT=; EW=0; EN_=0
fi
full=0; { [ -z "$FT" ] || [ $((now - FT)) -ge $FULL ]; } && { full=1; FT=$now; }
WD=" "; while read -r i d x; do [ "$d" = 00000000 ] && WD="$WD$i "; done < $RTF 2>/dev/null
PWA=$WA; WI=" "; WA=" "	# PWA: assoclist del giro prima (5/11 sera)
for p in /sys/class/net/*; do
i=${p##*/}; [ -d "$p/phy80211" ] || continue
case "$BC" in
*" $i="*) ;;
*) case "$BX" in *" $i="*) x=${BX#*" $i="}; x=${x%% *}; [ $((now - x)) -lt 60 ] && { case "$NA" in *" $i "*) ;; *) NA="$NA$i " ;; esac; continue; }; BX="${BX%%" $i="*} ${BX#*" $i="*" "}" ;; esac
x=$(iwinfo "$i" info 2>/dev/null | awk '{ for (k = 1; k < NF; k++) { if ($k == "Mode:" && m == "") m = $(k + 1); if ($k == "Channel:" && c == "") { c = $(k + 1); g = $(k + 2); sub(/^\(/, "", g); g = g + 0 } } } END { print m "|" c "|" (g >= 5.925 ? 6 : g >= 4.9 ? 5 : g > 0 ? 2 : "") }')
md=${x%%|*}; ch=${x#*|}; g=${ch#*|}; ch=${ch%%|*}; case "$ch" in *[!0-9]*) ch= ;; esac
b="Wi-Fi_2,4_GHz"; [ -n "$ch" ] && [ "$ch" -gt 14 ] && b="Wi-Fi_5_GHz"	# senza spazi: ON è un elenco di parole
case "$g" in 6) b="Wi-Fi_6_GHz" ;; 5) b="Wi-Fi_5_GHz" ;; 2) b="Wi-Fi_2,4_GHz" ;; esac
[ -n "$ch" ] && { BC="$BC $i=$b "; [ -n "$md" ] && [ "$md" != Master ] && NA="$NA$i "; }
[ -z "$ch" ] && [ -n "$md" ] && [ "$md" != Master ] && { BX="$BX$i=$now "; case "$NA" in *" $i "*) ;; *) NA="$NA$i " ;; esac; continue; } ;;
esac
case "$NA" in *" $i "*) continue ;; esac
rd=0; { [ $full = 1 ] || [ $EW = 0 ]; } && rd=1; case "$RQ" in *" $i "*) rd=1 ;; esac
wscan "$i" $rd
done
RQ=' '
for e in $WI; do i=${e#*|}; case "$NA" in *" $i "*) continue ;; esac; b="Wi-Fi_2,4_GHz"; case "$BC" in *" $i="*) b=${BC#*" $i="}; b=${b%% *} ;; esac; ON="$ON ${e%%|*}|$b"; [ "$DS" = " " ] || dsdel "${e%%|*}"; done
{ [ $full = 1 ] || [ $EN_ = 0 ]; } && nscan
for l in $NB; do
r=${l#*|}; d=${r%%|*}; r=${r#*|}; m=${r%%|*}; st=${r#*|}
case "$WD" in *" $d "*) continue;; esac
case "$st" in REACHABLE|DELAY|PROBE|STALE) ;; *) continue;; esac
[ -n "$m" ] || continue
a=${l%%|*}; case "$IM" in *" $m=$a|$d "*) ;; *" $m="*) x=${IM#*" $m="}; IM="${IM%%" $m="*} ${x#* }$m=$a|$d " ;; *) IM="$IM$m=$a|$d " ;; esac
case "$DS" in *" $m "*) continue ;; esac
case "$ON" in *" $m|"*) ;; *) v=cavo
case "$PON" in *" $m|"*) ;; *) { [ -z "$FDT" ] || [ $((now - FDT)) -ge 60 ]; } && fdb ;; esac
case "$FD" in *" $m="*) pi=${FD#*" $m="}; pi=${pi%% *}
[ -d "/sys/class/net/$pi/phy80211" ] && { v=Wi-Fi; case "$BC" in *" $pi="*) v=${BC#*" $pi="}; v=${v%% *};; esac; };; esac
ON="$ON $m|$v";; esac
done
PON="$ON "
for e in $ON; do
m=${e%%|*}; nocol "$m"; f=$P/$NC; s=; x=0; [ -f "$f" ] && read s x y < "$f"
lt=$now; case "$WA" in *" $m="*) lt=${WA#*" $m="}; lt=${lt%% *} ;; esac
[ "$s" = on ] && [ "$x" -gt $lt ] 2>/dev/null && [ "$x" -le $now ] && lt=$x
[ $((now - lt)) -ge $GONE ] && { [ "$s" = on ] && [ "$x $y" != "$lt ${e#*|}" ] && echo "on $lt ${e#*|}" > "$f"; continue; }
[ "$s $x $y" = "on $lt ${e#*|}" ] && continue
echo "on $lt ${e#*|}" > "$f"
[ "$s" = on ] && continue
echo "$((now + BT)) $m 1" >> $PL; pl=1	# ora vera senza processi (BT: accensione)
[ $first = 1 ] && continue
kn=; grep -qsE "^$m( |\$)" /etc/wrtfreedom/seen /tmp/wf-seen.new /tmp/wf-seen.new.f && kn=1
[ "$now" -lt 600 ] && [ -n "$kn" ] && { WF_Q=1 sh $W/event.sh dev join "$m" "${e#*|}" >/dev/null 2>&1 & continue; }
pq=; case "$PM" in *" $m="*) pp=${PM#*" $m="}; pp=${pp%% *}; pt=
case "$PT" in *" $pp="*) pt=${PT#*" $pp="}; pt=${pt%% *} ;; esac
if [ -n "$kn" ] && [ -n "$pt" ] && [ $((now - pt)) -lt 600 ]; then pq=1; else case "$PT" in *" $pp=$pt"*) PT="${PT%%" $pp=$pt"*}${PT#*" $pp=$pt"}" ;; esac; PT="$PT $pp=$now"; fi ;; esac
case " $WM " in *" $m "*) WF_TG=1 sh $W/event.sh dev join "$m" "${e#*|}" >/dev/null 2>&1 & continue ;; esac
if [ -n "$pq" ]; then WF_Q=1 sh $W/event.sh dev join "$m" "${e#*|}" >/dev/null 2>&1 &
else sh $W/event.sh dev join "$m" "${e#*|}" >/dev/null 2>&1 &
fi
done
for f in $P/*; do
[ -f "$f" ] || continue; read s x y < "$f"; [ "$s" = on ] || continue
n=${f##*/}; col "$n"
case "$WA" in *" $CO="*) ;; *) case "$PWA" in *" $CO="*) [ "$x" -lt "$PN" ] 2>/dev/null && { x=$now; echo "on $x $y" > "$f"; } ;; esac ;; esac
if [ "$x" -le "$now" ]; then	# x > now: data del pacchetto di prima, uscito subito
sl=$((now - x))
[ $sl -ge $GONE ] || { pqdel "$n"; continue; }
case "$PQ" in
*" $n="*) r=; [ -f $PR/$n ] && read -r r < $PR/$n
if [ "$r" = ok ]; then
pqdel "$n"; [ -d $PK ] || mkdir -p $PK; : > $PK/$n
echo "on $now $y" > "$f"; dsdel "$CO"; continue
fi
[ -n "$r" ] && pqdel "$n"	# «no»: per un sensore la prova riparte al giro dopo (impara se risponde)
if [ $sl -lt $DL ]; then
[ $sl -lt $OUT ] && continue	# mai uscito prima di OUT secondi di assenza (17:15)
[ -z "$r" ] && continue
case "$WA" in *" $CO="*) [ -f $PK/$n ] || continue ;; esac
fi ;;
*) [ $sl -lt $DL ] && { PQ="$PQ$n=$now "; probe "$CO" "$n" & continue; } ;;
esac
fi
pqdel "$n"; echo "off $x $y" > "$f"; m=$CO; dsdel "$m"; imdel "$m"
while :; do case "$NB" in *"|$m|"*) nx=${NB%%"|$m|"*}; nx=${nx##* }; NB="${NB%%" $nx|$m|"*} ${NB#*" $nx|$m|"*" "}" ;; *) break ;; esac; done
[ "$x" -gt "$now" ] || { echo "$((BT + x)) $m 0" >> $PL; pl=1; }	# uscito: ora vera dell'ultima volta visto
sh $W/event.sh dev leave "$m" >/dev/null 2>&1 &
done
[ "$pl" = 1 ] && [ -f $PL ] && [ "$(wc -l < $PL)" -gt $PLMAX ] && tail -n $PLMAX $PL > $PL.t && mv $PL.t $PL
pl=0; first=0
c=$((c+1))
if { [ $((c % 3)) = 2 ] || [ -f /tmp/wf-dnsfb.n ]; } && { [ "$DF" = 1 ] || [ -f /etc/wrtfreedom/dnsfb.state ] || [ -d /etc/wrtfreedom/adgmode.new ]; }; then WF_DF=${DF:-0} WF_LANG=${LG:-it} sh $W/adgmode.sh check >/dev/null 2>&1 & fi
if [ $((c % 3)) = 0 ] && any /tmp/wf-tgq/* && tgqgo; then ucode $W/tgq.uc flush >/dev/null 2>&1 & fi
if [ -n "$VP" ] && [ $((c % 3)) = 1 ] && [ "$(date +%s)" -ge "$VP" ] 2>/dev/null; then VP=$(( $(date +%s) + 60 )); sh $W/cron.sh vpnsvcresume >/dev/null 2>&1 & fi
if [ $((c % 3)) = 0 ]; then
[ $VT = 1 ] && tq vpnctl
[ "$WG" = 1 ] && tq wgx
tq custode.fast
tq usage
[ -f /tmp/wf-cbs.mm ] && tq cbs
if [ -f /tmp/wf-wifi.want ]; then
read ww x < /tmp/wf-wifi.want; ww=$((now - ${ww:-0}))
if [ $ww -lt 600 ] || { [ $((c % 30)) = 0 ] && [ $ww -lt 86400 ]; }; then tq wifi; fi
fi
if [ $((c % 6)) = 0 ]; then
tq fwstat
tq dev
tq health
any /dev/cdc-wdm* /dev/wwan* /dev/ttyUSB* /dev/ttyACM* /dev/mhi_* && tq sighist
fi
if [ "$NS" = 1 ]; then
tq nas; tq nasf
aq_=; [ -n "$AQ" ] && [ -r /proc/$AQ/cmdline ] && read -r aq_ < /proc/$AQ/cmdline
case "$aq_" in *aria2c*) ;; *) AQ=; command -v aria2c >/dev/null 2>&1 && { aq_=$(pidof aria2c 2>/dev/null); AQ=${aq_%% *}; } ;; esac
[ -n "$AQ" ] && tq nasdl
fi
any /dev/cdc-wdm* /dev/wwan* /dev/ttyUSB* /dev/ttyACM* /dev/mhi_* && tq sms
if [ $((c % 30)) = 0 ]; then
case "$BC" in *Wi-Fi_5_GHz*) tq wifi.radar ;; esac
[ -n "$GL" ] && tq wifi.glimit.check
fi
if [ $((c % 6)) = 0 ] && [ -x /etc/init.d/sqm ]; then
{ [ -z "$SQ" ] || [ ! /tmp/wf-sqmcf -nt /etc/config/sqm ] || [ $((c % 60)) = 0 ]; } && { SQ=0; grep -qs "enabled '1'" /etc/config/sqm && SQ=1; : > /tmp/wf-sqmcf; }
[ "$SQ" = 1 ] && tq sqm
fi
[ $((c % 6)) = 0 ] && tq custode
else
[ "$WG" = 1 ] && [ -f /tmp/wf-wgx.again ] && tq wgx
[ $VT = 1 ] && [ -f /tmp/wf-vpnctl.again ] && tq vpnctl
if memlow; then [ -z "$ML" ] && { tq mem; tq custode.fast; }; ML=1; else ML=; fi
fi
if [ -n "$TK" ] && [ $((now - TS)) -gt $TMAX ] && tkup; then kill -9 "$TK" 2>/dev/null; tkhung $((now - TS)); TK=; fi
if [ -n "$TQ" ] && ! tkup; then [ -n "$TK" ] && TB=; ucode $W/tick.uc $TQ >/dev/null 2>&1 & TK=$!; TS=$now; TJ=$TQ; TQ=; echo "$$ $TK" > $NPF; fi
if [ $((c % 6)) = 3 ] && [ -f /tmp/wf-fan.json.back ]; then
fb_=0; [ -f /tmp/wf-fan.json.beat ] && read -r fb_ x < /tmp/wf-fan.json.beat
case "$fb_" in ''|*[!0-9]*) fb_=0 ;; esac
if [ $((now - fb_)) -gt 180 ] || [ "$fb_" -gt $((now + 60)) ]; then
while read -r v p; do
case "$p" in
/sys/class/thermal/thermal_zone*/policy) case "$v" in ''|*[!a-z_]*) continue ;; esac ;;
/sys/class/thermal/cooling_device*/cur_state|/sys/class/hwmon/hwmon*/pwm1|/sys/class/hwmon/hwmon*/pwm1_enable) case "$v" in ''|*[!0-9]*) continue ;; esac ;;
*) continue ;;
esac
[ -f "$p" ] && echo "$v" > "$p" 2>/dev/null
done < /tmp/wf-fan.json.back
rm -f /tmp/wf-fan.json /tmp/wf-fan.json.back /tmp/wf-fan.json.beat
fi
fi
if [ -n "$GU" ] && [ $((now + BT)) -ge "$GU" ] 2>/dev/null && { [ -z "$GE" ] || [ $((now - GE)) -ge 30 ]; }; then GE=$now; sh $W/cron.sh guestend >/dev/null 2>&1 & fi
if [ $((c % 6)) = 1 ] && [ "$DR" != - ]; then
ddnsip
if [ "$DW" = 1 ] && [ $((c % 30)) = 13 ] && [ -f /tmp/.wf-ntp ]; then
dd_=$(date +%Y%m%d%H%M)
if [ "${dd_%????}" != "$DD" ] && [ "${dd_#????????}" -ge 1000 ] 2>/dev/null; then DD=${dd_%????}; sh $W/cron.sh ddnswd day >/dev/null 2>&1 & fi
fi
fi
if [ $((c % 180)) = 60 ] && { [ $((c % 4320)) = 60 ] || grep -qx net /tmp/wf-upd.err 2>/dev/null; }; then sh $W/upd.sh notify >/dev/null 2>&1 & fi
if [ $((c % 30)) = 23 ] && [ -x /etc/init.d/acme ] && [ -f /tmp/.wf-ntp ]; then
cd_=$(date +%Y%m%d%H%M)
if [ "${cd_%????}" != "$CK" ] && [ "${cd_#????????}" -ge 130 ] 2>/dev/null; then CK=${cd_%????}; sh $W/cron.sh certcheck >/dev/null 2>&1 & fi
fi
jobs >/dev/null 2>&1
nap
done
