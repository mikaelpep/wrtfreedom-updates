#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH
R=; [ -n "$WF_NASROOT" ] && [ ! -e /etc/openwrt_release ] && R=$WF_NASROOT
W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; TMP=/tmp/wf-nas; SECRET=$ETC/nas-aria2.secret
U=${WF_NASDLUC:-$W/nasdl.uc}
mkdir -p $TMP
uc() { [ -f "$U" ] || return 1; export U; ucode -e "let M = loadfile(getenv('U'))(); $1" </dev/null 2>/dev/null; }
rpc() { A2M=$1; export A2M; uc 'let r = M.rpc(getenv("A2M"), []); if (r == null) exit(1); print(sprintf("%J", r), "\n");'; }
ondisk() {
WFD=$1 awk 'BEGIN { d = ENVIRON["WFD"] } $1 ~ /^\/dev\// { m = $2; gsub(/\\040/, " ", m); gsub(/\\011/, "\t", m); gsub(/\\134/, "\\", m)
		if (m ~ /^\/(overlay|rom|boot|tmp|proc|sys|dev)?$/) next
		if ((d == m || substr(d, 1, length(m) + 1) == m "/") && length(m) > length(b)) b = m }
		END { if (b == "") exit 1; print b }' "$R/proc/mounts" 2>/dev/null
}
dlprep() {
C=$ETC/nas-aria2.conf; [ -f $C ] || exit 1
chmod 600 $C $SECRET 2>/dev/null
s=$(sed -n 's/^input-file=//p' $C); [ -n "$s" ] || exit 1
m=$(ondisk "${s%/*}") || exit 1
[ -e "$m/.wf-disco" ] || echo WrtFreedom 2>/dev/null > "$m/.wf-disco" || exit 1
mkdir -p "${s%/*}/.wf-dl" || exit 1; touch "$s"
[ -f "$s.add" ] && mv -f "$s.add" "$s.add.$$" && { cat "$s.add.$$" >> "$s"; rm -f "$s.add.$$"; }
exit 0
}
svc() {
i=$R/etc/init.d/wf-nasdl; [ -f "$i" ] || return 0
if [ "$1" = on ]; then $i enable; $i restart; else $i stop; $i disable; fi >/dev/null 2>&1
[ "$1" = on ] && [ -f $W/mem.uc ] && ( sleep 2; ucode $W/mem.uc apply ) </dev/null >/dev/null 2>&1 &
true
}

c=$1; [ $# -gt 0 ] && shift
case "$c" in
dldone)
echo "$2" | grep -qE '^[0-9a-f]{16}$' || exit 0
K=$1; G=$2; F=$4; export K G F
uc 'M.dldone(getenv("K"), getenv("G"), getenv("F") ?? "");' >/dev/null ;;
dlprep) dlprep ;;
dlpause) : > $TMP/dl.custode; rpc aria2.pauseAll >/dev/null || exit 1 ;;
dlresume) rm -f $TMP/dl.custode; uc 'M.tick();' >/dev/null ;;
dlactive) n=$(rpc aria2.getGlobalStat | sed -n 's/.*"numActive": *"\{0,1\}\([0-9][0-9]*\).*/\1/p'); echo "${n:-0}" ;;
tick) uc 'M.tick();' >/dev/null ;;
follow) uc 'M.follow();' >/dev/null ;;
svc) svc "$1" ;;
*) echo "uso: nasdl.sh dldone|dlprep|dlpause|dlresume|dlactive|tick|follow|svc on|off"; exit 2 ;;
esac
