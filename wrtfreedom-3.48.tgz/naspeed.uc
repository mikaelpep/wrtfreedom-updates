'use strict';
import { readfile, writefile, rename, unlink, stat, mkdir, rmdir, readlink, popen, open, lsdir } from 'fs';

const SYS = getenv('WF_SYS') ?? '/sys', PIO = getenv('WF_PROC') ?? '/proc', RUN = '/tmp/wf-nas';
const ETC = getenv('WF_NASETC') ?? '/etc/wrtfreedom', NASJ = ETC + '/nas.json';
const TS = (+(getenv('WF_SPEEDTS') ?? 1) > 0) ? +(getenv('WF_SPEEDTS') ?? 1) : 1;
const TICK = 250 * TS, START = 10000 * TS, CALM = 10000 * TS, COOL = 60000 * TS, SAFE = 120000 * TS, USERW = 10000 * TS;
const ETCEVERY = 1800000 * TS, GRACE = 1000 * TS, TRY = 300000 * TS, ULIST = 10000 * TS, UREAD = 2000 * TS;
const STEP = [ null, [ 500, 2000 ], [ 500, 1500 ], [ 1000, 2000 ], [ 1000, 1500 ], [ 1000, 1000 ], [ 2000, 1000 ], [ 3000, 1000 ],
[ 5000, 1000 ], [ 10000, 1000 ], [ 1, 0 ] ], TOP = 10, BASE = 3;
const NAME = [ null ];
for (let i = 1; i <= TOP; i++) push(NAME, i <= 3 ? [ 'Prudente', 'Safe' ] : i <= 7 ? [ 'Media', 'Medium' ] : [ 'Massima', 'Max' ]);
const USERB = 1048576;
const HOT = 50, COOLT = 45;
const FIX = { prudente: 3, media: 7, massima: 10, normale: 7, veloce: 10 };
const OLD7 = [ null, 2, 3, 5, 6, 7, 8, 10 ];
function ceilof(M) {
let c = M?.ceiling;
if (type(c) != 'int') return null;
if (M.v != 2) c = OLD7[c] ?? 0;
return c >= 2 && c <= TOP ? c : null;
}

function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rd(f) { return trim(readfile(f) ?? ''); }
function rj(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function wj(f, o, me) { let t = f + '.t' + me; writefile(t, sprintf('%J', o)); rename(t, f); }
function now() { let c = clock(true); return c[0] * 1000 + c[1] / 1000000.0; }
const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function njput(me, fn) {
if (!njlock()) return false;
let raw = readfile(NASJ), o = length(raw) ? rj(NASJ) : {};
if (type(o) == 'object' && fn(o)) { mkdir(ETC); wj(NASJ, o, me); }
njunlock();
return type(o) == 'object';
}
function okid(id) { return match('' + id, /^[A-Za-z0-9][A-Za-z0-9-]*$/) && length('' + id) <= 64; }
function hexv(s) {
s = lc(trim('' + s)); if (substr(s, 0, 2) != '0x') return +s || 0;
let n = 0;
for (let i = 2; i < length(s); i++) { let c = ord(s, i); n = n * 16 + (c >= 97 ? c - 87 : c - 48); }
return n;
}
function pstat(p) {
let s = readfile('/proc/' + p + '/stat');
if (!s) return null;
let f = split(substr(s, rindex(s, ')') + 2), ' ');
return { st: f[0], start: f[19] };
}
function readb(p) { let m = match(readfile(PIO + '/' + p + '/io') ?? '', /read_bytes: ([0-9]+)/); return m ? +m[1] : 0; }
function pct(a, p) {
if (!length(a)) return null;
let s = sort([ ...a ], (x, y) => x - y), i = int((length(s) - 1) * p + 0.5);
return s[i];
}
function r1(x) { return x == null ? null : +sprintf('%.1f', x); }
function running(id) {
let p = rd(RUN + '/speed-' + id + '.pid'), s = match(p, /^[0-9]+$/) ? pstat(p) : null;
return s != null && s.st != 'Z' && stat(RUN + '/speed-' + id + '.lock') != null;
}
function regread(f) {
let R = {};
for (let l in split(readfile(f) ?? '', '\n')) {
let m = match(l, /^(!?)([0-9]+) ([0-9]+)( (.+))?$/);
if (m) R[m[2]] = { keep: m[1] == '!', start: m[3], stop: m[5] };
}
return R;
}
function add(id, specs) {
if (!okid(id)) return 2;
mkdir(RUN);
let f = RUN + '/speed-' + id + '.pids', LD = f + '.lk', lk = false;
for (let i = 0; i < 100 && !lk; i++) {
lk = !!mkdir(LD);
if (!lk) { let ls = stat(LD); if (ls && time() - ls.mtime > 10) rmdir(LD); else sleep(20); }
}
let O = regread(f), N = {}, ch = false;
for (let p, e in O) { let ps = pstat(p); if (ps && ps.st != 'Z' && ps.start == e.start) N[p] = e; else ch = true; }
for (let s in specs) {
let m = match('' + s, /^(!?)([0-9]+)(@(\/[^ ]+))?$/);
if (!m || +m[2] <= 1) continue;
let ps = pstat(m[2]);
if (!ps || ps.st == 'Z') continue;
let o = N[m[2]];
if (o && o.start == ps.start && o.keep == (m[1] == '!')) continue;
N[m[2]] = { keep: m[1] == '!', start: ps.start, stop: m[4] };
ch = true;
}
if (ch) {
let L = '';
for (let p, e in N) L += (e.keep ? '!' : '') + p + ' ' + e.start + (e.stop ? ' ' + e.stop : '') + '\n';
let t = f + '.t' + (readlink('/proc/self') ?? 'x');
writefile(t, L); rename(t, f);
}
if (lk) rmdir(LD);
if (!running(id)) system('ucode ' + q(sourcepath()) + ' run ' + q(id) + ' </dev/null >/dev/null 2>&1 &');
return 0;
}
function baseof(id) {
let dev = stat(SYS + '/class/block/' + id) ? id : null;
if (!dev) {
let p = popen('block info 2>/dev/null', 'r'), o = p ? p.read('all') : '';
if (p) p.close();
for (let l in split(o ?? '', '\n')) {
let m = match(l, /^\/dev\/([^:]+):.* UUID="([^"]*)"/);
if (m && lc(m[2]) == lc(id)) { dev = m[1]; break; }
}
}
if (!dev) return null;
let s = split(readlink(SYS + '/class/block/' + dev) ?? '', '/'), up = s[length(s) - 2];
return length(s) > 1 && up != 'block' && stat(SYS + '/class/block/' + up + '/stat') ? up : dev;
}
const SHELL = 'L=; while read -r a b; do case $a in ' +
'S) for p in $b; do case " $L " in *" $p "*) ;; *) L="$L $p" ;; esac; done; kill -STOP $b ;; ' +
'C) kill -CONT $b ;; G) logger -t wrtfreedom "$b" ;; esac; done 2>/dev/null; [ -n "$L" ] && kill -CONT $L 2>/dev/null';

function regulate(id) {
let LK = RUN + '/speed-' + id + '.lock', PF = RUN + '/speed-' + id + '.pid', SF = RUN + '/speed-' + id + '.json';
let RF = RUN + '/speed-' + id + '.pids';
mkdir(RUN);
if (!mkdir(LK)) { if (running(id)) return 0; rmdir(LK); if (!mkdir(LK)) return 0; }
let me = readlink('/proc/self');
writefile(PF, me);
let quit = () => { unlink(SF); unlink(PF); rmdir(LK); };
let base = baseof(id);
if (!base) { quit(); return 1; }
let B = SYS + '/class/block/' + base, TF = RUN + '/smart/' + base + '.json', QF = RUN + '/smart/' + base + '.q';
let smartq = () => {
let s = stat(QF), v = trim(readfile(QF) ?? '');
if (!s || time() - s.mtime > 120) return false;
return v == 'run' || (match(v, /^[0-9]+$/) != null && time() - +v <= 3);
};
let K = popen('exec sh -c ' + q(SHELL) + ' >/dev/null 2>&1', 'w');
if (!K) { quit(); return 1; }
let send = (c) => { K.write(c + '\n'); K.flush(); };
let log = (t) => send('G ' + replace(t, /[\n\r]/g, ' '));

let MF = RUN + '/speed-' + id + '.mem', FG = RUN + '/speed-' + id + '.forget', etcw = -1e12, dirty = false, forgot = false;
let M = {};
if (stat(FG)) unlink(FG);
else M = rj(MF) ?? rj(NASJ)?.disks?.[id]?.speed ?? {};
let ceil = ceilof(M);
let l0 = +M.l0 > 0 ? +M.l0 : null, p0 = +M.p0 > 0 ? +M.p0 : null, tried = M.try ?? '';
let etcsave = (force) => {
if (!dirty || forgot) return;
if (!force && etcw > -1e12 && now() - etcw < ETCEVERY) return;
let sp = { ceiling: ceil, l0: r1(l0), p0: r1(p0), try: tried, v: 2 };
let ok = njput(me, (o) => {
if (type(o.disks) != 'object') o.disks = {};
if (type(o.disks[id]) != 'object') o.disks[id] = {};
if (sprintf('%J', o.disks[id].speed) == sprintf('%J', sp)) return false;
o.disks[id].speed = sp;
return true;
});
if (!ok) return;
etcw = now(); dirty = false;
};
let save = () => {
if (forgot) return;
wj(MF, { ceiling: ceil, l0: r1(l0), p0: r1(p0), try: tried, v: 2 }, me);
dirty = true;
etcsave(etcw == -1e12 && !rj(NASJ)?.disks?.[id]?.speed);
};
let today = () => { let t = localtime(); return sprintf('%04d%02d%02d', t.year, t.mon, t.mday); };
let DF = RUN + '/speed-' + id + '.day.json';
let diary = (k, lv, it, en) => {
let l = localtime(), d = sprintf('%04d-%02d-%02d', l.year, l.mon, l.mday), o = rj(DF);
if (type(o) != 'object' || o.d != d || type(o.ev) != 'array') o = { d: d, ev: [] };
push(o.ev, { t: time(), k: k, lv: lv, it: it, en: en });
if (length(o.ev) > 40) o.ev = slice(o.ev, length(o.ev) - 40);
wj(DF, o, me);
};
let fix = null, fmt = null;
let fixread = () => {
let s = stat(NASJ), m = s ? s.inode + ':' + s.mtime + ':' + s.size : '';
if (m == fmt) return false;
fmt = m;
let f = FIX[rj(NASJ)?.speed_mode] ?? null;
if (f == fix) return false;
fix = f; return true;
};
fixread();
let capof = () => fix ? fix : (ceil ? ceil - 1 : TOP);

let t0 = now(), base0 = !(l0 && p0), level = base0 ? BASE : (fix ? fix : (ceil ? min(ceil - 1, capof()) : min(BASE, capof())));
let since = t0, cyc0 = t0, cool = 0, grace = 0, down = false, trying = false, hot = false, luser = -1e12;
let S = [], Q = [], W = [], last = null, eprev = null, gone = 0, idle = 0, n = 0, temp = null, rmt = null, R = {};
let wrote = '', lat = null, mbs = 0, U = {}, ulist = -1e12, ut = 0;
let setl = (l, t) => { if (l != level) { level = l; since = t; cyc0 = t; } };
let slog = -1e12;
let safety = (t, why) => {
if (level == 1 && t < cool && t - slog < SAFE && why != 'disco sparito') {
let c0 = ceil;
ceil = max(2, (ceil ?? level) - 2); trying = false; down = true;
cool = t + SAFE; grace = t + GRACE; S = [];
if (ceil != c0) save();
return;
}
slog = t;
if (level == 1) log('NAS ' + id + ': errori del disco anche al gradino 1 (' + why + ')');
else log('NAS ' + id + ': ' + why + ', velocità al gradino 1');
ceil = max(2, (ceil ?? level) - 2); trying = false; down = true;
setl(1, t); cool = t + SAFE; grace = t + GRACE; S = []; save();
diary('safe', 1, why == 'disco sparito' ? 'Disco sparito: livello 1' : 'Errore o riavvio della porta: livello 1',
why == 'disco sparito' ? 'Drive gone: level 1' : 'Drive error or port restart: level 1');
};
diary('start', level, 'Lavoro iniziato · Livello ' + level, 'Job started · Level ' + level);
for (;;) {
let t = now();
n++;
let rs = stat(RF), mt = rs ? rs.mtime + ':' + rs.size : '';
if (mt != rmt) {
rmt = mt;
for (let p, e in regread(RF)) if (!R[p] || R[p].start != e.start) R[p] = { ...e, sent: 'C', io: null };
}
let live = 0, dead = [];
for (let p, e in R) {
let ps = pstat(p);
if (!ps || ps.st == 'Z' || ps.start != e.start) { push(dead, p); continue; }
if (e.keep) continue;
if (e.stop && !e.free && stat(e.stop)) e.free = true;
live++;
}
for (let p in dead) delete R[p];
if (t - ulist >= ULIST) {
ulist = t;
let nu = {};
for (let d in lsdir(PIO) ?? []) {
if (!match(d, /^[0-9]+$/) || (R[d] && !R[d].keep)) continue;
if (match(rd(PIO + '/' + d + '/comm'), /^(smbd|ksmbd|lighttpd|sftp-server)/)) nu[d] = true;
}
for (let p, e in R) if (e.keep) nu[p] = true;
for (let p in keys(U)) if (!nu[p]) delete U[p];
for (let p in keys(nu)) if (!exists(U, p)) U[p] = null;
}
if (t - ut >= UREAD) {
let ub = 0;
for (let p in keys(U)) {
let b = readb(p);
if (U[p] != null && b >= U[p]) ub += b - U[p];
U[p] = b;
}
if (ut > 0 && ub / ((t - ut) / 1000.0) > USERB) luser = t;
ut = t;
}
let x = split(rd(B + '/stat'), /[ \t]+/);
if (length(x) < 4) { if (++gone >= 8) { safety(t, 'disco sparito'); break; } sleep(TICK); continue; }
gone = 0;
let cur = { r: +x[0], s: +x[2], m: +x[3] }, qn = +(split(rd(B + '/inflight'), /[ \t]+/)[0] ?? 0);
let ec = hexv(rd(B + '/device/ioerr_cnt')) + hexv(rd(B + '/device/iotmo_cnt'));
let smp = null, db = 0;
if (last) {
let dr = cur.r - last.r;
db = (cur.s - last.s) * 512;
if (dr > 0 && cur.m >= last.m) smp = (cur.m - last.m) / (dr * 1.0);
if (db < 0) db = 0;
}
last = cur;
push(W, { t: t, d: db });
if (length(W) > 5) shift(W);
let wd = 0;
for (let i = 1; i < length(W); i++) wd += W[i].d;
let ws = length(W) > 1 ? (W[length(W) - 1].t - W[0].t) / 1000.0 : 0;
mbs = ws > 0 ? wd / ws / 1e6 : mbs;
if (n % 4 == 1) {
if (stat(FG)) {
unlink(FG); unlink(MF); forgot = true; dirty = false;
if (type(rj(NASJ)?.disks?.[id]?.speed) == 'object')
njput(me, (o) => { if (type(o.disks?.[id]?.speed) != 'object') return false; delete o.disks[id].speed; return true; });
}
if (fixread()) { trying = false; if (!base0 && level > capof()) setl(capof(), t); }
let T = rj(TF), tc = T?.temperature?.current ?? T?.nvme_smart_health_information_log?.temperature;
temp = type(tc) == 'int' || type(tc) == 'double' ? tc : null;
if (temp != null && temp >= HOT) { if (!hot) diary('hot', level, 'In pausa: disco a ' + temp + ' °C', 'Paused: drive at ' + temp + ' °C'); hot = true; }
else if (temp == null || temp < COOLT) hot = false;
}
let pu = t - luser < USERW, paused = pu || hot;
if (eprev != null && ec > eprev && !smartq()) safety(t, 'errore o riavvio della porta');
eprev = ec;
if (paused) { since = t; S = []; }
else {
if (smp != null) push(S, { t: t, v: smp });
push(Q, { t: t, q: qn });
while (length(S) && S[0].t < t - CALM) shift(S);
while (length(Q) && Q[0].t < t - CALM) shift(Q);
let V = map(S, (s) => s.v), k = length(V);
lat = null;
let a1 = [], a3 = [];
for (let s in S) { if (s.t >= t - 1000 * TS) push(a1, s.v); else if (s.t >= t - 3000 * TS && s.t < t - 2000 * TS) push(a3, s.v); }
let avg = (a) => { let z = 0; for (let v in a) z += v; return length(a) ? z / (length(a) * 1.0) : null; };
lat = avg(a1);
if (base0) {
if (t - t0 >= START && k >= 8) {
l0 = max(pct(V, 0.5), 0.1); p0 = max(pct(V, 0.9), 1); base0 = false; since = t; save();
if (fix) setl(fix, t);
}
else if (qn > 4) { setl(1, t); cool = t + COOL; }
}
else {
let up4 = k >= 5 && V[k - 1] > 1.5 * p0;
for (let i = k - 4; up4 && i < k; i++) if (!(V[i] > V[i - 1])) up4 = false;
let hit = t >= grace && ((smp != null && smp > 3 * p0) || up4 || qn > 4);
if (hit) {
if (level > 1) {
let tr = level;
ceil = ceil ? min(ceil, tr) : tr; if (ceil < 2) ceil = 2;
setl(max(1, tr - 2), t); save();
}
trying = false; down = true; cool = t + COOL; grace = t + GRACE; S = [];
}
else {
let cap = capof();
if (trying && fix) trying = false;
if (level > cap && !trying) setl(cap, t);
let qm = 0;
for (let z in Q) if (z.q > qm) qm = z.q;
let grow = lat != null && avg(a3) != null && lat > 1.2 * avg(a3) && lat > 1.2 * p0;
let calm = t - since >= CALM && t >= cool && k >= 4 && pct(V, 0.9) < 2 * p0 && !grow && qm <= 2;
if (calm && trying && t - since >= TRY) { ceil = ceil < TOP ? ceil + 1 : null; trying = false; since = t; save(); }
else if (calm && !trying && level < cap) setl(level + 1, t);
else if (calm && !trying && !fix && ceil && level == ceil - 1 && level < TOP && !down && tried != today()) {
tried = today(); trying = true; setl(ceil, t); save();
}
}
}
}
let st = STEP[level], go = !paused && (level == TOP || ((t - cyc0) % ((st[0] + st[1]) * TS)) < st[0] * TS);
let SS = [], CC = [];
for (let p, e in R) {
if (e.keep) continue;
let w = go || e.free ? 'C' : 'S';
if (w != e.sent) { push(w == 'S' ? SS : CC, p); e.sent = w; }
}
if (length(CC)) send('C ' + join(' ', CC));
if (length(SS)) send('S ' + join(' ', SS));
let O = { level: level, name: NAME[level][0], name_en: NAME[level][1], ceiling: ceil, l0: r1(l0), p0: r1(p0),
lat: r1(lat), mbs: r1(mbs), paused_for_user: pu, hot: hot };
let sig = level + ':' + ceil + ':' + pu + ':' + hot + ':' + l0;
if (sig != wrote || n % 4 == 0) { wrote = sig; wj(SF, O, me); }
if (live > 0) idle = 0;
else if (++idle >= 8) {
let c = 0;
for (let p, e in regread(RF)) { let ps = pstat(p); if (!e.keep && ps && ps.start == e.start && ps.st != 'Z') c++; }
if (!c) break;
idle = 0; rmt = null;
}
let d = TICK - (now() - t);
sleep(d > 0 ? int(d) : 1);
}
let CC = [];
for (let p, e in R) if (!e.keep && e.sent == 'S') push(CC, p);
if (length(CC)) send('C ' + join(' ', CC));
K.close();
etcsave(true);
diary('end', level, 'Lavoro finito · Livello ' + level, 'Job finished · Level ' + level);
quit();
return 0;
}

let A = ARGV ?? [];
if (A[0] == 'add') exit(add(A[1], slice(A, 2)));
else if (A[0] == 'run' && okid(A[1])) exit(regulate(A[1]));
else { print('uso: ucode naspeed.uc add <disco> <pid>|<pid>@<file di stop>|!<pid>... | run <disco>\n'); exit(2); }
