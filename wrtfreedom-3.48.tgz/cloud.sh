#!/bin/sh
export PATH=$PATH:/usr/sbin:/usr/bin:/sbin:/bin
D0=$(cd "$(dirname "$0")" && pwd)
R=; [ -n "$WF_CLOUDROOT" ] && [ ! -e /etc/openwrt_release ] && R=$WF_CLOUDROOT
W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; CJ=$ETC/cloud.json; RC=$ETC/cloud-rclone.conf; OLDRC=$ETC/nasx-rclone.conf
XJ=$ETC/nasx.json; CDIR=$ETC/nasx-cloud; NX=/tmp/wf-nas/x; T=/tmp/wf-cloud
CLOUDUC=${WF_CLOUDUC:-$W/cloud.uc}; CX=${WF_CLOUDX:-$D0/cloudx.sh}
IDLE=60; [ -n "$R" ] && IDLE=${WF_CLIDLE:-60}
. "$D0/cloudline.sh" || exit 1
umask 022
[ -d $T ] || { mkdir -p $T && chmod 700 $T; }
mkdir -p $T/req $T/res $T/q $T/jobs $T/log
EN=0; [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
alive() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }
now() { date +%s; }
age() { echo $(( $(now) - $(date -r "$1" +%s 2>/dev/null || echo 0) )); }
upt() { UP=; read -r UP _ </proc/uptime 2>/dev/null; UP=${UP%.*}; [ -n "$UP" ] || UP=$(now); }
booting() {
if [ -n "$R" ]; then [ -n "$WF_UPTIME" ] && [ "$WF_UPTIME" -lt 600 ] 2>/dev/null; return; fi
upt; [ "$UP" -lt 600 ] 2>/dev/null
}
js() { ucode -e "let N = {}; try { N = json(require(\"fs\").readfile(\"$1\") ?? \"{}\"); } catch (e) {} $2" </dev/null 2>/dev/null; }
ev() { [ -f $W/event.sh ] && sh $W/event.sh cron "$1" cloud "$2" </dev/null >/dev/null 2>&1; true; }
cx() { [ -f "$CX" ] && sh "$CX" "$@" </dev/null >/dev/null 2>&1; }
bg() { ( "$@" ) </dev/null >/dev/null 2>&1 & }

lk_get() {
until mkdir "$1" 2>/dev/null; do
p=$(cat "$1/pid" 2>/dev/null)
if { [ -n "$p" ] && ! alive "$p"; } || { [ -z "$p" ] && [ "$(age "$1")" -gt 60 ]; }; then rm -rf "$1"; continue; fi
return 1
done
echo "${2:-$$}" > "$1/pid"; [ -n "$3" ] && echo "$3" > "$1/job"; true
}
lk_dead() { p=$(cat "$1/pid" 2>/dev/null); { [ -n "$p" ] && ! alive "$p"; } || { [ -z "$p" ] && [ "$(age "$1")" -gt 60 ]; }; }
lk_wait() { _lw=0; until lk_get "$1"; do _lw=$((_lw + 1)); [ $_lw -ge "$2" ] && return 1; sleep 1; done; }
lk_put() { [ "$(cat "$1/pid" 2>/dev/null)" = $$ ] && rm -rf "$1"; true; }
CLN=; CLK=; _l=
onexit() { CLN="$CLN $*"; trap 'for _l in $CLK; do lk_put "$_l"; done; rm -rf $CLN' EXIT; }
onlock() { CLK="$CLK $*"; onexit; }
okid() { echo "$1" | grep -qE '^a[0-9]{1,3}$'; }
gen() {
okid "$1" || return 0
v_=$(tr -d '-' < /proc/sys/kernel/random/uuid 2>/dev/null | cut -c1-10); [ -n "$v_" ] || v_=$(date +%s).$$
printf '%s\n' "$v_" > "$T/gen-$1.$$" && mv -f "$T/gen-$1.$$" "$T/gen-$1" || rm -f "$T/gen-$1.$$"
true
}
okjob() { echo "$1" | grep -qE '^[A-Za-z0-9_-]{1,48}$'; }

nslots() {
cl_low && { NS=1; return; }
p=$(js $CJ 'let p = +(N.line?.parallel ?? 0); print(p >= 1 && p <= 8 ? int(p) : 0);')
[ "${p:-0}" -gt 0 ] && { NS=$p; return; }
case $(cl_tier) in A) NS=1 ;; B) NS=2 ;; *) NS=4 ;; esac
}
slot_get() {
J=$1; A=${2:--}; P=${3:-$PPID}
okjob "$J" || { echo "wait job"; return 1; }
[ "$A" = - ] || okid "$A" || { echo "wait acct"; return 1; }
for s in $T/slot.*; do
[ -d "$s" ] && [ "$(cat "$s/job" 2>/dev/null)" = "$J" ] || continue
sp=$(cat "$s/pid" 2>/dev/null)
if [ "$sp" = "$P" ] || ! alive "$sp"; then
echo "$P" > "$s/pid"
[ "$A" != - ] && [ "$(cat $T/acct-$A.lock/job 2>/dev/null)" = "$J" ] && echo "$P" > $T/acct-$A.lock/pid
echo "ok ${s##*.}"; return 0
fi
echo "wait slot"; return 1
done
qt=; [ -f $T/q/$J.slot ] && read -r qt qa qp < $T/q/$J.slot
case "$qt" in ''|*[!0-9]*) qt=$(now) ;; esac
echo "$qt $A $P" > $T/q/$J.slot.t && mv $T/q/$J.slot.t $T/q/$J.slot
if [ "$A" != - ] && [ -d $T/acct-$A.lock ] && ! lk_dead $T/acct-$A.lock && [ "$(cat $T/acct-$A.lock/job 2>/dev/null)" != "$J" ]; then
echo "wait acct"; return 1
fi
first=$(for f in $T/q/*.slot; do
[ -f "$f" ] || continue
read -r qt qa qp < "$f"
alive "$qp" || { rm -f "$f"; continue; }
qj=${f##*/}; qj=${qj%.slot}
if [ "$qa" != - ] && [ -d $T/acct-$qa.lock ] && ! lk_dead $T/acct-$qa.lock && [ "$(cat $T/acct-$qa.lock/job 2>/dev/null)" != "$qj" ]; then continue; fi
echo "$qt $qj"
done | sort -n | head -n 1 | cut -d' ' -f2)
[ "$first" = "$J" ] || { echo "wait slot"; return 1; }
if [ "$A" != - ]; then
lk_get $T/acct-$A.lock "$P" "$J" || { [ "$(cat $T/acct-$A.lock/job 2>/dev/null)" = "$J" ] && [ "$(cat $T/acct-$A.lock/pid 2>/dev/null)" = "$P" ] || { echo "wait acct"; return 1; }; }
fi
nslots; n=$NS; used=0
for s in $T/slot.*; do [ -d "$s" ] && { if lk_dead "$s"; then rm -rf "$s"; else used=$((used + 1)); fi; }; done
i=1
while [ $used -lt "$n" ] && [ $i -le 8 ]; do
if lk_get $T/slot.$i "$P" "$J"; then echo "$A" > $T/slot.$i/acct; rm -f $T/q/$J.slot; echo "ok $i"; return 0; fi
i=$((i + 1))
done
[ "$A" != - ] && [ "$(cat $T/acct-$A.lock/job 2>/dev/null)" = "$J" ] && rm -rf $T/acct-$A.lock
echo "wait slot"; return 1
}
slot_put() {
J=$1
for s in $T/slot.* $T/acct-*.lock; do [ -d "$s" ] && [ "$(cat "$s/job" 2>/dev/null)" = "$J" ] && rm -rf "$s"; done
rm -f $T/q/$J.slot; true
}

etxt() {
case "$1" in
pkg) echo 'pkg|Serve installare Cloud in Software|Install Cloud in Software first' ;;
svc) echo 'svc|Servizio cloud non valido|Invalid cloud service' ;;
token) echo 'token|Collegamento non valido: riprova|Invalid connection: try again' ;;
fields) echo "fields|Controlla i dati dell'account|Check the account details" ;;
relink) echo 'relink|Account da ricollegare|Account needs reconnecting' ;;
space) echo 'space|Spazio nel cloud finito|Cloud storage full' ;;
net) echo 'net|Internet non raggiungibile|Internet unreachable' ;;
busy) echo 'busy|Account occupato: riprova fra poco|Account busy: try again shortly' ;;
none) echo 'none|Account non trovato|Account not found' ;;
act) echo 'act|Azione sconosciuta|Unknown action' ;;
*) echo 'fail|Non riuscito|Failed' ;;
esac
}
PCZ_UC=$(cat <<'ucode'
let _pcr = null;
function pcz(id) {
	if (!match(id ?? '', /^a[0-9]{1,3}$/)) return '';
	if (_pcr == null) _pcr = split(require('fs').readfile(getenv('RC')) ?? '', '\n');
	let S = 'wfa' + substr(id, 1), k = false, ty = '', h = '';
	for (let l in _pcr) {
		let m = match(l, /^\[(.*)\][ \t]*$/);
		if (m) { if (k) break; k = m[1] == S; continue; }
		if (!k) continue;
		let p = match(l, /^(type|hostname)[ \t]*=[ \t]*([^ \t]*)[ \t]*$/);
		if (p) { if (p[1] == 'type') ty = p[2]; else h = p[2]; }
	}
	return ty != 'pcloud' ? '' : h == 'eapi.pcloud.com' ? 'eu' : h == 'api.pcloud.com' ? 'us' : '';
}
ucode
)
stput() {
lk_wait $T/state.lock 10 || return 0
case "$2" in ok|new|busy) _ste= ;; *) _ste=$(etxt "$2") ;; esac
A=$1 C=$2 X=$_ste V=${3:-} ZS=${4+1} Z=${4:-} RC=$RC F=$T/state.json ucode -e "$PCZ_UC"'let fs = require("fs"), E = getenv, S = {}, v = null; try { S = json(fs.readfile(E("F")) ?? "{}"); } catch (e) {} try { v = json(E("V") || "null"); } catch (e) {}
		if (type(S) != "object") S = {}; if (type(S.accts) != "object") S.accts = {};
		let a = E("A"), o = type(S.accts[a]) == "object" ? S.accts[a] : {}, x = split(E("X") ?? "", "|");
		o.st = length(E("X") ?? "") ? (x[0] == "relink" ? "relink" : "err") : E("C");
		if (length(E("X") ?? "")) { o.err = x[1]; o.err_en = x[2]; } else { delete o.err; delete o.err_en; }
		if (type(v) == "object") { for (let k in [ "total", "used", "free" ]) if (type(v[k]) == "int") o[k] = v[k]; o.t_about = type(v.t) == "int" ? v.t : time(); }
		if (E("ZS") == "1") { if (match(E("Z") ?? "", /^(eu|us)$/)) o.zone = E("Z"); else delete o.zone; }
		else if (!length(o.zone ?? "")) { let z = pcz(a); if (length(z)) o.zone = z; }
		o.t = time(); S.accts[a] = o; S.t = time();
		let t = E("F") + ".t"; fs.writefile(t, sprintf("%J", S)); fs.rename(t, E("F"));' </dev/null 2>/dev/null
lk_put $T/state.lock
}
stsum() {
lk_wait $T/state.lock 10 || return 0
v=
rb=$R/usr/bin/rclone; [ -x "$rb" ] || rb=
if command -v rclone >/dev/null 2>&1 && { [ ! -f $T/rclone.ver ] ||
{ [ -n "$rb" ] && { [ "$rb" -nt $T/rclone.ver ] || [ $R/lib/apk/db/installed -nt $T/rclone.ver ] || [ $R/usr/lib/opkg/status -nt $T/rclone.ver ]; }; } ||
{ { [ -z "$rb" ] || [ ! -s $T/rclone.ver ]; } && [ "$(age $T/rclone.ver)" -gt 86400 ]; }; }; then
rclone version </dev/null 2>/dev/null | sed -n '1s/^rclone v\{0,1\}\([0-9][0-9.]*\).*/\1/p' > $T/rclone.ver
fi
command -v rclone >/dev/null 2>&1 && v=$(cat $T/rclone.ver 2>/dev/null)
D=$(date +%Y%m%d) V=$v L=$(cut -d' ' -f1 $T/line 2>/dev/null) A1=$(cat $T/all.day 2>/dev/null) S1=$(cat $T/sim.day 2>/dev/null) CJ=$CJ RC=$RC F=$T/state.json ucode -e "$PCZ_UC"'let fs = require("fs"), E = getenv, S = {}, C = null; try { S = json(fs.readfile(E("F")) ?? "{}"); } catch (e) {} try { C = json(fs.readfile(E("CJ")) ?? "null"); } catch (e) {}
		if (type(S) != "object") S = {}; if (type(S.accts) != "object") S.accts = {};
		for (let a in (type(C?.accounts) == "array" ? C.accounts : [])) {
			let o = S.accts["" + a?.id];
			if (a?.svc == "pcloud" && type(o) == "object" && !length(o.zone ?? "")) { let z = pcz("" + a.id); if (length(z)) o.zone = z; }
		}
		function day(s) { let u = split(trim(s ?? ""), " "); return u[0] == E("D") && match(u[1] ?? "", /^[0-9]+$/) ? int(u[1]) : 0; }
		S.today_bytes = day(E("A1")); S.sim_bytes = day(E("S1")); S.sim_on = E("L") == "sim";
		if (length(E("V") ?? "")) S.rclone_ver = E("V"); else delete S.rclone_ver;
		S.t = time();
		let t = E("F") + ".t"; fs.writefile(t, sprintf("%J", S)); fs.rename(t, E("F"));' </dev/null 2>/dev/null
lk_put $T/state.lock
}
hc() { printf '(error|status|code|http)[^0-9a-z]{0,3}%s([^0-9]|$)|[(]%s [a-z]' "$1" "$1"; }
rcerr() {
if grep -qiE "invalid_grant|unauthori[sz]ed|token.*(expired|invalid|revoked)|\"result\": *(1000|2000)([^0-9]|\$)|$(hc 401)" "$1" 2>/dev/null; then echo relink
elif grep -qiE "ratelimitexceeded|rate ?limit|uploadlimitexceeded|too_many_requests|activitylimitreached|too many requests|$(hc 429)" "$1" 2>/dev/null; then echo busy
elif grep -qi 'quota\|storage.*full\|insufficient' "$1" 2>/dev/null; then echo space
elif grep -qi 'no such host\|dial tcp\|timeout\|network is unreachable' "$1" 2>/dev/null; then echo net
else echo fail; fi
}
svcab() { case "$1" in icloud|b2|s3|sftp) return 1 ;; esac; return 0; }
link1() {
_to=; command -v timeout >/dev/null 2>&1 && _to="timeout 60"
$_to rclone lsf "wfa${1#a}:" --max-depth 1 --dirs-only </dev/null >/dev/null 2>"$2"
}
about1() { rclone about "wfa${1#a}:" --json </dev/null 2>"$2" | ucode -e 'let a = null; try { a = json(require("fs").stdin.read("all")); } catch (e) {} let r = {}; if (type(a) == "object") for (let k in [ "total", "used", "free", "trashed" ]) if (type(a[k]) == "int" && a[k] >= 0) r[k] = a[k]; if (r.free != null || r.used != null) printf("%J\n", { ...r, t: time() });' 2>/dev/null; }
resp() { echo "$2" > $T/res/$1.json.t && mv $T/res/$1.json.t $T/res/$1.json; }
rerr() {
_rex=$(etxt "$2")
resp "$1" "{\"code\":\"${_rex%%|*}\",\"error\":\"$(echo "$_rex" | cut -d'|' -f2)\",\"error_en\":\"${_rex##*|}\"}"
}

AUTH_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, id = E('ID'), o = null;
try { o = json(fs.readfile(E('NEW')) ?? ''); } catch (e) { o = null; }
if (type(o) != 'object') { print('token\n'); exit(0); }
let svc = '' + (o.svc ?? ''), f = type(o.fields) == 'object' ? o.fields : {};
let TY = { pcloud: 'pcloud', drive: 'drive', onedrive: 'onedrive', dropbox: 'dropbox', box: 'box', kdrive: 'kdrive', koofr: 'koofr',
	jottacloud: 'jottacloud', mega: 'mega', icloud: 'iclouddrive', b2: 'b2', s3: 's3', hetzner: 'sftp', webdav: 'webdav', sftp: 'sftp' };
let FK = { kdrive: { token: 'access_token', drive: 'drive_id' }, koofr: { user: 'user', pass: 'password' }, jottacloud: { code: 'config_login_token' },
	mega: { user: 'user', pass: 'pass' }, icloud: { user: 'apple_id', pass: 'password' }, b2: { key_id: 'account', key: 'key' },
	s3: { vendor: 'provider', endpoint: 'endpoint', region: 'region', key_id: 'access_key_id', key: 'secret_access_key' },
	hetzner: { user: 'user', pass: 'pass', host: 'host' }, webdav: { url: 'url', user: 'user', pass: 'pass', vendor: 'vendor' },
	sftp: { host: 'host', port: 'port', user: 'user', pass: 'pass' } };
let OB = { koofr: [ 'password' ], mega: [ 'pass' ], icloud: [ 'password' ], hetzner: [ 'pass' ], webdav: [ 'pass' ], sftp: [ 'pass' ] };
if (!TY[svc]) { print('svc\n'); exit(0); }
/* valori su una riga sola (mai un'altra sezione dentro il file di rclone) */
function ok1(v) { return type(v) == 'string' && length(v) && length(v) <= 16384 && !match(v, /[[:cntrl:]]/); }
let kv = { type: TY[svc] };
if (FK[svc]) {
	for (let k, rk in FK[svc]) if (f[k] != null) { let v = '' + f[k]; if (!ok1(v)) { print('fields\n'); exit(0); } kv[rk] = v; }
	if (svc == 'koofr') kv.provider = 'koofr';
	if (svc == 'hetzner') kv.port = '23';
	if (svc == 's3' && !kv.provider) kv.provider = 'Other';
	/* 19/11 (analisi): S3 con il contenitore (bucket) come radice, wfa<n>: = <bucket>/ ovunque (vista, crypt, lavori):
	   sezione alias con la remote di rclone scritta per intero («:s3,chiave="valore",…:<bucket>/», valori tra
	   virgolette, le virgolette raddoppiate), una sezione sola come gli altri servizi; provider e bucket restano anche
	   da soli nella sezione (letti da nasbk.uc e dall'app, rclone non li usa) */
	if (svc == 's3') {
		let b = '' + (f.bucket ?? '');
		if (!match(b, /^[A-Za-z0-9][A-Za-z0-9._-]*$/) || length(b) > 63) { print('fields\n'); exit(0); }
		let cs = [];
		for (let k in [ 'provider', 'endpoint', 'region', 'access_key_id', 'secret_access_key' ])
			if (kv[k] != null && kv[k] !== '') push(cs, k + '="' + replace(kv[k], /"/g, '""') + '"');
		kv = { type: 'alias', remote: ':s3,' + join(',', cs) + ':' + b + '/', provider: kv.provider, bucket: b };
	}
	/* 19/11 (analisi): SFTP e Hetzner con la chiave del server salvata alla prima connessione e poi controllata
	   (known_hosts_file per account in /etc/wrtfreedom, lo scrive auth con khscan) */
	if (svc == 'sftp' || svc == 'hetzner') kv.known_hosts_file = E('KH');
	/* iCloud: il codice del secondo fattore non entra nella sezione, va a rclone come risposta config_2fa (file 0600) */
	if (svc == 'icloud' && f.code != null && f.code !== '') {
		let c = '' + f.code;
		if (!match(c, /^[0-9]{6,8}$/)) { print('fields\n'); exit(0); }
		fs.writefile(E('OBP') + '2fa', c);
	}
} else {
	/* token = JSON di rclone (stringa, come lo scrive cloud.uc); zona di pCloud (hostname) dentro il token, tolta prima
	   di scriverlo. Dal file di cloud.uc: own con client_id e client_secret (Google «Vedi Tutto Il Drive», scope drive;
	   senza: drive.file), drive_id e drive_type di OneDrive */
	let tk = null; try { tk = json('' + (o.token ?? '')); } catch (e) { tk = null; }
	if (type(tk) != 'object' || type(tk.access_token) != 'string') { print('token\n'); exit(0); }
	let hn = tk.hostname != null ? '' + tk.hostname : null;
	delete tk.hostname;
	kv.token = sprintf('%J', tk);
	/* 19/11 (analisi): client che ha preso il token (telefono con Accedi Con, OAuth.java; OneDrive col client del router
	   di Entra Con Un Codice): nella sezione, così rclone rinnova il token con lo stesso client (con il suo l'account
	   cade dopo la prima scadenza). pCloud no: il suo token non scade */
	let pcid = o.client_id != null && o.client_id !== '' && o.own !== true ? '' + o.client_id : null;
	if (pcid && match(svc, /^(drive|onedrive|dropbox|box)$/)) kv.client_id = pcid;
	if (svc == 'drive') {
		/* scope vero del token: own = drive; client del telefono = drive.file (il permesso che chiede OAuth.java);
		   token incollato da «rclone authorize "drive"» (client di rclone) = drive; scope dentro il token se c'è */
		kv.scope = pcid ? 'drive.file' : 'drive';
		if (o.own === true) {
			if (o.client_id == null || o.client_secret == null) { print('fields\n'); exit(0); }
			kv.scope = 'drive'; kv.client_id = '' + o.client_id; kv.client_secret = '' + o.client_secret;
		}
		if (type(tk.scope) == 'string')
			kv.scope = match(tk.scope, /auth\/drive( |$)/) ? 'drive' : match(tk.scope, /auth\/drive\.file/) ? 'drive.file' : kv.scope;
	}
	if (svc == 'onedrive' && o.drive_id != null && o.drive_id !== '') { kv.drive_id = '' + o.drive_id; kv.drive_type = '' + (o.drive_type ?? 'personal'); }
	if (svc == 'pcloud' && hn) kv.hostname = hn;
	for (let k in [ 'client_id', 'client_secret', 'drive_id', 'drive_type', 'hostname' ]) if (kv[k] != null && !match(kv[k], /^[A-Za-z0-9!._~-]{1,200}$/)) { print('fields\n'); exit(0); }
}
/* parole da offuscare: in file 0600, una per chiave, rclone obscure le legge dall'ingresso */
let ob = [];
for (let k in (OB[svc] ?? [])) if (kv[k] != null) { fs.writefile(E('OBP') + k, kv[k]); kv[k] = ''; push(ob, k); }
let Wx = {}; Wx['wfa' + substr(id, 1)] = kv;
fs.writefile(E('OUT'), sprintf('%J', Wx));
print('ok ' + join(' ', ob) + '\n');
ucode
)
auth() {
Q=$1; A=$(js $T/req/$Q.json 'print(N.id ?? "");')
okid "$A" || { rerr "$Q" none; return; }
NEW=$T/.new-$A
[ -f "$NEW" ] || { rerr "$Q" token; return; }
command -v rclone >/dev/null 2>&1 || { rerr "$Q" pkg; return; }
OUT=$T/.w-$Q; OBP=$T/.ob-$Q-
( umask 077; : > "$OUT"; )
KH=$ETC/cloud-kh-$A
o=$( umask 077; ID=$A NEW=$NEW OUT=$OUT OBP=$OBP KH=$KH ucode -e "$AUTH_UC" </dev/null 2>/dev/null )
case "$o" in ok*) ;; *) rm -f "$OUT" "$OBP"*; rerr "$Q" "${o:-token}"; stput "$A" "${o:-token}"; return ;; esac
HP=$(S=wfa${A#a} F=$OUT ucode -e 'let w = json(require("fs").readfile(getenv("F")))[getenv("S")]; if (w?.known_hosts_file) print(w.host ?? "", " ", w.port || "22");' </dev/null 2>/dev/null)
if [ -n "$HP" ] && ! khscan ${HP% *} ${HP#* } "$KH"; then rm -f "$OUT" "$OBP"*; rerr "$Q" net; stput "$A" net; return; fi
pczone "$A" "$OUT"
ZN=$(S=wfa${A#a} F=$OUT ucode -e 'let h = json(require("fs").readfile(getenv("F")))[getenv("S")]?.hostname; print(h == "eapi.pcloud.com" ? "eu" : h == "api.pcloud.com" ? "us" : "");' </dev/null 2>/dev/null)
for k in ${o#ok}; do
ob=$(rclone obscure - < "$OBP$k" 2>/dev/null) || { rm -f "$OUT" "$OBP"*; rerr "$Q" err; return; }
( umask 077; printf '%s' "$ob" > "$OBP$k.o" )
ob=
K=$k F=$OUT S=wfa${A#a} P=$OBP$k.o ucode -e 'let fs = require("fs"), Wx = json(fs.readfile(getenv("F"))); Wx[getenv("S")][getenv("K")] = trim(fs.readfile(getenv("P")) ?? ""); fs.writefile(getenv("F"), sprintf("%J", Wx));' </dev/null 2>/dev/null
done
if [ -f "${OBP}2fa" ]; then
e=$(icl2fa "$A" "$OUT" "${OBP}2fa")
[ -z "$e" ] || { rm -f "$OUT" "$OBP"*; rerr "$Q" "$e"; stput "$A" "$e"; return; }
fi
rm -f "$OBP"*
SV=$(js "$NEW" 'print(N.svc ?? "");')
rcput "$OUT"; r=$?; rm -f "$OUT"
[ $r = 0 ] || { rerr "$Q" busy; return; }
rm -f "$NEW"
export RCLONE_CONFIG=$RC
if link1 "$A" $T/log/auth-$A; then
ab=; svcab "$SV" && ab=$(about1 "$A" $T/log/auth-$A.ab)
stput "$A" ok "$ab" "$ZN"; resp "$Q" "{\"ok\":true,\"id\":\"$A\"}"
else e=$(rcerr $T/log/auth-$A); stput "$A" "$e" "" "$ZN"; rerr "$Q" "$e"; fi
rm -f $T/log/auth-$A $T/log/auth-$A.ab
}
khscan() {
[ -s "$3" ] && return 0
case "$1$2" in ''|*[!A-Za-z0-9.:_-]*) return 1 ;; esac
_kt=$T/.kh-$$; rm -rf "$_kt"; mkdir -p "$_kt" && chmod 700 "$_kt" || return 1
_kh=$1; [ "$2" = 22 ] || _kh="[$1]:$2"
_to=; command -v timeout >/dev/null 2>&1 && _to="timeout 20"
if command -v ssh-keyscan >/dev/null 2>&1; then $_to ssh-keyscan -T 10 -p "$2" "$1" </dev/null 2>/dev/null > "$_kt/k"
elif command -v dbclient >/dev/null 2>&1; then
HOME=$_kt $_to dbclient -y -p "$2" "wf@$1" true </dev/null >/dev/null 2>&1
cat "$_kt/.ssh/known_hosts" > "$_kt/k" 2>/dev/null
fi
awk -v h="$_kh" 'NF >= 3 && $1 !~ /^#/ && $2 ~ /^(ssh-|ecdsa-)/ { print h, $2, $3 }' "$_kt/k" 2>/dev/null > "$_kt/o"
[ -s "$_kt/o" ] && ( umask 077; cat "$_kt/o" > "$3.t" ) && mv -f "$3.t" "$3"
rm -rf "$_kt"; [ -s "$3" ]
}
ICL_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, S = E('S');
if (E('M') == 'put') {
	let Wx = json(fs.readfile(E('F'))), o = [];
	for (let s, kv in Wx) { push(o, '[' + s + ']'); for (let k, v in kv) push(o, k + ' = ' + v); }
	fs.writefile(E('C'), join('\n', o) + '\n');
	exit(0);
}
let kv = {}, cur = null;
for (let l in split(fs.readfile(E('C')) ?? '', '\n')) {
	let m = match(l, /^\[(.*)\][ \t]*$/);
	if (m) { cur = m[1]; continue; }
	let p = match(l, /^([A-Za-z0-9_]+)[ \t]*=[ \t]*(.*)$/);
	if (cur == S && p) kv[p[1]] = p[2];
}
if (!length(kv.trust_token ?? '')) exit(1);
let Wx = {}; Wx[S] = kv;
fs.writefile(E('F'), sprintf('%J', Wx));
ucode
)
pczone() {
S=wfa${1#a}
[ "$(S=$S F=$2 ucode -e 'let w = json(require("fs").readfile(getenv("F")))[getenv("S")]; if (w?.type == "pcloud" && !length(w?.hostname ?? "")) print("z");' </dev/null 2>/dev/null)" = z ] || return 0
TC=$T/.w-$Q.conf; TO=; command -v timeout >/dev/null 2>&1 && TO="timeout 15"
( umask 077; : > "$TC" )
M=put S=$S F=$2 C=$TC ucode -e "$ICL_UC" </dev/null 2>/dev/null || { rm -f "$TC"; return 0; }
for z in api.pcloud.com eapi.pcloud.com; do
if RCLONE_CONFIG=$TC $TO rclone about "$S:" --pcloud-hostname "$z" --contimeout 5s --timeout 10s --retries 1 --low-level-retries 1 </dev/null >/dev/null 2>&1; then
Z=$z S=$S F=$2 ucode -e 'let fs = require("fs"), Wx = json(fs.readfile(getenv("F"))); Wx[getenv("S")].hostname = getenv("Z"); fs.writefile(getenv("F"), sprintf("%J", Wx));' </dev/null 2>/dev/null
break
fi
done
rm -f "$TC"
}
icl2fa() {
S=wfa${1#a}; TC=$T/.w-$Q.conf
( umask 077; : > "$TC" )
M=put S=$S F=$2 C=$TC ucode -e "$ICL_UC" </dev/null 2>/dev/null || { rm -f "$TC"; echo fields; return; }
{ cat "$3"; echo; } | RCLONE_CONFIG=$TC rclone config update "$S" >$T/log/auth-$1 2>&1
if ! M=get S=$S F=$2 C=$TC ucode -e "$ICL_UC" </dev/null 2>/dev/null; then
e=$(rcerr $T/log/auth-$1); [ "$e" = net ] || e=token; echo "$e"
fi
rm -f "$TC" $T/log/auth-$1
}
rcput() {
n=0
until ucode "$CLOUDUC" rcput "$1" </dev/null >/dev/null 2>&1; do
n=$((n + 1)); [ $n -ge 3 ] && return 1; sleep 1
done
}

texp() {
e=$(awk -v s="[wfa${1#a}]" '/^\[.*\][ \t]*$/ { k = ($0 == s); next } k && /^token[ \t]*=/ { sub(/^token[ \t]*=[ \t]*/, ""); print; exit }' $RC 2>/dev/null |
ucode -e 'function dn(s) { let v = 0; for (let i = 0; i < length(s); i++) v = v * 10 + ord(s, i) - 48; return v; }
			let t = null; try { t = json(require("fs").stdin.read("all")); } catch (e) {}
			let m = match(t?.expiry ?? "", /^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})[.0-9]*(Z|([-+])([0-9]{2}):([0-9]{2}))$/);
			/* 19/11 (analisi): scadenza prima del 1971 (pCloud: 0001-01-01) o token senza refresh_token = non scade (vuoto) */
			if (m && dn(m[1]) >= 1971 && length(t?.refresh_token ?? "")) { let o = m[8] ? (dn(m[9]) * 3600 + dn(m[10]) * 60) * (m[8] == "-" ? -1 : 1) : 0;
				print(timegm({ year: dn(m[1]), mon: dn(m[2]), mday: dn(m[3]), hour: dn(m[4]), min: dn(m[5]), sec: dn(m[6]) }) - o - time()); }' 2>/dev/null)
echo "$e"
}
unlink1() {
Q=$1; okid "$2" || { rerr "$Q" none; return; }
p=$(js $T/req/$Q.json 'let p = N.link?.path; if (type(p) == "string" && !match(p, /[[:cntrl:]]/)) print(p);' | sed 's#^/*##')
case "/$p/" in */../*|*/./*) rerr "$Q" fail; return ;; esac
L=$T/log/r-$Q; TO=; command -v timeout >/dev/null 2>&1 && TO="timeout 60"
UC=$RC; S=wfa${2#a}; UJ=$T/.w-$Q.rc; UT=$T/.w-$Q.conf
( umask 077; js $T/req/$Q.json "let s = (N.rc ?? {})[\"$S\"]; if (type(s) == 'object') { let o = {}; for (let k, v in s) if (match(k, /^[A-Za-z0-9_]+\$/) && type(v) == 'string' && !match(v, /[[:cntrl:]]/)) o[k] = v; printf('%J', { \"$S\": o }); }" > "$UJ" )
if [ -s "$UJ" ]; then
( umask 077; : > "$UT" ); M=put S=$S F=$UJ C=$UT ucode -e "$ICL_UC" </dev/null 2>/dev/null && UC=$UT
fi
if RCLONE_CONFIG=$UC $TO rclone link --unlink "$S:$p" </dev/null >"$L" 2>&1; then resp "$Q" '{"ok":true}'
elif grep -qi "not supported\|doesn't support\|unknown flag\|not implemented\|can't unlink\|cannot unlink" "$L"; then
resp "$Q" '{"ok":true,"kept":true,"note":"Il servizio non permette di togliere il link: resta attivo fino alla scadenza","note_en":"The service does not allow removing the link: it stays active until it expires"}'
else e=$(rcerr "$L"); rerr "$Q" "$e"; fi
rm -f "$L" "$UJ" "$UT"
}
doreq() {
Q=$1; F=$T/req/$Q.json
read -r act A <<-EOF
	$(js "$F" 'print(N.act ?? "-", " ", N.id ?? "-");')
	EOF
A=${A:--}
case "$act" in
auth) auth "$Q"; rm -f "$F" "$T/req/$Q.wait"; return 0 ;;
about|ls|link|upreq|find|unlink) c=$act ;;
thumbs|revs|revert|trash|restore|stream|photo) c=$act ;;
mkdir|move|rm) c=op ;;
*) rerr "$Q" act; rm -f "$F"; return 0 ;;
esac
if [ "$A" != - ]; then
okid "$A" || { rerr "$Q" none; rm -f "$F"; return 0; }
if [ -d $T/acct-$A.lock ] && ! lk_dead $T/acct-$A.lock; then
x=$(texp "$A")
[ -z "$x" ] || [ "$x" -gt 900 ] || { [ -f $T/req/$Q.wait ] || : > $T/req/$Q.wait; return 2; }
fi
fi
export RCLONE_CONFIG=$RC
LA=; LS=
if [ "$c" = unlink ]; then
LA=$(js "$F" 'print(N.link?.id ?? "-");'); okid "$LA" || LA=-
LS=$(js "$F" "let s = (N.rc ?? {})[\"wfa${LA#a}\"]; if (type(s) == 'object') print(s.type ?? '');")
[ -n "$LS" ] || LS=$(js $CJ "for (let a in (N.accounts ?? [])) if (a.id == \"$LA\") print(a.svc ?? \"\");")
fi
if [ "$c" = unlink ] && [ "$LS" != pcloud ]; then unlink1 "$Q" "$LA"
elif [ -f "$CX" ]; then sh "$CX" "$c" "$Q" </dev/null >/dev/null 2>&1; else rerr "$Q" pkg; fi
[ -f $T/res/$Q.json ] || rerr "$Q" fail
rm -f "$F" $T/req/$Q.wait; return 0
}
lsold() {
ls -tr "$1"/*"$2" 2>/dev/null | while read -r p; do
n=${p##*/}; n=${n%"$2"}
case "$n" in ''|*[!A-Za-z0-9_-]*) continue ;; esac
[ ${#n} -le 48 ] && echo "$n"
done
}
work() {
p=$(cat $T/work.pid 2>/dev/null)
[ -n "$p" ] && [ "$p" != $$ ] && alive "$p" && exit 0
lk_get $T/work.lk || exit 0
echo $$ > $T/work.pid
trap 'rm -rf $T/work.lk; [ "$(cat $T/work.pid 2>/dev/null)" = $$ ] && rm -f $T/work.pid' EXIT
FF=0; WQ=$T/work.fifo
read -r -t 0 _k </dev/null 2>/dev/null; [ $? != 2 ] && { [ -p $WQ ] || { rm -f $WQ; mkfifo $WQ 2>/dev/null; }; } &&
[ -p $WQ ] && exec 4<>$WQ && FF=1
upt; la=$UP; wt=$((UP - 15)); ft=$((UP - 10))
while [ $((UP - la)) -lt "$IDLE" ]; do
got=0; wn=$UP; tw=0; [ $((wn - wt)) -ge 15 ] && tw=1
n=0; for x in $T/req/*.json; do [ -f "$x" ] && { n=1; break; }; done
[ $n = 1 ] && for Q in $(lsold $T/req .json); do
if [ -f $T/req/$Q.wait ]; then
if [ "$(age $T/req/$Q.wait)" -gt 600 ]; then rerr "$Q" busy; rm -f $T/req/$Q.json $T/req/$Q.wait; continue; fi
[ $tw = 1 ] || continue
fi
got=1; doreq "$Q" 4>&-
done
[ $tw = 1 ] && wt=$wn
w=0; for x in $T/req/*.wait; do [ -f "$x" ] && { w=1; break; }; done
if [ $got = 1 ] && [ $w = 0 ]; then upt; la=$UP
else
if [ $FF = 1 ]; then read -r -t 1 _k <&4; else sleep 1; fi
upt; [ $w = 1 ] && la=$UP
fi
[ $((UP - ft)) -ge 10 ] && { find $T/res -name '*.json' -mmin +1 -exec rm -f {} + 2>/dev/null; ft=$UP; }
done
}

jobwhy() {
w=$(cl_why "$2")
J=$T/jobs/$1.json Y=$2 I=${w%%|*} N_=${w#*|} ucode -e 'let fs = require("fs"), f = getenv("J"), o = null; try { o = json(fs.readfile(f)); } catch (e) {}
		if (type(o) == "object" && (o.wc != getenv("Y") || o.state != "wait")) { o.state = "wait"; o.wc = getenv("Y"); o.why = getenv("I"); o.why_en = getenv("N_"); o.t = time(); let t = f + ".w"; fs.writefile(t, sprintf("%J", o)); fs.rename(t, f); }' </dev/null 2>/dev/null
}
inhours() {
a=$(echo "$1" | tr -d :); b=$(echo "$2" | tr -d :); h=$(_cl_hm | tr -d :)
if [ "$a" -le "$b" ]; then [ "$h" -ge "$a" ] && [ "$h" -lt "$b" ]; else [ "$h" -ge "$a" ] || [ "$h" -lt "$b" ]; fi
}
mhours() { js $ETC/nas.json 'let c = N.media?.cloud ?? {}; if (c.on === true && c.mode == "pre" && match(c.from ?? "", /^[0-2][0-9]:[0-5][0-9]$/) && match(c.to_h ?? "", /^[0-2][0-9]:[0-5][0-9]$/)) print(c.from, " ", c.to_h);'; }
media_q() {
[ -f $ETC/nas.json ] || return 0
h=$(mhours); [ -n "$h" ] || return 0
inhours $h || return 0
command -v wf_udir >/dev/null 2>&1 || . "$D0/lib.sh" 2>/dev/null
L1=$(wf_udir shared media video) L2=$(wf_udir shared media music) L3=$(wf_udir shared media photo) || return 0
[ -n "$L1" ] && [ -n "$L2" ] && [ -n "$L3" ] || return 0
( umask 077; L1=$L1 L2=$L2 L3=$L3 NJ=$ETC/nas.json JF=$T/jobs/jmedia.json QF=$T/q/jmedia.json QJ=$T/jobs/jmedia.q.json ucode -e '
let fs = require("fs"), E = getenv, N = {}, J = null, now = time();
try { N = json(fs.readfile(E("NJ")) ?? "{}"); } catch (e) {}
try { J = json(fs.readfile(E("JF")) ?? "null"); } catch (e) {}
let c = N?.media?.cloud ?? {};
if (!match(c.acct ?? "", /^a[0-9]{1,3}$/) || type(c.to) != "string" || !length(c.disk ?? "")) exit(0);
if (type(J) == "object" && (J.state == "run" || J.state == "wait" || now - +(J.tq ?? 0) < 72000)) exit(0);
let P = [ E("L1"), E("L2"), E("L3") ];
let o = { job: "jmedia", kind: "media", name: "Scarica Prima", id: c.acct, path: P[0], paths: P, disk: "" + c.disk, to: c.to,
	net: type(c.net) == "object" ? c.net : { mode: "same" }, from: P[0], t: now, tq: now };
function w(f, x) { let t = f + ".t"; fs.writefile(t, sprintf("%J", x)); fs.rename(t, f); }
w(E("QF"), o); w(E("QJ"), o);
w(E("JF"), { ...o, state: "wait", wc: "queue", why: "In coda", why_en: "Queued", pct: 0, speed: 0, bytes: 0, size: 0 });' </dev/null >/dev/null 2>&1 )
rm -f $T/jobs/jmedia.stop; true
}
jobsof() {
lsold $T/jobs .json | JD=$T/jobs ucode -e 'let fs = require("fs"), d = getenv("JD");
		for (let j in split(trim(fs.stdin.read("all") ?? ""), "\n")) { if (!length(j)) continue; let N = {}; try { N = json(fs.readfile(d + "/" + j + ".json") ?? "{}"); } catch (e) {}
			print(j, " ", N?.state ?? "-", " ", int(N?.pid ?? 0), " ", N?.kind ?? "-", "\n"); }' 2>/dev/null
}
queue() {
used=0; for s in $T/slot.*; do [ -d "$s" ] && used=$((used + 1)); done
free=; [ $used -gt 0 ] && { nslots; free=$((NS - used)); [ $free -gt 0 ] || return 0; }
while read -r j st pid kind <&3; do
[ -z "$free" ] || [ $free -gt 0 ] || break
[ "$st" = wait ] || continue
[ -f $T/jobs/$j.stop ] && continue
[ "$pid" != 0 ] && alive "$pid" && continue
[ -n "$free" ] || { nslots; free=$((NS - used)); }
[ $free -gt 0 ] || break
case "$kind" in
router|camup|rtget) c=$kind ;;
media) c=media; h=$(mhours); [ -n "$h" ] || continue
inhours $h || continue ;;
down|nas|up|phone|url|mv|lcopy|copy) c=xfer ;;
*) continue ;;
esac
n=$(js $T/jobs/$j.json 'print(sprintf("%J", N.net ?? { mode: "same" }));')
if ! cl_check "$j" "$n" >/dev/null; then jobwhy "$j" "$CL_WHY"; continue; fi
[ -f "$CX" ] || continue
rm -f $T/q/$j.json
( umask 077; J=$T/jobs/$j.json P_=$$ ucode -e 'let fs = require("fs"), f = getenv("J"), o = null; try { o = json(fs.readfile(f)); } catch (e) {}
			if (type(o) == "object") { o.state = "run"; o.pid = +getenv("P_"); o.t = time(); let t = f + ".r"; fs.writefile(t, sprintf("%J", o)); fs.rename(t, f); }' </dev/null >/dev/null 2>&1 )
bg sh "$CX" "$c" "$j"; free=$((free - 1))
done 3<<-EOF
	$(jobsof)
	EOF
}

pause_end() {
[ "$(js $CJ 'print(N.pause?.on === true && +(N.pause?.until ?? 0) > 0 && +N.pause.until <= time() ? 1 : 0);')" = 1 ] || return 0
ubus call wrtfreedom cloud '{"act":"pause","do":"resume"}' >/dev/null 2>&1 ||
ucode -e "loadfile('$CLOUDUC')().cloud.call({ args: { act: 'pause', do: 'resume' } });" </dev/null >/dev/null 2>&1
true
}
expire() {
for f in $T/.new-*; do [ -f "$f" ] && [ "$(age "$f")" -gt 600 ] && rm -f "$f"; done
find $T/res -name '*.json' -mmin +1 -exec rm -f {} + 2>/dev/null
find $T/req -name '*.json' -mmin +15 -exec rm -f {} + 2>/dev/null
for f in $T/req/*.wait; do [ -f "$f" ] && [ ! -f "${f%.wait}.json" ] && rm -f "$f"; done
find $T/ph -type f -mmin +60 2>/dev/null | while read -r f; do
j=${f##*/}; j=${j%.part}; j=${j%.ok}
grep -q '"state": *"\(wait\|run\)"' "$T/jobs/$j.json" 2>/dev/null || rm -f "$f"
done
find $T/log -type f -mtime +7 -exec rm -f {} + 2>/dev/null
nl_=0; for f in $T/log/*; do [ -f "$f" ] && nl_=$((nl_ + 1)); done
[ $nl_ -gt 200 ] && ls -t $T/log | awk 'NR > 200' | while read -r f; do
case "$f" in mnt-*|purge|*/*|'') continue ;; esac
[ -f "$T/jobs/$f.json" ] || rm -f "$T/log/$f"
done
rm -f $T/.ro-*.conf $T/.w-* $T/.ob-* 2>/dev/null
jobsof | awk '$2 == "ok" || $2 == "err" || $2 == "stop" { a[++n] = $1 } END { for (i = 1; i <= n - 50; i++) print a[i] }' | while read -r j; do rm -f "$T/jobs/$j.json" "$T/jobs/$j.q.json" "$T/jobs/$j.stop" "$T/log/$j"; done
find $T/jobs -name '*.json' ! -name '*.q.json' -mtime +7 -exec sh -c 'for f; do grep -q "\"state\": *\"\(ok\|err\|stop\)\"" "$f" && rm -f "$f" "${f%.json}.q.json" "${f%.json}.stop"; done' sh {} + 2>/dev/null
true
}
tick_get() {
until mkdir $T/tick.lock 2>/dev/null; do
if [ -f $T/tick.lock ]; then p=$(cat $T/tick.lock 2>/dev/null); else p=$(cat $T/tick.lock/pid 2>/dev/null); fi
if { [ -n "$p" ] && ! alive "$p"; } || { [ -z "$p" ] && [ "$(age $T/tick.lock)" -gt 30 ]; }; then rm -rf $T/tick.lock; continue; fi
if [ -n "$p" ] && [ "$p" != $$ ] && [ "$(age $T/tick.lock)" -gt "${WF_TICKMAX:-1800}" ]; then
kill "$p" 2>/dev/null; rm -rf $T/tick.lock
ev cloud_stuck "⚠️ $(t 'Cloud ¦ Giro fermo da 30 minuti: riavviato' 'Cloud ¦ Round stuck for 30 minutes: restarted')"
continue
fi
return 1
done
echo $$ > $T/tick.lock/pid
}
tick() {
tick_get || exit 0
onlock $T/tick.lock
read -r mg qj <<-EOF
	$(js $CJ 'print(N.mig === 1 ? 1 : 0, " ", !length(N.accounts ?? []) && !length(N.share ?? {}) && N.pause?.on !== true ? 1 : 0);')
	EOF
[ "$mg" = 1 ] || migrate >/dev/null 2>&1
[ "$mg" = 1 ] && [ "$qj" = 1 ] && quiet && exit 0
pause_end; expire
ucode "$CLOUDUC" orphans </dev/null >/dev/null 2>&1 || true
for s in $T/slot.* $T/acct-*.lock; do [ -d "$s" ] && lk_dead "$s" && rm -rf "$s"; done
media_q
command -v rclone >/dev/null 2>&1 && queue
command -v rclone >/dev/null 2>&1 && crtick
stsum
[ -f $W/cloudmnt.sh ] && sh $W/cloudmnt.sh check </dev/null >/dev/null 2>&1
[ -n "$(lsold $T/req .json)" ] && ! alive "$(cat $T/work.pid 2>/dev/null)" && bg sh "$0" work
if grep -q '"upreq"' $ETC/cloud-links.json 2>/dev/null && [ "$(age $T/upnew.t)" -ge 3600 ]; then
: > $T/upnew.t; bg cx upnew
fi
if command -v rclone >/dev/null 2>&1 && [ "$(age $T/phtick.t)" -ge 900 ]; then : > $T/phtick.t; bg cx phtick; fi
if [ -z "$R" ] && grep -q '^type *= *pcloud' $RC 2>/dev/null && ! alive "$(cat $T/phs/listen.pid 2>/dev/null)" && [ "$(age $T/cwstart.t)" -ge 3600 ]; then
: > $T/cwstart.t; [ -x /etc/init.d/wrtfreedom ] && bg /etc/init.d/wrtfreedom start
fi
H=$(date +%H%M); day=$(date +%Y%m%d)
if [ "$H" -ge 330 ] && [ "$H" -lt 410 ] && [ "$(cat $T/night.day 2>/dev/null)" != "$day" ]; then
echo "$day" > $T/night.day; bg sh "$0" night
fi
if [ "$qj" = 1 ] && ! grep -q '"req"' $ETC/cloud-links.json 2>/dev/null && ! grep -q '"pre"' $ETC/nas.json 2>/dev/null; then
echo "$day" > $T/tick.day
else rm -f $T/tick.day; fi
true
}
quiet() {
[ -f $T/tick.day ] || return 1
for f in $CJ $ETC/nas.json $ETC/cloud-links.json "$D0/cloud.sh" $W/cloudmnt.sh $R/lib/apk/db/installed $R/usr/lib/opkg/status; do
[ -e "$f" ] && ! [ $T/tick.day -nt "$f" ] && return 1
done
for f in $T/req/* $T/res/* $T/jobs/* $T/q/* $T/ph/* $T/slot.* $T/acct-*.lock $T/.new-*; do [ -e "$f" ] && return 1; done
for f in $T/mnt/*; do [ -e "$f" ] && case ${f##*/} in intdir|*.pend) ;; *) return 1 ;; esac; done
set -- $(date '+%Y%m%d %H%M')
d_=; read -r d_ < $T/tick.day; [ "$d_" = "$1" ] || return 1
n_=; read -r n_ 2>/dev/null < $T/night.day
[ "${2#0}" -ge 330 ] && [ "${2#0}" -lt 410 ] && [ "$n_" != "$1" ] && return 1
true
}

late() { [ "$TIER" = A ] && [ "$(date +%H%M)" -ge 410 ] && [ "$(date +%H%M)" -lt 1200 ]; }
night() {
lk_get $T/night.lk || exit 0
trap 'rm -rf $T/night.lk' EXIT
command -v rclone >/dev/null 2>&1 && [ -f $RC ] || exit 0
TIER=$(cl_tier); export RCLONE_CONFIG=$RC
for AS in $(js $CJ 'for (let a in (N.accounts ?? [])) print(a.id, ":", a.svc ?? "", "\n");'); do
A=${AS%%:*}; SV=${AS#*:}
okid "$A" || continue
late && break
grep -q "^\[wfa${A#a}\]" $RC || continue
lk_get $T/acct-$A.lock $$ night || continue
if link1 "$A" $T/log/night-$A; then
ab=; svcab "$SV" && ab=$(about1 "$A" $T/log/night-$A.ab)
stput "$A" ok "$ab"
[ -n "$ab" ] && for j in $(js $XJ "for (let c in (N.cloud ?? [])) if (c.acct == \"$A\") print(c.id, \"\n\");"); do
echo "$j" | grep -qE '^[kc][0-9a-z]{1,16}$' && mkdir -p $CDIR && echo "$ab" > $CDIR/$j.about.t && mv $CDIR/$j.about.t $CDIR/$j.about
done
else
stput "$A" "$(rcerr $T/log/night-$A)"
fi
rm -f $T/log/night-$A $T/log/night-$A.ab; rm -rf $T/acct-$A.lock
done
late && exit 0
cx recv; late && exit 0
cx linkexp; late && exit 0
cx wtnight; late && exit 0
if [ "$(js $CJ "let r = N.router ?? {}; print(r.on === true && (r.every == 'day' || +(r.day ?? 0) == $(date +%w)) ? 1 : 0);")" = 1 ]; then
cx router
fi
true
}

heal() {
for s in $T/slot.* $T/acct-*.lock $T/mig.lock $T/night.lk $T/work.lk $T/tick.lock $T/state.lock; do
[ -d "$s" ] && lk_dead "$s" && { rm -rf "$s"; echo "lock ${s##*/}"; }
done
[ -d $T/rc.lock ] && [ "$(age $T/rc.lock)" -gt 120 ] && { rm -rf $T/rc.lock; echo "lock rc.lock"; }
n=$(now)
for f in $T/jobs/*.json; do
[ -f "$f" ] || continue
read -r st pid jt <<-EOF
		$(js "$f" 'print(N.state ?? "-", " ", int(N.pid ?? 0), " ", int(N.t ?? 0));')
		EOF
[ "$st" = run ] && [ "${jt:-0}" -gt 0 ] && [ $((n - jt)) -ge 7200 ] || continue
alive "$pid" && [ "$pid" != 0 ] && cl_kill "$pid"
J=$f ucode -e 'let fs = require("fs"), f = getenv("J"), o = json(fs.readfile(f)); o.state = "err"; o.code = "fail"; o.err = "Fermo da 2 ore"; o.err_en = "Stuck for 2 hours"; o.pid = 0; o.t = time(); let t = f + ".h"; fs.writefile(t, sprintf("%J", o)); fs.rename(t, f);' </dev/null 2>/dev/null
echo "stuck ${f##*/}"
done
m=$(awk '/^MemAvailable:/ { print $2; exit }' $CL_PROC/meminfo 2>/dev/null); mlim=102400
cl_mem rclonepush && { mlim=$((102400 + CL_TET * 1024)); [ "$CL_RIS" -lt "$mlim" ] && mlim=$CL_RIS; [ "$CL_SOTTO" -ge 1 ] || mlim=0; }
used=0; for s in $T/slot.*; do [ -d "$s" ] && used=$((used + 1)); done
if [ "${m:-999999}" -lt "$mlim" ] && [ $used -ge 2 ]; then
s=$(ls -dt $T/slot.* | sed -n 1p); p=$(cat "$s/pid" 2>/dev/null); j=$(cat "$s/job" 2>/dev/null)
alive "$p" && cl_kill "$p"; rm -rf "$s"
[ -f "$T/jobs/$j.json" ] && { jobwhy "$j" mem; J=$T/jobs/$j.json ucode -e 'let fs = require("fs"), f = getenv("J"), o = json(fs.readfile(f)); o.pid = 0; let t = f + ".h"; fs.writefile(t, sprintf("%J", o)); fs.rename(t, f);' </dev/null 2>/dev/null; }
echo "mem $j"
fi
true
}

MIG_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, now = time();
function rj(p) { try { return json(fs.readfile(p) ?? 'null'); } catch (e) { return null; } }
function ini(p) {
	let S = {}, o = [], cur = null;
	for (let l in split(fs.readfile(p) ?? '', '\n')) {
		let m = match(l, /^\[(.*)\][ \t]*$/);
		if (m) { cur = m[1]; S[cur] = {}; push(o, cur); continue; }
		let kv = match(l, /^([A-Za-z0-9_]+)[ \t]*=[ \t]*(.*)$/);
		if (cur && kv) S[cur][kv[1]] = kv[2];
	}
	return [ S, o ];
}
function tok(s) { let o = null; try { o = json(s ?? ''); } catch (e) { o = null; } return type(o) == 'object' ? o : null; }
/* stesso account = stesso servizio e stesso refresh_token (OneDrive: anche la stessa unità) */
function key(kv) {
	let t = tok(kv.token);
	if (!t) return null;
	return (kv.type ?? '') + '|' + (t.refresh_token ?? t.access_token ?? '') + '|' + (kv.type == 'onedrive' ? (kv.drive_id ?? '') : '');
}
let OI = ini(E('OLDRC')), NI = ini(E('RC')), O = OI[0], N = NI[0];
let C = rj(E('CJ')); if (type(C) != 'object') C = {};
C.v ??= 1; if (type(C.accounts) != 'array') C.accounts = [];
C.line ??= { sim: { gb: null, all: false, from: '01:00', to: '07:00' }, bw_up: 0, bw_down: 0, bw_at: [], parallel: 0 };
C.pause ??= { on: false, until: 0, by: 'user' };
C.router ??= { on: false, acct: '', every: 'week', day: 0, keep: 8, before_fw: true, last: 0, ok: true };
C.lim ??= { phone_mb: 0, ls_max: 50000 };
let SV = { drive: 'Google Drive', onedrive: 'OneDrive', dropbox: 'Dropbox', pcloud: 'pCloud', box: 'Box' };
let A = {}, top = 0, W = {}, map = {}, NEW = [];
for (let a in C.accounts) { let m = match('' + a.id, /^a([0-9]+)$/); if (m && +m[1] > top) top = +m[1]; }
for (let s in NI[1]) {
	let m = match(s, /^wfa([0-9]+)$/);
	if (!m) continue;
	if (+m[1] > top) top = +m[1];
	let k = key(N[s]); if (k && !A[k]) A[k] = 'a' + m[1];
}
function addacct(id, kv) {
	for (let a in C.accounts) if (a.id == id) return;
	let svc = kv.type ?? '', n = length(filter(C.accounts, (a) => a.svc == svc)), nm = (SV[svc] ?? svc) + (n ? ' ' + (n + 1) : '');
	let a = { id: id, svc: svc, name: nm, zone: '', mail: '', host: '', t_link: now, t_use: 0, own: svc == 'drive' && length(kv.client_id ?? '') > 0, warn_ok: false };
	if (svc == 'onedrive') { a.drive_id = kv.drive_id ?? ''; a.drive_type = kv.drive_type ?? 'personal'; }
	push(C.accounts, a);
}
function exp(s) { return tok(O[s].token)?.expiry ?? ''; }
let G = {}, Go = [];
for (let s in OI[1]) {
	if (!match(s, /^wf(k[0-9a-z]+|cc[0-9a-z]+)$/)) continue;
	let k = key(O[s]);
	if (!k) continue;
	if (!G[k]) { G[k] = []; push(Go, k); }
	push(G[k], s);
}
for (let k in Go) {
	let best = null;
	for (let s in G[k]) if (!best || exp(s) > exp(best)) best = s;
	let id = A[k];
	if (!id) { id = 'a' + (++top); A[k] = id; W['wfa' + substr(id, 1)] = O[best]; }
	addacct(id, O[best]);
	for (let s in G[k]) map[s] = id;
}
/* crypt di ogni backup: stessa password (i dati restano leggibili), remote verso l'account */
for (let s in OI[1]) {
	if (O[s].type != 'crypt') continue;
	let kv = { ...O[s] }, m = match(kv.remote ?? '', /^([^:]+):(.*)$/);
	if (m && map[m[1]]) kv.remote = 'wfa' + substr(map[m[1]], 1) + ':' + m[2];
	if (N[s] && N[s].remote == kv.remote) continue;
	W[s] = kv;
}
/* token in arrivo di «Accedi Con» (3.11): account nuovi */
for (let f in split(E('TOKS') ?? '', ' ')) {
	if (!length(f)) continue;
	let o = rj(f), m = match(f, /\.tok-([a-z]+)$/);
	if (!m || type(o) != 'object' || !tok(o.token)) continue;
	let kv = { type: m[1], token: o.token };
	if (m[1] == 'drive') kv.scope = 'drive';
	for (let x in [ 'drive_id', 'drive_type', 'client_id', 'client_secret' ]) if (o[x] != null) kv[x] = '' + o[x];
	let k = key(kv);
	if (A[k]) continue;
	let id = 'a' + (++top); A[k] = id; W['wfa' + substr(id, 1)] = kv; addacct(id, kv); push(NEW, id);
}
/* lavori di nasx.json: solo la mappa sezione → account, nasx.json lo cambia XMIG_UC sotto il suo lucchetto */
let need = keys(W);
for (let k, id in A) push(need, 'wfa' + substr(id, 1));
fs.writefile(E('OUTW'), sprintf('%J', W));
fs.writefile(E('OUTC'), sprintf('%.J\n', C));
fs.writefile(E('OUTM'), sprintf('%J', map));
let U = {}, need1 = [];
for (let s in need) if (!U[s]) { U[s] = true; push(need1, s); }
print(join(' ', need1), '\n', join(' ', NEW), '\n');
ucode
)
migrate() {
[ "$(js $CJ 'print(N.mig === 1 ? 1 : 0);')" = 1 ] && return 0
lk_get $T/mig.lock || return 1
MC=$ETC/.mig.c.$$; MX=$ETC/.mig.x.$$
onlock $T/mig.lock
onexit "$T/.mig.*" "$MC" "$MX"
for l in $NX/rc-*.lock; do [ -d "$l" ] && ! lk_dead "$l" && return 1; done
[ -f $OLDRC ] && [ ! -f $OLDRC.pre321 ] && ( umask 077; cp $OLDRC $OLDRC.pre321.t && mv $OLDRC.pre321.t $OLDRC.pre321 )
lk_wait $T/cj.lock 10 || return 1
onlock $T/cj.lock
if migrate1; then r=0; else r=1; fi
lk_put $T/cj.lock
return $r
}
XMIG_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, X = null, map = null;
try { X = json(fs.readfile(E('XJ')) ?? 'null'); } catch (e) { X = null; }
try { map = json(fs.readfile(E('MAP')) ?? 'null'); } catch (e) { map = null; }
if (type(map) != 'object') exit(1);
if (type(X) != 'object') exit(0);
if (type(X.cloud) == 'array') for (let c in X.cloud) {
	let bk = c.kind == 'backup', s = (bk ? 'wf' : 'wfc') + c.id;
	if (map[s]) c.acct = map[s];
	c.keep_days ??= 30;
	c.net ??= { mode: 'same' };
	if (bk) c.key2 ??= false; else c.mirror ??= (c.dir == 'up');
}
fs.writefile(E('OUTX'), sprintf('%.J\n', X));
ucode
)
migrate1() {
mkdir -p $ETC
toks=; for f in $NX/.tok-*; do [ -f "$f" ] && toks="$toks $f"; done
( umask 077; : > $T/.mig.w )
o=$(OLDRC=$OLDRC RC=$RC CJ=$CJ TOKS=$toks OUTW=$T/.mig.w OUTC=$MC OUTM=$T/.mig.m ucode -e "$MIG_UC" </dev/null 2>/dev/null) || return 1
need=$(echo "$o" | sed -n 1p); new=$(echo "$o" | sed -n 2p)
[ -f $MC ] && [ -f $T/.mig.m ] || return 1
if [ "$(cat $T/.mig.w)" != '{ }' ] && [ "$(cat $T/.mig.w)" != '{}' ]; then rcput $T/.mig.w || return 1; fi
for s in $need; do grep -q "^\[$s\][ 	]*$" $RC 2>/dev/null || return 1; done
if [ -f $XJ ]; then
mkdir -p "${NX%/*}"
lk_wait "${NX%/*}/cmig.lock" 10 || return 1
onlock "${NX%/*}/cmig.lock"
rm -f $MX
XJ=$XJ MAP=$T/.mig.m OUTX=$MX ucode -e "$XMIG_UC" </dev/null 2>/dev/null; r=$?
[ $r = 0 ] && [ -f $MX ] && { mv $MX $XJ || r=1; }
lk_put "${NX%/*}/cmig.lock"
[ $r = 0 ] || return 1
fi
mv $MC $CJ
for a in $new; do stput "$a" new; done
for f in $toks; do rm -f "$f"; done
rm -f $OLDRC
for l in $NX/rc-*.lock; do [ -d "$l" ] && rm -rf "$l"; done
F=$CJ ucode -e 'let fs = require("fs"), f = getenv("F"), C = json(fs.readfile(f)); C.mig = 1; let t = f + ".m"; fs.writefile(t, sprintf("%.J\n", C)); fs.rename(t, f);' </dev/null 2>/dev/null || return 1
true
}

knorm() {
k=$(cat); u=$(printf '%s' "$k" | tr -d ' -' | tr 'a-z' 'A-Z')
if printf '%s' "$u" | grep -qE '^[A-Z0-9]{24}$'; then printf '%s' "$u" | sed 's/\(....\)/\1-/g; s/-$//'
else printf '%s' "$k"; fi
k=; u=
}
crcomm() { [ "$(js $CJ "for (let a in (N.accounts ?? [])) if (a?.id == \"$1\") print(type(a.user) == 'string' && length(a.user) ? a.user : 'admin');")" = admin ]; }
crkdone() { rm -f $T/.crkey; }
crob() {
[ -f $T/.crkey ] || return 1
KY=$(knorm < $T/.crkey)
[ -n "$KY" ] || return 1
( umask 077; printf '%s' "$KY" | rclone obscure - > "$OBF" 2>/dev/null ) || { KY=; return 2; }
( umask 077; printf 'wfh%s' "$KY" | sha256sum | cut -c1-64 | rclone obscure - > "$O2F" 2>/dev/null ) || { KY=; return 2; }
KY=
[ -s "$OBF" ] && [ -s "$O2F" ] || return 2
}
CRS_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, U = loadfile(E('U'))(), N = {}, a = E('A_');
try { N = json(fs.readfile(E('NJ')) ?? '{}'); } catch (e) { N = {}; }
if (type(N) != 'object') N = {};
let pw = trim(fs.readfile(E('OBF')) ?? ''), p2 = trim(fs.readfile(E('O2F')) ?? '');
if (!length(pw)) {
	let S = {}, o = [], cur = null;
	for (let l in split(fs.readfile(E('RC')) ?? '', '\n')) {
		let m = match(l, /^\[(.*)\][ \t]*$/);
		if (m) { cur = m[1]; S[cur] = {}; push(o, cur); continue; }
		let kv = match(l, /^([A-Za-z0-9_]+)[ \t]*=[ \t]*(.*)$/);
		if (cur && kv) S[cur][kv[1]] = kv[2];
	}
	let best = null;
	for (let s in o) {
		if (!match(s, /^wfa[0-9]{1,3}[cx][0-9a-z]+$/) || S[s].type != 'crypt' || !length(S[s].password ?? '')) continue;
		best ??= s;
		let p = substr(s, 0, length(a) + 3);
		if (p == 'wf' + a + 'c' || p == 'wf' + a + 'x') { best = s; break; }
	}
	if (best == null) { print('nokey\n'); exit(0); }
	pw = S[best].password; p2 = S[best].password2 ?? '';
}
/* sezioni crypt: Amministratore, Cartella Condivisa («shared», scelta dell'utente del 18/11), persone di users, poi gone */
let L = [ 'admin', 'shared' ], seen = { admin: true, shared: true }, us = type(N.users) == 'object' ? N.users : {};
for (let u in sort(keys(us))) if (!seen[u]) { seen[u] = true; push(L, u); }
for (let g in (type(N.gone) == 'array' ? N.gone : [])) if (type(g) == 'object' && type(g.user) == 'string' && !seen[g.user]) { seen[g.user] = true; push(L, g.user); }
let W = {}, out = [], pre = U.UDIR.root + '/';
for (let u in L) {
	let p = U.udir(u, 'root', null, N), s = U.crsec(a, u);
	if (type(p) != 'string' || substr(p, 0, length(pre)) != pre || s == null) continue;
	let v = substr(p, length(pre));
	if (!length(v) || index(v, '/') >= 0 || match(v, /[\t\n\r]/)) continue;
	W[s] = { type: 'crypt', remote: 'wfa' + substr(a, 1) + ':' + p, filename_encryption: 'standard', directory_name_encryption: 'true',
		filename_encoding: 'base32', password: pw };
	if (length(p2)) W[s].password2 = p2;
	push(out, u + '\t' + v + '\t' + s);
}
if (!length(out)) { print('none\n'); exit(0); }
fs.writefile(E('OUT'), sprintf('%J', W));
print('ok\n', join('\n', out), '\n');
ucode
)
crs() { A_=$A U=${WF_UCFGUC:-$D0/ucfg.uc} NJ=$ETC/nas.json OBF=$OBF O2F=$O2F RC=$RC OUT=$OUT ucode -e "$CRS_UC" </dev/null 2>/dev/null; }
crinit() {
A=$1; okid "$A" || { echo bad; exit 1; }
crcomm "$A" || { rm -f $T/.crkey; echo bad; exit 1; }
OBF=$T/.ob-cr-$A-1; O2F=$T/.ob-cr-$A-2; OUT=$T/.w-cr-$A
onexit "$OBF" "$O2F" "$OUT" "$OUT.conf" "$T/.cr-$A.raw" "$T/.cr-$A.cand"
( umask 077; : > "$OBF"; : > "$O2F"; : > "$OUT" )
command -v rclone >/dev/null 2>&1 || { echo retry; exit 2; }
}
cryptset() {
crinit "$1"
crob; [ $? = 2 ] && { echo retry; exit 2; }
o=$(crs); [ "${o%%
*}" = ok ] || { echo nokey; exit 1; }
rm -f "$OBF" "$O2F"
rcput "$OUT" || { echo retry; exit 2; }
crkdone; gen "$A"; echo ok
}
CAND_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, U = loadfile(E('U'))(), N = {}, X = {};
try { N = json(fs.readfile(E('NJ')) ?? '{}'); } catch (e) { N = {}; }
try { X = json(fs.readfile(E('XJ')) ?? '{}'); } catch (e) { X = {}; }
for (let l in split(fs.readfile(E('RAW')) ?? '', '\n')) {
	let d = substr(l, -1) == '/', n = replace(l, /\/$/, '');
	if (length(n) && U.cpriv([ U.UDIR.root, E('VIS'), n ], N, X) != null) print(n, '\t', d ? 'd' : 'f', '\n');
}
ucode
)
cryptadopt() {
crinit "$1"; mkdir -p $T/cr
crob; r=$?
[ $r = 1 ] && { echo nokey; exit 1; }
[ $r = 2 ] && { echo retry > $T/cr/$A.adopt; echo retry; exit 2; }
o=$(crs); [ "${o%%
*}" = ok ] || { echo nokey > $T/cr/$A.adopt; echo nokey; exit 1; }
( umask 077; M=put RC=$RC F=$OUT C=$OUT.conf ucode -e 'let fs = require("fs"), E = getenv, W = json(fs.readfile(E("F"))), o = [], skip = false;
		for (let l in split(fs.readfile(E("RC")) ?? "", "\n")) { let m = match(l, /^\[(.*)\][ \t]*$/); if (m) skip = exists(W, m[1]); if (!skip && length(trim(l))) push(o, l); }
		for (let s, kv in W) { push(o, "[" + s + "]"); for (let k, v in kv) push(o, k + " = " + v); }
		fs.writefile(E("C"), join("\n", o) + "\n");' </dev/null 2>/dev/null ) || { echo retry > $T/cr/$A.adopt; echo retry; exit 2; }
good=0; seen=0; TO=; command -v timeout >/dev/null 2>&1 && TO="timeout 120"
[ "$(js $ETC/cloud-cifra.json "let f = N.accts?.[\"$A\"]?.f ?? {}; for (let k, v in f) if (v == 'enc' || v == 'mig' || v == 'back') { print(1); break; }")" = 1 ] && seen=1
TAB=$(printf '\t')
while IFS=$TAB read -r _ vis sec; do
[ $good = 1 ] && break
[ -n "$sec" ] || continue
RCLONE_CONFIG=$OUT.conf $TO rclone lsf "wfa${A#a}:Utenti/$vis" </dev/null > $T/.cr-$A.raw 2>/dev/null; r=$?
[ $r = 3 ] && continue
[ $r = 0 ] || { echo retry > $T/cr/$A.adopt; echo retry; exit 2; }
U=${WF_UCFGUC:-$D0/ucfg.uc} NJ=$ETC/nas.json XJ=$XJ VIS=$vis RAW=$T/.cr-$A.raw ucode -e "$CAND_UC" </dev/null > $T/.cr-$A.cand 2>/dev/null
[ -s $T/.cr-$A.cand ] || continue
grep -qE "^[0-9a-v]{26,}$TAB" $T/.cr-$A.cand && seen=1
set --; while IFS=$TAB read -r n ty; do set -- "$@" "$n"; done < $T/.cr-$A.cand
RCLONE_CONFIG=$OUT.conf $TO rclone cryptdecode "$sec:" "$@" </dev/null 2>/dev/null > $T/.cr-$A.raw
while IFS= read -r l; do
case "$l" in *" $TAB Failed to decrypt") continue ;; *" $TAB "*) ;; *) continue ;; esac
n=${l%% "$TAB" *}; dn=${l#* "$TAB" }
ty=$(awk -F'\t' -v n="$n" '$1 == n { print $2; exit }' $T/.cr-$A.cand)
if [ "$ty" = d ]; then
RCLONE_CONFIG=$OUT.conf $TO rclone lsf --crypt-strict-names --max-depth 1 "$sec:$dn" </dev/null >/dev/null 2>&1 || continue
fi
good=1; break
done < $T/.cr-$A.raw
done <<-EOF
	$(printf '%s\n' "$o" | sed 1d)
	EOF
if [ $good = 0 ] && [ $seen = 1 ]; then crkdone; echo keybad > $T/cr/$A.adopt; echo keybad; exit 3; fi
rm -f "$OBF" "$O2F"
rcput "$OUT" || { echo retry > $T/cr/$A.adopt; echo retry; exit 2; }
crkdone; gen "$A"; echo ok > $T/cr/$A.adopt; echo ok
}
crrun() { sh "$D0/cloudcr.sh" "$1" "$2"; gen "$2"; }
crtick() {
[ -f $ETC/cloud-cifra.json ] && [ -f "$D0/cloudcr.sh" ] || return 0
booting && return 0
for l in $(js $ETC/cloud-cifra.json 'for (let a, o in (N.accts ?? {})) { if (o?.pause === true) continue; if (o?.st == "back") print(a, ":back:-\n"); else if ((o?.st == "mig" || o?.st == "on") && N.on === true && N.keyok === true) print(a, ":run:", o.st, "\n"); }'); do
a=${l%%:*}; okid "$a" || continue
m=${l#*:}; s=${m#*:}; m=${m%%:*}
alive "$(cat $T/cr/$a.lk/pid 2>/dev/null)" && continue
[ "$s" = on ] && [ "$(cat $T/cr/$a.nxt 2>/dev/null || echo 0)" -gt "$(date +%s)" ] 2>/dev/null && continue
bg crrun "$m" "$a"
done
}

uninstall() {
alive "$(cat $T/work.pid 2>/dev/null)" && kill "$(cat $T/work.pid)" 2>/dev/null
for f in $T/jobs/*.json; do [ -f "$f" ] && { p=$(js "$f" 'print(int(N.pid ?? 0));'); [ "${p:-0}" -gt 1 ] && alive "$p" && cl_kill "$p"; }; done
rm -f $RC $RC.old $ETC/cloud-links.json $ETC/cloud-sim.day $OLDRC.pre321 $ETC/cloud-kh-a*
rm -rf $ETC/cloud-photo $T
true
}

c=$1; [ $# -gt 0 ] && shift
case "$c" in
tick) tick ;;
work) work ;;
slot) s=$1; [ $# -gt 0 ] && shift
case "$s" in get) slot_get "$@" ;; put) slot_put "$@" ;; *) echo "uso: cloud.sh slot get|put <job> <acct>"; exit 2 ;; esac ;;
night) night ;;
heal) heal ;;
migrate) migrate ;;
uninstall) uninstall ;;
cryptset) cryptset "$@" ;;
cryptadopt) cryptadopt "$@" ;;
crtick) command -v rclone >/dev/null 2>&1 && crtick ;;
*) echo "uso: cloud.sh tick|work|slot|night|heal|migrate|uninstall|cryptset|cryptadopt|crtick"; exit 2 ;;
esac
