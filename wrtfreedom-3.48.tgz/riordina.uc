import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, readlink } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', NJ = ETC + '/nas.json';
const TMP = '/tmp/wf-riordina', STJ = TMP + '/state.json', NTMP = '/tmp/wf-nas', CTMP = '/tmp/wf-cloud';
const SELF = getenv('WF_RIORDINAUC') ?? '/usr/share/wrtfreedom/riordina.uc', UC = getenv('WF_UCODE') ?? 'ucode';
const VSH = getenv('WF_NASSH') ?? '/usr/share/wrtfreedom/nasvc.sh';
const SYSMNT = /^\/(|overlay|rom|boot|tmp|proc|sys|dev)$/;
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
const PRE = '.wf-sposta-';

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
const UROOT = UCFG?.UDIR?.root ?? 'Utenti', UDL = UCFG?.UDIR?.dl ?? 'Download';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { let t = f + '.' + PID + '.t'; writefile(t, sprintf('%J', o)); rename(t, f); }
function err(code, it, en) { return { error: it, error_en: en, code: code }; }
function alive(p) { return match('' + p, /^[0-9]+$/) != null && stat('/proc/' + p) != null; }
function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
function isdir(p) { let s = lstat(p); return s?.type == 'directory'; }
function mkdirp(p) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c); } }
function freename(e, taken) {
let m = match(e, /^(.+)(\.[^.\/]{1,8})$/), b = m ? m[1] : e, x = m ? m[2] : '';
for (let i = 2; i < 10000; i++) { let n = b + ' (' + i + ')' + x; if (!taken(n)) return n; }
return null;
}
function rmwork(p) { if (type(p) == 'string' && match(p, /\/\.wf-sposta-[0-9a-z]+$/)) sh('rm -rf ' + q(p) + ' 2>/dev/null'); }

function disks() {
let c = rjs(NTMP + '/x/disks.json');
if (type(c?.list) == 'array' && length(c.list)) return filter(c.list, (d) => type(d) == 'object' && length(d.mnt ?? ''));
let D = [], seen = {};
for (let l in split(readfile(R + '/proc/mounts') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) < 4 || substr(p[0], 0, 5) != '/dev/' || seen[p[0]]) continue;
let mnt = unoct(p[1]);
if (match(mnt, SYSMNT) || match(p[2], /^(squashfs|ubifs|jffs2|swap)$/)) continue;
seen[p[0]] = 1;
let dev = replace(p[0], /^.*\//, '');
push(D, { id: dev, dev: dev, name: dev, mnt: mnt, fs: p[2], ro: index(split(p[3], ','), 'ro') >= 0 });
}
return D;
}
function disk(id) { for (let d in disks()) if (d.id == id) return d; return null; }
function dfree(mnt) {
let L = split(trim(sh('df -Pk ' + q(mnt) + ' 2>/dev/null')), '\n'), p = split(replace(L[length(L) - 1] ?? '', /  +/g, ' '), ' ');
return length(L) > 1 && match(p[3] ?? '', /^[0-9]+$/) ? +p[3] * 1024 : null;
}

function running() {
let s = rjs(STJ);
if (s?.state != 'run') return false;
return s.pid ? alive(s.pid) : time() - (s.t ?? 0) < 30;
}
function busy(mnt) {
for (let d in [ NTMP + '/x', NTMP + '/jobs' ]) for (let f in (lsdir(d) ?? [])) {
if (!match(f, /\.json$/) || f == 'disks.json') continue;
let j = rjs(d + '/' + f);
if (type(j) == 'object' && j.state == 'run' && alive(j.pid)) return true;
}
for (let f in (lsdir(CTMP + '/jobs') ?? [])) {
let j = rjs(CTMP + '/jobs/' + f);
if (type(j) == 'object' && j.state == 'run') return true;
}
if (mnt) for (let u in (lsdir(mnt + '/' + UROOT) ?? []))
for (let f in (lsdir(mnt + '/' + UROOT + '/' + u + '/' + UDL + '/.wf-dl/job') ?? [])) if (match(f, /^[0-9a-f]{16}\.json$/)) return true;
return running();
}

function pair(to) {
let M = rjs(NJ)?.main, D = disks(), f = null, t = null;
if (type(M) != 'object' || !length(M.id ?? '')) return err('nomain', 'Manca il Disco Principale', 'Main Disk missing');
for (let d in D) { if (d.id == M.id) f = d; if (d.id == to) t = d; }
if (!t) return err('disk', 'Disco non trovato', 'Disk not found');
if (t.id == M.id || (f && f.mnt == t.mnt)) return err('same', 'È già il Disco Principale', 'Already the Main Disk');
if (t.ro === true) return err('ro', 'Disco in sola lettura', 'Read-only disk');
let DD = rjs(NJ)?.doppio;
if (type(DD) == 'object' && DD.on === true && DD.b == t.id)
return err('doppio', 'Spegni prima il Disco Doppio: questo disco tiene le sue copie', 'Turn off Mirrored Drive first: this drive holds its copies');
return { from: f, from_id: M.id, to: t, src: f != null && isdir(f.mnt + '/' + UROOT) };
}

function plan(to) {
let P = pair(to);
if (P.error) return P;
let dst = P.to.mnt + '/' + UROOT;
return { from: { id: P.from_id, name: P.from?.name ?? P.from_id, on: P.from != null }, to: { id: P.to.id, name: P.to.name ?? P.to.id,
fs: P.to.fs ?? '', free: dfree(P.to.mnt) }, src: P.src, dst: isdir(dst) && length(lsdir(dst) ?? []) > 0,
busy: busy(P.from?.mnt) };
}

function state() {
let s = rjs(STJ);
if (type(s) != 'object') return { state: 'idle', step: 0, steps: 0, cur: '', err: '', err_en: '', left: 0 };
let st = s.state ?? 'idle';
if (st == 'run' && !running()) return { state: 'err', step: s.step ?? 0, steps: s.steps ?? 0, cur: s.cur ?? '',
err: 'Spostamento interrotto: riprova', err_en: 'Move interrupted: try again', left: s.left ?? 0, to: s.to };
return { state: st, step: s.step ?? 0, steps: s.steps ?? 0, cur: s.cur ?? '', err: s.err ?? '', err_en: s.err_en ?? '',
left: s.left ?? 0, to: s.to };
}

function walk(base, rel, fn) {
for (let e in (lsdir(base + rel) ?? [])) {
let r = rel + '/' + e, s = lstat(base + r);
if (s == null) continue;
if (s.type == 'directory') walk(base, r, fn);
else fn(r, s);
}
}
function rdirs(p) {
for (let e in (lsdir(p) ?? [])) if (isdir(p + '/' + e)) rdirs(p + '/' + e);
rmdir(p);
}

function dmerge(src, dst, L) {
for (let e in (lsdir(src) ?? [])) {
let s = src + '/' + e, t = dst + '/' + e;
if (lstat(t) == null) { if (!rename(s, t)) return false; push(L, [ 'mv', s, t ]); }
else if (isdir(s) && isdir(t)) { if (!dmerge(s, t, L)) return false; }
else {
let n = freename(e, (x) => lstat(dst + '/' + x) != null);
if (n == null || !rename(s, dst + '/' + n)) return false;
push(L, [ 'mv', s, dst + '/' + n ]);
}
}
if (!rmdir(src)) return false;
push(L, [ 'rmdir', src ]);
return true;
}
function dmove(src, dst, L) {
if (lstat(dst) == null) {
if (!rename(src, dst)) return false;
push(L, [ 'mv', src, dst ]);
return true;
}
if (!isdir(dst)) return false;
return dmerge(src, dst, L);
}
function dundo(L) {
for (let i = length(L) - 1; i >= 0; i--) {
let o = L[i];
if (o[0] == 'mv') rename(o[2], o[1]);
else if (o[0] == 'rmdir') mkdir(o[1]);
}
}
function fin(L, p) {
for (let o in L) if (o[0] == 'mv' && (p == o[1] || substr(p, 0, length(o[1]) + 1) == o[1] + '/')) return o[2] + substr(p, length(o[1]));
return null;
}
function same(a, b) { return a != null && b != null && a.type == b.type && (a.type == 'link' || (a.size == b.size && a.mtime - b.mtime <= 2 && b.mtime - a.mtime <= 2)); }

function setmain(id, uuid) {
let ok = false;
for (let i = 0; i < 5 && !ok; i++) ok = UCFG.pidlock(UCFG.NJLK, NTMP, 30);
if (!ok) return false;
let r = false;
try {
let N = rjs(NJ);
if (type(N) == 'object') { N.main = { id: id, uuid: uuid ?? '' }; wjs(NJ, N); r = rjs(NJ)?.main?.id == id; }
} catch (e) { r = false; }
UCFG.pidunlock(UCFG.NJLK);
return r;
}

let ST = null;
function sput(o) { for (let k, v in o) ST[k] = v; ST.t = time(); wjs(STJ, ST); }
function fail(it, en) { sput({ state: 'err', err: it, err_en: en }); return false; }

function job() {
mkdirp(TMP);
ST = rjs(STJ) ?? {};
let to = ST.to, uuid = ST.uuid, fresh = ST.fresh === true;
sput({ state: 'run', pid: PID, step: 0, steps: 6, cur: '', err: '', err_en: '', left: 0 });
let P = pair(to);
if (P.error) return fail(P.error, P.error_en);
let dmnt = P.to.mnt, DST = dmnt + '/' + UROOT;
for (let e in (lsdir(dmnt) ?? [])) if (substr(e, 0, length(PRE)) == PRE) rmwork(dmnt + '/' + e);
if (!P.src) {
if (!fresh) return fail('Cartella ' + UROOT + ' non trovata sul Disco Principale di adesso', UROOT + ' folder not found on the current Main Disk');
mkdirp(DST);
if (!setmain(P.to.id, uuid)) return fail('Impostazioni non salvate: riprova', 'Settings not saved: try again');
sput({ state: 'ok', step: 6, cur: '' });
return true;
}
let SRC = P.from.mnt + '/' + UROOT, W = dmnt + '/' + PRE + (ST.job ?? time()), WU = W + '/' + UROOT, t0 = time();
sput({ step: 1, cur: 'space' });
let tot = 0;
walk(SRC, '', (r, s) => { if (s.type == 'file') tot += s.size; });
let fr = dfree(dmnt);
if (fr != null && fr < tot + 67108864)
return fail(sprintf('Spazio insufficiente sul disco nuovo: servono %.1f GB', (tot + 67108864) / 1073741824.0),
sprintf('Not enough space on the new disk: %.1f GB needed', (tot + 67108864) / 1073741824.0));
sput({ step: 2, cur: 'copy', bytes: tot });
mkdir(W, 0700);
sh('cp -a ' + q(SRC) + ' ' + q(W + '/') + ' </dev/null >/dev/null 2>&1');
sput({ step: 3, cur: 'check' });
let bad = 0;
walk(SRC, '', (r, s) => {
if (s.type != 'file') return;
let c = lstat(WU + r);
if ((c == null || c.size != s.size) && s.mtime < t0) bad++;
});
if (!isdir(WU) || bad) {
rmwork(W);
return fail('Copia non riuscita: niente è cambiato', 'Copy failed: nothing changed');
}
sput({ step: 4, cur: 'move' });
let L = [];
if (!dmove(WU, DST, L)) {
dundo(L); rmwork(W);
return fail('Spostamento non riuscito: niente è cambiato', 'Move failed: nothing changed');
}
sput({ step: 5, cur: 'main' });
if (!setmain(P.to.id, uuid)) {
dundo(L); rmwork(W);
return fail('Impostazioni non salvate: niente è cambiato', 'Settings not saved: nothing changed');
}
rmdir(W);
sput({ step: 6, cur: 'clean' });
let left = 0;
let dl = (p) => { let c = readlink(p) ?? ''; return match(c, /^msdfs:/) != null || c == '../' + (UCFG?.UDIR?.shared ?? 'Cartella Condivisa'); };
walk(SRC, '', (r, s) => {
if (same(s, lstat(fin(L, WU + r))) || (s.type == 'link' && dl(SRC + r))) unlink(SRC + r);
else left++;
});
rdirs(SRC);
sput({ cur: 'shares', left: left });
if (stat(VSH)) sh('sh ' + q(VSH) + ' follow </dev/null >/dev/null 2>&1');
sput({ state: 'ok', cur: '' });
return true;
}

if (getenv('WF_RIORDINA_JOB') == '1') { job(); exit(0); }

return {
riordina: {
args: { act: 'x', to: 'x', uuid: 'x', fresh: true },
call: function(req) {
let w = type(UCFG?.who) == 'function' ? UCFG.who(req) : null;
if (w?.adm !== true) return err('who', 'Solo l\'Amministratore', 'Administrator only');
let a = req?.args ?? {}, act = a.act;
if (act == 'state') return state();
if (act == 'plan') return plan(a.to);
if (act == 'go') {
let P = pair(a.to);
if (P.error) return P;
if (!P.src && a.fresh !== true) return err('nosrc', 'Cartella ' + UROOT + ' non trovata sul Disco Principale di adesso', UROOT + ' folder not found on the current Main Disk');
if (busy(P.from?.mnt)) return err('busy', 'Lavori in corso: riprova quando finiscono', 'Tasks running: try again when they finish');
let j = lc(substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10)) || ('' + time());
mkdirp(TMP);
wjs(STJ, { state: 'run', job: j, t: time(), step: 0, steps: 6, cur: '', err: '', err_en: '', left: 0,
to: P.to.id, uuid: a.uuid ?? '', fresh: a.fresh === true });
sh('( WF_RIORDINA_JOB=1 ' + UC + ' ' + q(SELF) + ' ) </dev/null >/dev/null 2>&1 &');
return { ok: true, job: j };
}
return err('act', 'Azione non valida', 'Invalid action');
}
}
};
