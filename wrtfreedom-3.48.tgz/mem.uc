import { readfile, writefile, rename, unlink, stat, lsdir, mkdir, rmdir } from 'fs';

const RT = getenv('WF_MEMROOT'), OW = stat('/etc/openwrt_release') != null, R = (RT && !OW) ? RT : '', SCR = OW || R != '';
const OUT = R + '/tmp/wf-mem.json', FR = R + '/tmp/wf-mem.freno.json', MRG = R + '/tmp/wf-mem.margine';
const PR = R + '/proc', CG = R + '/sys/fs/cgroup', WG = CG + '/wrtfreedom', SVD = CG + '/services';
const CFG = R + '/etc/config', ADGM = R + '/etc/wrtfreedom/mem-adg', UCP = R + '/tmp/.uci/adguardhome';
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
const HERE = replace(sourcepath() ?? '/usr/share/wrtfreedom/mem.uc', /\/[^\/]*$/, '') || '.';

const SV = {
rclone: { min: 75, cg: 'rclone', comm: [ 'rclone' ], cmd: [ ' mount ', '/tmp/wf-cloud/mnt/' ], go: true, vadj: 100 },
rclonepush: { min: 40, cg: 'rclonepush', comm: [ 'rclone' ], cmd: [ ' copyto ', '/tmp/wf-cloud/' ], go: true, adj: 400 },
rclonedlna: { min: 40, pd: 'wrtfreedom/clouddlna', comm: [ 'rclone' ], cmd: [ ' serve dlna ', '/tmp/wf-cloud/mnt/dlna.conf' ], go: true, adj: 300 },
aria2: { min: 8, pd: 'wf-nasdl', comm: [ 'aria2c' ], cmd: [ 'nas-aria2.conf' ], adj: 400 },
adguard: { min: 80, comm: [ 'AdGuardHome', 'adguardhome' ], go: true },
smbd: { min: 12, comm: [ 'smbd' ] },
minidlna: { min: 6, comm: [ 'minidlnad', 'minidlna' ] }
};
const ESS = { netifd: -500, hostapd: -500, wpa_supplicant: -500, dnsmasq: -500, rpcd: -500, uhttpd: -500, dropbear: -500,
odhcpd: -500, ubusd: -500, logd: -500, AdGuardHome: -300, adguardhome: -300 };
const LOW = [ 'network', 'wpad', 'hostapd', 'dnsmasq', 'rpcd', 'uhttpd', 'dropbear', 'odhcpd', 'log', 'adguardhome', 'AdGuardHome' ];

function mx(a, b) { return a > b ? a : b; }
function rt(f) { return trim(readfile(f) ?? ''); }
function num(s) { s = trim('' + (s ?? '')); return match(s, /^[0-9]+$/) ? +s : null; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { let t = f + '.' + PID + '.t'; if (writefile(t, sprintf('%J', o)) != null) rename(t, f); else unlink(t); }
function wr(f, v) { return SCR && writefile(f, '' + v) != null; }
function hasmem(s) { return match(s ?? '', /(^|[ +\n])memory([ \n]|$)/) != null; }
function rnd4(k) { return int((k + 3) / 4) * 4; }

function meminfo() {
let M = {};
for (let l in split(readfile(PR + '/meminfo') ?? '', '\n')) { let m = match(l, /^([A-Za-z0-9_]+):[ \t]+([0-9]+)/); if (m) M[m[1]] = +m[2]; }
return M;
}

function on(d) {
let f = d + '/cgroup.subtree_control';
if (hasmem(readfile(f))) return true;
wr(f, '+memory');
return hasmem(readfile(f));
}
function cgon() {
if (!hasmem(readfile(CG + '/cgroup.controllers')) || !on(CG)) return false;
if (!stat(WG) && SCR) mkdir(WG);
if (!stat(WG) || !on(WG)) return false;
if (stat(SVD)) on(SVD);
return true;
}

const SRA = /(^|\n)RssAnon:[ \t]+([0-9]+)/, SRS = /(^|\n)RssShmem:[ \t]+([0-9]+)/, SVR = /(^|\n)VmRSS:[ \t]+([0-9]+)/,
SVH = /(^|\n)VmHWM:[ \t]+([0-9]+)/;
function sf(s, r) { let m = match(s, r); return m ? +m[2] : null; }
function scan() {
let P = [];
for (let d in lsdir(PR) ?? []) {
if (!match(d, /^[0-9]+$/)) continue;
let c = rt(PR + '/' + d + '/comm');
if (!length(c)) continue;
let s = readfile(PR + '/' + d + '/status') ?? '', a = sf(s, SRA);
push(P, { pid: d, comm: c, rss: a != null ? a + (sf(s, SRS) ?? 0) : (sf(s, SVR) ?? 0), hwm: sf(s, SVH) ?? 0 });
}
return P;
}
function cls(p, cg) {
if (cg) {
p.cgr = rt(PR + '/' + p.pid + '/cgroup');
let m = match(p.cgr, /(^|\n)0::\/wrtfreedom\/([^\/\n]+)(\n|$)/);
if (m) for (let k, s in SV) if (s.cg == m[2]) return k;
}
for (let k, s in SV) {
if (index(s.comm, p.comm) < 0) continue;
if (!s.cmd) return k;
if (p.cmd == null) p.cmd = join(' ', split(readfile(PR + '/' + p.pid + '/cmdline') ?? '', chr(0)));
if (!length(filter(s.cmd, (x) => index(p.cmd, x) < 0))) return k;
}
return null;
}
function goenv(pid) {
for (let e in split(readfile(PR + '/' + pid + '/environ') ?? '', chr(0))) {
let m = match(e, /^GOMEMLIMIT=([0-9]+)(B|KiB|MiB|GiB)?$/);
if (!m) continue;
let n = +m[1], u = m[2] ?? 'B';
return int(u == 'GiB' ? n * 1048576 : (u == 'MiB' ? n * 1024 : (u == 'KiB' ? n : n / 1024)));
}
return 0;
}

function level(MB, h, p) {
let up = h >= int(MB / 4) ? 2 : (h >= int(MB / 8) ? 1 : 0);
if (type(p) != 'int' || p < 0 || p > 2 || up >= p) return up;
let z = int(MB / 32), keep = h >= int(MB / 4) - z ? 2 : (h >= int(MB / 8) - z ? 1 : 0);
return keep < p ? keep : p;
}

function lowset(f, mb) {
let o = num(readfile(f)), b = mb * 1048576;
if (o != null && o > 0 && (b > o ? b - o : o - b) * 4 <= o) return;
wr(f, b);
}
function low(MB) {
if (!stat(SVD)) return;
let W = {}, tot = 0, cap = mx(1, int(MB / 16));
for (let n in LOW) {
let c = num(readfile(SVD + '/' + n + '/memory.current'));
if (c == null) continue;
W[n] = mx(1, int((c * 5 / 4 + 1048575) / 1048576)); tot += W[n];
}
if (!tot) return;
if (tot > cap) { let s = 0; for (let n, v in W) { W[n] = mx(1, int(v * cap / tot)); s += W[n]; } tot = s; }
lowset(SVD + '/memory.low', tot);
for (let n, v in W) lowset(SVD + '/' + n + '/memory.low', v);
}

function mlim(t) { return match(t ?? '', /(^|\n)[ \t]*option[ \t]+memlimit[ \t]+'?([0-9]*)'?/); }
function adgsec(t) { return match(t ?? '', /(^|\n)[ \t]*config[ \t]+adguardhome[ \t]+'?config'?/) != null; }
function uci() { return 'uci -q ' + (R ? "-c '" + CFG + "' " : ''); }
function upend() { return (stat(UCP)?.size ?? 0) > 0; }
function adg(go) {
let t = readfile(CFG + '/adguardhome');
if (t == null || !adgsec(t)) return null;
let m = mlim(t), cur = m ? m[2] : '', mk = split(rt(ADGM), ' '), want = go * 1048576;
if (cur != '' && cur != '0' && cur != mk[0]) return { memlimit: +cur, nostro: false };
if (cur != '' && cur == mk[0] && (want > +cur ? want - +cur : +cur - want) * 5 <= +cur) return { memlimit: +cur, nostro: true };
if (!SCR || upend()) return { memlimit: +(cur || 0), nostro: cur != '' && cur == mk[0] };
if (system(uci() + 'set adguardhome.config.memlimit=' + want + ' && ' + uci() + 'commit adguardhome') != 0) return { memlimit: +(cur || 0), nostro: false };
writefile(ADGM, want + ' ' + (length(mk[0]) ? (mk[1] ?? '0') : (m ? (cur || '0') : '-')) + '\n');
return { memlimit: want, nostro: true };
}

function freni() { let o = rjs(FR); return type(o) == 'object' ? o : {}; }
function fcg(c) { return type(c) == 'string' && match(c, /^\/services\/[^\/]+$/) != null; }
function nomi() {
let J = rjs(HERE + '/custode/memoria.json'), N = {};
for (let k, v in type(J?.serv) == 'object' ? J.serv : {}) if (type(v?.nome) == 'array' && length(v.nome) == 2) N[k] = v.nome;
return N;
}

function marg(d) {
let f = split(rt(MRG), ' '), m = +f[0], s = +f[1], n = time();
return (length(f) == 3 && f[2] == d && m >= 1 && m <= 512 && s > n && s <= n + 3600) ? int(m) : 0;
}

function giro(boot) {
let M = meminfo(), tot = M.MemTotal ?? 0;
if (!tot) return null;
let av = M.MemAvailable ?? ((M.MemFree ?? 0) + (M.Cached ?? 0)), MB = int(tot / 1024), RIS = int(MB / 4);
let O = rjs(OUT) ?? {}, OS = O.serv ?? {}, cg = cgon(), G = {}, A = { n: 0, kb: 0 }, E = [], NP = {};
for (let k in SV) G[k] = [];
if (!boot)
for (let p in scan()) {
let k = cls(p, cg);
if (k) push(G[k], p);
else if (p.rss > 0) { A.n++; A.kb += p.rss; }
if (ESS[p.comm] != null) push(E, p);
}
let mint = 0;
for (let k, s in SV) { NP[k] = boot ? +(OS[k]?.n ?? 0) : length(G[k]); if (NP[k]) mint += s.min; }
let ris = mint * 4 > MB * 3, liv = ris ? 0 : level(MB, int(av / 1024) - RIS, O.liv), S = {}, ch = O.st == null;
for (let k, s in SV) {
let lo = mx(s.min, int(MB / 8)), hi = mx(lo, int(MB / 4)), t = [ lo, int((lo + hi) / 2), hi ][liv], o = OS[k] ?? {};
let x = { min: s.min * 1024, sol: lo * 1024, max: hi * 1024, tetto: t * 1024, n: NP[k], uso: boot ? +(o.uso ?? 0) : 0 };
if (s.go) x.go = int(t * 4 / 5) * 1024;
for (let p in G[k]) x.uso += p.rss;
if (s.cg || s.pd) {
x.nostro = true;
let d = s.cg ? WG + '/' + s.cg : SVD + '/' + s.pd;
if (s.cg && cg && !stat(d) && SCR) mkdir(d);
if (s.pd && cg && index(s.pd, '/') > 0 && stat(d)) on(SVD + '/' + split(s.pd, '/')[0]);
if (cg && stat(d) && (s.cg || x.n > 0)) {
let gv = 0, hw = 0;
for (let p in G[k]) {
if (s.cg && (p.cgr ?? rt(PR + '/' + p.pid + '/cgroup')) != '0::/wrtfreedom/' + s.cg) wr(d + '/cgroup.procs', p.pid);
let aj = s.adj;
if (s.vadj) {
if (p.cmd == null) p.cmd = join(' ', split(readfile(PR + '/' + p.pid + '/cmdline') ?? '', chr(0)));
if (match(p.cmd, /\/tmp\/wf-cloudmnt\/[^ \/]+\.p( |$)/)) aj = s.vadj;
}
if (aj && rt(PR + '/' + p.pid + '/oom_score_adj') == '0') wr(PR + '/' + p.pid + '/oom_score_adj', aj);
if (s.go) gv += goenv(p.pid);
hw += p.hwm ?? 0;
}
let h = mx(t, int((gv * 5 / 4 + 1023) / 1024)), oh = num(readfile(d + '/memory.high'));
let ms = readfile(d + '/memory.stat') ?? '', ma = match(ms, /(^|\n)anon ([0-9]+)/), mf = match(ms, /(^|\n)file ([0-9]+)/);
let fmb = 0, fst = mx(int(MB / 32), 1);
if (ma && mf && +ma[2] <= h * 1048576) {
fmb = (int(+mf[2] / 1048576 / fst) + 2) * fst;
if (fmb > int(MB / 4)) fmb = int(MB / 4);
}
h += fmb;
if (k == 'rclone') h += marg(d);
if (boot && oh != null) h = mx(h, int(oh / 1048576));
let hb = '' + (h * 1048576);
if (rt(d + '/memory.high') != hb) wr(d + '/memory.high', hb);
x.ok = rt(d + '/memory.high') == hb;
x.high = h * 1024;
if (x.ok) x.cg = d;
let c = num(readfile(d + '/memory.current')), pk = num(readfile(d + '/memory.peak'));
let e = match(readfile(d + '/memory.events') ?? '', /(^|\n)high ([0-9]+)/);
if (c != null && !boot) x.uso = int((c - (mf && +mf[2] <= c ? +mf[2] : 0)) / 1024);
if (pk != null) x.picco = int(pk / 1024);
else if (hw > 0 && !boot) x.picco = hw;
x.ev = e ? +e[2] : 0;
}
}
x.picco = mx(mx(x.picco ?? 0, o.picco ?? 0), x.uso);
if (o.tetto != x.tetto || o.high != x.high) ch = true;
S[k] = x;
}
let ne = 0;
if (cg && !boot) {
for (let p in E) {
let f = PR + '/' + p.pid + '/oom_score_adj', a = rt(f), v = '' + ESS[p.comm];
if (a == '0' && wr(f, v)) a = rt(f);
if (a == v) ne++;
}
low(MB);
if (stat(FR)) {
let F = freni(), via = filter(keys(F), (i) => !length(filter(type(F[i]?.cg) == 'array' ? F[i].cg : [],
(c) => fcg(c) && num(readfile(CG + c + '/memory.high')) != null)));
if (length(via)) { for (let i in via) delete F[i]; wjs(FR, F); }
}
}
let st = ris ? 'riserva' : (cg ? 'ok' : 'nocg');
if (st != O.st) ch = true;
let J = { v: 1, t: time(), up: int(+split(rt(PR + '/uptime'), ' ')[0] || 0), seq: (O.seq ?? 0) + (ch ? 1 : 0), st: st, cg: cg,
tot: tot, avail: av, ris: RIS * 1024, liv: liv, sotto: av < RIS * 1024 ? (O.sotto ?? 0) + 1 : 0, min: mint * 1024,
serv: S, altri: boot ? (O.altri ?? A) : A, ess: boot ? (O.ess ?? 0) : ne };
let ag = boot ? adg(int(S.adguard.sol / 1024 * 4 / 5)) : O.adg;
if (ag) J.adg = ag;
J.nomi = boot || type(O.nomi) != 'object' ? nomi() : O.nomi;
wjs(OUT, J);
return J;
}

function check(k) {
let s = SV[k];
if (!s) return null;
let M = meminfo(), av = M.MemAvailable ?? ((M.MemFree ?? 0) + (M.Cached ?? 0)), ris = int((M.MemTotal ?? 0) / 1024 / 4) * 1024;
let n = (rjs(OUT) ?? {}).serv?.[k]?.n ?? 0, dopo = av - (n ? 0 : s.min * 1024);
return { svc: k, ok: dopo >= ris, min: s.min * 1024, avail: av, ris: ris, dopo: dopo };
}

function dnsprova(t) {
let n = R ? (num(getenv('WF_MEMDNSN')) ?? 5) : 5, z = R ? (num(getenv('WF_MEMDNSS')) ?? 2) : 2;
let sh = [
"W='" + HERE + "'; T=; command -v timeout >/dev/null 2>&1 && T='timeout 2'; i=0",
'while [ $i -lt ' + n + ' ]; do sleep ' + z + '; o=$($T nslookup openwrt.org 127.0.0.1 2>&1) && exit 0',
'case "$o" in *"can\'t find"*|*NXDOMAIN*|*SERVFAIL*|*REFUSED*) exit 0 ;; esac; i=$((i + 1)); done',
'ucode "$W/mem.uc" freno adguard off ' + t + ' >/dev/null 2>&1 || exit 0',
'if [ "$(uci -q get wrtfreedom.ui.lang)" = en ]; then X="⚠️ AdGuard Home ¦ No DNS with the brake ¦ Brake removed"',
'else X="⚠️ AdGuard Home ¦ DNS muto col freno ¦ Freno tolto"; fi',
'sh "$W/event.sh" cron mem_freno sys "$X"'
];
system('( ' + join('\n', sh) + '\n) </dev/null >/dev/null 2>&1 &');
}

function freno(id, off, t0) {
let s = SV[id];
if (!SCR) return { error: 'non su un router' };
if (s?.cg || s?.pd) return { error: 'già frenato da WrtFreedom' };
if (!s) return { error: 'programma non valido' };
let J = rjs(OUT), x = J?.serv?.[id], F = freni();
if (type(x) != 'object') return { error: 'memoria non ancora letta' };
if (off) {
let f = F[id], L = filter(type(f?.cg) == 'array' ? f.cg : [], fcg);
if (t0 != null && +(f?.t ?? -1) != t0) return { error: 'freno cambiato' };
for (let c in L) if (stat(CG + c + '/memory.high')) wr(CG + c + '/memory.high', 'max');
if (f) { delete F[id]; wjs(FR, F); }
return { ok: true, id: id, cg: L, high: null };
}
if (J.cg !== true) return { error: 'freno non disponibile su questo router' };
let C = {}, gv = 0;
for (let p in lsdir(PR) ?? []) {
if (!match(p, /^[0-9]+$/) || index(s.comm, rt(PR + '/' + p + '/comm')) < 0) continue;
let m = match(readfile(PR + '/' + p + '/cgroup') ?? '', /(^|\n)0::(\/services\/[^\/\n]+)/);
if (!m) return { error: 'programma fuori dai servizi del router' };
C[m[2]] = true;
if (s.go) gv = mx(gv, goenv(p));
}
let L = sort(keys(C));
if (!length(L)) return { error: 'programma non acceso' };
for (let c in L) if (!stat(CG + c + '/memory.high')) return { error: 'freno non disponibile su questo router' };
let u = +(x.uso ?? 0);
for (let c in L) u = mx(u, int((num(readfile(CG + c + '/memory.current')) ?? 0) / 1024));
let h = mx(mx(+(x.max ?? 0), +(x.min ?? 0)), int(u * 5 / 4));
if (id == 'adguard') {
let m = mlim(readfile(CFG + '/adguardhome')), ml = mx(m ? +(m[2] || 0) : 0, +(J.adg?.memlimit ?? 0));
h = mx(h, mx(int(ml / 1024 * 5 / 4), int(gv * 5 / 4)));
}
h = rnd4(h);
if (h <= 0) return { error: 'memoria non ancora letta' };
for (let c in L) {
wr(CG + c + '/memory.high', h * 1024);
if (rt(CG + c + '/memory.high') == '' + h * 1024) continue;
for (let y in L) wr(CG + y + '/memory.high', 'max');
if (F[id]) { delete F[id]; wjs(FR, F); }
return { error: 'freno non scritto' };
}
let t = time();
F[id] = { cg: L, high: h, t: t };
wjs(FR, F);
if (id == 'adguard') dnsprova(t);
return { ok: true, id: id, cg: L, high: h };
}

function down() {
for (let d in lsdir(PR) ?? []) {
if (!match(d, /^[0-9]+$/)) continue;
let v = ESS[rt(PR + '/' + d + '/comm')], f = PR + '/' + d + '/oom_score_adj';
if (v != null && rt(f) == '' + v) wr(f, 0);
}
for (let f in [ SVD + '/memory.low', ...map(LOW, (n) => SVD + '/' + n + '/memory.low') ]) if (stat(f) && rt(f) != '0') wr(f, 0);
for (let i, f in freni()) for (let c in type(f?.cg) == 'array' ? f.cg : []) if (fcg(c) && stat(CG + c + '/memory.high')) wr(CG + c + '/memory.high', 'max');
unlink(FR);
for (let k, s in SV) {
let d = s.cg ? WG + '/' + s.cg : (s.pd ? SVD + '/' + s.pd : null);
if (d && stat(d + '/memory.high')) wr(d + '/memory.high', 'max');
if (s.cg && stat(d)) rmdir(d);
}
rmdir(WG);
let m = mlim(readfile(CFG + '/adguardhome')), mk = split(rt(ADGM), ' ');
if (SCR && m && length(mk[0]) && m[2] == mk[0]) {
if (upend()) return true;
let p = mk[1] ?? '0';
system(uci() + (p == '-' ? 'delete adguardhome.config.memlimit' : 'set adguardhome.config.memlimit=' + (num(p) ?? 0)) + ' && ' + uci() + 'commit adguardhome');
}
unlink(ADGM);
unlink(OUT);
return true;
}

const MEM = {
tick: function() { return giro(false); },
boot: function() { return giro(true); },
apply: function() { return giro(false); },
check: check,
freno: freno,
down: down
};

function prog() {
let c = split(readfile('/proc/self/cmdline') ?? '', chr(0)), a = ARGV ?? [];
if (length(c) && c[length(c) - 1] == '') pop(c);
let i = length(c) - length(a) - 1;
return i >= 1 && match(c[i] ?? '', /(^|\/)mem\.uc$/) != null;
}
if (prog()) {
let A0 = '' + (ARGV[0] ?? '');
if (A0 == 'check') {
let r = check('' + (ARGV[1] ?? ''));
print(sprintf('%J\n', r ?? { error: 'svc' }));
exit(r == null ? 2 : (r.ok ? 0 : 1));
}
if (A0 == 'freno') {
let r = freno('' + (ARGV[1] ?? ''), ARGV[2] == 'off', ARGV[2] == 'off' ? num(ARGV[3]) : null);
print(sprintf('%J\n', r));
exit(r.ok ? 0 : 1);
}
if (match(A0, /^(tick|boot|apply|down)$/)) exit(MEM[A0]() ? 0 : 1);
}

return MEM;
