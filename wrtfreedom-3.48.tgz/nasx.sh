#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH
R=; [ -n "$WF_NASROOT" ] && [ ! -e /etc/openwrt_release ] && R=$WF_NASROOT
W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; XJ=$ETC/nasx.json; NJ=$ETC/nas.json; OCONF=$ETC/nasx-rclone.conf; CDIR=$ETC/nasx-cloud
X=/tmp/wf-nas/x
mkdir -p $X
EN=0; [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { wf_evp "$1" nas "$2"; }
evc() { wf_evp "$1" cloud "$2"; }
for lb_f in "${0%/*}/lib.sh" "$W/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
pmsg() { case "$1" in
cloud_resync) printf '⚠️ %s ¦ %s' "$(t 'Sincronizzazione Cloud' 'Cloud Sync')" "$2$(t ': una sincronizzazione ferma' ': a sync is stopped')" ;;
cloud_conflict) printf '⚠️ %s ¦ %s' "$(t 'Sincronizzazione Cloud' 'Cloud Sync')" "$2$(t ': una sincronizzazione con conflitti' ': a sync with conflicts')" ;;
*) printf '⚠️ %s ¦ %s' "$(t 'Sincronizzazione Cloud' 'Cloud Sync')" "$2$(t ': una sincronizzazione non riesce' ': a sync fails')" ;;
esac; }
once() { f=$X/once.$1; n=$(date +%s); l=$(cat "$f" 2>/dev/null); [ -n "$l" ] && [ $((n - l)) -lt "$2" ] && return 1; echo "$n" > "$f"; }
short() { printf '%s' "$1" | awk '{ if (length($0) > 22) print substr($0, 1, 21) "…"; else print }'; }
jesc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r\t'; }
js() { ucode -e "let N = {}; try { N = json(require(\"fs\").readfile(\"$1\") ?? \"{}\"); } catch (e) {} $2" 2>/dev/null; }
mnt_of() { js $X/disks.json "for (let d in (N.list ?? [])) if (d.id == \"$1\") { print(d.mnt); break; }"; }
ro_of() { js $X/disks.json "for (let d in (N.list ?? [])) if (d.id == \"$1\") { print(d.ro ? 1 : 0); break; }"; }
SPD=${WF_NASPEED:-$W/naspeed.uc}
spd() { [ -n "$1" ] && [ $# -gt 1 ] && [ -f "$SPD" ] && ucode "$SPD" add "$@" </dev/null >/dev/null 2>&1; true; }
alive() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }
rcl() {
RL=$X/rc-$1.lock
until mkdir "$RL" 2>/dev/null; do
p=$(cat "$RL/pid" 2>/dev/null)
if [ -n "$p" ] && ! alive "$p"; then rm -rf "$RL"; continue; fi
if [ -z "$p" ] && [ $(( $(date +%s) - $(date -r "$RL" +%s 2>/dev/null || echo 0) )) -gt 60 ]; then rm -rf "$RL"; continue; fi
{ [ "$2" = 1 ] && [ ! -f "$X/cloud-$ID.stop" ]; } || { RL=; return 1; }
sleep 2
done
echo $$ > "$RL/pid"
}
rcu() { [ -n "$RL" ] && [ "$(cat "$RL/pid" 2>/dev/null)" = "$$" ] && rm -rf "$RL"; RL=; true; }
clload() {
command -v cl_check >/dev/null 2>&1 && return 0
[ -f $W/cloudline.sh ] && . $W/cloudline.sh
command -v cl_check >/dev/null 2>&1 && return 0
cl_check() { CL_WHY=; echo "ok off 0 fix"; }
cl_add() { true; }
cl_kill() { kill "$1" 2>/dev/null; true; }
cl_tier() { echo B; }
cl_why() { echo 'In attesa|Waiting'; }
}
cmem() {
sv_=
[ -n "$1" ] && sv_=$(js $ETC/cloud.json "for (let a in (N.accounts ?? [])) if (a.id == \"$1\") { print(a.svc ?? ''); break; }")
[ -z "$sv_" ] && [ -n "$2" ] && sv_=$(awk -v s="[$2]" '$0 == s { f = 1; next } /^\[/ { f = 0 } f && $1 == "type" { sub(/^[^=]*=[ \t]*/, ""); print; exit }' "$CONF" 2>/dev/null)
if command -v cl_env >/dev/null 2>&1; then
cl_env "$sv_"; MEMO=$CL_RMEM
[ -z "$CL_MOK" ] && [ "$(cl_tier)" = A ] && export GOGC=20
elif [ "$(cl_tier)" = A ]; then export GOGC=20; MEMO="--buffer-size 1M --transfers 1 --checkers 2"
else MEMO="--buffer-size 4M --transfers 2 --checkers 4"; fi
command -v cl_in >/dev/null 2>&1 || cl_in() { true; }
true
}
CLSH=${WF_CLOUDSH:-$W/cloud.sh}
sget() {
[ -f "$CLSH" ] || return 0
while :; do
o=$(sh "$CLSH" slot get "$1" "$2" $$ 2>/dev/null) && { SJ=$1; return 0; }
{ [ "$3" = 1 ] && [ ! -f "$X/cloud-$ID.stop" ]; } || { sh "$CLSH" slot put "$1" >/dev/null 2>&1; return 1; }
WHY=${o#wait }; WHY=${WHY%% *}; cw wait; sleep 5
done
}
sput() { [ -n "$SJ" ] && [ -f "$CLSH" ] && sh "$CLSH" slot put "$SJ" >/dev/null 2>&1; SJ=; true; }
cabout() {
f=$X/cloud-$ID.about; n=$(date +%s)
[ $((n - $(date -r "$f" +%s 2>/dev/null || echo 0))) -lt 3600 ] && return 0
o=$(rclone about "$1:" --json </dev/null 2>/dev/null | ucode -e 'let a = null; try { a = json(require("fs").stdin.read("all")); } catch (e) {} let r = { t: time() }; if (type(a) == "object") for (let k in [ "total", "used", "free", "trashed" ]) if (type(a[k]) == "int" && a[k] >= 0) r[k] = a[k]; if (r.free != null) printf("%J\n", r);' 2>/dev/null)
[ -n "$o" ] || return 0
echo "$o" > "$f.t" && mv "$f.t" "$f"
[ $((n - $(date -r $CDIR/$ID.about +%s 2>/dev/null || echo 0))) -ge 86400 ] && mkdir -p $CDIR && cp "$f" $CDIR/$ID.about.t && mv $CDIR/$ID.about.t $CDIR/$ID.about
true
}
cacct() {
o=$(js $XJ "for (let c in (N.cloud ?? [])) if (c.id == \"$1\") { print(c.acct ?? '', '|', c.mirror === true ? 1 : (c.mirror === false ? 0 : ''), '|', type(c.net) == 'object' ? sprintf('%J', c.net) : ''); break; }")
ACCT=${o%%|*}; o=${o#*|}; MIRROR=${o%%|*}; NET=${o#*|}
echo "$ACCT" | grep -qE '^a[0-9]{1,3}$' || ACCT=
[ -n "$NET" ] || NET='{"mode":"same"}'
}
rcv() {
v_=
for f_ in $R/lib/apk/db/installed $R/usr/lib/opkg/status; do
[ -f "$f_" ] || continue
v_=$(awk '/^$/ { o = 0; next } /^P:/ { o = ($0 == "P:rclone"); next } /^Package:/ { o = ($2 == "rclone"); next }
			o && /^V:/ { print substr($0, 3); exit } o && /^Version:/ { print $2; exit }' "$f_" 2>/dev/null)
[ -n "$v_" ] && break
done
[ -n "$v_" ] || v_=$(jsonfilter -q -i /tmp/wf-cloud/rclone.json -e '@.ver' 2>/dev/null)
printf '%s' "$v_" | sed -n 's/^[^0-9]*\([0-9][0-9]*\.[0-9][0-9]*\(\.[0-9][0-9]*\)\{0,1\}\).*/\1/p' | head -n 1
}
rcge() { w_=$(rcv); [ -z "$w_" ] || [ "$(printf '%s\n%s\n' "$1" "$w_" | sort -t. -k1,1n -k2,2n -k3,3n | head -n 1)" = "$1" ]; }
hdel() { case "$1" in drive) echo --drive-use-trash=false ;; onedrive) rcge 1.67 && echo --onedrive-hard-delete ;; esac; }

cw() {
wt=; [ -n "$WHY" ] && { if [ "$WHY" = resync ]; then wt='Da riallineare|Needs realigning'; else wt=$(cl_why "$WHY" 2>/dev/null); fi; }
printf '{"state":"%s","bytes":%s,"total":%s,"files":%s,"files_total":%s,"speed":%s,"t0":%s,"t":%s,"pid":%s,"err":"%s","err_en":"%s","why":"%s","why_t":"%s","why_en":"%s","conflicts":%s,"own":"%s"}\n' \
		"$1" "${2:-0}" "${3:-0}" "${4:-0}" "${5:-0}" "${6:-0}" "$T0" "$(date +%s)" "${CP:-$$}" "$(jesc "$7")" "$(jesc "$8")" "$WHY" "$(jesc "${wt%%|*}")" "$(jesc "${wt#*|}")" "${NC:-0}" "$(jesc "${OWN:-}")" > "$P.t" && mv "$P.t" "$P"
}
clast() {
l="$(date +%s) $1 ${2:-0} ${3:-0}"; echo "$l" > $X/cloud-$ID.last
o=$(cat $CDIR/$ID.last 2>/dev/null); ot=${o%% *}; oo=$(echo "$o" | cut -d' ' -f2)
{ [ "$oo" != "$1" ] || [ $(( $(date +%s) - ${ot:-0} )) -ge 21600 ]; } && mkdir -p $CDIR && echo "$l" > $CDIR/$ID.last
true
}
fail() {
WHY=; cw err 0 0 0 0 0 "$1" "$2"; [ "$DRY" = 1 ] && exit 0
rm -f "$X/cloud-$ID.due"; clast 0 0 0
once cloud-$ID 21600 && ev nas_cloud_err "⚠️ $(t 'Sincronizzazione Cloud' 'Cloud Sync') ¦ $(t "$1" "$2") ¦ $(short "$NAME")"; exit 0
}
cwait() { WHY=${1:-net}; cw wait "${2:-0}" 0 0 0 0; [ "$DRY" = 1 ] || : > "$X/cloud-$ID.due"; exit 0; }
cstop() { rm -f "$X/cloud-$ID.stop" "$X/cloud-$ID.due"; WHY=; cw stop; exit 0; }
cresync() {
mkdir -p "$CDIR"; [ -f "$CDIR/$ID.resync" ] || : > "$CDIR/$ID.resync"
if [ -n "$1" ] || [ -f "$CDIR/$ID.bisync" ]; then
once resync-$ID 21600 && evc cloud_resync "⚠️ $(t 'Sincronizzazione Cloud' 'Cloud Sync') ¦ $(short "$NAME") $(t ferma stopped) ¦ $(t "Riallinea dall'app" 'Realign from the app')"
fi
rm -f "$CDIR/$ID.bisync" "$X/cloud-$ID.due"
WHY=resync; cw err 0 0 0 0 0 "${1:-Da riallineare}" "${2:-Needs realigning}"; exit 0
}
cerr() {
if grep -qi 'token\|unauthor\|invalid_grant\|401' "$LOG" 2>/dev/null; then fail 'Collega di nuovo l'"'"'account' 'Connect the account again'
elif grep -qi 'quota\|storage.*full\|insufficient' "$LOG" 2>/dev/null; then fail 'Spazio del cloud finito' 'Cloud storage full'
elif grep -qi 'no such host\|dial tcp\|timeout\|network' "$LOG" 2>/dev/null; then fail 'Internet non raggiungibile' 'Internet not reachable'
else fail 'Non riuscita' 'Failed'; fi
}
cline() {
set -- $(cl_check "nx-$ID" "$NET" 2>/dev/null)
[ "$1" = ok ] || { LW=${2:-net}; return 1; }
LOPT=; [ -n "$2" ] && [ "$2" != off ] && LOPT="--bwlimit $2"
[ "${3:-0}" -gt 0 ] 2>/dev/null && LOPT="$LOPT --max-transfer $3 --cutoff-mode soft"
true
}
lempty() {
for f in "$L"/* "$L"/.[!.]* "$L"/..?*; do
[ -e "$f" ] || [ -L "$f" ] || continue
case ${f##*/} in .wf-*) ;; *) return 1 ;; esac
done
true
}
cjob() {
ID=$1; F=$CDIR/$ID.sh
echo "$ID" | grep -qE '^c[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
OWN=
. "$F"
mkdir $X/cloud-$ID.lock 2>/dev/null || { alive "$(cat $X/cloud-$ID.lock/pid 2>/dev/null)" && exit 0; rm -rf $X/cloud-$ID.lock; mkdir $X/cloud-$ID.lock || exit 0; }
echo $$ > $X/cloud-$ID.lock/pid; rm -f $X/cloud-$ID.stop
P=$X/cloud-$ID.json; [ "$DRY" = 1 ] && P=$X/cloud-$ID.dry.json
LOG=$X/cloud-$ID.log; T0=$(date +%s); CP=; RL=; SJ=; WHY=; NC=0; LW=
trap 'rm -rf $X/cloud-$ID.lock; rcu; sput' EXIT
clload; cw run
command -v rclone >/dev/null 2>&1 || fail 'Manca rclone' 'rclone missing'
M=$(mnt_of "$DISK"); [ -n "$M" ] && [ -d "$M$LPATH" ] || fail 'Disco non collegato' 'Drive not connected'
M=$M awk 'BEGIN { m = ENVIRON["M"] } { p = $2; gsub(/\\040/, " ", p); gsub(/\\011/, "\t", p); gsub(/\\012/, "\n", p); gsub(/\\134/, "\\\\", p); if (p == m) f = 1 } END { exit !f }' $R/proc/mounts 2>/dev/null || fail 'Disco non collegato' 'Drive not connected'
[ "$DIR" != up ] && [ "$(ro_of "$DISK")" = 1 ] && fail 'Disco in sola lettura' 'Drive is read-only'
L=$M$LPATH; STAMP=$(date +%Y%m%d-%H%M)
cacct "$ID"
if [ -n "$ACCT" ]; then SEC=${RSEC:-wfa${ACCT#a}}; CONF=$ETC/cloud-rclone.conf
else SEC=wfc$ID; CONF=$OCONF; grep -q "^\[$SEC\]" "$CONF" 2>/dev/null || fail 'Collega di nuovo l'"'"'account' 'Connect the account again'; fi
[ -n "$MIRROR" ] || { if [ -n "$ACCT" ]; then MIRROR=0; else MIRROR=1; fi; }
RM="$SEC:${REM#/}"
export RCLONE_CONFIG=$CONF RCLONE_CACHE_DIR=$X/rclone-cache
cline || cwait "$LW"
if [ -n "$ACCT" ]; then sget "nx-$ID" "$ACCT" 1 || cstop; else rcl "$SEC" 1 || cstop; fi
WHY=; cw run
cmem "$ACCT" "$SEC"
}
crun() {
: > "$LOG"
( cl_in; exec rclone "$@" $MEMO $LOPT --use-json-log --stats 2s --stats-log-level NOTICE --log-level NOTICE --log-file "$LOG" ) </dev/null >/dev/null 2>&1 & CP=$!
spd "$DISK" "$CP"
echo $CP > $X/cloud-$ID.lock/rpid
n=0; LS=0; B=0; N=0
while alive $CP; do
sleep 2; n=$((n + 2))
s=$(tail -c 16384 "$LOG" 2>/dev/null | grep '"stats"' | tail -n 1)
[ -n "$s" ] && set -- $(printf '%s' "$s" | ucode -e 'let s = {}; try { s = json(require("fs").stdin.read("all")).stats ?? {}; } catch (e) {} print(int(s.bytes ?? 0), " ", int(s.totalBytes ?? 0), " ", int(s.transfers ?? 0), " ", int(s.totalTransfers ?? 0), " ", int(s.speed ?? 0));' 2>/dev/null) && [ $# = 5 ] && { cw run "$@"; B=$1; }
[ "$(wc -c < "$LOG" 2>/dev/null)" -gt 262144 ] 2>/dev/null && { tail -n 200 "$LOG" > "$LOG.t"; cat "$LOG.t" > "$LOG"; rm -f "$LOG.t"; }
if [ $n -ge "${CL_EVERY:-60}" ]; then
n=0; [ "$B" -gt "$LS" ] 2>/dev/null && { cl_add $((B - LS)); LS=$B; }
cl_check "nx-$ID" "$NET" >/dev/null 2>&1 || { LW=${CL_WHY:-net}; cl_kill "$CP"; }
fi
done
wait $CP; rc=$?
s=$(grep '"stats"' "$LOG" 2>/dev/null | tail -n 1)
set -- $(printf '%s' "$s" | ucode -e 'let s = {}; try { s = json(require("fs").stdin.read("all")).stats ?? {}; } catch (e) {} print(int(s.bytes ?? 0), " ", int(s.transfers ?? 0));' 2>/dev/null)
B=${1:-0}; N=${2:-0}
[ "$B" -gt "$LS" ] 2>/dev/null && cl_add $((B - LS))
[ -f $X/cloud-$ID.stop ] && cstop
[ -n "$LW" ] && cwait "$LW" "$B"
[ "$rc" = 8 ] && cwait cap "$B"
true
}
cbisync() {
mkdir -p "$M/.wf-cloud/$ID"
BI="--workdir|$M/.wf-cloud/$ID|--resilient|--recover|--max-lock|2m|--backup-dir1|$M/.wf-cloud-old/$ID/$STAMP|--backup-dir2|$SEC:.wf-cloud-old/$ID/$STAMP|--conflict-resolve|newer|--conflict-loser|num"
}
ccjob() {
ID=$1; F=$CDIR/$ID.sh
echo "$ID" | grep -qE '^c[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
OWN=; SACCT=; SREM=; SRSEC=
. "$F"
mkdir $X/cloud-$ID.lock 2>/dev/null || { alive "$(cat $X/cloud-$ID.lock/pid 2>/dev/null)" && exit 0; rm -rf $X/cloud-$ID.lock; mkdir $X/cloud-$ID.lock || exit 0; }
echo $$ > $X/cloud-$ID.lock/pid; rm -f $X/cloud-$ID.stop
P=$X/cloud-$ID.json; LOG=$X/cloud-$ID.log; T0=$(date +%s); CP=; RL=; SJ=; WHY=; NC=0; LW=; DISK=
trap 'rm -rf $X/cloud-$ID.lock; rcu; sput' EXIT
clload; cw run
command -v rclone >/dev/null 2>&1 || fail 'Manca rclone' 'rclone missing'
[ "$DIR" = up ] || fail 'Fra due cloud solo da uno all'"'"'altro' 'Between two clouds only one way'
cacct "$ID"
echo "$SACCT" | grep -qE '^a[0-9]{1,3}$' && [ -n "$ACCT" ] && [ "$SACCT" != "$ACCT" ] || fail 'Collega di nuovo l'"'"'account' 'Connect the account again'
CONF=$ETC/cloud-rclone.conf; SEC=${RSEC:-wfa${ACCT#a}}; SS=${SRSEC:-wfa${SACCT#a}}
grep -q "^\[$SEC\]" "$CONF" 2>/dev/null && grep -q "^\[$SS\]" "$CONF" 2>/dev/null || fail 'Collega di nuovo l'"'"'account' 'Connect the account again'
[ -n "$MIRROR" ] || MIRROR=0
RM="$SEC:${REM#/}"; L="$SS:${SREM#/}"; STAMP=$(date +%Y%m%d-%H%M)
export RCLONE_CONFIG=$CONF RCLONE_CACHE_DIR=$X/rclone-cache
cline || cwait "$LW"
case "$(ccoth "$SACCT")$(ccoth "$ACCT")" in
*relink*) fail 'Collega di nuovo l'"'"'account' 'Connect the account again' ;;
*ppause*) cwait ppause ;;
esac
sget "nx-$ID" "$ACCT" 1 || cstop
k_=/tmp/wf-cloud/acct-$SACCT.lock
if [ -d "$k_" ] && [ "$(cat "$k_/job" 2>/dev/null)" != "nx-$ID" ] && alive "$(cat "$k_/pid" 2>/dev/null)"; then sput; cwait acct; fi
WHY=; cw run
cmem "$ACCT"
}
ccoth() {
XA=$1 XS=/tmp/wf-cloud/state.json XF=$ETC/cloud.json ucode -e 'let fs = require("fs"), r = (f) => { let v = null; try { v = json(fs.readfile(f) ?? "{}"); } catch (e) {} return type(v) == "object" ? v : {}; };
		let S = r(getenv("XS")), N = r(getenv("XF")), a = getenv("XA");
		if (S.accts?.[a]?.st == "relink") print("relink");
		else for (let x in (N.accounts ?? [])) if (x?.id == a && length(x.user ?? "") && x.user != "admin" && N.ppause?.[x.user] === true) { print("ppause"); break; }' 2>/dev/null
}
cloudcc() {
DRY=0; ccjob "$1"
if [ -f $X/cloud-$ID.last ] || [ -f $CDIR/$ID.last ]; then
[ -n "$(rclone lsf --max-depth 1 --exclude '.wf-*/**' --exclude '.wf-*' "$L" </dev/null 2>/dev/null | head -n 1)" ] || fail 'Cartella del cloud vuota' 'Cloud folder empty'
fi
m=copy; [ "$MIRROR" = 1 ] && m=sync
crun $m "$L" "$RM" --backup-dir "$SEC:.wf-cloud-old/$ID/$STAMP" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart'
[ "$rc" != 0 ] && cerr
rm -f "$X/cloud-$ID.due"
[ -f $X/once.cloud-$ID ] && { rm -f "$X/once.cloud-$ID"; ev nas_cloud_ok "🗄️ $(t 'Sincronizzazione Cloud' 'Cloud Sync') ¦ $(t 'Di nuovo riuscita' 'Working again') ¦ $(short "$NAME")"; }
cw ok "$B" "$B" "$N" "$N" 0; clast 1 "$B" "$N"
true
}
cloud() {
grep -q "^SACCT='a[0-9]*'\$" "$CDIR/$1.sh" 2>/dev/null && { cloudcc "$1"; return; }
DRY=0; cjob "$1"
case "$DIR" in
up) lempty && fail 'Cartella del disco vuota' 'Drive folder empty'
m=copy; [ "$MIRROR" = 1 ] && m=sync
set -- $m "$L" "$RM" --backup-dir "$SEC:.wf-cloud-old/$ID/$STAMP" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart' ;;
down) if [ -f $X/cloud-$ID.last ] || [ -f $CDIR/$ID.last ]; then
[ -n "$(rclone lsf --max-depth 1 --exclude '.wf-*/**' --exclude '.wf-*' "$RM" </dev/null 2>/dev/null | head -n 1)" ] || fail 'Cartella del cloud vuota' 'Cloud folder empty'
fi
set -- sync "$RM" "$L" --backup-dir "$M/.wf-cloud-old/$ID/$STAMP" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart' ;;
both) rcge 1.66 || fail 'Aggiorna rclone (serve la 1.66)' 'Update rclone (1.66 needed)'
lempty && [ -f $CDIR/$ID.bisync ] && cresync 'Cartella del disco vuota' 'Drive folder empty'
{ [ -f $CDIR/$ID.bisync ] && [ ! -f $CDIR/$ID.resync ]; } || cresync
cbisync; OIFS=$IFS; IFS='|'
set -- bisync "$L" "$RM" $BI
IFS=$OIFS
[ -f $CDIR/$ID.chk ] && set -- "$@" --check-access --check-filename .wf-check
set -- "$@" --filter '+ /.wf-check' --filter '- .wf-*/**' --filter '- .wf-*' --filter '- .*.wfpart' ;;
*) fail 'Verso non valido' 'Invalid direction' ;;
esac
crun "$@"
if [ "$DIR" = both ]; then
NC=$(grep -c 'New or changed in both paths' "$LOG" 2>/dev/null); NC=${NC:-0}
if [ "$NC" -gt 0 ] 2>/dev/null; then
o=$(cut -d' ' -f1 $CDIR/$ID.conflicts 2>/dev/null); echo "$(( ${o:-0} + NC )) $(date +%s)" > $CDIR/$ID.conflicts
evc cloud_conflict "⚠️ $(t 'Sincronizzazione Cloud' 'Cloud Sync') ¦ $(short "$NAME") ¦ $NC $(t conflitti conflicts)"
fi
[ "$rc" = 7 ] && grep -qi 'Must run --resync\|check file check failed\|access test failed' "$LOG" 2>/dev/null && cresync
fi
[ "$rc" != 0 ] && cerr
[ "$DIR" = both ] && [ ! -f $CDIR/$ID.bisync ] && : > $CDIR/$ID.bisync
rm -f "$X/cloud-$ID.due"
[ -f $X/once.cloud-$ID ] && { rm -f "$X/once.cloud-$ID"; ev nas_cloud_ok "🗄️ $(t 'Sincronizzazione Cloud' 'Cloud Sync') ¦ $(t 'Di nuovo riuscita' 'Working again') ¦ $(short "$NAME")"; }
cw ok "$B" "$B" "$N" "$N" 0; clast 1 "$B" "$N"
[ -z "$ACCT" ] && cabout "$SEC"
true
}
resync() {
case "$2" in dry) DRY=1 ;; ok) DRY=0 ;; *) exit 2 ;; esac
cjob "$1"
[ "$DIR" = both ] || fail 'Verso non valido' 'Invalid direction'
rcge 1.66 || fail 'Aggiorna rclone (serve la 1.66)' 'Update rclone (1.66 needed)'
cbisync
[ $DRY = 1 ] || : > "$L/.wf-check" || fail 'Disco in sola lettura' 'Drive is read-only'
OIFS=$IFS; IFS='|'
set -- bisync "$L" "$RM" $BI
IFS=$OIFS
set -- "$@" --resync --resync-mode newer
[ $DRY = 1 ] && set -- "$@" --dry-run
set -- "$@" --filter '+ /.wf-check' --filter '- .wf-*/**' --filter '- .wf-*' --filter '- .*.wfpart'
crun "$@"
[ "$rc" != 0 ] && cerr
[ $DRY = 1 ] && { cw ok "$B" "$B" "$N" "$N" 0; exit 0; }
mkdir -p "$CDIR"; : > "$CDIR/$ID.bisync"; : > "$CDIR/$ID.chk"
rm -f "$CDIR/$ID.resync" "$X/once.resync-$ID" "$X/once.cloud-$ID" "$X/cloud-$ID.due"
cw ok "$B" "$B" "$N" "$N" 0; clast 1 "$B" "$N"
}
cloudstop() {
echo "$1" | grep -qE '^c[0-9a-z]{1,16}$' || return 0
alive "$(cat $X/cloud-$1.lock/pid 2>/dev/null)" || return 0
: > $X/cloud-$1.stop; p=$(cat $X/cloud-$1.lock/rpid 2>/dev/null); alive "$p" && kill "$p" 2>/dev/null; true
}
oldrm() {
ID=$1; echo "$ID" | grep -qE '^c[0-9a-z]{1,16}$' || return 0
f=$CDIR/oldrm-$ID
if [ -n "$2" ]; then echo "$2" | grep -qE '^a[0-9]{1,3}$' || return 0; mkdir -p "$CDIR"; echo "$2" > "$f.t" && mv "$f.t" "$f"; fi
A=$(cat "$f" 2>/dev/null); echo "$A" | grep -qE '^a[0-9]{1,3}$' || { rm -f "$f"; return 0; }
command -v rclone >/dev/null 2>&1 || return 0
clload; SJ=
sget "nxdel-$ID" "$A" || return 0
trap 'sput' EXIT
export RCLONE_CONFIG=$ETC/cloud-rclone.conf RCLONE_CACHE_DIR=$X/rclone-cache
sv=$(js $ETC/cloud.json "for (let a in (N.accounts ?? [])) if (a.id == \"$A\") { print(a.svc ?? ''); break; }")
if rclone purge $(hdel "$sv") "wfa${A#a}:.wf-cloud-old/$ID" </dev/null >/dev/null 2>"$X/oldrm-$ID.err" || grep -qi 'not found' "$X/oldrm-$ID.err"; then rm -f "$f"; fi
rm -f "$X/oldrm-$ID.err"; sput
true
}

prep() {
mkdir -p $X/www $X/wwwr $X/hits $X/bad $X/up
for k in s t u r p c n foto; do [ -L $X/www/$k ] || { rm -rf $X/www/$k; ln -s $W/nasx.cgi $X/www/$k; }; done
for k in s t u r p c n foto; do [ -L $X/wwwr/$k ] || { rm -rf $X/wwwr/$k; ln -s $W/nasx.cgi $X/wwwr/$k; }; done
[ -L $X/wwwr/app ] || { rm -rf $X/wwwr/app; ln -s $R/www/wrtfreedom $X/wwwr/app; }
true
}
NFTA=$R/usr/share/nftables.d/chain-pre
nftdel() { rm -f $NFTA/input_*/wf-nasx-allow.nft 2>/dev/null; true; }
svc() {
i=$R/etc/init.d/wf-nasx
[ -f "$i" ] || return 0
if [ "$1" = on ]; then prep; $i enable >/dev/null 2>&1; $i restart >/dev/null 2>&1
else $i stop >/dev/null 2>&1; $i disable >/dev/null 2>&1; fi
}
fwdel() { for s in $(uci -q show firewall | sed -n "s/^firewall\.\(wf_nasx_[A-Za-z0-9_]*\)=rule$/\1/p"); do uci -q delete firewall.$s; done; uci -q commit firewall; }
fw() {
command -v fw4 >/dev/null 2>&1 || { [ -f $X/fw.fp.new ] && mv -f $X/fw.fp.new $X/fw.fp; return 0; }
G=0; i=0
while [ $i -lt 30 ]; do
mkdir /tmp/wf-fw.lock 2>/dev/null && { G=1; break; }
lt=$(date -r /tmp/wf-fw.lock +%s 2>/dev/null)
if [ -n "$lt" ] && [ $(( $(date +%s) - lt )) -gt 120 ]; then rmdir /tmp/wf-fw.lock 2>/dev/null; else sleep 1; fi
i=$((i + 1))
done
if fw4 -q check >/dev/null 2>&1; then
[ -f $X/fw.fp.new ] && mv -f $X/fw.fp.new $X/fw.fp
else
fwdel; nftdel; rm -f $X/fw.fp; [ -f $X/fw.fp.new ] && mv -f $X/fw.fp.new $X/fw.fp.bad
once nas_fw 21600 && ev nas_fw "⚠️ $(t 'Link Di Condivisione' 'Sharing Links') ¦ $(t 'Regole del Firewall rifiutate' 'Firewall rules rejected') ¦ $(t 'Tolte, porte chiuse' 'Removed, ports closed')"
fi
fw4 -q reload >/dev/null 2>&1
[ $G = 1 ] && rmdir /tmp/wf-fw.lock; true
}
netclose() {
ubus call wrtfreedom nas_link '{"act":"close"}' >/dev/null 2>&1 || { sleep 5; ubus call wrtfreedom nas_link '{"act":"close"}' >/dev/null 2>&1; } ||
ucode -e "loadfile('${WF_NASXUC:-$W/nasx.uc}')().nas_link.call({ args: { act: 'close' } });" >/dev/null 2>&1
ev nas_link_fails "⚠️ $(t 'Link Di Condivisione' 'Sharing Links') ¦ $(t 'Troppi tentativi in un'"'"'ora' 'Too many attempts in an hour') ¦ $(t 'Porta chiusa' 'Port closed')"
}
probe() {
case "$1" in https://*/p/*) ;; *) return 0 ;; esac
command -v uclient-fetch >/dev/null 2>&1 || return 0
uclient-fetch -q -T 15 -O /dev/null "$1" >/dev/null 2>&1; true
}

tick() {
[ -f $XJ ] || return 0
if [ "$(js $XJ 'print(length(N.link?.list ?? []) || length(N.req ?? []) ? 1 : 0);')" = 1 ] || [ -n "$(ls $X/st 2>/dev/null)" ] || [ -f $X/up.json ] || [ -f /tmp/wf-nas/invite.json ] || [ -f $R/etc/init.d/wf-nasx ] || [ -f $ETC/nasx-parts ]; then
ubus call wrtfreedom nas_link '{"act":"tick"}' >/dev/null 2>&1
fi
[ "$(js $NJ 'print(N.on === false ? 0 : 1);')" = 0 ] && return 0
H=$(date +%H); Mi=$(date +%M); H=${H#0}; Mi=${Mi#0}; cur=$((H * 60 + Mi)); day=$(date +%Y%m%d); now=$(date +%s); due=
for f in $CDIR/c*.sh; do
[ -f "$f" ] || continue
id=$(basename "$f" .sh)
grep -q '^ON=1$' "$f" || continue
alive "$(cat $X/cloud-$id.lock/pid 2>/dev/null)" && continue
[ -f $CDIR/$id.resync ] && continue
[ -f $X/cloud-$id.due ] && { due="$due $id"; continue; }
at=$(sed -n "s/^AT='\([0-9][0-9]:[0-9][0-9]\)'$/\1/p" "$f"); ev_=$(sed -n 's/^EVERY=\([0-9]*\)$/\1/p' "$f")
if [ -n "$at" ]; then
ah=${at%:*}; am=${at#*:}; d=$((cur - ${ah#0} * 60 - ${am#0}))
[ $d -ge 0 ] && [ $d -lt 5 ] && [ "$(cat $X/cloud-$id.day 2>/dev/null)" != "$day" ] && { echo "$day" > $X/cloud-$id.day; due="$due $id"; }
elif [ "${ev_:-0}" -gt 0 ]; then
l=$(cut -d' ' -f1 $X/cloud-$id.last 2>/dev/null); [ -n "$l" ] || l=$(cut -d' ' -f1 $CDIR/$id.last 2>/dev/null)
[ $((now - ${l:-0} + 60)) -ge $((ev_ * 60)) ] && due="$due $id"
fi
done
old=0
if [ "$H" = 4 ] && [ "$Mi" -lt 5 ]; then
old=1
js $X/disks.json 'for (let d in (N.list ?? [])) if (!d.ro) print(d.mnt, "\n");' | while IFS= read -r m; do
[ -d "$m/.wf-cloud-old" ] && find "$m/.wf-cloud-old" -mindepth 2 -maxdepth 2 -type d -mtime +30 -exec rm -rf {} \; 2>/dev/null
done
fi
rm_=; for f in $CDIR/oldrm-c*; do [ -f "$f" ] && rm_="$rm_ ${f##*/oldrm-}"; done
{ [ -n "$due" ] || [ $old = 1 ] || [ -n "$rm_" ]; } && ( for id in $due; do sh "$0" cloud "$id"; done; for id in $rm_; do sh "$0" oldrm "$id"; done; [ $old = 1 ] && sh "$0" cloudold ) </dev/null >/dev/null 2>&1 &
true
}
cloudold() {
command -v rclone >/dev/null 2>&1 || return 0
mkdir $X/cloudold.lock 2>/dev/null || { alive "$(cat $X/cloudold.lock/pid 2>/dev/null)" && return 0; rm -rf $X/cloudold.lock; mkdir $X/cloudold.lock || return 0; }
echo $$ > $X/cloudold.lock/pid; RL=; SJ=
trap 'rm -rf $X/cloudold.lock; rcu; sput' EXIT
clload
now=$(date +%s)
for f in $CDIR/c*.sh; do
[ -f "$f" ] || continue
id=$(basename "$f" .sh); ID=$id
cacct "$id"
kd=$(js $XJ "for (let c in (N.cloud ?? [])) if (c.id == \"$id\") { let k = c.keep_days; if (type(k) == 'int' && k >= 1 && k <= 3650) print(k); break; }")
[ -n "$kd" ] || kd=30
old=$(date -d @$(( now - kd * 86400 )) +%Y%m%d 2>/dev/null) || continue
if [ -n "$ACCT" ]; then
RSEC=$(sed -n "s/^RSEC='\([A-Za-z0-9_]*\)'\$/\1/p" "$CDIR/$id.sh" 2>/dev/null | head -n 1)
SEC=${RSEC:-wfa${ACCT#a}}; export RCLONE_CONFIG=$ETC/cloud-rclone.conf
sget "nxold-$id" "$ACCT" || continue
sv=$(js $ETC/cloud.json "for (let a in (N.accounts ?? [])) if (a.id == \"$ACCT\") { print(a.svc ?? ''); break; }")
else
SEC=wfc$id; export RCLONE_CONFIG=$OCONF
grep -q "^\[$SEC\]" "$OCONF" 2>/dev/null && rcl "$SEC" || continue
sv=$(sed -n "s/^PROV='\(.*\)'$/\1/p" "$f")
fi
export RCLONE_CACHE_DIR=$X/rclone-cache
set -- $(hdel "$sv")
ls_=$(rclone lsf --dirs-only --max-depth 1 "$SEC:.wf-cloud-old/$id" </dev/null 2>/dev/null)
printf '%s\n' "$ls_" | while IFS= read -r d; do
d=${d%/}
case "$d" in [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]) ;; *) continue ;; esac
[ "${d%-*}" -lt "$old" ] && rclone purge "$@" "$SEC:.wf-cloud-old/$id/$d" </dev/null >/dev/null 2>&1
done
if ! grep -q "^DIR='down'$" "$f"; then
b=$(rclone size --json "$SEC:.wf-cloud-old/$id" </dev/null 2>/dev/null | ucode -e 'let a = null; try { a = json(require("fs").stdin.read("all")); } catch (e) {} if (type(a?.bytes) == "int" && a.bytes >= 0) print(a.bytes);' 2>/dev/null)
[ -n "$b" ] && echo "$b $(date +%s)" > $CDIR/$id.oldb
fi
rcu; sput
done
true
}

uninstall() {
for p in $(cat $X/cloud-*.lock/rpid 2>/dev/null); do kill "$p" 2>/dev/null; done
I=$R/etc/init.d/wf-nasx
[ -f $I ] && { $I stop; $I disable; rm -f $I; } >/dev/null 2>&1
fwdel; nftdel; command -v fw4 >/dev/null 2>&1 && fw4 -q reload >/dev/null 2>&1
rm -rf $XJ $OCONF $CDIR $ETC/nasx-web.conf $ETC/nasx.key $ETC/nasx-parts $X
}

c=$1; [ $# -gt 0 ] && shift
case "$c" in
tick) tick ;;
cloud) cloud "$@" ;;
cloudstop) cloudstop "$@" ;;
cloudold) cloudold ;;
resync) resync "$@" ;;
oldrm) oldrm "$@" ;;
prep) prep ;;
svc) svc "$@" ;;
fw) fw ;;
netclose) netclose ;;
probe) probe "$@" ;;
uninstall) uninstall ;;
*) echo "uso: nasx.sh tick|cloud|resync|cloudstop|cloudold|oldrm|prep|svc|fw|netclose|probe|uninstall"; exit 2 ;;
esac
