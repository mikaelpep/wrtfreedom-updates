'use strict';
import { popen, readfile, writefile, rename, mkdir, stat, unlink, lsdir } from 'fs';

const T = getenv('WF_SQMTMP') ?? '/tmp', LAG = T + '/wf-sqmlag.json', H = T + '/wf-sqmh.json', ST = T + '/wf-sqm.tick';
const HE = getenv('WF_SQMHE') ?? '/etc/wrtfreedom/sqmh.json', EVSH = getenv('WF_EVSH') ?? '/usr/share/wrtfreedom/event.sh';
const SYSNET = getenv('WF_SYSNET') ?? '/sys/class/net';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, /'/g, "'\\''") + "'"; }
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function num(f) { let v = trim(readfile(f) ?? ''); return match(v, /^[0-9]+$/) ? +v : null; }
const CFGW = (getenv('WF_CFGDIR') ?? '/etc/config/') + 'wrtfreedom';
let ENL = null;
function en() {
if (ENL != null) return ENL;
let s = false;
ENL = false;
for (let l in split(readfile(CFGW) ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == 'ui'; continue; }
let m = s ? match(l, /^[[:blank:]]*option lang '?([^']*)'?[[:blank:]]*$/) : null;
if (m) { ENL = m[1] == 'en'; break; }
}
return ENL;
}
function sqmget() {
let c = null;
try { c = require('ubus').connect(null, 10); } catch (e) { c = null; }
if (c) { let r = c.call('wrtfreedom', 'sqm', {}); try { c.disconnect(); } catch (e) {} return r; }
try { return json(sh('ubus -t 10 call wrtfreedom sqm 2>/dev/null') || 'null'); } catch (e) { return null; }
}

function kbit(n, u) { return int(+n * ({ K: 1, M: 1000, G: 1000000 }[u] ?? 0.001)); }

let ARH = null;
function arlag(cf, P) {
let m = match(cf, /config\.([A-Za-z0-9_-]+)\.sh$/);
if (!m) return null;
let ov = match(readfile(cf) ?? '', /(^|\n)[ \t]*log_file_path_override=["']?([^"' \t\n#]+)/);
let lf = getenv('WF_ARLOG') ?? (ov ? ov[2] : '/var/log/cake-autorate.' + m[1] + '.log');
let fs = stat(lf);
if (!fs) return null;
let C = type(P?.arh) == 'object' ? P.arh : {}, hd = '', pf = readfile(lf, 128) ?? '';
if (C.f == lf && C.i == fs.inode && +C.s <= fs.size && C.p == pf && length(C.h ?? '')) hd = C.h;
else {
let rx = '"^\\(DATA_\\)\\{0,1\\}HEADER;"';
hd = trim(sh('grep -m1 ' + rx + ' ' + q(lf) + ' 2>/dev/null')) || trim(sh('grep -m1 ' + rx + ' ' + q(lf + '.old') + ' 2>/dev/null'));
}
if (!length(hd)) return null;
ARH = { f: lf, i: fs.inode, s: fs.size, p: pf, h: hd };
let H = map(split(hd, ';'), (x) => trim(x));
let N = H[0] == 'DATA_HEADER' ? H : slice(H, 1), ix = (k) => index(N, k);
let dd = ix('DL_OWD_DELTA_US'), ud = ix('UL_OWD_DELTA_US'), dc = ix('DL_LOAD_CONDITION'), uc = ix('UL_LOAD_CONDITION');
if (dd < 0 || ud < 0 || dc < 0 || uc < 0) return null;
let s = 0, n = 0;
for (let l in split(sh('tail -n 600 ' + q(lf) + ' 2>/dev/null'), '\n')) {
if (substr(l, 0, 5) != 'DATA;') continue;
let F = map(split(l, ';'), (x) => trim(x)), a = F[dd], b = F[ud];
if (!match(F[dc] ?? '', /high/) && !match(F[uc] ?? '', /high/)) continue;
if (!match(a ?? '', /^-?[0-9]+(\.[0-9]+)?$/) || !match(b ?? '', /^-?[0-9]+(\.[0-9]+)?$/)) continue;
s += +a + +b; n++;
}
if (n < 5) return null;
let v = s / n / 1000;
return v > 0 ? int(v + 0.5) : 0;
}

function save() {
let o = rjs(H);
if (!o) return;
mkdir('/etc/wrtfreedom');
wjs(HE, o);
}

function tick() {
let S = sqmget();
if (type(S) != 'object') return;
if (!S.on || S.slow) {
let P0 = rjs(ST);
if (P0 && (P0.qf || P0.af || P0.qs || P0.qn || P0.ws || P0.wn)) { P0.qf = 0; P0.af = 0; P0.qs = P0.qn = P0.ws = P0.wn = false; wjs(ST, P0); }
return;
}
let now = time(), P = rjs(ST) ?? {}, X = S.tech ?? {}, sw = S.where?.swap === true;
let ab = stat(T + '/wf-svc.abtest.lock') != null || length(filter(lsdir(T) ?? [], (f) => substr(f, 0, 15) == 'wf-abtest.held.')) > 0, ok0 = S.pend == null && !ab;
let hr = (a) => filter(type(a) == 'array' ? a : [], (x) => now - +x < 3600), fx = hr(P.fx), ax = hr(P.ax), rc = now - +(P.t ?? 0) < 150;
let qf = ok0 && !S.run && !(S.where?.k == 'line' && S.where?.mobile) ? (rc ? +(P.qf ?? 0) : 0) + 1 : 0;
let af = ok0 && S.run && S.ar && S.arcfg && !S.arrun && trim(sh('uci -q get wrtfreedom.sqm.last 2>/dev/null')) == 'auto' ? (rc ? +(P.af ?? 0) : 0) + 1 : 0;
let qs = qf > 0 && P.qs === true, qn = qf > 0 && P.qn === true, ws = af > 0 && P.ws === true, wn = af > 0 && P.wn === true;
let ev = (it, tx) => sh('sh ' + q(EVSH) + ' cron sqm_fix net ' + q(en() ? tx : it) + ' >/dev/null 2>&1 </dev/null &');
let qr = match(X.rule ?? '', /^[A-Za-z0-9_]{1,64}$/) ? X.rule : '', BK = (getenv('WF_BAKDIR') ?? '/etc/wrtfreedom/bak') + '/sqm/id';
let cnd = '[ "$(uci -q get sqm.' + qr + '.enabled)" = 1 ] && [ ! -f ' + q(BK) + ' ]';
let fix = (ck, c) => sh('( command -v flock >/dev/null && { exec 9>' + T + '/wf-sqmrun.lock; i=0; until flock -n 9; do [ $? = 1 ] && [ $i -lt 300 ] || break; i=$((i+1)); sleep 1; done; }; ' +
'{ ' + ck + ' && ' + c + '; } 9>&- ) >/dev/null 2>&1 </dev/null &');
if (qf >= 2 && length(qr)) {
if (length(fx) < 3) {
push(fx, now); qf = 0;
fix(cnd, q(getenv('WF_SQMINIT') ?? '/etc/init.d/sqm') + ' restart');
if (!qs) ev('🌐 SQM ¦ Code ferme ¦ Riavviate dal router', '🌐 SQM ¦ Queues stopped ¦ Restarted by the router');
qs = true;
}
else if (!qn) { qn = true; ev('⚠️ SQM ¦ Code ferme: non ripartono ¦ Controlla la regola dello SQM', '⚠️ SQM ¦ Queues stopped for good ¦ Check the SQM rule'); }
}
if (af >= 2 && length(qr)) {
if (length(ax) < 3) {
push(ax, now); af = 0;
fix(cnd + ' && [ "$(uci -q get wrtfreedom.sqm.last)" = auto ]', q(getenv('WF_ARINIT') ?? '/etc/init.d/cake-autorate') + ' start');
if (!ws) ev('🌐 SQM ¦ Velocità Adattiva ferma ¦ Riavviata dal router', '🌐 SQM ¦ Adaptive Speed stopped ¦ Restarted by the router');
ws = true;
}
else if (!wn) { wn = true; ev('⚠️ SQM ¦ Velocità Adattiva ferma ¦ Non riparte: controllala', '⚠️ SQM ¦ Adaptive Speed stopped ¦ No restart: check it'); }
}
let C = {};
for (let l in split(sh('tc qdisc show 2>/dev/null'), '\n')) {
let m = match(l, /^qdisc cake [0-9a-f]+: dev ([^ ]+) root.* bandwidth ([0-9.]+)([KMG]?)bit/);
if (m) C[m[1]] = kbit(m[2], m[3]);
}
let eg = C[X.dev], ig = C[X.ifb], dl = sw ? eg : ig, ul = sw ? ig : eg;
let ld = X.line ?? '', rx = length(ld) ? num(SYSNET + '/' + ld + '/statistics/rx_bytes') : null, tx = length(ld) ? num(SYSNET + '/' + ld + '/statistics/tx_bytes') : null;
let dt = now - +(P.t ?? 0), rd = null, rt = null;
if (rx != null && P.rx != null && P.ld == ld && dt > 0 && dt < 300 && rx >= P.rx && tx >= P.tx) { rd = (rx - P.rx) * 8 / 1000 / dt; rt = (tx - P.tx) * 8 / 1000 / dt; }
let lim = (k) => k ?? 0, loaded = rd != null && ((lim(dl) > 0 && rd >= lim(dl) * 0.3) || (lim(ul) > 0 && rt >= lim(ul) * 0.3) ||
(!dl && !ul && S.dl > 0 && rd >= S.dl * 0.3));
let am = S.arrun ? arlag(X.arpath ?? '', P) : null;
let srv = S.srv?.list?.[0] ?? '1.1.1.1', pgt = +(P.pgt ?? 0), rtt = null, pnew = true;
if (am != null && P.prt != null && P.srv == srv && now >= pgt && now - pgt < 300) { rtt = +P.prt; pnew = false; }
else {
let pg = match(sh('ping -c 3 -W 1 -q ' + q(srv) + ' 2>/dev/null'), /= ([0-9.]+)\/([0-9.]+)\//);
rtt = pg ? +pg[2] : null; pgt = now;
}
let base = P.base;
if (pnew && rtt != null && !loaded) base = base == null || rtt <= base ? rtt : (base + 0.5 < rtt ? base + 0.5 : rtt);
let ms = rtt != null && base != null && loaded ? (rtt > base ? int(rtt - base + 0.5) : 0) : null;
if (am != null) { ms = am; loaded = true; }
let A = S.alert ?? {}, hi = +(P.hi ?? 0), lo = +(P.lo ?? 0), al = P.al === true, alt = +(P.alt ?? 0);
if (ms != null && ms >= +(A.ms ?? 30)) { hi++; lo = 0; }
else { hi = 0; if (ms == null || ms < +(A.ms ?? 30) * 0.7) lo++; }
if (al && lo >= 5) al = false;
let high = A.on === true && hi >= +(A.min ?? 2);
if (high && !al && now - alt >= 3600) {
al = true; alt = now;
let E = en(), tip = S.mode == 'auto' ? (S.prof != 'safe' ? (E ? 'Try the Cautious profile' : 'Prova il profilo Prudente') : (E ? 'The line is very busy' : 'La linea è molto carica')) :
(E ? 'Lower the limits a little' : 'Abbassa un po\' i limiti');
let txt = E ? '🌐 SQM ¦ High delay: +' + ms + ' ms ¦ Busy line for ' + hi + ' min ¦ ' + tip : '🌐 SQM ¦ Ritardo alto: +' + ms + ' ms ¦ Linea carica da ' + hi + ' min ¦ ' + tip;
sh((A.tg === false ? 'WF_NOTG=1 ' : 'WF_TG=1 ') + 'sh ' + q(EVSH) + ' cron sqm_lag net ' + q(txt) + ' >/dev/null 2>&1 </dev/null &');
}
let G0 = rjs(LAG) ?? {}, lms = ms, lt = ms != null ? now : null;
if (ms == null && G0.lms != null && now - +(G0.lt ?? 0) < 1800) { lms = G0.lms; lt = G0.lt; }
wjs(LAG, { t: now, ms: ms, base: base != null ? int(base * 10 + 0.5) / 10 : null, rtt: rtt, loaded: loaded, high: high, lms: lms, lt: lt });
wjs(ST, { t: now, rx: rx, tx: tx, ld: ld, base: base, prt: rtt, pgt: pgt, srv: srv, hi: hi, lo: lo, al: al, alt: alt, qf: qf, af: af, fx: fx, ax: ax, qs: qs, qn: qn, ws: ws, wn: wn, arh: ARH });
let R = rjs(H) ?? rjs(HE) ?? { list: [] }, hk = now - now % 3600, L = filter(R.list ?? [], (x) => +x.h > now - 90000), b = L[length(L) - 1];
let nb = !b || b.h != hk;
if (nb) { b = { h: hk, dmin: null, dmax: null, umin: null, umax: null, lsum: 0, ln: 0, lmax: 0, n: 0 }; push(L, b); }
let mm = (k, v, f) => { if (v != null && v > 0 && (b[k] == null || f(v, b[k]))) b[k] = v; };
mm('dmin', dl, (x, y) => x < y); mm('dmax', dl, (x, y) => x > y); mm('umin', ul, (x, y) => x < y); mm('umax', ul, (x, y) => x > y);
b.n++;
if (ms != null) { b.lsum += ms; b.ln++; if (ms > b.lmax) b.lmax = ms; }
b.lavg = b.ln ? int(b.lsum / b.ln + 0.5) : null;
R = { t: now, list: L };
wjs(H, R);
if (nb && localtime(now).hour % 3 == 0) { mkdir('/etc/wrtfreedom'); wjs(HE, R); }
}

let A0 = ARGV[0] ?? '';
if (A0 == 'tick') {
let lk = T + '/wf-sqm.lock', s = stat(lk);
if (s && time() - s.mtime < 120) exit(0);
writefile(lk, '' + time());
tick();
unlink(lk);
}
else if (A0 == 'save') save();
else print('uso: ucode sqm.uc tick|save\n');
