'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rename, readlink } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', NJ = ETC + '/nas.json', XJ = ETC + '/nasx.json', CJ = ETC + '/cloud.json';
const TMP = '/tmp/wf-nas', SESS = TMP + '/sess.json', SLK = TMP + '/sess.lock', REGF = TMP + '/reg.json', INV = TMP + '/invite.json';
const SH = getenv('WF_NASSH') ?? '/usr/share/wrtfreedom/nasvc.sh', NASXUC = getenv('WF_NASXUC') ?? '/usr/share/wrtfreedom/nasx.uc';
const NASVCUC = getenv('WF_NASVCUC') ?? '/usr/share/wrtfreedom/nasvc.uc', CLOUDUC = getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc';
const NASBKUC = getenv('WF_NASBKUC') ?? '/usr/share/wrtfreedom/nasbk.uc';
const AIMEMD = ETC + '/ai-mem.d';
const ACLF = R + '/usr/share/rpcd/acl.d/wrtfreedom.json', ACLG = 'wrtfreedom-nas';
const PMAX = 32, FMAX = 5, LOCKS = 900, UNLOCKS = 3600, RMAXH = 5, IADEF = 100, GB = 1073741824, HC = 1048576;
const RLK = TMP + '/reg.lock';
const MAINPJ = TMP + '/mainpause.json';
const AIU = '/tmp/wf-ai/u';
const TGU = ETC + '/tg-u', TGT = R + '/tmp/wf-tg-u';
const TRASHJ = TMP + '/trash-own.json', BKJ = TMP + '/bk-own.json', FARJ = TMP + '/far.json', CSTJ = '/tmp/wf-cloud/state.json';
const SYS = getenv('WF_SYS') ?? '/sys', MOUNTS = getenv('WF_MOUNTS') ?? '/proc/mounts';
const PCHOST = 'nas.home.arpa', DNSJ = ETC + '/nasdns.json';

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function rid() { return substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10) || ('' + time()); }
function mkdirp(p) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c); } }
function wsec(f, s) {
let t = f + '.t' + rid(), p = popen('umask 077; cat > ' + q(t), 'w');
if (!p) return false;
p.write(s); p.close();
if (rename(t, f)) return true;
unlink(t);
return false;
}
function cut(s, n) {
s = '' + s;
if (length(s) <= n) return s;
let i = n;
while (i > 0 && (ord(s, i) & 0xC0) == 0x80) i--;
return rtrim(substr(s, 0, i));
}
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
const CFGD = getenv('WF_CFGDIR') ?? (R + '/etc/config/');
function cfg(name) { return UCFG.read(CFGD + name, false); }
function arr(v) { return type(v) == 'array' ? v : (v == null || v == '' ? [] : split('' + v, ' ')); }

let LG = 'it';
function L(it, en) { return LG == 'en' ? en : it; }
function err(code, it, en, x) { let r = { error: it, error_en: en, code: code }; for (let k, v in x ?? {}) r[k] = v; return r; }
function tmpdir() { if (!stat(TMP)) { mkdirp(replace(TMP, /\/[^\/]+$/, '')); mkdir(TMP, 0700); } }
function xdrop(u, T) {
let XLK = TMP + '/cmig.lock';
if (!UCFG.pidlock(XLK, TMP, 30)) return false;
try {
let X = rjs(XJ);
if (type(X) == 'object') {
let n = 0, mine = (o) => (o?.own ?? 'admin') == u && +(o?.t ?? 0) <= T;
if (type(X.link?.list) == 'array') { let l = filter(X.link.list, (o) => !mine(o)); n += length(X.link.list) - length(l); X.link.list = l; }
if (type(X.req) == 'array') { let l = filter(X.req, (o) => !mine(o)); n += length(X.req) - length(l); X.req = l; }
if (n) { X.saved = time(); let t = XJ + '.t' + rid(); writefile(t, sprintf('%J', X)); if (!rename(t, XJ)) unlink(t); }
}
} catch (e) {}
UCFG.pidunlock(XLK);
return true;
}
const XPJ = ETC + '/nasu-xdrop.json';
function xpend(add) {
let s = add ? null : stat(XPJ);
if (!add && (!s || (time() - s.mtime < 30 && s.mtime <= time()))) return;
let P = filter(rjs(XPJ) ?? [], (p) => type(p) == 'object' && match(p.u, /^[a-z][a-z0-9]{0,19}$/) && type(p.t) == 'int'), K = [];
if (add) push(P, add);
for (let p in P) if (!xdrop(p.u, p.t)) push(K, p);
if (length(K)) wsec(XPJ, sprintf('%J', K)); else unlink(XPJ);
}
function begin() { LG = cfg('wrtfreedom')?.ui?.lang == 'en' ? 'en' : 'it'; tmpdir(); mkdirp(ETC); xpend(null); }
function ev(t, it, en, own) { detach('sh ' + q(R + '/usr/share/wrtfreedom/event.sh') + ' cron ' + t + ' nas ' + q(L(it, en)) + (type(own) == 'string' && match(own, /^[a-z][a-z0-9]{0,19}$/) ? ' ' + q(own) : '')); }

function E_WHO() { return err('who', 'Accesso scaduto: entra di nuovo', 'Access expired: sign in again'); }
function E_BLOCKED() { return err('blocked', 'Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator'); }
function E_BUSY() { return err('busy', 'Impostazioni del NAS occupate: riprova', 'NAS settings busy: try again'); }
function E_NONE() { return err('none', 'Persona non trovata', 'Person not found'); }
function E_LOCKED(until) {
let m = int((until - time() + 59) / 60);
if (m < 1) m = 1;
return err('locked', 'Troppi tentativi: riprova tra ' + m + (m == 1 ? ' minuto' : ' minuti'), 'Too many attempts: try again in ' + m + (m == 1 ? ' minute' : ' minutes'), { until: until });
}
function E_PASS() { return err('pass', 'Password di almeno 8 caratteri', 'Password of at least 8 characters'); }
function E_LAN() { return err('lan_only', 'Si fa dalla rete di casa o con la VPN', 'Only from the home network or the VPN'); }

function hexr(n) { let s = readfile('/dev/urandom', n) ?? '', o = ''; for (let i = 0; i < length(s); i++) o += sprintf('%02x', ord(s, i)); return length(o) == n * 2 ? o : null; }
function hsum(feed) {
let f = TMP + '/.h' + rid(), p = popen('umask 077; sha256sum > ' + q(f), 'w');
if (!p) return null;
feed(p); p.close();
let o = substr(readfile(f) ?? '', 0, 64);
unlink(f);
return match(o, /^[0-9a-f]{64}$/) ? o : null;
}
function phash(s, salt) {
salt ??= hexr(16);
if (salt == null) return null;
let u = salt + '$' + s, blk = u;
while (length(blk) < 65536) blk += u;
let n = int((HC + length(blk) - 1) / length(blk));
let h = hsum((p) => { for (let i = 0; i < n; i++) p.write(blk); });
return h ? salt + '$' + h : null;
}
function pcheck(s, st) {
let m = match('' + (st ?? ''), /^([0-9a-f]{32})\$([0-9a-f]{64})$/);
return m != null && phash('' + s, m[1]) === st;
}
const RCA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function rcode() {
let s = readfile('/dev/urandom', 12) ?? '', o = '';
if (length(s) < 12) return null;
for (let i = 0; i < 12; i++) o += (i && i % 4 == 0 ? '-' : '') + substr(RCA, ord(s, i) & 31, 1);
return o;
}
function ucode6() {
let s = readfile('/dev/urandom', 4) ?? '';
if (length(s) < 4) return null;
return sprintf('%06d', ((ord(s, 0) << 24 | ord(s, 1) << 16 | ord(s, 2) << 8 | ord(s, 3)) & 0x7fffffff) % 1000000);
}
function cnorm(c) { return uc(replace('' + (c ?? ''), /[- ]/g, '')); }
function passok(p) { return type(p) == 'string' && length(p) >= 8 && length(p) <= 64 && !match(p, /[[:cntrl:]]/); }

const ACC = { 'à': 'a', 'á': 'a', 'â': 'a', 'ä': 'a', 'ã': 'a', 'å': 'a', 'è': 'e', 'é': 'e', 'ê': 'e', 'ë': 'e', 'ì': 'i', 'í': 'i',
'î': 'i', 'ï': 'i', 'ò': 'o', 'ó': 'o', 'ô': 'o', 'ö': 'o', 'õ': 'o', 'ù': 'u', 'ú': 'u', 'û': 'u', 'ü': 'u', 'ç': 'c', 'ñ': 'n',
'ý': 'y', 'ÿ': 'y', 'À': 'a', 'Á': 'a', 'Â': 'a', 'Ä': 'a', 'Ã': 'a', 'Å': 'a', 'È': 'e', 'É': 'e', 'Ê': 'e', 'Ë': 'e', 'Ì': 'i',
'Í': 'i', 'Î': 'i', 'Ï': 'i', 'Ò': 'o', 'Ó': 'o', 'Ô': 'o', 'Ö': 'o', 'Õ': 'o', 'Ù': 'u', 'Ú': 'u', 'Û': 'u', 'Ü': 'u', 'Ç': 'c',
'Ñ': 'n', 'Ý': 'y', 'ß': 'ss', 'æ': 'ae', 'Æ': 'ae', 'œ': 'oe', 'Œ': 'oe', 'ø': 'o', 'Ø': 'o' };
function fold(s) { s = '' + s; for (let k, v in ACC) if (index(s, k) >= 0) s = replace(s, k, v); return lc(s); }
function nkey(s) { return replace(fold(s), /[^a-z0-9]/g, ''); }
function ckey(s) { let k = nkey(s); return length(k) ? k : lc(trim('' + s)); }
function slug(vis) { let s = substr(replace(nkey(vis), /^[0-9]+/, ''), 0, 20); return length(s) ? s : 'utente'; }
function ulen(s) { let n = 0; for (let i = 0; i < length(s); i++) if ((ord(s, i) & 0xc0) != 0x80) n++; return n; }
function visok(v) {
if (type(v) != 'string' || !length(v) || ulen(v) > 40 || index(v, '¦') >= 0) return false;
if (match(v, /[[:cntrl:]"=|%?*<>:\/\\]/) || match(v, /[. ]$/) || substr(v, 0, 1) == '.') return false;
return !match(lc(replace(v, /[.].*$/, '')), /^[ ]*(con|prn|aux|nul|com[1-9]|lpt[1-9])[ ]*$/);
}
function visold(v) { return type(v) == 'string' && length(v) >= 1 && !match(v, /[[:cntrl:]:\/\\]/) && !match(v, /^[.]+$/); }
function userok(u) { return type(u) == 'string' && match(u, /^[a-z][a-z0-9]{0,19}$/) != null; }
function reserved(N, s) {
let k = ckey(s);
if (!length(k) || index([ 'amministratore', 'cartellacondivisa', 'admin', 'root' ], k) >= 0) return true;
for (let l in split(readfile(R + '/etc/passwd') ?? '', '\n')) { let p = split(l, ':'); if (length(p[0]) && p[4] != 'wf-nas' && ckey(p[0]) == k) return true; }
for (let u, x in N.users) if (x?.cam && ckey(u) == k) return true;
return false;
}
function taken(N, s, skip) {
let k = ckey(s);
for (let u, x in N.users) if (u != skip && type(x) == 'object' && !x.cam && (ckey(u) == k || ckey(x.vis ?? '') == k)) return true;
for (let g in N.gone) if (ckey(g?.user ?? '') == k || ckey(g?.vis ?? '') == k) return true;
return false;
}
function propose(N, vis) {
let b = slug(vis), u = b, i = 2;
while ((reserved(N, u) || taken(N, u)) && i < 1000) { let n = '' + i++; u = substr(b, 0, 20 - length(n)) + n; }
return u;
}
function names(N, vis, user) {
vis = trim('' + (vis ?? ''));
if (!visok(vis)) return err('name', 'Nome non valido: da 1 a 40 caratteri, senza " = | ¦ % ? * < > : \\ /, senza punto davanti, senza punto o spazio in fondo, non CON, NUL, COM1…',
'Invalid name: 1 to 40 characters, no " = | ¦ % ? * < > : \\ /, no dot at the start, no dot or space at the end, not CON, NUL, COM1…');
if (reserved(N, vis)) return err('reserved', 'Nome riservato', 'Reserved name');
if (taken(N, vis)) return err('taken', 'Nome già usato', 'Name already used');
let u = user == null || user == '' ? propose(N, vis) : '' + user;
if (!userok(u)) return err('name', 'Nome di accesso non valido: lettere minuscole e numeri', 'Invalid sign-in name: lowercase letters and digits');
if (reserved(N, u)) return err('reserved', 'Nome riservato', 'Reserved name');
if (taken(N, u)) return err('taken', 'Nome già usato', 'Name already used');
return { vis: vis, user: u };
}

function nraw() { let N = rjs(NJ); if (type(N) != 'object') N = {}; if (type(N.users) != 'object') N.users = {}; if (type(N.gone) != 'array') N.gone = []; return N; }
function wnj(o) { mkdirp(ETC); let t = NJ + '.t' + rid(); writefile(t, sprintf('%J', o)); rename(t, NJ); }
function n340(N) {
let n = 0;
for (let u, x in N.users) {
if (type(x) != 'object' || x.cam || x.vis != null) continue;
let l = trim('' + (x.label ?? ''));
x.vis = visok(l) && !reserved(N, l) && !taken(N, l, u) ? l : u;
if (type(x.quota) != 'object') x.quota = { disk: type(x.quota_gb) == 'int' && x.quota_gb > 0 ? x.quota_gb : 0, cloud: 0 };
if (x.home != null || x.disk != null) x.old340 = { home: x.home ?? null, disk: x.disk ?? null };
for (let f in [ 'label', 'quota_gb', 'disk', 'home' ]) delete x[f];
n++;
}
return n;
}
function nget() {
let N = nraw();
if (!n340(N)) return N;
let w = false;
UCFG.njset(nraw, (M) => { w = n340(M) > 0; }, (M) => { if (w) wnj(M); });
return N;
}
function nset(fn) {
let r = null;
let o = UCFG.njset(() => { let N = nraw(); n340(N); return N; }, (N) => { r = fn(N); }, (N) => { if (r?.error == null && r?.nowrite !== true) wnj(N); });
return o == null ? E_BUSY() : r;
}
function people(N) { return filter(sort(keys(N.users)), (u) => type(N.users[u]) == 'object' && !N.users[u].cam); }

function zone(ip) { return type(UCFG.ipzone) == 'function' ? UCFG.ipzone(ip, { cfgdir: CFGD }) : 'net'; }
const HOMEZ = [ 'lan', 'vpn' ];
function athome(z) { return index(HOMEZ, z) >= 0; }
function zoneok(ip, via) { let z = zone(ip); return athome(z) || (z == 'net' && via === 'remote'); }

function sread() { let S = rjs(SESS); return type(S) == 'object' ? S : {}; }
function swrite(fn) {
if (!UCFG.pidlock(SLK, TMP, 5)) return false;
let S = sread(), ok = true;
try { fn(S); ok = wsec(SESS, sprintf('%J', S)); } catch (e) { ok = false; }
UCFG.pidunlock(SLK);
return ok;
}
function sidok(s) { return type(s) == 'string' && match(s, /^[0-9a-f]{32}$/) != null; }
function skill(L2) { for (let s in L2) if (sidok(s)) detach('ubus call session destroy ' + q(sprintf('%J', { ubus_rpc_session: s }))); }
function sdrop(u, keep) {
let K = [];
swrite((S) => { for (let s, v in S) if (v?.u == u && s != keep) { push(K, s); delete S[s]; } });
skill(K);
}

function pwset(u, pw) {
let f = TMP + '/.u' + rid(), r = [];
if (!wsec(f, u + '\t' + pw + '\n')) return null;
let o = sh('sh ' + q(SH) + ' usersets ' + q(f) + ' 2>/dev/null');
unlink(f);
for (let l in split(o, '\n')) { let m = match(l, /^([a-z0-9][a-z0-9._-]{0,31}) ok:([a-z0-9]+)$/); if (m && m[1] == u && index(r, m[2]) < 0) push(r, m[2]); }
return length(r) ? r : null;
}
const MC = {};
function svcsync() {
let M = UCFG.modof(MC, NASVCUC);
if (type(M?.users_sync) == 'function') { try { M.users_sync(); return; } catch (e) {} }
detach('sh ' + q(SH) + ' tick');
}
const ADMFP = ETC + '/nas-admpw.fp';
function admhas(n) {
n = lc(n);
if (stat(R + '/usr/sbin/smbd') && UCFG.smbusers(R)?.[n] !== true) return false;
if (stat(R + '/usr/sbin/ksmbd.mountd') && index(map(split(readfile(R + '/etc/ksmbd/ksmbdpwd.db') ?? '', '\n'), (l) => lc(split(l, ':')[0])), n) < 0) return false;
return true;
}
function admpw(p) {
if (type(p) != 'string' || !length(p) || length(p) > 128 || match(p, /[[:cntrl:]]/)) return err('pass', 'Password non valida', 'Invalid password');
let n = UCFG.smbadm(nget());
if (pcheck(p, trim(readfile(ADMFP) ?? '')) && admhas(n)) return { ok: true, same: true };
let f = TMP + '/.a' + rid(), r = [];
mkdir(TMP, 0700);
if (!wsec(f, p)) return E_BUSY();
let o = sh('sh ' + q(SH) + ' useradm ' + q(f) + ' 2>/dev/null');
unlink(f);
for (let l in split(o, '\n')) { let m = match(l, /^ok:([a-z0-9]+)$/); if (m && index(r, m[1]) < 0) push(r, m[1]); }
if (!length(r)) return err('fail', 'Password dell\'Amministratore non messa nelle Cartelle In Rete', 'Administrator password not set for Network Folders');
let h = phash(p);
if (h) wsec(ADMFP, h + '\n');
svcsync();
return { ok: true, svc: r };
}
function cloududel(u, N) {
let rc = UCFG.modof(MC, CLOUDUC)?._rc;
if (type(rc?.udel) != 'function') return null;
try { return rc.udel(u, N); } catch (e) { return null; }
}
const CLOUDMNT = getenv('WF_CLOUDMNT') ?? '/usr/share/wrtfreedom/cloudmnt.sh';
function cloudmntc() { return stat(CLOUDMNT) ? 'sh ' + q(CLOUDMNT) + ' check' : ''; }
function cloudcruser(u) {
if (!userok(u)) return;
let c = cloudmntc(), k = stat(CLOUDUC) ? 'o=$(ucode ' + q(CLOUDUC) + ' cruser ' + q(u) + ' 2>/dev/null)' : '';
if (!length(k) && !length(c)) return;
detach(length(k) ? k + (length(c) ? '; ' + c + '; case "$o" in *\'"n": 0\'*|*\'"n":0\'*|\'\') ;; *) sleep 90; ' + c + ' ;; esac' : '') : c);
}
function cloudmntkick() { let c = cloudmntc(); if (length(c)) detach(c); }
function cloududetach(u) {
let rc = UCFG.modof(MC, CLOUDUC)?._rc;
if (type(rc?.udetach) != 'function') return null;
try { return rc.udetach(u); } catch (e) { return null; }
}

function cloudjobs(u) {
let M = UCFG.modof(MC, NASBKUC);
if (type(M?.bkudel) != 'function') return null;
try { return M.bkudel(u); } catch (e) { return null; }
}

function cloudupclose(u) {
let rc = UCFG.modof(MC, CLOUDUC)?._rc;
if (type(rc?.upreq_close) != 'function') return null;
try { return rc.upreq_close(u); } catch (e) { return null; }
}
function udrop(u) {
if (!userok(u)) return;
let C = '';
for (let k, s in cfg('wrtfreedom')) if (s['.type'] == 'tgchat' && s.own == u && match(k, /^[A-Za-z0-9_]+$/)) C += 'uci -q delete wrtfreedom.' + k + '; ';
if (length(C)) sh(C + 'uci commit wrtfreedom; touch /tmp/wf-tg.menu');
xpend({ u: u, t: time() });
sh('rm -rf ' + q(AIU + '/' + u));
let TGF = TGU + '/' + u + '.json', had = stat(TGF) != null;
unlink(TGF);
sh('rm -f ' + q(TGT + '/' + u) + '.*');
if (had) sh('[ -x ' + q(R + '/etc/init.d/wrtfreedom') + ' ] && ( ' + q(R + '/etc/init.d/wrtfreedom') + ' reload ) >/dev/null 2>&1 </dev/null &');
}

function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
let MFS = '', MDV = '';
function mainmnt(N) {
MFS = ''; MDV = '';
let id = '' + (N.main?.id ?? ''), uu = '' + (N.main?.uuid ?? ''), dev = '';
if (length(uu) && match(uu, /^[0-9A-Za-z-]{1,64}$/)) { let l = readlink('/dev/disk/by-uuid/' + uu); if (l) dev = replace(l, /^.*\//, ''); }
if (!length(dev) && match(id, /^[a-z0-9]{1,32}$/)) dev = id;
let MJ = rjs(TMP + '/mnt.json'), mp = type(MJ) == 'object' ? (MJ[id] ?? MJ[uu]) : null;
for (let l in split(readfile('/proc/mounts') ?? '', '\n')) {
let p = split(l, ' ');
if (!length(p[1])) continue;
if ((length(dev) && p[0] == '/dev/' + dev) || (type(mp) == 'string' && length(mp) && unoct(p[1]) == mp)) {
MFS = type(UCFG.fsname) == 'function' ? UCFG.fsname(p[2] ?? '') : (p[2] ?? '');
let dm = match(p[0], /^\/dev\/([a-z0-9]{1,32})$/);
MDV = dm ? dm[1] : '';
return unoct(p[1]);
}
}
return null;
}
function keepnow(c) {
if (c.keep !== true) return false;
let hh = (v) => match('' + (v ?? ''), /^([01][0-9]|2[0-3]):00$/) ? +substr(v, 0, 2) : null, a = hh(c.from), b = hh(c.to);
if (a == null || b == null || a == b) return true;
let h = localtime().hour;
return a < b ? h >= a && h < b : h >= a || h < b;
}
function msleep(N, id) {
if (!length(MDV) || match(MDV, /^md/)) return false;
let c = type(N.sleep) == 'object' ? N.sleep : {}, m = type(c.mins) == 'int' && c.mins >= 0 ? c.mins : 15;
if (m <= 0 || keepnow(c)) return false;
let b = MDV;
if (stat(SYS + '/class/block/' + b + '/partition')) { let l = split(readlink(SYS + '/class/block/' + b) ?? '', '/'); if (length(l) >= 2 && match(l[length(l) - 2], /^[a-z0-9]{1,32}$/)) b = l[length(l) - 2]; }
if (trim(readfile(SYS + '/block/' + b + '/removable') ?? '') == '1') return false;
let x = split(trim(readfile(SYS + '/class/block/' + b + '/stat') ?? ''), /[ \t]+/);
if (length(x) < 7) return false;
let r = +x[2] * 512, w = +x[6] * 512, chg = null;
for (let p in [ rjs(TMP + '/io.json')?.[b], match(id, /^[A-Za-z0-9_-]{1,64}$/) ? rjs(TMP + '/scan/' + id + '.io') : null ])
if (type(p) == 'object' && p.r == r && p.w == w && type(p.chg) == 'int' && (chg == null || p.chg > chg)) chg = p.chg;
return chg != null && time() - chg >= m * 60;
}
function mainst(N) {
if (type(N.main) != 'object' || !length('' + (N.main.id ?? ''))) return { id: '', fs: '', state: 'none', text: L('Manca il Disco Principale', 'No Main Drive'), sleep: false };
let id = '' + N.main.id, P = rjs(MAINPJ), m = mainmnt(N);
if (type(P) == 'object' && P.state == 'bad') return { id: id, fs: m ? MFS : '', state: 'bad', text: L('Disco Guasto', 'Drive Failing'), sleep: false };
if (type(P) == 'object') return { id: id, fs: '', state: 'off', text: L('Disco Staccato', 'Drive Removed'), sleep: false };
return { id: id, fs: m ? MFS : '', state: 'ok', text: L('Pronto', 'Ready'), sleep: m != null && msleep(N, id) };
}
function mkbase(u) {
let N = nget(), m = mainmnt(N);
if (!m || type(UCFG.udir) != 'function' || type(UCFG.ubase) != 'function') return;
let r = UCFG.udir(u, 'root', null, N);
if (type(r) != 'string' || !length(r)) return;
for (let p in UCFG.ubase(N)) if (type(p) == 'string' && (p == r || substr(p, 0, length(r) + 1) == r + '/') && index(p, '..') < 0) mkdirp(m + '/' + p);
detach('sh ' + q(SH) + ' dirs');
}
function rmtrace(rel, u, G) {
let dir = (p) => lstat(p)?.type == 'directory', pf = rel + '/', t = time();
for (let l in split(readfile(MOUNTS) ?? '', '\n')) {
let x = split(l, ' ');
if (!match(x[0] ?? '', /^\/dev\//) || !length(x[1])) continue;
let m = unoct(x[1]);
if (match(m, /^\/(overlay|rom|boot|tmp|proc|sys|dev)?$/)) continue;
let V = m + '/.wf-vers';
if (dir(V)) for (let g in lsdir(V) ?? []) {
let p = V + '/' + g + '/' + rel;
if (match(g, /^@GMT-/) && dir(V + '/' + g) && dir(p)) push(G, q(p));
}
let T = m + '/.wf-trash';
if (!dir(T)) continue;
if (userok(u) && dir(T + '/' + u) && rename(T + '/' + u, T + '/via.' + t + '.' + u)) push(G, q(T + '/via.' + t + '.' + u));
if (!dir(T + '/info') || !dir(T + '/files')) continue;
for (let f in lsdir(T + '/info') ?? []) {
let n = match(f, /^([0-9A-Za-z._-]+)\.info$/);
if (!n) continue;
let fr = '';
for (let k in split(readfile(T + '/info/' + f) ?? '', '\n')) if (substr(k, 0, 5) == 'from=') { fr = replace(substr(k, 5), /^\/+/, ''); break; }
if (fr != rel && substr(fr, 0, length(pf)) != pf) continue;
let v = T + '/via.' + t + '.' + n[1];
if (lstat(T + '/files/' + n[1]) && rename(T + '/files/' + n[1], v)) push(G, q(v));
unlink(T + '/info/' + f);
}
}
}
function rmhome(N, vis, u) {
let m = mainmnt(N);
if (!m) return false;
let UD = UCFG.UDIR;
if (!visold(vis) || type(UD?.root) != 'string' || !length(UD.root) || vis == UD.admin || vis == UD.shared) return true;
let p = m + '/' + UD.root + '/' + vis, s = lstat(p), G = [];
if (s && s.type == 'directory') push(G, q(p));
rmtrace(UD.root + '/' + vis, u, G);
if (length(G)) detach('rm -rf ' + join(' ', G));
return true;
}

function usedof() { return rjs(TMP + '/quota.json') ?? {}; }
function today() { let t = localtime(time()); return sprintf('%04d-%02d-%02d', t.year, t.mon, t.mday); }
function iaof(x) { let n = x.ia_day?.d == today() ? +(x.ia_day?.n ?? 0) : 0; return { max: x.ia_max ?? IADEF, n: n }; }
function usedx(Q, u) { let v = Q[u]; return type(v) == 'object' ? { disk: +(v.disk ?? 0), cloud: +(v.cloud ?? 0) } : { disk: +(v ?? 0), cloud: 0 }; }
function pctof(x, U) { let qd = +(x.quota?.disk ?? 0); return qd > 0 ? int(U.disk * 100 / (qd * GB)) : 0; }
function pstate(x, pct) {
if (x.blocked) return { state: 'blocked', sev: 'off', text: L('Bloccata', 'Blocked') };
if (+(x.quota?.disk ?? 0) > 0 && pct >= 100) return { state: 'full', sev: 'bad', text: L('Ferma', 'Stopped') };
if (+(x.quota?.disk ?? 0) > 0 && pct >= 90) return { state: 'quota', sev: 'warn', text: L('Quota Al ' + pct + '%', 'Quota At ' + pct + '%') };
if (x.new) return { state: 'new', sev: 'info', text: L('Nuova', 'New') };
return { state: 'on', sev: 'ok', text: L('Attiva', 'Active') };
}
function linksof(u) {
let X = rjs(XJ), n = 0, now = time();
for (let l in (type(X?.link?.list) == 'array' ? X.link.list : [])) if ((l?.own ?? 'admin') == u && +(l?.exp ?? 0) > now) n++;
return n;
}
function quotaof(x) { return { disk: +(x.quota?.disk ?? 0), cloud: +(x.quota?.cloud ?? 0) }; }
function isn(v) { return type(v) == 'int' || type(v) == 'double'; }
function rcof() { let rc = UCFG.modof(MC, CLOUDUC)?._rc; return type(rc) == 'object' ? rc : null; }
function homeof(u) {
let rc = rcof();
if (type(rc?.uhome) != 'function') return null;
try { return rc.uhome(u); } catch (e) { return null; }
}
function comaccts() { let A = rjs(CJ)?.accounts; return filter(type(A) == 'array' ? A : [], (a) => type(a) == 'object' && (type(a.user) != 'string' || !length(a.user)) && a.own !== true); }
function cqof(x, used) {
let qc = +(x.quota?.cloud ?? 0), p = qc > 0 ? int(used * 100 / (qc * GB)) : 0;
if (qc <= 0) return { pct: 0, state: 'none', sev: 'ok', text: '' };
if (p >= 100 || used >= qc * GB) return { pct: p, state: 'full', sev: 'bad', block: true, text: L('Cloud Pieno', 'Cloud Full') };
if (p >= 90) return { pct: p, state: 'quota', sev: 'warn', text: L('Cloud Al ' + p + '%', 'Cloud At ' + p + '%') };
return { pct: p, state: 'ok', sev: 'ok', text: L('Spazio Cloud Ok', 'Cloud Space Ok') };
}
function uout(N, u, Q) {
let x = N.users[u], U = usedx(Q, u), pct = pctof(x, U), s = pstate(x, pct);
return { user: u, vis: x.vis ?? u, state: s.state, sev: s.sev, pct: pct, self: x.self === true, since: +(x.since ?? 0),
used: U, quota: quotaof(x), ia: iaof(x), lock_until: +(x.lock_until ?? 0) > time() ? +x.lock_until : 0,
person: x.person ?? '', need_pass: !length(x.ph ?? ''), links: linksof(u) };
}
function uget(N) {
let Q = usedof(), L2 = [], A = [], now = time(), hc = length(comaccts()) > 0;
for (let u in people(N)) {
let o = uout(N, u, Q), x = N.users[u];
if (hc) { let h = homeof(u); o.used.cloud = isn(h?.used) ? h.used : 0; }
let cq = cqof(x, o.used.cloud);
o.cpct = cq.pct;
push(L2, o);
if (o.lock_until > now) push(A, { k: 'locked', user: u, vis: o.vis, until: o.lock_until });
if (x.new) push(A, { k: 'new', user: u, vis: o.vis, t: +(x.since ?? 0) });
if (o.quota.disk > 0 && o.pct >= 90) push(A, { k: 'quota', user: u, vis: o.vis, pct: o.pct });
if (cq.state == 'quota' || cq.state == 'full') push(A, { k: 'cquota', user: u, vis: o.vis, pct: cq.pct });
}
let G = map(filter(N.gone, (g) => type(g) == 'object' && userok(g.user)), (g) => ({ user: g.user, vis: g.vis ?? g.user, t: +(g.t ?? 0), used: usedx(Q, g.user).disk }));
return { users: L2, gone: G, alerts: A, reg: N.reg !== false, max: PMAX, n: length(L2) };
}
function num(v) { return type(v) == 'int' || type(v) == 'double' ? v : 0; }
function dlof(u) { let D = rjs(TMP + '/dl-own.json')?.[u]; return { n: +(D?.n ?? 0), run: +(D?.run ?? 0), paused: D?.paused === true, kbs: int(num(D?.kbs)) }; }
function reqsof(u) {
let X = rjs(XJ), n = 0, now = time();
for (let r in (type(X?.req) == 'array' ? X.req : [])) if ((r?.own ?? 'admin') == u && r?.on !== false && +(r?.exp ?? 0) > now) n++;
return n;
}
function auser(a) { return type(a?.user) == 'string' && length(a.user) ? a.user : 'admin'; }
let CFREE = null;
const CLJ = ETC + '/cloud-links.json', CWD = '/tmp/wf-cloud';
function clinks(u) {
let L = rjs(CLJ)?.items, now = time(), o = {};
for (let x in (type(L) == 'array' ? L : [])) {
if (type(x) != 'object' || (type(x.own) == 'string' && length(x.own) ? x.own : 'admin') != u) continue;
if (isn(x.expire) && x.expire > 0 && x.expire < now) continue;
let c = o['' + x.id] ??= { links: 0, reqs: 0 };
if (x.kind == 'upreq') c.reqs++; else c.links++;
}
return o;
}
function cjobs(u) {
let o = {};
for (let f in (lsdir(CWD + '/jobs') ?? [])) {
if (!match(f, /^j[0-9a-z]{4,24}\.json$/)) continue;
let j = rjs(CWD + '/jobs/' + f);
if (type(j) != 'object' || j.kind != 'url' || (type(j.own) == 'string' && length(j.own) ? j.own : 'admin') != u) continue;
if (j.state != 'run' && j.state != 'wait' && j.state != 'pause') continue;
let c = o['' + j.id] ??= { n: 0, run: 0, kbs: 0 };
c.n++;
if (j.state == 'run') { c.run++; c.kbs += int(num(j.speed) / 1024); }
}
return o;
}
function ctrash(id, root) {
let f = CWD + '/trash-' + id + '.json', s = stat(f), T = s ? rjs(f) : null;
if (type(T?.list) != 'array') return null;
let n = 0, b = 0;
for (let x in T.list) {
let p = type(x?.path) == 'string' ? x.path : '';
if (root != null && !(length(p) && (p == '/' + root || substr(p, 0, length(root) + 2) == '/' + root + '/'))) continue;
n++; b += num(x.size);
}
return { n: n, bytes: b, t: s.mtime };
}
function cstate(st, paused, pct, full) {
if (st == 'relink') return { state: 'relink', sev: 'warn', text: L('Da Ricollegare', 'Reconnect Needed') };
if (st == 'old') return { state: 'old', sev: 'warn', text: L('Da Aggiornare', 'Update Needed') };
if (paused) return { state: 'pause', sev: 'off', text: L('In Pausa', 'Paused') };
if (st == 'err') return { state: 'err', sev: 'bad', text: L('Non Raggiungibile', 'Unreachable') };
if (full) return { state: 'full', sev: 'bad', text: L('Pieno', 'Full') };
if (st == 'new') return { state: 'new', sev: 'info', text: L('In Arrivo', 'Connecting') };
if (pct >= 90) return { state: st == 'busy' ? 'busy' : 'ok', sev: 'warn', text: L('Quasi Pieno', 'Almost Full') };
return { state: st == 'busy' ? 'busy' : 'ok', sev: 'ok', text: L('Pronto', 'Ready') };
}
function cloudof(N, u, U, x) {
let A = rjs(CJ)?.accounts, S = rjs(CSTJ)?.accts;
A = filter(type(A) == 'array' ? A : [], (a) => type(a) == 'object');
S = type(S) == 'object' ? S : {};
let st = (a) => type(S['' + a.id]) == 'object' ? S['' + a.id] : {};
let mine = filter(A, (a) => auser(a) == u), com = filter(A, (a) => auser(a) == 'admin' && a.own !== true), free = 0;
for (let a in com) free += num(st(a).free);
let a = mine[0];
CFREE = null;
let fa = [ ...mine, ...com ];
for (let y in fa) if (isn(st(y).free)) CFREE = (CFREE ?? 0) + st(y).free;
let hu = length(com) ? homeof(u) : null, rc = length(fa) ? rcof() : null;
let RA = {}, SV = {}, pz = false;
if (rc) {
try { for (let r in (type(rc.accts) == 'function' ? rc.accts() : [])) RA['' + r.id] = r; } catch (e) {}
try { for (let s in (type(rc.svcs) == 'function' ? rc.svcs() : [])) SV['' + s.id] = s; } catch (e) {}
try { pz = type(rc.paused) == 'function' && rc.paused() === true; } catch (e) {}
}
let PU = rjs(CJ)?.pause, root = type(UCFG.udir) == 'function' ? UCFG.udir(u, 'root', null, N) : null;
let LK = length(fa) ? clinks(u) : {}, JB = length(fa) ? cjobs(u) : {};
let ao = (y, home) => {
let id = '' + (y.id ?? ''), f = st(y), r = RA[id] ?? {}, c = SV['' + y.svc]?.caps ?? {};
let raw = '' + (r.state ?? (match(f.st ?? '', /^(ok|new|relink|err|busy)$/) ? f.st : 'ok'));
let total = isn(f.total) ? f.total : null, used = isn(f.used) ? f.used : null, fr = isn(f.free) ? f.free : (total != null && used != null ? (total > used ? total - used : 0) : null);
let pct = total > 0 && used != null ? int(used * 100 / total) : 0, s = cstate(raw, pz, pct, fr != null && total > 0 && fr <= 0);
let k = LK[id] ?? {}, j = JB[id] ?? {};
return { id: id, svc: '' + (y.svc ?? ''), svc_name: '' + (r.svc_name ?? SV['' + y.svc]?.name ?? y.svc ?? ''), name: '' + (y.name ?? ''),
kind: home ? 'home' : 'own', state: s.state, sev: s.sev, text: s.text, used: used, free: fr, total: total, pct: pct,
caps: { link: c.link === true, upreq: c.upreq === true, url: c.url === true, trash: c.trash === true, trash_list: c.trash_list === true },
dl: { n: j.n ?? 0, run: j.run ?? 0, kbs: j.kbs ?? 0 }, links: k.links ?? 0, reqs: k.reqs ?? 0,
trash: y.svc == 'pcloud' && (!home || type(root) == 'string' && length(root)) ? ctrash(id, home ? root : null) : null };
};
let AC = [ ...map(mine, (y) => ao(y, false)), ...map(com, (y) => ao(y, true)) ];
let tot = { dl: 0, links: 0, reqs: 0, trash: 0 };
for (let y in AC) { tot.dl += y.dl.n; tot.links += y.links; tot.reqs += y.reqs; tot.trash += y.trash?.n ?? 0; }
return { own: length(mine) > 0, common: length(com) > 0,
home: length(com) ? { used: num(hu?.used), free: free, others: isn(hu?.others) ? hu.others : null, stale: hu == null || hu.stale === true } : null,
acct: a ? { id: '' + (a.id ?? ''), name: '' + (a.name ?? ''), svc: '' + (a.svc ?? ''), used: num(st(a).used), free: num(st(a).free) } : null,
accts: AC, pause: { on: pz, until: pz && isn(PU?.until) ? PU.until : 0 }, quota: cqof(x, num(hu?.used)), tot: tot };
}
function svcof(N, x) {
let W = cfg('wrtfreedom'), ai = W?.ai ?? {}, tg = W?.tg ?? {}, pv = '' + (ai.prov ?? '');
return { cloud: stat(R + '/usr/bin/rclone') != null, ia: ai.on == '1' && length(pv) > 0 && ai['ok_' + pv] == '1' && iaof(x).max != 0,
dl: N.dl?.on === true, far: N.remote?.app === true, tv: N.media?.on === true, pc: N.tm?.on === true || N.fh?.on === true,
bot: length('' + (tg.token ?? '')) > 0 && length('' + (tg.chat ?? '')) > 0 };
}
function farof() {
let F = rjs(FARJ), on = F?.on === true;
return { on: on, open: F?.open === true, url: on && type(F?.url) == 'string' ? F.url : '' };
}
function trashof(u) { let T = rjs(TRASHJ)?.[u]; return { n: int(num(T?.n)), bytes: num(T?.bytes) }; }
function partsof(Q, u) {
let v = Q._parts?.[u];
if (type(v) != 'object') return null;
return { trash: num(v.trash), dl: num(v.dl), video: num(v.video), priv: type(v.priv) == 'int' || type(v.priv) == 'double' ? v.priv : null };
}
const BKST = [ 'ok', 'run', 'warn', 'bad', 'off', 'none' ];
function bkst(s) { return index(BKST, s) >= 0 ? s : 'none'; }
function bkp(o) { return { n: int(num(o?.n)), last: num(o?.last), st: bkst(o?.st) }; }
function bkof(u) {
let B = rjs(BKJ)?.[u];
if (type(B) != 'object') B = {};
let pc = bkp(B.pc), PL = filter(type(B.pc?.list) == 'array' ? B.pc.list : [], (c) => type(c?.name) == 'string' && length(c.name) > 0);
pc.list = map(slice(PL, 0, 20), (c) => ({ name: cut(c.name, 40), kind: c.kind == 'mac' ? 'mac' : 'pc', last: num(c.last), st: bkst(c.st) }));
return { last: num(B.last), ok: B.ok !== false, n: int(num(B.n)), next: num(B.next), err: type(B.err) == 'array' ? length(B.err) : int(num(B.err)),
phone: bkp(B.phone), dirs: bkp(B.dirs), cloud: bkp(B.cloud), pc: pc };
}
function pcof() { return { url: 'http://' + PCHOST + '/pc', short: PCHOST + '/pc', dns: rjs(DNSJ)?.ok === true }; }
function lastof(u, x, S) {
let t = num(x.last);
for (let s, v in S) if (v?.u == u && num(v.t) > t) t = v.t;
return t;
}
function devsof(u, S, BK) {
let D = {};
let add = (k, o) => { if (D[k] == null || D[k].t < o.t) D[k] = o; };
for (let s, v in S) if (v?.u == u && type(v.dev) == 'string' && length(v.dev)) add((v.pc === true ? 'c' : 'a') + lc(v.dev), { name: v.dev, kind: v.pc === true ? 'pc' : 'app', t: num(v.t) });
for (let c in BK.pc.list) add('c' + lc(c.name), { name: c.name, kind: c.kind, t: c.last });
let L = sort(values(D), (a, b) => b.t - a.t);
return length(L) ? slice(L, 0, 20) : null;
}
const MFREEJ = TMP + '/me-free.json';
function mfree(N, M) {
if (M.state != 'ok') return null;
let F = rjs(MFREEJ);
if (type(F) != 'object') F = {};
if (M.sleep) { let v = F[M.id]?.free; return type(v) == 'int' || type(v) == 'double' ? v : null; }
let m = mainmnt(N);
if (!m) return null;
let sv = null;
try { sv = require('fs').statvfs; } catch (e) { sv = null; }
let v = type(UCFG.vfs) == 'function' ? UCFG.vfs(m, null, sv, sh, q) : null;
if (!(+(v?.size ?? 0) > 0)) return null;
if (F[M.id]?.free !== v.free) { F[M.id] = { free: v.free, t: time() }; let t = MFREEJ + '.t' + rid(); writefile(t, sprintf('%J', F)); rename(t, MFREEJ); }
return v.free;
}
function freeof(N, x, U, M) {
let qd = +(x.quota?.disk ?? 0), r = qd * GB - U.disk;
return { disk: qd > 0 ? (r > 0 ? r : 0) : mfree(N, M), cloud: CFREE };
}
function lanipof() {
let F = cfg('firewall'), W = cfg('network'), nets = [];
for (let k, z in F) if (z['.type'] == 'zone') {
let n = type(z.network) == 'array' ? z.network : split('' + (z.network ?? ''), /[ \t]+/);
if (index(n, 'lan') >= 0 || z.name == 'lan') { nets = n; break; }
}
for (let n in nets) {
let a = W[n]?.ipaddr, ip = split('' + (type(a) == 'array' ? a[0] : (a ?? '')), '/')[0];
if (match(ip, /^([0-9]{1,3}\.){3}[0-9]{1,3}$/)) return ip;
}
return '';
}
function smbof(N, u, x) {
let s4 = split(readfile(ETC + '/nas-smb.fp') ?? '', '|')[0] == 'samba4', C = rjs(CJ), S = type(C?.share) == 'object' ? C.share : {}, cl = [];
for (let id in sort(keys(S), (a, b) => +substr(a, 1) - +substr(b, 1))) {
if (S[id]?.on !== true || !match(id, /^a[0-9]{1,3}$/)) continue;
for (let l in split(readfile('/tmp/wf-cloud/mnt/' + id + '.smb') ?? '', '\n')) {
let c = split(l, '|');
if (length(c) >= 4 && match(c[0], /^wfcloud_/) && length(c[1]) && c[6] != '1' && index(split(c[3], ' '), u) >= 0 && index(cl, c[1]) < 0) push(cl, c[1]);
}
}
let n = substr(replace('' + (N.adv?.name ?? ''), /[^A-Za-z0-9-]/g, '-'), 0, 15);
return { drive: s4 ? 'Drive' : 'Drive ' + replace('' + (x.vis ?? u), /[]\\\/:*?"<>|[[:cntrl:]]/g, '-'), cloud: cl, shared: 'Cartella Condivisa',
nb: match(n, /[A-Za-z]/) ? n : 'NAS', lanip: lanipof() };
}
function meout(N, u) {
let x = N.users[u], Q = usedof(), U = usedx(Q, u), pct = pctof(x, U), s = pstate(x, pct), M = mainst(N), S = sread(), BK = bkof(u);
let root = type(UCFG.udir) == 'function' ? UCFG.udir(u, 'root') : null, C = cloudof(N, u, U, x);
U = { disk: U.disk, cloud: num(C.home?.used) };
let FR = freeof(N, x, U, M), DL = dlof(u), LN = linksof(u), RQ = reqsof(u), TR = trashof(u);
let TT = { dl: DL.n + C.tot.dl, links: LN + C.tot.links, reqs: RQ + C.tot.reqs, trash: TR.n + C.tot.trash };
return { user: u, vis: x.vis ?? u, state: s.state, sev: s.sev, text: s.text, pct: pct, since: +(x.since ?? 0), used: U, quota: quotaof(x),
free: FR, full: s.state == 'full', main: M, pause: M.state != 'ok', ia: iaof(x), dl: DL, links: LN, reqs: RQ, tot: TT,
last: lastof(u, x, S), pw_t: num(x.pw_t), trash: TR, parts: partsof(Q, u), cloud: C, svc: svcof(N, x),
far: farof(), bk: BK, pc: pcof(), devs: devsof(u, S, BK), root: root ?? (UCFG.UDIR?.root + '/' + (x.vis ?? u)), smb: smbof(N, u, x) };
}

let WO = {};
function who(req) {
WO = { why: 'who', nj: nget(), reg: SESS };
if (type(UCFG.who) != 'function') return null;
let w = null;
try { w = UCFG.who(req, WO); } catch (e) { w = null; }
return w;
}
function whoerr() { return WO.why == 'blocked' ? E_BLOCKED() : E_WHO(); }

function failed(u, e) {
let lk = 0, vis = u;
let r = nset((N) => {
let x = N.users[u];
if (type(x) != 'object') return { nowrite: true };
vis = x.vis ?? u;
x.fails = +(x.fails ?? 0) + 1;
if (x.fails >= FMAX) { x.fails = 0; x.lock_until = lk = time() + LOCKS; }
return {};
});
if (r?.error) return r;
if (lk) {
ev('nas_user_locked', '🗄️ NAS ¦ ' + vis + ': 5 Tentativi Sbagliati ¦ Bloccata 15 Minuti', '🗄️ NAS ¦ ' + vis + ': 5 Wrong Attempts ¦ Locked 15 Minutes', u);
return E_LOCKED(lk);
}
return e;
}
function locked(x) { return +(x?.lock_until ?? 0) > time() ? E_LOCKED(+x.lock_until) : null; }
const LFJ = TMP + '/lf.json', LFLK = TMP + '/lf.lock';
function prefail(u, ok) {
tmpdir();
if (type(UCFG.pidlock) != 'function' || !UCFG.pidlock(LFLK, TMP, 10)) return E_BUSY();
let o = {};
try {
let F = rjs(LFJ), now = time();
if (type(F) != 'object') F = {};
for (let k, c in F) if (type(c) != 'object' || now - +(c.t ?? 0) >= LOCKS) delete F[k];
if (ok) delete F[u];
else if (+(nraw().users[u]?.lock_until ?? 0) > now) o = { locked: true };
else {
let c = F[u] ?? { n: 0 };
c.n = +c.n + 1; c.t = now;
if (c.n >= FMAX) {
delete F[u];
let lk = now + LOCKS, r = nset((N) => { let x = N.users[u]; if (type(x) != 'object') return { nowrite: true }; x.fails = 0; x.lock_until = lk; return {}; });
o = r?.error ? r : { lk: lk };
}
else F[u] = c;
}
let t = LFJ + '.t' + rid();
writefile(t, sprintf('%J', F)); rename(t, LFJ);
} catch (e) { o = E_BUSY(); }
UCFG.pidunlock(LFLK);
return o;
}

const PCSESS = 43200;
function stimeout() {
for (let k, s in cfg('rpcd')) if (s['.type'] == 'rpcd' && match('' + (s.timeout ?? ''), /^[0-9]{1,6}$/) && +s.timeout >= 60) return +s.timeout;
return 300;
}
function aclobj() {
let G = rjs(ACLF)?.[ACLG], O = [], seen = {};
for (let m in [ 'read', 'write' ]) for (let o, F in (type(G?.[m]?.ubus) == 'object' ? G[m].ubus : {}))
for (let f in (type(F) == 'array' ? F : [])) { let k = o + '.' + f; if (!seen[k]) { seen[k] = 1; push(O, [ o, f ]); } }
return O;
}
let UBC = null;
function ubc() {
if (UBC == null) {
UBC = false;
if (!length(R) && trim(readfile('/proc/self/comm') ?? '') != 'rpcd') { try { UBC = require('ubus').connect(null, 30) ?? false; } catch (e) { UBC = false; } }
}
return UBC;
}
function ubj(o, m, a) {
let U = ubc();
if (U) {
let r = null, e = null;
try { r = U.call(o, m, a); e = U.error(); } catch (x) { return null; }
return r != null ? r : (e == null ? {} : null);
}
let s = sh('ubus call ' + q(o) + ' ' + q(m) + ' ' + q(sprintf('%J', a)) + ' 2>/dev/null; echo "#$?"'), r = match(s, /#([0-9]+)[\n]*$/);
if (!r || r[1] != '0') return null;
s = replace(s, /#[0-9]+[\n]*$/, '');
if (!length(trim(s))) return {};
try { return json(s); } catch (e) { return null; }
}
function sclean() {
let K = [];
for (let s in keys(sread())) if (!sidok(s) || ubj('session', 'get', { ubus_rpc_session: s }) == null) push(K, s);
if (length(K)) swrite((S) => { for (let s in K) delete S[s]; });
return length(K);
}
function login(a, zn) {
begin();
a = type(a) == 'object' ? a : {};
if (a.ubus_rpc_session != null) return E_WHO();
let zk = type(zn) == 'string' && match(zn, /^(lan|vpn|guest|net)$/) != null;
if (!(zk ? athome(zn) || (zn == 'net' && a.via === 'remote') : zoneok(a.ip, a.via))) return E_LAN();
let u = lc(trim('' + (a.user ?? ''))), p = a.pass, N = nget(), x = userok(u) ? N.users[u] : null;
let E = err('login', 'Nome o password sbagliati (dopo 5 errori si aspetta 15 minuti)', 'Wrong name or password (after 5 errors wait 15 minutes)');
if (type(x) != 'object' || x.cam) { phash('' + p); return E; }
let pre = prefail(u);
if (pre.locked) { phash('' + p); return E; }
if (pre.error) return pre;
if (type(p) != 'string' || !pcheck(p, x.ph)) {
if (pre.lk) ev('nas_user_locked', '🗄️ NAS ¦ ' + (x.vis ?? u) + ': 5 Tentativi Sbagliati ¦ Bloccata 15 Minuti', '🗄️ NAS ¦ ' + (x.vis ?? u) + ': 5 Wrong Attempts ¦ Locked 15 Minutes', u);
return E;
}
prefail(u, true);
if (pre.lk) { let r0 = nset((M) => { let y = M.users[u]; if (!y || +(y.lock_until ?? 0) != pre.lk) return { nowrite: true }; y.lock_until = 0; return {}; }); if (r0?.error) return r0; }
if (x.blocked) return E_BLOCKED();
if (stat(R + '/usr/sbin/smbd') && UCFG.smbusers(R)?.[u] !== true) {
let pw = pwset(u, p);
if (pw && index(pw, 'samba4') >= 0) {
nset((M) => { let y = M.users[u]; if (y) y.pw = uniq([ ...(type(y.pw) == 'array' ? y.pw : []), ...pw ]); return {}; });
let M = UCFG.modof(MC, NASVCUC);
if (type(M?.engine_sync) == 'function') { try { M.engine_sync(); } catch (e) {} }
}
}
let now = time();
if (+(x.fails ?? 0) > 0 || now - +(x.last ?? 0) >= 3600) { let r = nset((M) => { if (M.users[u]) { M.users[u].fails = 0; M.users[u].last = now; } return {}; }); if (r?.error) return r; }
let dev = type(a.dev) == 'string' ? cut(trim(replace(replace(a.dev, /[[:space:]]+/g, ' '), /[[:cntrl:]<>"'\\`]/g, '')), 40) : '';
sclean();
let O = aclobj();
if (!length(O)) return E_BUSY();
let pc = a.pc === true, to = pc ? PCSESS : stimeout(), c = ubj('session', 'create', { timeout: to }), sid = c?.ubus_rpc_session;
if (!sidok(sid)) return E_BUSY();
let ok = ubj('session', 'grant', { ubus_rpc_session: sid, scope: 'ubus', objects: O }) != null &&
ubj('session', 'set', { ubus_rpc_session: sid, values: { username: u } }) != null &&
swrite((S) => { S[sid] = length(dev) ? { u: u, t: time(), dev: dev } : { u: u, t: time() }; if (pc) S[sid].pc = true; });
if (!ok) { ubj('session', 'destroy', { ubus_rpc_session: sid }); return E_BUSY(); }
return { sid: sid, timeout: to, user: u, vis: x.vis ?? u, role: 'user' };
}

function persok(pid) {
if (pid == null || pid == '') return true;
if (!match('' + pid, /^p_[a-z0-9]{1,16}$/)) return false;
return cfg('wrtfreedom')[pid]?.['.type'] == 'person';
}
function padd(vis, user, o) {
let out = null;
let r = nset((N) => {
if (length(people(N)) >= PMAX) return err('full', 'Massimo 32 persone', 'At most 32 people');
let n = names(N, vis, user);
if (n.error) return n;
let x = { vis: n.vis, self: false, new: false, blocked: false, since: time(), quota: { disk: 0, cloud: 0 }, fails: 0, lock_until: 0 };
for (let k, v in o) if (v != null) x[k] = v;
N.users[n.user] = x;
if (N.reg == null) N.reg = true;
out = n;
return n;
});
return r?.error ? r : out;
}

const M = {
nas_users: {
args: { act: 'x', user: 'x', vis: 'x', person: 'x', disk: 0, cloud: 0, max: 0, files: 'x', on: true, secs: 0, pass: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let w = who(req);
if (!w) return whoerr(req);
if (w.adm !== true) return E_WHO();
let a = req.args ?? {}, act = '' + (a.act ?? 'get'), u = '' + (a.user ?? '');
if (act == 'get') return uget(nget());
if (act == 'propose') return { user: propose(nget(), trim('' + (a.vis ?? ''))) };
if (act == 'adminpw') return admpw(a.pass);
if (act == 'reg') {
if (type(a.on) != 'bool') return err('on', 'Valore non valido', 'Invalid value');
let r = nset((N) => { N.reg = a.on; return {}; });
return r?.error ? r : uget(nget());
}
if (act == 'add') {
if (!persok(a.person)) return err('person', 'Persona di Dispositivi non trovata', 'Devices person not found');
let code = ucode6(), h = code ? phash(code) : null;
if (!h) return E_BUSY();
let until = time() + UNLOCKS;
let n = padd(a.vis, a.user, { person: length('' + (a.person ?? '')) ? '' + a.person : null, unlock: { hash: h, until: until } });
if (n.error) return n;
mkbase(n.user);
svcsync();
cloudcruser(n.user);
return { ...uget(nget()), user: n.user, code: code, until: until };
}
if (act == 'forget') {
let N = nget(), g = null;
for (let x in N.gone) if (x?.user == u) g = x;
if (!g) return E_NONE();
if (!rmhome(N, g.vis ?? '', u)) return err('nomain', 'Manca il Disco Principale', 'No Main Drive');
cloududel(u, N);
let r = nset((N2) => { N2.gone = filter(N2.gone, (x) => x?.user != u); return {}; });
if (r?.error) return r;
svcsync();
return uget(nget());
}
let N0 = nget();
if (!userok(u) || type(N0.users[u]) != 'object' || N0.users[u].cam) return E_NONE();
if (act == 'ok') {
let r = nset((N) => { if (N.users[u]) delete N.users[u].new; return {}; });
return r?.error ? r : uget(nget());
}
if (act == 'unlock') {
let code = ucode6(), h = code ? phash(code) : null;
if (!h) return E_BUSY();
let until = time() + UNLOCKS;
let r = nset((N) => { let x = N.users[u]; if (!x) return E_NONE(); x.unlock = { hash: h, until: until }; x.fails = 0; x.lock_until = 0; return {}; });
return r?.error ? r : { ...uget(nget()), code: code, until: until };
}
if (act == 'block' || act == 'unblock') {
let on = act == 'block';
let r = nset((N) => { let x = N.users[u]; if (!x) return E_NONE(); if (on) x.blocked = true; else delete x.blocked; return {}; });
if (r?.error) return r;
if (on) { sdrop(u, null); cloudupclose(u); }
detach('sh ' + q(SH) + ' ' + act + ' ' + q(u));
svcsync();
return uget(nget());
}
if (act == 'quota') {
let d = a.disk ?? N0.users[u].quota?.disk ?? 0, c = a.cloud ?? N0.users[u].quota?.cloud ?? 0;
if (type(d) != 'int' || type(c) != 'int' || d < 0 || c < 0 || d > 100000 || c > 100000) return err('quota', 'Spazio massimo non valido', 'Invalid maximum space');
let r = nset((N) => { let x = N.users[u]; if (!x) return E_NONE(); x.quota = { disk: d, cloud: c }; return {}; });
return r?.error ? r : uget(nget());
}
if (act == 'ia') {
if (type(a.max) != 'int' || a.max < 0 || a.max > 1000) return err('max', 'Tetto non valido: da 0 a 1000', 'Invalid limit: 0 to 1000');
let r = nset((N) => { let x = N.users[u]; if (!x) return E_NONE(); x.ia_max = a.max; return {}; });
return r?.error ? r : uget(nget());
}
if (act == 'del') {
let fm = '' + (a.files ?? '');
if (fm != 'keep' && fm != 'del') return err('files', 'Scegli se tenere o cancellare i file', 'Choose whether to keep or delete the files');
let vis = N0.users[u].vis ?? u;
if (fm == 'del' && !mainmnt(N0)) return err('nomain', 'Manca il Disco Principale', 'No Main Drive');
cloududetach(u);
let r = nset((N) => {
let x = N.users[u];
if (!x) return E_NONE();
if (fm == 'keep') push(N.gone, { user: u, vis: x.vis ?? u, since: +(x.since ?? 0), t: time() });
delete N.users[u];
return {};
});
if (r?.error) return r;
cloudjobs(u);
if (fm == 'del') cloududel(u, N0);
sdrop(u, null);
unlink(AIMEMD + '/' + u + '.json');
let I = rjs(INV);
if (type(I) == 'object') { let n = 0; for (let k, v in I) if (v?.user == u) { delete I[k]; n++; } if (n) wsec(INV, sprintf('%J', I)); }
udrop(u);
sh('sh ' + q(SH) + ' userdel ' + q(u) + ' >/dev/null 2>&1');
cloudmntkick();
if (fm == 'del') rmhome(nget(), vis, u);
svcsync();
return uget(nget());
}
if (act == 'invite') {
let secs = a.secs ?? 900;
if (type(secs) != 'int' || secs < 60 || secs > 3600) return err('secs', 'Durata non valida', 'Invalid duration');
let I = rjs(INV), now = time();
if (type(I) != 'object') I = {};
for (let k, v in I) if ((v?.until ?? 0) <= now) delete I[k];
let K = sort(keys(I), (x, y) => I[x].until - I[y].until);
while (length(K) >= 20) delete I[shift(K)];
let tk = rid() + rid();
I[tk] = { user: u, label: N0.users[u].vis ?? u, until: now + secs };
wsec(INV, sprintf('%J', I));
let XM = UCFG.modof(MC, NASXUC), base = '';
if (type(XM?.invite_ready) == 'function') {
let ir = XM.invite_ready();
if (type(ir) == 'object' && (ir.code != null || ir.error != null)) { delete I[tk]; wsec(INV, sprintf('%J', I)); return ir; }
if (type(ir?.base) == 'string') base = ir.base;
}
return { url: length(base) ? base + '/c/' + tk : '', tok: tk, secs: secs, until: now + secs };
}
return err('act', 'Azione sconosciuta', 'Unknown action');
}
},
nas_me: {
args: { act: 'x', old: 'x', new: 'x', vis: 'x', user: 'x', pass: 'x', read: true, ip: 'x', via: 'x', code: 'x', blind: true, as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let a = req.args ?? {}, act = '' + (a.act ?? 'get'), w = who(req);
if (!w) return whoerr(req);
if (act == 'propose' || act == 'register' || act == 'recover') {
if (w.sys !== true || exists(a, 'ubus_rpc_session')) return E_WHO();
if (act == 'recover' ? !zoneok(a.ip, a.via) : !athome(zone(a.ip))) return E_LAN();
if (act == 'propose') return { user: a.blind === true ? slug(trim('' + (a.vis ?? ''))) : propose(nget(), trim('' + (a.vis ?? ''))) };
if (act == 'register') {
let N = nget();
if (N.reg === false) return err('reg_off', 'Registrazione chiusa', 'Sign-up closed');
if (a.read !== true) return err('read', 'Leggi l\'avviso sui file', 'Read the notice about the files');
if (!passok(a.pass)) return E_PASS();
let n = names(N, a.vis, a.user);
if (n.error) return n;
if (!UCFG.pidlock(RLK, TMP, 30)) return E_BUSY();
let r = null;
try {
let now = time(), T = filter(rjs(REGF) ?? [], (t) => type(t) == 'int' && t > now - 3600);
if (length(T) >= RMAXH) r = err('many', 'Troppe registrazioni: riprova tra un\'ora', 'Too many sign-ups: try again in an hour');
else {
let rc = rcode(), ph = phash(a.pass), rh = rc ? phash(cnorm(rc)) : null;
r = !ph || !rh ? E_BUSY() : padd(n.vis, n.user, { self: true, new: true, ph: ph, rc: rh });
if (r.error == null) { r.rc = rc; push(T, now); wsec(REGF, sprintf('%J', T)); }
}
} catch (e) { r = E_BUSY(); }
UCFG.pidunlock(RLK);
if (r.error) return r;
let rc = r.rc;
let pw = pwset(r.user, a.pass);
if (pw) nset((N2) => { if (N2.users[r.user]) N2.users[r.user].pw = pw; return {}; });
mkbase(r.user);
svcsync();
cloudcruser(r.user);
ev('nas_user_new', '🗄️ NAS ¦ ' + r.vis + ' Si È Registrata ¦ Va Bene o Blocca', '🗄️ NAS ¦ ' + r.vis + ' Signed Up ¦ Approve or Block', r.user);
return { user: r.user, vis: r.vis, rc: rc };
}
let u = lc(trim('' + (a.user ?? ''))), N = nget(), x = userok(u) ? N.users[u] : null, c = cnorm(a.code);
let E = err('code', 'Codice sbagliato o scaduto', 'Wrong or expired code');
if (type(x) != 'object' || x.cam) { phash(c); return E; }
let lk = locked(x);
if (lk) return lk;
let ok = length(c) > 0 && (pcheck(c, x.rc) || (+(x.unlock?.until ?? 0) > time() && pcheck(c, x.unlock?.hash)));
if (!ok) return failed(u, E);
if (!passok(a.new)) return E_PASS();
let rc = rcode(), ph = phash(a.new), rh = rc ? phash(cnorm(rc)) : null;
if (!ph || !rh) return E_BUSY();
let pw = pwset(u, a.new);
let r = nset((N2) => { let y = N2.users[u]; if (!y) return E_NONE(); y.ph = ph; y.pw_t = time(); y.rc = rh; y.fails = 0; y.lock_until = 0; delete y.unlock; if (pw) y.pw = pw; return {}; });
if (r?.error) return r;
sdrop(u, null);
mkbase(u);
svcsync();
cloudcruser(u);
return { ok: true, rc: rc };
}
let u = w.u ?? (w.own != 'admin' ? w.own : null), N = nget(), x = u != null ? N.users[u] : null;
if (type(x) != 'object' || x.cam) return E_WHO();
if (x.blocked) return E_BLOCKED();
if (act == 'get') return meout(N, u);
if (act == 'pass') {
if (w.sys === true) return E_WHO();
let lk = locked(x);
if (lk) return lk;
if (type(a.old) != 'string' || !pcheck(a.old, x.ph)) return failed(u, err('login', 'Password attuale sbagliata', 'Wrong current password'));
if (!passok(a.new)) return E_PASS();
let ph = phash(a.new);
if (!ph) return E_BUSY();
let pw = pwset(u, a.new);
let r = nset((N2) => { let y = N2.users[u]; if (!y) return E_NONE(); y.ph = ph; y.pw_t = time(); y.fails = 0; if (pw) y.pw = pw; return {}; });
if (r?.error) return r;
sdrop(u, '' + (a.ubus_rpc_session ?? ''));
return { ok: true };
}
if (act == 'newrc') {
if (w.sys === true) return E_WHO();
let lk = locked(x);
if (lk) return lk;
if (type(a.old) != 'string' || !pcheck(a.old, x.ph)) return failed(u, err('login', 'Password attuale sbagliata', 'Wrong current password'));
let rc = rcode(), rh = rc ? phash(cnorm(rc)) : null;
if (!rh) return E_BUSY();
let r = nset((N2) => { let y = N2.users[u]; if (!y) return E_NONE(); y.rc = rh; y.fails = 0; return {}; });
if (r?.error) return r;
return { ok: true, rc: rc };
}
return err('act', 'Azione sconosciuta', 'Unknown action');
}
},
login: login,
sess_clean: function() {
if (trim(readfile('/proc/self/comm') ?? '') == 'rpcd') return -1;
tmpdir();
return sclean();
}
};

return M;
