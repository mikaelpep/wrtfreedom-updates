#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH
R=; [ -n "$WF_NASROOT" ] && [ ! -e /etc/openwrt_release ] && R=$WF_NASROOT
W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; TMP=/tmp/wf-nas; NJ=$ETC/nas.json; PEND=$ETC/nas.pend.json
REALM='WrtFreedom NAS'
SCPID=/var/run/wf-dlnascan.pid; [ -n "$R" ] && SCPID=$TMP/wf-dlnascan.pid
mkdir -p $TMP
EN=0; [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { [ -f $W/event.sh ] && sh $W/event.sh cron "$1" nas "$2" >/dev/null 2>&1; logger -t wrtfreedom "$2" 2>/dev/null; true; }
once() { f=$TMP/once.$1; n=$(date +%s); l=$(cat "$f" 2>/dev/null); [ -n "$l" ] && [ $((n - l)) -lt "$2" ] && return 1; echo "$n" > "$f"; }
hs() { awk -v b="${1:-0}" 'BEGIN { u="B KB MB GB TB"; split(u, U, " "); i=1; while (b >= 1024 && i < 5) { b /= 1024; i++ } s = (i == 1 ? sprintf("%d", b) : sprintf("%.1f", b)); sub(/\./, ",", s); print s " " U[i] }'; }
nj() { ucode -e "let N = {}; try { N = json(require(\"fs\").readfile(\"$NJ\") ?? \"{}\"); } catch (e) {} $1" 2>/dev/null; }
for lb_f in "${0%/*}/lib.sh" "$W/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
mnt_of() { wf_mntof "$1" "$R"; }
pst() {
if command -v stat >/dev/null 2>&1; then stat -c '%U:%G %a' "$1" 2>/dev/null; return; fi
ls -ld "$1" 2>/dev/null | awk 'NR == 1 { m = $1
		u = (substr(m, 2, 1) == "r") * 4 + (substr(m, 3, 1) == "w") * 2 + (index("xs", substr(m, 4, 1)) > 0)
		g = (substr(m, 5, 1) == "r") * 4 + (substr(m, 6, 1) == "w") * 2 + (index("xs", substr(m, 7, 1)) > 0)
		o = (substr(m, 8, 1) == "r") * 4 + (substr(m, 9, 1) == "w") * 2 + (index("xt", substr(m, 10, 1)) > 0)
		s = (index("sS", substr(m, 4, 1)) > 0) * 4 + (index("sS", substr(m, 7, 1)) > 0) * 2 + (index("tT", substr(m, 10, 1)) > 0)
		printf "%s:%s %s%d%d%d\n", $3, $4, (s ? s : ""), u, g, o }'
}
jesc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
SPD=${WF_NASPEED:-$W/naspeed.uc}
spd() { [ -n "$1" ] && [ $# -gt 1 ] && [ -f "$SPD" ] && ucode "$SPD" add "$@" </dev/null >/dev/null 2>&1; true; }

mounts() { awk '$1 ~ /^\/dev\// { p = $2; gsub(/\\040/, " ", p); if (p !~ /^\/(overlay|rom|boot|tmp|proc|sys|dev)?$/) print p }' $R/proc/mounts; }
trash() {
d=$(nj 'print(int(N.trash?.days ?? 30));'); case "$d" in ''|*[!0-9]*) d=30;; esac; [ "$d" -gt 0 ] || return 0
CUT=$(( $(date +%s) - d * 86400 ))
mounts | while IFS= read -r m; do
T="$m/.wf-trash"; [ -d "$T" ] || continue
for f in "$T"/info/*.info; do
[ -f "$f" ] || continue
w=$(sed -n 's/^when=\([0-9]*\).*/\1/p' "$f" | head -n 1); [ -n "$w" ] && [ "$w" -lt $CUT ] || continue
n=${f##*/}; n=${n%.info}
case "$n" in ''|.*|*/*) continue ;; esac
rm -rf "${T:?}/files/$n"; rm -f "$f"
done
for u in "$T"/*; do
case "${u##*/}" in files|info) continue ;; esac
[ -d "$u" ] && [ ! -L "$u" ] || continue
find "$u" -type f -mtime +$((d - 1)) -exec rm -f {} \; 2>/dev/null
find "$u" -mindepth 1 -depth -type d -exec rmdir {} \; 2>/dev/null
done
done
u_=$(wf_udir shared root 2>/dev/null); u_=${u_%%/*}; [ -n "$u_" ] || u_=Utenti
mounts | while IFS= read -r m; do
for T in "$m/$u_"/*/.wf-trash; do
[ -d "$T" ] && [ ! -L "$T" ] || continue
find "$T" -type f -mtime +$((d - 1)) -exec rm -f {} \; 2>/dev/null
find "$T" -depth -type d -exec rmdir {} \; 2>/dev/null
done
done; true
}

UQ='let C = loadfile(getenv("WF_U"))(), D = C.UDIR, f = C.udir, A = getenv("WF_ADM"), N = {};
if (!D || type(f) != "function") exit(0);
try { N = json(require("fs").readfile(getenv("WF_NJ")) ?? "{}"); } catch (e) {}
let ok = (p) => type(p) == "string" && length(p) > 0 && !match(p, /(^|\/)\.\.?(\/|$)/) && index(p, "\n") < 0 && index(p, "\t") < 0;
let up = (p) => replace(p, /\/[^\/]*$/, "");
let o = (p, k, u) => { if (ok(p)) print(p, "\t", k, "\t", u, "\n"); };
let P = [];
for (let u, x in (type(N.users) == "object" ? N.users : {}))
	if (type(x) == "object" && !x.cam && match(u, /^[a-z][a-z0-9]{0,19}$/) && ok(f(u, "root"))) push(P, u);
/* 3.42 (WP-R9): anche byte del Cestino della persona (trash-own.json di nasf.uc, assente = 0), Download e le cartelle
   Film fuori dai Download (Cartella Personale, File Caricati, File Ricevuti) per le parti dello spazio (nas_me parts);
   poi la Cartella Personale (parts.priv) */
if (getenv("WF_Q") == "quota") {
	let TO = {};
	try { TO = json(require("fs").readfile(getenv("WF_TO")) ?? "{}"); } catch (e) {}
	if (type(TO) != "object") TO = {};
	let q = (p) => ok(p) && p != "-" ? p : "-";
	for (let u in P) {
		let tb = +(TO[u]?.bytes ?? 0);
		print(u, "\t", f(u, "root"), "\t", int(N.users[u].quota?.disk ?? 0), "\t", tb > 0 ? sprintf("%d", tb) : "0", "\t", q(f(u, "dl")), "\t",
			q(f(u, "media", "video")), "\t", q(f(u, "up", "video")), "\t", q(f(u, "recv", "video")), "\t", q(f(u, "priv")), "\t",
			replace("" + (N.users[u].vis ?? u), /[\t\n]/g, " "), "\n");
	}
	exit(0);
}
/* passaggi del 15/11: righe «posto vecchio<TAB>posto nuovo (udir)», in quest ordine (i genitori prima): Multimedia/Film,
   Musica e Foto su nella Cartella Personale; Backup in Backup e Sincronizzazione; Sincronizzazioni dentro col nome
   nuovo; Backup Del Mac e Del PC rimasti accanto a Backup; Foto Del Telefono dentro Foto. I nomi vecchi stanno solo qui.
   Multimedia di prima da udir mold. Cartella Condivisa (15/11, scelta dell utente): Multimedia/Film, Musica e Foto su
   nella Condivisa, poi la riga «Multimedia<TAB>» (posto nuovo vuoto) = Multimedia tolta solo se vuota (rmdir) */
if (getenv("WF_Q") == "move") {
	let mv = (a, b) => { if (ok(a) && ok(b) && a != b) print(a, "\t", b, "\n"); };
	let M = f("shared", "mold");
	if (ok(M)) {
		for (let t in keys(D.mtypes ?? {})) mv(M + "/" + D.mtypes[t], f("shared", "media", t));
		print(M, "\t\n");
	}
	for (let u in [ "admin", ...P ]) {
		let r = f(u, "root"), pv = f(u, "priv"), m = f(u, "mold");
		if (!ok(r) || !ok(pv)) continue;
		/* Multimedia della persona tolta solo se vuota (rmdir), come quella della Condivisa */
		if (ok(m)) { for (let t in keys(D.mtypes ?? {})) mv(m + "/" + D.mtypes[t], f(u, "media", t)); print(m, "\t\n"); }
		mv(r + "/Backup", f(u, "backup"));
		mv(r + "/Sincronizzazioni", f(u, "sync"));
		for (let k in [ "tm", "fh" ]) if (ok(D[k])) mv(r + "/" + D[k], f(u, k));
		mv(r + "/Foto Del Telefono", f(u, "phones"));
	}
	/* 3.42 (M2 del 16/11): cartella della persona della 3.40 (old340.home di nasu.uc, relativa al Disco Principale; con
	   old340.disk di un altro disco niente) dentro Utenti/<vis> col suo nome; mai una cartella di base di qualcuno, mai
	   se è già lì dentro (anche solo con le maiuscole diverse, NTFS ed exFAT) */
	let base = [ lc(D.root), lc(f("shared", "root") ?? ""), lc(f("admin", "root") ?? "") ];
	for (let u in P) push(base, lc(f(u, "root")));
	for (let u in P) {
		let o3 = N.users[u].old340, h = o3?.home, r = f(u, "root");
		if (type(o3) != "object" || type(h) != "string" || !ok(h) || substr(h, 0, 1) == "/" || !ok(r)) continue;
		h = replace(h, /\/+$/, "");
		if (o3.disk != null && o3.disk != N.main?.id) continue;
		let lh = lc(h), lr = lc(r);
		if (index(base, lh) >= 0 || substr(lh, 0, length(lr) + 1) == lr + "/" || substr(lr, 0, length(lh) + 1) == lh + "/") continue;
		mv(h, r + "/" + replace(h, /^.*\//, ""));
	}
	exit(0);
}
o(D.root, "U", "");
/* 15/11: Cartella Condivisa senza Multimedia (media senza tipo = lei stessa): Film, Musica, Foto, Documenti, Programmi, Varie */
o(f("shared", "root"), "S", "");
for (let t in keys(D.mtypes ?? {})) o(f("shared", "media", t), "S", "");
for (let k in [ "docs", "prog", "misc" ]) o(f("shared", k), "S", "");
let r = f("admin", "router");
o(f("admin", "root"), "P", A); if (ok(r)) o(up(r), "q", A); o(r, "c", A); o(f("admin", "cams"), "c", A);
/* 15/11 sera: File Caricati della cartella Amministratore con le sottocartelle per tipo (come i Download delle persone) */
o(f("admin", "up"), "p", A);
for (let t in keys(D.types ?? {})) o(f("admin", "up", t), "p", A);
for (let u in P) {
	/* 15/11 sera: Film, Musica e Foto direttamente nella Cartella Personale (media senza tipo = lei stessa) */
	o(f(u, "root"), "P", u); o(f(u, "priv"), "q", u);
	for (let t in keys(D.mtypes ?? {})) o(f(u, "media", t), "p", u);
	o(f(u, "docs"), "p", u); o(f(u, "prog"), "p", u);
	/* CR-a B8: Download/ come le cartelle della persona (p, senza sticky): con Dividi Per Tipo spento i file stanno lì e
	   la persona li cancella anche da Cartelle In Rete */
	/* 15/11 sera: anche File Caricati e File Ricevuti per tipo come Download (p); in File Ricevuti le cartelle di prima,
	   una per richiesta, restano come sono */
	for (let k in [ "dl", "up", "recv" ]) {
		o(f(u, k), "p", u);
		for (let t in keys(D.types ?? {})) o(f(u, k, t), "p", u);
	}
	/* Backup e Sincronizzazione contiene Backup Del Mac, Backup Del PC e Sincronizzazione (cartelle di base): q, poi le
	   tre dentro; Dal Telefono dentro Foto e Video (già sopra, 17/11 sera); 18/11: anche Da Catalogare dentro Foto e
	   Video (in ubase di ucfg.uc, qui mancava: non rinasceva) */
	o(f(u, "pub"), "p", u); o(f(u, "backup"), "q", u);
	for (let k in [ "phones", "tocat", "tm", "fh", "tg", "sync" ]) o(f(u, k), "p", u);
}'
uq() { U=${WF_UCFGUC:-$W/ucfg.uc}; [ -f "$U" ] || return 0; WF_Q=$1 WF_U=$U WF_NJ=$NJ WF_ADM=$ADM WF_TO=$TMP/trash-own.json ucode -e "$UQ" </dev/null 2>/dev/null; }
mainck() {
MM=; x=$(nj 'let m = N.main ?? {}; print(lc("" + (m.uuid ?? "")), "|", m.id ?? "");'); mu=${x%%|*}; mi=${x#*|}
[ -n "$mu$mi" ] || { echo none > $TMP/main.st; return 1; }
[ -f $TMP/mainpause.json ] && { echo pause > $TMP/main.st; return 1; }
[ -n "$mu" ] && MM=$(mnt_of "$mu"); [ -z "$MM" ] && [ -n "$mi" ] && MM=$(mnt_of "$mi")
if [ -n "$MM" ] && [ -d "$MM" ]; then echo ok > $TMP/main.st; return 0; fi
MM=; echo off > $TMP/main.st; return 1
}
NASUC=${WF_NASUC:-$W/nas.uc}
NASUUC=${WF_NASUUC:-$W/nasu.uc}
SYS=/sys; [ -n "$R" ] && SYS=${WF_SYS:-$R/sys}
mainbase() {
awk -v m="$MM" '$1 ~ /^\/dev\// { p = $2; gsub(/\\040/, " ", p); if (p == m) { d = $1; sub(/^\/dev\//, "", d); print d; exit } }' $R/proc/mounts 2>/dev/null |
sed -E 's/^(nvme[0-9]+n[0-9]+|mmcblk[0-9]+)p[0-9]+$/\1/; s/^((s|h|v|xv)d[a-z]+)[0-9]+$/\1/'
}
mainio() { b=$(mainbase); [ -n "$b" ] && awk -v b="$b" 'NF >= 7 { print b, $3, $7 }' "$SYS/class/block/$b/stat" > $TMP/main.io 2>/dev/null; true; }
bkmove() {
tb=$(printf '\t'); uq move > $TMP/bkmove.t
while IFS="$tb" read -r a b; do
[ -n "$a" ] || continue
if [ -z "$b" ]; then
[ -d "$1/$a" ] && [ ! -L "$1/$a" ] && rmdir "$1/$a" 2>/dev/null && logger -t wrtfreedom "NAS: $a vuota, tolta" 2>/dev/null
continue
fi
o_="$1/$a" n_="$1/$b"; p_=${n_%/*}
[ -d "$o_" ] && [ ! -L "$o_" ] || continue
if [ -e "$n_" ] || [ -L "$n_" ]; then
once bkboth 86400 && logger -t wrtfreedom "NAS: $a e $b ci sono tutte e due, lasciate come sono" 2>/dev/null; continue
fi
[ -L "$p_" ] && continue
[ -d "$p_" ] || mkdir "$p_" 2>/dev/null || continue
mv "$o_" "$n_" 2>/dev/null && logger -t wrtfreedom "NAS: $a spostata in $b" 2>/dev/null
done < $TMP/bkmove.t
rm -f $TMP/bkmove.t; true
}
basedirs() {
[ -n "$1" ] && [ -d "$1" ] || return 0
bkmove "$1"
n_=0; tb=$(printf '\t'); uq dirs > $TMP/dirs.t
while IFS="$tb" read -r p k w; do
d="$1/$p"; [ -L "$d" ] && continue
c_=0
if [ ! -d "$d" ]; then [ -e "$d" ] && continue; mkdir "$d" 2>/dev/null || continue; n_=$((n_ + 1)); c_=1; fi
case $k in U) o_=root:root; m_=755 ;; S) o_=root:$GN; m_=1770 ;; P) o_=root:$w; m_=1770 ;; q) o_=root:$w; m_=3770 ;;
p) o_=root:$w; m_=2770 ;; c) [ $c_ = 1 ] || continue; o_=root:$w; m_=2770 ;; *) continue ;; esac
[ "$(pst "$d")" = "$o_ $m_" ] || { chown "$o_" "$d" && chmod "$m_" "$d"; } 2>/dev/null
done < $TMP/dirs.t
rm -f $TMP/dirs.t; echo $n_
}
quota() {
QCH=; [ -n "$MM" ] || mainck || return 0
tb=$(printf '\t'); o=$TMP/quota.json.t; printf '{' > $o; c=; fl=$TMP/full.list.t; : > $fl; op=$TMP/quota.parts.t; : > $op
uq quota > $TMP/quota.in
while IFS="$tb" read -r u p qg tk dl v1 v2 v3 pv lb; do
[ -d "$MM/$p" ] && [ ! -L "$MM/$p" ] || continue
x=$(nice -n 19 du -k "$MM/$p" 2>/dev/null | awk -F "$tb" -v r="$MM/$p" -v d="$MM/$dl" -v a="$MM/$v1" -v b="$MM/$v2" -v e="$MM/$v3" \
			-v pp="$MM/$pv" -v n="$dl" -v n1="$v1" -v n2="$v2" -v n3="$v3" -v np="$pv" '
			function in_p(x, s) { if (np != "-" && index(x, pp "/") == 1) w += s }
			$2 == r { t = $1 } n != "-" && $2 == d { l = $1; in_p(d, $1) } n1 != "-" && $2 == a { v += $1; in_p(a, $1) }
			n2 != "-" && $2 == b { v += $1; in_p(b, $1) } n3 != "-" && $2 == e { v += $1; in_p(e, $1) } np != "-" && $2 == pp { o = $1 }
			END { o -= w; if (o < 0) o = 0; printf "%.0f %.0f %.0f %.0f", t * 1024, l * 1024, v * 1024, o * 1024 }')
set -- $x; b=${1:-0}; bd=${2:-0}; bv=${3:-0}; bp=${4:-0}
set -- "$MM/.wf-vers"/@GMT-*/"$p"
if [ -e "$1" ]; then
vk=$(nice -n 19 du -sck "$@" 2>/dev/null | tail -n 1 | cut -f 1)
case "$vk" in ''|*[!0-9]*) vk=0 ;; esac
b=$(( b + vk * 1024 ))
fi
case "$tk" in ''|*[!0-9]*) tk=0 ;; esac
printf '%s"%s":%s' "$c" "$u" "$b" >> $o
printf '%s"%s":{"trash":%s,"dl":%s,"video":%s,"priv":%s}' "$c" "$u" "$tk" "$bd" "$bv" "$bp" >> $op; c=,
case "$qg" in ''|*[!0-9]*) qg=0 ;; esac
[ "$qg" -gt 0 ] || continue
pc=$(awk -v b="$b" -v q="$qg" 'BEGIN { printf "%d", b * 100 / (q * 1073741824) }')
if [ "$pc" -ge 100 ]; then
echo "$u" >> $fl
once q100-$u 86400 && ev nas_quota100 "💾 NAS ¦ $(t "Spazio Finito Di $lb" "$lb Is Out Of Space") ¦ $(hs $b) $(t 'su' 'of') $qg GB ¦ $(t 'Non scrive più' 'Writing stopped')"
elif [ "$pc" -ge 90 ]; then
once q90-$u 86400 && ev nas_quota90 "💾 NAS ¦ $(t "Quota Di $lb Al $pc%" "$lb Quota At $pc%") ¦ $(hs $b) $(t 'su' 'of') $qg GB"
fi
done < $TMP/quota.in
rm -f $TMP/quota.in
{ [ -n "$c" ] && printf ',"_parts":{' || printf '"_parts":{'; cat $op; echo '}}'; } >> $o; rm -f $op; mv -f $o $TMP/quota.json
sort $fl > $TMP/full.list.n; rm -f $fl
if [ "$(cat $TMP/full.list.n)" = "$(cat $TMP/full.list 2>/dev/null)" ] && [ -f $TMP/full.list ]; then rm -f $TMP/full.list.n
else mv -f $TMP/full.list.n $TMP/full.list; QCH=1; fi
}

dlnadb() {
k=$(uci -q show minidlna | sed -n "s/^minidlna\.\([^.]*\)=minidlna$/\1/p" | head -n 1)
d=; [ -n "$k" ] && d=$(uci -q get minidlna.$k.db_dir); echo "${d:-/var/run/minidlna}/files.db"
}
dlnaadded() {
db=$(dlnadb); command -v sqlite3 >/dev/null 2>&1 && [ -f "$db" ] || { echo 0; return; }
H=$(date +%H); Mi=$(date +%M); S=$(date +%S); md=$(( $(date +%s) - ${H#0} * 3600 - ${Mi#0} * 60 - ${S#0} ))
n=$(sqlite3 -readonly "$db" "SELECT count(*) FROM DETAILS WHERE MIME IS NOT NULL AND TIMESTAMP >= $md" 2>/dev/null)
case "$n" in ''|*[!0-9]*) echo 0 ;; *) echo "$n" ;; esac
}
dlnastat() {
h=$TMP/dlna.html
uclient-fetch -q -T 3 -O $h http://127.0.0.1:8200/ 2>/dev/null || { rm -f $h; return 0; }
WF_ADD=$(dlnaadded) ucode -e '
		let fs = require("fs"), t = fs.readfile("'$h'") ?? "", L = {}, tv = [];
		let A = {}, ok = (x) => match(x, /^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$/) != null, seen = {};
		for (let l in split(fs.readfile("/tmp/dhcp.leases") ?? "", "\n")) { let p = split(l, " "); if (length(p) >= 4) L[p[2]] = { mac: lc(p[1]), name: p[3] != "*" ? p[3] : "" }; }
		for (let l in split(fs.readfile("/proc/net/arp") ?? "", "\n")) { let p = split(l, /[ \t]+/); if (length(p) >= 4 && ok(p[3])) A[p[0]] = lc(p[3]); }
		let n = (k) => { let m = match(t, regexp(k + " files</td><td>([0-9]+)")); return m ? +m[1] : 0; };
		let c = split(t, "Connected clients")[1] ?? "";
		for (let r in split(c, "</tr>")) {
			let f = map(match(r, /<td>[^<]*<\/td>/g) ?? [], (x) => replace(x[0], /<\/?td>/g, ""));
			if (length(f) < 3 || !match(f[2], /^[0-9.]+$/)) continue;
			/* 11/11 (prova su OpenWrt vero, n. 9): il router stesso (pagina letta da 127.0.0.1, MAC FF:FF:FF:FF:FF:FF) non è una TV */
			if (match(f[2], /^127\./)) continue;
			/* MAC: dalla pagina, altrimenti dai lease DHCP o dalla tabella ARP del router */
			let mac = null;
			for (let x in f) if (ok(x)) mac = lc(x);
			mac = mac ?? L[f[2]]?.mac ?? A[f[2]];
			if (!mac || seen[mac] || mac == "ff:ff:ff:ff:ff:ff" || mac == "00:00:00:00:00:00") continue;
			seen[mac] = 1;
			push(tv, { mac: mac, ip: f[2], name: L[f[2]]?.name || f[1] });
		}
		fs.writefile("'$TMP'/dlna.json.t", sprintf("%J", { video: n("Video"), music: n("Audio"), photo: n("Image"), added: +(getenv("WF_ADD") ?? 0), tvs: tv, t: time() }));
		fs.rename("'$TMP'/dlna.json.t", "'$TMP'/dlna.json");' 2>/dev/null
rm -f $h
}
dlnareindex() {
k=$(uci -q show minidlna | sed -n "s/^minidlna\.\([^.]*\)=minidlna$/\1/p" | head -n 1); [ -n "$k" ] || { rm -f $TMP/dlna.scan; return 0; }
db=$(uci -q get minidlna.$k.db_dir)
echo $$ > $TMP/dlnascan.sh.pid
/etc/init.d/minidlna stop >/dev/null 2>&1
[ -n "$db" ] && rm -f "$db/files.db"
/etc/init.d/minidlna start >/dev/null 2>&1
rm -f $TMP/dlna.json
dlnago
dlnadone ""
rm -f $TMP/dlnascan.sh.pid
}
dlnascan() {
C=/var/etc/minidlna.conf; B=/usr/sbin/minidlnad
if [ ! -f $C ] || [ ! -x $B ]; then dlnareindex; return; fi
echo $$ > $TMP/dlnascan.sh.pid
/etc/init.d/minidlna stop >/dev/null 2>&1
$B -S -r -f $C -P $SCPID >/dev/null 2>&1 </dev/null &
p=$!
dlnadone "$p"
kill "$p" 2>/dev/null; sleep 1; rm -f $SCPID $TMP/dlnascan.sh.pid
/etc/init.d/minidlna start >/dev/null 2>&1
dlnago
}
dlnastop() {
s=$(cat $TMP/dlnascan.sh.pid 2>/dev/null); rm -f $TMP/dlnascan.sh.pid
case "$s" in ''|*[!0-9]*) ;; *) [ "$s" != $$ ] && grep -q dlnascan /proc/$s/cmdline 2>/dev/null && kill "$s" 2>/dev/null ;; esac
p=$(cat $SCPID 2>/dev/null)
case "$p" in ''|*[!0-9]*) p= ;; esac
if [ -n "$p" ] && [ "$(cat /proc/$p/comm 2>/dev/null)" = minidlnad ]; then
for c in $(pgrep -P "$p" 2>/dev/null); do [ "$(cat /proc/$c/comm 2>/dev/null)" = minidlnad ] && kill "$c" 2>/dev/null; done
kill "$p" 2>/dev/null; i=0
while kill -0 "$p" 2>/dev/null && [ $i -lt 10 ]; do sleep 1; i=$((i + 1)); done
kill -9 "$p" 2>/dev/null
fi
rm -f $SCPID $TMP/dlna.scan $TMP/dlna.json
$R/etc/init.d/minidlna start >/dev/null 2>&1
dlnago
true
}
dlnakids() {
E_=" $(awk '$4 == "01" && $2 ~ /:2008$/ { printf "%s ", $10 }' $R/proc/net/tcp $R/proc/net/tcp6 2>/dev/null) "
for c_ in $(pgrep -P "$1" 2>/dev/null); do
[ "$(cat $R/proc/$c_/comm 2>/dev/null)" = minidlnad ] || continue
k_=0
for f_ in $R/proc/$c_/fd/*; do
l_=$(readlink "$f_" 2>/dev/null) || continue
case "$l_" in "socket:["*"]") i_=${l_#socket:\[}; i_=${i_%]}; case "$E_" in *" $i_ "*) k_=1; break ;; esac ;; esac
done
[ $k_ = 0 ] && echo "$c_"
done; true
}
dlnaslp() {
id=$(nj 'print(split(N.media?.dirs?.[0] ?? "", ":")[0]);'); [ -n "$id" ] || return 1
m=$(mnt_of "$id"); [ -n "$m" ] || return 1
dv=$(awk -v m="$m" '$1 ~ /^\/dev\// { p = $2; gsub(/\\040/, " ", p); if (p == m) { sub(/^\/dev\//, "", $1); print $1; exit } }' $R/proc/mounts)
case "$dv" in ''|md*) return 1 ;; nvme*|mmcblk*) b=${dv%p[0-9]*} ;; *) b=$(echo "$dv" | sed 's/[0-9]*$//') ;; esac
[ "$(WF_B="$b" WF_S="$SYS/class/block/$b/stat" WF_IO=$TMP/io.json WF_SC="$TMP/scan/$id.io" WF_NJ=$NJ ucode -e '
		let fs = require("fs"), rj = (f) => { try { return json(fs.readfile(f) ?? "null"); } catch (e) { return null; } };
		let c = rj(getenv("WF_NJ"))?.sleep ?? {}, m = type(c.mins) == "int" && c.mins >= 0 ? c.mins : 15, r = 0;
		let x = split(trim(fs.readfile(getenv("WF_S")) ?? ""), /[ \t]+/);
		if (m > 0 && c.keep !== true && length(x) >= 7) {
			let rb = +x[2] * 512, wb = +x[6] * 512;
			for (let p in [ rj(getenv("WF_SC")), (rj(getenv("WF_IO")) ?? {})[getenv("WF_B")] ])
				if (type(p) == "object" && p.r == rb && p.w == wb && +(p.chg ?? 0) > 0) { r = time() - p.chg >= m * 60 ? 1 : 0; break; }
		}
		print(r, "\n");' </dev/null 2>/dev/null)" = 1 ]
}
dlnaauto() {
[ "$(nj 'print(N.media?.on === true ? 1 : 0);')" = 1 ] && [ -e $R/etc/init.d/minidlna ] || return 0
l_=$(cut -d' ' -f1 $TMP/dlna.scan 2>/dev/null); case "$l_" in ''|*[!0-9]*) ;; *) [ $(( $(date +%s) - l_ )) -lt 10800 ] && return 0 ;; esac
dlnaslp && return 0
mkdir -p $TMP; echo "$(date +%s) scan" > $TMP/dlna.scan
( sleep "${WF_DLNAWAIT:-30}"; sh "$0" dlnascan ) </dev/null >/dev/null 2>&1 &
true
}
dlnadone() {
p=$1; i=0
sleep 5
[ -n "$p" ] || p=$(pgrep -o -f /usr/sbin/minidlnad)
while [ -n "$p" ] && kill -0 "$p" 2>/dev/null && [ -n "$(dlnakids "$p")" ] && [ $i -lt 720 ]; do sleep 10; i=$((i + 1)); done
date +%s > $ETC/nas-media.last
rm -f $TMP/dlna.scan $TMP/dlna.json
n=$(dlnaadded)
if [ "${n:-0}" -gt 0 ]; then
if [ "$n" = 1 ]; then m_=$(t '1 file nuovo' '1 new file'); else m_="$n $(t 'file nuovi' 'new files')"; fi
ev nas_media_new "🗄️ $(t 'Server Multimediale' 'Media Server') ¦ $m_"
fi
true
}
dlnawatch() {
dlnaslp && { [ -f $TMP/dlna-watch.json ] && touch $TMP/dlna-watch.json; return 0; }
mx=$(cat /proc/sys/fs/inotify/max_user_watches 2>/dev/null); u=0; tn=0; top=
L=$(nj 'for (let s in (N.media?.dirs ?? [])) print(s, "\n");')
while IFS= read -r s; do
[ -n "$s" ] || continue
m=$(mnt_of "${s%%:*}"); [ -n "$m" ] && [ -d "$m${s#*:}" ] || continue
c=$(nice -n 19 find "$m${s#*:}" -type d 2>/dev/null | wc -l)
u=$((u + c)); [ "$c" -gt $tn ] && { tn=$c; top=$s; }
done <<EOF
$L
EOF
printf '{"used":%s,"max":%s,"dir":"%s","t":%s}\n' "$u" "${mx:-0}" "$(jesc "$top")" "$(date +%s)" > $TMP/dlna-watch.json.t && mv $TMP/dlna-watch.json.t $TMP/dlna-watch.json
[ -n "$mx" ] && [ "$u" -ge "$mx" ] && once media-watch 86400 &&
ev nas_media_watch "⚠️ $(t 'Server Multimediale' 'Media Server') ¦ $(t 'Troppe cartelle' 'Too many folders') ¦ $u $(t 'su' 'of') $mx"
true
}
nason() {
if command -v jsonfilter >/dev/null 2>&1; then [ "$(jsonfilter -q -i $NJ -e '@.on' 2>/dev/null)" = true ]
else [ "$(nj 'print(N.on === true ? 1 : 0);')" = 1 ]; fi
}
sparewant() {
[ -f $NJ ] || return 1
for n in $(sed -n '/^const SPARE = {/,/^};/s/^[[:space:]]*\([A-Za-z0-9_-]*\): \[.*/\1/p' "${WF_NASVCUC:-$W/nasvc.uc}" 2>/dev/null); do [ -e $R/etc/init.d/$n ] && return 0; done
C=${WF_CFGDIR:-/etc/config/}; [ -e "${C}ksmbd" ] || [ -e "${C}samba4" ] || [ -e $TMP/smb2.user ] && return 0
grep -q '"spw"' $NJ 2>/dev/null
}
ucf() {
V=${WF_NASVCUC:-$W/nasvc.uc}; [ -f "$V" ] || return 0
WF_A="$2" ucode -e "let M = loadfile('$V')(); M['$1'](getenv('WF_A'));" </dev/null >/dev/null 2>&1
}
tvpoll() {
echo "$1" | grep -qE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' || return 1
l=$TMP/tvpoll-$(echo "$1" | tr -d ':').lock; mkdir "$l" 2>/dev/null || return 0
ucf tvpoll "$1"; rmdir "$l"
}
dlnago() {
id=$(nj 'print(split(N.media?.dirs?.[0] ?? "", ":")[0]);'); [ -n "$id" ] || return 0
(
i=0
while [ $i -lt 15 ]; do
m=$(pgrep -o -f /usr/sbin/minidlnad); [ -n "$m" ] || exit 0
P=$(dlnakids "$m")
[ -n "$P" ] && { spd "$id" "!$m" $P; exit 0; }
sleep 2; i=$((i + 1))
done
) </dev/null >/dev/null 2>&1 &
}

davroot() {
rm -rf $TMP/dav; mkdir -p $TMP/dav
[ -f $ETC/nas-dav.links ] && while IFS="$(printf '\t')" read -r n p; do [ -n "$n" ] && [ -d "$p" ] && ln -s "$p" "$TMP/dav/$n"; done < $ETC/nas-dav.links
u=$(sed -n 's/^server.upload-dirs = ( "\(.*\)" )$/\1/p' $ETC/nas-dav.conf 2>/dev/null)
[ -n "$u" ] && awk -v m="${u%/*}" '{ p = $2; gsub(/\040/, " ", p) } p == m { f = 1 } END { exit !f }' $R/proc/mounts && mkdir -p "$u"
true
}
urlesc() {
printf '%s\n' "$1" | awk '{ s = $0; o = ""; H = "0123456789abcdef"
		while (match(s, /(%|\\x)[0-9A-Fa-f][0-9A-Fa-f]/)) {
			a = substr(s, 1, RSTART - 1); if (index(a, "\\")) exit
			h = tolower(substr(s, RSTART + RLENGTH - 2, 2)); v = (index(H, substr(h, 1, 1)) - 1) * 16 + index(H, substr(h, 2, 1)) - 1
			if (v < 32 || v == 127) exit
			o = o a sprintf("\\0%o", v); s = substr(s, RSTART + RLENGTH)
		}
		if (index(s, "\\")) exit
		print o s }'
}
davown() {
case "$1" in ''|-) return 0 ;; esac
okname "$1" || return 0
ug=$(awk -F: -v u="$1" '$1 == u && $5 == "wf-nas" { print $3 ":" $4; exit }' $R/etc/passwd); [ -n "$ug" ] || return 0
e_=$(urlesc "$2"); [ -n "$e_" ] || return 0
p=$(printf '%b' "$e_")
case "$p" in /*) ;; *) return 0 ;; esac
n=${p#/}; n=${n%%/*}
[ -n "$n" ] && grep -qxF "# wf-own $n" $ETC/nas-dav.conf 2>/dev/null || return 0
c_=$(wf_udir shared root) && c_=${c_##*/} && case "$p" in "/$n/$c_"|"/$n/$c_/"*)
[ "$(readlink "$TMP/dav/$n/$c_" 2>/dev/null)" = "../$c_" ] && { p=/$c_${p#"/$n/$c_"}; n=$c_; } ;; esac
[ -n "$n" ] && grep -qxF "# wf-own $n" $ETC/nas-dav.conf 2>/dev/null || return 0
b=$(readlink -f "$TMP/dav/$n" 2>/dev/null) && [ -d "$b" ] || return 0
f=$(readlink -f "$TMP/dav$p" 2>/dev/null) && [ -e "$f" ] || return 0
case "$f" in "$b"/?*) ;; *) return 0 ;; esac
if [ "$n" = "$c_" ]; then
case "$(pst "$f")" in *":$GN 1770") return 0 ;; esac
if [ "$3" = COPY ] && [ -d "$f" ] && [ ! -L "$f" ]; then
find "$f" -xdev -user 0 ! -type l -cmin -5 -exec chown "$ug" {} + -exec chmod g+w {} + 2>/dev/null
else
find "$f" -maxdepth 0 -xdev -user 0 ! -type l -exec chown "$ug" {} + -exec chmod g+w {} + 2>/dev/null
fi
return 0
fi
find "$f" -xdev -user 0 ! -type l -exec chown "$ug" {} + -exec chmod g+w {} + 2>/dev/null; true
}
davlog() {
while read -r st us de me ta _; do
case "$st" in 2[0-9][0-9]) ;; *) continue ;; esac
case "$me" in
PUT|MKCOL|LOCK) ;;
COPY|MOVE) case "$de" in ''|-) continue ;; esac; ta=${de#*://}; case "$ta" in /*) ;; *) ta=/${ta#*/} ;; esac ;;
*) continue ;;
esac
davown "$us" "${ta%%\?*}" "$me"
done
}

SQ=$TMP/svcq.d; SL=$TMP/svcq.run
sqls() { for f in "$SQ"/*; do [ -e "$f" ] || continue; case "$f" in *.t) ;; *) echo "${f##*/}";; esac; done; }
svcrun() {
while [ -n "$(sqls)" ]; do
if ! mkdir $SL 2>/dev/null; then
p=$(cat $SL/pid 2>/dev/null); lt=$(date -r $SL +%s 2>/dev/null)
[ -n "$p" ] && kill -0 "$p" 2>/dev/null && return 0
[ -z "$p" ] && [ -n "$lt" ] && [ $(( $(date +%s) - lt )) -lt 60 ] && return 0
rm -rf $SL; continue
fi
echo $$ > $SL/pid
w=${WF_SVCQ:-2}; [ -n "$R" ] && w=${WF_SVCQ:-0}
n=; i=0
while [ "$w" -gt 0 ] && [ $i -lt 5 ]; do c=$(sqls | wc -l); [ "$c" = "$n" ] && break; n=$c; sleep "$w"; i=$((i + 1)); done
F=$(sqls)
A=$(for f in $F; do cat "$SQ/$f"; done | awk 'NF { if ($1 == "fw") { fw = 1; next } n = $1; sub(/:[a-z]*$/, "", n); if (!(n in A)) O[++k] = n; A[n] = $1 }
			END { for (i = 1; i <= k; i++) printf "%s ", A[O[i]]; if (fw) printf "fw" }')
for f in $F; do rm -f "$SQ/$f"; done
S=; G=0
for x in $A; do if [ "$x" = fw ]; then G=1; else S="$S $x"; fi; done
SMBM=$(cat $TMP/smb.mode 2>/dev/null); rm -f $TMP/smb.mode
[ -n "$S" ] && SMBM=$SMBM svc $S
[ $G = 1 ] && fw
rm -rf $SL
done
true
}
svc() {
g_=
for x in $(for y in "$@"; do case "$y" in *:on) ;; *) echo "$y" ;; esac; done) $(for y in "$@"; do case "$y" in *:on) echo "$y" ;; esac; done); do
n=${x%%:*}; a=${x##*:}; i=$R/etc/init.d/$n; [ -x "$i" ] || [ -f "$i" ] || continue
if [ "$a" = on ] && [ "$SMBM" = keep ] && { [ "$n" = samba4 ] || [ "$n" = ksmbd ]; } && $i running >/dev/null 2>&1; then
continue
elif [ "$a" = on ] && [ "$SMBM" = reload ] && { [ "$n" = samba4 ] || [ "$n" = ksmbd ]; } && $i running >/dev/null 2>&1; then
$i reload >/dev/null 2>&1 || $i restart >/dev/null 2>&1
g_=1
elif [ "$a" = on ]; then $i enable >/dev/null 2>&1; $i restart >/dev/null 2>&1; [ "$n" = minidlna ] && dlnago
case "$n" in ksmbd|samba4) g_=1 ;; esac
else $i stop >/dev/null 2>&1; $i disable >/dev/null 2>&1; fi
done
[ -n "$g_" ] && [ -f $W/cloudmnt.sh ] && { ( sh $W/cloudmnt.sh check ) </dev/null >/dev/null 2>&1 & }
true
}
fwdel() { for s in $(uci -q show firewall | sed -n "s/^firewall\.\(wf_nas_[A-Za-z0-9_]*\)=rule$/\1/p"); do uci -q delete firewall.$s; done; uci -q commit firewall; }
fw() {
command -v fw4 >/dev/null 2>&1 || return 0
G=0; i=0
while [ $i -lt 30 ]; do
mkdir /tmp/wf-fw.lock 2>/dev/null && { G=1; break; }
lt=$(date -r /tmp/wf-fw.lock +%s 2>/dev/null)
if [ -n "$lt" ] && [ $(( $(date +%s) - lt )) -gt 120 ]; then rmdir /tmp/wf-fw.lock 2>/dev/null; else sleep 1; fi
i=$((i + 1))
done
if ! fw4 -q check >/dev/null 2>&1; then
fwdel; ev nas_fw "⚠️ NAS ¦ $(t 'Regole del Firewall rifiutate' 'Firewall rules rejected') ¦ $(t 'Tolte, porte chiuse' 'Removed, ports closed')"
fi
fw4 -q reload >/dev/null 2>&1
[ $G = 1 ] && rmdir /tmp/wf-fw.lock; true
}

fhas() { [ -f "$1" ] && awk -F: -v u="$2" '$1 == u { f = 1 } END { exit !f }' "$1"; }
fdel() {
[ -f "$1" ] || return 0
cp -p "$1" "$1.wf$$" && awk -F: -v u="$2" -v n="${3:-0}" -v v="$4" '!($1 == u && (n == 0 || $n == v))' "$1" > "$1.wf$$" &&
mv -f "$1.wf$$" "$1" || { rm -f "$1.wf$$"; return 1; }
}
GN=wfnas; ADM=$(wf_udir admin root 2>/dev/null); ADM=${ADM##*/}; BK=$ETC/nas-blk
okname() { [ "$1" = $ADM ] || echo "$1" | grep -qE '^[a-z0-9][a-z0-9._-]{0,31}$'; }
IDS=$ETC/nas-ids
nextid() { wf_nextid "$1" $IDS; }
gidof() { awk -F: -v g="$1" '$1 == g { print $3; exit }' $R/etc/group 2>/dev/null; }
gmem() {
f=$R/etc/group; [ -f "$f" ] || return 0
h=$(awk -F: -v g="$1" -v u="$2" '$1 == g { n = split($4, M, ","); for (i = 1; i <= n; i++) if (M[i] == u) f = 1 } END { print f ? 1 : 0 }' "$f")
if [ "$3" = add ]; then [ "$h" = 1 ] && return 0; else [ "$h" = 0 ] && return 0; fi
cp -p "$f" "$f.wf$$" && awk -F: -v OFS=: -v g="$1" -v u="$2" -v a="$3" '$1 == g { n = split($4, M, ","); s = ""
		for (i = 1; i <= n; i++) if (M[i] != "" && M[i] != u) s = s (s == "" ? "" : ",") M[i]
		if (a == "add") s = s (s == "" ? "" : ",") u; $4 = s } { print }' "$f" > "$f.wf$$" && mv -f "$f.wf$$" "$f" || { rm -f "$f.wf$$"; return 1; }
}
sysuser() {
wf_pwlock || return 1
r_=0
if fhas $R/etc/passwd "$1" && ! awk -F: -v u="$1" '$1 == u && $5 == "wf-nas" { f = 1 } END { exit !f }' $R/etc/passwd; then r_=1
elif [ "$2" = smb ]; then
fhas $R/etc/passwd "$1" || { id=$(nextid $R/etc/passwd); [ -n "$id" ] && wf_fadd $R/etc/passwd "$1:x:$id:65534:wf-nas:/var:/bin/false" || r_=1; }
else
w=$(gidof $GN); [ -n "$w" ] || { w=$(nextid $R/etc/group); [ -n "$w" ] && wf_fadd $R/etc/group "$GN:x:$w:" || r_=1; }
g=$(gidof "$1"); [ -n "$g" ] || { g=$(nextid $R/etc/group); [ -n "$g" ] && wf_fadd $R/etc/group "$1:x:$g:" || r_=1; }
[ -n "$g" ] && { [ "$g" -lt 2000 ] || [ "$g" -ge 3000 ]; } && r_=1
if [ $r_ = 0 ]; then
o=$(awk -F: -v u="$1" '$1 == u { print $3 ":" $4; exit }' $R/etc/passwd)
if [ -z "$o" ]; then id=$(nextid $R/etc/passwd); [ -n "$id" ] && wf_fadd $R/etc/passwd "$1:x:$id:$g:wf-nas:/var:/bin/false" || r_=1
elif [ "${o#*:}" != "$g" ]; then fdel $R/etc/passwd "$1" 5 wf-nas && wf_fadd $R/etc/passwd "$1:x:${o%%:*}:$g:wf-nas:/var:/bin/false" || r_=1; fi
[ $r_ = 0 ] && gmem $GN "$1" add
fi
fi
if [ $r_ = 0 ]; then
awk -F: -v u="$1" '$1 == u && $2 != "!" { f = 1 } END { exit !f }' $R/etc/shadow 2>/dev/null && fdel $R/etc/shadow "$1"
fhas $R/etc/shadow "$1" || wf_fadd $R/etc/shadow "$1:!:0:0:99999:7:::"
fi
wf_pwunlock; return $r_
}
userset() {
f=$2
[ -f "$f" ] || return 1
P=$(cat "$f"); rm -f "$f"
upw "$1" "$P" "$3"; r=$?; P=; return $r
}
usersets() {
f=$1; [ -f "$f" ] || return 1
L=$(cat "$f"); rm -f "$f"
tb=$(printf '\t')
while IFS="$tb" read -r u p; do [ -n "$u" ] && upw "$u" "$p" | sed "s/^/$u /"; done <<EOF
$L
EOF
L=; true
}
useradm() { userset $ADM "$1"; }
upw() {
u=$1; P=$2
okname "$u" && [ -n "$P" ] || return 1
sysuser "$u" "$3" || { P=; return 1; }
if command -v ksmbd.adduser >/dev/null 2>&1; then
{ printf '%s\n%s\n' "$P" "$P" | ksmbd.adduser -u "$u" || printf '%s\n%s\n' "$P" "$P" | ksmbd.adduser -a "$u"; } >/dev/null 2>&1 && echo ok:ksmbd
fi
command -v smbpasswd >/dev/null 2>&1 && printf '%s\n%s\n' "$P" "$P" | spw -s -a "$u" >/dev/null 2>&1 && echo ok:samba4
umask 077
if [ "$3" = smb ]; then
fhas $ETC/nas-dav.digest "$u" && fdel $ETC/nas-dav.digest "$u"
else
h=$(printf '%s' "$u:$REALM:$P" | md5sum | cut -c1-32)
{ [ -f $ETC/nas-dav.digest ] && awk -F: -v u="$u" '$1 != u' $ETC/nas-dav.digest; echo "$u:$REALM:$h"; } > $ETC/nas-dav.digest.t && mv $ETC/nas-dav.digest.t $ETC/nas-dav.digest && echo ok:dav
fi
P=
[ -e "$BK/$u" ] && userblock "$u" nokick >/dev/null 2>&1; true
}
smbkick() {
u=$1; P_=$R/proc; i_=$(awk -F: -v u="$u" '$1 == u && $5 == "wf-nas" { print $3; exit }' $R/etc/passwd); K_=; ks=
command -v smbstatus >/dev/null 2>&1 && K_=$(smbstatus -b -u "$u" 2>/dev/null | awk -v u="$u" '$2 == u { p = $1; sub(/^.*:/, "", p); if (p ~ /^[0-9]+$/) print p }')
for d in $P_/[0-9]*; do
c_=; read -r c_ 2>/dev/null < "$d/comm"
case "$c_" in ksmbd.mountd*) ks=1; continue ;; smbd|smbd\[*) ;; *) continue ;; esac
pp=$(awk '/^PPid:/ { print $2; exit }' "$d/status" 2>/dev/null); c_=; [ -n "$pp" ] && read -r c_ 2>/dev/null < "$P_/$pp/comm"
case "$c_" in smbd|smbd\[*) ;; *) continue ;; esac
p=${d##*/}
case " $(echo $K_) " in *" $p "*) kill "$p" 2>/dev/null; continue ;; esac
[ -n "$i_" ] && awk -v i="$i_" '/^Uid:/ { for (k = 2; k <= 5; k++) if ($k == i) f = 1 } END { exit !f }' "$d/status" 2>/dev/null && kill "$p" 2>/dev/null
done
[ -n "$ks" ] && cat $P_/net/tcp $P_/net/tcp6 2>/dev/null | awk '$2 ~ /:01BD$/ && $4 == "01" { f = 1 } END { exit !f }' && sqadd ksmbd:on
true
}
sqadd() {
mkdir -p $SQ; f=$SQ/$(date +%s)000000000.$$.sh
echo "$1" > "$f.t" && mv -f "$f.t" "$f" && { ( svcrun ) </dev/null >/dev/null 2>&1 & }
true
}
KDB=$R/etc/ksmbd/ksmbdpwd.db
userblock() {
u=$1; okname "$u" && [ "$u" != $ADM ] || return 1
umask 077; mkdir -p $BK; : > "$BK/$u"
if fhas $KDB "$u"; then
awk -F: -v u="$u" '$1 == u' $KDB > "$BK/$u.k"
{ command -v ksmbd.adduser >/dev/null 2>&1 && ksmbd.adduser -d "$u" </dev/null >/dev/null 2>&1; } || fdel $KDB "$u"
command -v ksmbd.control >/dev/null 2>&1 && ksmbd.control -r >/dev/null 2>&1
fi
spw -d "$u" >/dev/null 2>&1
if fhas $ETC/nas-dav.digest "$u"; then
awk -F: -v u="$u" '$1 == u' $ETC/nas-dav.digest > "$BK/$u.d" && fdel $ETC/nas-dav.digest "$u"
fi
[ "$2" = nokick ] || smbkick "$u"
echo ok:block
}
userunblock() {
u=$1; okname "$u" || return 1
[ -e "$BK/$u" ] || { echo ok:unblock; return 0; }
umask 077
if [ -s "$BK/$u.k" ] && ! fhas $KDB "$u"; then
{ [ -f $KDB ] && cat $KDB; cat "$BK/$u.k"; } > $KDB.wf$$ && mv -f $KDB.wf$$ $KDB
command -v ksmbd.control >/dev/null 2>&1 && ksmbd.control -r >/dev/null 2>&1
fi
spw -e "$u" >/dev/null 2>&1
if [ -s "$BK/$u.d" ] && ! fhas $ETC/nas-dav.digest "$u"; then
{ [ -f $ETC/nas-dav.digest ] && cat $ETC/nas-dav.digest; cat "$BK/$u.d"; } > $ETC/nas-dav.digest.t && mv -f $ETC/nas-dav.digest.t $ETC/nas-dav.digest
fi
rm -f "$BK/$u" "$BK/$u.k" "$BK/$u.d"; echo ok:unblock
}
sysdel() {
wf_pwlock || return 1
g=$(awk -F: -v u="$1" '$1 == u && $5 == "wf-nas" { print $4; exit }' $R/etc/passwd)
fdel $R/etc/passwd "$1" 5 wf-nas; fdel $R/etc/shadow "$1" 2 '!'
[ -n "$g" ] && [ "$g" -ge 2000 ] && [ "$g" -lt 3000 ] && fdel $R/etc/group "$1" 3 "$g"
gmem $GN "$1" del
wf_pwunlock
}
SPW=$R/etc/samba/smbpasswd; SPC=$TMP/smbpw.conf
spwc() {
s_=$R/etc/samba/smb.conf.template; b_=; f_=
if [ -f "$s_" ]; then
b_=$(sed -n 's/^[[:space:]]*passdb[[:space:]]\{1,\}backend[[:space:]]*=[[:space:]]*//p' "$s_" | tail -n 1 | tr -d '\r')
f_=$(sed -n 's/^[[:space:]]*smb[[:space:]]\{1,\}passwd[[:space:]]\{1,\}file[[:space:]]*=[[:space:]]*//p' "$s_" | tail -n 1 | tr -d '\r')
fi
[ -n "$b_" ] || b_=tdbsam
case "$b_" in smbpasswd:*) f_=${b_#smbpasswd:}; b_=smbpasswd ;; esac
f_=$(echo "$f_" | sed 's/[[:space:]]*$//'); [ -n "$f_" ] && SPW=$R$f_
c_=$(printf '[global]\n\tpassdb backend = %s\n\tsmb passwd file = %s\n\tprivate dir = %s' "${b_%% *}" "$SPW" "$R/etc/samba")
[ "$c_" = "$(cat $SPC 2>/dev/null)" ] && return 0
mkdir -p $TMP; printf '%s\n' "$c_" > $SPC.t && mv -f $SPC.t $SPC
}
spw() { command -v smbpasswd >/dev/null 2>&1 || return 1; spwc; smbpasswd -c $SPC "$@"; }
userdel() {
u=$1; okname "$u" || return 1
if command -v ksmbd.adduser >/dev/null 2>&1 || command -v ksmbd.deluser >/dev/null 2>&1; then
{ ksmbd.adduser -d "$u" || ksmbd.deluser "$u"; } </dev/null >/dev/null 2>&1
fi
fhas $KDB "$u" && fdel $KDB "$u" && { command -v ksmbd.control >/dev/null 2>&1 && ksmbd.control -r >/dev/null 2>&1; }
spw -x "$u" >/dev/null 2>&1
spwc; fhas $SPW "$u" && fdel $SPW "$u"
awk -F: -v u="$u" '$1 == u && $5 == "wf-nas" { f = 1 } END { exit !f }' $R/etc/passwd 2>/dev/null && sysdel "$u"
fdel $ETC/nas-dav.digest "$u"; rm -f "$BK/$u" "$BK/$u.k" "$BK/$u.d"; true
}
smborphans() {
spwc; [ -s $SPW ] || return 0
m_=$(awk '$1 == "passwd" { print $2; exit }' $IDS 2>/dev/null); case "$m_" in ''|*[!0-9]*) m_=0 ;; esac
o_=$(awk -F: -v m="$m_" 'NR == FNR { P[$1] = 1; next } /^[^#]/ && !($1 in P) { print ($2 >= 2000 && $2 <= m + 0 ? "w" : "x") $1 }' $R/etc/passwd $SPW 2>/dev/null)
[ -n "$o_" ] || return 0
x_=
for e_ in $o_; do u_=${e_#?}
if [ "${e_%"$u_"}" = w ] && okname "$u_"; then fdel $SPW "$u_"; else x_="$x_ $u_"; fi
done
[ -n "$x_" ] && once smborph 86400 && logger -t wrtfreedom "smbpasswd: utenti senza utente unix non del NAS, lasciati:$x_" 2>/dev/null
true
}

pendleft() { u=$(sed -n 's/.*"until":\([0-9]*\).*/\1/p' $PEND 2>/dev/null); [ -n "$u" ] && echo $((u - $(date +%s))); }
back() {
sleep "${1:-60}"; [ -f $PEND ] || return 0
l=$(pendleft); [ -n "$l" ] && [ "$l" -le 0 ] && ubus call wrtfreedom nas_adv '{"act":"back"}' >/dev/null 2>&1; true
}

fpnow() {
C=${WF_CFGDIR:-/etc/config/}
{ awk '$1 ~ /^\/dev\// { print $1, $2 }' $R/proc/mounts 2>/dev/null | sort
cat $TMP/mnt.json "${C}ksmbd" "${C}samba4" "${C}minidlna" "${C}network" $ETC/nasdns.json $ETC/nas-dav.links $TMP/full.list \
			$R/etc/ksmbd/ksmbd.conf.template $R/etc/samba/smb.conf.template 2>/dev/null; readlink $TMP/dlnadb 2>/dev/null
readlink /tmp/wf-dlnadb 2>/dev/null
cat /tmp/wf-cloud/dav.list 2>/dev/null
cat "${WF_NASVCUC:-$W/nasvc.uc}" 2>/dev/null
jsonfilter -q -i $NJ -e '@.main.uuid' -e '@.main.id' 2>/dev/null
[ -f $TMP/mainpause.json ] && echo mainpause; } | md5sum | cut -c1-32
}
DLGID=$ETC/nas-dlna.gid
pwgid() {
f=$R/etc/passwd; [ -f "$f" ] || return 1
cp -p "$f" "$f.wf$$" && awk -F: -v OFS=: -v u="$1" -v g="$2" '$1 == u { $4 = g } { print }' "$f" > "$f.wf$$" && mv -f "$f.wf$$" "$f" || { rm -f "$f.wf$$"; return 1; }
}
dlnagrp() {
w=$(gidof $GN); [ -n "$w" ] || return 0
o=$(awk -F: '$1 == "minidlna" { print $4; exit }' $R/etc/passwd 2>/dev/null); [ -n "$o" ] || return 0
h=$(awk -F: -v g=$GN '$1 == g { n = split($4, M, ","); for (i = 1; i <= n; i++) if (M[i] == "minidlna") f = 1 } END { print f ? 1 : 0 }' $R/etc/group 2>/dev/null)
[ "$o" = "$w" ] && [ "$h" = 1 ] && return 0
wf_pwlock || return 0
[ "$o" != "$w" ] && { [ -s $DLGID ] || echo "$o" > $DLGID; pwgid minidlna "$w"; }
gmem $GN minidlna add; wf_pwunlock
[ -f $R/etc/init.d/minidlna ] && pgrep -f /usr/sbin/minidlnad >/dev/null 2>&1 && { ( $R/etc/init.d/minidlna restart ) </dev/null >/dev/null 2>&1 & }
true
}
follow() {
F=$(fpnow); [ -n "$F" ] && [ "$F" = "$(cat $TMP/follow.fp 2>/dev/null)" ] && return 0
mainck && basedirs "$MM" >/dev/null
dlnagrp
[ "$(nj 'print(N.adv?.trash !== false ? 1 : 0);')" = 1 ] &&
sed -n 's/^[[:space:]]*recycle:repository = \(.*\)\/\.wf-trash\/%u\(\/%S\)\{0,1\}$/\1/p' $R/etc/samba/smb.conf.template 2>/dev/null | sort -u |
while IFS= read -r m_; do
awk -v m="$m_" '$1 ~ /^\/dev\// && $4 !~ /(^|,)ro(,|$)/ { p = $2; gsub(/\\040/, " ", p); if (p == m && $3 !~ /^(ntfs3?|ntfs-3g|vfat|exfat|fuse.*)$/) f = 1 }
				END { exit !f }' $R/proc/mounts || continue
t_="$m_/.wf-trash"; [ -L "$t_" ] && continue
[ -d "$t_" ] || mkdir "$t_" 2>/dev/null || continue
[ "$(pst "$t_")" = "root:root 1777" ] || chmod 1777 "$t_" 2>/dev/null
done
[ -f $W/nasrec.sh ] && sh $W/nasrec.sh follow </dev/null >/dev/null 2>&1
[ -f $W/nasdl.sh ] && sh $W/nasdl.sh follow </dev/null >/dev/null 2>&1
[ -f $W/cloudmnt.sh ] && ( sh $W/cloudmnt.sh check ) </dev/null >/dev/null 2>&1 &
V=${WF_NASVCUC:-$W/nasvc.uc}; [ -f "$V" ] || return 0
d=$(ucode -e "let M = loadfile('$V')(), x = M.follow(); print(x?.busy ? 'BUSY' : join(' ', x?.did ?? []), '\n');" </dev/null 2>$TMP/follow.err) || {
logger -t wrtfreedom "NAS: servizi che seguono il disco non riusciti: $(head -n 1 $TMP/follow.err 2>/dev/null)" 2>/dev/null; return 0; }
rm -f $TMP/follow.err
[ "$d" = BUSY ] && return 0
F=$(fpnow); [ -n "$F" ] && echo "$F" > $TMP/follow.fp
[ -n "$d" ] && logger -t wrtfreedom "NAS: servizi riscritti sul percorso nuovo del disco ($d)" 2>/dev/null
case " $d " in *" dlna "*) dlnaauto ;; esac; true
}

tick() {
[ -f $W/nasx.sh ] && sh $W/nasx.sh tick
sparewant && ucf spare
[ -s $TMP/sess.json ] && [ -f "$NASUUC" ] && ucode -e "loadfile('$NASUUC')().sess_clean();" </dev/null >/dev/null 2>&1
smborphans
nason || return 0
follow
ucf expire
m=$(pgrep -o -f /usr/sbin/minidlnad); [ -f $TMP/dlna.scan ] && [ -n "$m" ] && [ -n "$(dlnakids "$m")" ] && dlnago
[ -f $TMP/dlna.boot ] || { mkdir -p $TMP; touch $TMP/dlna.boot; dlnaauto; }
[ -f $PEND ] && { l=$(pendleft); [ -n "$l" ] && [ "$l" -le 0 ] && ubus call wrtfreedom nas_adv '{"act":"back"}' >/dev/null 2>&1; }
H=$(date +%H); Mi=$(date +%M); H=${H#0}; Mi=${Mi#0}
Q4=; [ "$H" = 4 ] && [ "$Mi" -lt 5 ] && Q4=1
[ -n "$Q4" ] && trash
if mainck; then
W_=; [ -n "$Q4" ] || [ "$(ucode "$NASUC" awake $TMP/main.io </dev/null 2>/dev/null)" = 1 ] && W_=1
if [ -n "$W_" ]; then
n=$(basedirs "$MM"); [ "${n:-0}" -gt 0 ] && ucf dfs
[ "${n:-0}" -gt 0 ] && once dirs 3600 && ev nas_dirs_fixed "🗄️ NAS ¦ $(t 'Cartelle Di Base Ricreate' 'Base Folders Recreated') ¦ $n"
if [ -n "$Q4" ] || once quota 900; then quota; mainio; [ -n "$QCH" ] && follow; fi
fi
fi
true
}

uninstall() {
I=$R/etc/init.d
for n in wf-nasdav wf-nasdl wf-nasdisc; do [ -f $I/$n ] && { $I/$n stop; $I/$n disable; rm -f $I/$n; }; done >/dev/null 2>&1
rm -f $R/etc/avahi/services/wfnas.service
O=$(nj 'print(join(" ", N.ours ?? []));')
for n in $O; do case $n in ksmbd|samba4|wsdd2|avahi-daemon) [ -f $I/$n ] && { $I/$n stop; $I/$n disable; };; esac; done >/dev/null 2>&1
for c in ksmbd samba4; do for s in $(uci -q show $c | sed -n "s/^$c\.\(wf_[A-Za-z0-9_]*\)=.*/\1/p"); do uci -q delete $c.$s; done; uci -q commit $c; done
RS=$(nj '
		let O = type(N.orig) == "object" ? N.orig : {}, u = (a) => system([ "uci", "-q", ...a ]);
		for (let c in [ "ksmbd", "samba4", "minidlna" ]) {
			let x = O[c];
			if (type(x) != "object" || !match("" + x.sec, /^[]@A-Za-z0-9_[]{1,64}$/)) continue;
			if (x.new === true) u([ "delete", c + "." + x.sec ]);
			else for (let k, v in (type(x.o) == "object" ? x.o : {})) {
				if (!match(k, /^[A-Za-z0-9_]{1,64}$/)) continue;
				let p = c + "." + x.sec + "." + k;
				if (v == null) u([ "delete", p ]);
				else if (type(v) == "array") { u([ "delete", p ]); for (let e in v) u([ "add_list", p + "=" + e ]); }
				else u([ "set", p + "=" + v ]);
			}
			u([ "commit", c ]);
			if (c == "minidlna") print("minidlna:", x.new === true ? "0" : (x.o?.enabled ?? "0"), "\n");
		}
		/* interfacce del server SMB (Cartelle Condivise dentro la VPN, nasvc.uc smbif): il valore di prima, se nessuno le ha cambiate */
		let X = N.smbif;
		if (type(X) == "object" && match("" + X.conf, /^(ksmbd|samba4)$/) && match("" + X.sec, /^([A-Za-z0-9_]{1,64}|@[A-Za-z0-9_]{1,32}\[[0-9]{1,3}\])$/)) {
			let p = X.conf + "." + X.sec + ".interface", h = require("fs").popen("uci -q get " + p), cur = trim((h ? h.read("all") : null) ?? "");
			if (cur == X.v) { if (X.o == null) u([ "delete", p ]); else u([ "set", p + "=" + X.o ]); u([ "commit", X.conf ]); }
		}')
g=$(gidof $GN); d_=$(cat $DLGID 2>/dev/null)
if [ -n "$d_" ] && [ -n "$g" ] && awk -F: -v g="$g" '$1 == "minidlna" && $4 == g { f = 1 } END { exit !f }' $R/etc/passwd 2>/dev/null; then
wf_pwlock && { pwgid minidlna "$d_"; wf_pwunlock; }
case "$RS" in *minidlna:*) ;; *) [ -f $I/minidlna ] && pgrep -f /usr/sbin/minidlnad >/dev/null 2>&1 && $I/minidlna restart >/dev/null 2>&1 ;; esac
fi
case "$RS" in
*minidlna:1*) [ -f $I/minidlna ] && $I/minidlna restart >/dev/null 2>&1 ;;
*minidlna:*) [ -f $I/minidlna ] && { $I/minidlna stop; $I/minidlna disable; } >/dev/null 2>&1 ;;
*) case " $(nj 'print(N.media?.on === true ? "on" : "");') " in *" on "*) k=$(uci -q show minidlna | sed -n "s/^minidlna\.\([^.]*\)=minidlna$/\1/p" | head -n 1)
[ -n "$k" ] && { uci -q set minidlna.$k.enabled=0; uci -q commit minidlna; $I/minidlna stop; $I/minidlna disable; } >/dev/null 2>&1;; esac ;;
esac
for f in $R/etc/ksmbd/ksmbd.conf.template $R/etc/samba/smb.conf.template; do [ -f "$f" ] && sed -i -e '/^# wf-nas$/{N;d;}' -e '/^# wf-nas-orig$/{N;s/^# wf-nas-orig\n#//;}' "$f"; done
s_=$(wf_udir shared root) && mainck && for l in "$MM/${s_%/*}"/*/"${s_##*/}"; do
[ -L "$l" ] && case "$(readlink "$l")" in msdfs:*|"../${s_##*/}") rm -f "$l" ;; esac
done; rm -f $TMP/dfs.json
rm -rf /tmp/wf-smbu
for f in $R/etc/ksmbd/ksmbd.conf $R/etc/samba/smb.conf; do [ -f "$f" ] && [ ! -L "$f" ] && grep -qx '# wf-nas' "$f" && rm -f "$f"; done
for u in $(awk -F: '$5 == "wf-nas" { print $1 }' $R/etc/passwd); do
spw -x "$u" >/dev/null 2>&1
sysdel "$u"
done
g=$(gidof $GN); [ -n "$g" ] && [ "$g" -ge 2000 ] && [ "$g" -lt 3000 ] && fdel $R/etc/group $GN 3 "$g"
command -v ksmbd.adduser >/dev/null 2>&1 && for u in $ADM $(nj 'print(join(" ", keys(N.users ?? {})));'); do ksmbd.adduser -d "$u" </dev/null >/dev/null 2>&1; done
fwdel; command -v fw4 >/dev/null 2>&1 && fw4 -q reload >/dev/null 2>&1
for n in samba4 ksmbd; do case " $O " in *" $n "*) continue ;; esac
[ -f $I/$n ] && $I/$n running >/dev/null 2>&1 && $I/$n reload >/dev/null 2>&1; done
rm -rf $ETC/nas.json $ETC/nas.pend.json $ETC/nas-bak $ETC/nas-rec.sh $ETC/nas-dav.conf $ETC/nas-dav.links $ETC/nas-dav.digest $ETC/nas-blk $ETC/nas-ids $ETC/nas-media.last $DLGID \
		$ETC/nas-aria2.conf $ETC/nas-aria2.secret $ETC/nas-dl-ok.sh $ETC/nas-dl-err.sh $ETC/nas-smb.fp $TMP
rm -rf /tmp/wf-dlnadb
}

c=$1; [ $# -gt 0 ] && shift
case "$c" in
tick) tick ;;
follow) follow ;;
trash) trash ;;
quota) quota ;;
dlnastat) dlnastat ;;
dlnascan) dlnascan ;;
dlnastop) dlnastop ;;
dlnareindex|dlnarescan) dlnareindex ;;
dlnawatch) dlnawatch ;;
tvfind) ucf tvfind; rm -f $TMP/tv.find ;;
tvpoll) tvpoll "$@" ;;
tvdo) ucf tvdo "$1" ;;
davroot) davroot ;;
davlog) davlog ;;
svc) svc "$@" ;;
spare) ucf spare ;;
svcrun) svcrun ;;
fw) fw ;;
userset) userset "$@" ;;
usersets) usersets "$@" ;;
userdel) userdel "$@" ;;
useradm) useradm "$@" ;;
userblock|block) userblock "$@" ;;
userunblock|unblock) userunblock "$@" ;;
dirs) mainck && basedirs "$MM" && ucf dfs ;;
back) back "$@" ;;
uninstall) uninstall ;;
*) echo "uso: nasvc.sh tick|follow|trash|quota|dlnastat|dlnascan|dlnareindex|dlnawatch|tvfind|tvpoll|tvdo|davroot|davlog|svc|svcrun|spare|fw|userset|usersets|userdel|useradm|userblock|userunblock|block|unblock|dirs|back|uninstall"; exit 2 ;;
esac
