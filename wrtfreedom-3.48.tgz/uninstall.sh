#!/bin/sh
say() { echo "## $*"; }
say "Rimuovo i file"
touch /tmp/wf-fan.json.stop
WF_UBP=0; [ -f /etc/wrtfreedom/ubus_prefix.wf ] && WF_UBP=1
WF_UP=$(cat /tmp/wf-bg.upg.pid 2>/dev/null)
case "$WF_UP" in ''|*[!0-9]*) ;; *) tr '\0' ' ' 2>/dev/null < /proc/$WF_UP/cmdline | grep -q /tmp/wf-bg.upg.pid && kill -TERM -"$WF_UP" "$WF_UP" 2>/dev/null ;; esac
rm -f /tmp/wf-bg.upg.pid
for b in /etc/wrtfreedom/bak/*/back.sh; do [ -f "$b" ] && sh "$b" >/dev/null 2>&1; done
if [ "$(uci -q get luci.main.mediaurlbase)" = /luci-static/wrtfreedom ]; then
P=$(uci -q get wrtfreedom.luci.prev); { [ -n "$P" ] && [ "$P" != /luci-static/wrtfreedom ] && [ -e "/www$P" ]; } || P=/luci-static/bootstrap
uci set luci.main.mediaurlbase="$P"
fi
uci -q delete luci.themes.WrtFreedom; uci commit luci
say "Rimuovo il Client VPN"
for i in $(uci -q show network | sed -nE 's/^network\.(wgo(ut|[0-9]+))=interface$/\1/p'); do ifdown "$i" 2>/dev/null; done
for s in $(uci -q show network | sed -nE 's/^network\.(wgo(ut|[0-9]+)(_peer|_rt)?|wgout_(r[0-9]+|main))=.*/\1/p'); do uci -q delete network.$s; done
for s in $(uci -q show firewall | sed -nE 's/^firewall\.(wgout_[A-Za-z0-9_]+)=.*/\1/p'); do uci -q delete firewall.$s; done
rm -f /usr/share/nftables.d/chain-pre/dstnat/40-wrtfreedom-vpndns.nft /usr/share/nftables.d/table-post/42-wrtfreedom-vpnmac.nft
for x in $(uci -q get wrtfreedom.vpnsite.site); do uci -q del_list "dhcp.@dnsmasq[0].nftset=/$x/4#inet#fw4#wf_vpnx"; done
uci -q delete network.wf_vpnsite; rm -f /usr/share/nftables.d/table-post/41-wrtfreedom-vpnsite.nft
uci -q delete firewall.wf_wgalt; uci -q delete firewall.wf_wgalt_in
for x in $(uci -q get wrtfreedom.wg.ddr); do uci -q del_list "dhcp.@dnsmasq[0].address=$x"; done
for s in $(uci -q show wrtfreedom | sed -n "s/^wrtfreedom\.peer_\([A-Za-z0-9_]*\)\.paused='1'$/\1/p"); do uci -q delete "network.$s.disabled"; done
[ -f /usr/share/wrtfreedom/nasdns.sh ] && sh /usr/share/wrtfreedom/nasdns.sh off </dev/null >/dev/null 2>&1
uci -q delete firewall.wf_dnsforce
for s in $(uci -q show dhcp | sed -nE 's/^dhcp\.(wf_hn_[a-z0-9]+)=domain$/\1/p'); do uci -q delete dhcp.$s; done
uci commit dhcp; /etc/init.d/dnsmasq reload >/dev/null 2>&1
rm -f /usr/share/nftables.d/table-pre/90-wrtfreedom.nft /usr/share/nftables.d/chain-post/*/90-wrtfreedom.nft
for s in $(uci -q show wrtfreedom.fwt | sed -nE "s/^wrtfreedom\.fwt\.([A-Za-z0-9_]+)=.*/\1/p"); do
[ "$(uci -q get firewall.$s)" = redirect ] && uci -q set firewall.$s.enabled=0
done
pkill -f 'wrtfreedom/naspeed\.uc' 2>/dev/null
pkill -f 'wrtfreedom/nasjob\.sh|wrtfreedom/nasvc\.sh|wrtfreedom/nasx\.sh|wrtfreedom/nasf\.sh|wrtfreedom/nasf\.uc|wrtfreedom/nasdl\.sh|wrtfreedom/nasrec\.sh|wrtfreedom/nasbk\.sh' 2>/dev/null
rm -rf /etc/wrtfreedom/.nas-copia /etc/wrtfreedom/nas-space
for x in /etc/wrtfreedom/nas*; do [ -e "$x" ] && mkdir -p /etc/wrtfreedom/.nas-copia && cp -a "$x" /etc/wrtfreedom/.nas-copia/; done
rm -rf /etc/wrtfreedom/.cloud-copia
for x in /etc/wrtfreedom/cloud*; do
[ -e "$x" ] || continue
[ "$x" = /etc/wrtfreedom/cloud-photo ] && continue
[ -d /etc/wrtfreedom/.cloud-copia ] || mkdir -m 700 /etc/wrtfreedom/.cloud-copia
cp -a "$x" /etc/wrtfreedom/.cloud-copia/
done
[ -d /etc/wrtfreedom/.cloud-copia ] && find /etc/wrtfreedom/.cloud-copia -type f -exec chmod 600 {} + 2>/dev/null
[ -f /usr/share/wrtfreedom/nasbk.sh ] && sh /usr/share/wrtfreedom/nasbk.sh uninstall >/dev/null 2>&1
[ -f /usr/share/wrtfreedom/nasrec.sh ] && sh /usr/share/wrtfreedom/nasrec.sh uninstall >/dev/null 2>&1
if [ -f /usr/share/wrtfreedom/cloudmnt.sh ]; then
WF_CN=$(sh /usr/share/wrtfreedom/cloudmnt.sh flush 120 </dev/null 2>/dev/null | sed -n 's/^pending=//p')
[ "${WF_CN:-0}" -gt 0 ] 2>/dev/null && say "Cartella Cloud: $WF_CN file non sono ancora nel cloud"
fi
[ -f /usr/share/wrtfreedom/cloudmnt.sh ] && sh /usr/share/wrtfreedom/cloudmnt.sh uninstall >/dev/null 2>&1
[ -f /usr/share/wrtfreedom/cloud.sh ] && sh /usr/share/wrtfreedom/cloud.sh uninstall >/dev/null 2>&1
rm -rf /tmp/wf-cloud/fl
pkill -f 'wrtfreedom/cloud\.sh|wrtfreedom/cloudx\.sh|wrtfreedom/cloudcr\.sh|wrtfreedom/cloudmnt\.sh' 2>/dev/null
DLD_=$(sed -n 's/^dir=//p' /etc/wrtfreedom/nas-aria2.conf 2>/dev/null | head -n 1)
case "$DLD_" in /?*) [ -d "$DLD_/.wf-dl" ] && rm -rf "$DLD_/.wf-dl"; rm -f "$DLD_"/.wf-aria2.session* 2>/dev/null ;; esac
awk '$1 ~ /^\/dev\// { gsub(/\\040/, " ", $2); print $2 }' /proc/mounts 2>/dev/null | while IFS= read -r m_; do
case "$m_" in /|/rom|/rom/*|/overlay|/overlay/*|/boot|/boot/*|'') continue ;; esac
[ -d "$m_/.wf-index" ] && rm -rf "$m_/.wf-index"
rm -rf "$m_/.wf-minidlna" "$m_/.wf-dav-tmp" "$m_/.wf-thumb" "$m_"/.wf-r-bak-r* 2>/dev/null; rm -f "$m_/.wf-sveglio" "$m_/.wf-disco"
find "$m_" -xdev -maxdepth 6 \( -type d \( -name .wf-trash -o -name .wf-vers -o -name .wf-index \) -prune \) -o \( -type d -name .wf-dl -prune -exec rm -rf {} \; \) -o \( -type f \( -name '.wf-aria2.session*' -o -name '.wf-photo.json' -o -name '.wf-photo.json.t' \) -exec rm -f {} \; \) 2>/dev/null
done
rm -f /www/cgi-bin/wf-nasx
grep -qs 'wf-nas-alias' /www/nas/index.html && { rm -f /www/nas/index.html; rmdir /www/nas 2>/dev/null; }
grep -qs 'wf-pc-alias' /www/pc/index.html && { rm -f /www/pc/index.html; rmdir /www/pc 2>/dev/null; }
[ -f /usr/share/wrtfreedom/nasx.sh ] && sh /usr/share/wrtfreedom/nasx.sh uninstall >/dev/null 2>&1
[ -f /usr/share/wrtfreedom/nasvc.sh ] && sh /usr/share/wrtfreedom/nasvc.sh uninstall >/dev/null 2>&1
pidof smbd >/dev/null 2>&1 && [ -x /etc/init.d/samba4 ] && /etc/init.d/samba4 reload >/dev/null 2>&1
pidof ksmbd.mountd >/dev/null 2>&1 && [ -x /etc/init.d/ksmbd ] && /etc/init.d/ksmbd reload >/dev/null 2>&1
rm -f /tmp/wf-blkw.*
for s in $(uci -q show firewall | sed -nE "s/^firewall\.([^.=]+)\.name='wf-nas-.*/\1/p"); do uci -q delete "firewall.$s"; done
rm -f /usr/share/nftables.d/*/*wf-nas*.nft /usr/share/nftables.d/*/*/*wf-nas*.nft /etc/nftables.d/*wf-nas*.nft
for s in $(uci -q show hd-idle | sed -nE "s/^hd-idle\.(wfnas_[A-Za-z0-9_]*)=hd-idle$/\1/p"); do uci -q delete hd-idle.$s; done; uci -q commit hd-idle; rm -rf /tmp/wf-nas
WF_NFS=$(uci -q show fstab | sed -nE "s/^fstab\.(wf_nas[A-Za-z0-9_]*)=mount$/\1/p")
if [ -n "$WF_NFS" ]; then for s in $WF_NFS; do uci -q delete "fstab.$s"; done; uci commit fstab; fi
rm -f /usr/share/nftables.d/table-pre/91-wrtfreedom-dev.nft /etc/nftables.d/90-wrtfreedom.nft
uci commit network; uci commit firewall; /etc/init.d/network reload; /etc/init.d/firewall reload
rm -rf /usr/share/ucode/luci/template/themes/wrtfreedom /www/luci-static/wrtfreedom
[ -x /etc/init.d/wrtfreedom ] && { /etc/init.d/wrtfreedom stop; /etc/init.d/wrtfreedom disable; }
if [ -f /usr/share/wrtfreedom/adgmode.sh ]; then
if [ -d /etc/wrtfreedom/adgmode ] || [ -d /etc/wrtfreedom/adgmode.new ] || grep -q "^MODE='direct'" /etc/wrtfreedom/dnsfb.state 2>/dev/null; then
say "Rimetto il DNS com'era prima"
if [ -d /etc/wrtfreedom/adgmode.new ]; then
if pgrep -f 'adgmode\.sh (direct|back)' >/dev/null 2>&1; then	# cambio in corso: annullato, attesa del ritorno
touch /tmp/wf-adgmode.no; i=0; while [ -d /etc/wrtfreedom/adgmode.new ] && [ $i -lt 30 ]; do sleep 1; i=$((i+1)); done
[ -d /etc/wrtfreedom/adgmode.new ] && { pkill -f 'adgmode\.sh (direct|back)'; sleep 1; }
fi
[ -d /etc/wrtfreedom/adgmode.new ] && sh /usr/share/wrtfreedom/adgmode.sh recover
fi
[ -d /etc/wrtfreedom/adgmode ] || grep -q "^MODE='direct'" /etc/wrtfreedom/dnsfb.state 2>/dev/null && sh /usr/share/wrtfreedom/adgmode.sh back
elif [ -f /etc/wrtfreedom/dnsfb.state ]; then
sh /usr/share/wrtfreedom/adgmode.sh check
fi
fi
[ -f /etc/wrtfreedom/slow ] && [ -f /usr/share/wrtfreedom/slow.sh ] && sh /usr/share/wrtfreedom/slow.sh off cfg >/dev/null 2>&1
[ -n "$(uci -q get wrtfreedom.sqm.fprev)" ] && ubus -t 20 call wrtfreedom sqm '{"action":"follow","go":"main"}' >/dev/null 2>&1
[ "$(uci -q get wrtfreedom.sqm.eq)" = 1 ] && ubus -t 20 call wrtfreedom sqm '{"action":"eq","on":false}' >/dev/null 2>&1
[ -x /etc/init.d/cake-autorate ] && ubus -t 20 call wrtfreedom sqm '{"action":"srv","def":true}' >/dev/null 2>&1
[ "$(uci -q get wrtfreedom.cbs.enabled)" = 1 ] && [ -f /usr/share/wrtfreedom/cbs.uc ] && ucode /usr/share/wrtfreedom/cbs.uc setup off >/dev/null 2>&1
{ [ -f /tmp/wf-leds.save ] || [ -f /tmp/wf-leds.5gbars ]; } && [ -f /usr/share/wrtfreedom/cron.sh ] && sh /usr/share/wrtfreedom/cron.sh ledon >/dev/null 2>&1
[ -f /tmp/wf-leds.5gbars ] && [ -f /usr/share/wrtfreedom/cron.sh ] && sh /usr/share/wrtfreedom/cron.sh ledbars free >/dev/null 2>&1
WF_LEDS=$(uci -q show system | sed -nE 's/^system\.(wf_led_[A-Za-z0-9_]+)=led$/\1/p')
if [ -n "$WF_LEDS" ]; then
for s in $WF_LEDS; do
p=$(uci -q get system.$s.wf_prev); d=$(uci -q get system.$s.sysfs)
uci -q delete system.$s
[ -n "$p" ] && [ -n "$d" ] && [ -w "/sys/class/leds/$d/trigger" ] && echo "$p" > "/sys/class/leds/$d/trigger" 2>/dev/null
done
uci commit system; /etc/init.d/led restart >/dev/null 2>&1
fi
WF_SUSP=$(uci -q get wrtfreedom.ledn.susp)
if [ -n "$WF_SUSP" ] && [ -f /etc/crontabs/root ]; then
cat > /tmp/wf-lednback.uc <<'EOF'
'use strict';
import { readfile, writefile, rename } from 'fs';
const F = '/etc/crontabs/root';
let sus = split(trim(getenv('WF_SUSP') ?? ''), ' '), out = [], ch = 0;
function crhash(s) { let h = 5381; for (let i = 0; i < length(s); i++) h = ((h * 33) ^ ord(s, i)) & 0x7fffffff; return sprintf('%08x', h); }
function crunwrap(c) {
	let m = match(c, /^\{ (.*) \} ; ucode \/usr\/share\/wrtfreedom\/svc\.uc log [0-9a-f]{8} \$\?$/s);
	if (!m) return c;
	let x = m[1];
	return substr(x, length(x) - 1) == ';' ? rtrim(substr(x, 0, length(x) - 1)) : x;
}
for (let l in split(readfile(F) ?? '', '\n')) {
	let s = substr(l, 0, 6) == '#off# ' ? substr(l, 6) : null, mm = s != null ? match(s, / #wrtfreedom /) : null;
	if (mm && !match(rtrim(s), / # wf:[a-z0-9_]{1,40}$/)) {
		let mi = index(s, mm[0]), meta = null;
		try { meta = json(replace(substr(s, mi + length(mm[0])), /\\%/g, '%')); } catch (e) {}
		let f = type(meta) == 'object' ? match(substr(s, 0, mi), /^[ \t]*([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+(.*)$/s) : null;
		if (f) {
			let cmd = crunwrap(f[6]), a = '' + (meta.a ?? '');
			let id = match('' + (meta.i ?? ''), /^[0-9a-f]{8}$/) ? meta.i : crhash(a + '|' + (meta.x ?? '') + '|' + (meta.n ?? '') + '|' + (meta.w ?? '') + (a == 'custom' || a == '' ? '|' + cmd : ''));
			if (index(sus, id) >= 0 && match(cmd, /cron\.sh led(off|on)( |$)/)) { l = s; ch++; }
		}
	}
	push(out, l);
}
if (ch) { writefile(F + '.wf', join('\n', out)); rename(F + '.wf', F); }
print(ch, '\n');
EOF
[ "$(WF_SUSP="$WF_SUSP" ucode /tmp/wf-lednback.uc 2>/dev/null)" -gt 0 ] 2>/dev/null && /etc/init.d/cron restart >/dev/null 2>&1
rm -f /tmp/wf-lednback.uc
fi
if [ -n "$(uci -q get wrtfreedom.wgwd.susp)" ] && [ -f /usr/share/rpcd/ucode/wrtfreedom.uc ]; then
ucode -e 'loadfile("/usr/share/rpcd/ucode/wrtfreedom.uc")().wrtfreedom.vpnwd.call({ args: { action: "restore" } });' >/dev/null 2>&1
/etc/init.d/cron restart >/dev/null 2>&1
[ -n "$(uci -q get wrtfreedom.wgwd.susp)" ] && { WF_SUSPK=1; say "ERRORE righe dell'utente spente dal Controllo Del Server VPN non rimesse: impostazioni tenute (reinstalla e disinstalla di nuovo)"; }
fi
if [ -n "$(uci -q get wrtfreedom.ddnswd.susp)" ] && [ -f /usr/share/rpcd/ucode/wrtfreedom.uc ]; then
ucode -e 'loadfile("/usr/share/rpcd/ucode/wrtfreedom.uc")().wrtfreedom.ddnswd.call({ args: { action: "restore" } });' >/dev/null 2>&1
/etc/init.d/cron restart >/dev/null 2>&1
[ -n "$(uci -q get wrtfreedom.ddnswd.susp)" ] && { WF_SUSPK=1; say "ERRORE righe o ganci dell'utente spenti dal Controllo Del Nome Di Casa non rimessi: impostazioni tenute (reinstalla e disinstalla di nuovo)"; }
rmdir /etc/hotplug.d/.disabled/iface /etc/hotplug.d/.disabled 2>/dev/null
fi
pkill -f 'wrtfreedom/tick\.uc' 2>/dev/null
pkill -f 'custode\.uc' 2>/dev/null
[ -f /usr/share/wrtfreedom/mem.uc ] && ucode /usr/share/wrtfreedom/mem.uc down </dev/null >/dev/null 2>&1
[ -f /usr/share/wrtfreedom/custode.uc ] && { [ -n "$(uci -q get wrtfreedom.custode.c5gwd)" ] || [ -f /etc/wrtfreedom/custode/c5gfw.json ]; } && ucode /usr/share/wrtfreedom/custode.uc c5gback >/dev/null 2>&1
rm -f /tmp/wf-sigfast.want
C=/etc/crontabs/root
if [ -f $C ] && grep -qE '# wf:[a-z0-9_]+$|/usr/share/wrtfreedom/cron\.sh (txlow|txnorm)( |$)|/usr/share/wrtfreedom/svc\.uc log |/usr/share/wrtfreedom/cron\.sh .* #wrtfreedom( |$)' $C; then
sed -E -e '/# wf:[a-z0-9_]+$/d; \#/usr/share/wrtfreedom/cron\.sh (txlow|txnorm)( |$)#d; \@/usr/share/wrtfreedom/cron\.sh .* #wrtfreedom( |$)@d' \
		-e 's#\{ (.*); \} ; ucode /usr/share/wrtfreedom/svc\.uc log [0-9a-f]{8} \$\?( \#wrtfreedom )#\1\2#' \
		-e 's#\{ (.*) \} ; ucode /usr/share/wrtfreedom/svc\.uc log [0-9a-f]{8} \$\?( \#wrtfreedom )#\1\2#' $C > $C.wf && mv $C.wf $C
/etc/init.d/cron restart >/dev/null 2>&1
fi
if [ -d /tmp/wf-svc.abtest.lock ] || ls /tmp/wf-abtest.held.* >/dev/null 2>&1; then
pkill -f 'svc\.uc abtest' 2>/dev/null
for f in /tmp/wf-abtest.held.*; do case "$f" in *.r) ;; *) [ -f "$f" ] && mv "$f" "$f.r" && sh "$f.r" >/dev/null 2>&1 ;; esac; done
fi
WF_WR=; [ -f /usr/share/wrtfreedom/lib.sh ] && WF_WR=$(sh /usr/share/wrtfreedom/lib.sh inact off 2>/dev/null)
s=$(uci -q get wrtfreedom.wifi.wpsadd)
[ -n "$s" ] && { uci -q delete "wireless.$s.wps_pushbutton"; uci commit wireless; WF_WR=1; }
[ "$WF_WR" = 1 ] && wifi reload >/dev/null 2>&1
if [ -f /usr/share/wrtfreedom/wifi.uc ]; then
ucode /usr/share/wrtfreedom/wifi.uc glimit off >/dev/null 2>&1	# Limite Di Velocità della rete ospiti: code CAKE e ifb tolte
sh /usr/share/wrtfreedom/cron.sh txnorm >/dev/null 2>&1
fi
WF_NP=$(uci -q get wrtfreedom.nlbw.prev); WF_ND=$(uci -q get nlbwmon.@nlbwmon[0].database_directory)
if [ -n "$WF_NP" ] && [ "$WF_NP" != /etc/nlbwmon ] && [ "$WF_ND" = /etc/nlbwmon ]; then
[ -x /etc/init.d/nlbwmon ] && /etc/init.d/nlbwmon stop
mkdir -p "$WF_NP"
for f in /etc/nlbwmon/*; do [ -f "$f" ] || continue; d="$WF_NP/${f##*/}"; [ -f "$d" ] && [ "$(wc -c < "$d")" -ge "$(wc -c < "$f")" ] && continue; cp -p "$f" "$d"; done
uci set nlbwmon.@nlbwmon[0].database_directory="$WF_NP"; uci commit nlbwmon
[ -x /etc/init.d/nlbwmon ] && /etc/init.d/nlbwmon start
fi
if [ -f /etc/sysctl.d/90-wrtfreedom-bbr.conf ]; then
rm -f /etc/sysctl.d/90-wrtfreedom-bbr.conf
[ "$(cat /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null)" = bbr ] && sysctl -w net.ipv4.tcp_congestion_control=cubic >/dev/null 2>&1
fi
rm -f /etc/uci-defaults/99-wrtfreedom /lib/upgrade/keep.d/wrtfreedom /etc/wrtfreedom/pacchetto.tgz /etc/wrtfreedom/pacchetto.tgz.t /etc/wrtfreedom/pacchetto.ver /etc/wrtfreedom/pacchetto.sum /etc/wrtfreedom/fw-prima
rm -f /etc/wrtfreedom-copie/pacchetto-prima-pacchetto.tgz
pkill -f 'wf-ritorno\.sh' 2>/dev/null
WF_RF=$(readlink -f /etc/resolv.conf 2>/dev/null); [ -n "$WF_RF" ] || WF_RF=/etc/resolv.conf
[ -s /tmp/wf-resolv.orig ] && [ "$(head -n 1 "$WF_RF" 2>/dev/null)" = "# wf-ritorno" ] && cp /tmp/wf-resolv.orig "$WF_RF" 2>/dev/null
WF_CD=/etc/wrtfreedom-copie/$(date +%Y%m%d-%H%M%S)
wfsz() { s_=0; for x in /etc/config/wrtfreedom /etc/wrtfreedom/* /etc/wrtfreedom/.[!.]*; do
[ -e "$x" ] && [ "$x" != /etc/wrtfreedom/bak ] || continue; k_=$(du -sk "$x" 2>/dev/null | awk '{print $1}'); s_=$((s_ + ${k_:-0})); done; echo $s_; }
WF_NEED=$(( $(wfsz) + 64 )); WF_FREE=$(df -k /etc/ 2>/dev/null | awk 'NR > 1 && NF >= 4 {a = $(NF - 2)} END {print a}')
WF_SPACE=1
case "$WF_FREE" in ''|*[!0-9]*) ;; *) [ "$WF_FREE" -ge "$WF_NEED" ] || { WF_SPACE=0; say "Spazio libero non sufficiente per la copia delle impostazioni (servono $WF_NEED KB, liberi $WF_FREE KB)"; };; esac
wfcd() { [ $WF_SPACE = 1 ] && mkdir -p "$WF_CD" && chmod 700 "$WF_CD"; }
WF_CFOK=1; [ "$WF_SUSPK" = 1 ] && WF_CFOK=0
if [ $WF_CFOK = 1 ] && [ -f /etc/config/wrtfreedom ]; then
wfcd && cp -p /etc/config/wrtfreedom "$WF_CD/config-wrtfreedom" || { rm -f "$WF_CD/config-wrtfreedom"; WF_CFOK=0; }
fi
rm -f /etc/init.d/wrtfreedom /etc/hotplug.d/*/90-wrtfreedom /etc/hotplug.d/acme/91-wrtfreedom
if [ $WF_CFOK = 1 ]; then rm -f /etc/config/wrtfreedom; elif [ "$WF_SUSPK" != 1 ]; then say "Copia di /etc/config/wrtfreedom non riuscita: il file resta"; fi
rm -f /lib/upgrade/keep.d/wrtfreedom-copia
rm -f /usr/share/rpcd/ucode/wrtfreedom.uc /usr/libexec/rpcd/wrtfreedom.wait /www/cgi-bin/wf-live /www/cgi-bin/wf-me /www/cgi-bin/wf-ai /usr/share/rpcd/acl.d/wrtfreedom.json
pkill -f 'health\.uc' 2>/dev/null
if [ -f /tmp/wf-fan.json.back ]; then
while read -r v p; do
case "$p" in
/sys/class/thermal/thermal_zone*/policy) case "$v" in ''|*[!a-z_]*) continue ;; esac ;;
/sys/class/thermal/cooling_device*/cur_state|/sys/class/hwmon/hwmon*/pwm1|/sys/class/hwmon/hwmon*/pwm1_enable) case "$v" in ''|*[!0-9]*) continue ;; esac ;;
*) continue ;;
esac
[ -f "$p" ] && echo "$v" > "$p" 2>/dev/null
done < /tmp/wf-fan.json.back
fi
rm -f /tmp/wf-fan.json /tmp/wf-fan.json.back /tmp/wf-fan.json.beat
if [ -f /tmp/wf-devev.pid ]; then
for p in $(cat /tmp/wf-devev.pid); do
case "$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)" in "iw event "|"ip -4 monitor neigh ") kill "$p" 2>/dev/null ;; esac
done
fi
pkill -f 'assist\.uc|speed\.uc' 2>/dev/null
[ -x /etc/init.d/wrtfreedom-ai ] && { /etc/init.d/wrtfreedom-ai stop; /etc/init.d/wrtfreedom-ai disable; }
rm -f /etc/init.d/wrtfreedom-ai
for p in $(pgrep -f 'wrtfreedom/ai\.uc' 2>/dev/null); do kill -TERM -$p $p 2>/dev/null; done
rm -f /etc/wrtfreedom/ai-*.key /etc/wrtfreedom/ai-mem.json; rm -rf /tmp/wf-ai /tmp/wf-tg.k /tmp/wf-evown /tmp/wf-evown.cnt
rm -f /etc/wrtfreedom/backup.pw
rm -rf /tmp/wf-backup
rm -rf /tmp/wf-tgf; rm -f /tmp/wf-casa-nas.json
rm -rf /tmp/wf-tg-u
for f in /etc/wrtfreedom/fwcustom.prev.nft /etc/wrtfreedom/fwcustom.old*.nft
do
[ -f "$f" ] || continue
mkdir -p /etc/wrtfreedom-copie && b=${f##*/} && mv "$f" "/etc/wrtfreedom-copie/${b%.nft}-$(date +%Y%m%d-%H%M).nft"
done
WF_EOK=1; [ "$WF_SUSPK" = 1 ] && WF_EOK=0
if [ $WF_EOK = 1 ] && [ -d /etc/wrtfreedom ]; then
if wfcd && mkdir -p "$WF_CD/wrtfreedom"; then
for x in /etc/wrtfreedom/* /etc/wrtfreedom/.[!.]*; do
[ -e "$x" ] && [ "$x" != /etc/wrtfreedom/bak ] || continue
cp -a "$x" "$WF_CD/wrtfreedom/" || { WF_EOK=0; break; }
done
else WF_EOK=0; fi
[ $WF_EOK = 1 ] || rm -rf "$WF_CD/wrtfreedom"
fi
if [ $WF_EOK = 1 ]; then rm -rf /etc/wrtfreedom; elif [ "$WF_SUSPK" != 1 ]; then say "Copia di /etc/wrtfreedom non riuscita: la cartella resta"; fi
rmdir "$WF_CD" 2>/dev/null
[ -d "$WF_CD" ] && say "Copia delle impostazioni in $WF_CD (cartella leggibile solo da root)"
rm -rf /www/wrtfreedom /tmp/.wf-* /tmp/wf-*
touch /tmp/wf-fan.json.stop
set --
for f in /www/wrtfreedom/ /usr/share/ucode/luci/template/themes/wrtfreedom/ /www/luci-static/wrtfreedom /usr/share/rpcd/ucode/wrtfreedom.uc /usr/libexec/rpcd/wrtfreedom.wait /www/cgi-bin/wf-live /www/cgi-bin/wf-me /www/cgi-bin/wf-ai /usr/share/rpcd/acl.d/wrtfreedom.json /usr/share/wrtfreedom/ /etc/wrtfreedom/ /etc/config/wrtfreedom /etc/init.d/wrtfreedom /etc/init.d/wrtfreedom-ai /etc/init.d/wf-nasdav /etc/init.d/wf-nasdl /etc/init.d/wf-nasx /etc/init.d/wf-nasftp /etc/init.d/wf-nasdisc /etc/init.d/wf-phwatch /etc/avahi/services/wfnas.service /www/cgi-bin/wf-nasx /etc/hotplug.d/iface/90-wrtfreedom /etc/hotplug.d/dhcp/90-wrtfreedom /etc/hotplug.d/usb/90-wrtfreedom /etc/hotplug.d/block/90-wrtfreedom /etc/hotplug.d/button/90-wrtfreedom /etc/hotplug.d/ntp/90-wrtfreedom /etc/hotplug.d/acme/90-wrtfreedom /etc/hotplug.d/acme/91-wrtfreedom /etc/uci-defaults/99-wrtfreedom; do
set -- "$@" -e "\#^$f\$#d"
done
[ -f /etc/sysupgrade.conf ] && sed -i "$@" /etc/sysupgrade.conf
rpcd_restart() { /etc/init.d/rpcd stop; i=0; while pidof rpcd >/dev/null && [ $i -lt 5 ]; do sleep 1; i=$((i+1)); done
for p in $(pidof rpcd); do kill -9 $p 2>/dev/null; done; /etc/init.d/rpcd start; }
say "Riavvio rpcd"
rm -rf /usr/share/wrtfreedom
rpcd_restart
rm -f /tmp/wf-fan.json.stop
[ $WF_UBP = 1 ] && { uci -q delete uhttpd.main.ubus_prefix; uci commit uhttpd; /etc/init.d/uhttpd restart; }
if [ "$WF_SUSPK" = 1 ]; then say "ERRORE rimosso solo in parte: righe o ganci dell'utente spenti dal pacchetto non rimessi, impostazioni tenute (reinstalla e disinstalla di nuovo)"
else say "OK rimosso"; fi
