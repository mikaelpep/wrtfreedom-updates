#!/usr/bin/ucode
'use strict';
import { readfile, stat, stdout, popen } from 'fs';

function out(s) { stdout.write(s); stdout.flush(); }
function param(k) { let m = match(getenv('QUERY_STRING') ?? '', regexp('(^|&)' + k + '=([^&]*)')); return m ? m[2] : ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function sess() { let m = match(getenv('HTTP_AUTHORIZATION') ?? '', /^Bearer ([0-9a-f]{32})$/); return m ? m[1] : param('sid'); }
let UBX = null;
function ub(o, m, a) {
if (UBX == null) { try { UBX = require('ubus').connect(null, 10) ?? false; } catch (e) { UBX = false; } }
if (UBX) { let x = null; try { x = UBX.call(o, m, a); } catch (e) { x = null; } if (x != null) return x; }
let p = popen('ubus -t 10 call ' + o + ' ' + m + ' ' + q(sprintf('%J', a)) + ' 2>/dev/null', 'r'), r = null;
if (p) { try { r = json(p.read('all')); } catch (e) {} p.close(); }
return r;
}
function en() {
let s = false;
for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?ui'?[[:blank:]]*$/) != null; continue; }
if (s && match(l, /^[[:blank:]]*option lang '?en'?[[:blank:]]*$/)) return true;
}
return false;
}
function err(st, it, e) {
out('Status: ' + st + '\r\nContent-Type: text/plain\r\n\r\n' + (en() ? e : it) + '\n');
exit(0);
}

let sid = sess(), id = param('id'), start = +param('from') || 0;
if (!match(sid, /^[0-9a-f]{32}$/) || (length(id) && !match(id, /^[0-9a-f]{8}$/)) || start < 0)
err('400 Bad Request', 'parametri non validi', 'invalid parameters');
let a = ub('session', 'access', { ubus_rpc_session: sid, scope: 'ubus', object: 'wrtfreedom', 'function': 'aiget' });
if (!a || !a.access)
err('403 Forbidden', 'accesso negato', 'access denied');
let U = null, W = null;
try { U = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')(); } catch (e) { U = null; }
try { W = type(U?.who) == 'function' ? U.who({ args: { ubus_rpc_session: sid } }) : null; } catch (e) { W = null; }
if (!W || (!W.adm && !match(W.own ?? '', /^[A-Za-z0-9._-]{1,64}$/)))
err('403 Forbidden', 'accesso negato', 'access denied');
let own = W.adm ? null : W.own, ans = '/tmp/wf-ai' + (own ? '/u/' + own : '') + '/ans.json';
out('Status: 200 OK\r\nContent-Type: application/x-ndjson\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nX-Accel-Buffering: no\r\n\r\n');
let c0 = clock(), last = '', pos = start, fk = null, tc = 0, r = null;
while (true) {
let c = clock(), ms = (c[0] - c0[0]) * 1000 + int((c[1] - c0[1]) / 1000000), st = stat(ans);
let k0 = st ? st.inode + ':' + st.size + ':' + st.mtime : '';
if (r == null || (k0 != fk && ms - tc >= 250) || ms - tc >= 1000 || ms > 55000) {
fk = k0; tc = ms;
let g = length(id) ? { id: id, from: pos } : { from: pos };
if (own) g.as = own;
let x = ub('wrtfreedom', 'aiget', g);
if (x && own && x.own !== own) x = null;
if (x && !x.error) r = x;
else if (r == null) r = { id: length(id) ? id : null, none: true, lost: length(id) > 0, done: true, errk: length(id) ? 'lost' : null };
}
let k = sprintf('%J', [ r.len, r.done, r.errk, r.ask?.id, length(r.src ?? []), r.st?.k, r.st?.t ]);
if (k != last || ms > 55000) {
last = k;
out(sprintf('%J\n', r));
if (r.len != null) pos = r.len;
}
if (r.done || ms > 55000)
break;
sleep(100);
}
