'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, readlink, symlink } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', NJ = ETC + '/nas.json', PEND = ETC + '/nas.pend.json', TMP = '/tmp/wf-nas';
const SH = getenv('WF_NASSH') ?? '/usr/share/wrtfreedom/nasvc.sh';
const CLOUDUC = getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc', CLJOBS = '/tmp/wf-cloud/jobs';
const DIGEST = ETC + '/nas-dav.digest', REALM = 'WrtFreedom NAS';
const DAVPORT = 5005, MARK = '# wf-nas', MARKO = '# wf-nas-orig';
const MAINPJ = TMP + '/mainpause.json';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(R + p) != null; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
function wjs(f, o) { let t = f + '.' + PID + '.t', s = sprintf('%J', o); if (writefile(t, s) == length(s)) rename(t, f); else unlink(t); }
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
function mkd(p) {
if (!mkdir(p)) return false;
let f = null;
try { f = require('fs').chmod; } catch (e) { f = null; }
if (type(f) == 'function') f(p, 493);
else sh('chmod 755 ' + q(p) + ' 2>/dev/null');
return true;
}
function arr(v) { return type(v) == 'array' ? v : (v == null || v == '' ? [] : split('' + v, /[ \t]+/)); }
function uniq(a) { let s = {}, r = []; for (let x in a) { x = '' + x; if (length(x) && !s[x]) { s[x] = 1; push(r, x); } } return r; }
function macok(x) { return match('' + x, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) != null; }
function leases() {
let L = {};
for (let l in split(readfile('/tmp/dhcp.leases') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) >= 4) L[lc(p[1])] = { ip: p[2], name: p[3] != '*' ? p[3] : '' };
}
return L;
}
function rid() { return substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10) || ('' + time()); }

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function admu(N) { return UCFG.smbadm(N); }
function cfg(name) { return UCFG.read((getenv('WF_CFGDIR') ?? '/etc/config/') + name, false); }
function first(C, t) { for (let k in C) if (C[k]['.type'] == t) return k; return null; }
function uset(c, s, o, v) { return 'uci -q set ' + q(c + '.' + s + '.' + o + '=' + v) + '; '; }
function ulist(c, s, o, L) { let r = 'uci -q delete ' + q(c + '.' + s + '.' + o) + '; '; for (let v in L) r += 'uci -q add_list ' + q(c + '.' + s + '.' + o + '=' + v) + '; '; return r; }
function dhcphosts() {
let C = cfg('dhcp'), r = {};
for (let k in C) if (C[k]['.type'] == 'host')
for (let m in arr(C[k].mac)) { m = lc(m); if (macok(m)) r[m] = { ip: '' + (C[k].ip ?? ''), name: '' + (C[k].x3000_label || C[k].name || '') }; }
return r;
}
function ipok(x) { return match('' + x, /^([0-9]{1,3}\.){3}[0-9]{1,3}$/) != null; }
function devname(mac, H, LS) { return H[mac]?.name || LS[mac]?.name || ''; }
function macip(mac, H, LS) { let f = H[mac]?.ip; return ipok(f) ? f : (ipok(LS[mac]?.ip) ? LS[mac].ip : ''); }

let LG = 'it';
function L(it, en) { return LG == 'en' ? en : it; }
function err(code, it, en) { return { error: it, error_en: en, code: code }; }
let NREG = [];
function begin() { LG = cfg('wrtfreedom')?.ui?.lang == 'en' ? 'en' : 'it'; mkdir(TMP); mkdir(ETC); NREG = []; }

const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function nget() {
if (length(NREG) >= 32) NREG = slice(NREG, -16);
let N = UCFG.njget(NJ, NREG);
for (let k in [ 'remote', 'media', 'dl', 'rec', 'adv', 'users', 'trash' ]) if (type(N[k]) != 'object') N[k] = {};
for (let k in [ 'shares', 'backups' ]) if (type(N[k]) != 'array') N[k] = [];
return N;
}
function nput(N) { return UCFG.njput(N, NREG, NJ, (s, F) => wjs(NJ, F)); }
function busy() { return err('busy', 'Impostazioni occupate: riprova', 'Settings busy: try again'); }

const SYSMNT = /^\/(|overlay|rom|boot|tmp|proc|sys|dev)$/, SYS = getenv('WF_SYS') ?? '/sys';
function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
function blkinfo(ML) { return UCFG.blkinfo(ML, { sys: SYS, run: TMP, sh, rj: rjs, wjr: wjs, mkdirp: mkdir }); }
function baseof(d) {
let m = match(d, /^(nvme[0-9]+n[0-9]+|mmcblk[0-9]+)p[0-9]+$/);
if (m) return m[1];
m = match(d, /^((s|h|v|xv)d[a-z]+)[0-9]+$/);
return m ? m[1] : d;
}
function virt(d) { return !!match(d, /^(mtdblock|mtd|ubi|loop|zram|ram|dm-|sr|fd|nbd)/); }
function disks() {
let M = {}, ML = [], D = [], NS = rjs(NJ)?.disks, sysd = {};
if (type(NS) != 'object') NS = {};
for (let l in split(readfile(R + '/proc/mounts') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) < 4) continue;
push(ML, { dev: p[0], mnt: unoct(p[1]) });
if (substr(p[0], 0, 5) == '/dev/' && index([ '/', '/rom', '/overlay', '/boot', '/boot/efi' ], unoct(p[1])) >= 0) sysd[baseof(substr(p[0], 5))] = 1;
if (substr(p[0], 0, 5) == '/dev/' && !M[p[0]])
M[p[0]] = { mnt: unoct(p[1]), fs: p[2], ro: match(p[3], /^ro(,|$)/) != null, opts: p[3] };
}
let B = blkinfo(ML);
for (let dv in sort(keys(B))) {
let a = B[dv], k = '/dev/' + dv;
if (type(a) != 'object' || !M[k] || match(M[k].mnt, SYSMNT)) continue;
if (match(a.TYPE ?? '', /^(squashfs|ubifs|jffs2|swap)$/)) continue;
let dev = replace(dv, /^.*\//, ''), bd = baseof(dev);
if (virt(dev) || sysd[bd] || match(dev, /^mmcblk[0-9]+(boot|rpmb)/) || (substr(bd, 0, 6) == 'mmcblk' && trim(readfile(SYS + '/class/block/' + bd + '/device/type') ?? '') == 'MMC')) continue;
let id = lc(a.UUID ?? '') || dev, fs = M[k].fs;
let st = NS[id]?.ro, lock = type(st) == 'bool' ? st : match(fs, /^(ntfs|ntfs3|ntfs-3g|fuseblk)$/) != null;
push(D, { id: id, dev: dev, name: a.LABEL || dev, mnt: M[k].mnt, fs: fs, ro: M[k].ro, lock: lock, opts: M[k].opts });
}
return D;
}
function rod(d) { return d.ro || d.lock === true; }
function diskof(D, id) { for (let d in D) if (d.id == id) return d; return null; }
function relok(p) {
p = '' + (p ?? '');
if (!length(p)) p = '/';
if (substr(p, 0, 1) != '/' || length(p) > 1024 || match(p, /[[:cntrl:]\\]/)) return null;
p = replace(p, /\/+/g, '/');
for (let s in split(p, '/')) if (s == '..' || s == '.') return null;
if (length(p) > 1 && substr(p, -1) == '/') p = substr(p, 0, length(p) - 1);
return p;
}
function absof(D, id, rel) {
let d = diskof(D, id), r = relok(rel);
if (!d || r == null) return null;
let p = d.mnt + (r == '/' ? '' : r), rp = null;
try { rp = require('fs').realpath(p); } catch (e) {}
if (rp && rp != d.mnt && index(rp, d.mnt + '/') != 0) return null;
return p;
}
function dpsplit(s) { let m = match('' + s, /^([^:]+):(\/.*)$/); return m ? { disk: m[1], path: relok(m[2]) } : null; }

const PK = {
ksmbd: [ [ 'ksmbd-server', '/usr/sbin/ksmbd.mountd' ] ],
samba4: [ [ 'samba4-server', '/usr/sbin/smbd' ] ],
webdav: [ [ 'lighttpd', '/usr/sbin/lighttpd' ], [ 'lighttpd-mod-webdav', '/usr/lib/lighttpd/mod_webdav.so' ],
[ 'lighttpd-mod-auth', '/usr/lib/lighttpd/mod_auth.so' ], [ 'lighttpd-mod-authn_file', '/usr/lib/lighttpd/mod_authn_file.so' ],
[ 'lighttpd-mod-accesslog', '/usr/lib/lighttpd/mod_accesslog.so' ] ],
sftp: [ [ 'openssh-sftp-server', '/usr/libexec/sftp-server', '/usr/lib/sftp-server' ] ],
dlna: [ [ 'minidlna', '/usr/sbin/minidlnad', '/usr/sbin/minidlna' ] ],
dl: [ [ 'aria2', '/usr/bin/aria2c' ] ],
rsync: [ [ 'rsync', '/usr/bin/rsync' ] ],
discovery: [ [ 'wsdd2', '/usr/bin/wsdd2', '/usr/sbin/wsdd2', '/usr/sbin/avahi-daemon' ] ],
cat: [ [ 'sqlite3-cli', '/usr/bin/sqlite3' ] ],
tv: [ [ 'ucode-mod-socket', '/usr/lib/ucode/socket.so' ] ],
wake: [ [ 'etherwake', '/usr/bin/etherwake', '/usr/sbin/etherwake' ] ]
};
function need(part) {
let r = [];
for (let p in PK[part]) { let ok = false; for (let i = 1; i < length(p); i++) if (has(p[i])) ok = true; if (!ok) push(r, p[0]); }
return r;
}
function pkgerr(P) {
return { ...err('pkg', 'Serve installare: ' + join(', ', P), 'Needs to be installed: ' + join(', ', P)), need: P };
}

function roShare(N) {
if (N.on !== true && !length(type(N.shares) == 'array' ? N.shares : [])) return false;
for (let d in disks()) if (d.ro) return true;
return false;
}
function camsmb1(N) { return N.rec?.adv?.smb1 === true && length(filter(N.shares, (s) => s?.cam)) > 0; }
function tmpkg() { return need('samba4'); }
function sambaOk() { return UCFG.smbmem(R); }
function engine(N) { return UCFG.smbengine(N, { R: R, ro: roShare(N), admu: admu(N) }); }

const VPNIF = /^wgo(ut|[0-9]+)$/;
function zarr(z) { return type(z.network) == 'array' ? z.network : split(z.network ?? '', ' '); }
function wgsrv(N, i) { return N[i]?.proto == 'wireguard' && !match(i, VPNIF) && length('' + (N[i].listen_port ?? '')) > 0; }
function wgcli(N, i) { return N[i]?.proto == 'wireguard' && !wgsrv(N, i); }
function zones() {
let F = cfg('firewall'), N = cfg('network'), home = null, alt = null, wan = null, wans = [], Z = {}, fwd = {}, fromhome = {}, out = {}, mine = {};
for (let k in F) {
let z = F[k];
if (z['.type'] != 'zone' || !z.name || !match(z.name, /^[A-Za-z0-9_]{1,15}$/)) continue;
let masq = z.masq == '1' || z.masq == 'true';
Z[z.name] = { nets: zarr(z), input: uc(z.input ?? 'REJECT'), masq: masq };
for (let i in Z[z.name].nets) if (wgcli(N, i)) out[z.name] = 1;
if (z.wf == '1') mine[z.name] = 1;
if (out[z.name]) continue;
if (!home && index(Z[z.name].nets, 'lan') >= 0) home = z.name;
if (!alt && !masq && uc(z.input ?? '') == 'ACCEPT') alt = z.name;
if (!wan && masq) wan = z.name;
if (masq) push(wans, z.name);
}
home = home ?? alt;
for (let k in F) if (F[k]['.type'] == 'forwarding') {
if (F[k].dest == wan) fwd[F[k].src] = 1;
if (F[k].src == home && F[k].dest != wan) fromhome[F[k].dest] = 1;
}
let vpn = [], guest = [], iot = null, wgaddr = '';
for (let n, z in Z) {
if (n == home || n == wan || out[n]) continue;
let wg = false;
for (let i in z.nets) if (wgsrv(N, i)) wg = true;
if (wg) push(vpn, n);
else if (index(wans, n) >= 0 && !fwd[n]) continue;
else if (!iot && (fromhome[n] || mine[n])) iot = n;
else if (fwd[n]) push(guest, n);
}
for (let k in N) if (N[k]['.type'] == 'interface' && wgsrv(N, k) && !length(wgaddr)) {
let a = arr(N[k].addresses)[0] ?? '';
wgaddr = split(a, '/')[0];
}
wans = filter(wans, (n) => n == wan || (n != home && !fwd[n] && index(vpn, n) < 0));
return { home: home, wan: wan, wans: wans, vpn: vpn, guest: guest, iot: iot, Z: Z, wgaddr: wgaddr };
}
function zonedev(Zs, z) {
let N = cfg('network');
for (let n in (Zs.Z[z]?.nets ?? [])) {
let i = N[n];
if (!i) continue;
if (i.type == 'bridge') return 'br-' + n;
if (type(i.device) == 'string' && match(i.device, /^[A-Za-z0-9_.-]{1,15}$/)) return i.device;
}
return '';
}
function homedev(Zs) { return zonedev(Zs, Zs.home); }
function sshport() { let D = cfg('dropbear'), k = first(D, 'dropbear'); let p = k ? D[k].Port ?? D[k].port : null; return match('' + (p ?? ''), /^[0-9]{1,5}$/) ? +p : 22; }
function homeip() {
let Zs = zones(), N = cfg('network');
for (let n in (Zs.Z[Zs.home]?.nets ?? [])) {
let a = N[n]?.ipaddr, ip = split('' + (type(a) == 'array' ? a[0] : (a ?? '')), '/')[0];
if (ipok(ip)) return ip;
}
return '';
}

function smbwant(N) { return (N.on === true || length(N.shares) || N.tm?.on || N.fh?.on) && N.smb_off !== true; }

function fwcmd(N) {
let F = cfg('firewall'), Zs = zones(), c = '', e = engine(N), r = N.remote, A = N.adv;
for (let k in F) if (match(k, /^wf_nas_/)) c += 'uci -q delete ' + q('firewall.' + k) + '; ';
let smb = e == 'samba4' ? [ '139', '445', '137-138' ] : [ '445' ];
let MP = [ '8200', '7879' ];
let lv = N.media.cloud?.on === true && N.media.cloud?.mode == 'live';
let so = N.smb_off !== true, lanP = uniq([ ...(smbwant(N) ? smb : []), ...(N.media.on ? [ '8200', '1900' ] : []), ...(lv ? [ '7879', '1900' ] : []),
...(r.webdav ? [ '' + (r.port ?? DAVPORT) ] : []) ]);
let vpnP = [ ...(r.smbvpn && so ? smb : []), ...(r.webdav ? [ '' + (r.port ?? DAVPORT) ] : []), ...(r.sftp ? [ '' + sshport() ] : []) ];
let allP = uniq([ ...smb, '8200', '7879', '1900', '' + (r.port ?? DAVPORT) ]);
let rule = (id, name, src, ports, tgt, mac) => {
if (!length(ports) || !src) return '';
return 'uci -q set ' + q('firewall.' + id + '=rule') + '; ' + uset('firewall', id, 'name', name) + uset('firewall', id, 'src', src) +
(mac ? uset('firewall', id, 'src_mac', mac) : '') +
ulist('firewall', id, 'proto', [ 'tcp', 'udp' ]) + ulist('firewall', id, 'dest_port', uniq(ports)) + uset('firewall', id, 'target', tgt) + uset('firewall', id, 'wf', '1');
};
if (Zs.home && Zs.Z[Zs.home].input != 'ACCEPT') c += rule('wf_nas_home', 'wf-nas-home', Zs.home, lanP, 'ACCEPT');
for (let z in Zs.vpn) c += rule('wf_nas_vpn_' + z, 'wf-nas-vpn-' + z, z, vpnP, 'ACCEPT');
let netrule = (z, on, tag, P) => on ? rule('wf_nas_' + tag + '_' + z, 'wf-nas-' + tag + '-' + z, z, P, 'ACCEPT') :
(Zs.Z[z].input == 'ACCEPT' ? rule('wf_nas_' + tag + '_' + z, 'wf-nas-' + tag + '-' + z, z, allP, 'REJECT') : '');
for (let z in Zs.guest) {
c += netrule(z, A.nets?.guest === true, 'guest', filter(lanP, (p) => index(MP, p) < 0));
if (N.media.on === true && A.nets?.guest === true && Zs.Z[z].input == 'ACCEPT') c += rule('wf_nas_dlnano_' + z, 'wf-nas-dlna-no-' + z, z, MP, 'REJECT');
}
if (Zs.iot) c += netrule(Zs.iot, A.nets?.iot === true, 'iot', lanP);
for (let z in Zs.wans) c += z == Zs.wan ? rule('wf_nas_wan', 'wf-nas-wan', z, allP, 'REJECT') : rule('wf_nas_wan_' + z, 'wf-nas-wan-' + z, z, allP, 'REJECT');
return c + 'uci -q commit firewall; ';
}

const VETO = '/.wf-*/';
const VETOS = '/Thumbs.db/.DS_Store/._*/.apdisk' + VETO;
let SHOK = null;
function shadowok() {
if (SHOK != null) return SHOK;
SHOK = false;
for (let d in [ '/usr/lib/samba/vfs', '/usr/lib/samba/modules/vfs', '/usr/lib64/samba/vfs' ]) if (has(d + '/shadow_copy2.so')) SHOK = true;
if (!SHOK && R == '') SHOK = index(sh('smbd -b 2>/dev/null'), 'shadow_copy2') >= 0;
return SHOK;
}
function tplset(f, add, tail, late) {
let t = readfile(R + f);
if (t == null) return;
let kof = (a) => { let m = match(a, /^[ \t]*([^=#;\[]+)=/); return m ? lc(replace(m[1], /[ \t]+/g, '')) : null; }, KY = {};
for (let a in [ ...(add ?? []), ...(late ?? []) ]) { let k = kof(a); if (k) KY[k] = true; }
let nbx = length(keys(KY));
let out = [], skip = false, ing = false, done = false, L = split(t, '\n'), orig = false;
let put = () => {
let bl = 0, held = [];
while (length(out) && match(out[length(out) - 1], /^# wf-(cloud|dav|dlna)$/)) unshift(held, pop(out));
while (length(out) && out[length(out) - 1] == '') { pop(out); bl++; }
for (let a in [ ...(add ?? []), ...(late ?? []) ]) push(out, MARK, '\t' + a);
while (bl-- > 0) push(out, '');
for (let h in held) push(out, h);
done = true;
};
let ourl = (a) => match(a, /^[ \t]*#?[ \t]*[^=#;\[]+=.*(\/nasdfree|\.wf-)/) != null;
for (let l in L) {
if (skip) { skip = false; continue; }
if (l == MARK) { skip = true; continue; }
if (l == MARKO) { orig = true; continue; }
if (orig) { orig = false; l = replace(l, /^#/, ''); if (ourl(l)) continue; }
if (ing && !done && ourl(l)) continue;
if (nbx && ing && !done && KY[kof(l) ?? ''] === true) { push(out, MARKO, '#' + l); continue; }
if (!done && match(l, /^[ \t]*\[/)) {
if (ing) { put(); ing = false; }
else if (match(l, /^[ \t]*\[global\]/)) ing = true;
}
push(out, l);
}
if (!done && ing) put();
while (length(out) && out[length(out) - 1] == '') pop(out);
for (let a in (tail ?? [])) push(out, MARK, a);
if (length(tail ?? []) && match(f, /smb\.conf\.template$/)) push(out, MARK, '[global]');
push(out, '');
let n = join('\n', out);
if (n == t) return;
let LK = '/tmp/wf-smbtpl.lock', got = false;
for (let k = 0; k < 10 && !(got = mkdir(LK)); k++) {
let s = stat(LK);
if (s && time() - s.mtime > 10) { rmdir(LK); continue; }
sh('sleep 1');
}
if (readfile(R + f) == t) { writefile(R + f + '.wf', n); rename(R + f + '.wf', R + f); }
if (got) rmdir(LK);
}
function people(N) { return filter(sort(keys(N.users)), (u) => type(N.users[u]) == 'object' && !N.users[u].cam && N.users[u].blocked !== true); }
function fulls(N) { let F = split(readfile(TMP + '/full.list') ?? '', '\n'); return filter(people(N), (u) => index(F, u) >= 0); }
function mpaused() { return stat(MAINPJ) != null; }
function fullfp(N) { return join(' ', fulls(N)) + (mpaused() ? ' |pausa' : ''); }
function smbnm(s) { return replace('' + s, /[]\\\/:*?"<>|[[:cntrl:]]/g, '-'); }
function nbname(N) { let n = substr(replace('' + (N.adv?.name ?? ''), /[^A-Za-z0-9-]/g, '-'), 0, 15); return match(n, /[A-Za-z]/) ? n : 'NAS'; }
function upath(N, own, k) { let p = UCFG.udir ? UCFG.udir(own, k, null, N) : null; return length(p ?? '') ? '/' + p : null; }
function camoff(N, D) { return mpaused() ? 'pause' : (diskof(D, N.main?.id) ? '' : 'nomain'); }
function camst(N, D) { return N.rec?.on === true && length(filter(N.shares, (s) => s?.cam)) ? (camoff(N, D) || null) : null; }
function uxfs(d) { return !match(d?.fs ?? '', /^(ntfs3?|vfat|exfat|fuse.*)$/); }
const DISKNM = 'Admin Drive', DRIVE = 'Drive';
const RESV = {"names":["drive","cloud","admin drive","admin cloud","cartella condivisa","backup del mac","backup del pc","global","homes","printers","print$","ipc$"],"starts":["drive ","cloud ","admin drive ","admin cloud ","nas ","cartella condivisa"]};
function reserved(name) {
let n = lc(trim(replace('' + (name ?? ''), /[ \t]+/g, ' ')));
if (index(RESV.names, n) >= 0) return true;
for (let s in RESV.starts) if (substr(n, 0, length(s)) == s) return true;
return false;
}
const SMBU = '/tmp/wf-smbu', DRIVEP = SMBU + '/%u/' + DRIVE;
function sharesAll(N, D, e) {
let S = [], mn = diskof(D, N.main?.id), P = people(N), pz = mpaused(), full = pz ? P : fulls(N), nm = {}, dv = {}, ADMU = admu(N);
let s4 = (e ?? engine(N)) == 'samba4', drv = (v) => s4 ? DRIVE : DRIVE + ' ' + v;
let add = (s) => { s.name = smbnm(s.name); s.dav = smbnm(s.dav ?? s.name); nm[lc(s.name)] = 1; dv[lc(s.dav)] = 1; push(S, s); };
let one = (b, H) => { let n = b, k = 2; if (H[lc(n)]) n = b + ' (Disco)'; while (H[lc(n)]) n = b + ' (Disco ' + (k++) + ')'; return n; };
if (N.on === true && mn) {
for (let u in P) {
let p = upath(N, u, 'root'), v = N.users[u].vis || u;
if (p) add({ name: drv(v), dav: v, disk: mn.id, path: p, read: index(full, u) >= 0 ? [ u ] : [], write: index(full, u) >= 0 ? [] : [ u ], kind: 'user', user: u, su: u });
}
let sp = upath(N, 'shared', 'root'), ap = upath(N, 'admin', 'root');
if (sp) add({ name: 'Cartella Condivisa', disk: mn.id, path: sp, read: pz ? uniq([ ADMU, ...P ]) : filter(full, (u) => u != ADMU), write: pz ? [] : uniq([ ADMU, ...filter(P, (u) => index(full, u) < 0) ]), kind: 'shared' });
if (ap) add({ name: drv(UCFG.UDIR.admin), dav: UCFG.UDIR.admin, disk: mn.id, path: ap, read: [], write: [ ADMU ], kind: 'admin', su: ADMU });
for (let g in (type(N.gone) == 'array' ? N.gone : [])) {
let p = upath(N, g?.user, 'root'), gv = g?.vis || g?.user, gn = lc(smbnm(gv)), gs = lc(smbnm(DRIVE + ' ' + gv));
if (p && !nm[gs] && !dv[gn]) add({ name: DRIVE + ' ' + gv, dav: gv, disk: mn.id, path: p, read: [], write: [ ADMU ], kind: 'gone', user: g.user });
}
}
let co = camoff(N, D);
for (let s in N.shares) if (s?.cam && N.rec?.on === true && !co && s.disk == mn?.id) add({ ...s, read: s.read ?? [], write: s.write ?? [], kind: 'cam' });
if (mn) for (let k in [ 'tm', 'fh' ]) {
if (N[k]?.on !== true || (k == 'tm' && engine(N) != 'samba4')) continue;
for (let u in P) {
let p = upath(N, u, k), f = index(full, u) >= 0;
if (p) add({ name: (UCFG.UDIR?.[k] ?? k) + ' (' + (N.users[u].vis || u) + ')', disk: mn.id, path: p, read: f ? [ u ] : [], write: f ? [] : [ u ], kind: k, user: u, tm: k == 'tm', fh: k == 'fh' });
}
}
let SN = type(N.smbn) == 'object' ? N.smbn : {}, used = {}, sch = false;
for (let k, v in SN) if (type(v) == 'int' && v >= 2) used[v] = 1;
if (N.on === true) for (let id in sort(map(filter(D, (d) => d.id != mn?.id), (d) => '' + d.id))) {
if (type(SN[id]) == 'int' && SN[id] >= 2) continue;
let n = 2;
while (used[n]) n++;
used[n] = 1; SN[id] = n; sch = true;
}
if (sch) N.smbn = SN;
if (N.on === true) for (let d in D) {
let o = N.disks?.[d.id], b = smbnm((type(o) == 'object' ? o.name ?? o.gone?.name : null) || d.name || d.id);
let sn = mn != null && d.id == mn.id ? DISKNM : DISKNM + ' ' + SN['' + d.id];
add({ name: one(sn, nm), dav: one(b, dv), disk: d.id, path: '/', read: rod(d) ? [ ADMU ] : [], write: rod(d) ? [] : [ ADMU ], kind: 'disk', noutenti: mn != null && d.id == mn.id, vu: true });
}
return S;
}
function tmstate(N, D, k) {
let x = N[k] ?? {}, pk = k == 'tm' ? tmpkg() : [], mn = diskof(D, N.main?.id);
let st = k == 'tm' && !sambaOk() ? 'mem' : (length(pk) ? 'install' : (x.on !== true || N.smb_off === true ? 'off' : (!mn ? 'nomain' : 'on')));
let S = st == 'on' ? filter(sharesAll(N, D), (s) => s.kind == k) : [];
return { on: x.on === true, state: st, need: pk, quota_gb: x.quota_gb ?? 0,
shares: map(S, (s) => ({ user: s.user, name: s.name, path: s.path, ro: !length(s.write), missing: absof(D, s.disk, s.path) == null })) };
}
function saveorig(N, conf, sec, K, C, isnew) {
if (type(N.orig) != 'object') N.orig = {};
if (N.orig[conf] != null) return;
if (isnew) { N.orig[conf] = { sec: sec, new: true }; return; }
let o = {};
for (let k in K) o[k] = C[sec]?.[k] ?? null;
N.orig[conf] = { sec: sec, o: o };
}
function smbvpnifs() {
let W = cfg('network'), O = cfg('openvpn'), dv = { tailscale0: true }, r = [];
for (let k, s in O) if (s['.type'] == 'openvpn' && s.enabled == '1' && (s.server != null || s.mode == 'server' || s.server_bridge != null) && match('' + (s.dev ?? ''), /^[A-Za-z0-9_.-]{1,15}$/)) dv[s.dev] = true;
for (let k, s in W) {
if (s['.type'] != 'interface') continue;
let d = '' + (s.device ?? s.ifname ?? '');
if (wgsrv(W, k) || ((s.proto ?? 'none') == 'none' && dv[d])) push(r, k);
}
return r;
}
function smbifdef(conf) {
let m = match(readfile(R + '/etc/init.d/' + conf) ?? '', /config_get[ \t]+interface[ \t]+"?\$1"?[ \t]+interface[ \t]+"([^"]*)"/);
if (m) return arr(m[1]);
let Zs = zones(); return Zs.Z[Zs.home]?.nets ?? [];
}
function smbifback(X) {
if (type(X) != 'object' || !match('' + X.conf, /^(ksmbd|samba4)$/) || !match('' + X.sec, /^([A-Za-z0-9_]{1,64}|@[A-Za-z0-9_]{1,32}\[[0-9]{1,3}\])$/)) return '';
if (join(' ', arr(cfg(X.conf)[X.sec]?.interface)) != X.v) return '';
return X.o == null ? 'uci -q delete ' + q(X.conf + '.' + X.sec + '.interface') + '; uci -q commit ' + q(X.conf) + '; ' : uset(X.conf, X.sec, 'interface', X.o) + 'uci -q commit ' + q(X.conf) + '; ';
}
function smblocaldrop() {
for (let f in [ '/etc/ksmbd/ksmbd.conf', '/etc/samba/smb.conf' ]) {
let s = lstat(R + f);
if (s?.type == 'file' && index(split(readfile(R + f) ?? '', '\n'), MARK) >= 0) unlink(R + f);
}
}
function smbold(conf) {
let oc = conf == 'samba4' ? 'ksmbd' : 'samba4', od = filter(keys(cfg(oc)), (k) => match(k, /^wf_/));
return length(od) ? join('', map(od, (k) => 'uci -q delete ' + q(oc + '.' + k) + '; ')) + 'uci -q commit ' + oc + '; ' : '';
}
function smbroot(d) {
if (!d || !match(d.fs ?? '', /^(ntfs3?|vfat|exfat|fuseblk)$/)) return true;
for (let o in split(d.opts ?? '', ',')) if (match(o, /^(dmask|umask)=/)) return !match(o, /=0*$/);
return true;
}
function camold(N) {
let ch = false;
for (let s in (N.shares ?? [])) if (type(s) == 'object' && s.allow != null) { delete s.allow; ch = true; }
if (type(N.rec) == 'object' && N.rec.auth != null) { delete N.rec.auth; ch = true; }
return ch;
}
const DFSJ = TMP + '/dfs.json';
function dfsof(N) { return ''; }
function davlink(N, D) {
if (N.on !== true || !uxfs(diskof(D ?? disks(), N.main?.id))) return false;
if (engine(N) == 'samba4' && N.smb_off !== true) return true;
return N.on === true && N.remote?.webdav === true && engine(N) != 'samba4' && has('/usr/sbin/lighttpd') && has('/usr/lib/lighttpd/mod_webdav.so');
}
function dfstpl() { return index(split(readfile(R + '/etc/samba/smb.conf.template') ?? '', '\n'), '\thost msdfs = yes') >= 0; }
function dfsnow(N) { let h = dfsof(N); return length(h) && dfstpl() ? h : ''; }
function dfsours(nm, c) { return match(c ?? '', /^msdfs:/) != null || c == '../' + nm; }
function dfslinks(N, D, h, w) {
let mn = diskof(D, N.main?.id), nm = UCFG.UDIR?.shared, ok = [], md = length(h) ? 'dfs' : (w ? 'dav' : '');
if (mn && length(nm ?? '')) {
let t = md == 'dfs' ? 'msdfs:' + h + '\\' + smbnm(nm) : (md == 'dav' ? '../' + nm : null), P = t ? people(N) : [];
let G = map(filter(type(N.gone) == 'array' ? N.gone : [], (g) => type(g?.user) == 'string'), (g) => g.user);
for (let u in uniq([ ...keys(type(N.users) == 'object' ? N.users : {}), ...G ])) {
let r = upath(N, u, 'root'), d = r ? absof(D, mn.id, r) : null;
if (!d || lstat(d)?.type != 'directory') continue;
let f = d + '/' + nm, l = lstat(f), cur = l?.type == 'link' ? readlink(f) : null;
if (l && !dfsours(nm, cur)) continue;
if (index(P, u) >= 0) {
if (cur != t) { if (l) unlink(f); if (!symlink(t, f)) continue; }
push(ok, u);
}
else if (l) unlink(f);
}
}
let o = sprintf('%J', { mode: length(ok) ? md : '', host: length(ok) ? h : '', users: ok });
if (readfile(DFSJ) != o) { mkdir(TMP); writefile(DFSJ + '.t', o); rename(DFSJ + '.t', DFSJ); }
}
function smbulinks(N, D) {
let L = {}, e = N.on === true && N.smb_off !== true ? engine(N) : '';
if (e == 'samba4') for (let s in sharesAll(N, D, e)) {
let p = (s.kind == 'user' || s.kind == 'admin') && length(s.su ?? '') ? absof(D, s.disk, s.path) : null;
if (p && !match(s.su, /[\/]|^\.\.?$/)) L[s.su] = p;
}
if (!length(keys(L)) && !stat(SMBU)) return;
mkd(SMBU);
for (let u in (lsdir(SMBU) ?? [])) {
let d = SMBU + '/' + u;
if (L[u] != null && lstat(d)?.type == 'directory') continue;
if (lstat(d)?.type == 'directory') { for (let f in (lsdir(d) ?? [])) if (lstat(d + '/' + f)?.type == 'link') unlink(d + '/' + f); rmdir(d); }
else unlink(d);
}
for (let u, p in L) {
let d = SMBU + '/' + u, f = d + '/' + DRIVE, l = lstat(f);
mkd(d);
if (l?.type == 'link' && readlink(f) == p) continue;
if (l?.type == 'link') unlink(f);
else if (l) continue;
symlink(p, f);
}
}
function smbcmd(N, D) {
let e = engine(N), c = '', A = N.adv, s1 = e == 'samba4' && camsmb1(N), min = s1 ? 'NT1' : (A.smb_min == '3' ? 'SMB3_00' : 'SMB2_10');
let conf = e == 'samba4' ? 'samba4' : 'ksmbd', C = cfg(conf), stype = e == 'samba4' ? 'sambashare' : 'share';
smblocaldrop();
for (let k in C) if (match(k, /^wf_/)) c += 'uci -q delete ' + q(conf + '.' + k) + '; ';
c += smbold(conf);
let g = first(C, e == 'samba4' ? 'samba' : 'globals');
if (g && match(g, /^wf_/)) g = null;
if (g) saveorig(N, conf, g, [ 'workgroup', 'description', 'name', 'allow_legacy_protocols', 'macos', ...(e == 'samba4' ? [ 'disable_netbios' ] : []) ], C, false);
if (!g) { g = e == 'samba4' ? 'wf_samba' : 'wf_globals'; c += 'uci -q set ' + q(conf + '.' + g + '=' + (e == 'samba4' ? 'samba' : 'globals')) + '; '; }
let vif = smbvpnifs(), X = type(N.smbif) == 'object' ? N.smbif : null;
let want = N.remote?.smbvpn === true && N.smb_off !== true && length(vif) > 0;
if (X && (!want || X.conf != conf || X.sec != g)) { c += smbifback(X); delete N.smbif; X = null; }
let c0 = length(c);
if (want) {
let cur = C[g]?.interface, o = X ? X.o : (cur == null ? null : join(' ', arr(cur)));
let v = join(' ', uniq([ ...(o == null ? smbifdef(conf) : arr(o)), ...vif ]));
c += uset(conf, g, 'interface', v);
N.smbif = { conf: conf, sec: g, o: o, v: v };
}
if (length(A.group ?? '')) c += uset(conf, g, 'workgroup', A.group);
if (length(A.name ?? '')) c += uset(conf, g, 'description', A.name) + (e == 'samba4' ? uset(conf, g, 'name', A.name) : '');
c += uset(conf, g, 'allow_legacy_protocols', '0');
if (e == 'samba4') c += uset(conf, g, 'macos', N.tm?.on ? '1' : '0');
let nb = e == 'samba4' && A.netbios === true;
if (e == 'samba4') c += uset(conf, g, 'disable_netbios', nb ? '0' : '1');
let cg = length(c);
let i = 0, tail = [], dh = e == 'samba4' ? dfsof(N) : '';
let vo = e == 'samba4' && N.vers?.on !== false && shadowok();
let dv = e != 'samba4' && davlink(N, D) ? (UCFG.UDIR?.shared ?? '') : '';
let s4l = e == 'samba4' && davlink(N, D);
let L = sharesAll(N, D, e);
if (e == 'samba4') {
let K = filter(L, (s) => (s.kind == 'user' || s.kind == 'admin') && absof(D, s.disk, s.path) != null);
L = filter(L, (s) => s.kind != 'user' && s.kind != 'admin');
if (length(K)) unshift(L, { name: DRIVE, kind: 'user', disk: K[0].disk, path: '/', sp: DRIVEP,
read: uniq(map(filter(K, (s) => length(s.read ?? [])), (s) => s.su)), write: uniq(map(filter(K, (s) => !length(s.read ?? [])), (s) => s.su)) });
}
for (let s in L) {
let p = s.sp ?? absof(D, s.disk, s.path), d = diskof(D, s.disk);
if (!p) continue;
let rd = uniq(s.read ?? []), wr = uniq(s.write ?? []), all = uniq([ ...rd, ...wr ]);
if (!length(all)) continue;
let pp = s.kind == 'user' || s.kind == 'shared' || s.kind == 'tm' || s.kind == 'fh', ux = uxfs(d);
let fr = pp && ux ? false : smbroot(d), vt = s.vu ? VETO + (UCFG.UDIR?.root ?? 'Utenti') + '/' : VETO;
if (s.sp && fr) { fr = false; rd = all; wr = []; }
if (s.kind == 'user' && length(dv)) vt += dv + '/';
let id = 'wf_' + (i++);
let bw = s.kind == 'tm' || s.kind == 'fh' || (s.kind == 'shared' && s4l) ? 'no' : 'yes';
let cm = pp && ux ? '0664' : '0666', dm = pp && ux ? '0775' : '0777';
if (e != 'samba4' && fr) {
push(tail, '[' + s.name + ']', '\tpath = ' + p, '\tread only = yes', '\tguest ok = no', '\tbrowseable = ' + bw, '\tcreate mask = ' + cm,
'\tdirectory mask = ' + dm, '\tforce user = root', '\tforce group = root', '\tvalid users = ' + join(' ', all),
...(length(wr) ? [ '\twrite list = ' + join(' ', wr) ] : []), ...(length(rd) ? [ '\tread list = ' + join(' ', rd) ] : []),
'\thide dot files = yes', '\tveto files = ' + vt);
continue;
}
if (e == 'samba4') {
let mac = N.tm?.on === true, x = [ '[' + s.name + ']', '\tpath = ' + p ];
if (fr) push(x, '\tforce user = root', '\tforce group = root');
push(x, '\tvalid users = ' + join(' ', all), '\tcreate mask = ' + cm, '\tdirectory mask = ' + dm, '\tbrowseable = ' + bw,
'\tread only = yes', '\tguest ok = no', ...(length(wr) ? [ '\twrite list = ' + join(' ', wr) ] : []),
...(length(rd) ? [ '\tread list = ' + join(' ', rd) ] : []), '\thide dot files = yes', '\tveto files = ' + VETOS + substr(vt, length(VETO)));
if (s.sp) push(x, '\twide links = yes');
else if (fr || s.kind == 'disk' || s.kind == 'cam') push(x, '\twide links = no');
if (A.trash !== false && !s.tm && d) push(x, '\trecycle:repository = ' + d.mnt + '/.wf-trash/%u/%S');
if (d?.fs == 'vfat') push(x, '\tfstype = FAT');
if (vo && !s.tm && d) push(x, '\tshadow:snapdir = ' + d.mnt + '/.wf-vers', '\tshadow:basedir = ' + d.mnt);
if (mac) push(x, '\tfruit:encoding = native', '\tfruit:metadata = stream', '\tfruit:veto_appledouble = no');
if (mac && s.tm) push(x, '\tfruit:time machine = yes', ...(type(N.tm?.quota_gb) == 'int' && N.tm.quota_gb > 0 ? [ '\tfruit:time machine max size = ' + N.tm.quota_gb + 'G' ] : []));
let vf = [ ...(mac ? [ 'catia', 'fruit', 'streams_xattr' ] : []), ...(!s.tm && vo && d ? [ 'shadow_copy2' ] : []), ...(!s.tm && A.trash !== false ? [ 'recycle' ] : []) ];
if (length(vf)) push(x, '\tvfs objects = ' + join(' ', vf));
push(tail, ...x);
continue;
}
c += 'uci -q set ' + q(conf + '.' + id + '=' + stype) + '; ' + uset(conf, id, 'name', s.name) + uset(conf, id, 'path', p) +
uset(conf, id, 'read_only', 'yes') + uset(conf, id, 'guest_ok', 'no') + uset(conf, id, 'browseable', bw) +
uset(conf, id, 'create_mask', cm) + uset(conf, id, 'dir_mask', dm) + (fr ? uset(conf, id, 'force_root', '1') : '') +
uset(conf, id, 'hide_dot_files', 'yes') + uset(conf, id, 'veto_files', vt) + uset(conf, id, 'users', join(' ', all)) +
(length(wr) ? uset(conf, id, 'write_list', join(' ', wr)) : '') + (length(rd) ? uset(conf, id, 'read_list', join(' ', rd)) : '');
}
let tpl = [ e == 'samba4' ? '/etc/samba/smb.conf.template' : '/etc/ksmbd/ksmbd.conf.template',
[ 'server min protocol = ' + min, ...(e == 'samba4' ? [ 'veto files = ' + VETOS, 'delete veto files = yes' ] : []), ...(length(dh) ? [ 'host msdfs = yes' ] : []),
...(e == 'samba4' ? [ 'access based share enum = no' ] : []), ...(e == 'samba4' && !nb ? [ 'disable netbios = yes' ] : []), ...(e == 'samba4' && A.trash !== false ?
[ 'recycle:keeptree = yes', 'recycle:versions = yes', 'recycle:touch = yes', 'recycle:touch_mtime = yes', 'recycle:exclude_dir = .wf-trash' ] : []),
...(vo ? [ 'shadow:format = @GMT-%Y.%m.%d-%H.%M.%S', 'shadow:localtime = no', 'shadow:sort = desc' ] : []),
'map to guest = ' + (e == 'samba4' ? 'Never' : 'never'), 'restrict anonymous = 2',
...(e == 'samba4' ? [ 'unix extensions = no', 'smb3 unix extensions = no', 'null passwords = no', 'max log size = 1000', ...(s1 ? [ 'ntlm auth = ntlmv2-only', 'lanman auth = no' ] : []) ] : []),
...(e == 'samba4' && has(replace(SH, /nasvc\.sh$/, 'nasdfree')) ? [ 'dfree command = ' + replace(SH, /nasvc\.sh$/, 'nasdfree'), 'dfree cache time = 60' ] : []) ], tail,
[ 'netbios name = ' + nbname(N) ] ];
return { c: c + 'uci -q commit ' + conf + '; ', e: e, conf: conf, tpl: tpl, dfs: dh, fp: conf + '|' + g + '|' + substr(c, c0) + sprintf('%J', tpl),
gfp: conf + '|' + g + '|' + substr(c, c0, cg - c0) + sprintf('%J', [ tpl[1], tpl[3] ]) };
}
const SMBFP = ETC + '/nas-smb.fp';
function smbfpok(N, D) {
let x = smbcmd(json(sprintf('%J', N)), D);
return readfile(SMBFP) == x.fp;
}

const DAVINIT = '#!/bin/sh /etc/rc.common\n# WrtFreedom: Cartella Sul Telefono (WebDAV del NAS), scritto da nasvc.uc e tolto da nasvc.sh uninstall\nSTART=99\nUSE_PROCD=1\n' +
'start_service() {\n\t[ -f /etc/wrtfreedom/nas-dav.conf ] || return 0\n\tsh /usr/share/wrtfreedom/nasvc.sh davroot\n\tprocd_open_instance\n' +
'\tprocd_set_param command /usr/sbin/lighttpd -D -f /etc/wrtfreedom/nas-dav.conf\n\tprocd_set_param respawn\n\tprocd_close_instance\n}\n';
function reesc(s) { return replace('' + s, /[]\\.^$|()*+?{}[]/g, (x) => '\\' + x); }
const CLDAVL = getenv('WF_CLDAVL') ?? '/tmp/wf-cloud/dav.list', CLDAVF = TMP + '/dav-cloud.list';
function cldav() { return readfile(CLDAVL) ?? ''; }
function cldavchg() { return cldav() != (readfile(CLDAVF) ?? ''); }
function davenc(s) {
let r = '', L = length(s);
for (let i = 0; i < L; ) {
let b = ord(s, i), n = b < 0x80 ? 1 : b >= 0xc2 && b <= 0xdf ? 2 : b >= 0xe0 && b <= 0xef ? 3 : b >= 0xf0 && b <= 0xf4 ? 4 : 0;
for (let j = 1; j < n; j++) { let x = ord(s, i + j); if (x == null || x < 0x80 || x > 0xbf) { n = 0; break; } }
let k = n || 1, c = substr(s, i, k), p = '';
for (let j = 0; j < k; j++) p += '%(?i:' + sprintf('%02x', ord(s, i + j)) + ')';
r += n == 0 ? p : n > 1 ? '(' + c + '|' + p + ')' : match(c, /^[A-Za-z0-9_~-]$/) ? c : '(' + reesc(c) + '|' + p + ')';
i += k;
}
return r;
}
function davdst(dn, sub, who, wr, rd) {
let h = '$REQUEST_HEADER["Destination"] =~ "^([A-Za-z]+://[^/]*)?/' + davenc(dn) + (sub != null ? '/(?i:' + davenc(sub) + ')' : '') + '(/|$)" {\n\t';
let un = (L) => '"username=\\"(' + join('|', map(L, reesc)) + ')\\""';
if (sub != null || !length(wr) || !length(who)) return h + 'webdav.is-readonly = "enable"\n}';
return h + '$REQUEST_HEADER["Authorization"] !~ ' + un(who) + ' {\n\t\twebdav.is-readonly = "enable"\n\t}' +
(length(rd) ? '\n\t$REQUEST_HEADER["Authorization"] =~ ' + un(rd) + ' {\n\t\twebdav.is-readonly = "enable"\n\t}' : '') + '\n}';
}
function davconf(N, D) {
let S = sharesAll(N, D), links = [], blocks = [], up = '', own = [], dst = [];
for (let s in S) {
let p = absof(D, s.disk, s.path);
if (!p || s.tm || s.cam || s.kind == 'cam') continue;
let rd = uniq(s.read ?? []), wr = uniq(s.write ?? []), who = uniq([ ...rd, ...wr ]);
if (!length(who)) continue;
if (!length(up)) up = diskof(D, s.disk).mnt + '/.wf-dav-tmp';
let dn = s.dav ?? s.name;
push(links, dn + '\t' + p);
if ((s.kind == 'user' || s.kind == 'shared') && uxfs(diskof(D, s.disk))) push(own, '# wf-own ' + dn);
let au = (r) => 'auth.require = ( "" => ( "method" => "digest", "realm" => "' + REALM + '", "require" => "' + r + '" ) )';
let ro = length(wr) && length(rd) ? '\n\t$REQUEST_HEADER["Authorization"] =~ "username=\\"(' + join('|', map(rd, reesc)) + ')\\"" {\n\t\twebdav.is-readonly = "enable"\n\t}' : '';
push(blocks, '$HTTP["url"] =~ "^/' + reesc(dn) + '(/|$)" {\n\t' + au(join('|', map(who, (u) => 'user=' + u))) +
'\n\twebdav.is-readonly = "' + (length(wr) ? 'disable' : 'enable') + '"' + ro + '\n}');
if (s.vu) push(blocks, '$HTTP["url"] =~ "^/' + reesc(dn) + '/(?i:' + reesc(UCFG.UDIR?.root ?? 'Utenti') + ')(/|$)" {\n\t' + au('user=.wf-nessuno') + '\n}');
push(dst, davdst(dn, null, who, wr, filter(rd, (u) => index(wr, u) < 0)));
if (s.vu) push(dst, davdst(dn, UCFG.UDIR?.root ?? 'Utenti', who, wr, []));
}
let cl = cldav(), seen = {}, uok = (u) => match(u, /^[A-Za-z0-9._-]{1,64}$/) != null;
for (let l in links) seen[lc(split(l, '\t')[0])] = true;
for (let l in split(cl, '\n')) {
let x = split(l, '|');
if (length(x) < 4) continue;
let dn = x[0], p = x[1], who = filter(uniq(arr(x[2])), uok), wr = filter(uniq(arr(x[3])), (u) => index(who, u) >= 0), rd = filter(who, (u) => index(wr, u) < 0);
if (!match(dn, /^[^\/"\\[:cntrl:]]{1,80}$/) || !match(p, /^\/[^"\\[:cntrl:]]*$/) || index(p + '/', '/../') >= 0 || seen[lc(dn)] || !length(who)) continue;
seen[lc(dn)] = true;
push(links, dn + '\t' + p);
let au = (r) => 'auth.require = ( "" => ( "method" => "digest", "realm" => "' + REALM + '", "require" => "' + r + '" ) )';
let ro = length(wr) && length(rd) ? '\n\t$REQUEST_HEADER["Authorization"] =~ "username=\\"(' + join('|', map(rd, reesc)) + ')\\"" {\n\t\twebdav.is-readonly = "enable"\n\t}' : '';
push(blocks, '$HTTP["url"] =~ "^/' + reesc(dn) + '(/|$)" {\n\t' + au(join('|', map(who, (u) => 'user=' + u))) +
'\n\twebdav.is-readonly = "' + (length(wr) ? 'disable' : 'enable') + '"' + ro + '\n}');
push(dst, davdst(dn, null, who, wr, rd));
for (let v in split(x[4] ?? '', '/')) if (length(v) && !match(v, /[[:cntrl:]"\\]/)) {
push(blocks, '$HTTP["url"] =~ "^/' + reesc(dn) + '/(?i:' + reesc(v) + ')(/|$)" {\n\t' + au('user=.wf-nessuno') + '\n}');
push(dst, davdst(dn, v, who, wr, []));
}
}
let lg = length(own) && has('/usr/lib/lighttpd/mod_accesslog.so');
let conf = 'server.modules = ( "mod_auth", "mod_authn_file", "mod_webdav"' + (lg ? ', "mod_accesslog"' : '') + ' )\nserver.document-root = "' + TMP + '/dav"\n' +
(lg ? 'accesslog.filename = "|sh ' + replace(q(SH), '"', '') + ' davlog"\naccesslog.format = "%>s %u %{Destination}i %r"\n' + join('\n', own) + '\n' : '') +
'server.port = ' + (N.remote.port ?? DAVPORT) + '\nserver.pid-file = "/var/run/wf-nasdav.pid"\nserver.errorlog-use-syslog = "enable"\n' +
(length(up) ? 'server.upload-dirs = ( "' + up + '" )\n' : '') + 'dir-listing.activate = "disable"\n' +
'auth.backend = "htdigest"\nauth.backend.htdigest.userfile = "/etc/wrtfreedom/nas-dav.digest"\nwebdav.activate = "enable"\n' +
'auth.require = ( "" => ( "method" => "digest", "realm" => "' + REALM + '", "require" => "valid-user" ) )\n' + join('\n', blocks) + '\n' +
(length(dst) ? join('\n', dst) + '\n' : '');
return { conf: conf, links: links, cl: cl };
}
function davchg(N, D) {
return readfile(ETC + '/nas-dav.conf') != davconf(N, D).conf || readfile(R + '/etc/init.d/wf-nasdav') != DAVINIT;
}
function davwrite(N, D) {
let x = davconf(N, D);
writefile(CLDAVF, x.cl);
writefile(ETC + '/nas-dav.conf', x.conf);
writefile(ETC + '/nas-dav.links', join('\n', x.links) + '\n');
writefile(R + '/etc/init.d/wf-nasdav', DAVINIT);
}

function nfsdrop() {
let f = R + '/etc/exports', t = readfile(f);
if (t == null || index(t, MARK + ' begin') < 0) return;
let out = [], skip = false;
for (let l in split(t, '\n')) { if (l == MARK + ' begin') { skip = true; continue; } if (l == MARK + ' end') { skip = false; continue; } if (!skip) push(out, l); }
while (length(out) && out[length(out) - 1] == '') pop(out);
writefile(f, join('\n', out) + (length(out) ? '\n' : ''));
}

function svcs(N) {
let e = engine(N), r = [];
let sm = smbwant(N);
push(r, [ 'ksmbd', sm && e == 'ksmbd' && has('/etc/init.d/ksmbd') ], [ 'samba4', sm && e == 'samba4' && has('/etc/init.d/samba4') ]);
push(r, [ 'wf-nasdav', N.remote.webdav === true && has('/usr/sbin/lighttpd') ]);
if (index(N.ours ?? [], 'nfsd') >= 0) push(r, [ 'nfsd', false ]);
return r;
}
function evnas(t, it, en) { detach('sh ' + q(R + '/usr/share/wrtfreedom/event.sh') + ' cron ' + t + ' nas ' + q(L(it, en))); }
const SPARE = {
samba4: [ 'Secondo server delle cartelle di rete (samba4)', 'Second network folder server (samba4)' ],
ksmbd: [ 'Secondo server delle cartelle di rete (ksmbd)', 'Second network folder server (ksmbd)' ],
lighttpd: [ 'Server web lighttpd di serie', 'Default lighttpd web server' ],
aria2: [ 'aria2 di serie', 'Default aria2' ],
vsftpd: [ 'FTP di serie (vsftpd)', 'Default FTP (vsftpd)' ],
minidlna: [ 'Server Multimediale di serie', 'Default Media Server' ],
wsdd2: [ 'Individuazione Rete di serie (wsdd2)', 'Default Network Discovery (wsdd2)' ]
};
function rcon(n) { for (let f in lsdir(R + '/etc/rc.d') ?? []) if (replace(f, /^S[0-9]+/, '') == n && match(f, /^S[0-9]/)) return true; return false; }
function procrun() {
let J = null, r = {};
try { J = json(sh('ubus -t 5 call service list 2>/dev/null') || 'null'); } catch (e) { J = null; }
for (let n, s in (type(J) == 'object' ? J : {})) for (let k, i in (type(s?.instances) == 'object' ? s.instances : {})) if (i?.running === true) r[n] = true;
return r;
}
const DISCINIT = '/etc/init.d/wf-nasdisc', AVSVC = '/etc/avahi/services/wfnas.service';
function wsddbin() { for (let b in [ '/usr/bin/wsdd2', '/usr/sbin/wsdd2' ]) if (has(b)) return b; return null; }
function discwant(N) { return !!smbwant(N) && N.adv?.discovery !== false; }
function discname(N) { return nbname(N); }
function discgroup(N) { let g = '' + (N.adv?.group || ''); return match(g, /^[A-Za-z0-9][A-Za-z0-9_-]{0,14}$/) ? g : 'WORKGROUP'; }
function discsvcs(N) {
let dk = discwant(N), ours = N.ours ?? [], r = [];
if (has('/etc/init.d/wsdd2') && index(ours, 'wsdd2') >= 0) push(r, [ 'wsdd2', false ]);
if (dk || has(DISCINIT)) push(r, [ 'wf-nasdisc', dk && wsddbin() != null ]);
if (has('/etc/init.d/avahi-daemon') && (!dk || index(ours, 'avahi-daemon') >= 0 || procrun()['avahi-daemon'] !== true)) push(r, [ 'avahi-daemon', dk ]);
return r;
}
function discwrite(N, D) {
let dk = discwant(N), b = wsddbin(), nm = discname(N), i = homedev(zones());
let TM = filter(sharesAll(N, D ?? disks()), (s) => s.kind == 'tm'), ad = '';
if (length(TM)) {
ad = '\t<service>\n\t\t<type>_adisk._tcp</type>\n\t\t<port>9</port>\n\t\t<txt-record>sys=waMa=0,adVF=0x100</txt-record>\n';
for (let j = 0; j < length(TM); j++) ad += '\t\t<txt-record>dk' + j + '=adVN=' + replace(replace(replace(TM[j].name, '&', '&amp;'), '<', '&lt;'), '>', '&gt;') + ',adVF=0x82</txt-record>\n';
ad += '\t</service>\n';
}
if (dk && b) {
let t = '#!/bin/sh /etc/rc.common\n# wf-nas: Individuazione Rete del NAS (wsdd2 con il nome del NAS)\nSTART=99\nUSE_PROCD=1\nstart_service() {\n\tprocd_open_instance\n' +
'\tprocd_set_param command ' + b + (length(i) ? ' -i ' + i : '') + ' -N ' + q(nm) + ' -G ' + q(discgroup(N)) + '\n\tprocd_set_param respawn\n\tprocd_close_instance\n}\n';
if (readfile(R + DISCINIT) != t) { writefile(R + DISCINIT, t); sh('chmod 755 ' + q(R + DISCINIT)); }
}
if (dk && has('/etc/init.d/avahi-daemon')) {
let x = '<?xml version="1.0" standalone="no"?>\n<!DOCTYPE service-group SYSTEM "avahi-service.dtd">\n<!-- wf-nas: Individuazione Rete del NAS -->\n<service-group>\n' +
'\t<name replace-wildcards="no">' + nm + '</name>\n\t<service>\n\t\t<type>_smb._tcp</type>\n\t\t<port>445</port>\n\t</service>\n' +
'\t<service>\n\t\t<type>_device-info._tcp</type>\n\t\t<port>0</port>\n\t\t<txt-record>model=RackMac</txt-record>\n\t</service>\n' + ad + '</service-group>\n';
if (readfile(R + AVSVC) != x) { mkd(R + '/etc/avahi/services'); writefile(R + AVSVC, x); }
if (((stat(R + AVSVC)?.mode ?? 420) & 511) != 420) {
let f = null;
try { f = require('fs').chmod; } catch (e) { f = null; }
if (type(f) == 'function') f(R + AVSVC, 420); else sh('chmod 644 ' + q(R + AVSVC) + ' 2>/dev/null');
}
}
else unlink(R + AVSVC);
}
function b64hex(s) {
let A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', b = 0, n = 0, h = '';
for (let i = 0; i < length(s); i++) {
let v = index(A, substr(s, i, 1));
if (v < 0) break;
b = ((b << 6) | v) & 0xffffff; n += 6;
if (n >= 8) { n -= 8; h += sprintf('%02x', (b >> n) & 255); }
}
return h;
}
function sha1of(f) {
let D = null, h = null;
try { D = require('digest'); } catch (e) { D = null; }
try { h = D?.sha1_file ? D.sha1_file(f) : null; } catch (e) { h = null; }
if (type(h) == 'string' && match(h, /^[0-9a-f]{40}$/)) return h;
h = split(trim(sh((getenv('WF_SHA1SUM') ?? 'sha1sum') + ' ' + q(f) + ' 2>/dev/null')), ' ')[0] ?? '';
return match(h, /^[0-9a-f]{40}$/) ? h : '';
}
function pkgconf(p) {
let f = R + p, s = stat(f);
if (s?.type != 'file') return false;
let rel = substr(p, 1), i = rindex(rel, '/'), d = substr(rel, 0, i), b = substr(rel, i + 1);
let A = readfile(R + '/lib/apk/db/installed');
if (A != null) {
let cd = null, cr = false;
for (let l in split(A, '\n')) {
let c = substr(l, 0, 2);
if (c == 'F:') { cd = substr(l, 2); cr = false; }
else if (c == 'R:') cr = cd == d && substr(l, 2) == b;
else if (c == 'Z:' && cr) {
let h = sha1of(f);
if (length(h)) return substr(l, 0, 4) != 'Z:Q1' || b64hex(substr(l, 4)) != h;
if (!has('/sbin/apk') && !has('/usr/bin/apk') && !length(sh('command -v apk 2>/dev/null'))) return false;
for (let x in split(sh('apk audit --system ' + q(p) + ' 2>/dev/null'), '\n'))
if (match(x, /^[A-Z]+ /) && trim(substr(x, index(x, ' ') + 1)) == rel) return true;
return false;
}
}
return true;
}
for (let l in split(readfile(R + '/usr/lib/opkg/status') ?? '', '\n')) {
let m = match(l, /^[ \t]+([^ \t]+)[ \t]+([0-9a-f]{32})$/);
if (m && m[1] == p) return split(trim(sh('md5sum ' + q(f) + ' 2>/dev/null')), ' ')[0] != m[2];
}
return true;
}
function uon(c, t) { for (let k, s in cfg(c)) if (s['.type'] == t && s.enabled == '1') return true; return false; }
function smbown(conf) {
let t = conf == 'samba4' ? 'sambashare' : 'share';
for (let k, s in cfg(conf)) if (s['.type'] == t && !match(k, /^wf_/) && !match(k, /^wfcloud_/)) return true;
let f = conf == 'samba4' ? '/etc/samba/smb.conf' : '/etc/ksmbd/ksmbd.conf', s = lstat(R + f);
return s?.type == 'file' && index(split(readfile(R + f) ?? '', '\n'), MARK) < 0;
}
function spare(N) {
let on = N.on === true, e = engine(N), o2 = e == 'samba4' ? 'ksmbd' : 'samba4', ours = type(N.ours) == 'array' ? N.ours : [];
let C = { lighttpd: () => pkgconf('/etc/lighttpd/lighttpd.conf'), aria2: () => uon('aria2', 'aria2'), vsftpd: () => pkgconf('/etc/vsftpd.conf') };
if (on) { C[o2] = () => smbown(o2); if (N.media?.on !== true) C.minidlna = () => uon('minidlna', 'minidlna'); }
if (on && discwant(N) && wsddbin()) C.wsdd2 = () => false;
let P = null, off = [], mine = [], W = type(N.spw) == 'object' ? N.spw : {}, W2 = {}, now = time(), du = false;
for (let n, own in C) {
if (index(ours, n) >= 0 || !has('/etc/init.d/' + n)) continue;
if (!rcon(n)) { P = P ?? procrun(); if (!P[n]) continue; }
if (!own()) { push(off, n); continue; }
push(mine, n);
if (n == o2) du = true;
W2[n] = W[n] ?? 0;
if (W2[n] && (n != o2 || now - W2[n] < 86400)) continue;
W2[n] = now;
if (n == o2) evnas('nas_spare', '⚠️ NAS ¦ Due server delle cartelle di rete ¦ ' + o2 + ' ha cartelle tue: non lo tocco ¦ Le scelte dell\'app possono non valere: spegni ' + o2 + ' o togli le sue cartelle',
'⚠️ NAS ¦ Two network folder servers ¦ ' + o2 + ' has your folders: left alone ¦ App choices may not apply: turn ' + o2 + ' off or remove its folders');
else evnas('nas_spare', '⚠️ NAS ¦ ' + L(SPARE[n][0], SPARE[n][1]) + ' acceso ¦ Con impostazioni tue: non lo tocco',
'⚠️ NAS ¦ ' + L(SPARE[n][0], SPARE[n][1]) + ' on ¦ With your settings: left alone');
}
if (du) writefile(TMP + '/smb2.user', '' + now); else unlink(TMP + '/smb2.user');
let ch = sprintf('%J', W2) != sprintf('%J', W);
if (ch) { if (length(W2)) N.spw = W2; else delete N.spw; }
if (length(off)) {
let two = index(off, o2) >= 0, nm = join(', ', map(filter(off, (n) => n != o2), (n) => L(SPARE[n][0], SPARE[n][1])));
if (two) evnas('nas_spare', '🔧 NAS ¦ Due server delle cartelle di rete ¦ ' + o2 + ' spento: resta ' + e + ' ¦ Valgono di nuovo le scelte dell\'app',
'🔧 NAS ¦ Two network folder servers ¦ ' + o2 + ' off: ' + e + ' stays ¦ App choices apply again');
if (length(nm)) evnas('nas_spare', '🔧 NAS ¦ ' + nm + ' ¦ Spento e tolto dall\'avvio ¦ Il NAS usa il suo', '🔧 NAS ¦ ' + nm + ' ¦ Stopped and removed from startup ¦ The NAS uses its own');
}
return { off: off, mine: mine, ch: ch, two: index(off, o2) >= 0 };
}
function sparefix() {
begin();
if (!stat(NJ)) return { off: [] };
let N = nget(), x = spare(N), e = engine(N), S = map(x.off, (n) => n + ':off');
if (x.two && index(N.ours ?? [], e) >= 0) push(S, e + ':on');
if (N.on === true) { let o = smbold(e == 'samba4' ? 'samba4' : 'ksmbd'); if (length(o)) sh(o + 'true'); }
if (length(S)) sh('sh ' + q(SH) + ' svc ' + join(' ', S) + ' >/dev/null 2>&1');
if (x.ch) nput(N);
return { off: x.off, mine: x.mine };
}
let SQN = 0;
function svcq(S, fw) {
let c = null, d = TMP + '/svcq.d';
try { c = clock(true); } catch (e) { c = null; }
if (type(c) != 'array') c = [ time(), 0 ];
mkdir(TMP); mkdir(d);
let f = d + '/' + sprintf('%010d%09d.%s.%d', c[0], c[1], PID, SQN++);
writefile(f + '.t', join('\n', [ ...S, ...(fw ? [ 'fw' ] : []) ]) + '\n');
rename(f + '.t', f);
detach('sh ' + q(SH) + ' svcrun');
}
function enginechg(N) { let e = engine(N); return smbwant(N) && has('/etc/init.d/' + e) && index(type(N.ours) == 'array' ? N.ours : [], e) < 0; }
function apply(N, parts) {
let D = disks(), c = '', S = [], tp = null, dh = null, fp = null, gfp = null;
if (parts.smb) { let x = smbcmd(N, D); c += x.c; tp = x.tpl; dh = x.dfs; fp = x.fp; gfp = x.gfp; }
c += fwcmd(N);
S = map(spare(N).off, (n) => n + ':off');
let nf = N.adv.nfs != null;
delete N.adv.nfs;
let S2 = [];
for (let x in [ ...svcs(N), ...discsvcs(N) ]) if (x[1]) push(S2, x[0] + ':on'); else if (index(N.ours ?? [], x[0]) >= 0) push(S, x[0] + ':off');
push(S, ...S2);
let o4 = N.ours ?? [], pe = index(o4, 'samba4') >= 0 ? 'samba4' : (index(o4, 'ksmbd') >= 0 ? 'ksmbd' : null), ne = engine(N);
let ech = parts.smb && smbwant(N) && pe != null && pe != ne && index(S, ne + ':on') >= 0;
N.ours = uniq([ ...filter(N.ours ?? [], (s) => index(S, s + ':off') < 0), ...map(filter(S, (s) => match(s, /:on$/)), (s) => replace(s, /:on$/, '')) ]);
if (!nput(N)) return false;
if (ech) {
let nm = join(', ', uniq(map(filter(sharesAll(N, D, ne), (s) => s.kind != 'cam'), (s) => s.name)));
evnas('nas_engine', '🔧 NAS ¦ Cartelle In Rete con ' + ne + ' ¦ Nomi delle cartelle: ' + nm, '🔧 NAS ¦ Network Folders on ' + ne + ' ¦ Folder names: ' + nm);
}
if (index(S, ne + ':on') >= 0) {
let mf = TMP + '/smb.mode', gf = TMP + '/smb.gfp', om = trim(readfile(mf) ?? ''), rl = gfp != null && readfile(gf) == gfp && !ech && index(o4, ne) >= 0 && om != 'restart';
let kp = !ech && index(o4, ne) >= 0 && (gfp == null ? !parts.smb : (fp != null && readfile(SMBFP) == fp && readfile(gf) == gfp)) && (om == '' || om == 'keep');
writefile(mf, kp ? 'keep\n' : (rl ? 'reload\n' : 'restart\n'));
if (gfp != null && readfile(gf) != gfp) { writefile(gf + '.t', gfp); rename(gf + '.t', gf); }
}
if (tp) tplset(tp[0], tp[1], tp[2], tp[3]);
if (parts.dav) davwrite(N, D);
if (nf || parts.smb) nfsdrop();
discwrite(N, D);
sh(c + 'chmod 755 ' + q(R + '/etc/init.d/wf-nasdav') + ' 2>/dev/null; true');
if (fp != null && readfile(SMBFP) != fp) { writefile(SMBFP + '.t', fp); rename(SMBFP + '.t', SMBFP); }
if (dh != null) dfslinks(N, D, dh, davlink(N, D));
if (parts.smb) smbulinks(N, D);
if (parts.smb || parts.dav) writefile(TMP + '/full.fp', fullfp(N));
svcq(S, true);
return true;
}
function oursset(N, s, on) { let o = type(N.ours) == 'array' ? N.ours : []; N.ours = on ? uniq([ ...o, s ]) : filter(o, (x) => x != s); }
const DLDB = '/tmp/wf-dlnadb';
const MLT = { video: 'V', music: 'A', photo: 'P' };
function mlib(N) {
let id = N.main?.id, r = [];
if (!length(id ?? '') || !UCFG.udir) return r;
for (let t in keys(MLT)) { let p = UCFG.udir('shared', 'media', t, N); if (length(p ?? '')) push(r, id + ':/' + p); }
return r;
}
function mltypes(N) {
let id = N.main?.id, r = {};
if (!length(id ?? '') || !UCFG.udir) return r;
for (let t, v in MLT) { let p = UCFG.udir('shared', 'media', t, N); if (length(p ?? '')) r[id + ':/' + p] = v; }
return r;
}
function mpriv(N, x) {
let U = UCFG.UDIR ?? {}, r = lc(U.root ?? 'Utenti'), s = split(lc(x.path), '/');
return x.disk == N.main?.id && length(s) > 1 && s[1] == r && (length(s) == 2 || s[2] != lc(U.shared ?? 'Cartella Condivisa'));
}
function dbwant(N, D) {
let d0 = dpsplit(mlib(N)[0] ?? ''), dk = d0 ? diskof(D, d0.disk) : null;
return dk && !rod(dk) ? dk.mnt + '/.wf-minidlna' : null;
}
function dblink(N, D) {
let w = dbwant(N, D), l = lstat(DLDB), cur = l?.type == 'link' ? readlink(DLDB) : null;
if (w ? cur == w : (l?.type == 'directory')) return false;
mkdir(TMP);
if (l?.type == 'link' || l?.type == 'file') unlink(DLDB); else if (l) sh('rm -rf ' + q(DLDB));
if (w) {
mkd(w);
let C = cfg('minidlna'), k = first(C, 'minidlna'), u = k ? C[k].user : null;
if (u && match('' + u, /^[a-z_][a-z0-9_-]{0,31}$/)) sh('chown ' + q(u) + ' ' + q(w) + ' 2>/dev/null');
if (!symlink(w, DLDB)) mkd(DLDB);
}
else mkd(DLDB);
let od = TMP + '/dlnadb', ol = lstat(od);
if (ol?.type == 'link') unlink(od); else if (ol?.type == 'directory') sh('rm -rf ' + q(od));
return true;
}
function dbflash(old) {
old = '' + (old ?? '');
if (length(R) && substr(old, 0, length(R)) == R) old = substr(old, length(R));
let m = match(old, /^(\/mnt\/[^\/]+)\/\.wf-minidlna$/), b = R + (m ? m[1] : '');
if (!m) return;
for (let l in split(readfile(R + '/proc/mounts') ?? '', '\n')) {
let p = split(l, ' '), x = length(p) > 1 ? unoct(p[1]) : '';
if (x == b || substr(x, 0, length(b) + 1) == b + '/') return;
}
if (lstat(R + old)?.type == 'directory') sh('rm -rf ' + q(R + old));
rmdir(b);
}
function dlnacmd(N, D) {
let m = N.media, dirs = mlib(N), on = m.on === true;
m.dirs = dirs; m.types = mltypes(N);
let C = cfg('minidlna'), k = first(C, 'minidlna') ?? 'config', c = C[k] ? '' : 'uci -q set minidlna.config=minidlna; ';
saveorig(N, 'minidlna', k, [ 'enabled', 'friendly_name', 'inotify', 'port', 'db_dir', 'log_dir', 'interface', 'media_dir' ], C, !C[k]);
let ty = type(m.types) == 'object' ? m.types : {};
let abs = filter(map(dirs, (s) => { let x = dpsplit(s), p = x ? absof(D, x.disk, x.path) : null; return p ? (match(ty[s] ?? '', /^[VAP]$/) ? ty[s] + ',' + p : p) : null; }), length), db = '';
let Zs = zones(), hd = homedev(Zs), id = Zs.iot && N.adv?.nets?.iot === true ? zonedev(Zs, Zs.iot) : '';
if (length(id) && id != hd) hd = length(hd) ? hd + ',' + id : id;
dblink(N, D); db = DLDB;
let lo = C[k]?.log_dir, lx = lo != null && (lo == DLDB || lo == TMP + '/dlnadb') ? 'uci -q delete ' + q('minidlna.' + k + '.log_dir') + '; ' : '';
return c + uset('minidlna', k, 'enabled', on ? '1' : '0') + uset('minidlna', k, 'friendly_name', m.name || 'NAS') + uset('minidlna', k, 'inotify', '1') +
uset('minidlna', k, 'port', '8200') + (length(db) ? uset('minidlna', k, 'db_dir', db) : '') + lx +
(length(hd) ? uset('minidlna', k, 'interface', hd) : '') + ulist('minidlna', k, 'media_dir', abs) + 'uci -q commit minidlna; ';
}

const DISC = [ 'wsdd2', 'avahi-daemon' ];
function pcomm() {
let C = [];
for (let p in lsdir(R + '/proc') ?? []) if (match(p, /^[0-9]+$/)) push(C, trim(readfile(R + '/proc/' + p + '/comm') ?? ''));
return C;
}
function discon(P) {
for (let c in P ?? pcomm()) if (index(DISC, c) >= 0) return true;
return false;
}
const LEDS = SYS + '/class/leds';
function ledtrg(n) {
let t = readfile(LEDS + '/' + n + '/trigger') ?? '', m = match(t, /\[([^\]]+)\]/);
return { cur: m ? m[1] : 'none', all: split(trim(replace(t, /[][]/g, ' ')), /[ \t\n]+/) };
}
function ledcur(n) {
for (let l in split(readfile('/tmp/wf-leds.save') ?? '', '\n')) { let x = split(l, '|'); if (x[0] == n && length(x) >= 2) return length(x[1]) ? x[1] : 'none'; }
return ledtrg(n).cur;
}
function ledsec(n) { return 'wf_led_' + replace(n, /[^A-Za-z0-9_]/g, '_'); }
const LEDACT = /^(usbport|usb-host|usbdev|usb-gadget|disk-activity|disk-read|disk-write|ata[0-9]*)$/;
function ledpick() {
let SY = cfg('system'), best = null, bs = 0;
for (let n in sort(lsdir(LEDS) ?? [])) {
if (!match(n, /^[A-Za-z0-9:_.-]{1,64}$/)) continue;
let t = SY[ledsec(n)]?.wf_prev ?? ledcur(n), s = match(t, LEDACT) ? 3 : (match(lc(replace(n, /^.*:/, '')), /(usb|sata|hdd|disk|storage)/) ? 2 : 0);
if (s > bs) { best = n; bs = s; }
}
return best;
}
function ledget(n) { return cfg('system')[ledsec(n)] ? false : ledcur(n) != 'none'; }
function ledset(n, on) {
let sec = ledsec(n), d = LEDS + '/' + n, SY = cfg('system'), T = ledtrg(n);
if (!on) {
sh('uci -q set ' + q('system.' + sec + '=led') + '; ' + uset('system', sec, 'sysfs', n) + uset('system', sec, 'trigger', 'none') +
uset('system', sec, 'default', '0') + uset('system', sec, 'wf_prev', ledcur(n)) + 'uci -q commit system');
writefile(d + '/trigger', 'none');
writefile(d + '/brightness', '0');
return null;
}
let pv = SY[sec]?.wf_prev, tr = pv && pv != 'none' ? pv : (T.cur != 'none' ? T.cur : (index(T.all, 'usbport') >= 0 ? 'usbport' : (index(T.all, 'disk-activity') >= 0 ? 'disk-activity' : null)));
if (!tr) return err('led', 'Questa spia non sa seguire il disco', 'This light cannot follow the drive');
let own = false;
for (let k, o in SY) if (o['.type'] == 'led' && o.sysfs == n && k != sec) own = true;
if (SY[sec]) sh('uci -q delete ' + q('system.' + sec) + '; uci -q commit system');
let NS = readfile('/tmp/wf-leds.save');
if (NS != null) {
let L = [], f = false;
for (let l in split(NS, '\n')) {
if (!length(l)) continue;
let x = split(l, '|');
if (x[0] == n) { l = n + '|' + tr + '|' + (x[2] ?? '0'); f = true; }
push(L, l);
}
if (f) { let t = '/tmp/wf-leds.save.' + PID + '.t'; writefile(t, join('\n', L) + '\n'); rename(t, '/tmp/wf-leds.save'); return null; }
}
if (T.cur != tr) writefile(d + '/trigger', tr);
if (tr == 'usbport' && !own) for (let p in lsdir(d + '/ports') ?? []) writefile(d + '/ports/' + p, '1');
if (own && has('/etc/init.d/led')) detach(q(R + '/etc/init.d/led') + ' restart');
return null;
}
const MOUNTC = getenv('WF_MOUNT') ?? 'mount';
function noatw(D) { return filter(D, (d) => !rod(d) && !match(d.fs ?? '', /^fuse/)); }
function noatget(A, D) {
let W = noatw(D);
if (!length(W)) return A.noatime === true;
for (let d in W) if (index(split(d.opts ?? '', ','), 'noatime') < 0) return false;
return true;
}
function noatset(D, on) {
let c = '';
for (let d in noatw(D)) c += MOUNTC + ' -o remount,' + (on ? 'noatime' : 'relatime') + ' ' + q(d.mnt) + ' >/dev/null 2>&1; ';
if (length(c)) detach(c);
}
function advx(N, D) {
let A = N.adv, n = ledpick();
if (n && type(A.led) == 'bool' && A.led != ledget(n)) { let e = ledset(n, A.led); if (e) return e; }
if (type(A.noatime) == 'bool' && A.noatime != noatget(A, D)) noatset(D, A.noatime);
return null;
}

const PARTS = { shares: 'shares', remote: 'remote', adv: 'adv', media: 'media' };
function pendget() { let p = rjs(PEND); if (!p) return null; let l = p.until - time(); return { pend: true, left: l < 0 ? 0 : l, secs: p.secs, what: p.what }; }
function pendarm(old, what, secs) {
secs = int(+(secs ?? 60)); if (secs < 30) secs = 30; if (secs > 300) secs = 300;
let p = rjs(PEND);
if (p?.what == what && p.old) old = p.old;
wjs(PEND, { old: old, what: what, until: time() + secs, secs: secs });
detach('sh ' + q(SH) + ' back ' + secs);
return { pend: true, left: secs, secs: secs };
}
function pendact(a) {
if (a == 'confirm') { let p = rjs(PEND); unlink(PEND); return { ok: true, confirmed: !!p }; }
if (a == 'back') {
let p = rjs(PEND);
unlink(PEND);
if (!p?.old) return { ok: true, back: false };
let N = nget(), O = p.old, k = PARTS[p.what];
if (!k) return { ok: true, back: false };
N[k] = type(O[k]) == type(N[k]) ? O[k] : N[k];
let dc = null;
if (k == 'media') { oursset(N, 'minidlna', N.media.on === true); dc = dlnacmd(N, disks()); }
if (k == 'adv') advx(N, disks());
if (!apply(N, { smb: true, dav: true })) { wjs(PEND, p); return busy(); }
if (dc) sh(dc + 'true');
sh('sh ' + q(R + '/usr/share/wrtfreedom/event.sh') + ' cron nas_back nas ' + q(L('⚠️ NAS ¦ Nessuna conferma entro ' + p.secs + ' s ¦ Rimesso com\'era', '⚠️ NAS ¦ No confirmation within ' + p.secs + ' s ¦ Restored')) + ' >/dev/null 2>&1 &');
return { ok: true, back: true };
}
return null;
}
function pendbusy(what) { let p = pendget(); return p && p.what != what ? err('pend', 'Un\'altra modifica aspetta la conferma', 'Another change is waiting for confirmation') : null; }
function clone(o) { return json(sprintf('%J', o)); }

function follow() {
begin();
let N = nget(), did = [];
if (N.on !== true) return { did: did };
let D = disks(), miss = (want, have) => length(filter(want, (p) => index(have, p) < 0)) > 0;
let e4 = engine(N) == 'samba4';
let S = filter(map(sharesAll(N, D, e4 ? 'samba4' : 'ksmbd'), (s) => { let p = absof(D, s.disk, s.path);
return { p: p, sp: p && e4 && (s.kind == 'user' || s.kind == 'admin') ? DRIVEP : p, nodav: s.tm === true || s.kind == 'cam' }; }), (x) => x.p != null);
let smb = false, dav = false;
if (N.smb_off !== true) {
let C = cfg(engine(N) == 'samba4' ? 'samba4' : 'ksmbd'), have = [], ours = [], pm = false;
for (let k, o in C) if (match(k, /^wf_/) && o.path) { push(have, o.path); push(ours, o.path); }
for (let l in split(readfile(R + (engine(N) == 'samba4' ? '/etc/samba/smb.conf.template' : '/etc/ksmbd/ksmbd.conf.template')) ?? '', '\n')) {
let m = match(l, /^\tpath = (.+)$/);
if (m) { push(have, m[1]); if (pm) push(ours, m[1]); }
pm = l == MARK;
}
let want = uniq(map(S, (x) => x.sp));
smb = miss(want, have) || miss(ours, want);		/* 16/11: link DFS della Cartella Condivisa acceso o spento (samba4 con o senza host) diverso dal modello scritto */
if (engine(N) == 'samba4' && (length(dfsof(N)) > 0) != dfstpl()) smb = true;
if (enginechg(N)) smb = true;
if (!smb && !smbfpok(N, D)) smb = true;
}
if (N.remote.webdav === true) {
let have = map(filter(split(readfile(ETC + '/nas-dav.links') ?? '', '\n'), length), (l) => split(l, '\t')[1] ?? '');
dav = miss(map(filter(S, (x) => !x.nodav), (x) => x.p), have) || cldavchg();
if (!dav && davchg(N, D)) dav = true;
}
if (fullfp(N) != (readfile(TMP + '/full.fp') ?? '')) { smb = smb || N.smb_off !== true; dav = dav || N.remote.webdav === true; }
if (smb || dav) {
if (!apply(N, { smb: smb, dav: dav })) return { did: did, busy: true };
push(did, ...filter([ smb ? 'smb' : null, dav ? 'dav' : null ], length));
}
if (N.media.on === true) {
let C = cfg('minidlna'), k = first(C, 'minidlna'), have = arr(k ? C[k].media_dir : []), ty = mltypes(N);
let want = filter(map(mlib(N), (s) => { let x = dpsplit(s), p = x ? absof(D, x.disk, x.path) : null; return p ? (ty[s] ? ty[s] + ',' + p : p) : null; }), length);
let old = k ? C[k].db_dir : null, w = dbwant(N, D), l = lstat(DLDB);
let dbok = old == DLDB && (w ? l?.type == 'link' && readlink(DLDB) == w : l?.type == 'directory');
if (miss(want, have) || miss(have, want) || !dbok) {
let dc = dlnacmd(N, D);
if (!nput(N)) return { did: did, busy: true };
sh(dc + 'true');
dbflash(old);
svcq([ 'minidlna:on' ], false);
push(did, 'dlna');
}
}
if (!smb) dfslinks(N, D, dfsnow(N), davlink(N, D));
if (!smb) smbulinks(N, D);
return { did: did };
}

function dbfile() { let C = cfg('minidlna'), k = first(C, 'minidlna'); return ((k ? C[k].db_dir : null) || '/var/run/minidlna') + '/files.db'; }
function relof(D, p) { for (let d in D) if (index(p, d.mnt + '/') == 0) return { disk: d.id, path: substr(p, length(d.mnt)) }; return null; }
function dbsleep() {
let D = disks(), r = relof(D, dbfile()), d = r ? diskof(D, r.disk) : null;
if (!d || match(d.dev, /^md/)) return false;
let c = rjs(NJ)?.sleep ?? {}, m = type(c.mins) == 'int' && c.mins >= 0 ? c.mins : 15;
if (m <= 0 || c.keep === true) return false;
let b = match(d.dev, /^(nvme[0-9]+n[0-9]+|mmcblk[0-9]+)p[0-9]+$/)?.[1] ?? replace(d.dev, /[0-9]+$/, '');
let x = split(trim(readfile(SYS + '/class/block/' + b + '/stat') ?? ''), /[ \t]+/);
if (length(x) < 7) return false;
let rb = +x[2] * 512, wb = +x[6] * 512;
for (let p in [ rjs(TMP + '/scan/' + d.id + '.io'), (rjs(TMP + '/io.json') ?? {})[b] ])
if (type(p) == 'object' && p.r == rb && p.w == wb && +(p.chg ?? 0) > 0) return time() - p.chg >= m * 60;
return false;
}
function sqe(s) { return "'" + replace('' + s, "'", "''") + "'"; }
function sql(s) {
let f = dbfile();
if (!stat(f)) return [];
let o = trim(sh('sqlite3 -readonly -json ' + q(f) + ' ' + q(s) + ' 2>/dev/null'));
if (!length(o)) return [];
try { let j = json(o); return type(j) == 'array' ? j : null; } catch (e) { return null; }
}
function dsec(s) { let m = match('' + (s ?? ''), /^([0-9]+):([0-9]{2}):([0-9]{2})/); return m ? +m[1] * 3600 + +m[2] * 60 + +m[3] : 0; }
function hms(s) { s = int(s); return sprintf('%d:%02d:%02d', int(s / 3600), int(s / 60) % 60, s % 60); }
function bname(p) { return replace('' + p, /^.*\//, ''); }
const TIPIUC = getenv('WF_NASTIPIUC') ?? replace(sourcepath() ?? '', /[^\/]*$/, '') + 'nastipi.uc';
let TIPI = null;
function tipi() { if (TIPI == null) { try { TIPI = loadfile(TIPIUC)() ?? {}; } catch (e) { TIPI = {}; } } return TIPI; }
function mclass(n) {
tipi();
let e = match(lc(n), /\.([a-z0-9]+)$/)?.[1];
return !e ? null : index(TIPI.vid ?? [], e) >= 0 ? 'V' : (index(TIPI.mus ?? [], e) >= 0 ? 'A' : (index(TIPI.img ?? [], e) >= 0 ? 'P' : null));
}
function resfile(N, D) {
let x = dpsplit(mlib(N)[0] ?? ''), d = x ? diskof(D, x.disk) : null;
return d && !rod(d) ? d.mnt + '/.wf-minidlna/resume.json' : TMP + '/resume.json';
}
function resget(f) {
let r = rjs(f);
if (type(r) != 'object') r = {};
if (type(r.list) != 'array') r.list = [];
if (type(r.seen) != 'object') r.seen = {};
return r;
}
function resput(f, r) { mkdir(replace(f, /\/[^\/]+$/, '')); wjs(f, r); }
function clres(d) {
let id = match('' + d, /^cl:(a[0-9]{1,3})$/)?.[1];
if (!id) return null;
for (let a in (rjs(ETC + '/cloud.json')?.accounts ?? [])) if (a?.id == id) return id;
return false;
}
const SEENP = 0.9;
function resset(N, D, disk, path, pos, dur, where) {
if (N.media.remember === false) return false;
let f = resfile(N, D), r = resget(f), k = disk + ':' + path;
r.list = filter(r.list, (x) => x.disk + ':' + x.path != k);
if (dur > 0 && pos >= dur * SEENP) {
r.seen[k] = time();
let K = sort(keys(r.seen), (a, b) => r.seen[a] - r.seen[b]);
while (length(K) > 3000) delete r.seen[shift(K)];
}
else {
delete r.seen[k];
unshift(r.list, { name: bname(path), disk: disk, path: path, pos: pos, dur: dur, where: where, t: time() });
r.list = slice(r.list, 0, 100);
}
resput(f, r);
return true;
}
function arpmap() {
let A = {};
for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) { let p = split(l, /[ \t]+/); if (length(p) >= 4 && macok(lc(p[3])) && p[3] != '00:00:00:00:00:00') A[p[0]] = lc(p[3]); }
return A;
}
function ipmac(ip, LS, A) { for (let m, x in LS) if (x.ip == ip) return m; return A[ip] ?? ''; }
function pstat(p) {
let s = readfile(R + '/proc/' + p + '/stat') ?? '', i = rindex(s, ')');
if (i < 0) return null;
let x = split(trim(substr(s, i + 1)), /[ \t]+/);
return length(x) >= 2 ? { st: x[0], pp: x[1] } : null;
}
function hex4(h) { return join('.', [ hex(substr(h, 6, 2)), hex(substr(h, 4, 2)), hex(substr(h, 2, 2)), hex(substr(h, 0, 2)) ]); }
function tcp8200() {
let S = {};
for (let f in [ 'tcp', 'tcp6' ]) for (let l in split(readfile(R + '/proc/net/' + f) ?? '', '\n')) {
let x = split(trim(l), /[ \t]+/);
if (length(x) < 10 || x[3] != '01' || !match(x[1], /:2008$/) || x[9] == '0') continue;
let h = split(x[2], ':')[0];
S[x[9]] = length(h) == 8 ? hex4(h) : (length(h) == 32 && uc(substr(h, 0, 24)) == '0000000000000000FFFF0000' ? hex4(substr(h, 24)) : '');
}
return S;
}
const SCANPID = R ? TMP + '/wf-dlnascan.pid' : '/var/run/wf-dlnascan.pid';
function scanlive() {
let a = time() - (stat(TMP + '/dlna.scan')?.mtime ?? 0);
if (a >= 10800) return false;
if (a < 30) return true;
let p = trim(readfile(TMP + '/dlnascan.sh.pid') ?? '');
return match(p, /^[0-9]+$/) != null && match(join(' ', split(readfile(R + '/proc/' + p + '/cmdline') ?? '', chr(0))), /dlna(scan|reindex)/) != null;
}
function playing(N, H, LS) {
if (time() - (stat(TMP + '/dlna.scan')?.mtime ?? 0) < 10800) return [];
let PR = {}, sc = trim(readfile(SCANPID) ?? '');
for (let p in (lsdir(R + '/proc') ?? [])) if (match(p, /^[0-9]+$/) && trim(readfile(R + '/proc/' + p + '/comm') ?? '') == 'minidlnad') { let s = pstat(p); if (s) PR[p] = s; }
let K = filter(keys(PR), (p) => PR[p].st != 'D' && PR[PR[p].pp] && !PR[PR[PR[p].pp].pp] && PR[p].pp != sc);
if (!length(K)) return [];
let S = tcp8200(), F = [], A = null;
for (let p in K) {
let fs = [], ip = null;
for (let fd in (lsdir(R + '/proc/' + p + '/fd') ?? [])) {
let t = readlink(R + '/proc/' + p + '/fd/' + fd);
if (!t) continue;
let so = match(t, /^socket:\[([0-9]+)\]$/);
if (so) { if (S[so[1]] != null && ip == null) ip = S[so[1]]; continue; }
let k = mclass(t);
if (!k || k == 'P') continue;
let m = match(readfile(R + '/proc/' + p + '/fdinfo/' + fd) ?? '', /pos:[ \t]*([0-9]+)/);
push(fs, { file: t, at: m ? +m[1] : 0 });
}
if (ip == null) continue;
for (let x in fs) push(F, { ...x, ip: ip });
}
if (!length(F)) return [];
A = arpmap();
let DU = {}, ok = {};
for (let x in F) ok[x.file] = 1;
if (has('/usr/bin/sqlite3') && !dbsleep()) for (let r in (sql('SELECT PATH p, DURATION d FROM DETAILS WHERE PATH IN (' + join(',', map(keys(ok), sqe)) + ')') ?? [])) DU[r.p] = dsec(r.d);
let seen = {}, out = [];
for (let x in F) {
if (seen[x.ip + '|' + x.file]) continue;
seen[x.ip + '|' + x.file] = 1;
let mac = length(x.ip) ? ipmac(x.ip, LS, A) : '', sz = stat(x.file)?.size ?? 0, du = DU[x.file] ?? 0;
push(out, { mac: mac, name: mac ? devname(mac, H, LS) : '', file: bname(x.file), pos: du && sz ? int(du * x.at / sz) : 0, dur: du });
}
return out;
}

const AVT = 'urn:schemas-upnp-org:service:AVTransport:1', RCS = 'urn:schemas-upnp-org:service:RenderingControl:1';
function xesc(s) { return replace(replace(replace(replace('' + s, '&', '&amp;'), '<', '&lt;'), '>', '&gt;'), '"', '&quot;'); }
function xun(s) { return replace(replace(replace(replace(replace('' + s, '&lt;', '<'), '&gt;', '>'), '&quot;', '"'), '&apos;', "'"), '&amp;', '&'); }
function xtag(x, t) { let m = match('' + x, regexp('<([A-Za-z0-9_]+:)?' + t + '( [^>]*)?>([^<]*)</')); return m ? xun(trim(m[3])) : ''; }
function sockmod() { try { return require('socket'); } catch (e) { return null; } }
function urlp(u) { let m = match('' + u, /^http:\/\/([0-9]{1,3}(\.[0-9]{1,3}){3})(:([0-9]{1,5}))?(\/[^ \r\n]*)?$/); return m ? { host: m[1], port: +(m[4] ?? 80), path: m[5] ?? '/' } : null; }
function hreq(u, meth, hdr, body, tmo) {
let S = sockmod(), U = urlp(u);
if (!S || !U) return null;
let c = null, r = '';
try { c = S.connect(U.host, '' + U.port, null, 3000); } catch (e) {}
if (!c) return null;
try {
c.send(meth + ' ' + U.path + ' HTTP/1.1\r\nHost: ' + U.host + ':' + U.port + '\r\n' + (hdr ?? '') + 'Content-Length: ' + length(body ?? '') +
'\r\nConnection: close\r\n\r\n' + (body ?? ''));
let end = time() + (tmo ?? 4);
while (time() <= end && length(r) < 262144) {
let p = S.poll(1000, [ c, S.POLLIN ]);
if (!length(p ?? [])) continue;
let d = c.recv(65536);
if (d == null || !length(d)) break;
r += d;
}
} catch (e) {}
try { c.close(); } catch (e) {}
let m = match(r, /^HTTP\/1\.[01] ([0-9]{3})/), i = index(r, '\r\n\r\n');
return m && +m[1] < 300 ? (i >= 0 ? substr(r, i + 4) : '') : null;
}
function soap(u, svc, act, args, tmo) {
let b = '<?xml version="1.0" encoding="utf-8"?>\n<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:' +
act + ' xmlns:u="' + svc + '">';
for (let k, v in args) b += '<' + k + '>' + xesc(v) + '</' + k + '>';
return hreq(u, 'POST', 'Content-Type: text/xml; charset="utf-8"\r\nSOAPACTION: "' + svc + '#' + act + '"\r\n', b + '</u:' + act + '></s:Body></s:Envelope>', tmo);
}
function tvidok(x) { return match('' + x, /^([0-9a-f]{2}:){5}[0-9a-f]{2}@[0-9a-z]{1,12}$/) != null; }
function tvmac(id) { return split('' + id, '@')[0]; }
function tvtag(udn, port) {
if (!length(udn)) return 'p' + port;
let h = 5381;
for (let i = 0; i < length(udn); i++) h = (h * 33 + ord(udn, i)) & 0xffffffff;
return sprintf('%08x', h);
}
function tvbase(id) { return TMP + '/tv-' + replace(replace('' + id, /:/g, ''), '@', '-'); }
function tvfile(id) { return tvbase(id) + '.json'; }
function tvres(id) { return tvbase(id) + '.res'; }
function tvload() {
let J = rjs(TMP + '/tv.json'), T = {};
if (type(J?.tvs) != 'object') return { t: 0, tvs: T };
let old = false;
for (let k, v in J.tvs) { if (tvidok(k) && type(v) == 'object') T[k] = v; else old = true; }
return { t: old ? 0 : +(J.t ?? 0), tvs: T };
}
function tvname(T, id, H, LS) {
let mc = tvmac(id), t = T[id] ?? {}, dn = devname(mc, H, LS), n = 0;
for (let k in keys(T)) if (tvmac(k) == mc) n++;
return n > 1 && length(t.name) ? (length(dn) ? dn + ' · ' + t.name : t.name) : (dn || t.name || '');
}
function tvfind() {
let S = sockmod(), s = null, L = {}, T = {};
if (!S) return null;
try { s = S.create(S.AF_INET, S.SOCK_DGRAM); } catch (e) {}
if (!s) return null;
let msg = 'M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\nMX: 2\r\nST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n';
try { for (let i = 0; i < 2; i++) s.send(msg, 0, { family: S.AF_INET, address: '239.255.255.250', port: 1900 }); } catch (e) {}
let end = time() + 3;
while (time() <= end && length(keys(L)) < 16) {
let p = null; try { p = S.poll(500, [ s, S.POLLIN ]); } catch (e) {}
if (!length(p ?? [])) continue;
let d = null; try { d = s.recv(4096); } catch (e) {}
let m = match(d ?? '', /[Ll][Oo][Cc][Aa][Tt][Ii][Oo][Nn]:[ \t]*([^\r\n]+)/);
if (m && urlp(trim(m[1]))) L[trim(m[1])] = 1;
}
try { s.close(); } catch (e) {}
let LS = leases(), A = arpmap();
for (let loc in keys(L)) {
let x = hreq(loc, 'GET', '', ''), U = urlp(loc);
if (x == null) continue;
let base = replace(xtag(x, 'URLBase') || ('http://' + U.host + ':' + U.port), /\/+$/, ''), sv = {};
for (let b in split(x, '<service>')) {
let t = xtag(b, 'serviceType'), c = xtag(b, 'controlURL');
if (length(c)) sv[t] = substr(c, 0, 7) == 'http://' ? c : base + (substr(c, 0, 1) == '/' ? '' : '/') + c;
}
let mac = ipmac(U.host, LS, A);
if (!macok(mac) || !sv[AVT]) continue;
T[mac + '@' + tvtag(xtag(x, 'UDN'), U.port)] = { mac: mac, ip: U.host, name: xtag(x, 'friendlyName'), brand: xtag(x, 'manufacturer'), model: xtag(x, 'modelName'), av: sv[AVT], rc: sv[RCS] ?? '' };
}
wjs(TMP + '/tv.json', { t: time(), tvs: T });
return T;
}
function pdec(s) { return replace('' + s, /%([0-9A-Fa-f]{2})/g, (m, h) => chr(hex(h))); }
const CLPORT = 7879;
function cllibs(N) {
let r = {};
if (!UCFG.udir) return r;
for (let t, v in MLT) { let p = UCFG.udir('shared', 'media', t, N); if (length(p ?? '')) r[bname(p)] = { k: v, p: '/' + p }; }
return r;
}
const CLMI = { mkv: 'video/x-matroska', avi: 'video/x-msvideo', mov: 'video/quicktime', webm: 'video/webm', ts: 'video/mp2t', m4v: 'video/mp4',
mp3: 'audio/mpeg', flac: 'audio/flac', m4a: 'audio/mp4', ogg: 'audio/ogg', opus: 'audio/ogg', wav: 'audio/wav', aac: 'audio/aac',
jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', heic: 'image/heic' };
function clmime(p) {
let c = mclass(p), e = match(lc(p), /\.([a-z0-9]+)$/)?.[1];
return !c ? null : (CLMI[e] ?? (c == 'V' ? 'video/mp4' : (c == 'A' ? 'audio/mpeg' : 'image/jpeg')));
}
function uenc(s) {
let o = '';
for (let i = 0; i < length(s); i++) { let c = substr(s, i, 1); o += match(c, /^[A-Za-z0-9._~\/-]$/) ? c : sprintf('%%%02X', ord(s, i)); }
return o;
}
function tvcl(N, uri) {
let m = match(uri, /^https?:\/\/[^\/:]+:([0-9]+)\/r\/([^?#]+)/), C = N.media?.cloud;
if (!m || +m[1] != CLPORT || C?.on !== true || C.mode != 'live' || !match('' + (C.acct ?? ''), /^a[0-9]{1,3}$/)) return null;
let rp = pdec(m[2]), i = index(rp, '/'), L = i > 0 ? cllibs(N)[substr(rp, 0, i)] : null, p = L ? relok(L.p + substr(rp, i)) : null;
return p ? { disk: 'cl:' + C.acct, path: p } : null;
}
function tvsrc(N, uri) {
let fp = null, m = match(uri, /\/MediaItems\/([0-9]+)\./);
if (m) { if (has('/usr/bin/sqlite3')) { let r = sql('SELECT PATH p FROM DETAILS WHERE ID = ' + int(m[1])); if (length(r ?? [])) fp = r[0].p; } }
else if ((m = match(uri, /^https?:\/\/[^\/]+\/(cgi-bin\/wf-nasx\/)?t\/([A-Za-z0-9_-]+)\//))) fp = rjs(TMP + '/x/st/' + m[2] + '.json')?.p;
else if ((m = match(uri, /^https?:\/\/[^\/:]+:([0-9]+)(\/[^?#]*)/)) && +m[1] == +(N.remote?.port ?? DAVPORT)) {
let p = pdec(m[2]);
for (let l in split(readfile(ETC + '/nas-dav.links') ?? '', '\n')) {
let x = split(l, '\t');
if (length(x) == 2 && length(x[0]) && index(p, '/' + x[0] + '/') == 0) { fp = x[1] + substr(p, length(x[0]) + 1); break; }
}
}
return type(fp) == 'string' && index(fp + '/', '/../') < 0 && stat(fp)?.type == 'file' ? fp : null;
}
function tvpoll1(TS, k) {
let T = TS[k];
if (!T?.av) return null;
let a = { InstanceID: '0' }, ti = soap(T.av, AVT, 'GetTransportInfo', a), pi = soap(T.av, AVT, 'GetPositionInfo', a);
let vo = length(T.rc) ? soap(T.rc, RCS, 'GetVolume', { InstanceID: '0', Channel: 'Master' }) : null;
if (ti == null && pi == null) { wjs(tvfile(k), { t: time(), state: 'off' }); return null; }
let N = nget(), st = xtag(ti, 'CurrentTransportState'), uri = xtag(pi, 'TrackURI'), fp = length(uri) ? tvsrc(N, uri) : null;
let cx = !fp && length(uri) ? tvcl(N, uri) : null, fk = fp ?? (cx ? cx.disk + ':' + cx.path : null);
let o = { t: time(), state: st == 'PLAYING' ? 'play' : (st == 'PAUSED_PLAYBACK' ? 'pause' : 'stop'), file: fp ? bname(fp) : (cx ? bname(cx.path) : ''), pos: dsec(xtag(pi, 'RelTime')),
dur: dsec(xtag(pi, 'TrackDuration')), vol: vo != null ? int(xtag(vo, 'CurrentVolume') || '0') : null };
let pv = rjs(tvfile(k)) ?? {}, ok = fk && o.state != 'stop' && o.dur > 0, dp = o.pos - +(pv.sp ?? 0);
if (ok && pv.sf == fk && dp < 30 && dp > -30 && (o.pos >= o.dur * SEENP) == (+(pv.sp ?? 0) >= o.dur * SEENP)) { o.sf = pv.sf; o.sp = pv.sp; ok = false; }
if (ok) {
let D = disks(), r = cx ?? relof(D, fp);
if (r && resset(N, D, r.disk, r.path, o.pos, o.dur, tvname(TS, k, dhcphosts(), leases()))) { o.sf = fk; o.sp = o.pos; }
}
wjs(tvfile(k), o);
return o;
}
function tvpoll(x) {
let TS = tvload().tvs, r = null;
x = lc('' + x);
for (let k in sort(keys(TS))) if (k == x || tvmac(k) == x) r = tvpoll1(TS, k) ?? r;
return r;
}
function tvdo(f) {
if (!match('' + f, /^tvq-[0-9a-z]{1,40}$/)) return null;
let J = rjs(TMP + '/' + f + '.json');
unlink(TMP + '/' + f + '.json');
if (type(J) != 'object' || !tvidok(J.id)) return null;
let TS = tvload().tvs, T = TS[J.id], a = { InstanceID: '0' }, ok = false;
if (!T?.av) return null;
if (J.act == 'play') {
let md = '<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">' +
'<item id="0" parentID="-1" restricted="1"><dc:title>' + xesc(J.title) + '</dc:title><upnp:class>object.item.' + (J.audio ? 'audioItem.musicTrack' : 'videoItem') +
'</upnp:class><res protocolInfo="http-get:*:' + xesc(J.mime) + ':*">' + xesc(J.url) + '</res></item></DIDL-Lite>';
soap(T.av, AVT, 'Stop', a);
ok = soap(T.av, AVT, 'SetAVTransportURI', { InstanceID: '0', CurrentURI: J.url, CurrentURIMetaData: md }) != null && soap(T.av, AVT, 'Play', { InstanceID: '0', Speed: '1' }) != null;
if (ok && J.pos > 0) { sh('sleep 3'); soap(T.av, AVT, 'Seek', { InstanceID: '0', Unit: 'REL_TIME', Target: hms(J.pos) }); }
if (ok) {
let N = nget();
if (type(N.media.tv) != 'object') N.media.tv = {};
if (type(N.media.tv[J.id]) != 'object') N.media.tv[J.id] = { ...(N.media.tv[tvmac(J.id)] ?? {}) };
if (!N.media.tv[J.id].perm) { N.media.tv[J.id].perm = time(); nput(N); }
}
}
else if (J.act == 'pause') ok = soap(T.av, AVT, 'Pause', a) != null;
else if (J.act == 'resume') ok = soap(T.av, AVT, 'Play', { InstanceID: '0', Speed: '1' }) != null;
else if (J.act == 'stop') ok = soap(T.av, AVT, 'Stop', a) != null;
else if (J.act == 'seek') ok = soap(T.av, AVT, 'Seek', { InstanceID: '0', Unit: 'REL_TIME', Target: hms(J.pos) }) != null;
else if (J.act == 'vol' && length(T.rc)) ok = soap(T.rc, RCS, 'SetVolume', { InstanceID: '0', Channel: 'Master', DesiredVolume: '' + J.vol }) != null;
wjs(tvres(J.id), { act: J.act, ok: ok, t: time() });
tvpoll1(TS, J.id);
return ok;
}

function expire() {
begin();
let N = nget(), now = time(), did = [], old = camold(N);
if (old && N.on === true && N.smb_off !== true) { if (apply(N, { smb: true, dav: N.remote.webdav === true })) push(did, 'allow'); }
else if (old) { if (nput(N)) push(did, 'allow'); }
else if (N.on === true && fullfp(N) != (readfile(TMP + '/full.fp') ?? '')) {
if (apply(N, { smb: true, dav: N.remote.webdav === true })) push(did, 'quota');
}
else if (N.on === true && N.remote?.webdav === true && cldavchg()) { if (apply(N, { smb: false, dav: true })) push(did, 'cloud-dav'); }
let I = rjs(TMP + '/invite.json');
if (type(I) == 'object') { let n = 0; for (let k, v in I) if ((v?.until ?? 0) <= now) { delete I[k]; n++; } if (n) wjs(TMP + '/invite.json', I); }
return { did: did };
}

let RCX = null;
function rcx() {
if (RCX == null) { try { RCX = stat(CLOUDUC) ? (loadfile(CLOUDUC)()?._rc ?? false) : false; } catch (e) { RCX = false; } }
return RCX || null;
}
const CLST = { off: [ 'Spento', 'Off' ], relink: [ 'Da Ricollegare', 'Reconnect' ], pause: [ 'In Pausa', 'Paused' ], wait: [ 'In Attesa', 'Waiting' ],
run: [ 'In Corso', 'Running' ], err: [ 'Non Riuscito', 'Failed' ], ok: [ 'Riuscito', 'Succeeded' ], never: [ 'Mai Fatto', 'Never Run' ] };
function hhmm(s) { return type(s) == 'string' && match(s, /^([01][0-9]|2[0-3]):[0-5][0-9]$/) != null; }
function clnet(n) {
if (type(n) != 'object' || !match('' + n.mode, /^(same|own|fixed)$/)) return null;
if (n.mode != 'own') return { mode: n.mode };
let gb = n.gb, all = n.all === true;
if ((type(gb) != 'int' && type(gb) != 'double') || !(gb == 0 || (gb >= 0.5 && gb <= 500))) return null;
if (!all && !(hhmm(n.from) && hhmm(n.to))) return null;
return { mode: 'own', gb: gb, all: all, from: type(n.from) == 'string' ? n.from : '', to: type(n.to) == 'string' ? n.to : '' };
}
function cljob() {
let J = null;
for (let f in (lsdir(CLJOBS) ?? [])) {
if (!match(f, /^[A-Za-z0-9_-]{1,48}\.json$/)) continue;
let o = rjs(CLJOBS + '/' + f);
if (type(o) == 'object' && o.kind == 'media' && (!J || +(o.t ?? 0) >= +(J.t ?? 0))) J = o;
}
return J;
}
function clout(m) {
let C = type(m.cloud) == 'object' ? m.cloud : {}, on = C.on === true, X = rcx();
let A = on && X && length(C.acct ?? '') ? X.acct('' + C.acct) : null, J = on && C.mode == 'pre' ? cljob() : null;
let last = +(C.last ?? 0), bytes = +(C.bytes ?? 0);
if (J?.state == 'ok' && +(J.t ?? 0) > last) { last = +J.t; bytes = +(J.bytes ?? 0); }
let st = !on ? 'off' : !A || A.state == 'relink' ? 'relink' : X.paused() ? 'pause' : J?.state == 'run' ? 'run' : J?.state == 'wait' ? 'wait' :
J?.state == 'err' ? 'err' : last ? 'ok' : 'never';
return { on: on, mode: C.mode ?? '', acct: C.acct ?? '', disk: C.disk ?? '', to: C.to ?? '', from: C.from ?? '',
to_h: C.to_h ?? '', net: type(C.net) == 'object' ? C.net : { mode: 'same' }, st: st, st_t: CLST[st][0], st_t_en: CLST[st][1],
last: last, bytes: bytes, warn: X ? X.tier() == 'A' : false };
}
function livesig(m) {
let C = type(m.cloud) == 'object' ? m.cloud : {};
return C.on === true && C.mode == 'live' ? sprintf('%J', [ C.acct ?? '', m.name ?? '' ]) : '';
}
function livereload(m, s0) { if (livesig(m) != s0 && has('/etc/init.d/wrtfreedom')) detach(q(R + '/etc/init.d/wrtfreedom') + ' reload'); }
function clset(m, c, NJ) {
let bad = (code) => err(code, 'Dal Cloud non valido', 'Invalid From The Cloud'), O = type(m.cloud) == 'object' ? m.cloud : {};
if (type(c) != 'object') return bad('cloud');
if (c.on === false) { m.cloud = { ...O, on: false }; delete m.cloud.path; return null; }
let X = rcx();
if (!X) return err('pkg', 'Serve installare Cloud in Software', 'Install Cloud in Software first');
let mo = '' + (c.mode ?? '');
if (mo != 'pre' && mo != 'live') return bad('mode');
let A = type(c.acct) == 'string' ? X.acct(c.acct) : null;
if (!A) return err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
let N = { on: true, mode: mo, acct: A.id, net: { mode: 'same' }, last: O.last ?? 0, bytes: O.bytes ?? 0 };
if (c.net != null) { N.net = clnet(c.net); if (!N.net) return err('net', 'Rete Da Usare non valida', 'Invalid Network To Use'); }
if (mo == 'pre') {
let mid = NJ.main?.id, dl = UCFG.udir ? UCFG.udir('admin', 'dl', null, NJ) : null, tp = length(dl ?? '') ? '/' + dl : null;
if (c.to != null) {
let x = type(c.to) == 'string' ? relok(c.to) : null;
if (x == null) return bad('to');
let ld = lc(x), lt = lc(tp ?? '');
if (mpriv(NJ, { disk: length('' + (c.disk ?? '')) ? '' + c.disk : mid, path: x }) && !(length(lt) && (ld == lt || substr(ld, 0, length(lt) + 1) == lt + '/')))
return err('private', 'Le cartelle delle persone non vanno sulla TV di tutti', 'People\'s folders never go on everyone\'s TV');
}
let d = diskof(disks(), '' + (mid ?? ''));
if (!d) return err('disk', 'Collega il Disco Principale', 'Connect the Main Disk');
if (rod(d)) return { ...err('ro', 'Disco in sola lettura', 'Disk is read-only'), ro: true };
if (tp == null) return bad('to');
if (!hhmm(c.from) || !hhmm(c.to_h)) return bad('from');
N.disk = d.id; N.to = tp; N.from = c.from; N.to_h = c.to_h;
}
else if (X.tier() == 'A' && c.ok_warn !== true)
return { ...err('warn', "In Diretta può scattare o rallentare internet: conferma l'avviso", 'Live can stutter or slow the internet: confirm the warning'), warn: true };
m.cloud = N;
return null;
}

const CLCAT = TMP + '/clcat.json', CLCATST = TMP + '/clcat.st.json', CLCATLK = TMP + '/clcat.lock';
const CDS = 'urn:schemas-upnp-org:service:ContentDirectory:1';
const CLDLST = '/tmp/wf-cloud/mnt/dlna.st';
const SELFUC = getenv('WF_NASVCUC') ?? sourcepath() ?? '/usr/share/wrtfreedom/nasvc.uc';
function memfree() { let m = match(readfile('/proc/meminfo') ?? '', /MemAvailable:[ \t]*([0-9]+)/); return m ? +m[1] : 0; }
function cllive(N) {
let C = type(N.media?.cloud) == 'object' ? N.media.cloud : {}, X = rcx();
if (C.on === true && C.mode == 'pre')
return err('pre', 'Con Scarica Prima i file del cloud sono già nel catalogo del disco', 'With Download First the cloud files are already in the disk catalog');
if (!X || C.on !== true || C.mode != 'live' || !match('' + (C.acct ?? ''), /^a[0-9]{1,3}$/))
return err('nolive', 'Accendi Dal Cloud › In Diretta nel Server Multimediale', 'Turn on From The Cloud › Live in the Media Server');
let A = X.acct('' + C.acct);
if (!A || A.state == 'relink') return err('relink', 'Account del cloud da ricollegare', 'Cloud account needs reconnecting');
if (X.paused()) return err('pause', 'Cloud in pausa', 'Cloud paused');
let s = split(trim(readfile(CLDLST) ?? ''), ' ');
if (s[0] != 'on') return { ...err('nolive', 'In Diretta non è ancora partita: riprova tra poco', 'Live has not started yet: try again shortly'), why: join(' ', slice(s, 1)) };
return { acct: '' + C.acct };
}
function clctl(ip) {
let b0 = 'http://' + ip + ':' + CLPORT, x = hreq(b0 + '/rootDesc.xml', 'GET', '', '', 6);
for (let b in split(x ?? '', '<service>')) {
if (xtag(b, 'serviceType') != CDS) continue;
let c = xtag(b, 'controlURL');
if (length(c)) return substr(c, 0, 7) == 'http://' ? c : b0 + (substr(c, 0, 1) == '/' ? '' : '/') + c;
}
return b0 + '/ctl';
}
function didl(x) {
let d = xtag(x, 'Result'), r = { c: [], i: [], n: +(xtag(x, 'NumberReturned') || '0'), tot: +(xtag(x, 'TotalMatches') || '0') };
let P = split(d, '<container ');
for (let j = 1; j < length(P); j++) { let m = match(P[j], /^([^>]* )?id="([^"]*)"/); if (m && length(m[2])) push(r.c, xun(m[2])); }
let I = split(d, '<item ');
for (let j = 1; j < length(I); j++) push(r.i, I[j]);
return r;
}
function clitem(b, Lb) {
let rs = match(b, /<res([^>]*)>([^<]*)<\/res>/), u = rs ? xun(trim(rs[2])) : '', m = match(u, /^https?:\/\/[^\/]+\/r\/([^?#]+)$/);
if (!m) return null;
let rp = pdec(m[1]), i = index(rp, '/'), L = i > 0 ? Lb[substr(rp, 0, i)] : null, p = L ? relok(L.p + substr(rp, i)) : null;
if (!p) return null;
let pi = match(rs[1], /protocolInfo="[^:"]*:[^:"]*:([^:"]+)/)?.[1] ?? '', mi = match(pi, /^(video|audio|image)\//) ? pi : clmime(p);
if (!mi) return null;
let sz = match(rs[1], /size="([0-9]+)"/)?.[1], du = match(rs[1], /duration="([^"]+)"/)?.[1];
return { p: p, ti: xtag(b, 'title'), sz: sz ? +sz : 0, du: dsec(du), mi: mi, da: xtag(b, 'date') };
}
function clcat(acct) {
begin();
let N = nget(), lv = cllive(N), ls = stat(CLCATLK);
if (lv.acct == null || lv.acct != '' + acct) return null;
if (ls && time() - ls.mtime > 900) rmdir(CLCATLK);
if (!mkdir(CLCATLK)) return null;
let ip = homeip(), cap = rcx()?.tier() == 'A' ? 2000 : 5000, Lb = cllibs(N), I = [], Q = [ '0' ], nc = 0, cut = false, end = time() + 600, bad = false;
let u = length(ip) ? clctl(ip) : null;
while (u && length(Q) && time() < end && nc < 500) {
let id = shift(Q), s0 = 0;
nc++;
while (time() < end) {
let x = soap(u, CDS, 'Browse', { ObjectID: id, BrowseFlag: 'BrowseDirectChildren', Filter: '*', StartingIndex: '' + s0, RequestedCount: '100', SortCriteria: '' }, 30);
if (x == null) { if (id == '0') bad = true; break; }
let B = didl(x);
push(Q, ...B.c);
for (let it in B.i) { if (length(I) >= cap) { cut = true; break; } let o = clitem(it, Lb); if (o) push(I, o); }
s0 += B.n;
if (cut || B.n <= 0 || s0 >= B.tot) break;
}
if (cut) break;
}
if (length(Q) && !cut) cut = true;
if (!u || bad) wjs(CLCATST, { ...(rjs(CLCATST) ?? {}), err: 'nolive', te: time() });
else {
wjs(CLCAT, { t: time(), acct: lv.acct, items: I });
wjs(CLCATST, { t: time(), acct: lv.acct, n: length(I), cut: cut });
}
rmdir(CLCATLK);
return { n: length(I), cut: cut, bad: bad };
}
function clcatrun() { let s = stat(CLCATLK); return s != null && time() - s.mtime <= 900; }
function clcatgo(acct) { if (!clcatrun()) detach('ucode -e ' + q("loadfile('" + SELFUC + "')().clcat('" + acct + "');")); }
function clcatst() { let S = rjs(CLCATST); return type(S) == 'object' ? { n: S.n ?? 0, t: S.t ?? 0, acct: S.acct ?? '', building: clcatrun(), cut: S.cut === true, ...(S.err ? { err: S.err } : {}) } : (clcatrun() ? { n: 0, t: 0, acct: '', building: true, cut: false } : null); }
function clcatq(N, r, k, f, by, qs, off, lim) {
if (length(by)) return err('nogroup', 'Raggruppamenti solo per i file sul disco', 'Groups only for files on the disk');
let lv = cllive(N);
if (lv.acct == null) return lv;
let pk = need('tv'); if (length(pk)) return pkgerr(pk);
let a = lv.acct, S = rjs(CLCATST) ?? {}, C = S.acct == a ? rjs(CLCAT) : null, run = clcatrun();
if (type(C?.items) != 'array' || C.acct != a) C = null;
if (!run && (r.fresh === true || !C || time() - +(C.t ?? 0) > 21600)) {
let mf = memfree();
if (mf > 0 && mf < 24576) { if (!C) return err('mem', 'Memoria del router quasi piena: il catalogo del cloud si fa più tardi', 'Router memory almost full: the cloud catalog will be built later'); }
else { clcatgo(a); run = true; }
}
if (!C) return { ...err('building', 'Catalogo del cloud in preparazione: riprova tra poco', 'Cloud catalog being prepared: try again shortly'), building: true };
let Lb = cllibs(N), pre = null;
if (k == 'lib') {
let m = match('' + (r.lib ?? ''), /^cl:(a[0-9]{1,3}):(\/.*)$/), p = m ? relok(m[2]) : null;
for (let nm, L in Lb) if (p && m[1] == a && lc(L.p) == lc(p)) pre = L.p + '/';
if (!pre) return err('lib', 'Libreria non trovata', 'Library not found');
}
let MI = { video: 'video/', music: 'audio/', photo: 'image/' }, rs = resget(resfile(N, disks())), RP = {}, lq = lc(qs), A = [], DA = {};
for (let x in rs.list) RP[x.disk + ':' + x.path] = x.pos;
for (let x in C.items) {
if (type(x) != 'object' || type(x.p) != 'string') continue;
if (MI[k] && substr(x.mi ?? '', 0, length(MI[k])) != MI[k]) continue;
if (pre && lc(substr(x.p, 0, length(pre))) != lc(pre)) continue;
if (length(lq) && index(lc(length(x.ti ?? '') ? x.ti : bname(x.p)), lq) < 0) continue;
let key = 'cl:' + a + ':' + x.p, pos = RP[key] ?? 0, seen = rs.seen[key] != null;
if (f == 'run' ? !(pos > 0) : (f == 'new' && (seen || pos > 0))) continue;
DA[x.p] = '' + (x.da ?? '');
push(A, { name: bname(x.p), title: x.ti ?? '', disk: 'cl:' + a, path: x.p, dur: x.du ?? 0, year: int(substr(x.da ?? '', 0, 4)) || 0, size: x.sz ?? 0,
artist: '', album: '', mime: x.mi ?? '', t: 0, pos: pos, seen: seen, cloud: true });
}
let tk = (x) => lc(length(x.title) ? x.title : x.name);
if (k == 'recent' || k == 'photo') sort(A, (x, y) => DA[x.path] != DA[y.path] ? (DA[x.path] < DA[y.path] ? 1 : -1) : (tk(x) < tk(y) ? -1 : (tk(x) > tk(y) ? 1 : 0)));
else sort(A, (x, y) => tk(x) < tk(y) ? -1 : (tk(x) > tk(y) ? 1 : 0));
return { n: length(A), items: slice(A, off, off + lim), groups: [], src: 'cloud', acct: a, t: +(C.t ?? 0), building: run, cut: S.cut === true };
}

function smbup() { let P = tipi().smbp ?? []; for (let c in pcomm()) if (index(P, c) >= 0) return true; return false; }
const CLMNTD = '/tmp/wf-cloud/mnt';
function clmnt(id) { return rjs(CLMNTD + '/' + id + '.json'); }
function cloudsh(C) {
let S = type(C?.share) == 'object' ? C.share : {}, A = {}, r = [], cs = tipi().cloudst, cb = tipi().cloudsmb;
for (let a in (type(C?.accounts) == 'array' ? C.accounts : [])) if (type(a) == 'object') A['' + a.id] = a.name ?? a.svc ?? '';
for (let id in sort(keys(S))) {
let x = S[id];
if (type(x) != 'object' || !match(id, /^a[0-9]{1,3}$/)) continue;
push(r, { id: id, name: x.name ?? '', acct: A[id] ?? '', st: type(cs) == 'function' ? cs(x, clmnt(id)) : 'off',
smb: type(cb) == 'function' ? cb(readfile(CLMNTD + '/' + id + '.smb')) : [] });
}
return r;
}
function liveof(N, D, C) {
let M = {}, lv = tipi().live;
if (type(lv) != 'function') return [];
for (let d in D) M[d.id] = true;
let P = {}, ss = tipi().smbsec;
for (let c in pcomm()) P[c] = true;
return lv(N, M, C, type(ss) == 'function' ? ss(P, cfg, (f) => readfile(R + f)) : smbup(), clmnt, filter(sharesAll(N, D), (s) => s.kind != 'cam'),
(id) => readfile(CLMNTD + '/' + id + '.smb'));
}
function dkname(N, id) { let o = N.disks?.[id]; return (type(o) == 'object' ? o.name ?? o.gone?.name : null) ?? id; }

const M = {
nas_shares: {
args: { act: 'x', on: true, secs: 0 },
call: function(req) {
begin();
let a = req.args.act ?? 'get', N = nget(), D = disks(), e = engine(N);
if (a == 'get' && N.on === true) detach('sh ' + q(SH) + ' follow');
let pa = pendact(a); if (pa) return pa;
let fixed = () => { let nb = nbname(N), ip = homeip(); return map(filter(sharesAll(N, D, e), (s) => s.kind != 'cam'), (s) => ({ name: s.name, kind: s.kind, user: s.user ?? '', disk: s.disk, path: s.path,
read: s.read, write: s.write, ro: !length(s.write), missing: absof(D, s.disk, s.path) == null, ...(s.noutenti ? { noutenti: true } : {}), dav: s.dav, nb: nb, lanip: ip })); };
if (a == 'list') return { shares: fixed(), on: N.smb_off !== true, engine: e, main: N.main?.id ?? '', cam_off: camst(N, D), nb: nbname(N), lanip: homeip() };
let out = () => {
let L2 = map(fixed(), (s) => index([ 'user', 'tm', 'fh' ], s.kind) >= 0 ? { ...s, path: '' } : s);
let CJ = rjs(R + '/etc/wrtfreedom/cloud.json'), mn = diskof(D, N.main?.id);
let md = diskof(D, N.main?.id), dro = engine(N) == 'samba4' && md != null && !uxfs(md) && smbroot(md);
return { shares: L2, engine: engine(N), samba_ok: sambaOk(), on: N.smb_off !== true, admin: admu(N),
main: N.main?.id ? { id: N.main.id, missing: mn == null } : null, cam_off: camst(N, D), live: liveof(N, D, CJ), cloud: cloudsh(CJ), nb: nbname(N), lanip: homeip(),
drive_ro: dro, need_samba4: UCFG.smbneed ? UCFG.smbneed(N, { R: R, ro: roShare(N) }) : false, ...(pendget() ?? {}) };
};
if (a == 'get') return out();
if (a == 'on') {
if (type(req.args.on) != 'bool') return err('on', 'Scegli acceso o spento', 'Choose on or off');
if (req.args.on && N.smb_off === true && smbwant({ ...N, smb_off: false })) { let pk = need(e); if (length(pk)) return pkgerr(pk); }
N.smb_off = !req.args.on;
if (!apply(N, { smb: true, dav: false })) return busy();
return out();
}
return err('act', 'Azione sconosciuta', 'Unknown action');
}
},
reserved: reserved,
users_sync: function() {
begin();
let N = nget();
return { ok: apply(N, { smb: true, dav: N.remote.webdav === true }), engine: engine(N) };
},
_remote: {
args: { act: 'x', webdav: true, smbvpn: true, sftp: true, secs: 0 },
call: function(req) {
begin();
let set = filter([ 'webdav', 'smbvpn', 'sftp' ], (k) => type(req.args[k]) == 'bool');
let a = req.args.act ?? (length(set) ? 'set' : 'get'), N = nget(), r = N.remote, Zs = zones();
let pa = pendact(a); if (pa) return pa;
let out = () => ({ webdav: r.webdav === true, smbvpn: r.smbvpn === true, sftp: r.sftp === true, addr: Zs.wgaddr, port: r.port ?? DAVPORT,
sftp_port: sshport(), vpn: length(Zs.vpn) > 0 || length(Zs.wgaddr) > 0, ...(pendget() ?? {}) });
if (a == 'get' || !length(set)) return out();
let P = [];
if (req.args.webdav === true) P = [ ...P, ...need('webdav') ];
if (req.args.sftp === true) P = [ ...P, ...need('sftp') ];
if (req.args.smbvpn === true) P = [ ...P, ...need(engine(N)) ];
if (length(P)) return pkgerr(uniq(P));
let risky = length(filter(set, (k) => req.args[k] === true && r[k] !== true)) > 0;
let bz = risky ? pendbusy('remote') : null; if (bz) return bz;
let before = clone(N), drop = [];
for (let k in set) {
if (r[k] === true && req.args[k] === false) { if (k == 'webdav') drop = [ ...drop, ...map(PK.webdav, (p) => p[0]) ]; if (k == 'sftp') push(drop, 'openssh-sftp-server'); }
r[k] = req.args[k];
}
if (r.webdav && !r.port) r.port = DAVPORT;
if (!apply(N, { smb: index(set, 'smbvpn') >= 0 || index(set, 'webdav') >= 0, dav: true })) return busy();
return { ...out(), ...(risky ? pendarm(before, 'remote', req.args.secs) : {}), ...(length(drop) ? { drop: drop } : {}) };
}
},
nas_media: {
args: { act: 'x', on: true, dirs: [], name: 'x', remember: true, secs: 0, cloud: {} },
call: function(req) {
begin();
let SK = [ 'on', 'dirs', 'name', 'remember' ];
let a = req.args.act ?? (length(filter([ ...SK, 'cloud' ], (k) => req.args[k] != null)) ? 'set' : 'get'), N = nget(), m = N.media, st = rjs(TMP + '/dlna.json') ?? {};
let pa = pendact(a); if (pa) return pa;
let od = join('|', type(m.dirs) == 'array' ? m.dirs : []);
m.dirs = mlib(N); m.types = mltypes(N);
let H = dhcphosts();
let tvlist = () => {
let LS = { ...leases() }, r = [], seen = {};
for (let k, x in H) if (length(x.name)) LS[k] = { ip: LS[k]?.ip ?? x.ip, name: x.name };
for (let t in (type(st.tvs) == 'array' ? st.tvs : [])) {
if (type(t) != 'object') continue;
let mac = lc('' + (t.mac ?? ''));
if (!macok(mac) || seen[mac]) continue;
seen[mac] = 1;
push(r, { mac: mac, ip: t.ip ?? LS[mac]?.ip ?? '', name: LS[mac]?.name || t.name || '' });
}
return r;
};
let spd = () => {
let id = dpsplit(m.dirs?.[0] ?? '')?.disk, f = TMP + '/speed-' + id + '.json', s = id ? stat(f) : null;
return s && time() - s.mtime <= 10 ? rjs(f) : null;
};
let W = rjs(TMP + '/dlna-watch.json') ?? {}, lt = +trim(readfile(ETC + '/nas-media.last') ?? '0');
let out = () => {
let D = disks(), rs = resget(resfile(N, D)), ty = {};
for (let s in m.dirs) ty[s] = m.types?.[s] ?? '';
let wr = m.on === true && W.used > 0 && W.max > 0 && W.used >= W.max;
let dm = filter(m.dirs ?? [], (s) => { let x = dpsplit(s); return !x || absof(D, x.disk, x.path) == null; });
let all = length(dm) > 0 && length(dm) == length(m.dirs ?? []), gd = uniq(map(dm, (s) => dpsplit(s)?.disk ?? ''));
let gw = all && m.on === true ? (length(gd) == 1 && length(gd[0]) ? { warn: 'Le librerie sono sul ' + dkname(N, gd[0]) + ', staccato', warn_en: 'The libraries are on ' + dkname(N, gd[0]) + ', unplugged' } :
{ warn: 'Le librerie sono su dischi staccati', warn_en: 'The libraries are on unplugged drives' }) : null;
let fl = all ? { video: 0, music: 0, photo: 0 } : { video: st.video ?? 0, music: st.music ?? 0, photo: st.photo ?? 0 };
return { on: m.on === true, name: m.name ?? '', dirs: m.dirs, types: ty, dirs_missing: dm, fixed: true, nomain: !length(m.dirs),
files: fl, tvs: tvlist(),
scan: st.scan === true || scanlive(), speed: spd(), last: lt, added: st.added ?? 0,
watch: { used: W.used ?? 0, max: W.max ?? 0, dir: W.dir ?? '' }, playing: m.on === true ? playing(N, H, leases()) : [],
resume_n: length(rs.list), remember: m.remember !== false,
cloud: { ...clout(m), ...(m.cloud?.on === true && m.cloud?.mode == 'live' ? { cat: clcatst() } : {}) },
db_ram: m.on === true && length(m.dirs ?? []) > 0 && dbwant(N, D) == null,
reindex_min: int((fl.video + fl.music + fl.photo) / 3000) + 1,
...(gw ? gw : (wr ? { warn: 'Troppe cartelle: i file nuovi potrebbero non comparire', warn_en: 'Too many folders: new files may not appear' } : {})),
...(pendget() ?? {}) };
};
if (a == 'get') {
if (m.on && time() - (stat(TMP + '/dlna.json')?.mtime ?? 0) > 60) detach('sh ' + q(SH) + ' dlnastat');
if (m.on && time() - (stat(TMP + '/dlna-watch.json')?.mtime ?? 0) > 3600) detach('sh ' + q(SH) + ' dlnawatch');
return out();
}
if (a == 'scan' || a == 'reindex' || a == 'rescan') {
if (!m.on) return err('off', 'Server Multimediale spento', 'Media Server is off');
if (scanlive()) return err('run', 'Scansione già in corso', 'Scan already running');
writefile(TMP + '/dlna.scan', time() + (a == 'scan' ? ' scan' : ' reindex'));
detach('sh ' + q(SH) + ' ' + (a == 'scan' ? 'dlnascan' : 'dlnareindex'));
return { ...out(), scan: true };
}
if (a == 'scan_stop') {
let sf = TMP + '/dlna.scan';
if (time() - (stat(sf)?.mtime ?? 0) >= 10800) return { ...out(), ok: true, scan: false };
if (match(readfile(sf) ?? '', / reindex/)) return err('reindex', 'Reindicizza non si può fermare', 'Reindex cannot be stopped');
detach('sh ' + q(SH) + ' dlnastop');
return { ...out(), ok: true, scan: false };
}
if (a == 'find') return { found: map(m.dirs, (s) => ({ dir: s, disk: split(s, ':')[0], name: bname(s), type: '', n: 0, on: true })) };
if (a != 'set') return err('act', 'Azione sconosciuta', 'Unknown action');
let ls0 = livesig(m);
if (req.args.cloud != null) {
let ce = clset(m, req.args.cloud, N);
if (ce) return ce;
if (!length(filter(SK, (k) => req.args[k] != null))) { if (!nput(N)) return busy(); if (livesig(m) != ls0) { sh(fwcmd(N) + 'true'); svcq([], true); } livereload(m, ls0); return { ...out(), ok: true }; }
}
let D = disks(), dirs = m.dirs;
if (req.args.dirs != null) {
if (type(req.args.dirs) != 'array') return err('path', 'Cartelle non valide', 'Invalid folders');
for (let s in req.args.dirs) {
let x = dpsplit(s);
if (!x || x.path == null) return err('path', 'Cartella non valida: ' + s, 'Invalid folder: ' + s);
if (mpriv(N, x)) return err('private', 'Le cartelle delle persone non vanno sulla TV di tutti', 'People\'s folders never go on everyone\'s TV');
if (index(dirs, x.disk + ':' + x.path) < 0) return err('path', 'Sulla TV vanno solo Film, Musica e Foto della Cartella Condivisa', 'Only Movies, Music and Photos of the Shared Folder go on the TV');
}
}
if (req.args.name != null && !length(trim('' + req.args.name))) req.args.name = null;
if (req.args.name != null && !match('' + req.args.name, /^[^[:cntrl:]"\\]{1,40}$/)) return err('name', 'Nome non valido', 'Invalid name');
if (req.args.remember != null && type(req.args.remember) != 'bool') return err('remember', 'Valore non valido', 'Invalid value');
let on = type(req.args.on) == 'bool' ? req.args.on : m.on === true;
let sc = scanlive(), off = sc && !on && m.on === true;
if (sc && !off) {
if (on != (m.on === true) || (req.args.name != null && '' + req.args.name != (m.name ?? '')))
return err('busy', 'Scansione in corso: riprova alla fine', 'Scan running: try again when it ends');
if (type(req.args.remember) == 'bool') { m.remember = req.args.remember; if (!nput(N)) return busy(); }
return { ...out(), ok: true };
}
if (on) {
if (!length(dirs)) return err('nomain', 'Scegli prima il Disco Principale', 'Choose the Main Disk first');
let pk = need('dlna');
if (length(pk)) return pkgerr(pk);
}
let was = m.on === true;
m.on = on; if (req.args.name != null) m.name = '' + req.args.name;
delete m.transcode; delete m.only; delete m.allow; delete m.names;
if (type(req.args.remember) == 'bool') m.remember = req.args.remember;
oursset(N, 'minidlna', on);
let dc = dlnacmd(N, D) + fwcmd(N);
if (!nput(N)) return busy();
sh(dc + 'true');
livereload(m, ls0);
if (off) detach('sh ' + q(SH) + ' dlnastop; sh ' + q(SH) + ' svc minidlna:off; sh ' + q(SH) + ' fw');
else svcq([ 'minidlna:' + (on ? 'on' : 'off') ], true);
if (on && !was) unlink(TMP + '/dlna.json');
if (on && od != join('|', m.dirs)) detach('sleep 5; sh ' + q(SH) + ' dlnawatch');
let r = out();
let dp = [ 'minidlna', ...(has('/usr/bin/sqlite3') ? [ 'sqlite3-cli' ] : []) ];
return { ...r, ...(was && !on ? { drop: dp } : {}) };
}
},
nas_catalog: {
args: { kind: 'x', q: 'x', f: 'x', by: 'x', lib: 'x', off: 0, lim: 0, wake: true, src: 'x', fresh: true },
call: function(req) {
begin();
let r = req.args, N = nget(), m = N.media, k = '' + (r.kind ?? 'video'), f = '' + (r.f ?? 'all'), by = '' + (r.by ?? ''), qs = '' + (r.q ?? '');
if (!match(k, /^(video|music|photo|recent|lib)$/)) return err('kind', 'Catalogo non valido', 'Invalid catalog');
if (!match(f, /^(all|new|run)$/) || !match(by, /^(|artist|album|track|year)$/)) return err('f', 'Filtro non valido', 'Invalid filter');
if (length(qs) > 64 || match(qs, /[[:cntrl:]]/)) return err('q', 'Ricerca non valida', 'Invalid search');
let off = r.off ?? 0, lim = r.lim ?? 50;
if (type(off) != 'int' || off < 0 || off > 100000 || type(lim) != 'int' || lim < 1 || lim > 200) return err('lim', 'Pagina non valida', 'Invalid page');
let src = '' + (r.src ?? 'disk');
if (src != 'disk' && src != 'cloud') return err('src', 'Origine non valida', 'Invalid source');
if (src == 'cloud') return clcatq(N, r, k, f, by, qs, off, lim);
let pk = need('cat'); if (length(pk)) return pkgerr(pk);
if (m.on !== true) return err('off', 'Server Multimediale spento', 'Media Server is off');
if (!stat(dbfile())) return err('nodb', 'Catalogo non ancora pronto', 'Catalog not ready yet');
if (r.wake !== true && dbsleep()) {
detach('sqlite3 -readonly ' + q(dbfile()) + ' ' + q('SELECT count(*) FROM DETAILS'));
return err('asleep', 'Disco a riposo: riprova tra qualche secondo', 'Disk asleep: try again in a few seconds');
}
let MI = { video: "MIME LIKE 'video/%'", music: "MIME LIKE 'audio/%'", photo: "MIME LIKE 'image/%'" }, D = disks(), w = [ MI[k] ?? 'MIME IS NOT NULL' ];
if (k == 'lib') {
let x = dpsplit(r.lib ?? ''), p = x ? absof(D, x.disk, x.path) : null;
if (!p || index(mlib(N), x.disk + ':' + x.path) < 0) return err('lib', 'Libreria non trovata', 'Library not found');
push(w, 'substr(PATH, 1, ' + (length(p) + 1) + ') = ' + sqe(p + '/'));
}
if (length(qs)) push(w, 'instr(lower(coalesce(TITLE, PATH)), lower(' + sqe(qs) + ')) > 0');
let W = ' FROM DETAILS WHERE ' + join(' AND ', w), bad = () => err('db', 'Catalogo non leggibile: riprova', 'Catalog not readable: try again');
if ((k == 'music' && (by == 'artist' || by == 'album')) || (k == 'photo' && by == 'year')) {
let gk = by == 'artist' ? "coalesce(ARTIST, '')" : (by == 'album' ? "coalesce(ALBUM, '')" : "substr(coalesce(DATE, ''), 1, 4)");
let cs = by == 'artist' ? 'count(DISTINCT ALBUM) albums, count(*) tracks' : (by == 'album' ? 'max(ARTIST) a, count(*) tracks' : 'count(*) n');
let G = sql('SELECT ' + gk + ' t, ' + cs + W + ' GROUP BY 1 ORDER BY 1' + (by == 'year' ? ' DESC' : '') + ' LIMIT ' + lim + ' OFFSET ' + off);
if (G == null) return bad();
let n = sql('SELECT count(DISTINCT ' + gk + ') n' + W);
return { n: n?.[0]?.n ?? length(G), items: [], groups: G };
}
let rs = resget(resfile(N, D)), RP = {};
for (let x in rs.list) RP[x.disk + ':' + x.path] = x.pos;
let ord = k == 'recent' ? 'TIMESTAMP DESC' : (k == 'photo' ? 'DATE DESC' : 'lower(coalesce(TITLE, PATH))');
let cols = 'SELECT PATH p, TITLE ti, DURATION du, DATE da, SIZE sz, ARTIST ar, ALBUM al, MIME mi, TIMESTAMP ts';
let item = (x) => {
let rl = relof(D, x.p);
if (!rl) return null;
let key = rl.disk + ':' + rl.path;
let sr = match(x.mi ?? '', /^video\//) ? replace(x.p, /\.[^.\/]*$/, '') + '.srt' : null;
return { name: bname(x.p), title: x.ti ?? '', disk: rl.disk, path: rl.path, dur: dsec(x.du), year: int(substr(x.da ?? '', 0, 4)) || 0, size: x.sz ?? 0,
artist: x.ar ?? '', album: x.al ?? '', mime: x.mi ?? '', t: x.ts ?? 0, pos: RP[key] ?? 0, seen: rs.seen[key] != null,
...(sr && stat(sr) ? { srt: bname(sr) } : {}) };
};
let items = [], n = 0;
if (f != 'all') {
let A = sql(cols + W + ' ORDER BY ' + ord + ' LIMIT 5000');
if (A == null) return bad();
let F = filter(map(A, item), (x) => x && (f == 'run' ? x.pos > 0 : (!x.seen && !x.pos)));
n = length(F); items = slice(F, off, off + lim);
}
else {
let A = sql(cols + W + ' ORDER BY ' + ord + ' LIMIT ' + lim + ' OFFSET ' + off);
if (A == null) return bad();
items = filter(map(A, item), (x) => x != null);
n = sql('SELECT count(*) n' + W)?.[0]?.n ?? length(items);
}
let ex = {};
if (k == 'video' || k == 'lib') {
let c = sql('SELECT (SELECT count(*) FROM CAPTIONS) s, (SELECT count(*)' + W + ' AND ALBUM_ART > 0) p');
ex = { subs: c?.[0]?.s ?? 0, posters: c?.[0]?.p ?? 0 };
}
return { n: n, items: items, groups: [], ...ex };
}
},
nas_resume: {
args: { act: 'x', disk: 'x', path: 'x', pos: 0, dur: 0, where: 'x' },
call: function(req) {
begin();
let r = req.args, a = '' + (r.act ?? 'get'), N = nget(), D = disks(), f = resfile(N, D), RS = resget(f);
let out = (x) => ({ list: map(x.list, (y) => ({ name: y.name, disk: y.disk, path: y.path, pos: y.pos, dur: y.dur, where: y.where ?? '', t: y.t })),
remember: N.media.remember !== false });
if (a == 'get') return out(RS);
if (a == 'clear') { RS.list = []; resput(f, RS); return out(RS); }
let d = '' + (r.disk ?? ''), p = relok(r.path), cl = clres(d);
if ((cl === null ? !diskof(D, d) : !cl) || p == null || p == '/') return err('path', 'File non valido', 'Invalid file');
if (a == 'del') { RS.list = filter(RS.list, (y) => y.disk + ':' + y.path != d + ':' + p); resput(f, RS); return out(RS); }
if (a != 'set') return err('act', 'Azione sconosciuta', 'Unknown action');
let pos = r.pos ?? 0, dur = r.dur ?? 0, wh = '' + (r.where ?? '');
if (type(pos) != 'int' || type(dur) != 'int' || pos < 0 || dur <= 0 || dur > 360000 || pos > dur) return err('pos', 'Posizione non valida', 'Invalid position');
if (length(wh) > 64 || match(wh, /[[:cntrl:]]/)) return err('where', 'Dispositivo non valido', 'Invalid device');
let ab = cl ? null : absof(D, d, p);
if (!cl && (!ab || stat(ab)?.type != 'file')) return err('path', 'File non trovato', 'File not found');
let ok = resset(N, D, d, p, pos, dur, wh);
return { ...out(resget(f)), saved: ok };
}
},
nas_tv: {
args: { act: 'x', id: 'x', mac: 'x', disk: 'x', path: 'x', pos: 0, vol: 0, wol: true, remote: true },
call: function(req) {
begin();
let r = req.args, a = '' + (r.act ?? 'list'), N = nget(), m = N.media, J = tvload(), T = J.tvs, H = dhcphosts(), LS = leases();
let id = lc('' + (r.id ?? r.mac ?? ''));
if (macok(id)) for (let k in sort(keys(T))) if (tvmac(k) == id) { id = k; break; }
let mac = tvmac(id), okid = tvidok(id) || macok(id);
let out = () => {
let S = type(m.tv) == 'object' ? m.tv : {}, L2 = [], live = {};
for (let k in keys(T)) live[tvmac(k)] = 1;
for (let k in uniq([ ...keys(T), ...keys(S) ])) {
if (!tvidok(k) && !(macok(k) && !live[k])) continue;
let mc = tvmac(k), t = T[k] ?? {}, s = S[k] ?? S[mc] ?? {}, p = rjs(tvfile(k)) ?? {}, rs = rjs(tvres(k));
push(L2, { id: k, mac: mc, name: tvname(T, k, H, LS) || s.name || '', brand: t.brand || s.brand || '', ip: t.ip ?? macip(mc, H, LS),
recv: t.av != null, perm: s.perm ?? 0, wol: s.wol === true, remote: s.remote !== false, state: p.state ?? (t.av ? 'stop' : 'off'),
file: p.file ?? '', pos: p.pos ?? 0, dur: p.dur ?? 0, vol: p.vol ?? null, ...(rs && time() - rs.t < 60 && rs.ok === false ? { fail: rs.act } : {}) });
}
return { tvs: L2, finding: time() - (stat(TMP + '/tv.find')?.mtime ?? 0) <= 30, t: J.t };
};
if (a == 'set') {
if (!okid) return err('mac', 'TV non valida', 'Invalid TV');
for (let k in [ 'wol', 'remote' ]) if (r[k] != null && type(r[k]) != 'bool') return err(k, 'Valore non valido', 'Invalid value');
if (r.wol === true) { let pk = need('wake'); if (length(pk)) return pkgerr(pk); }
if (type(m.tv) != 'object') m.tv = {};
if (!m.tv[id] && length(keys(m.tv)) >= 32) return err('max', 'Al massimo 32 TV', 'At most 32 TVs');
let s = m.tv[id] ?? { ...(m.tv[mac] ?? {}) };
if (type(r.wol) == 'bool') s.wol = r.wol;
if (type(r.remote) == 'bool') s.remote = r.remote;
if (T[id]) { s.name = T[id].name; s.brand = T[id].brand; }
m.tv[id] = s;
if (!nput(N)) return busy();
return out();
}
let pk = need('tv'); if (length(pk)) return pkgerr(pk);
if (a == 'list') {
if (time() - J.t > 60 && time() - (stat(TMP + '/tv.find')?.mtime ?? 0) > 30) { writefile(TMP + '/tv.find', '' + time()); detach('sh ' + q(SH) + ' tvfind'); }
let PM = {};
for (let k, t in T) if (t?.av && time() - (stat(tvfile(k))?.mtime ?? 0) > 5) PM[tvmac(k)] = 1;
for (let x in keys(PM)) detach('sh ' + q(SH) + ' tvpoll ' + q(x));
return out();
}
if (!okid) return err('mac', 'TV non valida', 'Invalid TV');
if (a == 'wake') {
let pw2 = need('wake'); if (length(pw2)) return pkgerr(pw2);
let dv = homedev(zones()), eb = has('/usr/bin/etherwake') ? '/usr/bin/etherwake' : '/usr/sbin/etherwake';
detach(eb + (length(dv) ? ' -i ' + q(dv) : '') + ' ' + q(mac));
return { ...out(), ok: true };
}
if (!T[id]?.av) return err('tv', 'La TV non risponde: accendila e riprova', 'The TV does not respond: turn it on and try again');
let job = { id: id, act: a };
if (a == 'play' && substr('' + (r.disk ?? ''), 0, 3) == 'cl:') {
let lv = cllive(N);
if (lv.acct == null) return lv;
if ('' + r.disk != 'cl:' + lv.acct) return err('nolive', 'In Diretta è accesa per un altro account del cloud', 'Live is on for another cloud account');
let p = relok(r.path), rp = null;
if (p == null || p == '/') return err('path', 'File non valido', 'Invalid file');
for (let nm, L in cllibs(N)) { let lp = lc(L.p) + '/'; if (substr(lc(p), 0, length(lp)) == lp) rp = nm + substr(p, length(L.p)); }
if (!rp) return err('notlib', 'Sulla TV vanno solo Film, Musica e Foto della Cartella Condivisa', 'Only Movies, Music and Photos of the Shared Folder go on the TV');
let mi = clmime(p);
if (!mi) return err('path', 'Non è un file multimediale', 'Not a media file');
let ip = homeip();
if (!length(ip)) return err('ip', 'Indirizzo del router non trovato', 'Router address not found');
job.url = 'http://' + ip + ':' + CLPORT + '/r/' + uenc(rp);
job.mime = mi; job.title = bname(p); job.audio = match(mi, /^audio\//) != null;
job.pos = type(r.pos) == 'int' && r.pos > 0 ? r.pos : 0;
}
else if (a == 'play') {
if (m.on !== true) return err('off', 'Server Multimediale spento', 'Media Server is off');
let pc = need('cat'); if (length(pc)) return pkgerr(pc);
let D = disks(), p = relok(r.path), ab = p != null ? absof(D, '' + (r.disk ?? ''), p) : null;
if (!ab || stat(ab)?.type != 'file') return err('path', 'File non trovato', 'File not found');
let x = sql('SELECT ID id, MIME mi, TITLE ti FROM DETAILS WHERE PATH = ' + sqe(ab));
if (!length(x ?? [])) return err('notindb', 'File non ancora nel catalogo: scansiona la libreria', 'File not in the catalog yet: scan the library');
let ip = homeip();
if (!length(ip)) return err('ip', 'Indirizzo del router non trovato', 'Router address not found');
let ext = match(ab, /\.([A-Za-z0-9]{1,5})$/);
job.url = 'http://' + ip + ':8200/MediaItems/' + int(x[0].id) + (ext ? '.' + lc(ext[1]) : '');
job.mime = x[0].mi || 'video/mp4'; job.title = x[0].ti || bname(ab); job.audio = match(job.mime, /^audio\//) != null;
job.pos = type(r.pos) == 'int' && r.pos > 0 ? r.pos : 0;
}
else if (a == 'seek') { if (type(r.pos) != 'int' || r.pos < 0) return err('pos', 'Posizione non valida', 'Invalid position'); job.pos = r.pos; }
else if (a == 'vol') { if (type(r.vol) != 'int' || r.vol < 0 || r.vol > 100) return err('vol', 'Volume non valido', 'Invalid volume'); job.vol = r.vol; }
else if (!match(a, /^(pause|resume|stop)$/)) return err('act', 'Azione sconosciuta', 'Unknown action');
let qid = 'tvq-' + rid();
wjs(TMP + '/' + qid + '.json', job);
detach('sh ' + q(SH) + ' tvdo ' + qid);
return { ...out(), ok: true, sent: a };
}
},
_backup: {
args: { act: 'x', id: 'x', on: true, dest: {} },
call: function(req) {
begin();
let a = req.args ?? {}, N = nget(), D = disks(), id = '' + (a.id ?? ''), act = a.act ?? 'set';
if (act == 'get') return { tm: tmstate(N, D, 'tm'), fh: tmstate(N, D, 'fh'), nb: nbname(N), lanip: homeip() };
if (act != 'set' || (id != 'tm' && id != 'fh')) return err('act', 'Azione sconosciuta', 'Unknown action');
let on = a.on === true, x = type(N[id]) == 'object' ? N[id] : {};
if (on) {
if (N.smb_off === true) return err('off', 'Cartelle In Rete spente: accendile prima', 'Network Folders are off: turn them on first');
if (id == 'tm' && !sambaOk()) return err('mem', 'Backup Del Mac serve più memoria nel router', 'Mac Backup needs more memory in the router');
let pk = id == 'tm' ? tmpkg() : need(engine(N)); if (length(pk)) return pkgerr(pk);
let mn = diskof(D, N.main?.id);
if (!mn) return err('nomain', N.main?.id ? 'Disco Principale staccato' : 'Scegli prima il Disco Principale', N.main?.id ? 'Main Disk unplugged' : 'Choose the Main Disk first');
if (rod(mn)) return err('ro', 'Il disco è in sola lettura', 'The disk is read-only');
}
let we = engine(N);
delete x.disk; delete x.path;
x.on = on; N[id] = x;
if (!apply(N, { smb: true, dav: id == 'fh' && N.remote.webdav === true })) return busy();
return { ok: true, tm: N.tm?.on === true, fh: N.fh?.on === true, tm_state: tmstate(N, D, 'tm'), fh_state: tmstate(N, D, 'fh'),
...(id == 'tm' && !on && we == 'samba4' && engine(N) == 'ksmbd' ? { drop: [ 'samba4-server' ] } : {}) };
}
},
nas_adv: {
args: { act: 'x', smb_min: 'x', name: 'x', group: 'x', nets: {}, trash: true, discovery: true, led: true, noatime: true, netbios: true, secs: 0 },
call: function(req) {
begin();
let ks = filter([ 'smb_min', 'name', 'group', 'nets', 'trash', 'discovery', 'led', 'noatime', 'netbios' ], (k) => req.args[k] != null);
let a = req.args.act ?? (length(ks) ? 'set' : 'get'), N = nget(), A = N.adv, Zs = zones();
let pa = pendact(a); if (pa) return pa;
let D = disks(), ln = ledpick(), PC = null, pc = () => PC ?? (PC = pcomm());
let now = () => ({ discovery: discon(pc()), led: ln ? ledget(ln) : null, noatime: noatget(A, D) });
let out = () => { let X = now(); return { smb_min: A.smb_min ?? '2', name: A.name ?? trim(readfile('/proc/sys/kernel/hostname') ?? ''), group: A.group ?? 'WORKGROUP',
nets: { guest: A.nets?.guest === true, iot: A.nets?.iot === true }, has: { guest: length(Zs.guest) > 0, iot: Zs.iot != null, discovery: !length(need('discovery')) },
disc_need: wsddbin() ? [] : [ 'wsdd2' ],
trash: A.trash !== false, netbios: A.netbios === true, engine: engine(N), samba_ok: sambaOk(), discovery: X.discovery, led: X.led, noatime: X.noatime,
mounts: map(D, (d) => ({ disk: d.id, name: N.disks?.[d.id]?.name ?? d.name, path: d.mnt })), nb: nbname(N), lanip: homeip(), ...(pendget() ?? {}) }; };
if (a == 'get' || !length(ks)) return out();
let sm = req.args.smb_min, nm = req.args.name, gr = req.args.group, nt = req.args.nets;
if (sm != null && sm != '2' && sm != '3') return err('smb', 'Versione SMB non valida (2 o 3)', 'Invalid SMB version (2 or 3)');
if (nm != null && !match(nm, /^[A-Za-z0-9][A-Za-z0-9-]{0,14}$/)) return err('name', 'Nome in rete: lettere, cifre e trattino, fino a 15', 'Network name: letters, digits and hyphen, up to 15');
if (nm != null && !match(nm, /[A-Za-z]/)) return err('name', 'Nome in rete: serve almeno una lettera', 'Network name: needs at least one letter');
if (gr != null && !match(gr, /^[A-Za-z0-9][A-Za-z0-9_-]{0,14}$/)) return err('group', 'Gruppo di lavoro non valido', 'Invalid workgroup');
if (nt != null && type(nt) != 'object') return err('nets', 'Reti non valide', 'Invalid networks');
for (let k in [ 'discovery', 'led', 'noatime', 'netbios' ]) if (req.args[k] != null && type(req.args[k]) != 'bool') return err(k, 'Valore non valido', 'Invalid value');
if (req.args.led != null && !ln) return err('led', 'Il router non ha una spia per il disco', 'The router has no light for the drive');
if (req.args.discovery === false && discon(pc()) && !length(filter([ ...DISC, 'wf-nasdisc' ], (s) => index(N.ours ?? [], s) >= 0)))
return err('discovery', 'Scoperta In Rete accesa da un altro programma del router', 'Network Discovery is on by another router program');
let P = [];
if (req.args.discovery === true) P = [ ...P, ...need('discovery') ];
if (req.args.trash === true) {
if (!sambaOk()) return err('mem', 'Il Cestino delle cartelle condivise serve più memoria nel router', 'The shared folders Recycle Bin needs more memory in the router');
P = [ ...P, ...need('samba4') ];
}
if (length(P)) return pkgerr(P);
let X = now(), xk = filter([ 'discovery', 'led', 'noatime' ], (k) => req.args[k] != null && req.args[k] != X[k]);
let risky = (sm == '3' && A.smb_min != '3') || (nt?.guest === true && A.nets?.guest !== true) || (nt?.iot === true && A.nets?.iot !== true) || length(xk) > 0;
let bz = risky ? pendbusy('adv') : null; if (bz) return bz;
let before = clone(N), we = engine(N), wn = A.nfs === true;
for (let k in xk) before.adv[k] = X[k];
if (sm != null) A.smb_min = sm; if (nm != null) A.name = nm; if (gr != null) A.group = gr;
if (type(req.args.trash) == 'bool') A.trash = req.args.trash;
if (type(req.args.netbios) == 'bool') A.netbios = req.args.netbios;
if (nt) A.nets = { guest: type(nt.guest) == 'bool' ? nt.guest : A.nets?.guest === true, iot: type(nt.iot) == 'bool' ? nt.iot : A.nets?.iot === true };
for (let k in [ 'discovery', 'led', 'noatime' ]) if (type(req.args[k]) == 'bool') A[k] = req.args[k];
if (length(xk)) { let e = advx(N, D); if (e) return e; }
if (!apply(N, { smb: true, dav: false })) return busy();
let drop = [ ...(wn ? [ 'nfs-kernel-server' ] : []), ...(we == 'samba4' && engine(N) == 'ksmbd' ? [ 'samba4-server' ] : []) ];
let ov = {};
for (let k in xk) ov[k] = A[k];
let pp = rjs(PEND);
if (risky && pp?.what == 'adv' && type(pp.old?.adv) == 'object') {
let ch = false;
for (let k in xk) if (pp.old.adv[k] == null) { pp.old.adv[k] = X[k]; ch = true; }
if (ch) wjs(PEND, pp);
}
return { ...out(), ...ov, ...(risky ? pendarm(before, 'adv', req.args.secs) : {}), ...(length(drop) ? { drop: drop } : {}) };
}
},
follow: follow,
dfs: function() { begin(); let N = nget(), D = disks(); dfslinks(N, D, dfsnow(N), davlink(N, D)); },
engine_sync: function() {
begin();
let N = nget();
if (!enginechg(N)) return { ok: true, engine: engine(N), did: false };
return { ok: apply(N, { smb: true, dav: N.remote.webdav === true }), engine: engine(N), did: true };
},
expire: expire,
spare: sparefix,
tvfind: tvfind,
tvpoll: tvpoll,
tvdo: tvdo,
clcat: clcat
};

return M;
