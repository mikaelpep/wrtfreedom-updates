#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
umask 077
W=/usr/share/wrtfreedom; D=/tmp/wf-backup; MF=/etc/wrtfreedom/backup.json; PF=/etc/wrtfreedom/backup-pkgs.txt
PEND=/tmp/wf-restore.pending; UNTIL=/tmp/wf-restore.until; PRE=$D/prima-del-ripristino.tar.gz; RB=/etc/wrtfreedom/bak/restore
RWAIT=120; BAKRUN=${WF_BAKRUN:-0}
mkdir -p $D /etc/wrtfreedom
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
js() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r'; }	# testo sicuro dentro una stringa JSON
err() { rm -f $D/create.$$.list; printf '{"error":"%s"}\n' "$(js "$1")"; exit 1; }	# elenco di create tolto anche negli errori
errc() { rm -f $D/create.$$.list $D/plain.$$.tar.gz $D/dec.$$; printf '{"error":"%s","code":"%s","enc":true}\n' "$(js "$1")" "$2"; exit 1; }
PWF=/etc/wrtfreedom/backup.pw
SECRET='^/etc/wrtfreedom/nas-cam\.pw$|^/etc/wrtfreedom/nasx-rclone\.conf$|^/etc/wrtfreedom/nasx-rclone\.conf\.pre321$|^/etc/wrtfreedom/backup\.pw$|^/etc/wrtfreedom/cloud-rclone\.conf(\.old)?$|^/etc/wrtfreedom/cloud-links\.json$|^/etc/wrtfreedom/nas-dav\.digest$|^/etc/wrtfreedom/nas-admpw\.fp$|^/etc/ksmbd/ksmbdpwd\.db$|^/etc/samba/smbpasswd$|^/etc/samba/passdb\.tdb$|^/etc/wrtfreedom/nas-blk/|^/etc/wrtfreedom/tg-u/'
WCF=/etc/config/wrtfreedom
notok() {
[ -f "$1" ] || return 0
awk -v q="'" -v d='"' '/^[ \t]*config[ \t]/ { s = ($3 == "tg" || $3 == q "tg" q || $3 == d "tg" d) }
s && /^[ \t]*option[ \t]/ && ($2 == "token" || $2 == q "token" q || $2 == d "token" d) { next } { print }' "$1" > "$1.t" &&
mv -f "$1.t" "$1" || { rm -f "$1.t"; return 1; }
}
NJF=/etc/wrtfreedom/nas.json; NJR=$D/st.$$
nopw() {
[ -f "$1" ] || return 0
F_=$1 ucode -e 'let fs = require("fs"), f = getenv("F_"), N = json(fs.readfile(f) ?? "{}");
for (let u, x in (type(N.users) == "object" ? N.users : {})) if (type(x) == "object") { x.pw = false; delete x.ph; delete x.rc; delete x.unlock; }
if (fs.writefile(f + ".t", sprintf("%J", N)) == null) exit(1);' 2>/dev/null && mv -f "$1.t" "$1" || { rm -f "$1.t"; return 1; }
}
isenc() { ucode $W/bakenc.uc is "$1" 2>/dev/null; }
OP=$D/open.tar.gz; OPI=$D/open.id; OPK=$D/open.pkgs; OPN=$D/open.t; OPT=600
sid() { sha256sum < "$1" 2>/dev/null | cut -d' ' -f1; }
opened() { [ -f $OP ] && [ -s $OPI ] && [ "$(sid "$1")" = "$(cat $OPI)" ]; }

adgyaml() { sh $W/lib.sh adgyaml 2>/dev/null; }	# file di AdGuard: una regola sola in lib.sh
adginit() { for s in adguardhome AdGuardHome; do [ -x /etc/init.d/$s ] && { echo $s; return; }; done; }
pm() { command -v apk >/dev/null && echo apk || echo opkg; }
userpkgs() {
if [ "$(pm)" = apk ]; then
[ -f /etc/apk/world ] || return 0
if [ -f /rom/etc/apk/world ]; then grep -vxFf /rom/etc/apk/world /etc/apk/world; else cat /etc/apk/world; fi
else
awk '/^Package:/{p=$2} /^Status:/ && / user /{print p}' /usr/lib/opkg/status 2>/dev/null |
while read -r p; do grep -qx "Package: $p" /rom/usr/lib/opkg/status 2>/dev/null || echo "$p"; done
fi | sed 's/[<>=~].*//' | grep -E '^[A-Za-z0-9._+-]+$' | sort -u
}
hasp() { if [ "$(pm)" = apk ]; then apk info -e "$1" >/dev/null 2>&1; else opkg status "$1" 2>/dev/null | grep -q '^Status:.* installed'; fi; }
extras() {
for f in /etc/ethers /etc/opkg/customfeeds.conf /etc/apk/repositories.d/customfeeds.list; do [ -f "$f" ] && echo "$f"; done
for d in /etc/luci-uploads /etc/crontabs /etc/ssl/acme /etc/acme /etc/adguardhome; do [ -d "$d" ] && find "$d" -type f 2>/dev/null; done
[ -f /etc/wrtfreedom/nas-own.json ] && echo /etc/wrtfreedom/nas-own.json
[ -d /etc/wrtfreedom/ai-mem.d ] && find /etc/wrtfreedom/ai-mem.d -type f 2>/dev/null
Y=$(adgyaml)
if [ -n "$Y" ]; then
echo "$Y"
for k in certificate_path private_key_path; do
p=$(sed -n "s/^ *$k: *['\"]\{0,1\}\([^'\"]*\)['\"]\{0,1\} *$/\1/p" "$Y" | head -n 1)
[ -n "$p" ] && [ -f "$p" ] && echo "$p"
done
fi
}
WFP='^/usr/share/wrtfreedom/|^/www/wrtfreedom/|^/usr/share/rpcd/ucode/wrtfreedom\.uc$|^/usr/share/rpcd/acl\.d/wrtfreedom\.json$|^/usr/libexec/rpcd/wrtfreedom\.wait$|^/www/cgi-bin/wf-(live|ai|me)$|^/etc/init\.d/wrtfreedom$|^/etc/hotplug\.d/.*/90-wrtfreedom$|^/etc/hotplug\.d/acme/91-wrtfreedom$|^/usr/share/ucode/luci/template/themes/wrtfreedom/|^/www/luci-static/wrtfreedom'
NOF='^/etc/wrtfreedom/ai-[A-Za-z0-9_]*\.key$|^/etc/wrtfreedom/pacchetto\.|^/etc/wrtfreedom/bak/|^/etc/wrtfreedom-copie/|'"$WFP"
filelist() { { sysupgrade -l 2>/dev/null; extras; echo $MF; echo $PF; } | grep '^/' | grep -vE "$NOF" | sort -u | while read -r f; do { [ -f "$f" ] || [ -L "$f" ]; } && echo "$f"; done; }

cat_of() {
case "$1" in
/usr/share/wrtfreedom/*|/www/wrtfreedom/*|/usr/share/rpcd/ucode/wrtfreedom.uc|/usr/share/rpcd/acl.d/wrtfreedom.json|/usr/libexec/rpcd/wrtfreedom.wait|/www/cgi-bin/wf-live|/www/cgi-bin/wf-ai|/www/cgi-bin/wf-me|/etc/init.d/wrtfreedom|/etc/hotplug.d/*/90-wrtfreedom|/etc/hotplug.d/acme/91-wrtfreedom|/usr/share/ucode/luci/template/themes/wrtfreedom/*|/www/luci-static/wrtfreedom*) echo wfpkg ;;
"$MF"|"$PF"|/etc/wrtfreedom/pacchetto.*|/etc/wrtfreedom/bak/*) echo wfpkg ;;
/etc/config/network|/etc/config/dhcp|/etc/config/sqm|/etc/config/mwan3|/etc/ethers|/etc/hosts) echo rete ;;
/etc/config/wireless) echo wifi ;;
/etc/config/firewall|/etc/firewall.user|/etc/nftables.d/*|/usr/share/nftables.d/*) echo firewall ;;
/etc/config/adguardhome|/etc/adguardhome/*|/etc/adguardhome.yaml|*/AdGuardHome.yaml) echo adguard ;;
/etc/config/ddns|/etc/config/acme|/etc/ssl/acme/*|/etc/acme/*) echo ddns ;;
/etc/passwd|/etc/shadow|/etc/group|/etc/config/dropbear|/etc/dropbear/*|/etc/config/uhttpd|/etc/config/rpcd|/etc/uhttpd.*) echo accesso ;;
/etc/config/quectel|/etc/config/modemmanager|/etc/config/qmodem|/etc/config/smstools3) echo modem ;;
/etc/crontabs/*) echo cron ;;
/etc/config/wrtfreedom|/etc/wrtfreedom/*) echo wf ;;
/etc/config/system|/etc/config/luci|/etc/config/fstab|/etc/config/ubootenv|/etc/rc.local|/etc/sysctl.conf|/etc/sysctl.d/*|/etc/profile|/etc/profile.d/*|/etc/shells|/etc/inittab|/etc/sysupgrade.conf|/etc/opkg/*|/etc/apk/*|/etc/luci-uploads/*) echo sistema ;;
/etc/config/*) echo altre ;;
*) echo file ;;
esac
}
CATS="rete wifi firewall adguard ddns accesso modem cron wf sistema altre file"

svc() { [ -x "/etc/init.d/$1" ] && /etc/init.d/$1 "${2:-restart}" >/dev/null 2>&1; }
reload_cat() {
case "$1" in
firewall) svc firewall reload ;;
adguard) s=$(adginit); [ -n "$s" ] && svc "$s" ;;
ddns) svc ddns ;;
cron) svc cron ;;
wf) svc wrtfreedom ;;
sistema) svc system reload; sysctl -p >/dev/null 2>&1; svc led ;;
altre) # ogni /etc/config/<nome> ripristinato con il suo servizio
grep '^etc/config/' $D/sel.list | sed 's#^etc/config/##' | while read -r n; do [ "$(cat_of /etc/config/$n)" = altre ] && svc "$n"; done ;;
esac
}
reload_late() {
case ",$1," in *,rete,*) svc network reload; svc dnsmasq; svc sqm ;; esac
case ",$1," in *,wifi,*) wifi reload >/dev/null 2>&1 ;; esac
case ",$1," in *,accesso,*) svc dropbear; svc uhttpd ;; esac
}
select_cats() {
tar tzf "$1" 2>/dev/null | sed 's#^\./##; s#/$##' | while read -r p; do
[ -n "$p" ] || continue
c=$(cat_of "/$p"); case ",$2," in *",$c,"*) echo "$p" ;; esac
done > $D/sel.list
}
apply() { # archivio categorie
select_cats "$1" "$2"
[ -s $D/sel.list ] || return 1
tar xzf "$1" -C / -T $D/sel.list 2>/dev/null || return 1
for c in $(echo "$2" | tr ',' ' '); do reload_cat "$c"; done
reload_late "$2"
}

A="$1"; F="${2:-$D/backup.tar.gz}"
[ "$A" = create ] && [ "$3" = tg ] && NOF="$NOF|^/etc/wrtfreedom/ai-mem\.json\$|^/etc/wrtfreedom/ai-votes\.json\$|^/etc/wrtfreedom/ai-mem\.d/"
PWU=
case "$A:$3" in
create:tg) [ -s $PWF ] && PWU=$PWF ;;
create:app) [ -n "$4" ] && [ -s "$4" ] && PWU=$4 ;;
esac
NS=; case "$A:$3" in create:tg|create:app) [ -n "$PWU" ] || { NOF="$NOF|$SECRET"; NS=1; } ;; esac
PWT=; case "$A:$3:$4" in create:app:$D/pw.*) PWT=$4 ;; inspect:$D/pw.*) PWT=$3 ;; esac
FO=; OPD=
cln() { rm -rf $NJR; rm -f $D/create.$$.list $D/plain.$$.tar.gz $D/plain.$$.tar.gz.t $D/dec.$$ $D/dec.$$.t ${FO:+"$FO.t"} ${PWT:+"$PWT"}; [ -z "$OPD" ] || rm -f $OP $OPN; }
trap cln EXIT; trap 'cln; exit 1' INT TERM HUP
case "$A" in
create)
FO=$F; [ -n "$PWU" ] && { [ "$3" = tg ] && case "$F" in *.tar.gz) FO=${F%.tar.gz}.wfbak ;; esac; F=$D/plain.$$.tar.gz; }
. /etc/openwrt_release 2>/dev/null
userpkgs > $PF; [ -f $MF ] || : > $MF
n=$(filelist | wc -l)
printf '{"v":1,"t":%s,"host":"%s","model":"%s","board":"%s","release":"%s","revision":"%s","target":"%s","pm":"%s","files":%s,"pkgs":%s,"wf":"%s"}\n' \
		"$(date +%s)" "$(js "$(uci -q get system.@system[0].hostname)")" "$(js "$(cat /tmp/sysinfo/model 2>/dev/null)")" "$(js "$(cat /tmp/sysinfo/board_name 2>/dev/null)")" \
		"$(js "$DISTRIB_RELEASE")" "$(js "$DISTRIB_REVISION")" "$(js "$DISTRIB_TARGET")" "$(pm)" "$n" "$(wc -l < $PF)" "$(js "$(cat $W/VERSION 2>/dev/null)")" > $MF
filelist | sed 's#^/##' > $D/create.$$.list
rm -f "$F.t"
RT_=/
if [ -n "$NS" ] && grep -qxE "${NJF#/}|${WCF#/}" $D/create.$$.list; then
rm -rf $NJR; mkdir -p $NJR && tar cf - -C / -T $D/create.$$.list 2>/dev/null | tar xf - -C $NJR 2>/dev/null && nopw "$NJR$NJF" ||
err "$(t "copia senza password delle persone non riuscita" "copy without people's passwords failed")"
notok "$NJR$WCF" || err "$(t "copia senza il token del bot non riuscita" "copy without the bot token failed")"
RT_=$NJR
fi
tar czf "$F.t" -C $RT_ -T $D/create.$$.list 2>/dev/null || { rm -f "$F.t"; err "$(t "archivio non creato" "archive not created")"; }
rm -rf $NJR
gzip -t "$F.t" 2>/dev/null || { rm -f "$F.t"; err "$(t "archivio rovinato" "corrupted archive")"; }
got=$(tar tzf "$F.t" 2>/dev/null | grep -vc '/$'); want=$(wc -l < $D/create.$$.list)
[ "$got" -ge "$want" ] || { rm -f "$F.t"; err "$(t "nell'archivio mancano dei file" "files missing from the archive") ($got/$want)"; }
tar xzf "$F.t" -O etc/wrtfreedom/backup.json >/dev/null 2>&1 || { rm -f "$F.t"; err "$(t "scheda del backup mancante" "backup manifest missing")"; }
mv "$F.t" "$F"; rm -f $D/create.$$.list
EN_=false; SE_=true
if [ -n "$PWU" ]; then
rm -f "$FO"
{ WF_BAKTMP=$D ucode $W/bakenc.uc enc "$F" "$FO" "$PWU" && WF_BAKTMP=$D ucode $W/bakenc.uc ver "$FO" "$PWU"; } >/dev/null 2>&1 ||
{ rm -f "$F" "$FO"; err "$(t "copia non cifrata" "copy not encrypted")"; }
rm -f "$F"; F=$FO; EN_=true
else case "$3" in tg|app) SE_=false ;; esac; fi
printf '{"ok":true,"file":"%s","size":%s,"files":%s,"pkgs":%s,"sha256":"%s","enc":%s,"secrets":%s}\n' "$F" "$(wc -c < "$F")" "$want" "$(wc -l < $PF)" "$(sha256sum "$F" | cut -d' ' -f1)" "$EN_" "$SE_" ;;

inspect)
[ -f "$F" ] || err "$(t "file mancante" "file missing")"
EN_=false
if isenc "$F"; then
if [ -n "$3" ] && [ -s "$3" ]; then
WF_BAKTMP=$D ucode $W/bakenc.uc dec "$F" $D/dec.$$ "$3" >/dev/null 2>&1; r_=$?
case $r_ in 0) ;; 4) errc "$(t "Password sbagliata" "Wrong password")" pass ;; *) errc "$(t "Copia cifrata non leggibile" "Encrypted copy not readable")" dec ;; esac
gzip -t $D/dec.$$ 2>/dev/null || errc "$(t "Copia cifrata non leggibile" "Encrypted copy not readable")" dec
rm -f $OP $OPI $OPK $OPN
tar xzf $D/dec.$$ -O etc/wrtfreedom/backup-pkgs.txt > $OPK 2>/dev/null
{ mv -f $D/dec.$$ $OP && sid "$F" > $OPI; } || { rm -f $OP $OPI $OPK; errc "$(t "Copia cifrata non leggibile" "Encrypted copy not readable")" dec; }
n_=$(date +%s).$$; echo "$n_" > $OPN
( sleep $OPT; [ "$(cat $OPN 2>/dev/null)" = "$n_" ] && rm -f $OP $OPN ) >/dev/null 2>&1 </dev/null &
elif ! opened "$F"; then
rm -f $OP $OPI $OPK $OPN; errc "$(t "Copia cifrata: serve la password" "Encrypted copy: password needed")" needpass
fi
F=$OP; EN_=true
fi
gzip -t "$F" 2>/dev/null && tar tzf "$F" > $D/in.list 2>/dev/null || err "$(t "il file non è un backup valido (.tar.gz rovinato o di altro tipo)" "the file is not a valid backup (corrupted or not a .tar.gz)")"
m=$(tar xzf "$F" -O etc/wrtfreedom/backup.json 2>/dev/null | head -n 1); [ -n "$m" ] || m=null
. /etc/openwrt_release 2>/dev/null
o=""; for c in $CATS; do o="$o\"$c\":0,"; done
cnt=$(sed 's#^\./##; s#/$##' $D/in.list | grep -v '^$' | while read -r p; do cat_of "/$p"; done | sort | uniq -c | awk '{printf "\"%s\":%s,", $2, $1}')
printf '{"ok":true,"size":%s,"files":%s,"cats":{%s},"manifest":%s,"now":{"model":"%s","board":"%s","release":"%s","revision":"%s"},"pending":%s,"enc":%s}\n' \
		"$(wc -c < "$F")" "$(grep -vc '/$' $D/in.list)" "$(echo "$cnt" | sed 's/,$//')" "$m" \
		"$(js "$(cat /tmp/sysinfo/model 2>/dev/null)")" "$(js "$(cat /tmp/sysinfo/board_name 2>/dev/null)")" "$(js "$DISTRIB_RELEASE")" "$(js "$DISTRIB_REVISION")" \
		"$([ -f $PEND ] && echo true || echo false)" "$EN_" ;;

restore)
C=$(echo "$3" | tr -d ' '); [ "$C" = tutte ] && C=$(for c in $CATS; do case $c in rete|wifi|accesso) ;; *) echo $c ;; esac; done | tr '\n' ',' | sed 's/,$//'); echo "$C" | grep -qE '^[a-z]+(,[a-z]+)*$' || { echo "## ERRORE $(t "categorie non valide" "invalid categories")"; exit 1; }
for c in $(echo "$C" | tr ',' ' '); do case " $CATS " in *" $c "*) ;; *) echo "## ERRORE $(t "categoria sconosciuta" "unknown category"): $c"; exit 1 ;; esac; done
if [ -f "$F" ] && isenc "$F"; then
opened "$F" || { echo "## ERRORE $(t "copia cifrata: prima scrivi la password" "encrypted copy: enter the password first")"; exit 1; }
echo restore > $OPN; OPD=1; F=$OP
fi
[ -f "$F" ] && gzip -t "$F" 2>/dev/null || { echo "## ERRORE $(t "il file di backup non è valido" "the backup file is not valid")"; exit 1; }
[ -f $PEND ] && { echo "## ERRORE $(t "c'è già un ripristino da confermare" "a restore is already waiting for confirmation")"; exit 1; }
echo "## $(t "Salvo la situazione attuale" "Saving the current state")"
sh "$0" create $PRE > $D/pre.json 2>&1; grep -q '"ok":true' $D/pre.json || { echo "## ERRORE $(t "copia della situazione attuale non riuscita: non tocco niente" "could not save the current state: nothing changed")"; exit 1; }
rm -rf $RB; select_cats $PRE "$C"
{ [ -s $D/sel.list ] && mkdir -p $RB && tar czf $RB/pre.tar.gz -C / -T $D/sel.list 2>/dev/null && gzip -t $RB/pre.tar.gz 2>/dev/null &&
echo "$C" > $RB/cats && printf '[ -f %s/id ] || { rm -rf %s; exit 0; }\nsh %s/backup.sh undo riavvio\n' $RB $RB $W > $RB/back.sh &&
echo $(( RWAIT + 30 + BAKRUN )) > $RB/lim && date +%s > $RB/id; } ||
{ rm -rf $RB; echo "## ATTENZIONE $(t "copia di sicurezza solo in memoria (spazio poco): con un riavvio prima della conferma il ripristino resta" "safety copy only in memory (little storage): a restart before confirming keeps the restore")"; }
echo "$C" > $PEND
echo "## $(t "Ripristino" "Restoring"): $(echo "$C" | sed 's/,/, /g')"
[ "$(echo "$3" | tr -d ' ')" = tutte ] && echo "## ATTENZIONE $(t "rete, Wi-Fi e accesso non ripristinati (si scelgono dall'app aggiornata)" "network, Wi-Fi and access not restored (choose them from the updated app)")"
if ! apply "$F" "$C"; then echo "## ERRORE $(t "nel backup non ci sono file di queste categorie" "the backup has no files in these categories")"; rm -rf $PEND $UNTIL $RB; exit 1; fi
echo "## $(t "File ripristinati" "Files restored"): $(wc -l < $D/sel.list)"
id=$(( $(date +%s) + RWAIT )); echo $id > $UNTIL; [ -f $RB/id ] && date +%s > $RB/id
( sleep $RWAIT; [ -f $PEND ] && [ "$(cat $UNTIL 2>/dev/null)" = "$id" ] && sh "$0" undo ) >/dev/null 2>&1 </dev/null &
echo "## OK $(t "in attesa di conferma" "waiting for confirmation")" ;;

confirm)
[ -f $PEND ] || { echo '{"ok":true,"none":true}'; exit 0; }
c=$(cat $PEND); rm -rf $PEND $UNTIL $RB
sh $W/event.sh cron restore sys "💾 Backup ¦ $(t "Ripristinato" "Restored") ¦ $(echo "$c" | sed 's/,/, /g')" >/dev/null 2>&1
echo '{"ok":true}' ;;

undo)	# ritorno del ripristino: senza conferma entro 120 s (copia in /etc, altrimenti quella in /tmp) oppure da back.sh
if [ -f $RB/id ] && [ -f $RB/pre.tar.gz ] && [ -s $RB/cats ]; then S_=$RB/pre.tar.gz; c=$(cat $RB/cats)
elif [ -s $PEND ] && [ -f $PRE ]; then S_=$PRE; c=$(cat $PEND)
else rm -rf $RB; exit 0; fi
apply $S_ "$c"; rm -rf $PEND $UNTIL $RB
if [ "$2" = riavvio ]; then m_=$(t "Backup ¦ Riavvio prima della conferma ¦ Rimesso com'era" "Backup ¦ Restart before confirming ¦ Restored")
else m_=$(t "Backup ¦ Nessuna conferma entro 120 s ¦ Rimesso com'era" "Backup ¦ No confirmation in 120 s ¦ Restored"); fi
sh $W/event.sh cron restore_undo sys "⚠️ $m_" >/dev/null 2>&1 ;;

pkgs)
[ -f "$F" ] || exit 0
if isenc "$F"; then [ -s $OPI ] && [ "$(sid "$F")" = "$(cat $OPI)" ] && cat $OPK 2>/dev/null
else tar xzf "$F" -O etc/wrtfreedom/backup-pkgs.txt 2>/dev/null; fi | grep -E '^[A-Za-z0-9._+-]+$' | while read -r p; do hasp "$p" || echo "$p"; done ;;

nopw)	[ -n "$2" ] && nopw "$2" || exit 1 ;;
notok)	[ -n "$2" ] && notok "$2" || exit 1 ;;

*)	echo "uso: backup.sh create|inspect|restore|confirm|undo|pkgs|nopw|notok"; exit 1 ;;
esac
exit 0
