#!/bin/sh
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { q=1; [ "$1" = reboot ] && q=; WF_Q=$q sh /usr/share/wrtfreedom/event.sh wd "$1" "$2" >/dev/null 2>&1; logger -t wrtfreedom-wd "$2"; }
for lb_f in /usr/share/wrtfreedom/lib.sh "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
nm() { if command -v wf_ifname >/dev/null 2>&1; then wf_ifname "$1"; else t "Linea" "Line"; fi; }
MODE=$1; MIN=60; LS=/tmp/wf-line.json; UPF=/proc/uptime; LAST=/etc/wrtfreedom/wd-last.json; NTP=/tmp/.wf-ntp; WANT=/tmp/wf-want; WL=/tmp/wf-wd.last; RC=/tmp/wf-wd.recon
CF=/etc/config/wrtfreedom; CS=/tmp/wf-wd.cfg
AG=/tmp/wf-agisce
[ -n "$WF_WDTEST" ] && [ ! -e /etc/openwrt_release ] && { MIN=${WF_WDMIN:-1}; case "$MIN" in ''|*[!0-9]*|0) MIN=1;; esac; LS=$WF_WDTEST/line.json; UPF=$WF_WDTEST/uptime; LAST=$WF_WDTEST/wd-last.json; NTP=$WF_WDTEST/ntp; WANT=$WF_WDTEST/want; WL=$WF_WDTEST/wd.last; RC=$WF_WDTEST/wd.recon; CF=$WF_WDTEST/cfg-wrtfreedom; CS=$WF_WDTEST/cfg.seen; AG=$WF_WDTEST/agisce; }
rtok() { [ -z "$(read -t 0.01 _n <&4 2>&1)" ]; }
WF=/tmp/wf-wd.fifo.$$; NF=0; rm -f "$WF"; mkfifo "$WF" 2>/dev/null && [ -p "$WF" ] && exec 4<>"$WF" && rtok && NF=1; rm -f "$WF"
nap() { s_=$(( $1 * MIN / 60 )); if [ $NF = 1 ]; then [ $s_ -gt 0 ] && read -t $s_ _n <&4; else sleep $s_; fi; }
BT=; bn=0; NT=
clk() {
bn=$((bn + 1)); read u_ _ < /proc/uptime; u_=${u_%.*}; case "$u_" in ''|*[!0-9]*) u_=0;; esac
if [ -z "$BT" ] || [ "$1" = 1 ] || [ $bn -ge 10 ] || { [ -z "$NT" ] && [ -f "$NTP" ]; }; then
bn=0; [ -f "$NTP" ] && NT=1; BT=$(( $(date +%s) - u_ ))
fi
NW=$((u_ + BT))
}
act() { printf 'wd %s\n' "$(date +%s)" > "$AG.t" && mv "$AG.t" "$AG"; }
busy5() {
if [ -f "$RC" ]; then
r_=$(date -r "$RC" +%s 2>/dev/null)
case "$r_" in ''|*[!0-9]*) ;; *) d_=$(( $(date +%s) - r_ )); [ $d_ -ge -5 ] && [ $d_ -lt 120 ] && return 0;; esac
fi
a_=; b_=; read -r a_ b_ < "$AG" 2>/dev/null; [ "$a_" = c5g ] || return 1
case "$b_" in ''|*[!0-9]*) return 1;; esac
d_=$(( $(date +%s) - b_ )); [ $d_ -ge -5 ] && [ $d_ -lt 600 ]
}
want() { mkdir -p "$WANT" && date +%s > "$WANT/$1"; }
did() { printf '%s %s\n' "$(date +%s)" "$1" > "$WL.t" && mv "$WL.t" "$WL"; }
recon() {
RI=$1; trap 'want "$RI"; ifup "$RI"; rm -f "$RC"; exit 0' INT TERM
act; echo "$1" > "$RC"; want "$1"; ifdown "$1"; nap 3; want "$1"; ifup "$1"; act; rm -f "$RC"; trap - INT TERM
did "$(t "Linea ricollegata" "Line reconnected")"
}
if [ -f "$RC" ]; then
ri=; read ri _ < "$RC" 2>/dev/null
case "$ri" in ''|*[!A-Za-z0-9_.-]*) ;; *) want "$ri"; ifup "$ri";; esac
rm -f "$RC"
fi
upt() { up=; read up _ < "$UPF"; up=${up%.*}; case "$up" in ''|*[!0-9]*) up=0;; esac; }
wanifs() { for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do [ "$(uci -q get firewall.$z.name)" = vpnout ] || uci -q get "firewall.$z.network"; done; }
lstate() {
case "$(uci -q get "network.$1.disabled")" in 1|on|true|yes|enabled) echo off; return;; esac
j=$(ifstatus "$1" 2>/dev/null)
[ "$(printf '%s' "$j" | jsonfilter -e '@.autostart' 2>/dev/null)" = false ] && { echo off; return; }
[ "$(printf '%s' "$j" | jsonfilter -e '@.pending' 2>/dev/null)" = true ] && { echo wait; return; }
u=$(printf '%s' "$j" | jsonfilter -e '@.uptime' 2>/dev/null)
case "$u" in ''|*[!0-9]*) ;; *) [ "$u" -lt $((3 * MIN)) ] && [ "$(printf '%s' "$j" | jsonfilter -e '@.up' 2>/dev/null)" = true ] && { echo wait; return; };; esac
echo go
}
foline() {
f=$(uci -q get wrtfreedom.fo.main); m=$(uci -q get wrtfreedom.fo.backup)
[ "$(uci -q get wrtfreedom.fo.enabled)" = 1 ] && [ -n "$f" ] && [ -n "$m" ] && [ "$f" != "$m" ] && echo "$f"
}
lineif() {
f=$(foline); [ -n "$f" ] && { echo "$f"; return; }
f=
for d in $(ip -4 route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p'); do
g=
for c in $(ubus call network.interface dump 2>/dev/null | jsonfilter -e "@.interface[@.l3_device=\"$d\"].interface" 2>/dev/null); do
[ "$(uci -q get "network.$c.proto")" = wireguard ] && { g=; break; }
[ -n "$g" ] || g=$c
[ -n "$(ifstatus "$c" 2>/dev/null | jsonfilter -e '@.route[@.target="0.0.0.0"].target' 2>/dev/null)" ] && { g=$c; break; }
done
[ -n "$g" ] && { f=$g; break; }
done
[ -n "$f" ] && { f=${f%_4}; echo "${f%_6}"; return; }
m=; o=
for n in $(wanifs); do
p=$(uci -q get "network.$n.proto")
case "$p" in none|dhcpv6) continue;; esac
[ "$(lstate "$n")" = off ] && { [ -n "$o" ] || o=$n; continue; }
[ -n "$f" ] || f=$n
case "$p" in modemmanager|qmi|mbim|ncm|3g|wwan|qcm) [ -n "$m" ] || m=$n;; esac
done
[ -n "$f" ] || f=$o
if [ "$MODE" = insieme ] && [ -n "$m" ]; then echo "$m"; else echo "$f"; fi
}
cg=0
cfg() {
cg=$((cg + 1))
if [ -z "$IV" ] || [ $cg -ge 10 ] || ! [ "$CF" -ot "$CS" ] || [ -e /tmp/.uci/wrtfreedom ]; then
cg=0; : > "$CS"
IV=$(uci -q get wrtfreedom.wd.interval); case "$IV" in ''|*[!0-9]*) IV=60;; esac; [ "$IV" -lt 10 ] && IV=10
H=$(uci -q get wrtfreedom.wd.hosts); [ -n "$H" ] || H="1.1.1.1 8.8.8.8"
F=$(uci -q get wrtfreedom.wd.fails); case "$F" in ''|*[!0-9]*) F=5;; esac; [ "$F" -ge 1 ] || F=5
WA=$(uci -q get wrtfreedom.wd.action); [ -n "$WA" ] || WA=reconnect
fi
A=$WA
}
check() {
ok=0; bk=0; fr=0
st=; sa=; so=; eval "$(jsonfilter -i "$LS" -e 'st=@.t' -e 'sa=@.active' -e 'so=@.ok' 2>/dev/null)"
case "$st" in ''|*[!0-9]*) st=;; esac
if [ -n "$st" ]; then sd=$((NW - st)); { [ $sd -ge 0 ] && [ $sd -lt 15 ]; } || { clk 1; sd=$((NW - st)); }; fi
[ -n "$st" ] && [ $sd -ge 0 ] && [ $sd -lt 15 ] && { fr=1; [ "$sa" = main ] || bk=1; }
if [ $fr = 1 ]; then
case "$so" in true|1) ok=1;; esac
[ $bk = 1 ] && return
else
for h in $H; do ping -c 1 -W 3 "$h" >/dev/null 2>&1 && { ok=1; break; }; done
fi
[ $ok = 0 ] && wget -q -T 6 -O /dev/null http://connectivitycheck.gstatic.com/generate_204 >/dev/null 2>&1 && ok=1
}
dur() {
if [ "$1" -lt 60 ]; then echo "$1 s"
elif [ "$1" -lt 90 ]; then t "1 minuto" "1 minute"
else m=$(( ($1 + 30) / 60 )); t "$m minuti" "$m minutes"; fi
}
bootok() {
[ "$up" -ge $((10 * MIN)) ] || return 1
[ -e "$LAST" ] || return 0
l=$(jsonfilter -i "$LAST" -e '@.t' 2>/dev/null); case "$l" in ''|*[!0-9]*) return 1;; esac
d=$((now - l))
if [ $d -lt 0 ] || [ "$(jsonfilter -i "$LAST" -e '@.ntp' 2>/dev/null)" = false ]; then [ "$up" -ge $(($1 * MIN)) ]
else [ $d -ge $(($1 * MIN)) ]; fi
}
bootsave() {
sy=false; [ -f "$NTP" ] && sy=true
mkdir -p "${LAST%/*}" && printf '{"t":%s,"ntp":%s}\n' "$now" "$sy" > "$LAST.t" && mv "$LAST.t" "$LAST" && return 0
rm -f "$LAST.t"; return 1
}
canboot() {
L=$(uci -q get wrtfreedom.wd.lastres); [ "${L:-1}" = 1 ] || return 1
bootok 360
}
fail=0
stab() { [ -n "$g0" ] || g0=$up; [ $((up - g0)) -ge $((3 * MIN)) ]; }
g0=; ff=0
if [ "$MODE" = insieme ]; then
f0=; nx=1; said=0; nl=0; sb=0; wn=0
while true; do
clk; echo $NW > /tmp/wf-batt/wd	# battito: il giro è vivo (prova di fumo, Custode), ora senza processi (clk)
cfg; check; upt; T=$((F * IV)); i=; ln=go
if [ $ok = 1 ]; then ff=0; else ff=$((ff + 1)); fi
[ $ok = 0 ] && [ -n "$g0" ] && [ $ff -lt 2 ] && { nap "$IV"; continue; }
if [ $ok = 0 ]; then
if [ $bk = 1 ]; then i=$(foline); ln=off; [ -n "$i" ] && ln=$(lstate "$i")
else i=$(lineif); [ -n "$i" ] && { nl=0; ln=$(lstate "$i"); }; fi
fi
if [ $ok = 1 ] && [ -n "$f0" ] && ! stab; then
:	# ritorno breve durante un guasto: si aspetta, nessun gradino
elif [ $ok = 1 ] || [ "$ln" = off ]; then
if [ $ok = 1 ] && [ $said = 1 ]; then
if [ $sb = 1 ]; then ev back "🌐 $(t "Linea Principale ¦ Tornata dopo" "Main Line ¦ Back after") $(dur $(( (g0 - f0) * 60 / MIN ))) ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
else ev back "🌐 Internet ¦ $(t "Tornato dopo" "Back after") $(dur $(( (g0 - f0) * 60 / MIN ))) ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"; fi
fi
f0=; nx=1; said=0; sb=0; wn=0; g0=
else
g0=; [ -n "$f0" ] || f0=$up
busy5 && { nap "$IV"; continue; }
k=$(( (up - f0) * 60 / MIN / T )); [ $k -gt 3 ] && k=$((k - k % 3))
if [ $k -ge $nx ]; then
nx=$((k + 1)); [ $k -ge 3 ] && nx=$((k + 3)); s=$(dur $((k * T)))
if [ "$ln" = wait ]; then wn=$((wn + 1)); [ $wn -ge 3 ] && ln=go; else wn=0; fi
if [ -z "$i" ]; then
[ $nl = 1 ] || { nl=1; said=1; ev noline "⚠️ $(t "Ripristino Automatico ¦ Linea non trovata ¦ Internet fermo da $s" "Automatic Recovery ¦ Line not found ¦ Internet down for $s")"; }
elif [ "$ln" = go ]; then
now=$(date +%s)
TO=; command -v timeout >/dev/null 2>&1 && TO="timeout 40"; $TO sh /usr/share/wrtfreedom/bb.sh wd >/dev/null 2>&1
if [ $bk = 0 ] && [ $((k % 3)) = 0 ] && [ $wn != 3 ] && canboot && bootsave; then
act; said=1; ev reboot "🌐 Router ¦ $(t "Lo riavvio ora" "Restarting now") ¦ $(t "Internet fermo da $s" "Internet down for $s") ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
nap 5; reboot; nap 120; continue
fi
said=1
if [ $bk = 1 ]; then sb=1; ev reconnect "🌐 $(nm "$i") ¦ $(t "Ricollegata: è la principale" "Reconnected: the main line") ¦ $(t "Senza internet da $s" "No internet for $s") ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
else ev reconnect "🌐 $(t "Linea ¦ Ricollegata" "Line ¦ Reconnected") ¦ $(t "Internet fermo da $s" "Internet down for $s") ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"; fi
recon "$i"
fi
fi
fi
nap "$IV"
done
fi
while true; do
clk; echo $NW > /tmp/wf-batt/wd	# battito: il giro è vivo (prova di fumo, Custode), ora senza processi (clk)
cfg; check
if [ $ok = 1 ]; then ff=0; else ff=$((ff + 1)); fi
[ $ok = 0 ] && [ -n "$g0" ] && [ $ff -lt 2 ] && { nap "$IV"; continue; }
if [ $ok = 1 ]; then
if [ $fail -gt 0 ]; then
upt
if stab; then
[ $fail -ge $F ] && ev back "🌐 $(t "Linea ¦ Tornata" "Line ¦ Back") ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
fail=0; g0=
fi
fi
else
g0=; fail=$((fail + 1))
if [ $fail -ge $F ]; then
if [ $bk = 1 ]; then i=$(foline); A=reconnect; [ -n "$i" ] || { fail=0; nap "$IV"; continue; }
else i=$(lineif); fi
[ -n "$i" ] && [ "$(lstate "$i")" = off ] && { fail=0; nap "$IV"; continue; }
fi
if [ $fail -eq $F ] || { [ $fail -gt $F ] && [ $(( (fail - F) % (F * 3) )) -eq 0 ]; }; then
busy5 && { fail=$((fail - 1)); nap "$IV"; continue; }
now=$(date +%s); upt
[ "$A" = reboot ] && { bootok 360 && bootsave || A=reconnect; }
[ "$A" = modem ] && [ -n "$MDT" ] && [ $((up - MDT)) -lt 3600 ] && A=reconnect
case "$A" in
modem) MDT=$up; act; ev modem "🌐 Modem ¦ $(t "Lo riavvio ora" "Restarting now") ¦ $(t "Internet fermo" "Internet down") ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
ucode /usr/share/wrtfreedom/modemctl.uc restart >/dev/null 2>&1; act; did "$(t "Modem riavviato" "Modem restarted")" ;;
reboot) act; ev reboot "🌐 Router ¦ $(t "Lo riavvio ora" "Restarting now") ¦ $(t "Internet fermo" "Internet down") ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
nap 5; reboot ;;
*) if [ $bk = 1 ]; then ev reconnect "🌐 $(nm "$i") ¦ $(t "Ricollegata: è la principale" "Reconnected: the main line") ¦ $(t "Senza internet da" "No internet for") $(dur $((fail * IV))) ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
recon "$i"; nap 120; continue; fi
ev reconnect "🌐 $(if [ -n "$i" ]; then nm "$i"; else t "Linea" "Line"; fi) ¦ $(t "Ricollegata" "Reconnected") ¦ $(t "Internet fermo" "Internet down") ¦ $(t "Dal Ripristino Automatico" "By Automatic Recovery")"
[ -n "$i" ] && recon "$i" ;;
esac
nap 120; continue
fi
fi
nap "$IV"
done
