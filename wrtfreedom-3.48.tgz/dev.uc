'use strict';
import { readfile, writefile, popen, open, stat, mkdir, rmdir, unlink, rename, lsdir } from 'fs';

const W = '/usr/share/wrtfreedom', NFF = '/usr/share/nftables.d/table-pre/91-wrtfreedom-dev.nft';
const TMP = '/tmp/wf-dev.json', ETC = '/etc/wrtfreedom/devuse.json', DAYS = '/etc/wrtfreedom/devdays.json', DP = '/tmp/wf-dpause.json', LOCK = '/tmp/wf-dev.lock';
const SEEN = '/etc/wrtfreedom/seen', SEENQ = '/tmp/wf-seen.new', SEENMAX = 100;
const PRESL = '/tmp/wf-presl', PLOG = '/etc/wrtfreedom/pres.log', SHJ = '/etc/wrtfreedom/shaper.json', SHF = '/etc/nftables.d/90-wrtfreedom.nft';
const DPE = '/etc/wrtfreedom/dpause.json', SHBAK = '/etc/wrtfreedom/shaper.bak', FWL = '/tmp/wf-fw.lock', FQ = '/tmp/wf-dev.fq', PMAX = 20000;
const THR = 120000, KEEP = 35;
const NFT = 'set wf_lan { type ifname; }\n' +
'set wf_up { type ether_addr; flags dynamic; size 1024; counter; }\n' +
'set wf_dn4 { type ipv4_addr; flags dynamic; size 4096; counter; }\n' +
'set wf_dn6 { type ipv6_addr; flags dynamic; size 4096; counter; }\n' +
'set wf_pause { type ether_addr; flags timeout; }\n' +
'set wf_pall { type ifname; flags timeout; }\n' +
'set wf_exc { type ether_addr; }\n' +
'chain wf_dev {\n' +
'\ttype filter hook forward priority filter - 2; policy accept;\n' +
'\tiifname @wf_pall ether saddr != @wf_exc drop\n' +
'\tether saddr @wf_pause drop\n' +
'}\n' +
'chain wf_cnt {\n' +
'\ttype filter hook forward priority filter + 1; policy accept;\n' +
'\tiifname @wf_lan add @wf_up { ether saddr }\n' +
'\toifname @wf_lan meta nfproto ipv4 add @wf_dn4 { ip daddr }\n' +
'\toifname @wf_lan meta nfproto ipv6 add @wf_dn6 { ip6 daddr }\n' +
'}\n';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rj(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function okmac(m) { return match(m, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) != null; }
function day(t) { let n = localtime(t); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
function hm(t) { let n = localtime(t); return n.hour * 60 + n.min; }
function arr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function ucf(name) { return UCFG.read((getenv('WF_CFGDIR') ?? '/etc/config/') + name, true); }
const WC = ucf('wrtfreedom');
const EN = (WC.ui?.lang ?? '') == 'en';
function t(it, en) { return EN ? en : it; }
function fx(s, R, w) { return (w ? '⚠️ ' : '📱 ') + join(' ¦ ', [ s, ...filter(R, (r) => length(r)) ]); }
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' dev ' + q(txt) + ' >/dev/null 2>&1 </dev/null &'); }
function gb(b) { return b < 1e9 ? sprintf(b < 1e7 ? '%.1f MB' : '%.0f MB', b / 1e6) : b >= 1e12 ? sprintf('%.1f TB', b / 1e12) : sprintf('%.1f GB', b / 1e9); }
let NM = null;
function devname(m) {
if (NM == null) {
NM = {};
let D = ucf('dhcp'), lf = '/tmp/dhcp.leases';
for (let k in D) if (D[k]['.type'] == 'dnsmasq' && length(D[k].leasefile ?? '')) lf = D[k].leasefile;
for (let l in split(readfile(lf) ?? '', '\n')) { let p = split(l, ' '); if (length(p) >= 4 && p[3] != '*') NM[lc(p[1])] = p[3]; }
for (let k in D) if (D[k]['.type'] == 'host') { let n = D[k].x3000_label || D[k].name || ''; if (length(n)) for (let x in split(lc(join(' ', arr(D[k].mac))), ' ')) NM[x] = n; }
}
return NM[m] ?? m;
}

let UB = null;
function ub(obj, m, a) {
if (UB == null) { try { UB = require('ubus').connect() ?? false; } catch (e) { UB = false; } }
if (UB) { let r = UB.call(obj, m, a ?? {}); if (r != null) return r; }
try { return json(sh('ubus call ' + obj + ' ' + m + ' 2>/dev/null') || 'null'); } catch (e) { return null; }
}
function lanifs() {
let F = ucf('firewall'), wn = {}, L = [];
for (let k in F) if (F[k]['.type'] == 'zone' && (F[k].masq == '1' || F[k].masq == 'true')) for (let n in split(join(' ', arr(F[k].network)), ' ')) if (length(n)) wn[n] = true;
for (let i in (ub('network.interface', 'dump') ?? {}).interface ?? []) {
let d = i.l3_device ?? i.device ?? '';
if (!i.up || wn[i.interface] || i.interface == 'loopback' || i.proto == 'wireguard' || !match(d, /^[A-Za-z0-9_.@-]{1,15}$/)) continue;
if (length(filter(i.route ?? [], (x) => (x.target == '0.0.0.0' || x.target == '::') && +x.mask == 0))) continue;
if (!length(i['ipv4-address'] ?? []) && !length(i['ipv6-address'] ?? []) && !length(i['ipv6-prefix-assignment'] ?? [])) continue;
if (index(L, d) < 0) push(L, d);
}
return L;
}
function elems(o) {
let J = null;
try { J = json(o); } catch (e) { return null; }
let R = null;
for (let x in J?.nftables ?? []) if (x.set) {
R = [];
for (let e in x.set.elem ?? []) { let v = e?.elem ?? e; push(R, { v: '' + (v?.val ?? v), b: +(v?.counter?.bytes ?? 0) }); }
}
return R;
}
function load() {
if (!stat(DP) && stat(DPE)) { let P = rj(DPE); if (P) wj(DP, P); }
let S = rj(TMP);
if (!S) {
let E = rj(ETC) ?? {}, A = rj(DAYS) ?? {}, Y = {}, nw = +(A.st ?? 0) > +(E.st ?? 0);
for (let k in E.days ?? {}) Y[k] = E.days[k];
for (let k in A.days ?? {}) if (nw || Y[k] == null) Y[k] = A.days[k];
S = { days: Y, q: E.q ?? {}, pb: E.pb ?? {}, ip: {}, rate: {} };
}
S.days = S.days ?? {}; S.q = S.q ?? {}; S.pb = S.pb ?? {}; S.ip = S.ip ?? {}; S.rate = S.rate ?? {};
return S;
}
function dpset(P) { wj(DP, P); mkdir('/etc/wrtfreedom'); wj(DPE, P); }
function save(S, all) {
let now = time(), d = day(now), C = {}, O = {};
S.st = now;
mkdir('/etc/wrtfreedom');
if (all || S.dd != d) {
for (let k in S.days) if (k != d) C[k] = S.days[k];
wj(DAYS, { days: C, st: now });
S.dd = d;
}
if (S.days[d]) O[d] = S.days[d];
wj(ETC, { days: O, q: S.q, pb: S.pb, st: now });
}
function qstart(d) {
if (!(d > 0)) return day(time());
let n = localtime(time()), y = n.year, m = n.mon;
if (n.mday < d) { m--; if (m < 1) { m = 12; y--; } }
return sprintf('%04d-%02d-%02d', y, m, d);
}
function used(S, mac, since, until) {
let u = 0;
for (let d in S.days) if (d >= since && (until == null || d <= until)) { let x = S.days[d][mac]; if (x) u += x[0] + x[1]; }
return u;
}
function dayok(days, t) { return !length(days) || index(days, '' + (localtime(t).wday % 7)) >= 0; }
function inslot(sl, days, now) {
let m = match(sl, /^([01][0-9]|2[0-3]):([0-5][0-9])-([01][0-9]|2[0-3]):([0-5][0-9])$/);
if (!m) return false;
let a = +m[1] * 60 + +m[2], b = +m[3] * 60 + +m[4], c = hm(now);
if (a < b) return c >= a && c < b && dayok(days, now);
return (c >= a && dayok(days, now)) || (c < b && dayok(days, now - 86400));
}

function want(S, now) {
let P = rj(DP) ?? {}, pz = {}, ps = {}, qs = {}, d = day(now), T = S.days[d] ?? {}, rmp = [], rma = null, rmd = [];
for (let m in P.d ?? {}) {
let u = +(P.d[m] ?? 0);
if (!okmac(m)) continue;
if (u > 0 && u <= now) { push(rmd, [m, P.d[m]]); ev('dev_dpause_end', fx(devname(m), [ t('Pausa internet finita', 'Internet pause ended') ])); }
else pz[m] = true;
}
for (let k in WC) {
let c = WC[k];
if (c['.type'] == 'person') {
let macs = filter(arr(c.mac), okmac), days = c.days ?? '', bud = +(c.budget ?? 0), u = 0, why = '', pu = P.p?.[k];
for (let m in macs) u += T[m]?.[2] ?? 0;
if (pu != null && pu > 0 && pu <= now) { push(rmp, [k, pu]); pu = null; }
if (pu != null) why = 'pause';
else if (length(filter(arr(c.slot), (s) => inslot(s, days, now)))) why = 'slot';
else if (bud > 0 && u >= bud && dayok(days, now)) {
why = 'budget';
if (S.pb[k] != d) { S.pb[k] = d; ev('dev_budget', fx(c.name ?? k, [ t('Tempo di oggi finito', 'Time for today is over'), t('Limite ', 'Limit ') + bud + ' min' ])); }
}
if (length(why)) for (let m in macs) pz[m] = true;
ps[k] = { used: u, why: why, until: pu };
}
else if (c['.type'] == 'quota' && okmac(c.mac ?? '') && +(c.gb ?? 0) > 0) {
let pt = '' + (c.to ?? ''), per = length(pt) > 0 && length('' + (c['from'] ?? '')) > 0;
if (per && (d < c['from'] || d > pt)) {
qs[c.mac] = { used: d < c['from'] ? 0 : used(S, c.mac, c['from'], pt), start: c['from'], over: false, blocked: false, done: d > pt };
continue;
}
let m = c.mac, st = per ? c['from'] : qstart(+(c.day ?? 0)), u = used(S, m, st), lim = +c.gb * 1e9, over = u >= lim, Q = S.q[m] ?? {};
if (Q.p != st) Q = { p: st, al: 0 };
if (over && !Q.al) {
Q.al = 1;
ev('dev_quota', fx(devname(m), [ t('Quota raggiunta', 'Quota reached'), gb(u) + ' / ' + gb(lim), c.act == 'block' ? t('Internet bloccato', 'Internet blocked') : null ]));
}
S.q[m] = Q;
let bl = over && c.act == 'block';
if (bl) pz[m] = true;
qs[m] = { used: u, start: st, over: over, blocked: bl };
}
}
let all = P.all, on = false;
if (all && all.until > 0 && all.until <= now) { rma = all; ev('dev_pause_end', fx(t('Tutta La Casa', 'Whole Home'), [ t('Pausa internet finita', 'Internet pause ended') ])); }
else if (all) on = true;
if (length(rmp) || rma || length(rmd)) {
let P2 = rj(DP) ?? {};
for (let x in rmp) if (P2.p?.[x[0]] == x[1]) delete P2.p[x[0]];
for (let x in rmd) if (P2.d?.[x[0]] == x[1]) delete P2.d[x[0]];
if (rma && P2.all?.t0 == rma.t0) P2.all = null;
dpset(P2);
}
S.ps = ps; S.qs = qs;
return { pause: keys(pz), all: on, exc: on ? filter(arr(all.except), okmac) : [] };
}
function neigh(lan, S, now, o) {
let M = {};
for (let l in split(o ?? sh('ip neigh show 2>/dev/null'), '\n')) {
let m = match(l, /^([0-9a-fA-F.:]+) dev ([^ ]+) lladdr ([0-9a-fA-F:]{17})/);
if (!m || index(lan, m[2]) < 0) continue;
let mac = lc(m[3]), ip = lc(m[1]);
if (!okmac(mac) || mac == '00:00:00:00:00:00') continue;
S.ip[ip] = [mac, now];
push(M[mac] = M[mac] ?? [], ip);
}
for (let ip in S.ip) if (now - S.ip[ip][1] > 86400) delete S.ip[ip];
return M;
}
function nftset(name, L, quote, tmo) {
let c = 'flush set inet fw4 ' + name + '\n';
if (length(L)) c += 'add element inet fw4 ' + name + ' { ' + join(', ', map(L, (x) => (quote ? '"' + x + '"' : x) + (tmo ? ' timeout 3m' : ''))) + ' }\n';
return c;
}
function gates(sf) {
let k = index(sf, '# wf:gates ');
if (k < 0) return [];
let l = substr(sf, k + 11), e = index(l, '\n'), G = null;
try { G = json(e >= 0 ? substr(l, 0, e) : l); } catch (x) {}
return type(G) == 'array' ? G : [];
}
function hhmm(s) { let m = match('' + (s ?? ''), /^([0-9]{2}):([0-9]{2})$/); return m ? +m[1] * 60 + +m[2] : 0; }
function gwin(g, t) {
if (g.u > 0 && t >= g.u) return false;
if (g.f && g.t) return inslot(g.f + '-' + g.t, g.d ?? '', t);
return dayok(g.d ?? '', t);
}
function gnext(g, now) {
let cur = gwin(g, now), n = localtime(now), C = [];
if (g.u > now) push(C, g.u);
for (let d = 0; d < 9; d++) for (let x in [hhmm(g.f), hhmm(g.t)]) {
let u = timegm({ year: n.year, mon: n.mon, mday: n.mday + d, hour: int(x / 60), min: x % 60, sec: 0 }), o = timegm(localtime(u)) - u;
o = timegm(localtime(u - o)) - (u - o);
if (u - o > now) push(C, u - o);
}
for (let c in sort(C, (a, b) => a - b)) if (gwin(g, c) != cur) return c;
return null;
}
function sync(S, D, lan, M, counters) {
let c = counters ? 'flush set inet fw4 wf_up\nflush set inet fw4 wf_dn4\nflush set inet fw4 wf_dn6\n' : '';
c += nftset('wf_lan', lan, true) + nftset('wf_pause', D.pause, false, true) + nftset('wf_pall', D.all ? lan : [], true, true) + nftset('wf_exc', D.exc);
writefile('/tmp/wf-dev.nft', c);
let ok = system('nft -f /tmp/wf-dev.nft >/dev/null 2>&1') == 0;
let sf = readfile(SHF) ?? '', s = '', now = time(), on = {}, nx = {}, sst = stat(SHF);
for (let x in match(sf, /set wfl4_([0-9a-f]+) /g) ?? []) {
let id = x[1], mac = join(':', map([0, 2, 4, 6, 8, 10], (i) => substr(id, i, 2))), ips = M[mac] ?? [];
if (length(id) == 12) s += nftset('wfl4_' + id, filter(ips, (y) => index(y, ':') < 0)) + nftset('wfl6_' + id, filter(ips, (y) => index(y, ':') >= 0));
}
for (let g in gates(sf)) {
let a = gwin(g, now), i = '' + g.i, ips = a && g.m ? (M[g.m] ?? []) : [];
if (on[i] == null) { on[i] = a; nx[i] = gnext(g, now); }
if (g.c) { s += nftset('wfti_' + g.n, a ? lan : [], true, true); continue; }
if (!okmac(g.m ?? '')) continue;
s += nftset('wft4_' + g.n, filter(ips, (y) => index(y, ':') < 0), false, true) + nftset('wft6_' + g.n, filter(ips, (y) => index(y, ':') >= 0), false, true) +
nftset('wftm_' + g.n, a ? [g.m] : [], false, true);
}
S.shp = { t: now, f: sst ? sst.mtime : null, on: on, next: nx };
if (length(s)) { writefile('/tmp/wf-dev.shp.nft', s); if (system('nft -f /tmp/wf-dev.shp.nft >/dev/null 2>&1') != 0) ok = false; }
if (ok) S.nfe = 0;
else if ((length(D.pause) || D.all || length(s)) && index(sh('nft list tables 2>/dev/null'), 'table inet fw4') >= 0) S.nfe = (S.nfe ?? 0) + 1;
if (S.nfe == 3) ev('dev_nft', fx(t('Pause e Limiti', 'Pauses and Limits'), [ t('Non aggiornati nel firewall', 'Not updated in the firewall') ], true));
return ok;
}
function fwlock() {
for (let i = 0; i < 60; i++) {
if (mkdir(FWL)) return true;
let s = stat(FWL);
if (s && time() - s.mtime > 120) rmdir(FWL); else sh('sleep 1');
}
return false;
}
function shback() {
if (stat('/sbin/fw4') && !fwlock()) return;
let B = rj(SHBAK);
if (type(B) == 'object') {
if (B.nft != null) writefile(SHF, B.nft); else unlink(SHF);
if (B.json != null) writefile(SHJ, B.json); else unlink(SHJ);
}
unlink(SHBAK);
if (!stat('/sbin/fw4')) return;
if (system('fw4 check >/dev/null 2>&1') != 0) unlink(SHF);
sh('/etc/init.d/firewall reload >/dev/null 2>&1');
rmdir(FWL);
}
function setup() {
if (!stat('/sbin/fw4')) return { error: 'serve firewall4' };
if (readfile(NFF) == NFT) return { ok: true, changed: false };
if (!fwlock()) return { error: 'firewall occupato' };
sh("mkdir -p '" + substr(NFF, 0, rindex(NFF, '/')) + "'");
let old = readfile(NFF);
writefile(NFF, NFT);
if (system('fw4 check >/dev/null 2>&1') != 0) { if (old != null) writefile(NFF, old); else unlink(NFF); rmdir(FWL); return { error: 'fw4 check' }; }
sh('/etc/init.d/firewall reload >/dev/null 2>&1');
rmdir(FWL);
return { ok: true, changed: true };
}
function seenflush() {
if (!stat(SEENQ) || !rename(SEENQ, SEENQ + '.f')) return;
let L = filter(split(readfile(SEEN) ?? '', '\n'), (l) => length(trim(l))), H = {}, n = length(L), K = [], q = 0;
for (let l in L) H[split(trim(l), ' ')[0]] = true;
for (let l in split(readfile(SEENQ + '.f') ?? '', '\n')) { let m = split(trim(l), ' ')[0]; if (okmac(m) && !H[m]) { H[m] = true; push(L, m + ' ?'); } }
for (let i = length(L) - 1; i >= 0; i--) if (!match(L[i], / \?$/) || ++q <= SEENMAX) unshift(K, L[i]);
if (length(L) > n) { mkdir('/etc/wrtfreedom'); writefile(SEEN + '.t', length(K) ? join('\n', K) + '\n' : ''); rename(SEEN + '.t', SEEN); }
unlink(SEENQ + '.f');
}
function presflush(S, now) {
seenflush();
if (stat(PRESL) && rename(PRESL, PRESL + '.f')) {
let o = readfile(PRESL + '.f'), f = null;
mkdir('/etc/wrtfreedom');
if (length(o) && (f = open(PLOG, 'a'))) { f.write(o); f.close(); }
unlink(PRESL + '.f');
}
let st = stat(PLOG), lim = now - 60 * 86400, old = false;
if (st && st.size <= PMAX * 32 && now - (+S.ptrim || 0) >= 7 * 86400) {
S.ptrim = now;
let t0 = +split(readfile(PLOG, 64) ?? '', ' ')[0];
old = t0 > 0 && t0 < lim;
}
if (st && (old || st.size > PMAX * 32)) {
delete S.prot;
let L = filter(split(readfile(PLOG) ?? '', '\n'), length), K = filter(L, (l) => +split(l, ' ')[0] >= lim);
if (length(K) > PMAX * 3 / 4) K = slice(K, length(K) - int(PMAX * 3 / 4));
if (length(K) < length(L)) { writefile(PLOG + '.t', length(K) ? join('\n', K) + '\n' : ''); rename(PLOG + '.t', PLOG); }
}
S.pt = now;
}
function lock(wait) {
let lk = mkdir(LOCK);
for (let i = 0; !lk && i < wait; i++) { sh('sleep 1'); lk = mkdir(LOCK); }
if (!lk) { let s = stat(LOCK); if (s && time() - s.mtime < 300) return false; rmdir(LOCK); lk = mkdir(LOCK); }
return lk;
}
function adgyaml() {
let s = false, u = {};
for (let l in split(readfile('/etc/config/adguardhome') ?? '', '\n')) {
if (match(l, /^[ \t]*config[ \t]/)) { s = match(l, /^[ \t]*config[ \t]+[^ \t]+[ \t]+['"]?config['"]?[ \t]*$/) != null; continue; }
let m = s ? match(l, /^[ \t]*option[ \t]+(config_file|config)[ \t]+['"]?([^'"]{1,255})/) : null;
if (m) u[m[1]] = trim(m[2]);
}
for (let f in [ u.config_file, u.config ]) if (length(f) && stat(f)) return f;
let c = stat('/tmp/wf-adgyaml'), y = c ? trim(readfile('/tmp/wf-adgyaml') ?? '') : '';
if (y == '-' && time() - c.mtime < 60) return null;
if (length(y) && y != '-' && time() - c.mtime < 600 && stat(y)) return y;
y = trim(sh('sh /usr/share/wrtfreedom/lib.sh adgyaml 2>/dev/null'));
return length(y) && stat(y) ? y : null;
}
function adgaddr(y, home) {
let f = false, a = '', bh = '', bp = '';
for (let l in split(y ? (readfile(y) ?? '') : '', '\n')) {
if (match(l, /^[^ \t#]/)) {
f = substr(l, 0, 5) == 'http:';
let m = match(l, /^bind_host:[ \t]*['"]?([^'" \t]*)/);
if (m) bh = replace(m[1], /^\[(.*)\]$/, '$1');
m = match(l, /^bind_port:[ \t]*['"]?([0-9]+)/);
if (m) bp = m[1];
continue;
}
let m = (f && !length(a)) ? match(l, /^[ \t]+address:[ \t]*['"]?([^'" \t]*)/) : null;
if (m) a = m[1];
}
let m = length(a) ? (match(a, /^\[(.*)\]:([0-9]+)$/) ?? match(a, /^(.*):([0-9]+)$/)) : [ null, bh, bp ];
if (!m || !match(m[2] ?? '', /^[0-9]+$/)) return '';
let h = m[1];
if (h == '' || h == '0.0.0.0' || h == '::') h = home == null ? '127.0.0.1' : home;
if (!length(h)) return '';
return (index(h, ':') >= 0 ? '[' + h + ']' : h) + ':' + m[2];
}
function adgforget(mac) {
let cred = trim(readfile('/etc/wrtfreedom/adguard') ?? '');
if (!length(cred)) return true;
let a = adgaddr(adgyaml()), K = '/tmp/.wf-adgf';
if (!length(a)) return false;
sh('umask 077; rm -f ' + K + '; : > ' + K);
writefile(K, 'user = "' + replace(cred, /[\\"]/g, (m) => '\\' + m) + '"\n');
let c = 'curl -s -m 8 -K ' + K + ' ', u = 'http://' + a + '/control/', J = null, ok = true;
try { J = json(sh(c + u + 'clients 2>/dev/null') || 'null'); } catch (e) {}
if (type(J) != 'object') ok = false;
for (let x in J?.clients ?? []) {
let ids = x.ids ?? [], rest = filter(ids, (i) => lc('' + i) != mac);
if (length(rest) == length(ids)) continue;
let body = length(rest) ? { name: x.name, data: { ...x, ids: rest } } : { name: x.name };
let r = sh(c + "-o /dev/null -w '%{http_code}' -X POST -H 'Content-Type: application/json' --data " + q(sprintf('%J', body)) + ' ' + u + 'clients/' + (length(rest) ? 'update' : 'delete') + ' 2>/dev/null');
if (trim(r) != '200') ok = false;
}
unlink(K);
return ok;
}
function forgetmac(S, mac) {
for (let d in S.days) delete S.days[d][mac];
delete S.q[mac]; delete S.rate[mac];
for (let ip in S.ip) if (S.ip[ip][0] == mac) delete S.ip[ip];
for (let f in [PRESL, PLOG]) if (stat(f)) { let K = filter(split(readfile(f) ?? '', '\n'), (l) => length(l) && split(l, ' ')[1] != mac); writefile(f + '.t', length(K) ? join('\n', K) + '\n' : ''); rename(f + '.t', f); }
save(S, true);
return adgforget(mac);
}
function fqadd(mac, n) { let f = open(FQ, 'a'); if (f) { f.write(mac + ' ' + n + '\n'); f.close(); } }
function fqrun(S) {
if (!stat(FQ) || !rename(FQ, FQ + '.w')) return;
let L = split(readfile(FQ + '.w') ?? '', '\n');
unlink(FQ + '.w');
for (let l in L) {
let p = split(trim(l), ' '), n = +(p[1] ?? 0);
if (okmac(p[0]) && !forgetmac(S, p[0]) && n < 4) fqadd(p[0], n + 1);
}
}

function shexp(S, now) {
let R = rj(SHJ), X = [], c = '', W = S.shxd ?? {}, ids = {};
if (type(R) != 'array') R = [];
for (let r in R) {
let id = '' + (r?.id ?? '');
if (type(r) != 'object' || !(+(r.until ?? 0) > 0) || !match(id, /^[A-Za-z0-9_]{1,32}$/)) continue;
let u = int(+r.until), w = '' + (r.who ?? '');
ids[id] = true;
if (W[id]?.u != u) W[id] = { u: u, e: 0, n: r.casa === true ? t('Tutta la casa', 'The whole house') : substr(w, 0, 2) == 'p:' ? (WC[substr(w, 2)]?.name ?? substr(w, 2)) : devname(lc('' + (r.mac ?? r.macs?.[0] ?? ''))) };
if (u <= now) push(X, id);
}
for (let id in keys(W)) {
if (W[id].u <= now && !W[id].e) { W[id].e = 1; ev('dev_slow_end', fx(W[id].n, [ t('Di nuovo veloce', 'Back to full speed') ])); }
if (!ids[id]) delete W[id];
}
S.shxd = W;
if (!length(X) || now - (S.shx ?? 0) < 300) return;
S.shx = now;
for (let id in X) c += 'ubus call wrtfreedom shaper ' + q(sprintf('%J', { del: id })) + '; ';
sh('( ' + c + ') >/dev/null 2>&1 </dev/null &');
}
function resetuse(S, mac) {
if (mac == 'all') { S.days = {}; S.qs = {}; }
else if (okmac(mac)) { for (let d in S.days) delete S.days[d][mac]; if (S.qs) delete S.qs[mac]; }
else return;
save(S, true);
}
function monthly(n) {
if (!length(WC.tg?.token ?? '') || !length(WC.tg?.chat ?? '')) return;
if (!(n >= 1 && n <= 10)) n = 5;
let S = load(), now = time(), x = localtime(now), y = x.year, m = x.mon, part = x.mday != 1, B = {}, tot = 0, first = null, T = [];
if (!part) { m--; if (m < 1) { m = 12; y--; } }
let pre = sprintf('%04d-%02d-', y, m), G = (b) => { let v = sprintf('%.1f', b / 1e9); return (EN ? v : replace(v, '.', ',')) + ' GB'; };
for (let d in S.days) if (substr(d, 0, 8) == pre) {
if (first == null || d < first) first = d;
for (let k in S.days[d]) { let v = S.days[d][k]; B[k] = (B[k] ?? 0) + v[0] + v[1]; tot += v[0] + v[1]; }
}
let L = sort(keys(B), (a, b) => B[b] - B[a]), mesi = EN ? ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] :
['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
let mn = mesi[m - 1];
push(T, '📊 ' + t('Consumo Di ', 'Usage In ') + uc(substr(mn, 0, 1)) + substr(mn, 1));
push(T, length(L) ? G(tot) + (part ? t(' fino a oggi', ' so far') : t(' in tutto', ' in total')) : t('Nessun consumo contato', 'No usage counted'));
for (let i = 0; i < length(L) && i < n; i++) push(T, (i + 1) + '. ' + devname(L[i]) + ' · ' + G(B[L[i]]));
if (first != null && first > pre + '01') push(T, t('Contato dal giorno ', 'Counted from day ') + +substr(first, 8, 2));
mkdir('/tmp/wf-tgq');
writefile('/tmp/wf-tgq/' + now + '-mo', join('\n', T));
sh('( ucode ' + W + '/tgq.uc flush ) </dev/null >/dev/null 2>&1 &');
}

let cmd = ARGV[0];
if (cmd == 'setup') { print(setup(), '\n'); exit(0); }
if (cmd == 'monthly') { monthly(+(ARGV[1] ?? 5)); exit(0); }
if (cmd == 'remove') {
if (stat(NFF) && fwlock()) { unlink(NFF); sh('/etc/init.d/firewall reload >/dev/null 2>&1'); rmdir(FWL); }
exit(0);
}
if (index(['tick', 'apply', 'save', 'forget', 'reset'], cmd) < 0) { print('uso: dev.uc setup | remove | tick | apply | save | forget <mac> | reset <mac|all> | monthly <quanti>\n'); exit(1); }
if (!lock(cmd == 'tick' ? 0 : 10)) {
let mac = lc('' + (ARGV[1] ?? ''));
if (cmd == 'forget' && okmac(mac)) fqadd(mac, 0);
if (cmd == 'save') save(load());
exit(0);
}
let S = load(), now = time();

if (cmd == 'save') {
let up = int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])), o = '';
for (let f in lsdir('/tmp/wf-pres') ?? []) {
let p = split(trim(readfile('/tmp/wf-pres/' + f) ?? ''), ' ');
if (match(f, /^[0-9a-f]{12}$/) && p[0] == 'on' && up - +p[1] < 240) o += now + ' ' + join(':', map([0, 2, 4, 6, 8, 10], (i) => substr(f, i, 2))) + ' 0\n';
}
if (length(o)) { let f = open(PRESL, 'a'); if (f) { f.write(o); f.close(); } }
presflush(S, now); wj(TMP, S); save(S); rmdir(LOCK); exit(0);
}

fqrun(S);
if (cmd == 'forget') {
let mac = lc('' + (ARGV[1] ?? ''));
if (okmac(mac) && !forgetmac(S, mac)) fqadd(mac, 1);
cmd = 'apply';
}
if (cmd == 'reset') { resetuse(S, lc('' + (ARGV[1] ?? ''))); cmd = 'apply'; }

let lan = lanifs();
if (cmd == 'apply') {
let M = neigh(lan, S, now);
let D = want(S, now);
sync(S, D, lan, M, false);
wj(TMP, S);
rmdir(LOCK);
exit(0);
}

let o = sh("for s in wf_up wf_dn4 wf_dn6; do nft -j list set inet fw4 $s 2>/dev/null || echo null; echo '@@WF@@'; done; ip neigh show 2>/dev/null"), p = split(o, '@@WF@@\n');
let U = elems(p[0]), D4 = elems(p[1]), D6 = elems(p[2]);
let M = neigh(lan, S, now, p[3]);
if (U == null) {
if (now - (S.setupAt ?? 0) > 3600) { S.setupAt = now; setup(); }
S.t = null;
}
else {
let d = day(now), T = S.days[d] = S.days[d] ?? {}, B = {};
for (let e in U) { let m = lc(e.v); if (okmac(m)) { B[m] = B[m] ?? [0, 0]; B[m][1] += e.b; } }
for (let e in [...(D4 ?? []), ...(D6 ?? [])]) {
let m = S.ip[lc(e.v)]?.[0];
if (m) { B[m] = B[m] ?? [0, 0]; B[m][0] += e.b; }
}
let dt = S.t ? now - S.t : 60, dm = int((dt + 30) / 60);
if (dm < 1) dm = 1;
if (dm > 5) dm = 5;
S.rate = {};
for (let m in B) {
let x = T[m] = T[m] ?? [0, 0, 0], b = B[m][0] + B[m][1];
x[0] += B[m][0]; x[1] += B[m][1];
if (b >= THR * dm) x[2] += dm;
if (b > 0) S.rate[m] = [int(B[m][0] / (dt > 0 ? dt : 60)), int(B[m][1] / (dt > 0 ? dt : 60))];
}
S.t = now;
let K = sort(keys(S.days));
while (length(K) > KEEP) delete S.days[shift(K)];
}
let Dw = want(S, now);
sync(S, Dw, lan, M, U != null);
shexp(S, now);
let sb = stat(SHBAK);
if (sb && now - sb.mtime > 120) shback();
if (!S.pt || now - S.pt >= 3600) presflush(S, now);
if (!S.st || now - S.st >= 3600) save(S);
wj(TMP, S);
rmdir(LOCK);
