#!/bin/sh
CL_R=; [ -n "$WF_CLOUDROOT" ] && [ ! -e /etc/openwrt_release ] && CL_R=$WF_CLOUDROOT
CL_ETC=$CL_R/etc/wrtfreedom; CL_CJ=$CL_ETC/cloud.json; CL_T=/tmp/wf-cloud; CL_W=$CL_R/usr/share/wrtfreedom
CL_PROC=/proc; [ -n "$CL_R" ] && CL_PROC=$CL_R/proc
CL_EVERY=${CL_EVERY:-60}
_cl_dir() { [ -d $CL_T ] || { mkdir -p $CL_T && chmod 700 $CL_T; }; }

cl_tier() {
_clv=$(cat $CL_T/tier 2>/dev/null)
case "$_clv" in A|B|C) echo "$_clv"; return 0 ;; esac
_clm=$(awk '/^MemTotal:/ { print $2; exit }' $CL_PROC/meminfo 2>/dev/null)
_clc=$(grep -c '^processor' $CL_PROC/cpuinfo 2>/dev/null)
if [ "${_clm:-0}" -lt 786432 ]; then _clv=A
else
case "$(uname -m 2>/dev/null)" in
x86_64|i?86) _clv=C ;;
*) if [ "${_clc:-0}" -lt 4 ]; then _clv=A; else _clv=B; fi ;;
esac
fi
_cl_dir; echo "$_clv" > $CL_T/tier.$$ && mv $CL_T/tier.$$ $CL_T/tier
echo "$_clv"
}
CL_MUC='let J = null; try { J = json(require("fs").readfile(getenv("CL_J")) ?? ""); } catch (e) {}
function n(v) { return type(v) == "int" && v >= 0; }
function p(v) { return type(v) == "int" && v >= 1024; }
let s = type(J) == "object" ? J.serv?.[getenv("CL_S")] : null, now = time();
if (type(s) != "object" || !n(J.t) || now - J.t > 180 || J.t - now > 60 || !p(s.tetto) || !n(J.avail) || !n(J.ris)) exit(1);
let cg = type(s.cg) == "string" && match(s.cg, /^\/[A-Za-z0-9\/._-]+$/) ? s.cg : "";
printf("CL_TET=%d CL_GO=%d CL_MIN=%d CL_AV=%d CL_RIS=%d CL_SOTTO=%d CL_CG=%s\n", int(s.tetto / 1024),
	int((p(s.go) ? s.go : s.tetto * 4 / 5) / 1024), int((n(s.min) ? s.min : 0) / 1024), J.avail, J.ris, n(J.sotto) ? J.sotto : 0, cg);'
_clmk=; _clmt=0; _clmr=1; _clmo=
cl_mem() {
CL_TET=; CL_GO=; CL_MIN=; CL_AV=; CL_RIS=; CL_SOTTO=0; CL_CG=
[ -f "$CL_R/tmp/wf-mem.json" ] || { _clmk=; return 1; }
_clmn=$(date +%s)
if [ "$_clmk" != "$1" ] || [ $((_clmn - _clmt)) -ge 30 ] || [ $((_clmn - _clmt)) -lt 0 ]; then
_clmo=$(CL_J=$CL_R/tmp/wf-mem.json CL_S=$1 ucode -e "$CL_MUC" 2>/dev/null); _clmr=$?
_clmk=$1; _clmt=$_clmn
fi
[ "$_clmr" = 0 ] || return 1
eval "$_clmo"
case "$CL_TET$CL_GO$CL_MIN$CL_AV$CL_RIS$CL_SOTTO" in ''|*[!0-9]*) CL_TET=; CL_CG=; return 1 ;; esac
case "$CL_CG" in
*..*) CL_CG= ;;
"$CL_R"/sys/fs/cgroup/wrtfreedom/rclone|"$CL_R"/sys/fs/cgroup/wrtfreedom/rclonepush) ;;
*) CL_CG= ;;
esac
[ -n "$CL_CG" ] && [ ! -w "$CL_CG/cgroup.procs" ] && CL_CG=
true
}
cl_in() {
[ -n "$CL_CG" ] || return 0
{ echo 0 > "$CL_CG/cgroup.procs"; echo 400 > /proc/self/oom_score_adj; } 2>/dev/null
true
}
_cl_lowm() { [ $((CL_AV - CL_RIS)) -lt $((CL_TET * 1024)) ]; }
_cl_lowf() {
[ "$(cl_tier)" = A ] || return 1
_clm=$(awk '/^MemAvailable:/ { print $2; exit }' $CL_PROC/meminfo 2>/dev/null)
[ "${_clm:-0}" -lt 153600 ]
}
cl_low() {
cl_mem rclonepush && { _cl_lowm; return; }
_cl_lowf
}
_cl_v170() {
_clr=$(cat $CL_T/rclone.ver 2>/dev/null); _clr1=${_clr%%.*}; _clr2=${_clr#*.}; _clr2=${_clr2%%.*}
case "$_clr1.$_clr2" in .*|*.|*[!0-9.]*) return 1 ;; esac
[ "$_clr1" -gt 1 ] || { [ "$_clr1" -eq 1 ] && [ "$_clr2" -ge 70 ]; }
}
_cl_p2() { _clp2=1; while [ $((_clp2 * 2)) -le "$1" ]; do _clp2=$((_clp2 * 2)); done; }
cl_env() {
CL_CHUNK=; CL_RMEM=; CL_MOK=
if [ "$(cl_tier)" = A ]; then _clb=1 _clx=1 _clk=2; else _clb=4 _clx=2 _clk=4; fi
case "$1" in drive|box) _clpz=8 ;; onedrive) _clpz=10 ;; s3) _clpz=20 ;; dropbox) _clpz=48 ;; b2) _clpz=384 ;; *) _clpz=0 ;; esac
_clv=; _cl_v170 && _clv=1; _clf=
if cl_mem rclonepush; then
CL_MOK=1
_cln=0; [ -n "$CL_CG" ] && _cln=$(grep -c . "$CL_CG/cgroup.procs" 2>/dev/null)
case "$_cln" in ''|*[!0-9]*) _cln=0 ;; esac
_cll=$((CL_TET / (_cln + 1))); [ "$_cll" -ge "$CL_MIN" ] || _cll=$CL_MIN; [ "$_cll" -ge 32 ] || _cll=32
export GOMEMLIMIT=$((_cll * 4 / 5))MiB
_clr=$((_cll * 3 / 5 - 16)); [ $_clr -ge 4 ] || _clr=4
if [ $_clr -ge 32 ]; then _clq=4; elif [ $_clr -ge 16 ]; then _clq=2; else _clq=1; fi
[ $_clq -ge $_clb ] || _clb=$_clq
[ $_clr -ge 16 ] || _clk=2
_cl_lowm && { _clx=1; export GOGC=50; }
[ $_clx -gt 1 ] && [ $((_clx * (_clpz + _clb))) -gt $_clr ] && _clx=1
_clc=$(( (_clr - _clx * _clb) / _clx )); [ $_clc -ge 1 ] || _clc=1
if [ $_clpz -gt $_clc ]; then
case "$1" in
dropbox) _cl_p2 $_clc; [ $_clp2 -ge 4 ] || _clp2=4; CL_CHUNK=${_clp2}M; _clf="--dropbox-chunk-size $CL_CHUNK" ;;
drive) _cl_p2 $_clc; CL_CHUNK=${_clp2}M; _clf="--drive-chunk-size $CL_CHUNK" ;;
onedrive) if [ $_clc -ge 5 ]; then CL_CHUNK=5M; else CL_CHUNK=2560k; fi; _clf="--onedrive-chunk-size $CL_CHUNK" ;;
s3) _clu=$((_clc / 5)); [ $_clu -ge 1 ] || _clu=1; _clf="--s3-upload-concurrency $_clu" ;;
b2) if [ -n "$_clv" ]; then
_clu=$((_clc / 96))
if [ $_clu -ge 1 ]; then _clf="--b2-upload-concurrency $_clu"
else _cl_p2 $_clc; [ $_clp2 -ge 8 ] || _clp2=8; CL_CHUNK=${_clp2}M; _clf="--b2-chunk-size $CL_CHUNK --b2-upload-concurrency 1"; fi
else _cl_p2 $((_clc / 4)); [ $_clp2 -ge 8 ] || _clp2=8; CL_CHUNK=${_clp2}M; _clf="--b2-chunk-size $CL_CHUNK"; fi ;;
esac
fi
[ "$CL_TET" -lt 64 ] && _clf="${_clf:+$_clf }--multi-thread-streams 1"
[ -n "$_clv" ] && _clf="${_clf:+$_clf }--max-buffer-memory $((_clr > 8 ? _clr - 4 : 4))M"
elif _cl_lowf; then
CL_CHUNK=16M; export GOGC=20
case "$1" in dropbox|b2) _clf="--$1-chunk-size $CL_CHUNK" ;; esac
fi
CL_RMEM="--buffer-size ${_clb}M --transfers $_clx --checkers $_clk${_clf:+ $_clf}"
export CL_CHUNK CL_RMEM CL_MOK; true
}
cl_why() {
case "$1" in
pause) echo 'Pausa Cloud|Cloud paused' ;;
net) echo 'Internet non raggiungibile|Internet unreachable' ;;
sim) echo 'Aspetta la linea fissa|Waiting for the fixed line' ;;
simask) echo 'Scegli quanto usare la SIM|Choose how much SIM to use' ;;
hours) echo 'Aspetta le ore della SIM|Waiting for the SIM hours' ;;
cap) echo 'Tetto della SIM raggiunto|SIM cap reached' ;;
fix) echo 'Riparte dopo 30 minuti di linea fissa|Resumes after 30 minutes on the fixed line' ;;
slot|queue) echo 'In coda|Queued' ;;
acct) echo 'Account occupato|Account busy' ;;
mem) echo 'Memoria del router quasi finita|Router memory almost full' ;;
stop) echo 'Fermato|Stopped' ;;
*) echo 'In attesa|Waiting' ;;
esac
}

CL_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv;
function rj(p) { try { return json(fs.readfile(p) ?? 'null'); } catch (e) { return null; } }
/* cifre lette una per una («08» e «09» mai come numeri in base 8) */
function dn(s) { let v = 0; for (let i = 0; i < length(s); i++) v = v * 10 + ord(s, i) - 48; return v; }
function mins(s) { let m = match('' + s, /^([0-9][0-9]):([0-9][0-9])$/); if (!m) return null; return dn(m[1]) * 60 + dn(m[2]); }
function inh(a, b, h) { a = mins(a); b = mins(b); if (a == null || b == null) return false; return a <= b ? (h >= a && h < b) : (h >= a || h < b); }
let C = rj(E('CL_CJ')) ?? {}, now = time(), hm = mins(E('CL_HMV')) ?? 0, dev = E('CL_DEV') ?? '', T = E('CL_T'), day = E('CL_DAY');
let N = null; try { N = json(E('CL_NET') || '{}'); } catch (e) { N = null; }
if (type(N) != 'object') N = {};
let P = C.pause ?? {}, Ln = C.line ?? {};
if (P.on === true && (!(+(P.until ?? 0) > 0) || +P.until > now)) { print('wait pause\n'); exit(0); }
let up = +(Ln.bw_up ?? 0), down = +(Ln.bw_down ?? 0);
for (let b in (type(Ln.bw_at) == 'array' ? Ln.bw_at : [])) if (type(b) == 'object' && inh(b.from, b.to, hm)) { up = +(b.up ?? 0); down = +(b.down ?? 0); break; }
let bw = (up > 0 || down > 0) ? (up > 0 ? int(up) + 'k' : 'off') + ':' + (down > 0 ? int(down) + 'k' : 'off') : 'off';
if (!length(dev)) { print('wait net\n'); exit(0); }
let D = null; try { D = json(fs.stdin.read('all') ?? ''); } catch (e) { D = null; }
let proto = '';
for (let i in (D?.interface ?? [])) if (i.l3_device == dev || i.device == dev) { proto = '' + (i.proto ?? ''); break; }
let L = rj('/tmp/wf-line.json'), U = rj('/tmp/wf-usage.json');
let sim = match(proto, /^(modemmanager|qmi|mbim|ncm|3g|qcm|wwan)$/) != null || (U?.mobile === true && U.dev == dev) ||
	(L?.active == 'backup' && (!length(L.dev ?? '') || L.dev == dev));
/* linea di prima: «tipo da_quando dalla_SIM» in T/line (solo quando cambia) */
let st = split(trim(fs.readfile(T + '/line') ?? ''), ' '), k = sim ? 'sim' : 'fix';
if (st[0] != k) {
	st = [ k, '' + now, st[0] == 'sim' ? '1' : '0' ];
	let t = T + '/line.' + E('CL_PID');
	fs.writefile(t, join(' ', st) + '\n'); fs.rename(t, T + '/line');
}
let r = N.mode == 'own' ? N : (Ln.sim ?? {}), max = 0;
function simno() {
	if (N.mode == 'fixed') return 'sim';
	if (r.gb == null) return 'simask';
	if (r.all !== true && !inh(r.from ?? '01:00', r.to ?? '07:00', hm)) return 'hours';
	if (+r.gb > 0) {
		let cap = int(+r.gb * 1e9), u = split(trim(fs.readfile(T + '/sim.day') ?? fs.readfile(E('CL_ETC') + '/cloud-sim.day') ?? ''), ' ');
		let used = u[0] == day ? +(u[1] ?? 0) : 0;
		if (used >= cap) return 'cap ' + r.gb + ' ' + (r.all === true ? '00:00' : (r.from ?? '01:00'));
		max = cap - used;
	}
	return null;
}
if (sim) { let w = simno(); print(w ? 'wait ' + w + '\n' : 'ok ' + bw + ' ' + max + ' sim\n'); exit(0); }
if (st[2] == '1' && now - +st[1] < 1800 && simno() != null) { print('wait fix\n'); exit(0); }
print('ok ' + bw + ' 0 fix\n');
ucode
)
_cl_hm() { if [ -n "$CL_R" ] && [ -n "$WF_CLHM" ]; then echo "$WF_CLHM"; else date +%H:%M; fi; }
_cl_ev() {
_clf=$CL_T/once.$1; _cln=$(date +%s); _cll=$(cat $_clf 2>/dev/null)
[ -n "$_cll" ] && [ $((_cln - _cll)) -lt "$2" ] && return 0
echo "$_cln" > $_clf
[ -f $CL_W/event.sh ] && sh $CL_W/event.sh cron "$1" cloud "$3" </dev/null >/dev/null 2>&1
true
}
_cl_en() { [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ]; }
cl_check() {
_cl_dir
_cld=$(ip route get 1.1.1.1 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n 1)
[ -n "$_cld" ] || _cld=$(ip -6 route get 2606:4700:4700::1111 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n 1)
_clo=$( { [ -n "$_cld" ] && ubus call network.interface dump 2>/dev/null; } |
CL_DEV=$_cld CL_NET=${2:-} CL_HMV=$(_cl_hm) CL_DAY=$(date +%Y%m%d) CL_CJ=$CL_CJ CL_T=$CL_T CL_ETC=$CL_ETC CL_PID=$$ ucode -e "$CL_UC" 2>/dev/null)
[ -n "$_clo" ] || _clo='wait net'
set -- $_clo
CL_BW=off; CL_MAX=0; CL_LINE=; CL_WHY=
if [ "$1" = ok ]; then
CL_BW=$2 CL_MAX=$3 CL_LINE=$4
echo "$_clo"; return 0
fi
CL_WHY=$2
case "$2" in
simask) if _cl_en; then _clx='📶 Cloud ¦ Choose how much SIM to use ¦ jobs are waiting'; else _clx='📶 Cloud ¦ Scegli quanto usare la SIM ¦ i lavori aspettano'; fi
_cl_ev cloud_simask 21600 "$_clx" ;;
cap) _clg=$(echo "$3" | sed 's/\.0*$//')
if _cl_en; then _clx="📶 Cloud ¦ SIM cap reached ¦ $_clg GB: resumes at $4"; else _clx="📶 Cloud ¦ Tetto della SIM raggiunto ¦ $(echo "$_clg" | tr . ,) GB: riprende alle $4"; fi
_cl_ev cloud_simcap 21600 "$_clx" ;;
esac
echo "wait $2"; return 1
}
cl_add() {
case "$1" in ''|*[!0-9]*) return 0 ;; esac
_cl_dir
_cli=0; until mkdir $CL_T/simday.lock 2>/dev/null; do
_cli=$((_cli + 1)); [ $_cli -ge 5 ] && { rm -rf $CL_T/simday.lock; continue; }; sleep 1
done
_cly=$(date +%Y%m%d)
_clu=$(cat $CL_T/all.day 2>/dev/null)
_clb=${_clu#* }; [ "${_clu%% *}" = "$_cly" ] && [ -n "$_clb" ] && [ "$_clb" != "$_clu" ] || _clb=0
echo "$_cly $((_clb + $1))" > $CL_T/all.day.$$ && mv $CL_T/all.day.$$ $CL_T/all.day
[ "$(cut -d' ' -f1 $CL_T/line 2>/dev/null)" = sim ] || { rmdir $CL_T/simday.lock 2>/dev/null; return 0; }
[ -f $CL_T/sim.day ] || cp $CL_ETC/cloud-sim.day $CL_T/sim.day 2>/dev/null
_clu=$(cat $CL_T/sim.day 2>/dev/null)
_clb=${_clu#* }; [ "${_clu%% *}" = "$_cly" ] && [ -n "$_clb" ] && [ "$_clb" != "$_clu" ] || _clb=0
echo "$_cly $((_clb + $1))" > $CL_T/sim.day.$$ && mv $CL_T/sim.day.$$ $CL_T/sim.day
rmdir $CL_T/simday.lock 2>/dev/null
if [ $(( $(date +%s) - $(date -r $CL_ETC/cloud-sim.day +%s 2>/dev/null || echo 0) )) -ge 1800 ]; then
mkdir -p $CL_ETC && cp $CL_T/sim.day $CL_ETC/cloud-sim.day.t && mv $CL_ETC/cloud-sim.day.t $CL_ETC/cloud-sim.day
fi
true
}
cl_kill() {
_clk=$1; [ -n "$_clk" ] || return 0
_cla=$(cat /proc/[0-9]*/stat 2>/dev/null | awk -v r="$_clk" '
		{ s = $0; if (!sub(/^.*\) /, "", s)) next; split(s, f, " "); n++; c[n] = $1; pp[n] = f[2] }
		END { k[r] = 1; o = r; g = 1
			while (g) { g = 0; for (i = 1; i <= n; i++) if ((pp[i] in k) && !(c[i] in k)) { k[c[i]] = 1; o = o " " c[i]; g = 1 } }
			print o }')
[ -n "$_cla" ] || _cla=$_clk
for _clp in $_cla; do kill -TERM "$_clp" 2>/dev/null; done
true
}
cl_tick() {
_clnow=$(date +%s)
[ -f $CL_T/jobs/$2.stop ] && { CL_STOP=stop; cl_kill "$1"; return 1; }
[ $((_clnow - ${_cltl:-0})) -lt "$CL_EVERY" ] && return 0
_cltl=$_clnow
cl_check "$2" "$3" >/dev/null && return 0
CL_STOP=$CL_WHY; cl_kill "$1"; return 1
}
_cl_alive() { kill -0 "$1" 2>/dev/null && ! grep -q '^[0-9]* (.*) Z ' /proc/$1/stat 2>/dev/null; }
cl_watch() {
CL_STOP=; _cltl=$(date +%s)
while _cl_alive "$1"; do
sleep 1
cl_tick "$@" || return 1
done
true
}
