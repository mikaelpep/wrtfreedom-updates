import { stat, readfile, writefile, unlink } from 'fs';

const W = getenv('WF_TICKDIR') ?? '/usr/share/wrtfreedom', ERR = getenv('WF_TICKERR') ?? '/tmp/wf-tick.err', CUR = getenv('WF_TICKCUR') ?? '/tmp/wf-tick.cur';
const MODS = /^(usage|fwstat|dev|health|custode|sms|sighist|vpnctl|wgx|cbs|wifi|sqm|nas|nasdl|nasf|mem)$/, ARG = /^[a-z]{1,16}$/;
const NASFN = { nas: 'watch', nasdl: 'tick', nasf: 'logtick', mem: 'tick' };
const DEF = { sms: 'refresh', cbs: 'refresh' };
const FINE = 'wf-tick-exit';

function errore(m, e) {
let R = {};
for (let l in split(readfile(ERR) ?? '', '\n')) { let x = match(l, /^([a-z]+): /); if (x && x[1] != m) R[x[1]] = l; }
R[m] = m + ': ' + substr(replace('' + (e?.message ?? e), /[\r\n]+/g, ' '), 0, 200);
writefile(ERR, join('\n', values(R)) + '\n');
}

const CALL = type(call) == 'function' ? call : null, LF = {};
function prog(f) { if (!LF[f]) LF[f] = loadfile(f); return LF[f]; }
function inc(f, S) { if (CALL) CALL(prog(f), null, S); else include(f, S); }

const NR = getenv('WF_TICKNAS') ?? '/tmp/wf-nas', NFP = [ (getenv('WF_CFGDIR') ?? '/etc/config/') + 'minidlna', (getenv('WF_NASETC') ?? '/etc/wrtfreedom') + '/nas.json' ];
function nasfidle() {
let J = null;
try { J = json(readfile(NR + '/logc.json') ?? ''); } catch (e) { return false; }
if (type(J) != 'object' || type(J.p) != 'array' || !length(J.p) || length(J.act ?? {})) return false;
let d = localtime(), P = map(J.p, (v) => '' + v);
if (J.day != sprintf('%04d-%02d-%02d', d.year, d.mon, d.mday)) return false;
let fp = join(',', map(NFP, (f) => { let s = stat(f); return s ? s.mtime + ':' + s.size : '-'; })), now = time();
let F = split(trim(readfile(NR + '/logtick.fp') ?? ''), ' '), ft = +(F[1] ?? '');
if (F[0] != fp || !(ft <= now && now - ft < 300)) { writefile(NR + '/logtick.fp', fp + ' ' + now + '
'); return false; }
for (let f in [ '/proc/net/tcp', '/proc/net/tcp6' ])
for (let l in split(readfile(f) ?? '', '\n')) {
let x = split(trim(l), /[ \t]+/);
if (length(x) >= 4 && x[3] == '01' && index(P, '' + hex(split(x[1], ':')[1] ?? '')) >= 0) return false;
}
return true;
}

function run(m, args) {
let f = W + '/' + m + '.uc';
if (!stat(f)) return true;
if (m == 'nasf' && nasfidle()) return true;
if (NASFN[m]) {
try { let N = prog(f)(), fn = N?.[NASFN[m]]; if (type(fn) == 'function') fn(); }
catch (e) { errore(m, e); return false; }
return true;
}
let S = proto({ ARGV: args, exit: (c) => die(FINE) }, global);
try { inc(f, S); }
catch (e) { if ((e?.message ?? '') != FINE) { errore(m, e); return false; } }
return true;
}

function fastck(a) {
let f = W + '/fastck.uc', R = null;
if (!stat(f)) return null;
let S = proto({ ARGV: a, RES: (x) => { R = x; }, exit: (c) => die(FINE) }, global);
try { inc(f, S); }
catch (e) { if ((e?.message ?? '') != FINE) { errore('fastck', e); return null; } }
return R;
}

let L = [ ...ARGV ];
if (index(L, 'custode.fast') >= 0 && index(L, 'mem') < 0) unshift(L, 'mem');
let ko = 0;
for (let a in L) {
let p = split('' + a, '.'), m = shift(p);
if (!match(m, MODS) || length(filter(p, (x) => !match(x, ARG)))) continue;
if (!length(p)) p = [ DEF[m] ?? 'tick' ];
writefile(CUR, a + '\n');
let fk = m == 'custode' && length(p) == 1 && p[0] == 'fast' ? fastck([ 'pre' ]) : null;
if (fk?.skip === true) continue;
if (!run(m, p)) ko++;
if (fk && type(fk.fp) == 'string') fastck([ 'post', fk.fp ]);
try { gc(); } catch (e) {}
}
unlink(CUR);
exit(ko ? 1 : 0);
