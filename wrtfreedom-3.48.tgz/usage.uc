'use strict';
import { readfile, writefile, popen, stat, mkdir, rmdir, rename } from 'fs';

const TMP = '/tmp/wf-usage.json', ETC = '/etc/wrtfreedom/usage.json', W = '/usr/share/wrtfreedom', LOCK = '/tmp/wf-usage.lock';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
let UO = null;
function uo(sec, opt) {
if (UO == null) {
UO = {};
let s = null;
for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1]; continue; }
let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
if (m && UO[s + '.' + m[1]] == null) UO[s + '.' + m[1]] = m[2];
}
}
return UO[sec + '.' + opt] ?? '';
}
function load(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
const EN = uo('ui', 'lang') == 'en';
function t(it, en) { return EN ? en : it; }
function gb(b) { return sprintf('%.1f GB', b / 1e9); }

function linedev() {
let L = filter(split(trim(sh("uci -q show network | sed -n \"s/^network\\.\\([A-Za-z0-9_]*\\)\\.proto='\\(modemmanager\\|qmi\\|mbim\\|ncm\\|3g\\|wwan\\)'$/\\1/p\"")), '\n'), length);
for (let i in L) {
let d = trim(sh('ifstatus ' + q(i) + ' 2>/dev/null | jsonfilter -e "@.l3_device" 2>/dev/null'));
if (length(d)) return { dev: d, iface: i, mobile: true };
}
for (let l in split(readfile('/proc/net/route') ?? '', '\n')) { let f = split(l, '\t'); if (f[1] == '00000000' && f[7] == '00000000') return { dev: f[0], iface: '', mobile: false }; }
return null;
}
function cycle(day) {
let n = localtime(time()), d = +day || 1;
let dim = (y, m) => m == 2 ? ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0 ? 29 : 28) : (m == 4 || m == 6 || m == 9 || m == 11 ? 30 : 31);
let start = (y, m) => { let last = dim(y, m); return sprintf('%04d-%02d-%02d', y, m, d > last ? last : d); };
let y = n.year, m = n.mon, s = start(y, m);
if (n.mday < +substr(s, 8, 2)) { m--; if (m < 1) { m = 12; y--; } s = start(y, m); }
let ny = +substr(s, 0, 4), nm = +substr(s, 5, 2) + 1;
if (nm > 12) { nm = 1; ny++; }
return { s: s, next: start(ny, nm) };
}

let cmd = ARGV[0], lk = false;
if (cmd == 'tick') {
lk = mkdir(LOCK);
if (!lk) { let s = stat(LOCK); if (s && time() - s.mtime < 300) exit(0); rmdir(LOCK); lk = mkdir(LOCK); if (!lk) exit(0); }
}
if (cmd == 'unslow') {
lk = mkdir(LOCK);
for (let i = 0; !lk && i < 10; i++) { sh('sleep 1'); lk = mkdir(LOCK); }
}
function done(c) { if (lk) rmdir(LOCK); exit(c); }
function slowsh(a) { sh('( sh ' + W + '/slow.sh ' + a + ' ) >/dev/null 2>&1 </dev/null &'); }
let S = load(TMP) ?? load(ETC) ?? { rx: 0, tx: 0, hist: [], since: time() };
let day = uo('usage', 'day') || '1', quota = +(uo('usage', 'quota') || '0') * 1e9, warn = +(uo('usage', 'warn') || '80');
let now = time(), CY = cycle(day), cyc = CY.s;

if (cmd == 'tick') {
if (!S.dev || !S.devt || now - S.devt > 600) { let L = linedev(); if (L) { S.dev = L.dev; S.iface = L.iface; S.mobile = L.mobile; } S.devt = now; }
if (!S.dev) done(0);
let b = '/sys/class/net/' + S.dev + '/statistics/', rx = +trim(readfile(b + 'rx_bytes') ?? '0'), tx = +trim(readfile(b + 'tx_bytes') ?? '0');
let renew = S.cyc && S.cyc != cyc;
if (renew) { unshift(S.hist, { from: S.cyc, rx: S.rx, tx: S.tx }); S.hist = slice(S.hist, 0, 6); S.rx = 0; S.tx = 0; S.al = 0; S.unslow = 0; }
S.cyc = cyc; S.next = CY.next;
let lt = localtime(now), dd = sprintf('%04d-%02d-%02d', lt.year, lt.mon, lt.mday);
if (S.dd != dd) { S.dd = dd; S.db = 0; }
if (S.ldev == S.dev && S.lrx != null && rx >= S.lrx && tx >= S.ltx) { S.rx += rx - S.lrx; S.tx += tx - S.ltx; S.db += rx - S.lrx + tx - S.ltx; }
S.ldev = S.dev; S.lrx = rx; S.ltx = tx; S.t = now;
let used = S.rx + S.tx;
let sdl = int(+uo('usage', 'slowdl') || 0), sul = int(+uo('usage', 'slowul') || 0), sv = sdl + '/' + sul;
let simq = uo('sim', 'auto') == '1' && uo('sim', 'onquota') == '1' && +(load('/tmp/wf-sim.json')?.slots ?? 0) >= 2;
let at = +uo('usage', 'slowat') == 90 ? 90 : 100, son = uo('usage', 'slow') == '1';
let cfgv = (son ? 1 : 0) + '/' + sv + '/' + at;
if (S.slowcfg != null && S.slowcfg != cfgv) S.unslow = 0;
S.slowcfg = cfgv;
let want = son && quota > 0 && used >= quota * at / 100 && !S.unslow && !simq && (sdl > 0 || sul > 0);
if (quota > 0) {
if (used >= quota && (S.al ?? 0) < 2) { S.al = 2; sh((want ? 'WF_Q=1 ' : '') + 'sh ' + W + '/event.sh cron usage_full net ' + q('📊 ' + t('Consumo Della SIM', 'SIM Usage') + ' ¦ ' + t('Giga dell\'offerta finiti', 'Data plan used up') + ' ¦ ' + gb(used) + ' / ' + gb(quota)) + ' >/dev/null 2>&1'); }
else if (used >= quota * warn / 100 && (S.al ?? 0) < 1) { S.al = 1; sh('sh ' + W + '/event.sh cron usage_warn net ' + q('📊 ' + t('Consumo Della SIM', 'SIM Usage') + ' ¦ ' + t('Usato il', 'Used') + ' ' + warn + '% ' + t('dei giga', 'of the data plan') + ' ¦ ' + gb(used) + ' / ' + gb(quota)) + ' >/dev/null 2>&1'); }
}
let retry = now - +(S.slowtry ?? 0) >= 120;
if (want && retry && (!S.slow || S.slowv != sv || !stat('/tmp/wf-slow.on'))) {
S.slow = S.slow || now; S.slowv = sv; S.slowtry = now;
slowsh('on ' + sdl + ' ' + sul + ' ' + q(S.dev) + ' ' + (S.mobile ? 1 : 0));
}
else if (!want && retry && (S.slow || stat('/etc/wrtfreedom/slow'))) { S.slow = 0; S.slowv = ''; S.slowtry = now; slowsh('off ' + (renew ? 'renew' : 'cfg')); }
writefile(TMP, sprintf('%J', S));
if (!S.st || now - S.st > 3600) cmd = 'save';
}
if (cmd == 'reset') { S.rx = 0; S.tx = 0; S.al = 0; S.since = now; cmd = 'save'; }
if (cmd == 'unslow') { S.unslow = 1; if (S.slow || stat('/etc/wrtfreedom/slow')) { S.slow = 0; S.slowv = ''; S.slowtry = now; slowsh('off app'); } cmd = 'save'; }
if (cmd == 'save') {
if (!S.cyc) done(0);
S.st = now;
writefile(TMP, sprintf('%J', S));
let P = { cyc: S.cyc, next: S.next, rx: S.rx, tx: S.tx, al: S.al ?? 0, hist: S.hist ?? [], st: now, since: S.since ?? now, slow: S.slow ?? 0, slowv: S.slowv ?? '', unslow: S.unslow ?? 0, slowcfg: S.slowcfg, dd: S.dd ?? '', db: S.db ?? 0 };
mkdir('/etc/wrtfreedom');
writefile(ETC + '.t', sprintf('%J', P)); rename(ETC + '.t', ETC);
done(0);
}
if (cmd != 'tick') { print('uso: usage.uc tick|save|reset|unslow\n'); exit(1); }
done(0);
