#!/bin/sh
#% stato|Stato|Status|📊
#% linea|Linea e Modem|Line and Modem|🌐
#% wifi|Wi-Fi|Wi-Fi|📶
#% dev|Dispositivi|Devices|📱
#% vpn|VPN|VPN|🔐
#% dns|AdGuard e DNS|AdGuard and DNS|🔒
#% diag|Diagnostica|Diagnostics|🧰
#% sys|Sistema|System|⚙️
#% nas|NAS|NAS|🗄️
#@ stato|status|stato|d||Riepilogo: linea, IP, carico, dispositivi|Summary: line, IP, load, devices||
#@ uptime|uptime|stato|||Da quanto è acceso il router|How long the router has been on||
#@ carico|load|stato|||Carico e uso del processore|Processor load and usage||
#@ memoria|memory|stato|||Memoria usata e libera|Used and free memory||
#@ disco|disk|stato|||Spazio su memoria interna e dischi|Space on internal storage and drives||
#@ temperatura|temperature|stato||thermal|Temperatura del router|Router temperature||
#@ salute|health|stato|||Salute del router: stato, processore, memoria, temperatura e spazio|Router health: status, processor, memory, temperature and storage||
#@ ventola|fan|stato|o|fan|Ventola: livello e scelta, con i pulsanti per cambiarla|Fan: level and setting, with buttons to change it|automatica, silenziosa, fresca o massima (facoltativo)|automatic, quiet, cool or max (optional)
#@ versione|version|stato|||Modello, firmware e versioni|Model, firmware and versions||
#@ ip|ip|stato|d||Indirizzo IP della linea e pubblico|Line and public IP address||
#@ ipv6|ipv6|stato|||Indirizzi IPv6 della linea|Line IPv6 addresses||
#@ velocita|speed|stato|||Velocità della linea in questo momento|Line speed right now||
#@ consumo|usage|stato|||Dati usati nel periodo dell'offerta, come nell'app|Data used in the plan period, as in the app||
#@ ora|time|stato|||Data, ora e fuso orario del router|Router date, time and time zone||
#@ linea|line|linea|||Stato della connessione internet|Internet connection status||
#@ riconnetti|reconnect|linea|c||Riconnette la linea internet|Reconnects the internet line||
#@ segnale|signal|linea||modem|Qualità del segnale mobile|Mobile signal quality||
#@ cella|cell|linea||modem|Cella a cui è collegato il modem|Cell the modem is connected to||
#@ bande|bands|linea||modem|Bande in uso e abilitate|Bands in use and enabled||
#@ operatore|operator|linea||modem|Operatore e tecnologia|Operator and technology||
#@ rete_mobile|mobile_network|linea||modem|Tecnologia, banda e canale|Technology, band and channel||
#@ sim|sim|linea||modem|Stato della SIM|SIM status||
#@ imei|imei|linea||modem|IMEI del modem|Modem IMEI||
#@ riavvia_modem|restart_modem|linea|c|modem|Riavvia il modem|Restarts the modem||
#@ solo4g|lte_only|linea|c|modem|Modem solo in 4G|Modem in 4G only||
#@ standard|standard|linea|c|modem|Modem in 4G + 5G NSA|Modem in 4G + 5G NSA||
#@ celle|cells|linea||modem|Celle vicine|Nearby cells||
#@ temp_modem|modem_temp|linea||modem|Temperatura del modem|Modem temperature||
#@ apn|apn|linea||modem|APN configurati nel modem|APNs set in the modem||
#@ sms|sms|linea||modem|SMS ricevuti sulla SIM|SMS received on the SIM||
#@ at|at|linea|a|modem|Legge dal modem con un comando AT|Reads from the modem with an AT command|Comando AT di lettura (es. AT+CSQ)|Read-only AT command (e.g. AT+CSQ)
#@ sqm|line_control|linea||sqm|SQM: stato e limiti|SQM: status and limits||
#@ sqm_on|line_control_on|linea||sqm|Accende lo SQM|Turns SQM on||
#@ sqm_off|line_control_off|linea|c|sqm|Spegne lo SQM|Turns SQM off||
#@ sqm_profilo|line_control_profile|linea|a|sqm|Profilo dello SQM|SQM profile|prudente, bilanciato, veloce, spento o un profilo per orario|cautious, balanced, fast, off or a scheduled profile
#@ sqm_prova|line_control_test|linea|c|sqm|Prova Prima e Dopo: il voto della linea senza e con lo SQM (circa 250 MB)|Before and After Test: the line grade without and with SQM (about 250 MB)||
#@ wifi|wifi|wifi|d|wifi|Reti Wi-Fi e dispositivi collegati|Wi-Fi networks and connected devices||
#@ wifi_on|wifi_on|wifi|d|wifi|Accende il Wi-Fi|Turns Wi-Fi on||
#@ wifi_off|wifi_off|wifi|cd|wifi|Spegne il Wi-Fi|Turns Wi-Fi off||
#@ wifi_riavvia|wifi_restart|wifi|c|wifi|Riavvia il Wi-Fi|Restarts Wi-Fi||
#@ ospiti|guest|wifi||guest|Stato della rete ospiti|Guest network status||
#@ ospiti_on|guest_on|wifi||guest|Accende la rete ospiti|Turns the guest network on||
#@ ospiti_off|guest_off|wifi|c|guest|Spegne solo la rete ospiti|Turns only the guest network off||
#@ password_wifi|wifi_password|wifi|of|wifi,curl|Nome e password delle reti|Network names and passwords|Nome della rete (facoltativo)|Network name (optional)
#@ qr_wifi|wifi_qr|wifi|of|wifi,qr,curl|QR per collegarsi al Wi-Fi|QR code to join Wi-Fi|Nome della rete (facoltativo)|Network name (optional)
#@ canali|channels|wifi||wifi|Reti vicine per canale|Nearby networks by channel||
#@ segnale_wifi|wifi_signal|wifi||wifi|Segnale dei dispositivi in Wi-Fi|Signal of Wi-Fi devices||
#@ potenza|tx_power|wifi||wifi|Canale e potenza delle radio|Radio channel and power||
#@ client|clients|dev|d||Dispositivi collegati|Connected devices||
#@ online|online|dev|||Dispositivi attivi adesso|Devices active right now||
#@ nuovi|new|dev|||Ultimi dispositivi nuovi|Latest new devices||
#@ cerca|find|dev|a||Cerca un dispositivo|Finds a device|Nome, IP o MAC|Name, IP or MAC
#@ dettagli|details|dev|a||Dettagli di un dispositivo|Device details|Nome, IP o MAC|Name, IP or MAC
#@ blocca|block|dev|ca||Blocca internet a un dispositivo|Blocks internet for a device|Nome, IP o MAC|Name, IP or MAC
#@ sblocca|unblock|dev|a||Sblocca un dispositivo|Unblocks a device|Nome, IP o MAC|Name, IP or MAC
#@ client_bloccati|blocked_clients|dev|||Dispositivi bloccati|Blocked devices||
#@ disconnetti|kick|dev|ca|hostapd|Scollega un dispositivo dal Wi-Fi|Kicks a device off Wi-Fi|Nome, IP o MAC|Name, IP or MAC
#@ sveglia|wake|dev|a|wol|Wake-on-LAN: accende un computer dalla rete|Wake-on-LAN: wakes a computer over the network|Nome o MAC|Name or MAC
#@ top_client|top_clients|dev|||Chi ha consumato più dati|Who used the most data||
#@ fasce|time_slots|dev|||Orari e velocità: limiti e fasce di oggi|Schedules and speed: limits and slots for today||
#@ limita|limit|dev|a||Limita la velocità di un dispositivo|Limits the speed of a device|Nome e Mbit/s (es. TV 20), off per togliere|Name and Mbit/s (e.g. TV 20), off to remove
#@ rallenta|slow_down|dev|a||Rallenta per qualche minuto un dispositivo, una persona o la casa|Slows down a device, a person or the house for a while|Nome, Mbit/s e minuti (es. TV 10 60), off per togliere|Name, Mbit/s and minutes (e.g. TV 10 60), off to remove
#@ ip_fissi|static_ips|dev|||Indirizzi IP riservati|Reserved IP addresses||
#@ vpn|vpn|vpn|d|wg|Stato del Server VPN|VPN Server status||
#@ vpn_on|vpn_on|vpn|d|wg|Accende il Server VPN|Turns the VPN Server on||
#@ vpn_off|vpn_off|vpn|cd|wg|Spegne il Server VPN|Turns the VPN Server off||
#@ vpn_riavvia|vpn_restart|vpn|c|wg|Riavvia il Server VPN|Restarts the VPN Server||
#@ vpn_peer|vpn_peers|vpn||wg|Chi è collegato al Server VPN|Who is connected to the VPN Server||
#@ vpn_traffico|vpn_traffic|vpn||wg|Dati scambiati da ogni dispositivo|Data used by each device||
#@ vpn_qr|vpn_qr|vpn|af|wg,qr,curl|QR di un dispositivo del Server VPN|QR code of a VPN Server device|Nome del dispositivo|Device name
#@ vpn_nuovo|vpn_new|vpn|af|wg,qr,curl|Aggiunge un dispositivo al Server VPN con QR|Adds a device to the VPN Server with QR|Nome del nuovo dispositivo|New device name
#@ vpn_indirizzo|vpn_address|vpn||wg|Indirizzo e porta per collegarsi|Address and port to connect||
#@ servizio_vpn|vpn_service|vpn|o|vpnsvc|Client VPN: stato, on o off|VPN Client: status, on or off|on oppure off (facoltativo)|on or off (optional)
#@ adguard|adguard|dns||adg|Stato e statistiche di AdGuard Home|AdGuard Home status and stats||
#@ adg_on|adg_on|dns||adg|Accende la protezione|Turns protection on||
#@ adg_off|adg_off|dns|c|adg|Spegne la protezione|Turns protection off||
#@ pausa|pause|dns|a|adg|Pausa di AdGuard Home|Pauses AdGuard Home|Minuti di pausa|Minutes to pause
#@ top_bloccati|top_blocked|dns||adg|Domini più bloccati|Most blocked domains||
#@ top_domini|top_domains|dns||adg|Domini più richiesti|Most requested domains||
#@ top_client_dns|top_dns_clients|dns||adg|Dispositivi con più richieste|Devices with the most requests||
#@ filtri|filters|dns||adg|Liste di blocco attive|Active blocklists||
#@ risolvi|resolve|dns|a||Risolve un nome di dominio|Resolves a domain name|Dominio (es. google.com)|Domain (e.g. google.com)
#@ dns_svuota|dns_flush|dns|||Svuota la cache DNS|Clears the DNS cache||
#@ dns_server|dns_servers|dns|||Server DNS usati dal router|DNS servers used by the router||
#@ ping|ping|diag|a||Ping verso un indirizzo|Pings an address|Indirizzo o nome|Address or name
#@ traceroute|traceroute|diag|a|trace|Percorso verso un indirizzo|Route to an address|Indirizzo o nome|Address or name
#@ latenza|latency|diag|||Latenza verso gateway e internet|Latency to gateway and internet||
#@ speedtest|speedtest|diag|||Test di velocità della linea|Line speed test||
#@ porte|ports|diag|||Porte aperte verso i dispositivi|Ports forwarded to devices||
#@ interfacce|interfaces|diag|||Tutte le reti e i loro indirizzi|All networks and their addresses||
#@ route|routes|diag|||Tabella dei percorsi|Routing table||
#@ ddns|ddns|diag||ddns|Stato del DDNS|DDNS status||
#@ ddns_aggiorna|ddns_update|diag||ddns|Aggiorna subito i nomi DDNS|Updates the DDNS names now||
#@ nat|nat|diag|||Verifica NAT e CGNAT della linea|Checks the line for NAT and CGNAT||
#@ connessioni|connections|diag||conntrack|Connessioni aperte|Open connections||
#@ porta|port|diag|a|curl|Prova se una porta risponde|Tests whether a port answers|Indirizzo e porta (es. 1.1.1.1 443)|Address and port (e.g. 1.1.1.1 443)
#@ riavvia|reboot|sys|cd||Riavvia il router|Restarts the router||
#@ riavvia_rete|restart_network|sys|c||Riavvia tutte le reti|Restarts all networks||
#@ log|log|sys|||Ultime righe del registro|Latest log lines||
#@ errori|errors|sys|||Errori e avvisi nel registro|Errors and warnings in the log||
#@ processi|processes|sys|||Programmi che usano più risorse|Programs using the most resources||
#@ servizi|services|sys|||Servizi attivi e fermi|Running and stopped services||
#@ servizio|service|sys|ca||Riavvia un servizio|Restarts a service|Nome del servizio|Service name
#@ aggiornamenti|updates|sys|||Pacchetti da aggiornare|Packages to update||
#@ aggiorna_pacchetto|update_package|sys|c||Aggiorna il Pacchetto Router dal server|Updates the Router Package from the server||
#@ backup|backup|sys|f|curl|Manda qui il backup delle impostazioni|Sends the settings backup here||
#@ eventi|events|sys|d||Ultimi eventi del router|Latest router events||
#@ usb|usb|sys|||Dispositivi USB collegati|Connected USB devices||
#@ cron|cron|sys|||Operazioni pianificate|Scheduled tasks||
#@ certificati|certificates|sys||acme|Certificati: scadenza e rinnovo|Certificates: expiry and renewal||
#@ libera_ram|free_ram|sys|||Libera la memoria cache|Frees cached memory||
#@ sincronizza_ora|sync_time|sys|||Rimette l'orologio con internet|Syncs the clock with the internet||
#@ menu|menu|sys|l||Pulsanti dei comandi per categoria|Command buttons by category||
#@ aiuto|help|sys|l||Elenco dei comandi|List of commands||
#@ espelli|eject|nas|co|nas|Espelle il disco in sicurezza, con conferma|Safely ejects the disk, with confirmation|Nome del disco (se ce n'è più di uno)|Disk name (if there is more than one)
#@ rimuovi|remove_disk|nas|co|nas|Nome di prima di /espelli: espelle il disco, con conferma|Old name of /eject: ejects the disk, with confirmation|Nome del disco (se ce n'è più di uno)|Disk name (if there is more than one)
#@ scansiona|scan|nas||nas|Server Multimediale: cerca i file nuovi della libreria|Media Server: looks for new files in the library||
#@ tv|tv|nas|o|nas|Server Multimediale: cosa guarda la TV, film da finire, Pausa e Riprendi|Media Server: what the TV is playing, films to finish, Pause and Resume|pausa, riprendi o film (facoltativo)|pause, resume or film (optional)
#@ scarica|download|nas|a|nas|Scarica un link sul disco del NAS|Downloads a link to the NAS disk|Link (http, https o magnet)|Link (http, https or magnet)
#@ backup_nas|nas_backup|nas|co|nas|Avvia un Backup del NAS o un Backup Cloud, con conferma|Starts a NAS backup or a Cloud backup, with confirmation|Nome del backup (se ce n'è più di uno)|Backup name (if there is more than one)
#@ cloud|cloud|nas|o||Stato del Cloud: account, spazio, ultimo backup, SIM e coda|Cloud status: accounts, space, last backup, SIM and queue|pausa, riprendi o backup (facoltativo)|pause, resume or backup (optional)
#@ cloud_pausa|cloud_pause|nas|co||Pausa Cloud: ferma backup e sincronizzazioni, con conferma|Cloud Pause: stops backups and syncs, with confirmation|Ore di pausa (vuoto = fino a Riprendi)|Hours of pause (empty = until Resume)
#@ cloud_riprendi|cloud_resume|nas|c||Fa ripartire il Cloud dopo la Pausa, con conferma|Restarts the Cloud after the Pause, with confirmation||
#@ nas|nas|nas|o|nas|Stato del NAS: motivo, Adesso, spazio, utenti, download e servizi|NAS status: reason, Now, space, users, downloads and services|pausa o riprendi i download (facoltativo)|pause or resume downloads (optional)
#@ pausa_download|pause_downloads|nas|o|nas|Mette in pausa tutti i download del NAS, con Riprendi|Pauses all NAS downloads, with Resume|riprendi per farli ripartire (facoltativo)|resume to restart them (optional)
#@ cerca_file|find_file|nas|af|nas,curl|Cerca un file sul NAS e lo manda qui (fino a 50 MB)|Finds a file on the NAS and sends it here (up to 50 MB)|Nome del file (almeno 2 lettere)|File name (at least 2 letters)

W=/usr/share/wrtfreedom
for lb_f in "$W/lib.sh" "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
A=$(printf '%s' "$ARG" | tr -d '\r\n' | sed 's/^ *//; s/ *$//')
OWN=${WF_OWN:-admin}; ASJ=
case "$OWN" in admin) ;; *) printf '%s' "$OWN" | grep -qE '^[a-z][a-z0-9]{0,19}$' && ASJ=",\"as\":\"$OWN\"" || OWN=invalid ;; esac
LOG=/tmp/wf-events.log	# 2.94: sempre in RAM (copia sulla memoria interna dal Custode)

hb() { awk -v b="${1:-0}" 'BEGIN{split("B KB MB GB TB",u," ");i=1;while(b>=1024&&i<5){b/=1024;i++}if(i==1)printf "%.1f KB",b/1024;else printf "%.1f %s",b,u[i]}'; }
lmax() { awk -v n="$1" -v t="$(t "E altri" "And")" -v u="$(t "" " more")" 'NR <= n {print; next} END {if (NR > n) printf "%s %d%s\n", t, NR - n, u}'; }
dur() { awk -v s="${1:-0}" -v d="$(t g d)" 'BEGIN{s=int(s);x=int(s/86400);h=int(s%86400/3600);m=int(s%3600/60);if(x)printf "%d%s %dh %dm",x,d,h,m;else if(h)printf "%dh %dm",h,m;else printf "%dm %ds",m,s%60}'; }
export EN
J() { ucode -e "let EN=getenv('EN')=='1'; let d=null; try { d=json(require('fs').stdin.read('all')||'null'); } catch(e) { exit(0); } if(d==null) exit(0); $1" 2>/dev/null; }
get() { if command -v curl >/dev/null 2>&1; then curl -s -m "${2:-15}" "$1"; else uclient-fetch -q -T "${2:-15}" -O - "$1"; fi 2>/dev/null; }
wanifs() { for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do [ "$(uci -q get firewall.$z.name)" = vpnout ] || uci -q get "firewall.$z.network"; done | tr ' ' '\n' | grep -v '^$'; }	# zona internet vera (con il NAT)
wgif() { l_=$(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); for i in $l_; do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; for i in $l_; do echo "$i"; return; done; }
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
ifip() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null; }
wanip() { for i in $(wanifs); do a_=$(ifip "$i"); [ -n "$a_" ] && { echo "$a_"; return; }; done; }	# la prima linea con un IP
wandevs() { for i in $(wanifs); do ifstatus "$i" 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null; done | sort -u; }
pubip() { get https://api.ipify.org 8 | grep -oE '^[0-9.]+$' || get https://ifconfig.me/ip 8 | grep -oE '^[0-9.]+$'; }
cgnat() { echo "$1" | grep -qE '^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.)'; }
ATR() { sh $W/at.sh "$1" 2>/dev/null | tr -d '\r'; }
fanadj() {
y_=${WF_SYSCLASS:-/sys/class}
for d_ in "$y_"/thermal/cooling_device*; do
grep -qi fan "$d_/type" 2>/dev/null && [ -r "$d_/cur_state" ] || continue
m_=$(cat "$d_/max_state" 2>/dev/null); case "$m_" in ''|*[!0-9]*) continue ;; esac
[ "$m_" -ge 1 ] && [ "$m_" -le 255 ] && return 0
done
for d_ in "$y_"/hwmon/hwmon*; do
[ -e "$d_/pwm1" ] && [ -e "$d_/pwm1_enable" ] || continue
{ grep -qi fan "$d_/name" 2>/dev/null || ls "$d_"/fan[0-9]_input >/dev/null 2>&1; } && return 0
done
return 1
}
leases() { f=$(uci -q get dhcp.@dnsmasq[0].leasefile); cat "${f:-/tmp/dhcp.leases}" 2>/dev/null; }
devs() {
[ -n "$DV_" ] && { echo "$DV_"; return; }
{ leases; uci -q show dhcp 2>/dev/null; } | awk -v q="'" '
		function add(m) { if (!(m in A)) { A[m] = 1; o[++n] = m } }
		# righe dei contratti («scadenza mac ip nome …»): mai un «=», che ogni riga di uci show ha
		!/=/ { if (NF < 4) next; m = tolower($2); add(m); if (!(m in LI)) { LI[m] = $3; if ($4 != "*") LN[m] = $4 }; next }
		{ k = $0; sub(/=.*/, "", k); v = substr($0, length(k) + 2); split(k, p, ".") }
		v == "host" && p[3] == "" { h[++nh] = p[2]; next }
		p[3] == "mac" || p[3] == "ip" || p[3] == "name" || p[3] == "x3000_label" { sub("^" q, "", v); sub(q "$", "", v); gsub(q "\\\\" q q, q, v); V[p[2], p[3]] = v }
		END { for (i = 1; i <= nh; i++) { s = h[i]; m = tolower(V[s, "mac"]); sub(/[ \047].*/, "", m); if (m == "" || (m in HS)) continue
				HS[m] = s; add(m) }
			for (i = 1; i <= n; i++) { m = o[i]; s = HS[m]; ip = LI[m]; nm = ""
				if (s != "") { nm = V[s, "x3000_label"]; if (ip == "") ip = V[s, "ip"] }
				if (nm == "") nm = LN[m]; if (nm == "" && s != "") nm = V[s, "name"]
				print m, (ip != "" ? ip : "-"), (nm != "" ? nm : "-") } }'
}
devname() { devs | awk -v m="$(echo "$1" | tr 'A-F' 'a-f')" '!f && $1 == m && $3 != "-" {sub(/^[^ ]+ [^ ]+ /, ""); print; f = 1}'; }
find_dev() {
[ -n "$A" ] || { t "@@H 📱 Dispositivi ¦ Scrivi nome, IP o MAC" "@@H 📱 Devices ¦ Type name, IP or MAC"; exit 0; }
R=$(devs | awk -v q="$(echo "$A" | tr 'A-Z' 'a-z')" '{ n = $0; sub(/^[^ ]+ [^ ]+ /, "", n); n = tolower(n) } !s[$1]++ && (n==q || $2==q || $1==q || index(n,q))')
[ -n "$R" ] || { echo "$A" | grep -qiE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' && R="$(echo "$A" | tr 'A-F' 'a-f') - -"; }	# senza nome: dn/dalt, mai il MAC nudo come nome
[ -n "$R" ] || { echo "@@H 📱 $(t Dispositivi Devices) ¦ $(t "Nessuno trovato" "None found") ¦ $A"; exit 0; }
}
one_dev() {
find_dev
[ "$(echo "$R" | wc -l)" -gt 1 ] && { t "@@H 📱 Più Dispositivi ¦ Scrivi nome intero o MAC" "@@H 📱 Several Devices ¦ Type full name or MAC"; echo; CLX=$(cl_all); echo "$R" | while read m_r _ n_r; do [ "$n_r" = - ] && n_r=$(dn "$m_r"); echo "• $n_r · $m_r"; done; exit 0; }
MAC=$(echo "$R" | awk '{print $1}'); IP=$(echo "$R" | awk '{print $2}'); NM=$(echo "$R" | awk '{sub(/^[^ ]+ [^ ]+ /, ""); print}'); [ "$NM" = - ] && NM=$(dn "$MAC")
}
cl_all() { ubus call wrtfreedom clients 2>/dev/null | J 'if (type(d.list) != "array") exit(0); print("n ", length(d.list), "\n");
	for (let x in d.list) if (type(x) == "object" && length(x.mac ?? "")) { let n = trim(replace("" + (x.name ?? ""), /[[:space:]]+/g, " "));
		print(lc(x.mac), " ", x.on ? "on" : "off", " ", length(x.ip ?? "") ? x.ip : "-", " ", length(n) ? n : "-", "\n"); }'; }
cl_on() { cl_all | awk '$1 != "n" && $2 == "on" {print $1, $3}'; }
dalt() {
m_=$(echo "$1" | tr 'A-F' 'a-f'); e_=$(echo "$m_" | cut -c13-17)
case "$m_" in ?[2367abef]*) echo "$(t "Indirizzo Privato" "Private Address") $e_"; return ;; esac
v_=$(awk -F'|' -v p="$(echo "$m_" | cut -c1-8 | tr -d : | tr a-f A-F)" '!/^#/ && index(" " $3 " ", " " p " ") {print $1; exit}' $W/oui.txt 2>/dev/null)
if [ -n "$v_" ]; then echo "$(t "Dispositivo $v_" "$v_ Device") $e_"; else echo "$(t Dispositivo Device) $e_"; fi
}
dn() {
m_=$(echo "$1" | tr 'A-F' 'a-f')
n_=$(echo "$CLX" | awk -v m="$m_" '!f && $1 == m && $4 != "-" {sub(/^[^ ]+ [^ ]+ [^ ]+ /, ""); print; f = 1}')
[ -n "$n_" ] || n_=$(devname "$m_"); [ -n "$n_" ] || n_=$2
if [ -n "$n_" ]; then printf '%s' "$n_"; else dalt "$m_"; fi
}
wifi_ifs() { iwinfo 2>/dev/null | awk '/ESSID/{print $1}'; }
adgcred() { cat /etc/wrtfreedom/adguard 2>/dev/null; }
adg() {
[ -n "$(adgcred)" ] || { t "@@H 🔒 AdGuard Home ¦ Non collegato ¦ Collegalo nell'app" "@@H 🔒 AdGuard Home ¦ Not linked ¦ Link it in the app"; exit 0; }
AA=$(adgaddr); [ -n "$AA" ] || { t "@@H ⚠️ AdGuard Home ¦ Non trovato" "@@H ⚠️ AdGuard Home ¦ Not found"; exit 0; }
K=/tmp/wf-tga.$$; ( umask 077; printf 'user = %s\n' "$(wf_curlq "$(adgcred)")" > $K )
if [ -n "$3" ]; then curl -s -m 15 -K $K -X "$1" -H 'Content-Type: application/json' --data "$3" "http://$AA/control/$2"
else curl -s -m 15 -K $K -X "$1" "http://$AA/control/$2"; fi
rm -f $K
}
adgok() { s_=$(adg GET status); case "$s_" in @@H*) echo "$s_"; exit 0 ;; '') t "@@H ⚠️ AdGuard Home ¦ Non risponde" "@@H ⚠️ AdGuard Home ¦ Not answering"; exit 0 ;; esac; }
uerr() { e=$(echo "$1" | jsonfilter -e '@.error' 2>/dev/null); echo "${e:-${1:-$(t "Nessuna risposta dal router" "No answer from the router")}}"; }
wfget() { ubus -t 5 call wrtfreedom "$1" '{"action":"get"}' 2>/dev/null; }
jv() { v_=$(printf '%s' "$1" | jsonfilter -e "$2" 2>/dev/null | head -n 1); case "$v_" in null|None) v_= ;; esac; printf '%s' "$v_"; }	# un valore del JSON (vuoto se manca o è null)
dhm() { date -d "@$1" '+%d/%m %H:%M' 2>/dev/null; }
nhm() { echo "$1" | awk '$1 ~ /^[0-9]+$/ && $2 ~ /^[0-9]+$/ && $3 == "*" && $4 == "*" && $5 == "*" { printf "%02d:%02d", $2, $1 }'; }
okhost() { echo "$1" | grep -qE '^[A-Za-z0-9.:][A-Za-z0-9.:-]{0,252}$' ||{ t "@@H 🧰 Indirizzo ¦ Non valido" "@@H 🧰 Address ¦ Not valid"; exit 0; }; }
ddnshost() { uci -q show ddns 2>/dev/null | awk -F"'" '!h && /^ddns\.[^.]*\.lookup_host=/ {h = $2} END {if (h != "") print h}'; }	# il primo nome DDNS
wgconf() { # $1 = sezione del client: stampa la configurazione completa (serve la chiave salvata dall'app)
I=$(wgif); s=$1; pk=$(uci -q get wrtfreedom.peer_$s.priv)
[ -n "$pk" ] || return 1
sp=$(uci -q get network.$I.private_key | wg pubkey 2>/dev/null)
h=$(uci -q get wrtfreedom.wg.host); [ -n "$h" ] || h=$(ddnshost); [ -n "$h" ] || h=$(wanip)
homenet >/dev/null	# non trovata: niente DNS di serie e il Parziale porta solo la rete della VPN
d=$(uci -q get wrtfreedom.wg.dns); [ -n "$d" ] || d=$HN_IP
ad=$(uci -q get network.$s.allowed_ips | awk '{print $1}')
if [ "$(uci -q get wrtfreedom.peer_$s.full)" = 1 ]; then al="0.0.0.0/0, ::/0"; else
NETWORK=; PREFIX=; eval "$(ipcalc.sh "$(uci -q get network.$I.addresses | awk '{print $1}')" 2>/dev/null)"
al=; [ -n "$NETWORK" ] && [ -n "$PREFIX" ] && al="$NETWORK/$PREFIX"
if [ -n "$HN_IP" ] && [ -n "$HN_PFX" ]; then
NETWORK=; PREFIX=; eval "$(ipcalc.sh "$HN_IP/$HN_PFX" 2>/dev/null)"
[ -n "$NETWORK" ] && [ -n "$PREFIX" ] && al="${al:+$al, }$NETWORK/$PREFIX"
fi; fi
printf '[Interface]\nPrivateKey = %s\nAddress = %s\n' "$pk" "$ad"; [ -n "$d" ] && printf 'DNS = %s\n' "$d"
printf '\n[Peer]\nPublicKey = %s\n' "$sp"
ps=$(uci -q get network.$s.preshared_key); [ -n "$ps" ] && printf 'PresharedKey = %s\n' "$ps"
printf 'Endpoint = %s:%s\nAllowedIPs = %s\nPersistentKeepalive = 25\n' "$h" "$(uci -q get network.$I.listen_port)" "$al"
}
peer_find() { # sezione del client VPN con quel nome
I=$(wgif)
for s in $(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)=wireguard_$I$/\1/p"); do
[ "$(uci -q get network.$s.description | tr 'A-Z' 'a-z')" = "$(echo "$1" | tr 'A-Z' 'a-z')" ] && { echo $s; return; }
done
}
qrphoto() { # $1 testo, $2 didascalia
f=/tmp/wf-tgqr.$$.png; qrencode -o $f -s 8 -m 2 "$1" 2>/dev/null || { t "@@H ⚠️ QR ¦ Non creato" "@@H ⚠️ QR ¦ Not created"; exit 0; }
echo "@@PHOTO $f ttl=300"; printf '@@H %s\n%s' "$2" "$(t "Si cancella tra 5 minuti" "Deleted in 5 minutes")"
}
f29() { ucode -e '
	let fs = require("fs");
	/* larghezza di un carattere come nella bolla (e nella Galleria): emoji fuori dal piano base e simboli U+2600–U+27BF
	   (✅ ❌ ⚠) contano 2, il selettore U+FE0F conta 0 (3.00: «✅ …» tagliato a 30 sul router vero) */
	function cw(s, i) { let b = ord(s, i), c = ord(s, i + 1); if (b >= 240) return 2; if (b == 0xe2 && c >= 0x98 && c <= 0x9e) return 2;
		if (b == 0xef && c == 0xb8 && ord(s, i + 2) == 0x8f) return 0; return 1; }
	function ul(s) { let n = 0; for (let i = 0; i < length(s); i++) if ((ord(s, i) & 192) != 128) n += cw(s, i); return n; }
	function cu(s, m) { let u = 0, p = -1; for (let i = 0; i < length(s); i++) { if ((ord(s, i) & 192) == 128) continue; u += cw(s, i); if (u > m - 1 && p < 0) p = i; if (u > m) return rtrim(substr(s, 0, p)) + "…"; } return s; }
	/* a metà (nomi di dominio, 6/11): inizio e fine con «…» in mezzo */
	function cm(s, m) { if (ul(s) <= m) return s; let a = int((m - 1) / 2), b = m - 1 - a; return substr(s, 0, a) + "…" + substr(s, length(s) - b); }
	function fo(s) {
		if (ul(s) <= 29) return [ s ];
		let i = index(s, ": "), R = [], r = "";
		if (i > 0 && i < length(s) - 2 && ul(substr(s, 0, i)) <= 29) { let t = substr(s, i + 2); return [ substr(s, 0, i), ...fo(uc(substr(t, 0, 1)) + substr(t, 1)) ]; }
		/* «• nome · dettaglio» (6/11): il dettaglio sulla riga sotto */
		i = index(s, " · ");
		if (i > 0 && ul(substr(s, 0, i)) <= 29) { let t = substr(s, i + 4); return [ substr(s, 0, i), ...fo(uc(substr(t, 0, 1)) + substr(t, 1)) ]; }
		for (let w in split(s, " ")) { if (length(r) && ul(r) + 1 + ul(w) > 29) { push(R, r); r = w; } else r += (length(r) ? " " : "") + w; }
		if (length(r)) push(R, r);
		return R;
	}
	let l;
	while (length(l = fs.stdin.read("line") ?? "")) {
		l = rtrim(l, "\n"); let x = split(l, "\t");
		if (length(x) == 3 || length(x) == 4) { let m = 29 - ul(x[0]) - ul(x[2]); print(x[0], m > 3 ? (x[3] == "m" ? cm(x[1], m) : cu(x[1], m)) : x[1], x[2], "\n"); }
		else for (let r in fo(l)) print(r, "\n");
	}' 2>/dev/null; }
nr() { echo "⚠️ $(t "Non riuscito" "Failed") ¦ $1"; }	# forma F: « ¦ » = a capo nel bot
esito() {
n_=$1; ok_=$2; st_=$3; shift 3
while ! "$@"; do
[ "$n_" -gt 0 ] || { nr "$(eval "$st_")"; return 1; }
n_=$((n_ - 1)); sleep 1
done
echo "✅ $ok_"
}
non() { ! "$@"; }	# il contrario di un controllo (spento, tolto)
dopo() { mkdir -p /tmp/wf-tgq; f_="/tmp/wf-tgq/$(date +%s)-ck$$"; { [ -n "$WF_CHAT" ] && printf '#to:%s\n' "$WF_CHAT"; hdopo "$1"; } > "$f_"; ucode $W/tgq.uc flush; }
hdopo() {
[ -n "$WF_HEAD" ] || { printf '%s' "$1"; return; }
e_=${WF_HEAD%%|*}; c_=${WF_HEAD#*|}; r_=$1
case "$r_" in "⚠️ "*) e_=⚠️; r_=${r_#⚠️ } ;; "✅ "*) r_=${r_#✅ } ;; "🧪 "*) r_=${r_#🧪 } ;; esac
printf '%s %s ¦ %s' "$e_" "$c_" "$r_"
}
vpnon() { isup "$(wgif)"; }	# /vpn: interfaccia del Server VPN accesa (netifd)
vpnst() { echo "$(t "Server VPN" "VPN Server") $(vpnon && t acceso on || t spento off)"; }
vpnnew() { vpnon && u_=$(ifstatus "$(wgif)" 2>/dev/null | jsonfilter -e '@.uptime' 2>/dev/null) && [ -n "$u_" ] && [ "$u_" -le $(( $(date +%s) - T0 + 2 )) ]; }
wifion() { [ -n "$(wifi_ifs)" ]; }	# /wifi: almeno una rete Wi-Fi in onda (iwinfo)
wifist() { wifion && t "Wi-Fi acceso" "Wi-Fi on" || t "Wi-Fi spento" "Wi-Fi off"; }
lineup() { [ -n "$(wanip)" ]; }
linest() { ip_=$(wanip); [ -n "$ip_" ] && echo "$(t "linea attiva" "line up") · IP $ip_" || t "linea giù" "line down"; }
gst() {
c_=0; a_=0; U_=$(uci -q show wireless); L_=$(printf '%s\n' "$U_" | sed -n "s/^wireless\.\([^.]*\)\.network='guest'$/\1/p")
for s in $L_; do printf '%s\n' "$U_" | grep -qxF "wireless.$s.disabled='1'" || c_=1; done
[ -n "$L_" ] && [ -n "$(ubus call network.wireless status 2>/dev/null | J 'let L = split("'"$(echo $L_)"'", " "); for (let r in d) for (let i in d[r]?.interfaces ?? []) if (index(L, i.section) >= 0 && i.ifname) print(i.ifname, "\n");')" ] && a_=1
case $c_$a_ in 11) echo on;; 00) echo off;; 10) echo cfg;; *) echo air;; esac
}
gston() { [ "$(gst)" = on ]; }
gstoff() { [ "$(gst)" = off ]; }
gsttxt() { case "$(gst)" in on) t "rete ospiti accesa" "guest network on";; off) t "rete ospiti spenta" "guest network off";;
cfg) t "rete ospiti accesa nelle impostazioni ma non in onda" "guest network on in the settings but not on air";;
*) t "rete ospiti spenta nelle impostazioni ma ancora in onda" "guest network off in the settings but still on air";; esac; }
blkr() { uci -q get "firewall.x3kb_$(echo "$1" | tr -d :)" >/dev/null; }
blkn() { command -v nft >/dev/null 2>&1 || return 0; nft list ruleset 2>/dev/null | awk -v m="ether saddr $(echo "$1" | tr 'A-F' 'a-f')" 'index(tolower($0), m) && tolower($0) ~ /reject/ {f = 1} END {exit !f}'; }
blk() { blkr "$1" && blkn "$1"; }
unblk() { ! blkr "$1" && { ! command -v nft >/dev/null 2>&1 || ! blkn "$1"; }; }
blkst() { if blk "$1"; then t "Bloccato" "Blocked"; elif blkr "$1"; then t "Regola non caricata" "Rule not loaded"; elif ! unblk "$1"; then t "Ancora bloccato" "Still blocked"; else t "Non bloccato" "Not blocked"; fi; }
assoc() { for i in $(wifi_ifs); do iwinfo $i assoclist 2>/dev/null | grep -qi "^$1" && return 0; done; return 1; }
shv() { ubus call wrtfreedom shaper 2>/dev/null | J 'if (type(d.list) != "array") exit(0); let k = lc("'"$1"'");
	let me = (r) => index(k, ":") >= 0 ? lc("" + (r.mac ?? "")) == k && r.casa !== true && r.macs == null && r.from == null && r.to == null && !length("" + (r.days ?? "")) && r.until == null : r.id == k;
	let x = filter(d.list, (r) => type(r) == "object" && me(r) && r.dl && r.on !== false)[0]; print(x ? x.dl : 0, "\n");'; }
shis() { [ "$(shv "$1")" = "$2" ]; }
shno() { [ "$(shv "$1")" = 0 ]; }
shst() { v_=$(shv "$1"); case "$v_" in '') t "Nessuna risposta dal router" "No answer from the router";; 0) echo "$NM $(t "alla velocità piena" "at full speed")";;
*) echo "$NM $(t "al massimo" "at most") ↓ $v_ Mbit/s";; esac; }
svcst() { ubus call wrtfreedom svc 2>/dev/null | J 'let x = filter(d.list ?? [], (y) => y.id == "'"$1"'")[0]; if (x) print(x.on ? "on" : "off");'; }
svcon() { [ "$(svcst "$1")" = on ]; }
pidon() { pidof "$1" >/dev/null 2>&1; }	# processo acceso (servizio fuori dall'elenco di /servizi)
adgon() { case "$(adg GET status)" in *'"protection_enabled":true'*) ;; *) return 1 ;; esac; }
adgoff() { case "$(adg GET status)" in *'"protection_enabled":false'*) ;; *) return 1 ;; esac; }	# spenta: AdGuard risponde e lo dice
adgst() { s_=$(adg GET status); [ -n "$s_" ] || { t "AdGuard Home non risponde" "AdGuard Home is not answering"; return; }
printf '%s' "$s_" | grep -q '"protection_enabled":true' && t "protezione accesa" "protection on" || t "protezione spenta" "protection off"; }
sqmk() { [ "$(ubus -t 5 call wrtfreedom sqm 2>/dev/null | jsonfilter -e "@.$1" 2>/dev/null)" = "${2:-true}" ]; }
sqmst() { sh $W/sqmctl.sh state 2>/dev/null | head -n 1 | sed 's/^🎚 //'; }
fsplit() { awk '{ i = index($0, ": "); if (length($0) > 29 && i > 1) { print substr($0, 1, i - 1); r = substr($0, i + 2); print toupper(substr(r, 1, 1)) substr(r, 2) } else print }'; }
vsv() { ubus call wrtfreedom vpnout '{"action":"state"}' 2>/dev/null | J "print(d.$1 ?? '')"; }
lineok() {
[ -f /tmp/wf-line.json ] || return 0
[ -p /tmp/wf-line.fifo ] && echo k 1<>/tmp/wf-line.fifo
[ "$(jsonfilter -i /tmp/wf-line.json -e '@.ok' 2>/dev/null)" = true ] && [ "$(jsonfilter -i /tmp/wf-line.json -e '@.t' 2>/dev/null || echo 0)" -ge "$T0" ]
}
vsok() { if [ "$1" = on ]; then [ "$(vsv state)" = ok ]; else [ "$(vsv state)" = off ]; fi && lineok; }
vsst() { w_=ok; [ "$1" = off ] && w_=off
if [ "$(vsv state)" != $w_ ]; then v_=$(vsv v); echo "$(t "Client VPN" "VPN Client"): ${v_:-$(t "nessuna risposta" "no answer")}"; else t "la casa è rimasta senza internet" "the home was left without internet"; fi; }

nas_ok() { [ "$(jsonfilter -q -i /etc/wrtfreedom/nas.json -e '@.on' 2>/dev/null)" = true ]; }
nas_pick() { awk -F'\t' -v a="$(printf '%s' "$1" | tr 'A-Z' 'a-z')" 'NF >= 2 { n++; l[n] = $0; if (a != "" && (tolower($1) == a || tolower($2) == a)) { m++; r = $0 } } END { if (a != "") { if (m == 1) print r } else if (n == 1) print l[1] }'; }
nas_id() { printf '%s' "$1" | grep -qE '^[A-Za-z0-9_.:-]{1,64}$'; }
nas_sz() { awk -v b="${1:-0}" -v en=$EN 'BEGIN { split("KB MB GB TB", u, " "); v = b / 1024; i = 1; while (v >= 1024 && i < 4) { v /= 1024; i++ }
	s = (v >= 10 || i == 1) ? sprintf("%d %s", int(v + 0.5), u[i]) : sprintf("%.1f %s", v, u[i]); if (i == 1 && v < 1) s = "1 KB"; sub(/[.]0 /, " ", s); if (!en) gsub(/\./, ",", s); print s }'; }
nas_dlall() {
if [ -n "$ASJ" ]; then D_=$(ubus call wrtfreedom nas_me "{\"act\":\"get\"$ASJ}" 2>/dev/null | J 'let x = d.dl ?? {}; print(int(+(x.run ?? 0)), " ", x.paused ? 1 : 0, "\n");')
else D_=$(ubus call wrtfreedom nas_state 2>/dev/null | J 'let x = d.dl ?? {}; print(int(+(x.run ?? 0)), " ", x.paused ? 1 : 0, "\n");'); fi
n_=${D_% *}; p_=${D_#* }; case "$n_" in ''|*[!0-9]*) n_=0 ;; esac
if [ "$1" = pauseall ] && [ "$n_" = 0 ]; then
if [ "$p_" = 1 ]; then echo "@@BTN riprendi=$(t Riprendi Resume)"; t "@@H 🗄️ Download ¦ Già in pausa ¦ Tocca Riprendi per ripartire" "@@H 🗄️ Download ¦ Already paused ¦ Tap Resume to restart"
else t "@@H 🗄️ Download ¦ Nessun download in corso" "@@H 🗄️ Download ¦ No download running"; fi
return
fi
o_=$(ubus call wrtfreedom nas_dl "{\"act\":\"$1\"$ASJ}" 2>&1)
case "$o_" in
*'"error"'*) e_=$(printf '%s' "$o_" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ Download"; t "Non riuscito" "Failed"; echo; [ -n "$e_" ] && printf '%s\n' "$e_" | fsplit ;;
*'{'*) if [ "$1" = pauseall ]; then
echo "@@BTN riprendi=$(t Riprendi Resume)"; echo "@@H 🗄️ Download"
if [ "$n_" = 1 ]; then t "1 download in pausa" "1 download paused"; else t "$n_ download in pausa" "$n_ downloads paused"; fi; echo
t "Tocca Riprendi per ripartire" "Tap Resume to restart"; echo
else echo "@@BTN pausa=$(t Pausa Pause)"; echo "@@H 🗄️ Download"; t "Download ripresi" "Downloads resumed"; echo; fi ;;
*) t "@@H ⚠️ Download ¦ Il router non ha risposto ¦ Riprova" "@@H ⚠️ Download ¦ The router did not answer ¦ Try again" ;;
esac
}
bk_list() {
ubus call wrtfreedom nas_backup '{"act":"get"}' 2>/dev/null | J 'for (let k in d.list ?? []) if ((k.own ?? "admin") == "admin") print((k.id ?? "") + "\t" + replace("" + (k.name ?? k.id), /[\t\n]/g, " ") + "\td\n");'
ubus call wrtfreedom nas_cloud '{"act":"get"}' 2>/dev/null | J 'for (let k in d.list ?? []) if (k.kind == "backup" && (k.own ?? "admin") == "admin") print((k.id ?? "") + "\t" + replace("" + (k.name ?? k.id), /[\t\n]/g, " ") + "\tc\n");'
}
bk_show() { echo "@@H 🗄️ $(t "Quale Backup" "Which Backup")"; printf '%s\n' "$1" | awk -F'\t' 'NF >= 2 {print "• " $2 ($3 == "c" ? " · Cloud" : "")}' | lmax 8; t "Scrivi /backup_nas <nome>" "Type /nas_backup <name>"; }
cl_pause() {
if [ "$1" = resume ]; then j_='{"act":"pause","do":"resume","kind":"bot"}'; else j_="{\"act\":\"pause\",\"until\":$1,\"kind\":\"bot\"}"; fi
o_=$(ubus call wrtfreedom cloud "$j_" 2>&1)
case "$o_" in
*'"error"'*) e_=$(printf '%s' "$o_" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ Cloud"; t "Non riuscito" "Failed"; echo; [ -n "$e_" ] && printf '%s\n' "$e_" | fsplit ;;
*'"pause"'*) printf '%s' "$o_" | J 'let p = d.pause ?? {}, u = +(p.until ?? 0);
			let l = localtime(u), n = localtime(time()), dy = l.mday == n.mday && l.mon == n.mon, hh = sprintf("%02d:%02d", l.hour, l.min);
			if (p.on) {
				print("@@BTN riprendi=", EN ? "Resume Cloud" : "Riprendi Cloud", "\n@@H 🗄️ ", EN ? "Cloud Pause" : "Pausa Cloud", "\n");
				if (u > 0) print(EN ? "Paused until " : "In pausa fino ", dy ? (EN ? "" : "alle ") : (EN ? "" : "al ") + sprintf("%02d/%02d ", l.mday, l.mon), hh, "\n");
				else print(EN ? "Paused until Resume" : "In pausa fino a Riprendi", "\n");
			} else print("@@H 🗄️ Cloud\n", EN ? "Resumed" : "Ripreso", "\n", EN ? "The queue restarts" : "La coda riparte", "\n");' ;;
*) t "@@H ⚠️ Cloud ¦ Il router non ha risposto ¦ Riprova" "@@H ⚠️ Cloud ¦ The router did not answer ¦ Try again" ;;
esac
}

if [ "$1" = --needs ]; then
ok() { if "$@" >/dev/null 2>&1; then echo 1; else echo 0; fi; }
echo "modem $( { [ "$(sh $W/at.sh --tool 2>/dev/null)" != none ] || mmcli -L 2>/dev/null | grep -q Modem; } && echo 1 || echo 0)"
echo "wifi $( uci -q show wireless | grep -q '=wifi-iface' && command -v iwinfo >/dev/null && echo 1 || echo 0)"
echo "guest $(ok sh -c "uci -q show wireless | grep -q \"network='guest'\"")"
echo "wg $( command -v wg >/dev/null && [ -n "$(wgif)" ] && echo 1 || echo 0)"
echo "adg $( { [ -x /etc/init.d/adguardhome ] || command -v AdGuardHome >/dev/null; } && [ -n "$(adgcred)" ] && command -v curl >/dev/null && echo 1 || echo 0)"
echo "qr $(ok command -v qrencode)"
echo "wol $( { command -v etherwake || command -v ether-wake; } >/dev/null && echo 1 || echo 0)"
echo "nlbw $( command -v nlbw >/dev/null && pidof nlbwmon >/dev/null && echo 1 || echo 0)"
echo "thermal $(ls /sys/class/thermal/thermal_zone*/temp >/dev/null 2>&1 && echo 1 || echo 0)"
echo "ddns $(ok test -x /etc/init.d/ddns)"
echo "acme $(ok test -x /etc/init.d/acme)"
echo "curl $(ok command -v curl)"
echo "hostapd $( [ -n "$(ubus list 'hostapd.*' 2>/dev/null)" ] && echo 1 || echo 0)"
echo "trace $(ok command -v traceroute)"
echo "conntrack $(ok test -r /proc/sys/net/netfilter/nf_conntrack_count)"
echo "vpnsvc $(ok grep -q "^config vpntun" /etc/config/wrtfreedom)"
echo "sqm $( [ -x /etc/init.d/sqm ] && uci -q show sqm | grep -q '=queue$' && echo 1 || echo 0)"
echo "fan $(fanadj && echo 1 || echo 0)"
echo "nas $(nas_ok && echo 1 || echo 0)"
exit 0
fi

case "$OWN" in
admin) ;;
*) case "$ASJ:$1" in ,*:scarica|,*:pausa_download|,*:cerca_file) ;; *) t "@@H ⚠️ Bot ¦ Non permesso in questa chat" "@@H ⚠️ Bot ¦ Not allowed in this chat"; exit 0 ;; esac ;;
esac

case "$1" in
stato)
WF_IP=; [ "$WF_ROLE" = s ] || WF_IP=$(wanip)
WF_NL=$(cl_all | awk 'NR == 1 && $1 == "n" {print $2}'); WF_NL=${WF_NL:-—}; WF_WG=''
I=$(wgif); [ -n "$I" ] && WF_WG=$(ubus call wrtfreedom vpnwd 2>/dev/null | J '
		if (d.state) print((EN ? "VPN Server" : "Server VPN") + ": " + d.v);')
WF_SYS="$(t "Acceso da" "Up for"): $(dur "$(cut -d. -f1 /proc/uptime)")"
export WF_IP WF_NL WF_WG WF_SYS
o=$(ubus call wrtfreedom casa 2>/dev/null | J '
		let ip = getenv("WF_IP") ?? "", wg = getenv("WF_WG") ?? "", l = d.line ?? {}, w = d.wifi, v = d.vpn, n = d.dev ?? {};
		print("@@H 📊 " + (EN ? "Home Status" : "Stato Della Casa") + "\n");
		print((d.ok ? (EN ? "All good" : "Tutto bene") : (EN ? "To check: " : "Da vedere: ") + d.n) + "\n");
		print((EN ? "Line" : "Linea") + ": " + (l.v ?? "—") + (length(l.tech ?? "") ? " · " + l.tech : "") + "\n");
		if (length(ip)) print("IP: " + ip + "\n");
		print((EN ? "Devices" : "Dispositivi") + ": " + trim(getenv("WF_NL") ?? "0") + (EN ? " · active " : " · attivi ") + (n.v ?? "—") + "\n");
		if (w) print("Wi-Fi: " + w.v + "\n");
		if (v) print((EN ? "VPN Client" : "Client VPN") + ": " + v.v + "\n");
		if (length(wg)) print(wg + "\n");
		print((getenv("WF_SYS") ?? "") + "\n");
		/* Stato Della Casa (2.49): lo stesso calcolo della Dashboard e della notifica fissa (esito sopra, qui i motivi) */
		for (let x in d.items) if (x.sev == "bad" || x.sev == "warn") print((x.sev == "bad" ? "❌ " : "• ") + (x.id == "newdev" ? (EN ? "To confirm: " : "Nuovi da confermare: ") + (n.new ?? "") : x.text) + "\n");
		if (d.today && d.today.b != null) print((EN ? "Today: " : "Oggi: ") + d.today.v + "\n");
	')
if [ -n "$o" ]; then echo "$o"; else echo "@@H 📊 $(t "Stato Della Casa" "Home Status")"; echo "$WF_SYS"; fi
;;
uptime)
echo "@@H 🩺 $(t Accensione "Power On")"
echo "$(t "Acceso da" "Up for"): $(dur "$(cut -d. -f1 /proc/uptime)")"
echo "$(t "Acceso il" "Started on"): $(date -d @$(( $(date +%s) - $(cut -d. -f1 /proc/uptime) )) '+%d/%m/%Y %H:%M' 2>/dev/null)"
;;
carico)
ps=$(head -n 1 /proc/stat); set -- $ps; a=$(( $2+$3+$4+$5+$6+$7+$8 )); b=$5
sleep 1; ps=$(head -n 1 /proc/stat); set -- $ps; c=$(( $2+$3+$4+$5+$6+$7+$8 )); d=$5
echo "@@H 🩺 $(t Processore Processor)"
echo "$(t Uso Use): $(( 100 - 100 * (d - b) / (c - a + 1) ))% · $(grep -c ^processor /proc/cpuinfo) core"
echo "$(t Carico Load): $(cut -d' ' -f1-3 /proc/loadavg)"
echo "$(t Processi Processes): $(cut -d' ' -f4 /proc/loadavg | cut -d/ -f2)"
;;
memoria)
echo "@@H 🩺 $(t Memoria Memory)"
awk -v EN=$EN '/MemTotal/{t=$2}/MemAvailable/{a=$2}/SwapTotal/{st=$2}/SwapFree/{sf=$2}
	END{printf "%s: %d MB (%d%%)\n", EN?"In use":"In uso", (t-a)/1024, (t-a)*100/t
	    printf "%s: %d MB\n", EN?"Free":"Libera", a/1024
	    printf "%s: %d MB\n", EN?"Total":"Totale", t/1024
	    if(st>0) printf "Swap: %d %s %d MB\n", (st-sf)/1024, EN?"of":"di", st/1024}' /proc/meminfo
;;
disco)
echo "@@H 🩺 $(t "Spazio" "Space")"
df -h 2>/dev/null | awk -v EN=$EN 'NR>1 && ($6=="/" || $6=="/overlay" || $6=="/tmp" || $6~/^\/mnt\/[^\/]+$/ || $6~/^\/srv\/[^\/]+$/){
		n=$6; if(n=="/overlay" || n=="/") n=EN?"Internal":"Interna"; else if(n=="/tmp") n=EN?"Temporary":"Temporanea"; else { sub(/^.*\//,"",n); n=(EN?"Drive ":"Disco ") n }
		if(s[n]++) next; printf "%s: %s %s (%s)\n", n, $4, EN?"free":"liberi", $5}'
nas_ok && ubus call wrtfreedom nas_state 2>/dev/null | J 'const H = { ok: [ "buona", "good" ], warn: [ "da controllare", "needs checking" ], bad: [ "in pericolo", "at risk" ] };
	for (let k in d.disks ?? []) { let s = k.smart ?? {}, h = H[k.health], w = h ? h[EN ? 1 : 0] : s.ok === true ? (EN ? "good" : "buona") : s.ok === false ? (EN ? "needs checking" : "da controllare") : null, x = [];
		if (w) push(x, (EN ? "Health " : "Salute ") + w); if (k.health && k.health != "ok" && k.health_why) push(x, lc(EN ? (k.health_why.en ?? k.health_why.it) : k.health_why.it));
		if (+s.temp > 0) push(x, +s.temp + " °C"); if (k.sleeping) push(x, EN ? "asleep" : "a riposo");
		/* 10/11 (contratto dischi.md): Avvio Rapido di Windows, stesso UUID di un altro disco, Prepara interrotto */
		if (k.hib) push(x, EN ? "Windows Fast Startup: read only" : "Avvio Rapido di Windows: sola lettura");
		if (k.win) push(x, EN ? "connect it to Windows, open it and use Eject Safely" : "collegalo a Windows, aprilo e fai Rimuovi In Sicurezza");
		if (k.dup) push(x, EN ? "same UUID as another drive" : "stesso UUID di un altro disco");
		if (k.fmt_cut) push(x, EN ? "preparation interrupted: Prepare again" : "preparazione interrotta: Prepara di nuovo");
		if (length(x)) print((k.name ?? k.id) + ": " + join(" · ", x) + "\n"); }' | fsplit
;;
temperatura)
echo "@@H 🩺 $(t "Temperatura" "Temperature")"
k=0
for z in /sys/class/thermal/thermal_zone* /sys/class/hwmon/hwmon*; do
f=$z/temp; n=$(cat $z/type 2>/dev/null); [ -f "$f" ] || { f=$z/temp1_input; n=$(cat $z/name 2>/dev/null); }
[ -f "$f" ] || continue
case "$(echo "$n" | tr 'A-Z' 'a-z')" in
*phy*|*mt7*|*ath*|*wifi*|*wlan*|*radio*) n="Wi-Fi" ;;
*cpu*|*soc*|*tsens*|*core*|*thermal*) n=$(t Processore Processor) ;;
*) k=$((k + 1)); n="$(t Sensore Sensor) $k" ;;
esac
awk -v n="$n" '{v=$1; if(v>1000) v=v/1000; printf "%s: %.0f °C\n", n, v}' "$f"
done 2>/dev/null | awk '!s[$0]++'
;;
salute)
o=$(ubus call wrtfreedom health 2>/dev/null | J '
		let s = d.state ?? "ok", n = (x, u) => x == null ? "—" : x + u, v = "" + (d.v ?? "—");
		/* forma F (avvisi.md): soggetto «Router <esito>» («Router da tenere d occhio»), sotto righe «Etichetta valore» */
		print("@@H 🩺 " + (EN ? "Health" : "Salute") + "\n" + v + "\n");
		for (let w in d.why ?? []) print((w.sev == "bad" ? "❌ " : "• ") + w.text + "\n");
		print((EN ? "Processor" : "Processore") + ": " + n(d.cpu?.pct, "%") + "\n");
		print((EN ? "Memory" : "Memoria") + ": " + n(d.mem?.pct, "%") + "\n");
		/* 3.34 Memoria del router (health.memx = /tmp/wf-mem.json di mem.uc, kB): riserva sempre libera sulla RAM */
		let X = d.memx;
		if (type(X) == "object" && +X.ris > 0 && +X.tot > 0) print((EN ? "Reserve: " : "Riserva: ") + int(X.ris / 1024) + (EN ? " MB of " : " MB di ") + int(X.tot / 1024) + " MB\n");
		/* stesse frasi della app (Salute › Memoria) e della IA per gli stati del router */
		if (type(X) == "object" && X.st == "nocg") print(EN ? "This router has no memory brakes: I only watch it.\n" : "Questo router non ha i freni della memoria: la guardo e basta.\n");
		else if (type(X) == "object" && X.st == "riserva") print(EN ? "Too many heavy services on: limits at minimum.\n" : "Troppi servizi pesanti accesi: tetti al minimo.\n");
		print((EN ? "Temperature" : "Temperatura") + ": " + n(d.temp?.c, " °C") + "\n");
		print((EN ? "Free space" : "Spazio libero") + ": " + n(d.disk?.free, "%") + "\n");
	')
if [ -n "$o" ]; then echo "$o"; else t "@@H ⚠️ Salute ¦ Non letta ¦ Riprova tra poco" "@@H ⚠️ Health ¦ Not read ¦ Try again shortly"; fi
;;
ventola)
m=
case "$(printf '%s' "$A" | tr 'A-Z' 'a-z')" in
'') ;;
auto|automatica|automatic) m=auto ;;
quiet|silenziosa) m=quiet ;;
cool|fresca) m=cool ;;
max|massima|maximum) m=max ;;
*) t "@@H 🩺 Ventola ¦ Scrivi uno di questi: ¦ automatica, silenziosa, ¦ fresca o massima" "@@H 🩺 Fan ¦ Type one of these: ¦ automatic, quiet, ¦ cool or max"; exit 0 ;;
esac
fanadj || { t "@@H 🩺 Ventola ¦ Non regolabile ¦ Su questo router" "@@H 🩺 Fan ¦ Not adjustable ¦ On this router"; exit 0; }
WF_FSET=
if [ -n "$m" ]; then
r=$(ubus call wrtfreedom health "{\"action\":\"set\",\"fan\":\"$m\"}" 2>/dev/null)
[ -n "$r" ] || { t "@@H ⚠️ Ventola ¦ Il router non ha risposto ¦ Riprova" "@@H ⚠️ Fan ¦ The router did not answer ¦ Try again"; exit 0; }
e=$(printf '%s' "$r" | jsonfilter -e '@.error' 2>/dev/null)
[ -z "$e" ] || { echo "@@H ⚠️ $(t Ventola Fan) ¦ $e"; exit 0; }
WF_FSET=1
fi
export WF_FSET
o=$(ubus call wrtfreedom health 2>/dev/null | J '
		let f = d.fan, t = d.temp?.c, M = [ ["auto", "Automatica", "Automatic"], ["quiet", "Silenziosa", "Quiet"], ["cool", "Fresca", "Cool"], ["max", "Massima", "Maximum"] ];
		if (!f?.adj) { print(EN ? "@@H 🩺 Fan ¦ Not adjustable ¦ On this router" : "@@H 🩺 Ventola ¦ Non regolabile ¦ Su questo router"); exit(0); }
		let nm = (k) => { for (let x in M) if (x[0] == k) return EN ? x[2] : x[1]; return EN ? M[0][2] : M[0][1]; }, mo = f.mode ?? "auto";
		print("@@BTN " + join("|", map(M, (x) => x[0] + "=" + (x[0] == mo ? "✅ " : "") + (EN ? x[2] : x[1]))) + "\n");
		/* 2.99: titolo standard con l esito («Impostata su silenziosa» dopo una scelta, altrimenti la scelta) */
		print("@@H 🩺 " + (EN ? "Fan ¦ " : "Ventola ¦ ") + (getenv("WF_FSET") == "1" ? (EN ? "Set to " : "Impostata su ") + lc(nm(mo)) : nm(mo)) + "\n");
		print(f.force ? (EN ? "At full speed for the heat" : "Al massimo per il caldo") : (EN ? "Level: " : "Livello: ") + (f.max ? (f.lvl ?? 0) + (EN ? " of " : " di ") + f.max : (f.pct ?? 0) + "%"), "\n");
		if (f.rpm) print((EN ? "Speed: " : "Giri: ") + f.rpm + (EN ? " rpm" : " al minuto") + "\n");
		if (t != null) print((EN ? "Temperature: " : "Temperatura: ") + t + " °C\n");
		print((EN ? "Over " : "Sopra ") + (f.hot ?? 75) + (EN ? " °C: full speed" : " °C: al massimo") + "\n");
	')
if [ -n "$o" ]; then echo "$o"; else t "@@H ⚠️ Ventola ¦ Non letta ¦ Riprova tra poco" "@@H ⚠️ Fan ¦ Not read ¦ Try again shortly"; fi
;;
versione)
[ -f /etc/openwrt_release ] && . /etc/openwrt_release
echo "@@H ⚙️ $(t Versione Version)"
echo "$(t Modello Model): $(cat /tmp/sysinfo/model 2>/dev/null || uci -q get system.@system[0].hostname)"
echo "Firmware: ${DISTRIB_DESCRIPTION:-—}"
echo "Kernel: $(uname -r) · $(uname -m)"
echo "WrtFreedom: $(cat $W/VERSION 2>/dev/null)"
;;
ip)
ip=$(wanip); p=$(pubip)
echo "@@H 🌐 IP"
echo "$(t Linea Line): ${ip:-–}"
echo "$(t Pubblico Public): ${p:-$(t "non raggiungibile" "unreachable")}"
[ -n "$ip" ] && [ -n "$p" ] && [ "$ip" != "$p" ] && { t "Dietro il NAT dell'operatore" "Behind carrier NAT"; echo; }
;;
ipv6)
echo "@@H 🌐 IPv6"
o=$(for i in $(wanifs); do d=$(ifstatus "$i" 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null); [ -n "$d" ] || continue
ip -6 addr show dev $d scope global 2>/dev/null | awk -v d="$(wf_ifname "$i")" '/inet6/{print d ": " $2}'; done | awk '!s[$0]++')
echo "${o:-$(t "Nessun indirizzo" "No address")}"
;;
velocita)
D=$(wandevs | sed -n 1p); [ -n "$D" ] || { t "@@H 🌐 Velocità ¦ Linea non attiva" "@@H 🌐 Speed ¦ Line not active"; exit 0; }
X=/sys/class/net/$D/statistics; [ -r $X/rx_bytes ] && [ -r $X/tx_bytes ] || { t "@@H 🌐 Velocità ¦ Linea non attiva" "@@H 🌐 Speed ¦ Line not active"; exit 0; }
r1=$(cat $X/rx_bytes 2>/dev/null); t1=$(cat $X/tx_bytes 2>/dev/null); sleep 3
r2=$(cat $X/rx_bytes 2>/dev/null); t2=$(cat $X/tx_bytes 2>/dev/null)
[ -n "$r1" ] && [ -n "$r2" ] && [ -n "$t1" ] && [ -n "$t2" ] || { t "@@H 🌐 Velocità ¦ Linea non attiva" "@@H 🌐 Speed ¦ Line not active"; exit 0; }
awk -v r=$((r2-r1)) -v s=$((t2-t1)) -v EN=$EN 'BEGIN{printf "@@H 🌐 %s\n%s\n↓ %.2f Mbit/s\n↑ %.2f Mbit/s\n", EN?"Speed":"Velocità", EN?"Right now":"Adesso", r*8/3/1e6, s*8/3/1e6}'
;;
consumo)
o=$(ubus -t 5 call wrtfreedom usage 2>/dev/null | J '
		let S = d.s, c = match("" + (S?.cyc ?? ""), /^([0-9]{4})-([0-9]{2})-([0-9]{2})$/);
		if (type(S) != "object" || !c) exit(0);
		let gb = (b) => { let g = (+b || 0) / 1e9; return sprintf(g < 10 ? "%.2f GB" : g < 100 ? "%.1f GB" : "%.0f GB", g); };
		let rx = +(S.rx ?? 0), tx = +(S.tx ?? 0), used = rx + tx, q = +(d.quota ?? 0) * 1e9, day = +(d.day ?? 1) || 1;
		/* rinnovo: next di usage.uc (lo stesso calcolo del periodo); senza (stato di una versione di prima) lo stesso giorno
		   del mese dopo (o il suo ultimo giorno), come usNext dell app */
		let nx = match("" + (S.next ?? ""), /^[0-9]{4}-([0-9]{2})-([0-9]{2})$/), y = +c[1], m = +c[2] + 1; if (m > 12) { m = 1; y++; }
		let dim = m == 2 ? ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0 ? 29 : 28) : (m == 4 || m == 6 || m == 9 || m == 11 ? 30 : 31);
		let rn = nx ? nx[2] + "/" + nx[1] : sprintf("%02d/%02d", day > dim ? dim : day, m);
		print("@@H 📊 ", S.mobile === false ? (EN ? "Line Usage" : "Consumo Della Linea") : (EN ? "SIM Usage" : "Consumo Della SIM"), "\n");
		print(EN ? "Used: " : "Usati: ", gb(used), q > 0 ? sprintf(" (%d%%)", used * 100 / q) : "", "\n");
		print(EN ? "Plan: " : "Offerta: ", q > 0 ? gb(q) : (EN ? "unlimited" : "senza limite"), "\n");
		print("↓ ", EN ? "Downloaded: " : "Scaricati: ", gb(rx), "\n", "↑ ", EN ? "Sent: " : "Inviati: ", gb(tx), "\n");
		print(EN ? "From " : "Dal ", c[3], "/", c[2], EN ? " · renews " : " · rinnovo ", rn,"\n");
		if (d.slow?.active) print(EN ? "Data used up: slowed down" : "Giga finiti: velocità ridotta", "\n");')
[ -n "$o" ] && { echo "$o"; exit 0; }
echo "@@H 📊 $(t Consumo Usage)"; echo "$(t "Dall'accensione" "Since boot")"
for i in $(wanifs); do D=$(ifstatus "$i" 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null); [ -r "/sys/class/net/$D/statistics/rx_bytes" ] || continue
[ -r /sys/class/net/$D/statistics/rx_bytes ] || continue; echo "$(wf_ifname "$i"): ↓ $(hb "$(cat /sys/class/net/$D/statistics/rx_bytes 2>/dev/null)") ↑ $(hb "$(cat /sys/class/net/$D/statistics/tx_bytes 2>/dev/null)")"; done | awk '!s[$0]++'
;;
ora)
echo "@@H ⚙️ $(t Ora Time)"
echo "$(t Data Date): $(date '+%d/%m/%Y')"
echo "$(t Ora Time): $(date '+%H:%M:%S')"
echo "$(t "Fuso" "Time zone"): $(uci -q get system.@system[0].zonename || uci -q get system.@system[0].timezone)"
echo "NTP: $([ "$(uci -q get system.ntp.enabled)" = 0 ] && t spento off || t attivo on)"
[ -f /tmp/.wf-ntp ] || { t "⚠️ Orologio non sincronizzato" "⚠️ Clock not synced"; echo; }
;;
linea)
L=$(wanifs); BK=$(uci -q get wrtfreedom.fo.backup)
echo "@@H 🌐 $(t Linea Line)"
o=$(for i in $L; do
S=$(ifstatus $i 2>/dev/null) || continue
n=$(wf_ifname "$i"); case "$n" in "Linea IPv6"|"IPv6 Line") continue ;; esac
if echo "$S" | jsonfilter -e '@.up' 2>/dev/null | grep -q true; then
echo "$n: $(t collegata connected)"
echo "$(t Da For): $(dur "$(echo "$S" | jsonfilter -e '@.uptime')")"
[ "$WF_ROLE" = s ] && continue
echo "IP: $(echo "$S" | jsonfilter -e '@["ipv4-address"][0].address')"
echo "Gateway: $(echo "$S" | jsonfilter -e '@.route[@.target="0.0.0.0"].nexthop' | head -n 1)"
echo "DNS: $(echo "$S" | jsonfilter -e '@["dns-server"][*]' | head -n 2 | tr '\n' ' ' | sed 's/ $//')"
elif [ -n "$BK" ] && [ "$i" = "$BK" ]; then echo "$n: $(t "non collegata" "not connected")"; fi
done)
echo "${o:-$(t "Nessuna linea collegata" "No line connected")}"
;;
riconnetti)
t "@@H 🌐 Linea ¦ Riconnessione in corso ¦ Ti scrivo qui l'esito" "@@H 🌐 Line ¦ Reconnecting ¦ I will write the result here"
( sleep 2; sh $W/event.sh act wan_reconnect; dopo "$(esito 60 "$(t "Linea riconnessa" "Line reconnected")" linest lineup)" ) >/dev/null 2>&1 </dev/null &
;;
segnale)
ucode $W/modemctl.uc tg segnale
;;
sqm) echo "@@H 🌐 SQM"; sh $W/sqmctl.sh state 2>/dev/null | sed 's/^🎚 //; s/^SQM: //' | fsplit ;;
sqm_on|sqm_off|sqm_profilo)
if [ $1 = sqm_profilo ]; then o=$(sh $W/sqmctl.sh pick "$A" 2>/dev/null); else o=$(sh $W/sqmctl.sh ${1#sqm_} 2>/dev/null); fi
r=$?; o=$(printf '%s' "$o" | sed 's/^🎚 //')
[ $r = 0 ] || { echo "@@H ⚠️ SQM"; printf '%s\n' "$o" | fsplit; exit 0; }
case "$o" in *"$(t "non trovato" "not found")"*) echo "@@H ⚠️ SQM"; printf '%s\n' "$o" | fsplit; exit 0;; esac
case "$1 $(echo "$A" | tr 'A-Z' 'a-z' | sed 's/^ *//; s/ *$//')" in sqm_off*|"sqm_profilo spento"|"sqm_profilo off") esito 5 "$o" sqmst sqmk on false ;; *) esito 10 "$o" sqmst sqmk run ;; esac
;;
sqm_prova)
o=$(ubus -t 10 call wrtfreedom sqmtest '{"action":"start"}' 2>/dev/null)
[ -n "$o" ] || { t "@@H ⚠️ Prova Prima e Dopo ¦ Non partita ¦ Il router non risponde" "@@H ⚠️ Before and After Test ¦ Not started ¦ The router does not answer"; exit 0; }
e=$(echo "$o" | jsonfilter -e '@.error' 2>/dev/null)
[ -z "$e" ] || { echo "@@H ⚠️ $(t "Prova Prima e Dopo ¦ Non partita" "Before and After Test ¦ Not started") ¦ $e"; exit 0; }
( i=0; s=run
while [ $i -lt 72 ] && [ "$s" = run ]; do sleep 5; i=$((i + 1)); s=$(jsonfilter -i /tmp/wf-abtest.json -e '@.st' 2>/dev/null); done
R=/tmp/wf-abtest.json; g() { jsonfilter -i $R -e "$1" 2>/dev/null; }
case "$s" in
ok) m="🧪 $(t "Senza SQM: voto" "Without SQM: grade") $(g '@.off.grade') (+$(g '@.off.inc') ms) ¦ $(t "Con SQM: voto" "With SQM: grade") $(g '@.on.grade') (+$(g '@.on.inc') ms) ¦ $(t "Dati usati" "Data used"): $(g '@.mb') MB" ;;
err) m="⚠️ $(t "Prova non riuscita" "Test failed") ¦ $(g '@.msg')" ;;
*) m="⚠️ $(t "Nessun risultato" "No result") ¦ $(t "Dopo 6 minuti" "After 6 minutes")" ;;
esac
WF_HEAD="🌐|$(t "Prova Prima e Dopo" "Before and After Test")"; dopo "$m" ) </dev/null >/dev/null 2>&1 &
t "@@H 🌐 Prova Prima e Dopo ¦ Partita: circa 1 minuto ¦ Fino a 250 MB ¦ Ti scrivo qui il voto" "@@H 🌐 Before and After Test ¦ Started: about 1 minute ¦ Up to 250 MB ¦ I will write the grade here"; echo ;;
cella)
ucode $W/modemctl.uc tg cella
;;
bande)
ucode $W/modemctl.uc tg bande
;;
operatore)
ucode $W/modemctl.uc tg operatore
;;
rete_mobile)
ucode $W/modemctl.uc tg rete_mobile
;;
sim)
ucode $W/modemctl.uc tg sim
;;
imei)
i=$(ATR 'AT+CGSN' | grep -oE '[0-9]{14,16}' | sed -n 1p)
echo "@@H 🌐 IMEI"; echo "${i:-$(t "Non letto dal modem" "Not read from the modem")}"
;;
riavvia_modem)
t "@@H 🌐 Modem ¦ Riavvio in corso ¦ Linea di nuovo tra 1 minuto ¦ Ti scrivo qui l'esito" "@@H 🌐 Modem ¦ Restarting ¦ Line back in 1 minute ¦ I will write the result here"
( sleep 2
if ucode $W/modemctl.uc restart >/dev/null 2>&1; then sleep 20; dopo "$(esito 160 "$(t "Modem riavviato, linea attiva" "Modem restarted, line up")" linest lineup)"
else dopo "$(nr "$(t "il modem rifiuta il riavvio" "the modem refused the restart")")"; fi ) >/dev/null 2>&1 </dev/null &
;;
solo4g)
ucode $W/modemctl.uc tg solo4g
;;
standard)
ucode $W/modemctl.uc tg standard
;;
celle)
ucode $W/modemctl.uc tg celle
;;
temp_modem)
ucode $W/modemctl.uc tg temp_modem
;;
apn)
echo "@@H 🌐 APN"; o=$(ATR 'AT+CGDCONT?' | grep CGDCONT | sed 's/+CGDCONT: //; s/"//g' | awk -F, '{printf "• %s · %s · %s\n",$1,$2,($3==""?"-":$3)}')
echo "${o:-$(t "Nessun APN letto" "No APN read")}"
;;
sms)
ATR 'AT+CMGF=1' >/dev/null; o=$(ATR 'AT+CMGL="ALL"' | grep -v '^OK$')
[ -n "$(echo "$o" | grep CMGL)" ] || { t "@@H 🌐 SMS ¦ Nessuno sulla SIM" "@@H 🌐 SMS ¦ None on the SIM"; exit 0; }
echo "@@H 🌐 SMS"; echo "$o" | sed 's/+CMGL: [0-9]*,"[^"]*","\([^"]*\)",[^,]*,"\([^"]*\)".*/\n📨 \1 · \2/' | tail -n 40
;;
at)
echo "@@H 🌐 $(t "Comando AT" "AT Command")"
echo "$A" | grep -qiE '^AT[A-Za-z0-9+&=?,";:_ .*#%!^$-]*$' || { t "Scrivi un comando con AT" "Type a command with AT"; exit 0; }
U=$(printf '%s' "$A" | tr 'a-z' 'A-Z')
case "$U" in
*';'*) ok=0 ;;
AT+COPS=\?|AT+CPOL=\?|AT+QOPS*|*SCAN*) ok=2 ;;
AT|ATI|ATI0|AT\&V|AT+CSQ|AT+CIMI|AT+CGMI|AT+CGMM|AT+CGMR|AT+CGSN|AT+GMI|AT+GMM|AT+GMR|AT+GSN|AT+CCID|AT+QCCID|AT+ICCID|AT+CNUM|AT+QNWINFO|AT+QSPN|AT+QCSQ|AT+QRSRP|AT+QTEMP|AT+QCAINFO|'AT+QENG="SERVINGCELL"'|'AT+QENG="NEIGHBOURCELL"') ok=1 ;;
*) ok=0; echo "$U" | grep -qE '^AT[+$^%!][A-Z0-9]{1,16}=?\?$' && ok=1 ;;
esac
[ $ok = 2 ] && { t "Ricerca lunga rifiutata ¦ Fermerebbe la linea" "Long search refused ¦ It would stop the line"; echo; exit 0; }
[ $ok = 1 ] || { t "Solo comandi di lettura ¦ Es. AT+CSQ, AT+CFUN?" "Read-only commands only ¦ E.g. AT+CSQ, AT+CFUN?"; echo; exit 0; }
o=$(ATR "$A"); case "$o" in "ERROR: "*) nr "$(printf '%s\n' "${o#ERROR: }" | f29 | sed ':a;N;$!ba;s/\n/ ¦ /g')"; exit 0 ;; esac
echo "${o:-$(t "Nessuna risposta" "No answer")}" | f29
;;
wifi)
echo "@@H 📶 Wi-Fi"
F=$(wifi_ifs)
for i in $F; do
iwinfo $i info 2>/dev/null | awk -v c="$(iwinfo $i assoclist 2>/dev/null | grep -c dBm)" -v EN=$EN '/ESSID/{gsub(/.*ESSID: "|"$/,""); s=$0} /Channel:/{for(k=1;k<=NF;k++) if($k=="Channel:") ch=$(k+1); if(match($0,/\([0-9.]+ GHz\)/)) g=substr($0,RSTART+1,RLENGTH-6); sub(/\.0*$/,"",g); sub(/^5\.[0-9]*$/,"5",g); sub(/^2\.4[0-9]*$/,"2.4",g); sub(/^6\.[0-9]*$/,"6",g)} END{printf "%s · %s GHz\n%s: %d · %s %s\n", s, g, EN?"Devices":"Dispositivi", c, EN?"channel":"canale", ch}'
done
for s in $(uci -q show wireless | sed -n "s/^wireless\.\([^.=]*\)=wifi-iface$/\1/p"); do
[ "$(uci -q get wireless.$s.disabled)" = 1 ] && echo "$(uci -q get wireless.$s.ssid): $(t spenta off)"
done
[ -n "$F" ] || { t "Spento" "Off"; echo; }
;;
wifi_on)
sh $W/event.sh act wifi_on >/dev/null 2>&1; esito 20 "$(t "Wi-Fi acceso" "Wi-Fi on")" wifist wifion
;;
wifi_off)
t "@@H 📶 Wi-Fi ¦ Lo spengo ¦ Ti scrivo qui l'esito" "@@H 📶 Wi-Fi ¦ Turning it off ¦ I will write the result here"
( sleep 3; sh $W/event.sh act wifi_off; dopo "$(esito 15 "$(t "Wi-Fi spento" "Wi-Fi off")" wifist non wifion)" ) >/dev/null 2>&1 </dev/null &
;;
wifi_riavvia)
t "@@H 📶 Wi-Fi ¦ Riavvio in corso ¦ Ti scrivo qui l'esito" "@@H 📶 Wi-Fi ¦ Restarting ¦ I will write the result here"
( sleep 3; ucode $W/wifi.uc restart; dopo "$(esito 20 "$(t "Wi-Fi riavviato" "Wi-Fi restarted")" wifist wifion)" ) >/dev/null 2>&1 </dev/null &
;;
ospiti)
G=$(uci -q show wireless | sed -n "s/^wireless\.\([^.]*\)\.network='guest'$/\1/p")
echo "@@H 📶 $(t "Rete Ospiti" "Guest Network")"
for s in $G; do echo "$(uci -q get wireless.$s.ssid): $([ "$(uci -q get wireless.$s.disabled)" = 1 ] && t spenta off || t accesa on)"; done
[ -n "$G" ] || { t "Non configurata" "Not set up"; echo; }
;;
ospiti_on|ospiti_off)
o=$(ubus call wrtfreedom quick "{\"act\":\"guest_${1#ospiti_}\"}" 2>&1)
echo "$o" | grep -q '"ok"' || { nr "$(uerr "$o")"; exit 0; }
if [ "$1" = ospiti_on ]; then esito 20 "$(t "Rete ospiti accesa" "Guest network on")" gsttxt gston
else esito 20 "$(t "Rete ospiti spenta" "Guest network off")" gsttxt gstoff; fi
;;
password_wifi)
mkdir -p /tmp/wf-tgfile && chmod 700 /tmp/wf-tgfile
f=/tmp/wf-tgfile/$(t Password-WiFi WiFi-Passwords).txt
for s in $(uci -q show wireless | sed -n "s/^wireless\.\([^.=]*\)=wifi-iface$/\1/p"); do
[ "$(uci -q get wireless.$s.mode)" = ap ] || continue
n=$(uci -q get wireless.$s.ssid); [ -n "$A" ] && ! echo "$n" | grep -qiF "$A" && continue
k=$(uci -q get wireless.$s.key); e=$(uci -q get wireless.$s.encryption)
if [ "$e" = none ] || [ -z "$k" ]; then printf '%s · %s\n' "$n" "$(t "rete aperta" "open network")"; else printf '%s · %s\n' "$n" "$k"; fi
done | awk '!s[$0]++' > "$f"
[ -s "$f" ] || { rm -f "$f"; t "@@H 📶 Password Wi-Fi ¦ Nessuna rete trovata" "@@H 📶 Wi-Fi Passwords ¦ No network found"; exit 0; }
echo "@@DOC $f ttl=300"; t "@@H 📶 Password Wi-Fi ¦ Si cancella tra 5 minuti" "@@H 📶 Wi-Fi Passwords ¦ Deleted in 5 minutes"
;;
qr_wifi)
for s in $(uci -q show wireless | sed -n "s/^wireless\.\([^.=]*\)=wifi-iface$/\1/p"); do
[ "$(uci -q get wireless.$s.mode)" = ap ] && [ "$(uci -q get wireless.$s.disabled)" != 1 ] || continue
n=$(uci -q get wireless.$s.ssid); [ -n "$A" ] && ! echo "$n" | grep -qiF "$A" && continue
k=$(uci -q get wireless.$s.key); e=$(uci -q get wireless.$s.encryption)
x() { printf '%s' "$1" | sed 's/[\\;,:"]/\\&/g'; }
if [ "$e" = none ] || [ -z "$k" ]; then q="WIFI:T:nopass;S:$(x "$n");;"; else q="WIFI:T:WPA;S:$(x "$n");P:$(x "$k");;"; fi
qrphoto "$q" "📶 $n"; exit 0
done
t "@@H 📶 QR Wi-Fi ¦ Nessuna rete trovata" "@@H 📶 Wi-Fi QR ¦ No network found"
;;
canali)
echo "@@H 📶 $(t "Reti Vicine" "Nearby Networks")"
for i in $(wifi_ifs); do
g=$(iwinfo $i info 2>/dev/null | awk '!g && match($0, /\([0-9.]+ GHz\)/) {g = substr($0, RSTART + 1, RLENGTH - 6) + 0} END {if (g) print (g >= 5.9 ? 6 : g >= 5 ? 5 : 2.4) " GHz"}')
iwinfo $i scan 2>/dev/null | awk '/Channel:/{for(k=1;k<=NF;k++) if($k=="Channel:") print $(k+1)}' | sort -n | uniq -c | awk -v g="${g:-Wi-Fi}" -v EN=$EN 'NR==1{printf "%s:\n", g} {printf "• %s %s: %d %s\n", EN?"Channel":"Canale", $2, $1, EN?"networks":"reti"}'
done
;;
segnale_wifi)
echo "@@H 📶 $(t "Segnale Wi-Fi" "Wi-Fi Signal")"; CLX=$(cl_all); DV_=$(devs)
for i in $(wifi_ifs); do
iwinfo $i assoclist 2>/dev/null | awk '/dBm/ && /^[0-9A-Fa-f][0-9A-Fa-f]:/{print tolower($1), $2}' | while read m s; do
echo "$s $(dn $m)"
done
done | sort -n | while read s n; do echo "• $n: $s dBm"; done | lmax 40
;;
potenza)
echo "@@H 📶 $(t "Potenza Radio" "Radio Power")"
for i in $(wifi_ifs); do
iwinfo $i info 2>/dev/null | awk -v EN=$EN '/ESSID/{gsub(/.*ESSID: "|"$/,""); s=$0} /Tx-Power/{for(k=1;k<=NF;k++){if($k=="Tx-Power:") p=$(k+1) " " $(k+2)}} /Channel:/{for(k=1;k<=NF;k++){ if($k=="Channel:") c=$(k+1); if($k=="HT" && $(k+1)=="Mode:") h=$(k+2) }} END{printf "%s\n%s: %s · %s\n%s: %s\n", s, EN?"Channel":"Canale", c, h, EN?"Power":"Potenza", p}'
done
;;
client)
CLX=$(cl_all); [ -n "$CLX" ] || { t "@@H ⚠️ Dispositivi ¦ Nessuna risposta dal router" "@@H ⚠️ Devices ¦ No answer from the router"; exit 0; }
echo "@@H 📱 $(t Dispositivi Devices) ($(echo "$CLX" | awk '$1 == "n" {print $2; exit}'))"
echo "$CLX" | awk '$1 != "n"' | while read m o i n; do
[ "$n" = - ] && n=$(dalt "$m"); [ "$o" = on ] && d=✅ || d=•; [ "$i" = - ] && echo "$d $n" || echo "$d $n · $i"
done | sort -k2 | lmax 60
;;
online)
O=$(cl_all | awk '$1 != "n" && $2 == "on"'); [ -n "$O" ] || { t "@@H 📱 Attivi Adesso ¦ Nessun dispositivo" "@@H 📱 Active Now ¦ No device"; exit 0; }
echo "@@H 📱 $(t "Attivi Adesso" "Active Now") ($(echo "$O" | wc -l))"
echo "$O" | while read m o ip n; do [ "$n" = - ] && n=$(dalt "$m"); [ "$ip" = - ] && echo "• $n" || echo "• $n · $ip"; done | sort | lmax 60
;;
nuovi)
o=$(grep '|dev_new|' "$LOG" 2>/dev/null | tail -n 10)
[ -n "$o" ] || { t "@@H 📱 Dispositivi Nuovi ¦ Nessuno nel registro" "@@H 📱 New Devices ¦ None in the log"; exit 0; }
echo "@@H 📱 $(t "Dispositivi Nuovi" "New Devices")"
echo "$o" | awk -F'|' '{cmd="date -d @" $1 " \"+%d/%m %H:%M\""; cmd | getline d; close(cmd); i=index($4, " ¦ ");
		if (i) { $4=substr($4, 1, i-1); sub(/^[^ ]+ /,"",$4) } else { sub(/^[^:]*: /,"",$4); sub(/ \([^()]*\)$/,"",$4) } print "• " d " · " $4}'
;;
cerca)
find_dev; O=$(cl_on | cut -d' ' -f1)
echo "@@H 📱 $(t Trovati Found)"
echo "$R" | while read m i n; do echo "$O" | grep -qx "$m" && d=✅ || d=•; [ "$n" = - ] && n=$(dalt "$m"); [ "$i" = - ] && echo "$d $n · $m" || echo "$d $n · $i"; done
;;
dettagli)
one_dev
echo "@@H 📱 $NM"
[ "$IP" = - ] || echo "IP: $IP"; echo "MAC: $MAC"
cl_on | cut -d' ' -f1 | grep -qx "$MAC" && echo "$(t Stato Status): $(t attivo active)" || echo "$(t Stato Status): $(t "non attivo" "inactive")"
e=$(leases | awk -v m=$MAC '!e && tolower($2) == m {e = $1} END {if (e != "") print e}'); [ -n "$e" ] && [ "$e" != 0 ] && echo "$(t "Contratto fino a" "Lease until"): $(date -d @$e '+%d/%m %H:%M' 2>/dev/null)"
uci -q show dhcp 2>/dev/null | grep -qi "mac='$MAC'" && { t "IP riservato: sì" "Reserved IP: yes"; echo; }
for i in $(wifi_ifs); do s=$(iwinfo $i assoclist 2>/dev/null | awk -v m=$MAC 'tolower($1)==m{print $2; exit}'); [ -n "$s" ] && echo "$(t "Segnale Wi-Fi" "Wi-Fi signal"): $s dBm"; done
uci -q get "firewall.x3kb_$(echo "$MAC" | tr -d :)" >/dev/null && { t "Internet: bloccato" "Internet: blocked"; echo; }
;;
blocca|sblocca)
one_dev
[ "$MAC" = "$(echo "$MAC" | grep -E '^([0-9a-f]{2}:){5}[0-9a-f]{2}$')" ] || { t "@@H ⚠️ Dispositivi ¦ MAC non valido" "@@H ⚠️ Devices ¦ Invalid MAC"; exit 0; }
a=block; [ "$1" = sblocca ] && a=unblock
o=$(ubus call wrtfreedom quick "{\"act\":\"$a\",\"mac\":\"$MAC\",\"name\":\"$(echo "$NM" | tr -d '"\\')\"}" 2>&1)
echo "$o" | grep -q '"ok"' || { nr "$(uerr "$o")"; exit 0; }
if [ $a = block ]; then esito 15 "$NM $(t "bloccato" "blocked")" 'echo "$NM ¦ $(blkst "$MAC")"' blk "$MAC"
else esito 15 "$NM $(t "sbloccato" "unblocked")" 'echo "$NM ¦ $(blkst "$MAC")"' unblk "$MAC"; fi
;;
client_bloccati)
B=$(uci -q show firewall | sed -n "s/^firewall\.\(x3kb_[0-9a-f]*\)=rule$/\1/p")
[ -n "$B" ] || { t "@@H 📱 Bloccati ¦ Nessun dispositivo" "@@H 📱 Blocked ¦ No device"; exit 0; }
echo "@@H 📱 $(t Bloccati Blocked)"; CLX=$(cl_all)
for b in $B; do m=$(uci -q get firewall.$b.src_mac | awk '{print $1}'); echo "• $(dn "$m" "$(uci -q get firewall.$b.name)") · $m"; done
;;
disconnetti)
one_dev; n=0
for o in $(ubus list 'hostapd.*' 2>/dev/null); do
ubus call $o del_client "{\"addr\":\"$MAC\",\"reason\":5,\"deauth\":true,\"ban_time\":30000}" >/dev/null 2>&1 && n=1
done
[ $n = 1 ] || { echo "@@H 📱 $NM"; t "Non è collegato al Wi-Fi" "Not on Wi-Fi"; echo; exit 0; }
esito 5 "$NM $(t "scollegato dal Wi-Fi" "kicked off Wi-Fi") ¦ $(t "Può tornare dopo 30 s" "Can return after 30 s")" 'echo "$NM $(t "ancora collegato al Wi-Fi" "still on Wi-Fi")"' non assoc "$MAC"
;;
sveglia)
one_dev
o=$(ubus call wrtfreedom wol "{\"mac\":\"$MAC\"}" 2>&1)
echo "$o" | grep -q '"ok"' && { echo "@@H 📱 $NM"; t "Accensione inviata" "Wake sent"; echo; } || nr "$(uerr "$o")"
;;
top_client)
o=$(ubus call wrtfreedom clusage 2>/dev/null)
[ -n "$o" ] || { t "@@H ⚠️ Consumo ¦ Nessuna risposta dal router" "@@H ⚠️ Usage ¦ No answer from the router"; exit 0; }
L=$(echo "$o" | J 'let L=[]; for(let m in d.devs ?? {}) { let x=d.devs[m].month ?? [0,0]; if(x[0]+x[1]>0) push(L,[m,x[0],x[1]]); } L=sort(L,(a,b)=>(b[1]+b[2])-(a[1]+a[2])); for(let i=0;i<length(L)&&i<15;i++) print(L[i][0]," ",L[i][1]," ",L[i][2],"\n");')
[ -n "$L" ] || { echo "@@H 📊 $(t "Consumo Dei Dispositivi" "Device Usage")"; echo "$o" | jsonfilter -e '@.ok' 2>/dev/null | grep -q true && t "Nessuno in 30 giorni" "None in 30 days" || { t "Conteggio non attivo" "Counting not active"; echo; echo "$o" | jsonfilter -e '@.why' 2>/dev/null; }; exit 0; }
echo "@@H 📊 $(t "Consumo Dei Dispositivi" "Device Usage")"; t "Ultimi 30 giorni" "Last 30 days"; echo; CLX=$(cl_all)
DV_=$(devs); echo "$L" | while read m r s; do
printf '• \t%s\t\n↓ %s · ↑ %s\n' "$(dn $m)" "$(hb $r)" "$(hb $s)"
done | f29
;;
fasce)
o=$(ubus call wrtfreedom shaper 2>/dev/null)
echo "$o" | grep -q '"list"' || { echo "@@H ⚠️ $(t "Orari e Velocità" "Schedules and Speed")"; uerr "$o"; exit 0; }
echo "$o" | J 'let G=EN?["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]:["Dom","Lun","Mar","Mer","Gio","Ven","Sab"], hm=(x)=>{let n=localtime(x); return sprintf("%02d:%02d",n.hour,n.min);}, L=filter(d.list ?? [],(r)=>r.dl||r.ul);
		print("@@H ⏰ ", EN?"Schedules and Speed":"Orari e Velocità", "\n");
		if(d.can===false) print("⚠️ ", d.why ?? "", "\n");
		if(!length(L)) { print(EN?"No limits":"Nessun limite", "\n"); exit(0); }
		for(let r in L) {
			let who=r.casa ? (EN?"The whole house":"Tutta la casa") : length(r.name ?? "") ? r.name : (r.mac ?? (EN?"person":"persona")), sp="↓ " + (r.dl ?? "—") + (r.ul ? " · ↑ " + r.ul : "") + " Mbit/s";
			let dd=length(r.days ?? "") ? join(", ", map(split(r.days,""),(c)=>G[+c])) : (EN?"every day":"tutti i giorni"), st=r.off ? (EN?" · paused":" · sospesa") : r.on===true ? " · " + (EN?"active now":"attiva adesso") : "";
			if(r.kind=="slow") print("• 🐢 ", who, " · ", sp, " · ", EN?"until ":"fino alle ", hm(r.until), "\n");
			else if(r.kind=="fix") print("• ⚡ ", who, " · ", sp, " · ", EN?"always":"sempre", "\n");
			else print("• ", who, " · ", r.from ? r.from + "–" + r.to + " · " : "", dd, " · ", sp, st, r.next && !r.off ? " · " + (EN?"changes at ":"cambia alle ") + hm(r.next) : "", "\n");
		}
		print(EN?"Slots used: ":"Posti usati: ", d.used, "/", d.max, "\n");'
;;
limita|rallenta)
C=$1; OFF=0
case "$(echo "$A" | tr 'A-Z' 'a-z')" in *" off"|*" togli") OFF=1; A=${A% *} ;; esac	# «togli» = «off» in italiano
P=$(echo "$A" | awk '{n=0;for(i=NF;i>1&&$i~/^[0-9]+$/&&n<2;i--)n++;s="";for(j=1;j<=NF-n;j++)s=s (j>1?" ":"") $j;print s "|" (n>=1?$(NF-n+1):"") "|" (n==2?$NF:"")}')
A=${P%%|*}; P=${P#*|}; V1=${P%%|*}; V2=${P#*|}
[ $OFF = 1 ] || [ -n "$V1" ] || [ $C = rallenta ] || { t "@@H 📱 Limita Velocità ¦ Scrivi nome e Mbit/s ¦ Es. TV 20, oppure TV togli" "@@H 📱 Speed Limit ¦ Type name and Mbit/s ¦ E.g. TV 20, or TV off"; exit 0; }
WHO=; TG=; NM=
if [ $C = rallenta ]; then
case "$(echo "$A" | tr 'A-Z' 'a-z')" in casa|tutti|"tutta la casa"|home|house|all|everyone) WHO=casa; TG='"casa":true'; NM=$(t "Tutta la casa" "The whole house") ;; esac
[ -n "$WHO" ] || for p in $(uci -q show wrtfreedom | sed -n "s/^wrtfreedom\.\(p_[a-z0-9]*\)=person$/\1/p"); do
[ "$(uci -q get wrtfreedom.$p.name | tr 'A-Z' 'a-z')" = "$(echo "$A" | tr 'A-Z' 'a-z')" ] || continue
M=$(for m in $(uci -q get wrtfreedom.$p.mac | tr 'A-F' 'a-f'); do echo "$m" | grep -qE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$' && printf '"%s",' "$m"; done)
[ -n "$M" ] || continue
WHO="p:$p"; TG="\"macs\":[${M%,}]"; NM=$(uci -q get wrtfreedom.$p.name); break
done
fi
[ -n "$WHO" ] || { one_dev; WHO="d:$(echo "$MAC" | tr -d :)"; TG="\"mac\":\"$MAC\""; }
if [ $C = limita ]; then
if [ $OFF = 1 ]; then X="{\"kind\":\"fix\",$TG,\"off\":true}"
else
echo "$V1" | grep -qE '^[0-9]{1,5}$' && [ "$V1" -ge 1 ] && [ "$V1" -le 10000 ] || { t "@@H ⚠️ Velocità ¦ Non valida ¦ Da 1 a 10000 Mbit/s" "@@H ⚠️ Speed ¦ Not valid ¦ From 1 to 10000 Mbit/s"; exit 0; }
U=${V2:-$V1}; echo "$U" | grep -qE '^[0-9]{1,5}$' && [ "$U" -ge 1 ] && [ "$U" -le 10000 ] || { t "@@H ⚠️ Velocità ¦ Non valida ¦ Da 1 a 10000 Mbit/s" "@@H ⚠️ Speed ¦ Not valid ¦ From 1 to 10000 Mbit/s"; exit 0; }
V1=$(( ${V1#"${V1%%[!0]*}"} )); U=$(( ${U#"${U%%[!0]*}"} ))
X="{\"kind\":\"fix\",$TG,\"dl\":$V1,\"ul\":$U}"
fi
o=$(ubus call wrtfreedom shaper "{\"add\":\"$(echo "$X" | sed 's/"/\\"/g')\"}" 2>&1)
echo "$o" | grep -q '"ok"' || { nr "$(uerr "$o")"; exit 0; }
if [ $OFF = 1 ]; then esito 3 "$NM: $(t "di nuovo alla velocità piena" "back to full speed")" "shst $MAC" shno "$MAC"
else esito 3 "$NM: $(t "al massimo" "at most") ↓ $V1 · ↑ $U Mbit/s · $(t "posti liberi" "free slots") $(echo "$o" | jsonfilter -e '@.left' 2>/dev/null)" "shst $MAC" shis "$MAC" "$V1"; fi
exit 0
fi
K=${WHO#d:}; K=${K#p:}
if [ $OFF = 1 ]; then
o=$(ubus call wrtfreedom shaper "{\"del\":\"slow_$K\"}" 2>&1)
echo "$o" | grep -q '"ok"' || { echo "@@H 📱 $NM"; t "Non era rallentato" "Was not slowed down"; echo; exit 0; }
esito 3 "$NM: $(t "di nuovo alla velocità piena" "back to full speed")" "shst slow_$K" shno "slow_$K"
exit 0
fi
V1=${V1:-10}; V2=${V2:-60}
echo "$V1" | grep -qE '^[0-9]{1,5}$' && [ "$V1" -ge 1 ] && [ "$V1" -le 10000 ] || { t "@@H ⚠️ Velocità ¦ Non valida ¦ Da 1 a 10000 Mbit/s" "@@H ⚠️ Speed ¦ Not valid ¦ From 1 to 10000 Mbit/s"; exit 0; }
echo "$V2" | grep -qE '^[0-9]{1,4}$' && [ "$V2" -ge 1 ] && [ "$V2" -le 1440 ] || { t "@@H ⚠️ Minuti ¦ Non validi ¦ Da 1 a 1440" "@@H ⚠️ Minutes ¦ Not valid ¦ From 1 to 1440"; exit 0; }
V1=$(( ${V1#"${V1%%[!0]*}"} )); V2=$(( ${V2#"${V2%%[!0]*}"} ))	# in base 10 (020 = 20)
X="{\"kind\":\"slow\",\"who\":\"$WHO\",$TG,\"dl\":$V1,\"min\":$V2}"
o=$(ubus call wrtfreedom shaper "{\"add\":\"$(echo "$X" | sed 's/"/\\"/g')\"}" 2>&1)
echo "$o" | grep -q '"ok"' || { nr "$(uerr "$o")"; exit 0; }
esito 3 "$NM: $(t "al massimo" "at most") $V1 Mbit/s $(t "fino alle" "until") $(date -d @$(( $(date +%s) + V2 * 60 )) +%H:%M 2>/dev/null), $(t "poi torna veloce da solo" "then back to full speed by itself")" "shst slow_$K" shis "slow_$K" "$V1"
;;
ip_fissi)
H=$(uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=host$/\1/p")
[ -n "$H" ] || { t "@@H 📱 IP Riservati ¦ Nessuno" "@@H 📱 Reserved IPs ¦ None"; exit 0; }
echo "@@H 📱 $(t "IP Riservati" "Reserved IPs")"
for h in $H; do echo "• $(uci -q get dhcp.$h.name || echo -) · $(uci -q get dhcp.$h.ip)"; done
;;
vpn)
I=$(wgif); [ -n "$I" ] || { t "@@H 🔐 Server VPN ¦ Non configurato" "@@H 🔐 VPN Server ¦ Not set up"; exit 0; }
now=$(date +%s); D=$(wg show $I dump 2>/dev/null)
echo "@@H 🔐 $(t "Server VPN" "VPN Server")"
echo "$(t Stato Status): $(isup $I && t acceso on || t spento off)"
echo "$(t Porta Port): $(uci -q get network.$I.listen_port)"
echo "$(t Dispositivi Devices): $(echo "$D" | tail -n +2 | grep -c .)"
echo "$(t "Collegati adesso" "Connected now"): $(echo "$D" | tail -n +2 | awk -v n=$now '$5>0 && n-$5<180' | wc -l)"
G=$(wfget vpnwd)
if [ -n "$G" ]; then
if [ "$(jv "$G" @.how)" = loop ]; then w=$(t "ogni 30 s" "every 30 s")
elif [ "$(jv "$G" @.on)" = true ] && [ -n "$(jv "$G" @.ifc)" ]; then w=$(t "il tuo script" "your script")
else w=$(t spento off); fi
echo "$(t "Controllo" "Check"): $w"
lt=$(jv "$G" @.last.t)
if [ -n "$lt" ]; then
if [ "$(jv "$G" @.last.rc)" = 0 ]; then w=$(t riaccesa "back on")
elif [ "$(jv "$G" @.down)" = true ]; then w=$(t "non riaccesa" "not back on")
else w=$(t "tornata da sola" "recovered"); fi
echo "$(t "Intervento" "Fix"): $(dhm "$lt")"; echo "$(t Esito Result): $w"
fi
fi
;;
vpn_on|vpn_off|vpn_riavvia)
[ -n "$(wgif)" ] || { t "@@H 🔐 Server VPN ¦ Non configurato" "@@H 🔐 VPN Server ¦ Not set up"; exit 0; }
a=${1#vpn_}; [ $a = riavvia ] && a=restart
T0=$(date +%s); sh $W/event.sh act vpn_$a >/dev/null 2>&1
case $a in
on) esito 10 "$(t "Server VPN acceso" "VPN Server on")" vpnst vpnon ;;
off) esito 10 "$(t "Server VPN spento" "VPN Server off")" vpnst non vpnon ;;
*) esito 15 "$(t "Server VPN riavviato" "VPN Server restarted")" 'echo "$(vpnst) ¦ $(t "Non riavviato" "Not restarted")"' vpnnew ;;
esac
;;
vpn_peer|vpn_traffico)
I=$(wgif); now=$(date +%s)
[ $1 = vpn_peer ] && H="@@H 🔐 $(t "Dispositivi VPN" "VPN Devices")" || H="@@H 🔐 $(t "Traffico VPN" "VPN Traffic")"
D=$(wg show $I dump 2>/dev/null | tail -n +2); [ -n "$D" ] || { echo "$H"; t "Nessun dispositivo" "No device"; echo; exit 0; }
echo "$H"; NW=$(uci -q show network)
echo "$D" | while read pub _ ep ips hs rx tx _; do
n=$(echo "$NW" | awk -F. -v k="public_key='$pub'" '!n && index($0, k) {n = $2} END {if (n != "") print n}'); nm=$(uci -q get network.$n.description); nm=${nm:-${ips%%/*}}
case "$hs" in ''|*[!0-9]*) hs=0 ;; esac
if [ $1 = vpn_peer ]; then
if [ "$hs" -gt 0 ] && [ $((now - hs)) -lt 180 ]; then echo "✅ $nm · ${ep%:*}"
elif [ "$hs" -gt 0 ]; then echo "• $nm · $(t "visto" "seen") $(dur $((now - hs))) $(t fa ago)"
else echo "• $nm · $(t "mai collegato" "never connected")"; fi
else printf '• \t%s\t\n↓ %s · ↑ %s\n' "$nm" "$(hb $tx)" "$(hb $rx)"; fi
done | f29	# 6/11: righe oltre 29 caratteri con il dettaglio sotto («• iPhone Mikael» / «Mai collegato»)
;;
vpn_qr)
[ -n "$A" ] || { t "@@H 🔐 QR VPN ¦ Scrivi il nome" "@@H 🔐 VPN QR ¦ Type the device name"; exit 0; }
s=$(peer_find "$A"); [ -n "$s" ] || { echo "@@H 🔐 QR VPN ¦ $(t "Nessun dispositivo così" "No such device") ¦ $A"; exit 0; }
c=$(wgconf $s) || { t "@@H ⚠️ QR VPN ¦ Aggiunto fuori dall'app ¦ Chiave non sul router ¦ QR non rifattibile" "@@H ⚠️ VPN QR ¦ Added outside the app ¦ Key not on the router ¦ QR cannot be rebuilt"; exit 0; }
qrphoto "$c" "🔐 $A"
;;
vpn_nuovo)
n=$(printf '%s' "$A" | tr -d '"\\' | cut -c1-40); [ -n "$n" ] || { t "@@H 🔐 Nuovo Dispositivo VPN ¦ Scrivi il nome" "@@H 🔐 New VPN Device ¦ Type the name"; exit 0; }
[ -n "$(peer_find "$n")" ] && { echo "@@H 🔐 $n"; t "Esiste già" "Already exists"; echo; echo "$(t "Usa" "Use") /vpn_qr $n"; exit 0; }
o=$(ubus call wrtfreedom wgpeer "{\"action\":\"add\",\"name\":\"$n\",\"full\":false}" 2>&1)
s=$(echo "$o" | jsonfilter -e '@.id' 2>/dev/null); [ -n "$s" ] || { nr "$(uerr "$o" | sed 's/: / ¦ /')"; exit 0; }
[ "$(peer_find "$n")" = "$s" ] && wgconf $s >/dev/null || { nr "$(t "il dispositivo \"$n\" non risulta nel Server VPN" "device \"$n\" is not in the VPN Server")"; exit 0; }
qrphoto "$(wgconf $s)" "🔐 $n ¦ $(t "Nuovo dispositivo" "New device") ¦ IP: $(echo "$o" | jsonfilter -e '@.ip')"
;;
vpn_indirizzo)
I=$(wgif); h=$(uci -q get wrtfreedom.wg.host); how=$(t "scelto nell'app" "set in the app")
[ -n "$h" ] || { h=$(ddnshost); how="DDNS"; }
[ -n "$h" ] || { h=$(wanip); how=$(t "IP della linea" "line IP"); }
echo "@@H 🔐 $(t "Indirizzo VPN" "VPN Address")"
if [ -n "$h" ]; then echo "$h:$(uci -q get network.$I.listen_port)"; echo "$(t Origine Source): $how"
else t "Nessun indirizzo da fuori" "No address from outside"; echo; t "Scegline uno nell'app" "Choose one in the app"; echo; fi
p=$(pubip); [ -n "$p" ] && echo "$(t "IP pubblico" "Public IP"): $p"
w=$(wanip); cgnat "$w" && { t "⚠️ Linea dietro CGNAT" "⚠️ Line behind CGNAT"; echo; t "Da fuori non raggiungibile" "Not reachable from outside"; echo; }
;;
servizio_vpn)
v=; case "$(echo "$A" | tr 'A-Z' 'a-z')" in on|si|sì|accendi) v=on ;; off|no|spegni) v=off ;; esac
if [ -n "$v" ]; then
b=false; [ $v = on ] && b=true
v0=$(vsv on); T0=$(date +%s); o=$(ubus call wrtfreedom vpnout "{\"action\":\"onoff\",\"on\":$b,\"safe\":true}" 2>&1)
echo "$o" | grep -q '"ok"' || { nr "$(uerr "$o")"; exit 0; }
t "@@H 🔐 Client VPN ¦ $([ $v = on ] && echo Acceso || echo Spento) ¦ Controllo che funzioni ¦ Ti scrivo qui l'esito" "@@H 🔐 VPN Client ¦ Turned $v ¦ Checking that it works ¦ I will write the result here"
( # il controllo dei collegamenti (ogni 30 s da notify.sh) subito, per non aspettarlo
[ $v = on ] && { sleep 5; ( ucode $W/vpnctl.uc tick ) >/dev/null 2>&1 </dev/null & }
if r=$(esito 50 "$(t "Client VPN" "VPN Client") $(t "$([ $v = on ] && echo acceso || echo spento)" "$v")" "vsst $v" vsok $v); then
ubus call wrtfreedom vpnout '{"action":"confirm"}' 2>&1 | grep -q '"ok"' || r=$(nr "$(t "il router non ha accettato la conferma: il Client VPN torna com'era da solo" "the router did not accept the confirmation: the VPN Client goes back by itself")")
else
B=${WF_BAKDIR:-/etc/wrtfreedom/bak}; [ -d "$B/vpn" ] && echo 1 > "$B/vpn/notg"
vback() { [ "$(vsv on)" = "$v0" ]; }
if ubus call wrtfreedom vpnout '{"action":"back"}' 2>&1 | grep -q '"ok"' && esito 15 "" true vback >/dev/null; then r="$r · $(t "rimesso com'era" "restored")"
else r="$r · $(t "e non rimesso com'era" "and not restored")"; fi
fi
dopo "$r" ) >/dev/null 2>&1 </dev/null &
exit 0
fi
echo "@@H 🔐 $(t "Client VPN" "VPN Client")"
ubus call wrtfreedom vpnout '{"action":"state"}' 2>/dev/null | J '
		if (d.none || d.on == null) exit(0);
		let w = EN ? d.where : d.wherei, lt = d.pause ? localtime(d.pause) : null;
		print((EN ? "Status: " : "Stato: ") + lc(d.v) + "\n");
		if (d.on && length(w)) print((EN ? "Where: " : "Dove: ") + w + "\n");
		if (d.on) print((EN ? "For: " : "Per: ") + lc(d.who) + "\n");
		if (lt) print((EN ? "Paused until " : "In pausa fino alle ") + sprintf("%02d:%02d", lt.hour, lt.min) + "\n");
	'
ubus call wrtfreedom vpnout 2>/dev/null | J '
		if (d.none) { print(EN ? "Not set up\nConnect it in the app\n" : "Non configurato\nCollegalo nell" + chr(39) + "app\n"); exit(0); }
		for (let t in d.tunnels) {
			let s = t.srv ?? {}, ip = t.ip ?? {}, hs = (t.st ?? {}).hs ?? 0, ok = t.on && hs > 0 && d.now - hs < 180;
			let where = (ip.country && ok ? ip.country : s.city || s.name || s.host) + (ok && ip.city ? " · " + ip.city : "");
			print((ok ? "✅ " : "❌ ") + where + ": " + (!t.on ? (EN ? "off" : "spento") : ok ? (EN ? "connected" : "collegato") : (EN ? "not responding" : "non risponde")) + "\n");
			print((t.n == 0 ? (t.mode == "dev" ? (EN ? "Chosen devices" : "Dispositivi scelti") : t.mode == "except" ? (EN ? "All except some" : "Tutti tranne alcuni") : (EN ? "Whole home" : "Tutta la casa")) : length(t.devs) + (EN ? " devices" : " dispositivi")) +
				(ok && ip.ip ? " · IP " + ip.ip : "") + "\n");
		}
	'
;;
adguard)
s=$(adg GET status); case "$s" in @@H*) echo "$s"; exit 0 ;; esac
[ -n "$s" ] || { t "@@H ⚠️ AdGuard Home ¦ Non risponde" "@@H ⚠️ AdGuard Home ¦ Not answering"; exit 0; }
echo "@@H 🔒 AdGuard Home"
echo "$s" | grep -q '"protection_enabled":true' && t "Protezione: accesa" "Protection: on" || t "Protezione: spenta" "Protection: off"; echo
v=$(echo "$s" | jsonfilter -e '@.version' 2>/dev/null); [ -n "$v" ] && echo "$(t Versione Version): $v"
adg GET stats | J 'let q=d.num_dns_queries||0,b=d.num_blocked_filtering||0; printf("%s: %d\n%s: %d (%.1f%%)\n%s: %.0f ms\n", EN?"Queries":"Richieste", q, EN?"Blocked":"Bloccate", b, q?b*100/q:0, EN?"Average time":"Tempo medio", (d.avg_processing_time||0)*1000);' 2>/dev/null
;;
adg_on|adg_off)
adgok; v=true; [ $1 = adg_off ] && v=false
adg POST protection "{\"enabled\":$v}" >/dev/null
if [ $v = true ]; then esito 5 "$(t "AdGuard Home acceso" "AdGuard Home on")" adgst adgon
else esito 5 "$(t "AdGuard Home spento" "AdGuard Home off")" adgst adgoff; fi
;;
pausa)
m=$(echo "$A" | grep -oE '^[0-9]{1,4}'); [ -n "$m" ] && [ "$m" -gt 0 ] || { t "@@H 🔒 Pausa ¦ Scrivi i minuti (es. 10)" "@@H 🔒 Pause ¦ Type the minutes (e.g. 10)"; exit 0; }
adgok
adg POST protection "{\"enabled\":false,\"duration\":$((m * 60000))}" >/dev/null
esito 5 "$(t "Protezione in pausa per" "Protection paused for") $m min" adgst adgoff
;;
top_bloccati|top_domini|top_client_dns)
adgok
k=top_blocked_domains; h="@@H 🔒 $(t "Più Bloccati" "Most Blocked")"
[ $1 = top_domini ] && { k=top_queried_domains; h="@@H 🔒 $(t "Più Richiesti" "Most Requested")"; }
[ $1 = top_client_dns ] && { k=top_clients; h="@@H 🔒 $(t "Richieste Per Dispositivo" "Requests Per Device")"; }
echo "$h"; [ $1 = top_client_dns ] && DV_=$(devs)
WF_DOM=$(uci -q get 'dhcp.@dnsmasq[0].domain'); export WF_DOM
adg GET stats | J "let S={}, L=[], dm=getenv('WF_DOM') ?? '', x=length(dm) ? '.' + dm : null; for (let o in d.$k ?? []) for (let n in o) { let m = n;
		if (x && '$1' != 'top_client_dns' && length(m) > length(x) && substr(m, length(m) - length(x)) == x) m = substr(m, 0, length(m) - length(x));
		S[m] = (S[m] ?? 0) + o[n]; }
		for (let n in S) push(L, [n, S[n]]); L = sort(L, (a, b) => b[1] - a[1]); for (let i = 0; i < length(L) && i < 15; i++) print(L[i][0], ' ', L[i][1], '\n');" 2>/dev/null | while read n c; do
[ $1 = top_client_dns ] && { x=$(echo "$DV_" | awk -v i="$n" '!f && $2 == i && $3 != "-" {sub(/^[^ ]+ [^ ]+ /, ""); print; f = 1}'); n=${x:-$n}; }
printf '• %s \t%s\t\tm\n' "$c" "$n"
done | f29
;;
filtri)
adgok
echo "@@H 🔒 $(t "Liste Di Blocco" "Blocklists")"
adg GET filtering/status | J 'for(let f in (d.filters||[])) print(f.enabled?"✅ ":"❌ ", "\t", f.name, "\t\n", EN ? "Rules: " : "Regole: ", f.rules_count, "\n");' 2>/dev/null | f29
;;
risolvi)
okhost "$A"
echo "@@H 🔒 DNS"; echo "$(t Nome Name): $A"; nslookup "$A" 2>&1 | awk '/^Name:/{n=1;next} n&&/^Address/{sub(/^Address[ 0-9]*: */,""); print "• " $0}' | lmax 10
;;
dns_svuota)
if [ -x /etc/init.d/dnsmasq ]; then
/etc/init.d/dnsmasq restart >/dev/null 2>&1
if [ -n "$(svcst dnsmasq)" ]; then esito 10 "$(t "Cache DNS svuotata" "DNS cache cleared")" 't "Il server dei nomi non è ripartito" "The name server did not start again"' svcon dnsmasq
else esito 10 "$(t "Cache DNS svuotata" "DNS cache cleared")" 't "Il server dei nomi non è ripartito" "The name server did not start again"' pidon dnsmasq; fi
fi
if [ -n "$(adgcred)" ] && command -v curl >/dev/null 2>&1; then
adg POST cache_clear >/dev/null 2>&1
[ -n "$(adg GET status)" ] && { [ -x /etc/init.d/dnsmasq ] || echo "✅ $(t "Cache DNS di AdGuard Home svuotata" "AdGuard Home DNS cache cleared")"; } || nr "$(t "AdGuard Home non risponde" "AdGuard Home is not answering")"
elif [ ! -x /etc/init.d/dnsmasq ]; then t "@@H 🔒 DNS ¦ Nessuna cache da svuotare" "@@H 🔒 DNS ¦ No cache to clear"; echo
fi
;;
dns_server)
echo "@@H 🔒 $(t "Server DNS" "DNS Servers")"
u=$(uci -q get dhcp.@dnsmasq[0].server); [ -n "$u" ] && echo "dnsmasq → $u"
grep nameserver /tmp/resolv.conf.d/resolv.conf.auto 2>/dev/null | awk '{print "• " $2}' | sort -u
[ -n "$(adgcred)" ] && command -v curl >/dev/null 2>&1 && adg GET dns_info | J 'for(let u in (d.upstream_dns||[])) print("AdGuard → ", u, "\n");'
;;
ping)
okhost "$A"; o=$(ping -c 4 -W 2 "$A" 2>&1)
l=$(echo "$o" | sed -n 's/.*[ ,]\([0-9.]*\)% packet loss.*/\1/p' | head -n 1); m=$(echo "$o" | awk -F/ '/min\/avg/{printf "%.0f", $4}')
echo "@@H 🧰 Ping"; printf '\t%s\t\n' "$A" | f29
if [ -n "$m" ]; then echo "$(t "Risponde in" "Answers in") $m ms · ${l:-0}% $(t persi lost)"
else t "Nessuna risposta" "No answer"; echo; fi
;;
traceroute)
okhost "$A"; echo "@@H 🧰 $(t Percorso Route)"; echo "$A"; traceroute -n -w 2 -q 1 -m 20 "$A" 2>&1 | tail -n +2 | lmax 20
;;
latenza)
g=$(ip route show default 2>/dev/null | awk '{print $3; exit}')
echo "@@H 🧰 $(t Latenza Latency)"
for h in $g 1.1.1.1 8.8.8.8; do
r=$(ping -c 3 -W 2 "$h" 2>/dev/null | awk -F/ '/min\/avg/{print $4}')
case "$h" in 1.1.1.1) n=Cloudflare ;; 8.8.8.8) n=Google ;; *) n=Gateway ;; esac
echo "$n: ${r:-–} ms"
done
;;
speedtest)
echo "@@H 🧰 $(t "Test Di Velocità" "Speed Test")"; ucode $W/speed.uc text | fsplit
;;
porte)
R=$(uci -q show firewall | sed -n "s/^firewall\.\([^.=]*\)=redirect$/\1/p")
[ -n "$R" ] || { t "@@H 🔒 Porte Aperte ¦ Nessuna" "@@H 🔒 Open Ports ¦ None"; exit 0; }
echo "@@H 🔒 $(t "Porte Aperte" "Open Ports")"
for r in $R; do
[ "$(uci -q get firewall.$r.target)" = SNAT ] && continue
echo "$([ "$(uci -q get firewall.$r.enabled)" = 0 ] && echo ❌ || echo ✅) $(uci -q get firewall.$r.name): $(uci -q get firewall.$r.src_dport)"
echo "→ $(uci -q get firewall.$r.dest_ip):$(uci -q get firewall.$r.dest_port) $(uci -q get firewall.$r.proto)"
done
;;
interfacce)
echo "@@H 🧰 $(t "Tutte Le Reti" "All Networks")"
ubus call network.interface dump 2>/dev/null | J 'for(let i in d.interface){ if(i.interface=="loopback") continue; let a=i["ipv4-address"]; print(i.up?"1 ":"0 ", i.interface, " ", (a&&length(a)?a[0].address+"/"+a[0].mask:"-"), "\n"); }' |
while read u i a; do echo "$([ "$u" = 1 ] && echo ✅ || echo ❌) $(wf_ifname "$i")$([ "$a" = - ] || echo ": $a")"; done
;;
route)
echo "@@H 🧰 $(t "Tabella Dei Percorsi" "Routing Table")"
o=$({ ubus call network.interface dump 2>/dev/null | J 'for (let i in d.interface ?? []) if (i.l3_device && i.interface != "loopback") print(i.l3_device, " ", i.interface, "\n");' |
while read d i; do echo "N $d $(wf_ifname "$i")"; done
ip route show 2>/dev/null | sed 's/^/4 /'; ip -6 route show default 2>/dev/null | sed 's/^/6 /'
} | awk -v al="$(t "Altra rete" "Other network")" -v dr="$(t "diretta" "direct")" '
		$1 == "N" { if (!($2 in N)) { n = $0; sub(/^N [^ ]+ /, "", n); N[$2] = n }; next }
		{ dv = ""; gw = ""; for (k = 2; k < NF; k++) { if ($k == "dev") dv = $(k + 1); if ($k == "via") gw = $(k + 1) }
		  if (dv == "" || dv == "lo") next
		  nm = (dv in N) ? N[dv] : al
		  if ($2 == "default") print nm ($1 == 6 ? " IPv6" : "") ": " (gw != "" ? "via " gw : dr)
		  else if ($1 == 4) print $2 ": " nm }' | lmax 20)
echo "${o:-$(t "Nessun percorso" "No route")}"
;;
ddns)
S=$(uci -q -X show ddns | sed -n "s/^ddns\.\([^.=]*\)=service$/\1/p")
[ -n "$S" ] || { t "@@H 🧰 DDNS ¦ Nessun nome" "@@H 🧰 DDNS ¦ No name"; exit 0; }
RD=$(uci -q get ddns.global.ddns_rundir); RD=${RD:-/var/run/ddns}; LD=$(uci -q get ddns.global.ddns_logdir); LD=${LD:-/var/log/ddns}
echo "@@H 🧰 DDNS"
for s in $S; do
ip=$(cat "$RD/$s.ip" 2>/dev/null); n=$(uci -q get "ddns.$s.lookup_host"); [ -n "$n" ] || n=$(uci -q get "ddns.$s.domain")
echo "$([ "$(uci -q get "ddns.$s.enabled")" = 1 ] && echo ✅ || echo ❌) ${n:-$s}"; echo "IP: ${ip:-–}"
done
G=$(wfget ddnswd)
if [ -n "$G" ]; then
if [ "$(jv "$G" @.how)" = svc ]; then w=$(t "acceso" "on")
elif [ "$(jv "$G" @.on)" = true ] && [ -n "$(jv "$G" @.ifc)" ]; then w=$(t "il tuo script" "your script")
else w=$(t spento off); fi
echo "$(t "Controllo" "Check"): $w"
ct=$(jv "$G" @.chg.t); [ -n "$ct" ] && { echo "$(t "Ultimo cambio" "Last change"): $(dhm "$ct")"; echo "$(t "Nuovo IP" "New IP"): $(jv "$G" @.chg.ip)"; }
fi
[ -x /etc/init.d/acme ] && wfget certrenew | J '
		for (let c in d.certs ?? []) if (type(c) == "object" && c.on && c.na) { let n = localtime(+c.na);
			print(EN ? "Certificate" : "Certificato", "\n", c.dom, "\n", EN ? "Expires: " : "Scade il: ", sprintf("%02d/%02d", n.mday, n.mon), "\n",
				EN ? "Renewal: " : "Rinnovo: ", d.how ? (EN ? "automatic" : "automatico") : (EN ? "stopped" : "fermo"), "\n"); }'
;;
ddns_aggiorna)
o=$(sh $W/cron.sh ddnsforce 2>/dev/null)
case "$o" in @@H*) echo "$o" ;; "⚠️ "*) echo "@@H ⚠️ DDNS"; echo "${o#⚠️ }" ;; *) echo "@@H 🧰 DDNS"; echo "${o:-$(t "Nessuna risposta" "No answer")}" ;; esac
;;
nat)
w=$(wanip); p=$(pubip)
echo "@@H 🧰 NAT"; echo "$(t "IP linea" "Line IP"): ${w:-–}"; echo "$(t "IP pubblico" "Public IP"): ${p:-–}"
if [ -z "$w" ] || [ -z "$p" ]; then t "Non verificabile" "Cannot check"
elif [ "$w" = "$p" ]; then t "✅ IP pubblico diretto ¦ Porte e VPN raggiungibili" "✅ Direct public IP ¦ Ports and VPN reachable"
elif cgnat "$w"; then t "⚠️ CGNAT dell'operatore ¦ Porte e VPN chiuse da fuori" "⚠️ Carrier CGNAT ¦ Ports and VPN closed outside"
else t "⚠️ Doppio NAT ¦ Altro router davanti" "⚠️ Double NAT ¦ Another router in front"; fi; echo
;;
connessioni)
c=$(cat /proc/sys/net/netfilter/nf_conntrack_count 2>/dev/null); m=$(cat /proc/sys/net/netfilter/nf_conntrack_max 2>/dev/null)
echo "@@H 🧰 $(t Connessioni Connections)"; echo "$(t Aperte Open): ${c:-–} $(t di of) ${m:-–}"
[ -r /proc/net/nf_conntrack ] && {
echo "R 127.0.0.1"	# sempre almeno una riga di nomi (FNR == NR qui sotto)
ip addr show 2>/dev/null | awk '$1 == "inet" || $1 == "inet6" {sub(/\/.*/, "", $2); print "R", $2}'
sed -n 's/.*"ip": *"\([^"]*\)".*/R \1/p' /tmp/wf-pubip.json 2>/dev/null
cl_all | awk '$1 != "n" && $3 != "-" && $4 != "-" {l = $0; sub(/^[^ ]+ [^ ]+ [^ ]+ /, "", l); print "C", $3, l}'
devs | awk '$2 != "-" && $3 != "-" {l = $0; sub(/^[^ ]+ [^ ]+ /, "", l); print "D", $2, l}'
} | awk -v r=Router '
		# IPv6 delle connessioni scritto per intero (0000:…:0001): nella forma corta di ip addr (::1), 6/11 router vero
		function ip6(a,  g, n, j, s, b, bl, cs, cl) { if (a !~ /:/ || a ~ /::/) return a
			n = split(a, g, ":"); bl = 0; cl = 0
			for (j = 1; j <= n; j++) { sub(/^0+/, "", g[j]); if (g[j] == "") g[j] = "0" }
			for (j = 1; j <= n; j++) if (g[j] == "0") { if (!cl) cs = j; cl++; if (cl > bl) { bl = cl; b = cs } } else cl = 0
			s = ""; if (bl < 2) { for (j = 1; j <= n; j++) s = s (j > 1 ? ":" : "") g[j]; return s }
			for (j = 1; j < b; j++) s = s (j > 1 ? ":" : "") g[j]; s = s "::"
			for (j = b + bl; j <= n; j++) s = s g[j] (j < n ? ":" : ""); return s }
		FNR == NR { if (!($2 in N)) N[$2] = ($1 == "R") ? r : substr($0, length($1 $2) + 3); next }
		{ for (i = 1; i <= NF; i++) if ($i ~ /^src=/) { n[ip6(substr($i, 5))]++; break } }
		END { for (i in n) print n[i], ((i in N) ? N[i] : i) }' - /proc/net/nf_conntrack | sort -rn | awk '{c = $1; sub(/^[^ ]+ /, ""); print "• " $0 ": " c}' | lmax 8
;;
porta)
h=$(echo "$A" | awk '{print $1}' | sed 's/:[0-9]*$//'); p=$(echo "$A" | grep -oE '[0-9]{1,5}$')
okhost "$h"; [ -n "$p" ] && [ "$h" != "$p" ] || { t "@@H 🧰 Porta ¦ Scrivi indirizzo e porta ¦ Es. 1.1.1.1 443" "@@H 🧰 Port ¦ Type address and port ¦ E.g. 1.1.1.1 443"; exit 0; }
c=$(curl -s -o /dev/null -m 5 --connect-timeout 5 -w '%{time_connect}' "telnet://$h:$p" </dev/null 2>/dev/null); r=$?
echo "@@H 🧰 $(t Porta Port)"; echo "$h:$p"
if awk -v c="${c:-0}" 'BEGIN{exit !(c+0>0)}'; then echo "✅ $(t "Risponde" "Open")"
elif [ $r = 7 ]; then echo "❌ $(t "Chiusa" "Closed")"; else echo "❌ $(t "Non risponde" "Not answering")"; fi
;;
riavvia)
t "@@H ⚙️ Router ¦ Riavvio in corso" "@@H ⚙️ Router ¦ Restarting"
( sleep 5; reboot ) >/dev/null 2>&1 </dev/null &
;;
riavvia_rete)
t "@@H ⚙️ Rete ¦ Riavvio in corso ¦ Torna tra poco ¦ Ti scrivo qui l'esito" "@@H ⚙️ Network ¦ Restarting ¦ Back shortly ¦ I will write the result here"
mkdir -p /tmp/wf-want; date +%s > /tmp/wf-want/_all
( sleep 3; /etc/init.d/network restart; dopo "$(esito 60 "$(t "Rete riavviata, linea attiva" "Network restarted, line up")" linest lineup)" ) >/dev/null 2>&1 </dev/null &
;;
log)
echo "@@H ⚙️ $(t Registro Log)"
logread 2>/dev/null | tail -n 200 | awk -v sy="$(t Sistema System)" '
		$6 ~ /\.debug$/ || /processing user request/ { next }
		{ hm = substr($4, 1, 5); r = $0; sub(/^([^ ]+ +){6}/, "", r); p = r; sub(/:.*/, "", p); sub(/\[[0-9]*\]$/, "", p); m = r; sub(/^[^:]*: */, "", m)
		  sub(/^<[a-z]+> */, "", m); if (m ~ /^\[modem[0-9]*\]/) { p = "ModemManager"; sub(/^\[[^]]*\] */, "", m) }
		  n = (p == "ModemManager") ? "Modem" : (p == "dropbear") ? "SSH" : (p ~ /^dnsmasq/) ? "DNS" : (p == "netifd") ? "Rete" :
		      (p == "hostapd") ? "Wi-Fi" : (p == "odhcpd") ? "DHCP" : (p == "kernel") ? "Kernel" : (p == "" || p == "procd") ? sy : p
		  l = hm " " n " · " m; if (l == u) next; u = l; L[++k] = l }
		END { for (i = (k > 15 ? k - 14 : 1); i <= k; i++) print "\t" L[i] "\t" }' | f29
;;
errori)
ubus call wrtfreedom logsum '{"see":true}' 2>/dev/null | J '
		print("@@H ⚙️ " + (EN ? "Errors and Warnings" : "Errori e Avvisi") + "\n" + (EN ? "Total: " : "Totale: ") + d.see + "\n");
		if (!d.see) exit(0);
		/* 6/11: il numero prima del nome del gruppo, nome e testi accorciati a 29 caratteri (f29) */
		for (let g in slice(d.groups, 0, 8)) {
			print("\n" + (g.lv == "warn" ? "⚠️ " : "❌ ") + g.see + " · \t" + g.name + "\t\n");
			for (let m in slice(g.msgs, 0, 2)) print("• \t" + replace(m.text, /\t/g, " ") + "\t" + (m.n > 1 ? " ×" + m.n : "") + "\n");
		}
	' | f29
;;
processi)
echo "@@H ⚙️ $(t Processi Processes)"
{ top -b -n 1 2>/dev/null || ps w 2>/dev/null; } | awk -v EN=$EN '
		function nm(c, a,  b) { b = c; sub(/^.*\//, "", b); gsub(/[][]/, "", b)
			if (b == "ucode" && a ~ /\.uc$/) { sub(/^.*\//, "", a); sub(/\.uc$/, "", a); return "WrtFreedom " a }
			if (b ~ /^dnsmasq/) return EN ? "Names and Addresses" : "Nomi e Indirizzi"; if (b == "hostapd") return "Wi-Fi"
			if (b == "wpa_supplicant") return EN ? "Wi-Fi Client" : "Wi-Fi Client"; if (b == "netifd") return EN ? "Network" : "Rete"
			if (b == "odhcpd") return "DHCP"; if (b == "uhttpd") return EN ? "Web Page" : "Pagina Web"; if (b == "rpcd") return EN ? "App Link" : "Collegamento App"
			if (b == "ModemManager" || b == "mmcli") return "Modem"; if (b == "AdGuardHome") return "AdGuard Home"; return b }
		/^CPU:/ { for (i = 2; i < NF; i++) if ($(i + 1) == "idle") id = $i; next }
		/^Mem:/ { u = $2; f = $4; next }
		$1 == "PID" { for (i = 1; i <= NF; i++) { if ($i == "%CPU") pc = i; if ($i == "COMMAND") cc = i }; s = 1; next }
		s && cc { a = (NF > cc) ? $(cc + 1) : ""; L[++k] = "• " nm($cc, a) (pc ? " · " $pc : "") }
		END { if (id != "") { sub(/%/, "", id); print (EN ? "Processor: " : "Processore: ") (100 - id) "%" }
			if (u != "") { sub(/K$/, "", u); sub(/K$/, "", f); printf "RAM: %d MB · %d MB %s\n", u / 1024, f / 1024, EN ? "free" : "liberi" }
			for (i = 1; i <= k && i <= 12; i++) print L[i]; if (k > 12) print (EN ? "And " : "E altri ") (k - 12) (EN ? " more" : "") }' | f29
;;
servizi)
ubus call wrtfreedom svc 2>/dev/null | J '
		let on = filter(d.list, (x) => x.on), off = filter(d.list, (x) => !x.on && x.boot);
		print("@@H ⚙️ " + (EN ? "Services" : "Servizi") + "\n");
		/* 6/11: un servizio per riga (f29), prima i fermi che dovrebbero essere accesi */
		if (length(off)) { print("❌ " + (EN ? "Stopped, should run" : "Fermi da accendere") + ": " + length(off) + "\n"); for (let x in off) print("• " + x.name + (x.name != x.id ? " · " + x.id : "") + "\n"); }
		print("✅ " + (EN ? "Running" : "Attivi") + ": " + length(on) + "\n");
		for (let x in on) print("• \t" + x.name + "\t\n");
	' | f29
;;
servizio)
n=$(echo "$A" | awk '{print $1}'); echo "$n" | grep -qE '^[A-Za-z0-9_.-]+$' && [ -x /etc/init.d/$n ] || { t "@@H ⚙️ Servizio ¦ Non trovato ¦ Nome esatto in /servizi" "@@H ⚙️ Service ¦ Not found ¦ Exact name in /services"; exit 0; }
o=$(ubus call wrtfreedom svc "{\"action\":\"restart\",\"name\":\"$n\"}" 2>&1)
case "$o" in *'"pend": true'*)
i=0; s=
while [ $i -lt 10 ]; do sleep 3; i=$((i+1))
s=$(ubus call wrtfreedom svc 2>/dev/null | J 'let n = "'"$n"'", x = filter(d.list, (y) => y.id == n)[0]; print(x?.on && d.what?.name == n ? "on" : "");')
[ "$s" = on ] && break; done
if [ "$s" = on ] && ubus call wrtfreedom svc '{"action":"confirm"}' 2>/dev/null | grep -q '"ok": true'; then echo "✅ $n $(t riavviato restarted)"
else echo "⚠️ $n $(t "non risponde" "not answering") ¦ $(t "È un servizio vitale" "It is a vital service") ¦ $(t "Torna com’era tra 2 minuti" "Goes back in 2 minutes")"; fi;;
*'"ok": true'*) if [ -n "$(svcst "$n")" ]; then esito 10 "$n $(t riavviato restarted)" 'echo "$n $(t "fermo dopo il riavvio" "stopped after the restart")"' svcon "$n"
else echo "✅ $n $(t riavviato restarted)"; fi;;
*'non trovato'*) t "@@H ⚙️ Servizio ¦ Non trovato ¦ Nome esatto in /servizi" "@@H ⚙️ Service ¦ Not found ¦ Exact name in /services";;
*'in attesa'*) t "@@H ⚠️ Servizio ¦ Altra modifica in attesa ¦ Riprova tra 2 minuti" "@@H ⚠️ Service ¦ Another change is waiting ¦ Try again in 2 minutes";;
*) t "@@H ⚠️ Servizio ¦ Non riavviato" "@@H ⚠️ Service ¦ Not restarted";; esac
;;
aggiornamenti)
if command -v apk >/dev/null 2>&1; then apk update >/dev/null 2>&1; L=$(apk list -u 2>/dev/null | awk '{print $1}')
else opkg update >/dev/null 2>&1; L=$(opkg list-upgradable 2>/dev/null | awk '{print $1 " " $3 " → " $5}'); fi
echo "@@H ⬆️ $(t Aggiornamenti Updates)"
if [ -n "$L" ]; then echo "$(t "Da aggiornare" "To update"): $(echo "$L" | wc -l)"; echo "$L" | sed 's/^/• /' | lmax 30
else t "✅ Pacchetti aggiornati" "✅ Packages up to date"; echo; fi
echo; sh $W/upd.sh status
;;
aggiorna_pacchetto)
( sh $W/upd.sh safe tg > /tmp/wf-upd.log 2>&1 ) >/dev/null 2>&1 </dev/null &
t "@@H ⬆️ Pacchetto Router ¦ Controllo e installo ¦ Ti scrivo quando ho finito" "@@H ⬆️ Router Package ¦ Checking and installing ¦ I'll write when done"
;;
backup)
h=$(uci -q get system.@system[0].hostname); f=/tmp/backup-${h:-router}-$(date +%Y%m%d).tar.gz
rm -f "$f" "${f%.tar.gz}.wfbak"
if [ -f /usr/share/wrtfreedom/backup.sh ]; then sh /usr/share/wrtfreedom/backup.sh create "$f" tg >/dev/null 2>&1; else sysupgrade -b "$f" >/dev/null 2>&1; fi
if [ -s "${f%.tar.gz}.wfbak" ]; then
echo "@@DOC ${f%.tar.gz}.wfbak"; echo "@@H 💾 Backup ¦ $(t "Copia cifrata pronta" "Encrypted copy ready")"; exit 0
fi
[ -s "$f" ] || { t "@@H ⚠️ Backup ¦ Non creato" "@@H ⚠️ Backup ¦ Not created"; exit 0; }
echo "@@DOC $f"; echo "@@H 💾 Backup ¦ $(t "Copia impostazioni pronta" "Settings copy ready") ¦ $(t "Password e chiavi leggibili" "Passwords and keys readable") ¦ $(t "Imposta la password nell'app" "Set a password in the app")"
;;
eventi)
o=$(tail -n 120 "$LOG" 2>/dev/null | awk -F'|' '$3 !~ /#so:/' | tail -n 15)
[ -n "$o" ] || { t "@@H ⚙️ Eventi ¦ Nessuno" "@@H ⚙️ Events ¦ None"; exit 0; }
echo "@@H ⚙️ $(t "Ultimi Eventi" "Latest Events")"
echo "$o" | awk -F'|' -v today="$(date +%d/%m)" '{cmd="date -d @" $1 " \"+%d/%m %H:%M\""; cmd | getline d; close(cmd); split(d, x, " "); if (x[1] == today) d = x[2]; i = index($4, " ¦ "); if (i) $4 = substr($4, 1, i - 1); print d " \t" $4 "\t"}' | f29
;;
usb)
o=$(for d in /sys/bus/usb/devices/*; do [ -f $d/idVendor ] || continue; [ -f $d/product ] || continue; echo "• $(cat $d/manufacturer 2>/dev/null) $(cat $d/product)"; done | grep -viE 'host controller|root hub')
echo "@@H 🔌 USB"; echo "${o:-$(t "Nessun dispositivo" "No device")}"
;;
cron)
o=$(wfget cron | J '
		let out = [], hm = (w) => { let m = match(w ?? "", /^([0-9]{1,2}) ([0-9]{1,2}) \* \* \*$/); return m ? (EN ? "every day at " : "ogni giorno alle ") + sprintf("%02d:%02d", +m[2], +m[1]) : (w ?? ""); };
		for (let l in d.lines ?? []) if (l.on) push(out, "• " + (l.meta?.n || l.cmd || "?") + " · " + hm(l.when));
		for (let x in d.nat ?? []) if (x.on !== false) push(out, "• " + (x.name ?? x.kind) + (x.when ? " · " + hm(x.when) : ""));
		for (let x in d.wf ?? []) if (x.name) push(out, "• " + x.name);
		for (let x in d.sys ?? []) if (length(x) && substr(x, 0, 1) != "#") push(out, "• " + x);
		if (length(out)) print(join("\n", out), "\n");')
[ -n "$o" ] || o=$(grep -v '^#' /etc/crontabs/root 2>/dev/null | grep .)
echo "@@H ⏰ $(t Pianificazioni Schedules)"; echo "${o:-$(t "Nessuna" "None")}" | f29	# 6/11: righe lunghe con l'orario sotto
r=
C=$(wfget certrenew); if [ -n "$(jv "$C" @.how)" ]; then h=$(nhm "$(jv "$C" @.when)"); r="$r• $(t "Rinnovo Dei Certificati: ogni notte" "Certificate Renewal: every night")${h:+ $(t alle at) $h}
"; fi
[ "$(jv "$(wfget vpnwd)" @.how)" = loop ] && r="$r• $(t "Controllo Del Server VPN: ogni 30 s" "VPN Server Check: every 30 s")
"
[ "$(jv "$(wfget ddnswd)" @.how)" = svc ] && r="$r• $(t "Controllo Del DDNS: quando cambia l'IP" "DDNS Check: when the IP changes")
"
f=$(wfget fastwd | J '
		let N = { wifi: [ "Wi-Fi", "Wi-Fi" ], firewall: [ "Firewall", "Firewall" ], bot: [ "Bot Telegram", "Telegram Bot" ], cron: [ "Pianificazioni", "Schedules" ], memoria: [ "Memoria", "Memory" ] };
		for (let k, x in d) if (N[k] && type(x) == "object" && x.on) print("• ", EN ? N[k][1] + ": every " : N[k][0] + ": ogni ", x.sec, " s\n");')
[ -n "$f" ] && r="$r$f
"
r=$(printf '%s' "$r" | f29)
[ -n "$r" ] && { echo; echo "$(t "Fatte dal router:" "Done by the router:")"; printf '%s
' "$r"; }
;;
certificati)
wfget certrenew | J '
		let C = filter(d.certs ?? [], (c) => type(c) == "object" && c.on), w = match(d.when ?? "", /^([0-9]{1,2}) ([0-9]{1,2}) \* \* \*$/);
		print("@@H 📜 ", EN ? "Certificates" : "Certificati", "\n");
		if (!length(C)) { print(EN ? "None turned on\n" : "Nessuno acceso\n"); exit(0); }
		for (let c in C) {
			let n = c.na ? int((+c.na - time()) / 86400) : null;
			print(c.dom, c.test ? (EN ? " (test)" : " (di prova)") : "", "\n", n == null ? (EN ? "Not issued yet" : "Non ancora emesso") : n < 0 ? (EN ? "Expired" : "Scaduto") : (EN ? "Expires in " + n + " days" : "Scade tra " + n + " giorni"), "\n");
		}
		print(d.how ? (EN ? "Renewal: every night" : "Rinnovo: ogni notte") + (w ? sprintf(EN ? " %02d:%02d" : " %02d:%02d", +w[2], +w[1]) : "") : (EN ? "⚠️ Renewal stopped" : "⚠️ Rinnovo fermo"), "\n");
		if (d.last) { let l = localtime(+d.last.t); print(EN ? "Last renewal: " : "Ultimo rinnovo: ", sprintf("%02d/%02d", l.mday, l.mon), "\n", EN ? "Result: " : "Esito: ", d.last.rc == 0 ? (EN ? "done" : "riuscito") : (EN ? "failed" : "non riuscito"), "\n"); }'
;;
libera_ram)
b=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo); sync; { echo 3 > /proc/sys/vm/drop_caches; } 2>/dev/null
a=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)
echo "@@H 🩺 $(t Memoria Memory)"; echo "$(t Prima Before): $b MB $(t liberi free)"; echo "$(t Dopo After): $a MB $(t liberi free)"
;;
sincronizza_ora)
S=$(uci -q get system.ntp.server | awk '{print $1}')
if ntpd -q -n -p ${S:-pool.ntp.org} >/dev/null 2>&1; then echo "✅ $(t "Ora rimessa" "Time synced") ¦ $(date '+%d/%m/%Y %H:%M:%S')"
else nr "$(t "Server dell'ora muto" "Time server not answering") ¦ $(date '+%d/%m/%Y %H:%M:%S')"; fi
;;
espelli|rimuovi)
nas_ok || { t "@@H 🗄️ Disco ¦ NAS spento ¦ Accendilo dall'app" "@@H 🗄️ Disk ¦ NAS is off ¦ Turn it on in the app"; exit 0; }
C=$(ubus call wrtfreedom nas_state 2>/dev/null | J 'for (let k in d.disks ?? []) if (k.usb) print((k.id ?? "") + "\t" + (k.name ?? k.id) + "\n");')
[ -n "$C" ] || { t "@@H 🗄️ Disco ¦ Nessun disco da espellere" "@@H 🗄️ Disk ¦ No disk to eject"; exit 0; }
P=$(printf '%s\n' "$C" | nas_pick "$A")
[ -n "$P" ] || { echo "@@H 🗄️ $(t "Quale Disco" "Which Disk")"; printf '%s\n' "$C" | awk -F'\t' '{print "• " $2}' | lmax 8; t "Scrivi /espelli <nome>" "Type /eject <name>"; exit 0; }
id=${P%%	*}; nm=${P#*	}
nas_id "$id" || { t "@@H ⚠️ Disco ¦ Non espulso" "@@H ⚠️ Disk ¦ Not ejected"; exit 0; }
o=$(ubus call wrtfreedom nas_disk "{\"act\":\"eject\",\"id\":\"$id\",\"bg\":true}" 2>&1)
case "$o" in
*'"ok": true'*|*'"ok":true'*)
t0=$(( $(date +%s) - 1 )); r=; i=0; n=${WF_TGEJ:-30}
while [ $i -lt "$n" ]; do
sleep 1; i=$((i + 1))
r=$(ubus call wrtfreedom nas_state 2>/dev/null | ID=$id T0=$t0 J 'if (d.error || type(d.disks) != "array") exit(0);
					let k = filter(d.disks, (x) => "" + x.id == getenv("ID"))[0], e = k?.eject_last;
					if (!k) print("ok");
					else if (type(e) == "object" && +(e.t ?? 0) >= +getenv("T0") && (e.res == "ok" || e.res == "busy")) print(e.res == "ok" ? "ok" : "busy:" + join(", ", (EN ? e.users_en : e.users) ?? []));')
[ -n "$r" ] && break
done
case "$r" in
ok) echo "@@H 🗄️ $nm"; t "Puoi staccarlo" "Safe to unplug" ;;
busy:*) u=${r#busy:}; echo "@@H ⚠️ $nm"; t "Non espulso ¦ Non staccarlo" "Not ejected ¦ Do not unplug it"; echo
if [ -n "$u" ]; then t "Lo usa: $u" "Used by: $u"; else t "Il disco è ancora in uso" "The drive is still in use"; fi; echo ;;
*) echo "@@H ⚠️ $nm"; t "Espelli non ha finito ¦ Non staccarlo" "Eject did not finish ¦ Do not unplug it"; echo; t "Guarda nell'app" "Check the app"; echo ;;
esac ;;
*) e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ $nm"; t "Non espulso" "Not ejected"; echo; [ -n "$e" ] && printf '%s\n' "$e" | fsplit ;;
esac
;;
scarica)
nas_ok || { t "@@H 🗄️ Download ¦ NAS spento ¦ Accendilo dall'app" "@@H 🗄️ Download ¦ NAS is off ¦ Turn it on in the app"; exit 0; }
if [ -z "$A" ] || [ ${#A} -gt 2000 ] || ! printf '%s' "$A" | grep -qE '^(https?://|magnet:[?])[^ "\\]+$'; then
t "@@H ⚠️ Download ¦ Link non valido ¦ Scrivi /scarica <link>" "@@H ⚠️ Download ¦ Invalid link ¦ Type /download <link>"; exit 0
fi
o=$(ubus call wrtfreedom nas_dl "{\"act\":\"add\",\"url\":\"$A\",\"via\":\"bot\"$ASJ}" 2>&1)
case "$o" in
*'"error"'*) e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ Download"; t "Non avviato" "Not started"; echo; [ -n "$e" ] && printf '%s\n' "$e" | fsplit ;;
*) echo "@@H 🗄️ Download"; t "In coda" "Queued"; echo; t "Ti avviso alla fine" "I will tell you when it ends" ;;
esac
;;
backup_nas)
nas_ok || { t "@@H 🗄️ Backup ¦ NAS spento ¦ Accendilo dall'app" "@@H 🗄️ Backup ¦ NAS is off ¦ Turn it on in the app"; exit 0; }
C=$(bk_list)
[ -n "$C" ] || { t "@@H 🗄️ Backup ¦ Nessun backup ¦ Creane uno dall'app" "@@H 🗄️ Backup ¦ No backup ¦ Create one in the app"; exit 0; }
P=$(printf '%s\n' "$C" | nas_pick "$A")
[ -n "$P" ] || { bk_show "$C"; exit 0; }
id=${P%%	*}; nm=${P#*	}; k=${nm##*	}; nm=${nm%%	*}
nas_id "$id" || { t "@@H ⚠️ Backup ¦ Non avviato" "@@H ⚠️ Backup ¦ Not started"; exit 0; }
if [ "$k" = c ]; then o=$(ubus call wrtfreedom nas_cloud "{\"act\":\"run\",\"id\":\"$id\"}" 2>&1)
else o=$(ubus call wrtfreedom nas_backup "{\"act\":\"run\",\"id\":\"$id\"}" 2>&1); fi
case "$o" in
*'"job"'*) echo "@@H 🗄️ $nm"; if [ "$k" = c ]; then t "Backup Cloud avviato" "Cloud backup started"; else t "Backup avviato" "Backup started"; fi; echo; t "Ti avviso alla fine" "I will tell you when it ends" ;;
*) e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ $nm"; t "Non avviato" "Not started"; echo; [ -n "$e" ] && printf '%s\n' "$e" | fsplit ;;
esac
;;
cloud)
case "$(printf '%s' "$A" | tr 'A-Z' 'a-z')" in
pausa|pause) echo "@@BTN pausa_ok=$(t "✅ Sì" "✅ Yes")|no=✖️ No"; t "@@H 🗄️ Pausa Cloud ¦ Fino a Riprendi ¦ Confermi?" "@@H 🗄️ Cloud Pause ¦ Until Resume ¦ Confirm?"; exit 0 ;;
riprendi|resume) echo "@@BTN riprendi_ok=$(t "✅ Sì" "✅ Yes")|no=✖️ No"; t "@@H 🗄️ Riprendi Cloud ¦ Confermi?" "@@H 🗄️ Resume Cloud ¦ Confirm?"; exit 0 ;;
pausa_ok) cl_pause 0; exit 0 ;;
riprendi_ok) cl_pause resume; exit 0 ;;
no) t "@@H 🗄️ Cloud ¦ Annullato" "@@H 🗄️ Cloud ¦ Cancelled"; exit 0 ;;
backup)
C=$(bk_list)
[ -n "$C" ] || { t "@@H 🗄️ Backup ¦ Nessun backup ¦ Creane uno dall'app" "@@H 🗄️ Backup ¦ No backup ¦ Create one in the app"; exit 0; }
bk_show "$C"; exit 0 ;;
esac
S=$(ubus call wrtfreedom cloud_state 2>/dev/null)
[ "$(printf '%s' "$S" | J 'print(type(d.sum) == "object" ? 1 : 0);')" = 1 ] || { t "@@H ⚠️ Cloud ¦ Non letto ¦ Riprova tra poco" "@@H ⚠️ Cloud ¦ Not read ¦ Try again shortly"; exit 0; }
case "$(printf '%s' "$S" | J 'print(d.sum.k ?? "");')" in
none) t "@@H 🗄️ Cloud ¦ Da installare ¦ Installalo dall'app" "@@H 🗄️ Cloud ¦ To install ¦ Install it in the app"; exit 0 ;;
setup) t "@@H 🗄️ Cloud ¦ Nessun account ¦ Collegalo dall'app" "@@H 🗄️ Cloud ¦ No account ¦ Connect it in the app"; exit 0 ;;
esac
G=$(ubus call wrtfreedom cloud '{"act":"get"}' 2>/dev/null); N=$(ubus call wrtfreedom nas_cloud '{"act":"get"}' 2>/dev/null)
printf '{"s":%s,"g":%s,"n":%s}' "$S" "${G:-null}" "${N:-null}" | J 'let s = d.s, x = s.sum, p = s.pause ?? {}, sm = s.sim ?? {}, us = 0, tt = 0, lb = 0;
		let fm = (b) => { let u = [ "KB", "MB", "GB", "TB" ], v = b / 1024.0, i = 0; while (v >= 1024 && i < 3) { v /= 1024.0; i++; }
			let r = v >= 10 || i == 0 ? sprintf("%d %s", int(v + 0.5), u[i]) : replace(sprintf("%.1f %s", v, u[i]), ".0 ", " "); return EN ? r : replace(r, ".", ","); };
		let gb = (v) => { let r = replace(sprintf("%.1f", +v), /\.0$/, ""); return EN ? r : replace(r, ".", ","); };
		let adm = (o) => (type(o) == "string" ? o : "admin") == "admin";
		for (let a in (type(d.g?.accounts) == "array" ? d.g.accounts : [])) if (+(a.total ?? 0) > 0 && adm(a.user)) { us += +(a.used ?? 0); tt += +a.total; }
		for (let c in (type(d.n?.list) == "array" ? d.n.list : [])) if (c.kind == "backup" && adm(c.own) && c.last_ok !== false && +(c.last ?? 0) > lb) lb = +c.last;
		print("@@BTN ", p.on ? "riprendi=" + (EN ? "Resume Cloud" : "Riprendi Cloud") : "pausa=" + (EN ? "Pause Cloud" : "Pausa Cloud"), "|backup=", EN ? "NAS Backup" : "Backup NAS", "\n");
		print("@@H ", x.k == "ok" || x.k == "run" || x.k == "pause" ? "🗄️" : "⚠️", " Cloud\n");
		print(EN ? "Status: " : "Stato: ", lc(EN ? (x.t_en ?? x.t) : x.t), "\n");
		if (length(x.why ?? "")) print(EN ? "Reason: " : "Motivo: ", EN ? (x.why_en ?? x.why) : x.why, "\n");
		if (x.k == "run" && type(x.live) == "object" && length(x.live.t ?? "")) print(EN ? "Now: " : "Adesso: ", x.live.t, " · ", int(+(x.live.pct ?? 0)), "%\n");
		if (tt > 0) print(EN ? "Space: " : "Spazio: ", fm(us), EN ? " of " : " di ", fm(tt), "\n");
		if (lb > 0) { let l = localtime(lb), n = localtime(time());
			print(EN ? "Last backup: " : "Ultimo backup: ", l.mday == n.mday && l.mon == n.mon ? "" : sprintf("%02d/%02d ", l.mday, l.mon), sprintf("%02d:%02d", l.hour, l.min), "\n"); }
		if (sm.on || +(sm.gb_today ?? 0) > 0) print(EN ? "SIM today: " : "SIM oggi: ", gb(sm.gb_today ?? 0), " GB", sm.gb_cap != null ? (EN ? " of " : " di ") + gb(sm.gb_cap) + " GB" : "", "\n");
		print(EN ? "Queued: " : "In coda: ", int(+(s.queue ?? 0)), "\n");' | fsplit
;;
cloud_pausa)
a=$(printf '%s' "$A" | tr 'A-Z' 'a-z' | sed -E 's/ *(ore|ora|h|hours|hour)$//')
case "$a" in
riprendi|resume) cl_pause resume ;;
'') cl_pause 0 ;;
*[!0-9]*) t "@@H ⚠️ Pausa Cloud ¦ Ore non valide ¦ Scrivi /cloud_pausa 2" "@@H ⚠️ Cloud Pause ¦ Invalid hours ¦ Type /cloud_pause 2" ;;
*) a=$(printf '%s' "$a" | sed 's/^0*//')
if [ -n "$a" ] && [ "${#a}" -le 3 ] && [ "$a" -le 720 ]; then cl_pause "$a"
else t "@@H ⚠️ Pausa Cloud ¦ Da 1 a 720 ore" "@@H ⚠️ Cloud Pause ¦ From 1 to 720 hours"; fi ;;
esac
;;
cloud_riprendi)
cl_pause resume
;;
scansiona)
S=$(t "Server Multimediale" "Media Server")
nas_ok || { t "@@H 🗄️ $S ¦ NAS spento ¦ Accendilo dall'app" "@@H 🗄️ $S ¦ NAS is off ¦ Turn it on in the app"; exit 0; }
o=$(ubus call wrtfreedom nas_media '{"act":"scan"}' 2>&1)
case "$o" in
*'"error"'*) e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ $S"; t "Non avviata" "Not started"; echo; [ -n "$e" ] && printf '%s\n' "$e" | fsplit ;;
*'"on"'*) echo "@@H 🗄️ $S"; t "Cerco i file nuovi" "Looking for new files"; echo; t "Le TV si fermano per qualche secondo" "TVs pause for a few seconds"; echo ;;
*) t "@@H ⚠️ $S ¦ Il router non ha risposto ¦ Riprova" "@@H ⚠️ $S ¦ The router did not answer ¦ Try again" ;;
esac
;;
tv)
S=$(t "Server Multimediale" "Media Server")
nas_ok || { t "@@H 🗄️ $S ¦ NAS spento ¦ Accendilo dall'app" "@@H 🗄️ $S ¦ NAS is off ¦ Turn it on in the app"; exit 0; }
M=$(ubus call wrtfreedom nas_media '{"act":"get"}' 2>/dev/null)
[ -n "$M" ] || { t "@@H ⚠️ $S ¦ Non letto ¦ Riprova tra poco" "@@H ⚠️ $S ¦ Not read ¦ Try again shortly"; exit 0; }
printf '%s' "$M" | J 'exit(d.on === true ? 0 : 1);' || { t "@@H 🗄️ $S ¦ Spento ¦ Accendilo dall'app" "@@H 🗄️ $S ¦ Off ¦ Turn it on in the app"; exit 0; }
TV=$(ubus call wrtfreedom nas_tv '{"act":"list"}' 2>/dev/null)
cur() { printf '%s' "$TV" | J 'let L = filter(d.tvs ?? [], (x) => x.state == "play" || x.state == "pause"); L = [ ...filter(L, (x) => x.state == "play"), ...filter(L, (x) => x.state != "play") ];
		let x = L[0]; if (x && match(x.mac ?? "", /^[0-9a-f:]{17}$/)) print(join("\t", [ x.mac, x.name || x.mac, x.state, +(x.pos ?? 0), +(x.dur ?? 0), replace("" + (x.file ?? ""), /[\t\n]/g, " ") ]), "\n");'; }
hms() { awk -v s="$1" 'BEGIN { s = int(s); printf "%d:%02d", int(s / 3600), int((s % 3600) / 60) }'; }
C=$(cur); m=$(printf '%s' "$C" | cut -f1); n=$(printf '%s' "$C" | cut -f2); st=$(printf '%s' "$C" | cut -f3)
v=$(printf '%s' "$A" | tr 'A-Z' 'a-z')
case "$v" in
pausa|pause|riprendi|resume)
case "$v" in pausa|pause) w=pause; need=play ;; *) w=resume; need=pause ;; esac
[ -n "$m" ] && [ "$st" = "$need" ] || { t "@@H 🗄️ $S ¦ Nessuna TV da comandare" "@@H 🗄️ $S ¦ No TV to control"; exit 0; }
o=$(ubus call wrtfreedom nas_tv "{\"act\":\"$w\",\"mac\":\"$m\"}" 2>&1)
case "$o" in
*'"ok": true'*|*'"ok":true'*) if [ $w = pause ]; then echo "@@H 🗄️ $n"; t "In pausa a $(hms "$(printf '%s' "$C" | cut -f4)")" "Paused at $(hms "$(printf '%s' "$C" | cut -f4)")"; echo
else echo "@@H 🗄️ $n"; t "Ripreso" "Resumed"; echo; fi ;;
*) e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ $n"; t "Non riuscito" "Failed"; echo; [ -n "$e" ] && printf '%s\n' "$e" | fsplit ;;
esac
exit 0 ;;
film)
P=$(printf '%s' "$TV" | J 'let L = filter(d.tvs ?? [], (x) => x.recv && x.state != "off" && match(x.mac ?? "", /^[0-9a-f:]{17}$/)); if (length(L) == 1) print(L[0].mac, "\t", L[0].name || L[0].mac, "\n");')
[ -n "$P" ] || { t "@@H 🗄️ $S ¦ Accendi una TV ¦ Poi scrivi /tv" "@@H 🗄️ $S ¦ Turn on a TV ¦ Then type /tv"; exit 0; }
R=$(ubus call wrtfreedom nas_resume '{"act":"get"}' 2>/dev/null | J 'let x = (d.list ?? [])[0]; if (x) print(sprintf("%J", { disk: "" + x.disk, path: "" + x.path, pos: int(+(x.pos ?? 0)) }), "\t", replace("" + (x.name ?? ""), /[\t\n]/g, " "), "\t", int(+(x.pos ?? 0)), "\n");')
[ -n "$R" ] || { t "@@H 🗄️ $S ¦ Nessun film da finire" "@@H 🗄️ $S ¦ No film to finish"; exit 0; }
m=${P%%	*}; n=${P#*	}; a=$(printf '%s' "$R" | cut -f1); f=$(printf '%s' "$R" | cut -f2)
a=$(printf '%s' "$a" | J "print(sprintf('%J', { ...d, act: 'play', mac: '$m' }))")
o=$(ubus call wrtfreedom nas_tv "$a" 2>&1)
case "$o" in
*'"ok": true'*|*'"ok":true'*) echo "@@H 🗄️ $n"; t "Riprendo $f" "Resuming $f"; echo; t "Da $(hms "$(printf '%s' "$R" | cut -f3)")" "From $(hms "$(printf '%s' "$R" | cut -f3)")"; echo ;;
*) e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ $n"; t "Non riuscito" "Failed"; echo; [ -n "$e" ] && printf '%s\n' "$e" | fsplit ;;
esac
exit 0 ;;
esac
b=; [ "$st" = play ] && b="pausa=$(t Pausa Pause)"; [ "$st" = pause ] && b="riprendi=$(t Riprendi Resume)"
f=$(printf '%s' "$TV" | J 'print(length(filter(d.tvs ?? [], (x) => x.recv && x.state != "off")) == 1 ? 1 : 0)')
r=$(printf '%s' "$M" | J 'print(+(d.resume_n ?? 0))')
[ -z "$st" ] && [ "$f" = 1 ] && [ "${r:-0}" -gt 0 ] && b="${b:+$b|}film=$(t "Riprendi Un Film" "Resume A Film")"
[ -n "$b" ] && echo "@@BTN $b"
echo "@@H 🗄️ $S"
printf '%s' "$M" | J 'print((EN ? "State: on" : "Stato: attivo") + (d.scan ? (EN ? " · scanning" : " · scansione in corso") : "") + "\n");'
if [ -n "$m" ]; then
echo "$(t Adesso Now): $n"
p=$(printf '%s' "$C" | cut -f4); u=$(printf '%s' "$C" | cut -f5); ti=$(printf '%s' "$C" | cut -f6); ti=${ti##*/}
[ -n "$ti" ] && echo "$(t Guarda Playing): $ti ($(hms "$p") $(t di of) $(hms "$u"))$( [ "$st" = pause ] && printf ' · %s' "$(t "in pausa" paused)")"
else
printf '%s' "$M" | J 'let p = (d.playing ?? [])[0]; if (p) print((EN ? "Now: " : "Adesso: ") + (p.name || (EN ? "a TV" : "una TV")) + "\n" + (EN ? "Playing: " : "Guarda: ") + replace("" + (p.file ?? ""), /^.*\//, "") + "\n");
			else print(EN ? "Now: no TV\n" : "Adesso: nessuna TV\n");'
fi
printf '%s' "$M" | J 'let n = (v) => { let s = "" + int(+(v ?? 0)), o = ""; while (length(s) > 3) { o = (EN ? "," : ".") + substr(s, -3) + o; s = substr(s, 0, -3); } return s + o; };
		if (+(d.resume_n ?? 0) > 0) print((EN ? "To finish: " : "Da finire: ") + d.resume_n + (EN ? " films" : " film") + "\n");
		print((EN ? "Files: " : "File: ") + n(d.files?.video) + (EN ? " films, " : " film, ") + n(d.files?.music) + (EN ? " songs, " : " brani, ") + n(d.files?.photo) + (EN ? " photos" : " foto") + "\n");'
;;
nas)
nas_ok || { t "@@H 🗄️ NAS ¦ Spento ¦ Accendilo dall'app" "@@H 🗄️ NAS ¦ Off ¦ Turn it on in the app"; exit 0; }
case "$(printf '%s' "$A" | tr 'A-Z' 'a-z')" in
pausa|pause) nas_dlall pauseall; exit 0 ;;
riprendi|resume) nas_dlall resumeall; exit 0 ;;
esac
S=$(ubus call wrtfreedom nas_state 2>/dev/null)
printf '%s' "$S" | J 'exit(type(d.disks) == "array" ? 0 : 1);' || { t "@@H ⚠️ NAS ¦ Non letto ¦ Riprova tra poco" "@@H ⚠️ NAS ¦ Not read ¦ Try again shortly"; exit 0; }
printf '%s' "$S" | J 'exit(d.health == "none" || !length(d.disks) ? 0 : 1);' && { t "@@H 🗄️ NAS ¦ Nessun disco ¦ Collega un disco USB" "@@H 🗄️ NAS ¦ No drive ¦ Plug in a USB drive"; exit 0; }
printf '%s' "$S" | J 'let x = d.dl ?? {}; if (+(x.run ?? 0) > 0) print("@@BTN pausa=", EN ? "Pause Downloads" : "Pausa Download", "\n"); else if (x.paused) print("@@BTN riprendi=", EN ? "Resume Downloads" : "Riprendi Download", "\n");'
printf '%s' "$S" | J 'let ok = d.health == "ok", lf = (s) => lc(substr("" + s, 0, 1)) + substr("" + s, 1), w = d.now ?? {}, x = d.dl ?? {}, fr = 0, sz = 0;
		let fm = (b) => { let u = [ "KB", "MB", "GB", "TB" ], v = b / 1024.0, i = 0; while (v >= 1024 && i < 3) { v /= 1024.0; i++; }
			let s = v >= 10 || i == 0 ? sprintf("%d %s", int(v + 0.5), u[i]) : replace(sprintf("%.1f %s", v, u[i]), ".0 ", " "); return EN ? s : replace(s, ".", ","); };
		for (let k in d.disks) if (k.mounted && +(k.size ?? 0) > 0) { fr += +(k.free ?? 0); sz += +k.size; }
		print("@@H ", ok ? "🗄️" : "⚠️", " NAS\n");
		print(EN ? "Status: " : "Stato: ", ok ? (EN ? "ready" : "pronto") : (EN ? "needs checking" : "da controllare"), "\n");
		if (!ok && d.rlabel) print(EN ? "Reason: " : "Motivo: ", lf(EN ? (d.rlabel.en ?? d.rlabel.it) : d.rlabel.it), "\n");
		if (w.kind != "pb" && length(w.t ?? "")) print(EN ? "Now: " : "Adesso: ", lf(w.t), "\n");
		if (sz > 0) print(EN ? "Free: " : "Libero: ", fm(fr), EN ? " of " : " di ", fm(sz), "\n");
		print(EN ? "Connected users: " : "Utenti connessi: ", int(+(d.clients ?? 0)), "\n");
		print("Download: ", +(x.run ?? 0) > 0 ? int(+x.run) + (EN ? " running" : " in corso") : x.paused ? (EN ? "paused" : "in pausa") : (EN ? "none" : "nessuno"), "\n");
		if (d.svc_n) print(EN ? "Services: " : "Servizi: ", int(+(d.svc_n.on ?? 0)), EN ? " on of " : " accesi su ", int(+(d.svc_n.of ?? 0)), "\n");' | fsplit
;;
pausa_download)
nas_ok || { t "@@H 🗄️ Download ¦ NAS spento ¦ Accendilo dall'app" "@@H 🗄️ Download ¦ NAS is off ¦ Turn it on in the app"; exit 0; }
case "$(printf '%s' "$A" | tr 'A-Z' 'a-z')" in riprendi|resume) nas_dlall resumeall ;; *) nas_dlall pauseall ;; esac
;;
cerca_file)
S=$(t "Cerca" "Search")
nas_ok || { t "@@H 🗄️ $S ¦ NAS spento ¦ Accendilo dall'app" "@@H 🗄️ $S ¦ NAS is off ¦ Turn it on in the app"; exit 0; }
TF=/tmp/wf-tgf; mkdir -p "$TF" && chmod 700 "$TF"
FF=$TF/find-$(printf '%s' "${WF_CHAT:-0}" | tr -cd '0-9-' | cut -c1-24).json
DS=$(ubus call wrtfreedom nas_state 2>/dev/null)
printf '%s' "$DS" | J 'exit(type(d.disks) == "array" ? 0 : 1);' || { t "@@H ⚠️ $S ¦ Non letto ¦ Riprova tra poco" "@@H ⚠️ $S ¦ Not read ¦ Try again shortly"; exit 0; }
export WD="$DS" WFF="$FF"
v=$(printf '%s' "$A" | tr 'A-Z' 'a-z'); Q=$A; WW=0
if printf '%s' "$v" | grep -qE '^(x[1-8]|w|c)_[0-9a-f]{8}$'; then
export WK="${v#*_}"
ST=$(J 'if (d.id == getenv("WK") && time() - +(d.t ?? 0) < 86400) print(sprintf("%J", d), "\n");' 2>/dev/null < "$FF")
[ -n "$ST" ] || { t "@@H 🗄️ $S ¦ Ricerca scaduta ¦ Scrivi di nuovo /cerca_file" "@@H 🗄️ $S ¦ Search expired ¦ Type /find_file again"; exit 0; }
case "$v" in
w_*) Q=$(printf '%s' "$ST" | J 'print(d.q ?? "")'); WW=1 ;;
c_*)
tk=$(printf '%s' "$ST" | J 'if (match(d.link ?? "", /^[A-Za-z0-9_-]+$/)) print(d.link);')
[ -n "$tk" ] || { t "@@H 🗄️ Link ¦ Già chiuso" "@@H 🗄️ Link ¦ Already closed"; exit 0; }
o=$(ubus call wrtfreedom nas_link "{\"act\":\"del\",\"tok\":\"$tk\"$ASJ}" 2>&1)
case "$o" in
*'"error"'*) e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ Link"; t "Non chiuso" "Not closed"; echo; [ -n "$e" ] && printf '%s\n' "$e" | fsplit ;;
*'{'*) printf '%s' "$ST" | J 'delete d.link; let f = getenv("WFF"), fs = require("fs"); fs.writefile(f + ".t", sprintf("%J", d)); fs.rename(f + ".t", f);'
t "@@H 🗄️ Link ¦ Chiuso ¦ Non si apre più" "@@H 🗄️ Link ¦ Closed ¦ It no longer opens" ;;
*) t "@@H ⚠️ Link ¦ Il router non ha risposto ¦ Riprova" "@@H ⚠️ Link ¦ The router did not answer ¦ Try again" ;;
esac
exit 0 ;;
x*)
export WI="${v%%_*}"; WI=${WI#x}
P=$(printf '%s' "$ST" | WO=${ASJ:+$OWN} J 'let x = (d.items ?? [])[+getenv("WI") - 1], D = null, wo = length(getenv("WO") ?? "") > 0;
				try { for (let k in json(getenv("WD") || "{}")?.disks ?? []) if (x && k.id == x.disk && k.mounted && match(k.mnt ?? "", /^\/[^\t\n]+$/) && (!wo || k.main === true)) D = k; } catch (e) {}
				if (!x || !D || !match(x.path ?? "", /^\/[^\t\n]+$/) || match(x.path, /(^|\/)\.\.(\/|$)/)) exit(0);
				let p = split(x.path, "/"), n = length(x.name ?? "") ? x.name : p[length(p) - 1];
				print(join("\t", [ D.mnt, x.path, replace(n, /[\t\n]/g, " "), D.name ?? D.id, length(p) > 2 ? p[length(p) - 2] : "" ]), "\n");')
[ -n "$P" ] || { t "@@H 🗄️ $S ¦ Disco non collegato ¦ Cerca di nuovo" "@@H 🗄️ $S ¦ Drive not connected ¦ Search again"; exit 0; }
mn=$(printf '%s' "$P" | cut -f1); pa=$(printf '%s' "$P" | cut -f2); nm=$(printf '%s' "$P" | cut -f3); dn=$(printf '%s' "$P" | cut -f4); dd=$(printf '%s' "$P" | cut -f5)
f=$mn$pa
[ -f "$f" ] || { echo "@@H 🗄️ $nm"; t "File non trovato" "File not found"; echo; t "Forse è stato spostato" "It may have been moved"; echo; exit 0; }
if [ -n "$ASJ" ]; then
ur=$(wf_udir "$OWN" root); sr=$(wf_udir shared root); mr=$(readlink -f "$mn" 2>/dev/null); rp=$(readlink -f "$f" 2>/dev/null)
case "$rp" in
"$mr/$ur/"*|"$mr/$sr/"*) [ -n "$ur" ] && [ -n "$sr" ] && [ -n "$mr" ] && f=$rp || { t "@@H ⚠️ $S ¦ Cartella di un'altra persona" "@@H ⚠️ $S ¦ Another person's folder"; exit 0; } ;;
*) t "@@H ⚠️ $S ¦ Cartella di un'altra persona" "@@H ⚠️ $S ¦ Another person's folder"; exit 0 ;;
esac
else
mr=$(readlink -f "$mn" 2>/dev/null); rp=$(readlink -f "$f" 2>/dev/null)
case "$rp" in "$mr"/?*) [ -n "$mr" ] || rp= ;; *) rp= ;; esac
WR=${rp#"$mr"} ucode -e 'let U = null; try { U = loadfile(getenv("WF_UCFGUC") ?? "/usr/share/wrtfreedom/ucfg.uc")(); } catch (e) { U = null; }
					exit(length(getenv("WR") ?? "") && type(U?.upriv) == "function" && U.upriv(null, getenv("WR")) == null ? 0 : 1);' 2>/dev/null ||
{ t "@@H ⚠️ $S ¦ Cartella di una persona" "@@H ⚠️ $S ¦ A person's folder"; exit 0; }
f=$rp
fi
b=$(ls -lnL "$f" 2>/dev/null | awk '{print $5}'); case "$b" in ''|*[!0-9]*) b=0 ;; esac
wh=$dn; [ -n "$dd" ] && wh="$dn › $dd"
if [ "$b" -le 50000000 ]; then
L_=$TF/$(tr -dc 0-9a-f < /proc/sys/kernel/random/uuid | cut -c1-12); mkdir -p "$L_"
sn=$(printf '%s' "$nm" | tr -d '\000-\037' | tr ';,"\\/' '_____'); [ -n "$sn" ] || sn='file'
ln -s "$f" "$L_/$sn" || { t "@@H ⚠️ $S ¦ File non inviato ¦ Riprova" "@@H ⚠️ $S ¦ File not sent ¦ Try again"; exit 0; }
echo "@@DOC $L_/$sn"; echo "@@H 🗄️ $nm"; echo "$(nas_sz "$b") · $wh"
exit 0
fi
LJ=$(printf '%s' "$ST" | WO=${ASJ:+$OWN} J 'let x = d.items[+getenv("WI") - 1], o = { act: "add", disk: x.disk, path: x.path, hours: 24, where: "home" };
				if (length(getenv("WO") ?? "")) o.as = getenv("WO"); print(sprintf("%J", o));')
o=$(ubus call wrtfreedom nas_link "$LJ" 2>&1)
u=$(printf '%s' "$o" | J 'let u = "" + (d.link?.url ?? ""); if (match(u, /^https?:\/\/[^ \t\n]+$/)) print(u);')
tk=$(printf '%s' "$o" | J 'let k = "" + (d.link?.tok ?? ""); if (match(k, /^[A-Za-z0-9_-]+$/)) print(k);')
if [ -z "$u" ]; then
e=$(printf '%s' "$o" | J 'print(EN ? (d.error_en ?? d.error ?? "") : (d.error ?? ""))'); echo "@@H ⚠️ $nm"; t "Troppo grande per Telegram" "Too big for Telegram"; echo
if [ -n "$e" ]; then printf '%s\n' "$e" | fsplit; else t "Link non creato: aprilo dall'app" "Link not created: open it in the app"; echo; fi
exit 0
fi
[ -n "$tk" ] && printf '%s' "$ST" | WT="$tk" J 'd.link = getenv("WT"); let f = getenv("WFF"), fs = require("fs"); fs.writefile(f + ".t", sprintf("%J", d)); fs.rename(f + ".t", f);'
[ -n "$tk" ] && echo "@@BTN c_$WK=$(t "Chiudi Il Link" "Close The Link")"
echo "@@H 🗄️ $nm"; t "Troppo grande per Telegram" "Too big for Telegram"; echo
echo "$(nas_sz "$b") · $wh"; t "Link di 1 giorno, in casa e con la VPN:" "1-day link, at home and with the VPN:"; echo; echo "$u"
exit 0 ;;
esac
fi
[ ${#Q} -ge 2 ] && [ ${#Q} -le 100 ] || { t "@@H 🗄️ $S ¦ Scrivi almeno 2 lettere ¦ /cerca_file <nome>" "@@H 🗄️ $S ¦ Type at least 2 letters ¦ /find_file <name>"; exit 0; }
RQ=$(printf '%s' "$Q" | WW=$WW WO=${ASJ:+$OWN} ucode -e 'let o = { q: require("fs").stdin.read("all"), limit: 6, wake: getenv("WW") == "1" };
		if (length(getenv("WO") ?? "")) o.as = getenv("WO"); print(sprintf("%J", o))' 2>/dev/null)
O=$(ubus -t 25 call wrtfreedom nas_find "$RQ" 2>/dev/null)
[ -n "$O" ] || { t "@@H ⚠️ $S ¦ Il router non ha risposto ¦ Riprova" "@@H ⚠️ $S ¦ The router did not answer ¦ Try again"; exit 0; }
WK=$(tr -dc 0-9a-f < /proc/sys/kernel/random/uuid | cut -c1-8); export WQ="$Q" WK
printf '%s' "$O" | J 'let fs = require("fs"), D = {}, it = [], q = getenv("WQ") ?? "", k = getenv("WK") ?? "", f = getenv("WFF");
		try { for (let x in json(getenv("WD") || "{}")?.disks ?? []) D[x.id] = x; } catch (e) {}
		let sz = (b) => { let u = [ "KB", "MB", "GB", "TB" ], v = +(b ?? 0) / 1024.0, i = 0; while (v >= 1024 && i < 3) { v /= 1024.0; i++; }
			let s = v >= 10 || i == 0 ? sprintf("%d %s", v < 1 ? 1 : int(v + 0.5), u[i]) : replace(sprintf("%.1f %s", v, u[i]), ".0 ", " "); return EN ? s : replace(s, ".", ","); };
		if (d.error) { print("@@H ⚠️ ", EN ? "Search" : "Cerca", "\n", EN ? (d.error_en ?? d.error) : d.error, "\n"); exit(0); }
		for (let x in d.items ?? []) if (type(x.path) == "string" && match(x.path, /^\/[^\t\n]+$/)) push(it, { disk: "" + x.disk, path: x.path, name: "" + (x.name ?? ""), size: +(x.size ?? 0) });
		let more = length(it) > 5, sl = map(filter(d.asleep ?? [], (x) => D[x]), (x) => D[x].name ?? x), n = 40;
		it = slice(it, 0, 5);
		if (length(q) > n) { while (n > 0 && (ord(q, n) & 192) == 128) n--; q = substr(q, 0, n) + "…"; }
		fs.writefile(f + ".t", sprintf("%J", { id: k, q: getenv("WQ"), t: time(), items: it })); fs.rename(f + ".t", f);
		let T = "@@H 🗄️ " + (EN ? "Search: " : "Cerca: ") + q + "\n";
		if (!length(it)) {
			if (length(sl)) print("@@BTN w_", k, "=", EN ? "Search" : "Cerca", "\n@@H 🗄️ ", join(", ", sl), "\n", EN ? "The drive is hibernating" : "Il disco è in ibernazione", "\n", EN ? "Wake it to search?" : "Svegliarlo per cercare?", "\n");
			else print(T, EN ? "No file found" : "Nessun file trovato", "\n");
			exit(0);
		}
		let B = [];
		for (let i = 0; i < length(it); i++) push(B, "x" + (i + 1) + "_" + k + "=" + replace(it[i].name, /[|\n]/g, " ") + " · " + sz(it[i].size));
		if (length(sl)) push(B, "w_" + k + "=" + (EN ? "Search Hibernating Drives Too" : "Cerca Anche Nei Dischi Fermi"));
		print("@@BTN1 ", join("|", B), "\n", T);
		print(more ? (EN ? "More than 5: the newest 5" : "Più di 5: i 5 più recenti") : length(it) + (EN ? " found" : (length(it) == 1 ? " trovato" : " trovati")), "\n");
		if (length(sl)) print(join(", ", sl), EN ? ": hibernating, not searched" : ": in ibernazione, non cercato", "\n");
		print(EN ? "Tap a file to get it" : "Tocca un file per riceverlo", "\n");'
;;
*)
t "@@H 💬 Bot ¦ Comando sconosciuto" "@@H 💬 Bot ¦ Unknown command"
;;
esac
exit 0
