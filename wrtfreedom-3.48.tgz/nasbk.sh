#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH
umask 077
R=; [ -n "$WF_NASROOT" ] && [ ! -e /etc/openwrt_release ] && R=$WF_NASROOT
W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; NJ=$ETC/nas.json; BKD=$ETC/nas-bak; CONF=$ETC/nasx-rclone.conf; CDIR=$ETC/nasx-cloud
OCONF=$CONF; CCONF=$ETC/cloud-rclone.conf; XJ=$ETC/nasx.json; CT=/tmp/wf-cloud; CLOUDUC=${WF_CLOUDUC:-$W/cloud.uc}; ACCT=
TMP=/tmp/wf-nas; X=$TMP/x; V=${WF_NASBKUC:-$W/nasbk.uc}
mkdir -p $TMP $X
EN=0; [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { wf_evp "$1" nas "$2"; }
pmsg() { case "$1" in
nas_cloudbk_err) printf '⚠️ Backup Cloud ¦ %s' "$2$(t ': un backup cloud non riesce' ': a cloud backup fails')" ;;
cloud_key_bad) printf '⚠️ Backup Cloud ¦ %s' "$2$(t ': un backup cloud non si apre' ': a cloud backup does not open')" ;;
*) printf '⚠️ Backup ¦ %s' "$2$(t ': un backup non riesce' ': a backup fails')" ;;
esac; }
once() { f=$X/once.$1; n=$(date +%s); l=$(cat "$f" 2>/dev/null); [ -n "$l" ] && [ $((n - l)) -lt "$2" ] && return 1; echo "$n" > "$f"; }
hs() { awk -v b="${1:-0}" 'BEGIN { u="B KB MB GB TB"; split(u, U, " "); i=1; while (b >= 1024 && i < 5) { b /= 1024; i++ } s = (i == 1 ? sprintf("%d", b) : sprintf("%.1f", b)); sub(/\./, ",", s); print s " " U[i] }'; }
short() { printf '%s' "$1" | awk '{ if (length($0) > 22) print substr($0, 1, 21) "…"; else print }'; }
jesc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r\t'; }
js() { ucode -e "let N = {}; try { N = json(require(\"fs\").readfile(\"$1\") ?? \"{}\"); } catch (e) {} $2" 2>/dev/null; }
for lb_f in "${0%/*}/lib.sh" "$W/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
mnt_of() { wf_mntof "$1" "$R"; }
fsof() { awk -v m="$1" '{ p = $2; gsub(/\\040/, " ", p) } p == m { print $3; exit }' $R/proc/mounts; }
freeb() { df -kP "$1" 2>/dev/null | awk 'NR == 2 { printf "%.0f", $4 * 1024 }'; }
usedpct() { df -kP "$1" 2>/dev/null | awk 'NR == 2 && $2 > 0 { printf "%d", ($2 - $4) * 100 / $2 }'; }
alive() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }
SPD=${WF_NASPEED:-$W/naspeed.uc}
spd() { [ -n "$1" ] && [ $# -gt 1 ] && [ -f "$SPD" ] && ucode "$SPD" add "$@" </dev/null >/dev/null 2>&1; true; }
slow() { "$@" & sp=$!; [ -n "$E" ] && echo "$sp" > "$E/pid" 2>/dev/null; spd "$SRC" "$sp"; wait $sp; }
blk() {
L=$TMP/bak-$1.lock
if ! mkdir "$L" 2>/dev/null; then
alive "$(cat "$L/pid" 2>/dev/null)" && return 1
[ -f "$L/pid" ] || [ $(( $(date +%s) - $(date -r "$L" +%s 2>/dev/null || echo 0) )) -gt 60 ] || return 1
rm -rf "$L"; mkdir "$L" 2>/dev/null || return 1
fi
echo $$ > "$L/pid"
}
beat() {
[ -n "$J" ] || return 0
SF=${J%.json}.stop
( n=0; while kill -0 $$ 2>/dev/null; do
sleep 2; n=$((n + 1))
[ -f "$SF" ] && [ -n "$E" ] && kill "$(cat "$E/pid" 2>/dev/null)" 2>/dev/null
if [ -n "$E" ] && [ -s "$E/dm" ] && [ ! -e "$(cat "$E/dm")/.wf-disco" ]; then
: > "$E/gone"; kill "$(cat "$E/pid" 2>/dev/null)" 2>/dev/null
fi
[ $((n % 30)) = 0 ] && touch -c "$J"
done ) </dev/null >/dev/null 2>&1 &
BT=$!
}
bk() { ucode -e "let M = loadfile('$V')(); M.$1('$2');" </dev/null >/dev/null 2>&1; }
pstop() {
PS=; case "$1" in ''|admin) return 1 ;; esac
printf '%s' "$1" | grep -qxE '[a-z][a-z0-9]{0,19}' || return 1
PS=$(ucode -e "let M = loadfile('$V')(); print(M.pstop('$1')?.code ?? '');" </dev/null 2>/dev/null)
[ -n "$PS" ]
}
rcput() {
rs=$(cat); rn=0
if [ "$CONF" = "$CCONF" ]; then
cdir
until { ( umask 077; { printf '{"%s":' "$1"; if [ -n "$rs" ]; then printf '%s' "$rs"; else printf 'null'; fi; printf '}'; } > $CT/.w-nbk.$$ ) &&
ucode "$CLOUDUC" rcput $CT/.w-nbk.$$ </dev/null >/dev/null 2>&1; }; do
rm -f $CT/.w-nbk.$$; rn=$((rn + 1)); [ $rn -ge 3 ] && { rs=; return 1; }; sleep 1
done; rm -f $CT/.w-nbk.$$; rs=; return 0
fi
until printf '%s' "$rs" | ucode -e "let M = loadfile('$V')(), s = require('fs').stdin.read('all') ?? '', W = {}; try { W['$1'] = length(trim(s)) ? json(s) : null; } catch (e) { exit(1); } exit(M.rcset(W) ? 0 : 1);" 2>/dev/null; do
rn=$((rn + 1)); [ $rn -ge 3 ] && { rs=; return 1; }; sleep 1
done; rs=
}
rcdel() {
[ -f $CONF ] || return 0
rn=0
if [ "$CONF" = "$CCONF" ]; then
cdir
until { ( umask 077; printf '%s\n' "$@" | awk 'BEGIN { printf "{" } /^wf[a-z0-9]+$/ && !/^wfa[0-9]+$/ { printf "%s\"%s\":null", c, $0; c = "," } END { print "}" }' > $CT/.w-nbk.$$ ) &&
ucode "$CLOUDUC" rcput $CT/.w-nbk.$$ </dev/null >/dev/null 2>&1; }; do
rm -f $CT/.w-nbk.$$; rn=$((rn + 1)); [ $rn -ge 3 ] && return 1; sleep 1
done; rm -f $CT/.w-nbk.$$; return 0
fi
until ucode -e "let M = loadfile('$V')(), W = {}; for (let s in split('$*', ' ')) if (length(s)) W[s] = null; exit(M.rcset(W) ? 0 : 1);" </dev/null >/dev/null 2>&1; do
rn=$((rn + 1)); [ $rn -ge 3 ] && return 1; sleep 1
done
}
cdir() { [ -d $CT/jobs ] || { mkdir -p $CT/jobs && chmod 700 $CT; }; }
rcl() {
if [ -n "$ACCT" ]; then cdir; RL=$CT/acct-$ACCT.lock; else RL=$X/rc-$1.lock; fi
until mkdir "$RL" 2>/dev/null; do
p=$(cat "$RL/pid" 2>/dev/null)
if [ -n "$p" ] && ! alive "$p"; then rm -rf "$RL"; continue; fi
if [ -z "$p" ] && [ $(( $(date +%s) - $(date -r "$RL" +%s 2>/dev/null || echo 0) )) -gt 60 ]; then rm -rf "$RL"; continue; fi
{ [ "$2" = 1 ] && ! cstopped; } || { RL=; return 1; }
sleep 2
done
echo $$ > "$RL/pid"; [ -n "$ACCT" ] && echo "nbk-$ID-l$$" > "$RL/job"; true
}
cstopped() { [ -f "$X/cloud-$ID.stop" ] || [ -f "$CT/jobs/nbk-$ID.stop" ] || { [ -n "$J" ] && [ -f "${J%.json}.stop" ]; }; }
cinfo() {
ACCT=; KEEPD=30; NETJ='{"mode":"same"}'; ALSO=; KEY2=0; CHECKM=0
eval "$(XI=$ID XF=$XJ ucode -e '
let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {}
for (let c in (type(N?.cloud) == "array" ? N.cloud : [])) {
	if (type(c) != "object" || c.id != getenv("XI")) continue;
	let a = "" + (c.acct ?? ""), k = int(c.keep_days ?? 30), o = "" + (c.also ?? "");
	if (match(a, /^a[0-9]{1,3}$/)) print("ACCT=", a, "\n");
	print("KEEPD=", (k >= 1 && k <= 3650) ? k : 30, "\n");
	if (type(c.net) == "object") print("NETJ=\x27", replace(sprintf("%J", c.net), /[\x27\n]/g, ""), "\x27\n");
	if (match(o, /^k[0-9a-z]{1,16}$/)) print("ALSO=", o, "\n");
	print("KEY2=", c.key2 === true ? 1 : 0, "\nCHECKM=", c.check_m === true ? 1 : 0, "\n");
	break;
}' </dev/null 2>/dev/null)"
cacct
}
cacct() { if [ -n "$ACCT" ]; then CONF=$CCONF; RA=wfa${ACCT#a}; else CONF=$OCONF; RA=wf$ID; fi; }
cline() {
[ -n "$CLD" ] || { [ -f $W/cloudline.sh ] && . $W/cloudline.sh; CLD=1; }
command -v cl_check >/dev/null 2>&1 || cl_check() { echo "ok off 0 fix"; }
command -v cl_add >/dev/null 2>&1 || cl_add() { true; }
command -v cl_tier >/dev/null 2>&1 || cl_tier() { echo B; }
true
}
cgo() {
cbf=$1; cau=$2; w0=$(date +%s); CJOB=${CJN:-nbk-$ID}
while :; do
cstopped && return 1
if l=$(cl_check "$CJOB" "$NETJ" 2>/dev/null); then
WHY=queue
if [ -f $W/cloud.sh ] && [ -n "$ACCT" ]; then
o=$(sh $W/cloud.sh slot get "$CJOB" "$ACCT" $$ </dev/null 2>/dev/null) && WHY=
[ "$o" = 'wait acct' ] && WHY=acct
elif rcl "$RA"; then WHY=; fi
if [ -z "$WHY" ]; then
set -- $l; CBW=
case "$2" in ''|off|0|-) ;; *) CBW="--bwlimit $2" ;; esac
[ -n "$3" ] && [ "$3" -gt 0 ] 2>/dev/null && CBW="$CBW --max-transfer $3 --cutoff-mode soft"
return 0
fi
else
set -- $l; WHY=${2:-net}; cslput
[ "$cau" = 1 ] && return 2
fi
"$cbf" wait
[ $(( $(date +%s) - w0 )) -ge "${WF_CLWAIT:-72000}" ] && return 2
s=60; { [ "$WHY" = queue ] || [ "$WHY" = acct ]; } && s=10; [ -n "$WF_CLSTEP" ] && s=$WF_CLSTEP; i=0
while [ $i -lt "$s" ]; do cstopped && return 1; sleep 1; i=$((i + 1)); done
done
}
cslput() { [ -n "$CJOB" ] && [ -f $W/cloud.sh ] && sh $W/cloud.sh slot put "$CJOB" </dev/null >/dev/null 2>&1; true; }
crun() {
cb=$1; shift
XMEM="--buffer-size 4M --transfers 2 --checkers 4"
[ "$(cl_tier)" = A ] && { export GOGC=20; XMEM="--buffer-size 1M --transfers 1 --checkers 2"; }
: > "$LOG"
rclone "$@" $XMEM $CBW --use-json-log --stats 2s --stats-log-level NOTICE --log-level NOTICE --log-file "$LOG" </dev/null >/dev/null 2>&1 & CP=$!
SRC=$DISK; spd "$DISK" "$CP"
[ -d $X/cloud-$ID.lock ] && echo $CP > $X/cloud-$ID.lock/rpid
n=0; LWHY=
while alive $CP; do
sleep 2; n=$((n + 2))
cstopped && { kill -TERM $CP 2>/dev/null; wait $CP; return 254; }
[ "$cb" != - ] && "$cb"
if [ $n -ge "${CL_EVERY:-60}" ] && [ -n "$ACCT" ]; then
n=0
if ! l=$(cl_check "$CJOB" "$NETJ" 2>/dev/null); then
set -- $l; LWHY=${2:-net}; kill -TERM $CP 2>/dev/null; wait $CP; return 253
fi
fi
[ "$(wc -c < "$LOG" 2>/dev/null)" -gt 262144 ] 2>/dev/null && { tail -n 200 "$LOG" > "$LOG.t" && cat "$LOG.t" > "$LOG"; rm -f "$LOG.t"; }
done
wait $CP
}
cbytes() {
s=$(grep '"stats"' "$LOG" 2>/dev/null | tail -n 1)
printf '%s' "$s" | ucode -e 'let s = {}; try { s = json(require("fs").stdin.read("all")).stats ?? {}; } catch (e) {} print(int(s.bytes ?? 0), " ", int(s.transfers ?? 0));' 2>/dev/null
}
ctr() {
if grep -qiE 'invalid_grant|unauthori[sz]ed|401|token (expired|revoked|rejected)|invalid access_token' "$1" 2>/dev/null; then echo relink
elif grep -qiE 'quota|storage.*full|insufficient|no space|507' "$1" 2>/dev/null; then echo space
elif grep -qiE 'no such host|dial tcp|i/o timeout|timeout|network is unreachable|connection refused' "$1" 2>/dev/null; then echo net
elif grep -qiE 'not decrypt|decrypt|bad password|illegal base32|strict|nonce|crypt' "$1" 2>/dev/null; then echo key
elif grep -qiE 'directory not found|object not found|not found|404' "$1" 2>/dev/null; then echo path
else echo fail; fi
}
cmsg() {
case "$1" in
relink) CM='Account da ricollegare'; CME='Account needs reconnecting' ;;
space) CM='Spazio del cloud finito'; CME='Cloud storage full' ;;
net) CM='Internet non raggiungibile'; CME='Internet not reachable' ;;
key) CM='La chiave non apre questo backup'; CME='The key does not open this backup' ;;
path) CM='Cartella del cloud non trovata'; CME='Cloud folder not found' ;;
busy) CM="Account occupato da un'altra copia: riprova più tardi"; CME='Account busy with another copy: try again later' ;;
never) CM='Nessuna copia ancora nel cloud'; CME='No copy in the cloud yet' ;;
*) CM='Non riuscito'; CME='Failed' ;;
esac
}
evc() { wf_evp "$1" cloud "$2"; }
kid() { echo "$1" | grep -qE '^k[0-9a-z]{1,16}$' && [ -f "$CDIR/$1.sh" ] && { ( sh "$0" cloud "$1" ) </dev/null >/dev/null 2>&1 & }; true; }
rcu() { [ -n "$RL" ] && [ "$(cat "$RL/pid" 2>/dev/null)" = "$$" ] && rm -rf "$RL"; RL=; true; }
cabout() {
f=$X/cloud-$ID.about; n=$(date +%s)
[ $((n - $(date -r "$f" +%s 2>/dev/null || echo 0))) -lt 3600 ] && return 0
o=$(rclone about "$1:" --json </dev/null 2>/dev/null | ucode -e 'let a = null; try { a = json(require("fs").stdin.read("all")); } catch (e) {} let r = { t: time() }; if (type(a) == "object") for (let k in [ "total", "used", "free", "trashed" ]) if (type(a[k]) == "int" && a[k] >= 0) r[k] = a[k]; if (r.free != null) printf("%J\n", r);' 2>/dev/null)
[ -n "$o" ] || return 0
echo "$o" > "$f.t" && mv "$f.t" "$f"
[ $((n - $(date -r $CDIR/$ID.about +%s 2>/dev/null || echo 0))) -ge 86400 ] && mkdir -p $CDIR && cp "$f" $CDIR/$ID.about.t && mv $CDIR/$ID.about.t $CDIR/$ID.about
true
}

jw() {
[ -n "$J" ] || return 0
printf '{"id":"%s","op":"%s","name":"%s","done":%s,"total":%s,"bytes":%s,"bytes_total":%s,"file":"","state":"%s","t":%s,"pid":%s,"wait":%s,"err":"%s","err_en":"%s","own":"%s"%s}\n' \
		"$JOB" "${OP:-backup}" "$(jesc "$NAME")" "${2:-0}" "${3:-0}" "${2:-0}" "${3:-0}" "$1" "$(date +%s)" $$ "${WAIT:-false}" "$(jesc "$ERR")" "$(jesc "$ERR_EN")" "$(jesc "${OWN:-admin}")" "${JX:+,$JX}" > "$J.t" && mv "$J.t" "$J"
}
dw() {
f=$TMP/bk-dry-$ID.json; c=$(date -r $BKD/$ID.sh +%s 2>/dev/null)
printf '{"state":"%s","ok":%s,"files":%s,"bytes":%s,"free":%s,"secs":%s,"t":%s,"cfg":%s,"pid":%s,"err":"%s","err_en":"%s"}\n' \
		"$1" "${2:-false}" "${3:-0}" "${4:-0}" "${5:-0}" "${6:-0}" "$(date +%s)" "${c:-0}" $$ "$(jesc "$7")" "$(jesc "$8")" > "$f.$$.t" && mv "$f.$$.t" "$f"
}
bakend() {
n=$(date +%s); x=${4:-0}
echo "$n $1 ${2:-0} $x $((n - T0))" > $BKD/$ID.last
echo "$(date +%Y%m%d) $1 $x" >> $BKD/hist
[ "$(wc -l < $BKD/hist)" -gt 400 ] && { tail -n 300 $BKD/hist > $BKD/hist.t; mv $BKD/hist.t $BKD/hist; }
if [ "$1" = 1 ]; then
echo "$n" > $BKD/$ID.ok; rm -f $X/once.bkerr-$ID; jw ok "${2:-0}" "${2:-0}"
ev nas_backup_ok "$3"
[ -n "$DM" ] && bk bkprune "$ID"
else
jw err 0 0
if [ "$WARN" != 0 ] && { [ "$AUTO" != 1 ] || once bkerr-$ID 72000; }; then ev nas_backup_err "$3"; fi
fi
kid "$(js "$NJ" "for (let b in (N.backups ?? [])) if (b?.id == \"$ID\") { print(b.also ?? \"\"); break; }")"
exit 0
}
skip() {
if [ "$DRY" = 1 ]; then dw err false 0 0 0 0 "$1" "$2"; exit 0; fi
[ -n "$PART" ] && rm -rf "$PART"
bakend 0 0 "⚠️ Backup ¦ $(t "$1" "$2") ¦ $(short "$NAME")"
}
stopped() { [ -n "$PART" ] && rm -rf "$PART"; rm -f "$SF"; jw stop 0 0; exit 0; }
ondisk() { [ -z "$DM" ] || { [ ! -f "$E/gone" ] && [ -n "$(fsof "$DM")" ] && [ -e "$DM/.wf-disco" ]; }; }
onflash() { case "$(df -P "$1" 2>/dev/null | awk 'NR == 2 { print $NF }')" in /|/overlay|/rom) return 0 ;; esac; return 1; }
dsync() { sync -f "$1" 2>/dev/null || sync; }
lost() {
[ -n "$DST" ] && [ -d "$DST" ] && ! ondisk && onflash "$DST" && rm -rf "$DST"
skip 'Non riuscito: disco staccato' 'Failed: drive removed'
}
SECRET='etc/wrtfreedom/nas-cam.pw etc/wrtfreedom/nasx-rclone.conf etc/wrtfreedom/nasx-rclone.conf.pre321 etc/wrtfreedom/backup.pw etc/wrtfreedom/cloud-rclone.conf etc/wrtfreedom/cloud-rclone.conf.old etc/wrtfreedom/cloud-links.json etc/wrtfreedom/nas-dav.digest etc/wrtfreedom/nas-admpw.fp etc/ksmbd/ksmbdpwd.db etc/samba/smbpasswd etc/samba/passdb.tdb etc/wrtfreedom/tg-u'
nopw() { [ -f "$1" ] || return 0; sh $W/backup.sh nopw "$1"; }
notok() { [ -f "$1" ] || return 0; sh $W/backup.sh notok "$1"; }
nosecret() {
l=$(tar tzf "$1" 2>/dev/null) || return 1
f=0; for s in $SECRET etc/wrtfreedom/nas.json 'etc/wrtfreedom/nas-blk/.*' etc/config/wrtfreedom; do printf '%s\n' "$l" | grep -qxE "(\./)?$s(/.*)?" && f=1; done
[ $f = 1 ] || return 0
rm -rf "$E/rt"; mkdir -p "$E/rt" && tar xzf "$1" -C "$E/rt" 2>/dev/null || return 1
for s in $SECRET; do rm -rf "$E/rt/$s"; done
rm -rf "$E/rt/etc/wrtfreedom/nas-blk"
nopw "$E/rt/etc/wrtfreedom/nas.json" || { rm -rf "$E/rt"; return 1; }
notok "$E/rt/etc/config/wrtfreedom" || { rm -rf "$E/rt"; return 1; }
(cd "$E/rt" && tar czf "$1.t" $(ls -A)) && mv "$1.t" "$1"; r=$?; rm -rf "$E/rt"; return $r
}
run() {
ID=$1; JOB=$2; DF=$3; F=$BKD/$ID.sh; AUTO=0; [ -n "$JOB" ] || AUTO=1; PART=; BT=
echo "$ID" | grep -qE '^b[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
. "$F"
T0=$(date +%s); E=$TMP/bk-$ID.e$$; MISS=0; NSK=0
if [ "$DRY" = 1 ]; then
dw run; trap 'rm -rf $E' EXIT
else
blk "$ID" || exit 0
trap 'rm -rf $TMP/bak-$ID.lock $E; [ -n "$DF" ] && rm -f "$DF"; [ -n "$BT" ] && kill $BT 2>/dev/null' EXIT
[ -n "$JOB" ] || JOB=bak-$ID-$T0
mkdir -p $TMP/jobs $E; J=$TMP/jobs/$JOB.json; jw run 0 0; beat
fi
command -v rsync >/dev/null 2>&1 || skip 'Manca rsync' 'rsync missing'
if pstop "$OWN"; then
case $PS in
blocked) skip 'Saltato: accesso bloccato' 'Skipped: access blocked' ;;
nomain) skip 'Saltato: Disco Principale in pausa' 'Skipped: Main Drive paused' ;;
*) skip 'Saltato: spazio finito' 'Skipped: space used up' ;;
esac
fi
S=$(mnt_of "$SRC")
[ -n "$S" ] || [ "$ROUTER" = 1 ] || skip 'Saltato: disco mancante' 'Skipped: disk missing'
[ -n "$SAFE" ] || SAFE=$(printf '%s' "$NAME" | sed 's/[^A-Za-z0-9._-]/_/g')
if [ "$KIND" = nas ]; then DM=; DST="rsync://$HOST$DPATH/$SAFE"
else DM=$(mnt_of "$DDISK"); [ -n "$DM" ] || skip 'Saltato: disco mancante' 'Skipped: disk missing'; DST="$DM$DPATH/$SAFE"; fi
if [ -n "$DM" ]; then
FC=$(js "$NJ" 'let A = N.bk?.adv ?? {}; print(A.full ?? "prune", " ", A.cap ?? 80);'); FULL=${FC% *}; CAP=${FC#* }
case "$CAP" in ''|*[!0-9]*) CAP=80;; esac
U=$(usedpct "$DM"); [ "$FULL" = stop ] && [ "${U:-0}" -ge "$CAP" ] && skip 'Saltato: Quota Delle Copie piena' 'Skipped: Backup Quota full'
fi
STAMP=$(date +%Y%m%d-%H%M); mkdir -p $E/empty
MODE_=snap; O=-a
if [ -n "$DM" ]; then
ROOT=$(readlink -f "$DM" 2>/dev/null); inroot "$DST" || skip 'Non riuscito: cartella' 'Failed: folder'
if [ "$DRY" != 1 ]; then
{ [ -e "$DM/.wf-disco" ] || : > "$DM/.wf-disco"; } 2>/dev/null && ondisk || skip 'Saltato: disco mancante' 'Skipped: disk missing'
echo "$DM" > "$E/dm"
mkdir -p "$DST" || skip 'Non riuscito: cartella' 'Failed: folder'
rm -rf "$DST"/[0-9]*-[0-9]*.partial "$DST"/router/.router-*.t
fi
case "$(fsof "$DM")" in vfat|msdos|exfat|ntfs|ntfs3|fuseblk) MODE_=mirror; O="-rt --modify-window=2";; esac
PREV=$(ls -1 "$DST" 2>/dev/null | grep -E '^[0-9]{8}-[0-9]{4}$' | sort | tail -n 1)
else
rsync -r $E/empty/ "$DST/" >/dev/null 2>&1 || skip 'Saltato: NAS non raggiungibile' 'Skipped: NAS unreachable'
PREV=
for v in $(rsync "$DST/" 2>/dev/null | awk '{ print $NF }' | grep -E '^[0-9]{8}-[0-9]{4}$' | sort -r); do
rsync "$DST/$v/.wf-incompleta" >/dev/null 2>&1 || { PREV=$v; break; }
[ "$DRY" = 1 ] || rsync -r --delete --include="/$v/***" --exclude='*' $E/empty/ "$DST/" >/dev/null 2>&1
done
fi
BD=
if [ $MODE_ = mirror ]; then
TO="$DST/current/"; LD=; O="$O --delete"; BD="--backup-dir=$DST/old/$STAMP"
elif [ -n "$DM" ]; then TO="$DST/$STAMP.partial/"; LD=${PREV:+--link-dest=$DST/$PREV}; [ "$DRY" = 1 ] || PART="$DST/$STAMP.partial"
else TO="$DST/$STAMP/"; LD=${PREV:+--link-dest=../$PREV}; fi
[ "$DRY" = 1 ] && [ -n "$DM" ] && [ ! -d "$DST" ] && { TO="$E/dry/"; mkdir -p "$TO"; LD=; }
set --
if [ -n "$S" ]; then
L=$BKD/$ID.dirs; [ -n "$DF" ] && [ -s "$DF" ] && L=$DF
if [ "$ALL" = 1 ] && [ "$L" != "$DF" ]; then set -- "$S/"
else
MISS=0
while IFS= read -r d; do [ -n "$d" ] || continue; if [ -e "$S$d" ]; then set -- "$@" "$S/.$d"; else MISS=$((MISS + 1)); fi; done < "$L"; O="$O -R"
[ $# -eq 0 ] && [ "$MISS" -gt 0 ] && skip 'Cartella da copiare non trovata' 'Folder to copy not found'
fi
fi
XF="--exclude-from=$BKD/$ID.excl"; O="$O --exclude=/.wf-disco"
SIZE=0; NEED=0
if [ $# -gt 0 ]; then
ST=$(slow rsync -n --stats $O ${LD:+"$LD"} "$XF" "$@" "$TO" 2>/dev/null)
NEED=$(echo "$ST" | sed -n 's/^Total transferred file size: \([0-9,.]*\).*/\1/p' | tr -d ',.')
TOT=$(echo "$ST" | sed -n 's/^Total file size: \([0-9,.]*\).*/\1/p' | tr -d ',.')
NF=$(echo "$ST" | sed -n 's/^Number of \(regular \)\{0,1\}files transferred: \([0-9,.]*\).*/\2/p' | tr -d ',.')
if [ "$DRY" = 1 ]; then
FR=0; [ -n "$DM" ] && FR=$(freeb "$DM")
set -- $(cut -d' ' -f4,5 $BKD/$ID.last 2>/dev/null)
RT=$(( ${2:-0} > 0 && ${1:-0} > 0 ? ${1:-0} / ${2:-1} : 0 )); [ "$RT" -gt 0 ] 2>/dev/null || { RT=20971520; [ -z "$DM" ] && RT=5242880; }
OK=true; [ -n "$DM" ] && [ "${NEED:-0}" -gt $((FR - 52428800)) ] && OK=false
dw ok $OK "${NF:-0}" "${NEED:-0}" "$FR" $(( ${NEED:-0} / RT + 1 ))
exit 0
fi
[ -f "$SF" ] && stopped
ondisk || lost
if [ -n "$DM" ] && [ -n "$NEED" ] && [ "$NEED" -gt $(( $(freeb "$DM") - 52428800 )) ] 2>/dev/null; then
skip 'Saltato: disco pieno' 'Skipped: disk full'
fi
if [ $MODE_ = mirror ]; then : > "$DST/.wf-incompleta" && dsync "$DST"
elif [ -z "$DM" ]; then mkdir -p $E/mk && : > $E/mk/.wf-incompleta && rsync -r $E/mk/ "$DST/$STAMP/" >/dev/null 2>&1 || skip 'Saltato: NAS non raggiungibile' 'Skipped: NAS unreachable'; fi
{ slow rsync $O ${BD:+"$BD"} ${LD:+"$LD"} "$XF" --info=progress2 "$@" "$TO" 2>$E/err; echo $? > $E/rc; } | tr '\r' '\n' |
awk -v T="${NEED:-0}" -v J="$J" -v JOB="$JOB" -v N="$(jesc "$NAME")" -v P=$$ '
				$1 ~ /^[0-9,]+$/ && $2 ~ /%$/ { b = $1; gsub(/,/, "", b); p = $2 + 0; if (p == lp) next; lp = p
					printf "{\"id\":\"%s\",\"op\":\"backup\",\"name\":\"%s\",\"done\":%s,\"total\":%s,\"bytes\":%s,\"bytes_total\":%s,\"file\":\"\",\"state\":\"run\",\"pid\":%s}\n", JOB, N, b, T, b, T, P > (J ".t")
					close(J ".t"); system("mv \"" J ".t\" \"" J "\"") }'
rc=$(cat $E/rc 2>/dev/null)
ondisk || lost
[ -f "$SF" ] && stopped
if [ "$rc" = 23 ]; then
NSK=$(grep -c '^rsync: ' $E/err 2>/dev/null); [ "${NSK:-0}" -gt 0 ] || NSK=1
grep '^rsync: ' $E/err 2>/dev/null | sed -n 's/^[^"]*"\(.*\)".*$/\1/p' | head -n 50 > $BKD/$ID.skip.t && mv $BKD/$ID.skip.t $BKD/$ID.skip
elif [ "$rc" != 0 ] && [ "$rc" != 24 ]; then skip 'Copia non riuscita' 'Copy failed'; fi
if [ -n "$DM" ]; then
dsync "$DST"; ondisk || lost
if [ "$MODE_" = snap ]; then rm -rf "${DST:?}/$STAMP"; mv "$DST/$STAMP.partial" "$DST/$STAMP" || skip 'Copia non riuscita' 'Copy failed'; PART=
else rm -f "$DST/.wf-incompleta"; fi
dsync "$DST"
else rsync -r --delete --include='/.wf-incompleta' --exclude='*' $E/empty/ "$DST/$STAMP/" >/dev/null 2>&1; fi
SIZE=${TOT:-0}
elif [ "$DRY" = 1 ]; then
dw ok true 0 0 0 1; exit 0
fi
if [ "$ROUTER" = 1 ] && [ -n "$DM" ] && [ -f $W/backup.sh ]; then
ondisk || lost
mkdir -p "$DST/router"
RTF="$DST/router/.router-$STAMP.tar.gz.t"
sh $W/backup.sh create "$E/router.tar.gz" >/dev/null 2>&1 && nosecret "$E/router.tar.gz" && cp "$E/router.tar.gz" "$RTF" && dsync "$RTF" && ondisk &&
mv "$RTF" "$DST/router/router-$STAMP.tar.gz" && SIZE=$((SIZE + $(wc -c < "$E/router.tar.gz"))) || { rm -f "$RTF"; ondisk || lost; skip 'Copia del router non riuscita' 'Router copy failed'; }
[ "${KEEP:-0}" -gt 0 ] && find "$DST/router" -name 'router-*.tar.gz' -mtime +$KEEP -exec rm -f {} \; 2>/dev/null
fi
if [ -z "$DM" ] && [ "${KEEP:-0}" -gt 0 ]; then
CUT=$(date -d @$(( $(date +%s) - KEEP * 86400 )) +%Y%m%d-%H%M 2>/dev/null)
[ -n "$CUT" ] && for v in $(rsync "$DST/" 2>/dev/null | awk '{ print $NF }' | grep -E '^[0-9]{8}-[0-9]{4}$' | sort | sed '$d'); do
[ "$(echo "$v" | tr -d -)" -lt "$(echo "$CUT" | tr -d -)" ] && rsync -r --delete --include="/$v/***" --exclude='*' $E/empty/ "$DST/" >/dev/null 2>&1
done
fi
TX=""; [ "$MODE" = plug ] && TX=" · $(t 'Puoi espellere il disco' 'You can eject the drive')"
if [ "${NSK:-0}" -gt 0 ]; then echo "$(date +%s) skip $NSK" > $BKD/$ID.chk.t && mv $BKD/$ID.chk.t $BKD/$ID.chk
TX="$TX · ⚠️ $(t "File non copiati: $NSK" "Files not copied: $NSK")"
elif [ "${MISS:-0}" -gt 0 ]; then echo "$(date +%s) miss $MISS" > $BKD/$ID.chk.t && mv $BKD/$ID.chk.t $BKD/$ID.chk; rm -f $BKD/$ID.skip
TX="$TX · ⚠️ $(t "Cartelle non trovate: $MISS" "Folders not found: $MISS")"
else rm -f $BKD/$ID.chk $BKD/$ID.skip; fi
bakend 1 "$SIZE" "💾 Backup ¦ $(t 'Copia finita' 'Copy finished') ¦ $(short "$NAME") · $(hs "${NEED:-0}")$TX" "${NEED:-0}"
}

freename() {
d=${1%/*}; b=${1##*/}; e=; case "$b" in ?*.*) e=".${b##*.}"; b=${b%.*};; esac
i=2; while [ -e "$d/$b ($i)$e" ] || [ -L "$d/$b ($i)$e" ]; do i=$((i + 1)); done; printf '%s' "$d/$b ($i)$e"
}
inroot() {
[ -n "$ROOT" ] || return 0
x=$1; while [ ! -e "$x" ] && [ ! -L "$x" ] && [ "${#x}" -gt "${#ROOT}" ]; do x=${x%/*}; done
r=$(readlink -f "$x" 2>/dev/null) && [ -n "$r" ] || return 1
case "$r" in "$ROOT"|"$ROOT"/*) return 0 ;; esac
return 1
}
put1() { # <file della versione> <arrivo>
inroot "${2%/*}" && mkdir -p "${2%/*}" && inroot "${2%/*}" || return 1
if [ ! -e "$2" ] && [ ! -L "$2" ]; then cp -p "$1" "$2"
elif [ ! -L "$2" ] && cmp -s "$1" "$2"; then return 0
else cp -p "$1" "$(freename "$2")"; fi
}
restore() {
JOB=$1; echo "$JOB" | grep -qE '^bak-r[0-9a-z]{1,16}$' || exit 1
J=$TMP/jobs/$JOB.json; LST=$TMP/jobs/$JOB.list; [ -f "$LST" ] || exit 1
NAME=$(js "$J" 'print(N.name ?? "");'); ROOT=$(js "$J" 'print(N.root ?? "");'); OP=restore; W2=$TMP/jobs/$JOB.files; BT=
trap 'rm -f "$LST" "$W2"; [ -n "$BT" ] && kill $BT 2>/dev/null' EXIT
beat
TB=$(printf '\t')
: > "$W2"
while IFS="$TB" read -r s d; do
[ -n "$s" ] || continue
if [ -d "$s" ] && [ ! -L "$s" ]; then find "$s" -type f | while IFS= read -r f; do printf '%s\t%s\n' "$f" "$d${f#"$s"}"; done >> "$W2"
elif [ ! -d "$s" ]; then printf '%s\t%s\n' "$s" "$d" >> "$W2"; fi
done < "$LST"
TOT=$(grep -c . "$W2"); n=0; bad=0; jw run 0 "$TOT"
while IFS="$TB" read -r s d; do
[ -f "$TMP/jobs/$JOB.stop" ] && { rm -f "$TMP/jobs/$JOB.stop"; jw stop $n "$TOT"; exit 0; }
put1 "$s" "$d" || bad=$((bad + 1))
n=$((n + 1)); [ $((n % 20)) = 0 ] && jw run $n "$TOT"
done < "$W2"
if [ $bad -gt 0 ]; then jw err $n "$TOT"; ev nas_backup_err "⚠️ $(t 'Ripristino' 'Restore') ¦ $bad $(t 'file non ripristinati' 'files not restored') ¦ $(short "$NAME")"
else jw ok $n "$TOT"; ev nas_backup_ok "💾 $(t 'Ripristino' 'Restore') ¦ $(t 'Finito' 'Finished') ¦ $(short "$NAME") · $n file"; fi
}

verify() {
ID=$1; F=$BKD/$ID.sh
echo "$ID" | grep -qE '^b[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
. "$F"
[ "$KIND" != nas ] || exit 0
blk "$ID" || exit 0
trap 'rm -rf $TMP/bak-$ID.lock' EXIT
S=$(mnt_of "$SRC"); DM=$(mnt_of "$DDISK"); [ -n "$S" ] && [ -n "$DM" ] || exit 0
[ -n "$SAFE" ] || SAFE=$(printf '%s' "$NAME" | sed 's/[^A-Za-z0-9._-]/_/g')
D="$DM$DPATH/$SAFE"
LV=$(ls -1 "$D" 2>/dev/null | grep -E '^[0-9]{8}-[0-9]{4}$' | sort | tail -n 1); [ -d "$D/current" ] && LV=current
[ -n "$LV" ] || exit 0
E=$TMP/bk-$ID.v$$; mkdir -p $E; trap 'rm -rf $TMP/bak-$ID.lock $E' EXIT
if [ "$ALL" = 1 ]; then echo / > $E/dirs; else cp $BKD/$ID.dirs $E/dirs; fi
bad=0
while IFS= read -r d; do
[ "$d" = / ] && d=
[ -d "$S$d" ] && [ -d "$D/$LV$d" ] || continue
slow rsync -rnc --out-format='%n' --exclude-from="$BKD/$ID.excl" "$S$d/" "$D/$LV$d/" </dev/null 2>/dev/null | grep -v '/$' > $E/c
slow rsync -rnt --modify-window=2 --out-format='%n' --exclude-from="$BKD/$ID.excl" "$S$d/" "$D/$LV$d/" </dev/null 2>/dev/null | grep -v '/$' > $E/t
bad=$((bad + $(awk 'FILENAME == ARGV[1] { s[$0] = 1; next } !($0 in s) { n++ } END { print n + 0 }' $E/t $E/c)))
done < $E/dirs
printf '{"t":%s,"bad":%s}\n' "$(date +%s)" "$bad" > $TMP/bk-verify-$ID.json
[ $bad -gt 0 ] && ev nas_backup_err "⚠️ $(t 'Verifica Integrità' 'Integrity Check') ¦ $bad $(t 'file da ricopiare' 'files to copy again') ¦ $(short "$NAME")"
true
}

du_() {
o=$TMP/bk-du.json.t; printf '{' > $o; c=
js $TMP/bk-pc.json 'for (let x in (N.list ?? [])) print(x.path, "\n");' | while IFS= read -r p; do
[ -d "$p" ] || continue
b=$(du -sk "$p" 2>/dev/null | awk '{ printf "%.0f", $1 * 1024 }')
printf '%s"%s":%s' "$c" "$(jesc "$p")" "${b:-0}" >> $o; c=,
done
echo '}' >> $o; mv $o $TMP/bk-du.json
}

cw() {
n=$(date +%s); w=; wt=; [ "$1" = wait ] && { w=$WHY; wt=$(cl_why "$w" 2>/dev/null); }
printf '{"state":"%s","bytes":%s,"total":%s,"files":%s,"files_total":%s,"speed":%s,"t0":%s,"t":%s,"pid":%s,"wc":"%s","why":"%s","why_en":"%s","err":"%s","err_en":"%s"}\n' \
		"$1" "${2:-0}" "${3:-0}" "${4:-0}" "${5:-0}" "${6:-0}" "$T0" "$n" "${CP:-$$}" "$w" "${wt%%|*}" "${wt#*|}" "$(jesc "$7")" "$(jesc "$8")" > "$P.t" && mv "$P.t" "$P"
[ -n "$ACCT" ] || return 0
[ "$1" != "$CWS" ] || [ $((n - ${CWT:-0})) -ge 30 ] || return 0
CWS=$1; CWT=$n; cdir; f=$CT/jobs/nbk-$ID.json
pc=0; [ "${3:-0}" -gt 0 ] 2>/dev/null && pc=$(( ${2:-0} * 100 / $3 ))
printf '{"job":"nbk-%s","kind":"nasbk","bk":"%s","acct":"%s","name":"%s","state":"%s","wc":"%s","why":"%s","why_en":"%s","pct":%s,"bytes":%s,"size":%s,"speed":%s,"pid":%s,"err":"%s","err_en":"%s","t":%s}\n' \
		"$ID" "$ID" "$ACCT" "$(jesc "$NAME")" "$1" "$w" "${wt%%|*}" "${wt#*|}" "$pc" "${2:-0}" "${3:-0}" "${6:-0}" "${CP:-$$}" "$(jesc "$7")" "$(jesc "$8")" "$n" > "$f.$$" && mv "$f.$$" "$f"
}
clast() {
l="$(date +%s) $1 ${2:-0} ${3:-0}"; echo "$l" > $X/cloud-$ID.last
o=$(cat $CDIR/$ID.last 2>/dev/null); ot=${o%% *}; oo=$(echo "$o" | cut -d' ' -f2)
{ [ "$oo" != "$1" ] || [ $(( $(date +%s) - ${ot:-0} )) -ge 21600 ]; } && mkdir -p $CDIR && echo "$l" > $CDIR/$ID.last
true
}
ro_of() { js $X/disks.json "for (let d in (N.list ?? [])) if (d.id == \"$1\") { print(d.ro ? 1 : 0); break; }"; }
cmnt() { js $X/disks.json "for (let d in (N.list ?? [])) if (d.id == \"$1\") { print(d.mnt); break; }"; }
cbase() { if [ "$CRYPT" = 1 ]; then printf '%s' "wf${ID}x:"; else printf '%s' "$RA:${REM#/}/"; fi; }
crem() { awk -v s="[wf${ID}x]" '/^\[.*\][ \t]*$/ { k = ($0 == s); next } k && /^remote[ \t]*=/ { sub(/^remote[ \t]*=[ \t]*/, ""); print; exit }' $CONF 2>/dev/null; }
cgone() { for e in last vers full about keep keepnext st check; do rm -f "$CDIR/$ID.$e"; done; rm -f $X/cloud-$ID.* "$CT/jobs/nbk-$ID.json"; }
stput() {
mkdir -p $CDIR
XF=$CDIR/$ID.st XT=$CDIR/$ID.st.$$ ucode -e 'let fs = require("fs"), S = {}; try { S = json(fs.readfile(getenv("XF")) ?? "{}"); } catch (e) {}
		if (type(S) != "object") S = {};
		for (let a in ARGV) { let i = index(a, "="); if (i > 0) try { S[substr(a, 0, i)] = json(substr(a, i + 1)); } catch (e) {} }
		fs.writefile(getenv("XT"), sprintf("%J\n", S)); fs.rename(getenv("XT"), getenv("XF"));' "$@" </dev/null 2>/dev/null; true
}
keybad() { grep -q '"keybad": *true' "$CDIR/$ID.st" 2>/dev/null; }
cdone() { [ -f "$CDIR/$ID.last" ] || [ -f "$X/cloud-$ID.last" ]; }
cinfo_put() {
c=false; [ "$CRYPT" = 1 ] && c=true
printf '{"v":1,"t":%s,"crypt":%s,"kind":"backup"}\n' "$(date +%s)" "$c" | rclone rcat "$RA:${REM#/}/.wf-info" >/dev/null 2>&1; true
}
cprog() {
s=$(tail -c 16384 "$LOG" 2>/dev/null | grep '"stats"' | tail -n 1)
[ -n "$s" ] || s=$(grep '"stats"' "$LOG" 2>/dev/null | tail -n 1)
[ -n "$s" ] && cw run $(printf '%s' "$s" | ucode -e 'let s = {}; try { s = json(require("fs").stdin.read("all")).stats ?? {}; } catch (e) {} print(int(s.bytes ?? 0), " ", int(s.totalBytes ?? 0), " ", int(s.transfers ?? 0), " ", int(s.totalTransfers ?? 0), " ", int(s.speed ?? 0));' 2>/dev/null)
true
}
cloud() {
ID=$1; F=$CDIR/$ID.sh
echo "$ID" | grep -qE '^k[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
REMV=0; ADOPT=0; WARN=1; OWN=
. "$F"
[ "$REMV" = 2 ] || exit 0
pstop "$OWN" && exit 0
cinfo; cline; CBW=
mkdir $X/cloud-$ID.lock 2>/dev/null || { alive "$(cat $X/cloud-$ID.lock/pid 2>/dev/null)" && exit 0; rm -rf $X/cloud-$ID.lock; mkdir $X/cloud-$ID.lock || exit 0; }
echo $$ > $X/cloud-$ID.lock/pid; rm -f $X/cloud-$ID.stop $CT/jobs/nbk-$ID.stop
P=$X/cloud-$ID.json; LOG=$X/cloud-$ID.log; T0=$(date +%s); CP=; RL=; CJOB=; CDONE=0; WHY=
trap 'rm -rf $X/cloud-$ID.lock; cslput; rcu; [ -f "$F" ] || { rcdel "wf$ID" "wf${ID}x"; cgone; }; [ "$CDONE" = 1 ] && { bk bkown; kid "$ALSO"; }' EXIT
cw run
fail() { CDONE=1; cw err 0 0 0 0 0 "$1" "$2"; clast 0 0 0; [ -n "$B" ] && [ -n "$RL$CJOB" ] && cvers
[ "$WARN" != 0 ] && once cloud-$ID 21600 && ev nas_cloudbk_err "⚠️ Backup Cloud ¦ $(t "$1" "$2") ¦ $(short "$NAME")"; exit 0; }
cstop() { rm -f $X/cloud-$ID.stop $CT/jobs/nbk-$ID.stop; cw stop; exit 0; }
B=
command -v rclone >/dev/null 2>&1 || fail 'Manca rclone' 'rclone missing'
[ -z "$ACCT" ] || grep -q "^\[$RA\]" $CONF 2>/dev/null || fail 'Account da ricollegare' 'Account needs reconnecting'
[ "$CRYPT" = 1 ] && keybad && fail 'La chiave non apre questo backup' 'The key does not open this backup'
[ "$ADOPT" = 1 ] && [ -f $X/.pw-$ID ] && { CDONE=0; cw stop; exit 0; }
[ "$CRYPT" = 1 ] && ! grep -q "^\[wf${ID}x\]" $CONF 2>/dev/null && fail 'Password Di Crittografia mancante' 'Encryption Password missing'
[ "$CRYPT" = 1 ] && [ "$(crem)" != "$RA:${REM#/}" ] && fail 'Cartella del cloud non ancora pronta: riprova fra poco' 'Cloud folder not ready yet: try again shortly'
M=$(cmnt "$DISK"); [ -n "$M" ] || M=$(mnt_of "$DISK"); [ -n "$M" ] && [ -d "$M$LPATH" ] || fail 'Disco non collegato' 'Drive not connected'
[ -n "$(fsof "$M")" ] || fail 'Disco non collegato' 'Drive not connected'
[ -e "$M/.wf-disco" ] || : > "$M/.wf-disco" 2>/dev/null
L=$M$LPATH; B=$(cbase); STAMP=$(date +%Y%m%d-%H%M)
export RCLONE_CONFIG=$CONF RCLONE_CACHE_DIR=$X/rclone-cache
KN=0; BYT=0; NR=0; KD=0
while :; do
if [ -n "$ACCT" ]; then
cgo cw; r=$?
[ $r = 1 ] && cstop
[ $r = 2 ] && { w=$(cl_why "$WHY" 2>/dev/null); [ -n "$w" ] || w='Linea non disponibile|Line not available'; fail "${w%%|*}" "${w#*|}"; }
cw run "$BYT"
else
rcl "wf$ID" 1 || cstop
fi
if [ -f $CDIR/$ID.keepnext ] && [ $KD = 0 ]; then
KD=1
o=$(rclone lsf --dirs-only "${B}old" </dev/null 2>/dev/null); rc=$?
{ [ $rc = 0 ] || [ $rc = 3 ]; } && KN=1
K=$({ printf '%s\n' "$o" | tr -d '/'; echo "$STAMP"; cat $CDIR/$ID.keep 2>/dev/null; } | grep -E '^[0-9]{8}-[0-9]{4}$' | sort | tail -n 1)
echo "$K" > $CDIR/$ID.keep.t && mv $CDIR/$ID.keep.t $CDIR/$ID.keep
fi
if [ -z "$(ls -A "$L" 2>/dev/null | grep -v '^\.wf-')" ] && [ -n "$(rclone lsf --max-depth 1 "${B}current" </dev/null 2>/dev/null | head -n 1)" ]; then
fail 'Cartella da copiare vuota: copia fermata' 'Folder to copy is empty: copy stopped'
fi
crun cprog sync "$L" "${B}current" --backup-dir "${B}old/$STAMP" $(trk) --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart'
rc=$?
set -- $(cbytes)
BY=${1:-0}; NN=${2:-0}; BYT=$((BYT + BY))
[ -n "$ACCT" ] && [ "$BY" -gt 0 ] && cl_add "$BY" >/dev/null 2>&1
{ [ $rc = 254 ] || cstopped; } && cstop
if [ -n "$ACCT" ] && { [ $rc = 253 ] || [ $rc = 8 ]; }; then
WHY=$LWHY; [ $rc = 8 ] && WHY=cap
cslput; rcu; NR=$((NR + 1))
[ $NR -ge 50 ] && fail 'Linea non disponibile' 'Line not available'
cw wait "$BYT"; continue
fi
break
done
BY=$BYT
if [ "$rc" != 0 ]; then
if grep -qi 'token\|unauthor\|invalid_grant\|401' "$LOG" 2>/dev/null; then fail 'Collega di nuovo l'"'"'account' 'Connect the account again'
elif grep -qi 'quota\|storage.*full\|insufficient' "$LOG" 2>/dev/null; then fail 'Spazio del cloud finito' 'Cloud storage full'
elif grep -qi 'no such host\|dial tcp\|timeout\|network' "$LOG" 2>/dev/null; then fail 'Internet non raggiungibile' 'Internet not reachable'
else fail 'Non riuscito' 'Failed'; fi
fi
[ -f $X/once.cloud-$ID ] && { rm -f $X/once.cloud-$ID; ev nas_cloudbk_ok "🗄️ Backup Cloud ¦ $(t 'Di nuovo riuscito' 'Working again') ¦ $(short "$NAME")"; }
[ "$KN" = 1 ] && rm -f $CDIR/$ID.keepnext
CDONE=1; cw ok "$BY" "$BY" "$NN" "$NN" 0; clast 1 "$BY" "$NN"; cday; cvers; cinfo_put; cabout "$RA"
}
pccloud() {
ID=$1; F=$CDIR/$ID.sh
echo "$ID" | grep -qE '^c[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
ON=0; WARN=1; OWN=; RSEC=; DISK=; LPATH=; REM=
. "$F"
[ "$ON" = 1 ] || exit 0
pstop "$OWN" && exit 0
cinfo; cline; CBW=
[ -n "$ACCT" ] || exit 0
CONF=$CCONF; RA=$RSEC; echo "$RA" | grep -qE '^wfa[0-9]{1,3}[a-z0-9]*$' || RA=wfa${ACCT#a}
mkdir $X/cloud-$ID.lock 2>/dev/null || { alive "$(cat $X/cloud-$ID.lock/pid 2>/dev/null)" && exit 0; rm -rf $X/cloud-$ID.lock; mkdir $X/cloud-$ID.lock || exit 0; }
echo $$ > $X/cloud-$ID.lock/pid; rm -f $X/cloud-$ID.stop $CT/jobs/nbk-$ID.stop
P=$X/cloud-$ID.json; LOG=$X/cloud-$ID.log; T0=$(date +%s); CP=; RL=; CJOB=; CDONE=0; WHY=
trap 'rm -rf $X/cloud-$ID.lock; cslput; rcu; [ "$CDONE" = 1 ] && bk bkown' EXIT
cw run
pcfail() { CDONE=1; cw err 0 0 0 0 0 "$1" "$2"; clast 0 0 0
[ "$WARN" != 0 ] && once cloud-$ID 21600 && ev nas_cloudbk_err "⚠️ Backup Cloud ¦ $(t "$1" "$2") ¦ $(short "$NAME")"; exit 0; }
pcstop() { rm -f $X/cloud-$ID.stop $CT/jobs/nbk-$ID.stop; cw stop; exit 0; }
command -v rclone >/dev/null 2>&1 || pcfail 'Manca rclone' 'rclone missing'
grep -q "^\[wfa${ACCT#a}\]" $CONF 2>/dev/null || pcfail 'Account da ricollegare' 'Account needs reconnecting'
grep -q "^\[$RA\]" $CONF 2>/dev/null || pcfail 'Cartella del cloud non ancora pronta: riprova fra poco' 'Cloud folder not ready yet: try again shortly'
[ "$(ucode -e "let M = loadfile('$V')(); print(M.pcqf('$OWN', '$ACCT') ? 1 : 0);" </dev/null 2>/dev/null)" = 1 ] && pcfail 'Spazio Cloud finito: libera spazio o chiedi più spazio' 'Cloud space full: free some space or ask for more'
M=$(cmnt "$DISK"); [ -n "$M" ] || M=$(mnt_of "$DISK"); [ -n "$M" ] && [ -d "$M$LPATH" ] || pcfail 'Disco non collegato' 'Drive not connected'
[ -n "$(fsof "$M")" ] || pcfail 'Disco non collegato' 'Drive not connected'
L=$M$LPATH
[ -n "$(ls -A "$L" 2>/dev/null | grep -v '^\.wf-')" ] || pcfail 'Cartella del disco vuota' 'Drive folder empty'
export RCLONE_CONFIG=$CONF RCLONE_CACHE_DIR=$X/rclone-cache
BYT=0; NR=0
while :; do
cgo cw; r=$?
[ $r = 1 ] && pcstop
[ $r = 2 ] && { w=$(cl_why "$WHY" 2>/dev/null); [ -n "$w" ] || w='Linea non disponibile|Line not available'; pcfail "${w%%|*}" "${w#*|}"; }
cw run "$BYT"
crun cprog copy "$L" "$RA:${REM#/}" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart'
rc=$?
set -- $(cbytes)
BY=${1:-0}; NN=${2:-0}; BYT=$((BYT + BY))
[ "$BY" -gt 0 ] && cl_add "$BY" >/dev/null 2>&1
{ [ $rc = 254 ] || cstopped; } && pcstop
if [ $rc = 253 ] || [ $rc = 8 ]; then
WHY=$LWHY; [ $rc = 8 ] && WHY=cap
cslput; NR=$((NR + 1))
[ $NR -ge 50 ] && pcfail 'Linea non disponibile' 'Line not available'
cw wait "$BYT"; continue
fi
break
done
if [ "$rc" != 0 ]; then
if grep -qi 'token\|unauthor\|invalid_grant\|401' "$LOG" 2>/dev/null; then pcfail 'Collega di nuovo l'"'"'account' 'Connect the account again'
elif grep -qi 'quota\|storage.*full\|insufficient' "$LOG" 2>/dev/null; then pcfail 'Spazio del cloud finito' 'Cloud storage full'
elif grep -qi 'no such host\|dial tcp\|timeout\|network' "$LOG" 2>/dev/null; then pcfail 'Internet non raggiungibile' 'Internet not reachable'
else pcfail 'Non riuscito' 'Failed'; fi
fi
[ -f $X/once.cloud-$ID ] && { rm -f $X/once.cloud-$ID; ev nas_cloudbk_ok "🗄️ Backup Cloud ¦ $(t 'Di nuovo riuscito' 'Working again') ¦ $(short "$NAME")"; }
CDONE=1; cw ok "$BYT" "$BYT" "$NN" "$NN" 0; clast 1 "$BYT" "$NN"; cabout "wfa${ACCT#a}"
}
pold() { ls -1 "$L/old" 2>/dev/null | grep -E '^[0-9]{8}-[0-9]{4}$' | sort; }
pres() { df -kP "$1" 2>/dev/null | awk 'NR == 2 { r = $2 * 1024 * 0.05; if (r < 1073741824) r = 1073741824; printf "%.0f", r }'; }
pspace() {
while :; do
f_=$(freeb "$L"); [ -n "$f_" ] || return 0
[ "$f_" -ge "${WF_PRES:-$RES}" ] 2>/dev/null && return 0
v_=$(pold | grep -v "^$STAMP\$" | head -n 1); [ -n "$v_" ] || return 1
rm -rf "${L:?}/old/$v_"
done
}
pprog() {
cprog; PN=$((PN + 1)); [ $((PN % 5)) = 0 ] || return 0
pspace || { SPF=1; kill -TERM "$CP" 2>/dev/null; }
true
}
ptrim() {
NP=0; k_=$(date -d "@$(( $(date +%s) - ${1:-$KEEP} * 86400 ))" +%Y%m%d%H%M 2>/dev/null) || return 0
for v_ in $(pold); do [ "${v_%-*}${v_#*-}" -lt "$k_" ] && { rm -rf "${L:?}/old/$v_"; NP=$((NP + 1)); }; done
true
}
pload() {
ID=$1; F=$CDIR/$ID.sh
echo "$ID" | grep -qE '^p[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
ON=0; WARN=1; OWN=; ACCT=; RSEC=; REM=/; DISK=; LPATH=; KEEP=30; NETJ='{"mode":"same"}'
. "$F"
echo "$ACCT" | grep -qE '^a[0-9]{1,3}$' || exit 1
CONF=$CCONF; RA=$RSEC; echo "$RA" | grep -qE '^wfa[0-9]{1,3}[a-z0-9]*$' || RA=wfa${ACCT#a}
SRC_=$RA:${REM#/}
export RCLONE_CONFIG=$CONF RCLONE_CACHE_DIR=$X/rclone-cache
}
pdisk() {
M=$(cmnt "$DISK"); [ -n "$M" ] || M=$(mnt_of "$DISK"); L=
[ -n "$M" ] && [ -n "$(fsof "$M")" ] || return 1
L=$M$LPATH
}
cpull() {
pload "$1"
[ "$ON" = 1 ] || exit 0
pstop "$OWN" && exit 0
cline; CBW=
mkdir $X/cloud-$ID.lock 2>/dev/null || { alive "$(cat $X/cloud-$ID.lock/pid 2>/dev/null)" && exit 0; rm -rf $X/cloud-$ID.lock; mkdir $X/cloud-$ID.lock || exit 0; }
echo $$ > $X/cloud-$ID.lock/pid; rm -f $X/cloud-$ID.stop $CT/jobs/nbk-$ID.stop
P=$X/cloud-$ID.json; LOG=$X/cloud-$ID.log; T0=$(date +%s); CP=; RL=; CJOB=; CDONE=0; WHY=
trap 'rm -rf $X/cloud-$ID.lock; cslput; rcu; [ -f "$F" ] || rm -f $X/cloud-$ID.* $CDIR/$ID.* $CT/jobs/nbk-$ID.json; [ "$CDONE" = 1 ] && bk bkown' EXIT
cw run
plfail() { CDONE=1; cw err 0 0 0 0 0 "$1" "$2"; clast 0 0 0
[ "$WARN" != 0 ] && once cloud-$ID 21600 && ev nas_cloudbk_err "⚠️ $(t 'Backup Del Cloud' 'Cloud Backup To Drive') ¦ $(t "$1" "$2") ¦ $(short "$NAME")"; exit 0; }
plstop() { rm -f $X/cloud-$ID.stop $CT/jobs/nbk-$ID.stop; cw stop; exit 0; }
command -v rclone >/dev/null 2>&1 || plfail 'Manca rclone' 'rclone missing'
grep -q "^\[wfa${ACCT#a}\]" $CONF 2>/dev/null || plfail 'Account da ricollegare' 'Account needs reconnecting'
grep -q "^\[$RA\]" $CONF 2>/dev/null || plfail 'Cartella del cloud non ancora pronta: riprova fra poco' 'Cloud folder not ready yet: try again shortly'
m_=$(awk '/^MemAvailable:/ { print int($2 / 1024) }' /proc/meminfo 2>/dev/null)
[ -n "$m_" ] && [ "$m_" -lt "${WF_PMEM:-16}" ] && plfail 'Memoria insufficiente: riprova più tardi' 'Not enough memory: try again later'
pdisk || plfail 'Disco non collegato' 'Drive not connected'
[ "$(ro_of "$DISK")" = 1 ] && plfail 'Disco in sola lettura' 'Drive is read-only'
[ -e "$M/.wf-disco" ] || : > "$M/.wf-disco" 2>/dev/null
STAMP=$(date +%Y%m%d-%H%M)
mkdir -p "$L/current" "$L/old" 2>/dev/null || plfail 'Cartella del disco non scritta' 'Drive folder not written'
RES=$(pres "$L"); [ -n "$RES" ] || RES=1073741824
pspace || plfail 'Spazio del disco finito' 'Drive space full'
BYT=0; NR=0; PN=0; SPF=0
while :; do
cgo cw; r=$?
[ $r = 1 ] && plstop
[ $r = 2 ] && { w=$(cl_why "$WHY" 2>/dev/null); [ -n "$w" ] || w='Linea non disponibile|Line not available'; plfail "${w%%|*}" "${w#*|}"; }
cw run "$BYT"
o_=$(rclone lsf --max-depth 1 "$SRC_" --exclude '.wf-*/**' --exclude '.wf-*' </dev/null 2>/dev/null) && [ -z "$o_" ] && [ -n "$(ls -A "$L/current" 2>/dev/null)" ] &&
plfail 'Cartella del cloud vuota: copia fermata' 'Cloud folder empty: copy stopped'
crun pprog sync "$SRC_" "$L/current" --backup-dir "$L/old/$STAMP" $(trk) --exclude-from "$CDIR/$ID.excl" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart'
rc=$?
set -- $(cbytes)
BY=${1:-0}; NN=${2:-0}; BYT=$((BYT + BY))
[ "$BY" -gt 0 ] && cl_add "$BY" >/dev/null 2>&1
[ "$SPF" = 1 ] && plfail 'Spazio del disco finito' 'Drive space full'
{ [ $rc = 254 ] || cstopped; } && plstop
if [ $rc = 253 ] || [ $rc = 8 ]; then
WHY=$LWHY; [ $rc = 8 ] && WHY=cap
cslput; rcu; NR=$((NR + 1))
[ $NR -ge 50 ] && plfail 'Linea non disponibile' 'Line not available'
cw wait "$BYT"; continue
fi
break
done
if [ "$rc" != 0 ]; then
case "$(ctr "$LOG")" in
relink) plfail 'Collega di nuovo l'"'"'account' 'Connect the account again' ;;
net) plfail 'Internet non raggiungibile' 'Internet not reachable' ;;
path) plfail 'Cartella del cloud non trovata' 'Cloud folder not found' ;;
*) grep -qi 'no space left' "$LOG" 2>/dev/null && plfail 'Spazio del disco finito' 'Drive space full'; plfail 'Non riuscito' 'Failed' ;;
esac
fi
[ -f $X/once.cloud-$ID ] && { rm -f $X/once.cloud-$ID; ev nas_cloudbk_ok "🗄️ $(t 'Backup Del Cloud' 'Cloud Backup To Drive') ¦ $(t 'Di nuovo riuscito' 'Working again') ¦ $(short "$NAME")"; }
ptrim
CDONE=1; cw ok "$BYT" "$BYT" "$NN" "$NN" 0; clast 1 "$BYT" "$NN"; cabout "wfa${ACCT#a}"
}
cpullfree() {
pload "$1"; JOB=$3; OP=free; J=$TMP/jobs/$JOB.json
echo "$JOB" | grep -qE '^bak-f[0-9a-z]{1,16}$' || exit 1
DAYS=$(printf '%s' "$2" | tr -cd '0-9'); jw run 0 0
[ -n "$DAYS" ] && [ "$DAYS" -ge 1 ] && [ "$DAYS" -le 3650 ] && pdisk || { jw err 0 0; exit 0; }
STAMP=; ptrim "$DAYS"; JX="\"removed\":$NP"; jw ok 0 0
}
pjw() { WAIT=false; [ "$1" = wait ] && WAIT=true; jw run "$n" "$TOT"; WAIT=false; }
cpullput() {
JOB=$1; echo "$JOB" | grep -qE '^bak-r[0-9a-z]{1,16}$' || exit 1
pload "$2"; J=$TMP/jobs/$JOB.json; LST=$TMP/jobs/$JOB.list; OP=restore; [ -f "$LST" ] || exit 1
cline; CBW=; CJN=nbk-$ID-r; RL=; CJOB=
trap 'rm -f "$LST"; cslput; rcu' EXIT
TB=$(printf '\t'); TOT=$(grep -c . "$LST"); n=0; bad=0; jw run 0 "$TOT"
cgo pjw; r=$?
[ $r = 1 ] && { rm -f "${J%.json}.stop"; jw stop 0 "$TOT"; exit 0; }
[ $r = 2 ] && { ERR=$(t 'Linea non disponibile' 'Line not available'); ERR_EN='Line not available'; jw err 0 "$TOT"; exit 0; }
while IFS="$TB" read -r s d; do
[ -n "$s" ] || continue
cstopped && { rm -f "${J%.json}.stop"; jw stop $n "$TOT"; exit 0; }
case "$SRC_" in *:) d=${d#/} ;; esac
if [ -d "$s" ]; then rclone copy "$s" "$SRC_$d" --ignore-existing $CBW --exclude '.wf-*' </dev/null >/dev/null 2>&1 || bad=$((bad + 1))
else rclone copyto "$s" "$SRC_$d" --ignore-existing $CBW </dev/null >/dev/null 2>&1 || bad=$((bad + 1)); fi
n=$((n + 1)); jw run $n "$TOT"
done < "$LST"
if [ $bad -gt 0 ]; then jw err $n "$TOT"; ev nas_backup_err "⚠️ $(t 'Ripristino' 'Restore') ¦ $bad $(t 'non ripristinati nel cloud' 'not restored to the cloud') ¦ $(short "$NAME")"
else jw ok $n "$TOT"; ev nas_backup_ok "💾 $(t 'Ripristino' 'Restore') ¦ $(t 'Rimesso nel cloud' 'Put back in the cloud') ¦ $(short "$NAME")"; fi
}
cfull() {
f=$X/cloud-$ID.full; [ -f "$f" ] || cp $CDIR/$ID.full "$f" 2>/dev/null
{ cat "$f" 2>/dev/null; [ -n "$1" ] && echo "$1"; } | grep -E '^[0-9]{8}-[0-9]{4}$' | sort -u > "$f.t"
[ -z "$1" ] && [ -f $CDIR/$ID.vers ] && awk 'NR == FNR { v[$0] = 1; next } v[$0]' $CDIR/$ID.vers "$f.t" > "$f.u" && mv "$f.u" "$f.t"
if cmp -s "$f.t" "$f"; then rm -f "$f.t"; else mv "$f.t" "$f"; fi
cmp -s "$f" $CDIR/$ID.full && return 0
[ $(( $(date +%s) - $(date -r $CDIR/$ID.full +%s 2>/dev/null || echo 0) )) -ge 86400 ] || return 0
mkdir -p $CDIR && cp "$f" $CDIR/$ID.full.t && mv $CDIR/$ID.full.t $CDIR/$ID.full
}
cday() {
rm -f $X/cloud-$ID.lok
{ rclone lsf -R --files-only "$L" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart' </dev/null 2>/dev/null &&
echo .wf-end && : > $X/cloud-$ID.lok; } | gzip -c |
rclone rcat "${B}old/$STAMP/.wf-list.gz" >/dev/null 2>&1 || { rm -f $X/cloud-$ID.lok; return 0; }
[ -f $X/cloud-$ID.lok ] || return 0
rm -f $X/cloud-$ID.lok; cfull "$STAMP"
}
cvers() {
o=$(rclone lsf --dirs-only "${B}old" 2>/dev/null) || return 0
mkdir -p $CDIR
printf '%s\n' "$o" | tr -d '/' | grep -E '^[0-9]{8}-[0-9]{4}$' | sort > $CDIR/$ID.vers.t
if cmp -s $CDIR/$ID.vers.t $CDIR/$ID.vers; then rm -f $CDIR/$ID.vers.t; else mv $CDIR/$ID.vers.t $CDIR/$ID.vers; fi
{ [ -f $X/cloud-$ID.full ] || [ -f $CDIR/$ID.full ]; } && cfull
true
}
mv1() { # <file scaricato> <arrivo>
inroot "${2%/*}" && mkdir -p "${2%/*}" && inroot "${2%/*}" || return 1
if [ ! -e "$2" ] && [ ! -L "$2" ]; then mv "$1" "$2"
elif [ ! -L "$2" ] && cmp -s "$1" "$2"; then rm -f "$1"
else mv "$1" "$(freename "$2")"; fi
}
rrun() {
o=$1; shift
rclone "$@" </dev/null >"$o" 2>/dev/null & CP=$!
SRC=$DISK; spd "$DISK" "$CP"
while alive $CP; do [ -f "$STOP" ] && kill $CP 2>/dev/null; sleep 1; done
wait $CP
}
rget() { rrun /dev/null "$@"; }
pieces() { rm -f "$2".[0-9]*; P=$2 N=${WF_PIECE:-50000} awk 'BEGIN { p = ENVIRON["P"]; n = ENVIRON["N"] + 0 } (NR - 1) % n == 0 { if (f != "") close(f); f = p "." sprintf("%05d", int((NR - 1) / n)) } { print > f }' "$1"; }
dayget() {
DV=${1%%/*}; RP=${1#"$DV"}; WD=$SG/d$i; k=0
mkdir -p "$WD" || return 1
rrun "$WD/m.gz" cat "${B}old/$DV/.wf-list.gz" || return 1
[ -f "$STOP" ] && return 0
gunzip -c "$WD/m.gz" > "$WD/m" 2>/dev/null || return 1
rm -f "$WD/m.gz"
[ "$(tail -n 1 "$WD/m")" = .wf-end ] || return 1
RP=$RP awk 'BEGIN { r = substr(ENVIRON["RP"], 2) } $0 == ".wf-end" { next } r == "" || $0 == r || index($0, r "/") == 1' "$WD/m" > "$WD/w"
rm -f "$WD/m"; : > "$WD/src"
[ -s "$WD/w" ] || return 1
n0=$(echo "$DV" | tr -d -)
rrun "$WD/v" lsf --dirs-only "${B}old" || return 1
for v in $(tr -d '/' < "$WD/v" | grep -E '^[0-9]{8}-[0-9]{4}$' | sort); do
[ -f "$STOP" ] && return 0
[ -s "$WD/w" ] || break
[ "$(echo "$v" | tr -d -)" -gt "$n0" ] || continue
rrun "$WD/o" lsf -R --files-only "${B}old/$v" || return 1
[ -s "$WD/o" ] || continue
k=$((k + 1)); : > "$WD/f$k"; : > "$WD/w2"; pieces "$WD/w" "$WD/p"
for p in "$WD/p".[0-9]*; do
F=$WD/f$k R=$WD/w2 awk 'BEGIN { f = ENVIRON["F"]; r = ENVIRON["R"] } NR == FNR { h[$0] = 1; next } ($0 in h) { print >> f; delete h[$0] } END { for (x in h) print x >> r }' "$p" "$WD/o"
done
rm -f "$WD/p".[0-9]*; mv "$WD/w2" "$WD/w"
[ -s "$WD/f$k" ] && printf 'old/%s\t%s\n' "$v" "$k" >> "$WD/src"
done
[ -s "$WD/w" ] && { k=$((k + 1)); mv "$WD/w" "$WD/f$k"; printf 'current\t%s\n' "$k" >> "$WD/src"; }
rm -f "$WD/w" "$WD/o" "$WD/v"
while IFS="$TB" read -r s k; do
pieces "$WD/f$k" "$WD/q"
for p in "$WD/q".[0-9]*; do
rget copy "$B$s" "$WD/$k" --files-from-raw "$p" --no-traverse
[ -f "$STOP" ] && return 0
done
rm -f "$WD/q".[0-9]*
RP=$RP D=$2 S=$WD/$k/ awk 'BEGIN { r = ENVIRON["RP"]; d = ENVIRON["D"]; s = ENVIRON["S"] } { printf "%s%s\t%s%s\n", s, $0, d, substr("/" $0, length(r) + 1) }' "$WD/f$k" >> "$W2"
done < "$WD/src"
}
cloudrestore() {
JOB=$1; ID=$2; F=$CDIR/$ID.sh
echo "$JOB" | grep -qE '^bak-r[0-9a-z]{1,16}$' && echo "$ID" | grep -qE '^k[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
J=$TMP/jobs/$JOB.json; LST=$TMP/jobs/$JOB.list; [ -f "$LST" ] || exit 1
CRYPT=0; REM=
. "$F"
cinfo
NAME=$(js "$J" 'print(N.name ?? "");'); OP=restore; W2=$TMP/jobs/$JOB.files; STOP=$TMP/jobs/$JOB.stop
M=$(cmnt "$DISK"); [ -n "$M" ] || M=$(mnt_of "$DISK")
ROOT=$(js "$J" 'print(N.root ?? "");'); [ -n "$ROOT" ] || ROOT=$(readlink -f "$M" 2>/dev/null)
SG=$M/.wf-r-$JOB; BT=; RL=
trap 'rm -rf "$LST" "$W2" "$SG"; [ -n "$BT" ] && kill $BT 2>/dev/null; rcu' EXIT
jw run 0 0; beat
if [ -z "$M" ] || ! command -v rclone >/dev/null 2>&1; then jw err 0 0; exit 0; fi
export RCLONE_CONFIG=$CONF RCLONE_CACHE_DIR=$X/rclone-cache
w0=$(date +%s)
until rcl "wf$ID"; do
[ -f "$STOP" ] && { rm -f "$STOP"; WAIT=; jw stop 0 0; exit 0; }
if [ $(( $(date +%s) - w0 )) -ge "${WF_RCWAIT:-1800}" ]; then
WAIT=; ERR="Account occupato da un'altra copia: riprova più tardi"; ERR_EN='Account busy with another copy: try again later'
jw err 0 0; exit 0
fi
[ -n "$WAIT" ] || { WAIT=true; jw run 0 0; }
sleep 2
done
[ -n "$WAIT" ] && { WAIT=; jw run 0 0; }
B=$(cbase); TB=$(printf '\t'); i=0; bad=0; : > "$W2"
while IFS="$TB" read -r s d; do
[ -n "$s" ] || continue
i=$((i + 1))
case "$s" in
day/*) dayget "${s#day/}" "$d" || bad=$((bad + 1)) ;;
*) rget copyto "$B$s" "$SG/$i" || bad=$((bad + 1)) ;;
esac
[ -f "$STOP" ] && { rm -f "$STOP"; jw stop 0 0; exit 0; }
if [ -d "$SG/$i" ]; then find "$SG/$i" -type f | while IFS= read -r f; do printf '%s\t%s\n' "$f" "$d${f#"$SG/$i"}"; done >> "$W2"
elif [ -f "$SG/$i" ]; then printf '%s\t%s\n' "$SG/$i" "$d" >> "$W2"; fi
done < "$LST"
TOT=$(grep -c . "$W2"); n=0; jw run 0 "$TOT"
while IFS="$TB" read -r s d; do
[ -f "$STOP" ] && { rm -f "$STOP"; jw stop $n "$TOT"; exit 0; }
mv1 "$s" "$d" || bad=$((bad + 1))
n=$((n + 1)); [ $((n % 20)) = 0 ] && jw run $n "$TOT"
done < "$W2"
if [ $bad -gt 0 ]; then jw err $n "$TOT"; ev nas_backup_err "⚠️ $(t 'Ripristino' 'Restore') ¦ $bad $(t 'file non ripristinati' 'files not restored') ¦ $(short "$NAME")"
else jw ok $n "$TOT"; ev nas_backup_ok "💾 $(t 'Ripristino' 'Restore') ¦ $(t 'Finito' 'Finished') ¦ $(short "$NAME") · $n file"; fi
}
cloudstop() {
echo "$1" | grep -qE '^[kp][0-9a-z]{1,16}$' || return 0
alive "$(cat $X/cloud-$1.lock/pid 2>/dev/null)" || return 0
: > $X/cloud-$1.stop; p=$(cat $X/cloud-$1.lock/rpid 2>/dev/null); alive "$p" && kill "$p" 2>/dev/null; true
}
cryptset() {
ID=$1; F=$CDIR/$ID.sh; PF=$X/.pw-$ID
echo "$ID" | grep -qE '^k[0-9a-z]{1,16}$' && [ -f "$F" ] || { rm -f "$PF"; exit 1; }
ADOPT=0
. "$F"
cinfo
if [ "$ADOPT" = 1 ] && [ -f "$PF" ]; then
alive "$(sed -n 's/.*"pid":\([0-9]*\).*/\1/p' $X/cloud-$ID.adopt.json 2>/dev/null)" && exit 0
exec sh "$0" adopt "$ID"
fi
if [ -f "$PF" ]; then
command -v rclone >/dev/null 2>&1 || exit 0	# il giro dopo riprova (il file resta in /tmp, solo root)
csec "$PF" "$KEY2"; r=$?
[ $r = 2 ] && exit 0
[ $r = 3 ] && { rm -f "$PF"; exit 1; }
[ $r = 0 ] || exit 1
else
OB=$(cpw password); O2=$(cpw password2)
[ -n "$OB" ] || exit 1
cput || exit 1
fi
rm -f "$PF"
}
knorm() {
k=$(cat); u=$(printf '%s' "$k" | tr -d ' -' | tr 'a-z' 'A-Z')
if printf '%s' "$k" | grep -q -- '-' && printf '%s' "$u" | grep -qE '^[A-Z0-9]{24}$'; then printf '%s' "$u" | sed 's/\(....\)/\1-/g; s/-$//'
else printf '%s' "$k"; fi
k=; u=
}
cpw() { awk -v s="[wf${ID}x]" -v c="$1" '/^\[.*\][ \t]*$/ { k = ($0 == s); next } k { n = $0; sub(/[ \t]*=.*$/, "", n); if (n == c) { sub(/^[^=]*=[ \t]*/, ""); print; exit } }' $CONF 2>/dev/null; }
csec() {
KY=$(knorm < "$1")
OB=$(printf '%s' "$KY" | rclone obscure - 2>/dev/null) || { KY=; return 2; }
O2=; [ "$2" = 1 ] && { O2=$(printf 'wf2%s' "$KY" | sha256sum | cut -c1-64 | rclone obscure - 2>/dev/null) || { KY=; return 2; }; }
KY=
[ -n "$OB" ] || return 3
cput
}
cput() {
{ printf '{"type":"crypt","remote":"%s:%s","password":"%s",' "$RA" "$(jesc "${REM#/}")" "$OB"
[ -n "$O2" ] && printf '"password2":"%s",' "$O2"
printf '"filename_encryption":"standard","directory_name_encryption":"true"}'; } | rcput "wf${ID}x"; r=$?
OB=; O2=; return $r
}
cloudold() {
command -v rclone >/dev/null 2>&1 || return 0
for F in $CDIR/k*.sh; do
[ -f "$F" ] || continue
ID=$(basename "$F" .sh); CRYPT=0; REM=; REMV=0
. "$F"
cinfo; export RCLONE_CONFIG=$CONF
[ "$REMV" = 2 ] || continue
[ "$CRYPT" = 1 ] && [ "$(crem)" != "$RA:${REM#/}" ] && continue
B=$(cbase)
rcl "$RA" || continue
[ -f $CDIR/$ID.keepnext ] && { cvers; rcu; continue; }
cpurge "$KEEPD"
cvers; rcu
done; true
}
cpurge() {
NP=0; CUT=$(date -d @$(( $(date +%s) - $1 * 86400 )) +%Y%m%d-%H%M 2>/dev/null); [ -n "$CUT" ] || return 1
K=$(cat $CDIR/$ID.keep 2>/dev/null | tr -d '\n-'); echo "$K" | grep -qE '^[0-9]{12}$' || K=0
for v in $(rclone lsf --dirs-only "${B}old" 2>/dev/null | tr -d '/' | grep -E '^[0-9]{8}-[0-9]{4}$'); do
n=$(echo "$v" | tr -d -)
[ "$n" -le "$K" ] && continue
[ "$n" -lt "$(echo "$CUT" | tr -d -)" ] && rclone purge "${B}old/$v" >/dev/null 2>&1 && NP=$((NP + 1))
done; true
}
cjob() {
ID=$1; JOB=$2; F=$CDIR/$ID.sh; J=; RL=; CJOB=; CBW=
echo "$ID" | grep -qE '^k[0-9a-z]{1,16}$' && [ -f "$F" ] || exit 1
[ -z "$JOB" ] || echo "$JOB" | grep -qE '^bak-[0-9a-z-]{1,40}$' || exit 1
CRYPT=0; REM=; REMV=0; DISK=; LPATH=; ADOPT=0
. "$F"
cinfo; cline
[ -n "$JOB" ] && { mkdir -p $TMP/jobs; J=$TMP/jobs/$JOB.json; }
LOG=$X/cloud-$ID.$OP.log; T0=$(date +%s)
export RCLONE_CONFIG=$CONF RCLONE_CACHE_DIR=$X/rclone-cache
}
trk() {
b_=$(command -v rclone); k_="$(date -r "$b_" +%s 2>/dev/null) $(wc -c < "$b_" 2>/dev/null)"
[ "$(sed -n 1p $X/rclone.trk 2>/dev/null)" = "$k_" ] || { v_=$(rclone version 2>/dev/null </dev/null | sed -n '1s/^rclone v\([0-9]*\)\.\([0-9]*\).*/\1 \2/p')
o_=; set -- $v_; [ -n "$2" ] && { [ "$1" -gt 1 ] || [ "$2" -ge 53 ]; } && o_='--track-renames --track-renames-strategy modtime,leaf'
printf '%s\n%s\n' "$k_" "$o_" > $X/rclone.trk.t && mv $X/rclone.trk.t $X/rclone.trk; }
sed -n 2p $X/rclone.trk 2>/dev/null
}
cend() {
ERR=; ERR_EN=; [ "$1" = err ] && { cmsg "${2:-fail}"; ERR=$CM; ERR_EN=$CME; JX="$JX${JX:+,}\"code\":\"${2:-fail}\""; }
jw "$1" 0 0; rm -f "$LOG"; [ -n "$J" ] && rm -f "${J%.json}.stop"
cslput; rcu; true
}
cwaitl() {
w0=$(date +%s)
until rcl "$RA"; do
cstopped && return 1
[ $(( $(date +%s) - w0 )) -ge "${WF_RCWAIT:-1800}" ] && return 1
[ -n "$WAIT" ] || { WAIT=true; jw run 0 0; }
sleep 2
done
[ -n "$WAIT" ] && { WAIT=; jw run 0 0; }; true
}
free_() {
OP=free; cjob "$1" "$3"; DAYS=$(printf '%s' "$2" | tr -cd '0-9')
trap 'rm -f "$LOG"; cslput; rcu' EXIT
jw run 0 0
[ -n "$DAYS" ] && [ "$DAYS" -ge 1 ] && [ "$DAYS" -le 3650 ] || { cend err fail; exit 0; }
command -v rclone >/dev/null 2>&1 || { cend err fail; exit 0; }
[ "$REMV" = 2 ] || { cend err fail; exit 0; }
[ "$CRYPT" = 1 ] && [ "$(crem)" != "$RA:${REM#/}" ] && { cend err fail; exit 0; }
cwaitl || { if cstopped; then cend stop; else cend err busy; fi; exit 0; }
B=$(cbase)
[ -f $CDIR/$ID.keepnext ] && { cend err never; exit 0; }
cpurge "$DAYS"; cvers
rm -f $X/cloud-$ID.about; cabout "$RA"
JX="\"removed\":$NP"; cend ok
}
aw() { printf '{"state":"%s","code":"%s","key2":%s,"pid":%s,"t":%s}\n' "$1" "$2" "${3:-false}" $$ "$(date +%s)" > $X/cloud-$ID.adopt.json.t && mv $X/cloud-$ID.adopt.json.t $X/cloud-$ID.adopt.json; }
adopt() {
OP=adopt; cjob "$1" "$2"; PA=$X/.pw-$ID; KPA=0
trap '[ "$KPA" = 1 ] || rm -f "$PA"; rm -f "$LOG"; cslput; rcu' EXIT
aw run; jw run 0 0
ko() { [ "$1" = key ] && stput keybad=true; aw err "$1"; cend err "$1"; exit 0; }
later() { KPA=1; rcdel "wf${ID}x"; ko "$1"; }
command -v rclone >/dev/null 2>&1 || later fail
[ -n "$ACCT" ] && grep -q "^\[$RA\]" $CONF 2>/dev/null || later relink
cwaitl || { if cstopped; then KPA=1; aw stop; cend stop; else later busy; fi; exit 0; }
K2=false
if [ "$CRYPT" = 1 ]; then
[ -s "$PA" ] || ko key
c=key
for k in 1 0; do
csec "$PA" $k; r=$?
[ $r = 0 ] || { [ $r = 3 ] && ko key; later fail; }
: > "$LOG"
if rclone lsf --crypt-strict-names --max-depth 1 "wf${ID}x:current" --log-file "$LOG" --log-level ERROR </dev/null >/dev/null 2>>"$LOG"; then
c=; [ $k = 1 ] && K2=true; break
fi
c=$(ctr "$LOG"); case "$c" in relink|net|space) break ;; esac
c=key
done
case "$c" in '') ;; key) rcdel "wf${ID}x"; ko key ;; *) later "$c" ;; esac
else
: > "$LOG"
rclone lsf --max-depth 1 "$RA:${REM#/}/current" --log-file "$LOG" --log-level ERROR </dev/null >/dev/null 2>>"$LOG" || ko "$(ctr "$LOG")"
fi
stput keybad=false key_t="$(date +%s)"
B=$(cbase); cvers; cabout "$RA"
aw ok "" "$K2"; JX="\"key2\":$K2"; cend ok
}
ddw() { f=$TMP/cloud-dry-$ID.json; printf '%s\n' "$1" > "$f.$$" && mv "$f.$$" "$f"; }
derr() { cmsg "$1"; ddw "{\"state\":\"err\",\"code\":\"$1\",\"error\":\"$(jesc "$CM")\",\"error_en\":\"$(jesc "$CME")\",\"t\":$(date +%s),\"pid\":$$}"; exit 0; }
clouddry() {
OP=dry; cjob "$1"
trap 'rm -f "$LOG" $X/cloud-$ID.dm $X/cloud-$ID.dd; rcu' EXIT
ddw "{\"state\":\"run\",\"t\":$(date +%s),\"pid\":$$}"
command -v rclone >/dev/null 2>&1 || derr fail
M=$(cmnt "$DISK"); [ -n "$M" ] || M=$(mnt_of "$DISK"); [ -n "$M" ] && [ -d "$M$LPATH" ] || derr path
L=$M$LPATH; set --
if cdone; then
[ -z "$ACCT" ] || grep -q "^\[$RA\]" $CONF 2>/dev/null || derr relink
cwaitl || derr busy
B=$(cbase); : > "$LOG"; : > $X/cloud-$ID.dm; : > $X/cloud-$ID.dd
rclone check "$L" "${B}current" --one-way --size-only --missing-on-dst $X/cloud-$ID.dm --differ $X/cloud-$ID.dd \
			--exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart' --log-file "$LOG" --log-level NOTICE </dev/null >/dev/null 2>&1
rc=$?; rcu
if [ $rc != 0 ] && ! grep -q 'differences found' "$LOG" 2>/dev/null; then
c=$(ctr "$LOG"); case "$c" in relink|net|space) derr "$c" ;; esac
fi
set -- $(cat $X/cloud-$ID.dm $X/cloud-$ID.dd | sort -u | while IFS= read -r p; do [ -f "$L/$p" ] && wc -c < "$L/$p"; done | awk '{ n++; b += $1 } END { printf "%d %.0f", n, b }')
else
set -- $(rclone size --json "$L" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart' </dev/null 2>/dev/null | ucode -e 'let s = {}; try { s = json(require("fs").stdin.read("all")); } catch (e) {} print(int(s?.count ?? 0), " ", int(s?.bytes ?? 0));' 2>/dev/null)
fi
ddw "{\"state\":\"ok\",\"files\":${1:-0},\"bytes\":${2:-0},\"t\":$(date +%s),\"pid\":$$}"
}
browse() {
RQ=$1; echo "$RQ" | grep -qE '^b[0-9a-z]{1,20}$' || exit 1
Q=$X/browse-$RQ.req; [ -f "$Q" ] || exit 1
BR=$X/browse-$RQ.json
berr() { cmsg "$1"; printf '{"error":"%s","error_en":"%s","code":"%s"}\n' "$(jesc "$CM")" "$(jesc "$CME")" "$1" > "$BR.$$" && mv "$BR.$$" "$BR"; rm -f "$Q"; exit 0; }
eval "$(XF=$Q ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {}
		function q(s) { return "\x27" + replace("" + s, "\x27", "") + "\x27"; }
		print("BI=", q(N.id ?? ""), "\nBS=", q(N.stamp ?? ""), "\nBP=", q(N.path ?? "/"), "\n");' </dev/null 2>/dev/null)"
echo "$BI" | grep -qE '^k[0-9a-z]{1,16}$' || berr fail
echo "$BS" | grep -qE '^(current|[0-9]{8}-[0-9]{4})$' || berr fail
case "/$BP/" in */../*|*/./*) berr path ;; esac
OP=browse; cjob "$BI"
trap 'rm -f "$LOG" "$Q"; rcu' EXIT
command -v rclone >/dev/null 2>&1 || berr fail
[ -z "$ACCT" ] || grep -q "^\[$RA\]" $CONF 2>/dev/null || berr relink
cwaitl || berr busy
B=$(cbase); V=current; [ "$BS" = current ] || V=old/$BS
BP=$(printf '%s' "$BP" | sed 's#^/*##; s#/*$##'); : > "$LOG"
o=$(rclone lsjson --max-depth 1 "$B$V${BP:+/$BP}" --log-file "$LOG" --log-level ERROR </dev/null 2>/dev/null) || berr "$(ctr "$LOG")"
printf '%s' "$o" | ucode -e '
let L = []; try { L = json(require("fs").stdin.read("all") ?? "[]"); } catch (e) {}
function dn(s) { let v = 0; for (let i = 0; i < length(s); i++) v = v * 10 + ord(s, i) - 48; return v; }
let out = [];
for (let x in (type(L) == "array" ? L : [])) {
	if (type(x?.Name) != "string" || substr(x.Name, 0, 4) == ".wf-" || match(x.Name, /\.wfpart$/)) continue;
	let m = match(x.ModTime ?? "", /^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})/), t = 0;
	if (m) t = timegm({ year: dn(m[1]), mon: dn(m[2]), mday: dn(m[3]), hour: dn(m[4]), min: dn(m[5]), sec: dn(m[6]) });
	push(out, { name: x.Name, dir: x.IsDir === true, size: x.IsDir ? 0 : int(x.Size ?? 0), mtime: t > 0 ? t : 0 });
	if (length(out) >= 2000) break;
}
printf("%J\n", { items: out });' > "$BR.$$" 2>/dev/null && mv "$BR.$$" "$BR" || berr fail
}
vw() {
[ "$1" = wait ] && JX="\"why\":\"$WHY\""
printf '{"do":"%s","state":"%s","why":"%s","bad":%s,"code":"%s","t":%s}\n' "$DO" "$1" "$([ "$1" = wait ] && printf '%s' "$WHY")" "${BAD:-0}" "$VC" "$(date +%s)" > $X/cloud-$ID.chk.json.t && mv $X/cloud-$ID.chk.json.t $X/cloud-$ID.chk.json
jw "$1" 0 0; JX=
}
cverify() {
OP=check; DO=$2; VC=; BAD=0; cjob "$1" "$3"; CJN=nbk-$ID-c
trap 'rm -f "$LOG"; cslput; rcu' EXIT
vend() { VC=$2; vw "$1"; JX="\"bad\":$BAD"; cend "$1" "$2"; exit 0; }
vw run
command -v rclone >/dev/null 2>&1 || vend err fail
[ "$REMV" = 2 ] || vend err fail
{ [ -z "$ACCT" ] || grep -q "^\[$RA\]" $CONF 2>/dev/null; } || vend err relink
cdone || vend err never
B=$(cbase)
[ "$AUTO" = 1 ] && [ "$(cl_tier)" = A ] && NETJ='{"mode":"fixed"}'
if [ "$DO" = key ]; then
[ "$CRYPT" = 1 ] || vend ok
[ "$(crem)" = "$RA:${REM#/}" ] || vend err fail
if [ "$AUTO" = 1 ]; then cl_check "nbk-$ID" "$NETJ" >/dev/null 2>&1 || vend stop; fi
cwaitl || { cstopped && vend stop; vend err busy; }
: > "$LOG"
if rclone lsf --crypt-strict-names --max-depth 1 "${B}current" --log-file "$LOG" --log-level ERROR </dev/null >/dev/null 2>>"$LOG"; then ok=1
else c=$(ctr "$LOG"); case "$c" in relink|net|space|busy) vend err "$c" ;; esac; ok=0; fi
if [ $ok = 1 ]; then stput keybad=false key_t="$(date +%s)"; else stput keybad=true key_t="$(date +%s)"; fi
if [ $ok = 0 ]; then
once keybad-$ID 21600 && evc cloud_key_bad "⚠️ Backup Cloud ¦ $(short "$NAME") ¦ $(t 'La chiave non apre la copia' 'Key does not open the copy')"
vend err key
fi
vend ok
fi
[ "$DO" = full ] || vend err fail
M=$(cmnt "$DISK"); [ -n "$M" ] || M=$(mnt_of "$DISK"); [ -n "$M" ] && [ -d "$M$LPATH" ] || vend err fail
L=$M$LPATH; SRC=$DISK
while :; do
cgo vw "$AUTO"; r=$?
[ $r = 1 ] && vend stop
[ $r = 2 ] && { [ "$AUTO" = 1 ] && vend stop; vend err net; }
vw run
if [ "$CRYPT" = 1 ]; then crun - cryptcheck "$L" "${B}current" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart'
else crun - check "$L" "${B}current" --exclude '.wf-*/**' --exclude '.wf-*' --exclude '.*.wfpart'; fi
rc=$?
{ [ $rc = 254 ] || cstopped; } && vend stop
[ $rc = 253 ] && { WHY=$LWHY; cslput; rcu; vw wait; continue; }
break
done
BAD=$(grep -o '[0-9][0-9]* differences found' "$LOG" 2>/dev/null | tail -n 1 | cut -d' ' -f1); BAD=${BAD:-0}
[ "$rc" = 0 ] || [ "$BAD" -gt 0 ] || vend err "$(ctr "$LOG")"
mkdir -p $CDIR; echo "$(date +%s) $BAD" > $CDIR/$ID.check.t && mv $CDIR/$ID.check.t $CDIR/$ID.check
[ "$BAD" -gt 0 ] && ev nas_cloudbk_err "⚠️ $(t 'Controllo Integrità' 'Integrity Check') ¦ $BAD $(t 'file da ricopiare' 'files to copy again') ¦ $(short "$NAME")"
vend ok
}
cverall() {
n=$(date +%s); d=$(date +%d)
for f in $CDIR/k*.sh; do
[ -f "$f" ] || continue
i=$(basename "$f" .sh); KIND=; CRYPT=0
. "$f"
[ "$KIND" = backup ] || continue
ID=$i; cdone || continue
kt=$(sed -n 's/.*"key_t": *\([0-9]*\).*/\1/p' $CDIR/$i.st 2>/dev/null)
[ "$CRYPT" = 1 ] && [ $((n - ${kt:-0})) -ge 15552000 ] && AUTO=1 sh "$0" verify "$i" key
cinfo; [ "$CHECKM" = 1 ] || continue
ct=$(cut -d' ' -f1 $CDIR/$i.check 2>/dev/null); a=$((n - ${ct:-0}))
{ { [ "$d" = 01 ] && [ $a -ge 172800 ]; } || [ $a -ge 3024000 ]; } && AUTO=1 sh "$0" verify "$i" full
done; true
}

phdirs() { ucode -e "let M = loadfile('$V')(); print(M.phwdirs());" </dev/null 2>/dev/null; }
phtops() { ucode -e "let M = loadfile('$V')(); print(M.phwtops());" </dev/null 2>/dev/null; }
PHI=/etc/init.d/wf-phwatch
phwsvc() {
[ -z "$R" ] && command -v inotifywait >/dev/null 2>&1 || return 1
if [ -f $X/phwatch.off ]; then
[ $(( $(date +%s) - $(cat $X/phwatch.off 2>/dev/null || echo 0) )) -lt 86400 ] && { [ -x $PHI ] && $PHI stop >/dev/null 2>&1; return 1; }
rm -f $X/phwatch.off
fi
d_=$(phdirs)
if [ -z "$d_" ]; then [ -x $PHI ] && $PHI stop >/dev/null 2>&1; return 0; fi
if [ ! -x $PHI ]; then
printf '#!/bin/sh /etc/rc.common\n# WrtFreedom: Foto Del Telefono in ordine appena arrivate (nasbk.sh phwatch), tolto da nasbk.sh uninstall\nSTART=99\nUSE_PROCD=1\nstart_service() {\n\tprocd_open_instance\n\tprocd_set_param command /bin/sh %s/nasbk.sh phwatch\n\tprocd_set_param respawn 3600 5 0\n\tprocd_close_instance\n}\n' "$W" > $PHI
chmod 755 $PHI; $PHI enable >/dev/null 2>&1
fi
pgrep -f 'nasbk.sh phwatch' >/dev/null 2>&1 || $PHI start >/dev/null 2>&1
{ [ "$d_" = "$(cat $X/phwatch.dirs 2>/dev/null)" ] && [ "$(phtops)" = "$(cat $X/phwatch.top 2>/dev/null)" ]; } || pkill -f "inotifywait .*$X/phwatch\." 2>/dev/null
true
}
phwatch() {
command -v inotifywait >/dev/null 2>&1 || exit 0
NQ_=0; SL_=2
while :; do
if [ -f $X/phwatch.off ] && [ -z "$WF_PHONCE" ]; then sleep 600; continue; fi
phdirs > $X/phwatch.dirs.t && mv $X/phwatch.dirs.t $X/phwatch.dirs
phtops > $X/phwatch.top.t && mv $X/phwatch.top.t $X/phwatch.top
if [ ! -s $X/phwatch.dirs ]; then [ -n "$WF_PHONCE" ] && return 0; sleep 60; continue; fi
[ -n "$WF_PHONCE" ] || ( sh "$0" phtidy ) </dev/null >/dev/null 2>&1 &
S_=$(date +%s)
{ p_=; if [ -s $X/phwatch.top ]; then inotifywait -m -q -e close_write -e moved_to --format '%w%f' --fromfile $X/phwatch.top & p_=$!; fi
inotifywait -m -r -q -e close_write -e moved_to --format '%w%f' --fromfile $X/phwatch.dirs
[ -n "$p_" ] && { [ -n "$WF_PHONCE" ] && wait "$p_" || kill "$p_"; }; true; } 2>/dev/null | while IFS= read -r f; do
case "${f##*/}" in .*|*.tmp|*.part|*.partial|*.crdownload|*.download|*~) continue ;; esac
[ "$(wc -c < $X/phwatch.q 2>/dev/null || echo 0)" -lt 262144 ] || { [ -f $X/phwatch.full ] || : > $X/phwatch.full; continue; }
if [ -d "$f" ]; then grep -qxF "${f%/*}" $X/phwatch.top 2>/dev/null || find "$f" -type f >> $X/phwatch.q 2>/dev/null; else printf '%s\n' "$f" >> $X/phwatch.q; fi
[ -d $X/phq.run ] || ( sh "$0" phfileq ) </dev/null >/dev/null 2>&1 &
done
[ -n "$WF_PHONCE" ] && return 0
if [ $(( $(date +%s) - S_ )) -lt 30 ]; then NQ_=$((NQ_ + 1)); SL_=$((SL_ * 2)); [ $SL_ -gt 300 ] && SL_=300
else NQ_=0; SL_=2; fi
if [ $NQ_ -ge 3 ]; then
date +%s > $X/phwatch.off
ev nas_photo_err "⚠️ Foto ¦ $(t 'Troppe cartelle da seguire: foto messe in ordine ogni 5 minuti' 'Too many folders to watch: photos sorted every 5 minutes')"
NQ_=0; SL_=2; continue
fi
sleep $SL_
done
}
phfileqrun() {
while :; do
mkdir $X/phq.run 2>/dev/null || return 0
i_=0
while [ -s $X/phwatch.q ] && [ $i_ -lt 720 ]; do
mv $X/phwatch.q $X/phwatch.w
n_=$(ucode -e "let M = loadfile('$V')(); print(M.phfileq('$X/phwatch.w').moved);" </dev/null 2>/dev/null)
rm -f $X/phwatch.w
[ "${n_:-0}" = 0 ] && [ -s $X/phwatch.q ] && sleep 5
i_=$((i_ + 1))
done
rmdir $X/phq.run 2>/dev/null
[ -f $X/phwatch.full ] && [ ! -s $X/phwatch.q ] && { rm -f $X/phwatch.full; bk phtidy; }
[ -s $X/phwatch.q ] && [ $i_ -lt 720 ] || return 0
done
}

tick() {
for f in $X/.pw-k*; do [ -f "$f" ] && sh "$0" cryptset "${f##*/.pw-}"; done
n=$(date +%s); for f in $X/.tok-*; do [ -f "$f" ] && [ $((n - $(date -r "$f" +%s 2>/dev/null || echo 0))) -gt 600 ] && rm -f "$f"; done
bk bktick
h=$(date +%H%M); d=$(date +%Y%m%d)
if [ "$h" -ge 430 ] && [ "$h" -lt 500 ] && [ "$(cat $X/cloud-verify.day 2>/dev/null)" != "$d" ] && ls $CDIR/k*.sh >/dev/null 2>&1; then
echo "$d" > $X/cloud-verify.day; ( sh "$0" verify cloud ) </dev/null >/dev/null 2>&1 &
fi
if [ "$h" -ge 200 ] && [ "$h" -lt 400 ] && [ "$(cat $X/phmove.day 2>/dev/null)" != "$d" ]; then
echo "$d" > $X/phmove.day; ( sh "$0" phmove ) </dev/null >/dev/null 2>&1 &
fi
if phwsvc; then { [ -f $X/phwatch.full ] || once phtidy 3600; } && { rm -f $X/phwatch.full; ( sh "$0" phtidy ) </dev/null >/dev/null 2>&1 & }
else ( sh "$0" phtidy ) </dev/null >/dev/null 2>&1 & fi
[ -f $X/phren2.ok ] || ( sh "$0" phren ) </dev/null >/dev/null 2>&1 &
true
}

rcawk() {
[ -f $CONF ] || return 0
( umask 077; awk -v s=" $* " '/^\[.*\][ \t]*$/ { n = $0; sub(/^\[/, "", n); sub(/\][ \t]*$/, "", n); k = index(s, " " n " ") > 0 } !k' $CONF > $CONF.t$$ ) &&
mv $CONF.t$$ $CONF || rm -f $CONF.t$$
}
uninstall() {
[ -z "$R" ] && [ -x $PHI ] && { $PHI stop >/dev/null 2>&1; $PHI disable >/dev/null 2>&1; rm -f $PHI; }
pkill -f "inotifywait .*$X/phwatch\." 2>/dev/null
for p in $(cat $X/cloud-k*.lock/rpid $X/cloud-p*.lock/rpid 2>/dev/null); do kill "$p" 2>/dev/null; done
for p in $(cat $TMP/bak-*.lock/pid 2>/dev/null); do kill "$p" 2>/dev/null; done
for p in $(cat $TMP/bk-*.e*/pid 2>/dev/null); do kill "$p" 2>/dev/null; done
pkill -f "rsync .*--exclude-from=$BKD/" 2>/dev/null
for f in $CDIR/k*.sh; do [ -f "$f" ] && { i=$(basename "$f" .sh); rcdel "wf$i" "wf${i}x" || rcawk "wf$i" "wf${i}x"; rm -f "$CDIR/$i.sh" "$CDIR/$i.last" "$CDIR/$i.vers" "$CDIR/$i.full" "$CDIR/$i.about" "$CDIR/$i.keep" "$CDIR/$i.keepnext" "$CDIR/$i.st" "$CDIR/$i.check"
[ -f $CCONF ] && { CONF=$CCONF; rcdel "wf${i}x" || rcawk "wf${i}x"; CONF=$OCONF; }; }; done
for l in $CT/acct-*.lock $CT/slot.*; do [ -d "$l" ] && case "$(cat "$l/job" 2>/dev/null)" in nbk-*) rm -rf "$l" ;; esac; done
rm -f $CT/jobs/nbk-* $CT/q/nbk-* $CT/.w-nbk.* 2>/dev/null
rm -f $BKD/hist $BKD/macs.json $BKD/warned.json $BKD/*.ok $BKD/*.nv $BKD/*.chk $BKD/*.skip $BKD/present.json $X/phwatch.off $X/phwatch.full $X/rclone.trk $X/remind.json $X/.pw-* $X/.pwa-* $X/.tok-* $X/cloud-k*
rm -f $CDIR/p*.sh $CDIR/p*.excl $CDIR/p*.last $CDIR/p*.st $X/cloud-p*
rm -rf $TMP/bk-* $TMP/bak-*.lock $X/cloud-k*.lock $X/cloud-p*.lock $X/rc-wfk*.lock; true
}
bkownrun() {
L_=$TMP/bk-own.run; A_=$TMP/bk-own.again
p_=$(cat "$L_" 2>/dev/null); [ -n "$p_" ] && [ -d "/proc/$p_" ] && { : > "$A_"; return 0; }
echo $$ > "$L_"; trap 'rm -f "$L_"' EXIT
i_=0; while [ $i_ -lt 5 ]; do rm -f "$A_"; bk bkown; [ -f "$A_" ] || break; i_=$((i_+1)); done
}

c=$1; [ $# -gt 0 ] && shift
case "$c" in tick|restore|cloudrestore|phmove|phren|phtidy|phwatch|phfileq) umask 022 ;; esac
case "$c" in
tick) tick ;;
run) DRY=0; run "$@" ;;
dry) DRY=1; run "$1" ;;
restore) restore "$@" ;;
verify) case "$1" in cloud) cverall ;; k*) cverify "$@" ;; *) verify "$@" ;; esac ;;
du) du_ ;;
cloud) cloud "$@" ;;
pccloud) pccloud "$@" ;;
cpull) cpull "$@" ;;
cpullfree) cpullfree "$@" ;;
cpullput) cpullput "$@" ;;
cloudstop) cloudstop "$@" ;;
cryptset) cryptset "$@" ;;
cloudold) cloudold ;;
cloudrestore) cloudrestore "$@" ;;
cloudfree) free_ "$@" ;;
adopt) adopt "$@" ;;
clouddry) clouddry "$@" ;;
browse) browse "$@" ;;
uninstall) uninstall ;;
bkown) bkownrun ;;
phmove) bk phmove ;;
phren) bk phren ;;
phtidy) bk phtidy ;;
phwatch) phwatch ;;
phfileq) phfileqrun ;;
*) echo "uso: nasbk.sh tick|run|dry|restore|verify|du|cloud|pccloud|cpull|cpullfree|cpullput|cloudstop|cryptset|cloudold|cloudrestore|cloudfree|adopt|clouddry|browse|uninstall|bkown|phmove|phren|phtidy|phwatch|phfileq"; exit 2 ;;
esac
