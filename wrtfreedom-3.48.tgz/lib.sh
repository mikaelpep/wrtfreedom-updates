#!/bin/sh
[ -n "$P0" ] || { [ -n "$WF_CRONTEST" ] && [ ! -e /etc/openwrt_release ] && P0=$WF_CRONTEST; }

lb_uadd() { if [ -n "$lb_us" ]; then printf '%s/%s\n' "$1" "$lb_us"; else printf '%s\n' "$1"; fi; }
lb_utype() { case "$1" in video) echo Film ;; music) echo Musica ;; photo) echo Foto ;; app) [ "$2" = media ] || echo Programmi ;; doc) [ "$2" = media ] || echo Documenti ;; esac; }
lb_uvis() {
case "$1" in ''|admin|shared|*[!A-Za-z0-9._-]*) return 1 ;; esac
lb_uf=${WF_NASETC:-$P0/etc/wrtfreedom}/nas.json
[ -s "$lb_uf" ] || return 1
if [ -n "$(jsonfilter -i "$lb_uf" -e "@.users[\"$1\"]" 2>/dev/null)" ]; then
case "$(jsonfilter -i "$lb_uf" -e "@.users[\"$1\"].cam" 2>/dev/null)" in ''|false|0) ;; *) return 1 ;; esac
lb_uv=$(jsonfilter -i "$lb_uf" -e "@.users[\"$1\"].vis" 2>/dev/null)
else
lb_uv=$(jsonfilter -i "$lb_uf" -e "@.gone[@.user=\"$1\"].vis" 2>/dev/null | head -n 1)
fi
case "$lb_uv" in ''|.*|*/*|Amministratore|'Cartella Condivisa') return 1 ;; esac
[ "$(printf '%s' "$lb_uv" | wc -l)" -eq 0 ] && [ ${#lb_uv} -le 255 ] || return 1
printf '%s\n' "$lb_uv"
}
wf_udir() {
lb_uk=${2:-root} lb_us=$3 lb_uw='Utenti/Amministratore/WrtFreedom'
if [ -n "$lb_us" ]; then
case "/$lb_us/" in *//*|*/.*) return 1 ;; esac
[ "$(printf '%s' "$lb_us" | wc -l)" -eq 0 ] || return 1
fi
case "$lb_uk" in router) lb_uadd "$lb_uw/Router"; return 0 ;; cams) lb_uadd "$lb_uw/Telecamere"; return 0 ;; esac
if [ "$1" = shared ]; then
lb_ub='Utenti/Cartella Condivisa'
case "$lb_uk" in
root) lb_uadd "$lb_ub" ;;
media) [ -z "$lb_us" ] && { echo "$lb_ub"; return 0; }
lb_ut=$(lb_utype "$lb_us" media); [ -n "$lb_ut" ] && echo "$lb_ub/$lb_ut" ;;
mold) lb_uadd "$lb_ub/Multimedia" ;;
docs) lb_uadd "$lb_ub/Documenti" ;;
prog) lb_uadd "$lb_ub/Programmi" ;;
misc) lb_uadd "$lb_ub/Varie" ;;
*) return 1 ;;
esac
return
fi
if [ "$1" = admin ]; then lb_uv=Amministratore; else lb_uv=$(lb_uvis "$1") || return 1; fi
lb_ub="Utenti/$lb_uv" lb_up="Utenti/$lb_uv/Cartella Personale"
case "$lb_uk" in
root) lb_uadd "$lb_ub" ;;
wf) [ "$1" = admin ] || return 1; lb_uadd "$lb_uw" ;;
priv) lb_uadd "$lb_up" ;;
media) [ -z "$lb_us" ] && { echo "$lb_up"; return 0; }
lb_ut=$(lb_utype "$lb_us" media); [ "$lb_ut" = Foto ] && lb_ut='Foto e Video'; [ -n "$lb_ut" ] && echo "$lb_up/$lb_ut" ;;
mold) lb_uadd "$lb_up/Multimedia" ;;
phones) lb_uadd "$lb_up/Foto e Video/Dal Telefono" ;;
tocat) lb_uadd "$lb_up/Foto e Video/Da Catalogare" ;;
pold) lb_uadd "$lb_up/Foto" ;;
phold) lb_uadd "$lb_up/Foto e Video/Foto Del Telefono" ;;
docs) lb_uadd "$lb_up/Documenti" ;;
prog) lb_uadd "$lb_up/Programmi" ;;
dl|up|recv) case $lb_uk in dl) lb_un=Download ;; up) lb_un='File Caricati' ;; *) lb_un='File Ricevuti' ;; esac
[ -z "$lb_us" ] && { echo "$lb_ub/$lb_un"; return 0; }
lb_ut=$(lb_utype "$lb_us" "$lb_uk"); echo "$lb_ub/$lb_un/${lb_ut:-Varie}" ;;
pub) lb_uadd "$lb_ub/Cartella Pubblica" ;;
backup) lb_uadd "$lb_ub/Backup e Sincronizzazione" ;;
tm) lb_uadd "$lb_ub/Backup e Sincronizzazione/Backup Del Mac" ;;
fh) lb_uadd "$lb_ub/Backup e Sincronizzazione/Backup Del PC" ;;
sync) lb_uadd "$lb_ub/Backup e Sincronizzazione/Sincronizzazione" ;;
tg) lb_uadd "$lb_ub/Telegram" ;;
lnk) lb_uadd "$lb_ub/Link Condivisi" ;;
inbox) lb_uadd "$lb_ub/Richieste File In Arrivo" ;;
*) return 1 ;;
esac
}

lb_cpu() {
WF_NASETC=${WF_NASETC:-$P0/etc/wrtfreedom} WF_CPA=$1 WF_CPB=$2 ucode -e "let U = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')(), a = getenv('WF_CPA'), b = getenv('WF_CPB');
		let r = '$3' == 'p' ? U.cpriv(a) : U.crsec(a, b);
		if (r == null) exit(1);
		print(type(r) == 'object' ? join('\t', [ r.own, r.vis, r.top, r.rest ]) : r, '\n');" </dev/null 2>/dev/null
}
wf_cpriv() { [ -n "$1" ] && lb_cpu "$1" '' p; }
wf_crsec() { [ -n "$1" ] && [ -n "$2" ] && lb_cpu "$1" "$2" s; }

wf_homezone() {
uci -q show firewall 2>/dev/null | awk '
	{ e = index($0, "="); if (!e) next; k = substr($0, 1, e - 1); v = substr($0, e + 1); gsub(/\047/, "", v)
	  n = split(k, p, ".")
	  if (n == 2) { if (v == "zone") z[++c] = k; next }
	  if (n == 3) o[p[1] "." p[2], p[3]] = v }
	END {
		for (i = 1; i <= c; i++) {
			s = z[i]; nm = o[s, "name"]; if (nm == "") continue
			nets = " " o[s, "network"] " "; m = o[s, "masq"] == "1" || o[s, "masq"] == "true"
			if (h == "" && index(nets, " lan ")) h = s
			if (a == "" && !m && nm != "vpnout" && o[s, "input"] == "ACCEPT") a = s
		}
		if (h == "") h = a
		if (h != "") print o[h, "name"], o[h, "network"]
	}'
}
wf_maskbits() {
echo "${1:-255.255.255.0}" | awk -F. '{ b = 0; for (i = 1; i <= 4; i++) { o = $i + 0; while (o >= 128) { b++; o = (o * 2) % 256 } } print b }'
}
homenet() {
HN_NET=; HN_DEV=; HN_IP=; HN_PFX=
export HN_PFX
lb_hz=$(wf_homezone); set -- $lb_hz
[ $# -gt 1 ] || return 1
shift
for lb_n in "$@"; do
lb_s=$(ifstatus "$lb_n" 2>/dev/null) || continue
[ "$(echo "$lb_s" | jsonfilter -e '@.up' 2>/dev/null)" = true ] || continue
lb_i=$(echo "$lb_s" | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null)
[ -n "$lb_i" ] || continue
HN_NET=$lb_n; HN_IP=$lb_i; HN_PFX=$(echo "$lb_s" | jsonfilter -e '@["ipv4-address"][0].mask' 2>/dev/null)
HN_DEV=$(echo "$lb_s" | jsonfilter -e '@.l3_device' 2>/dev/null); [ -n "$HN_DEV" ] || HN_DEV=$(echo "$lb_s" | jsonfilter -e '@.device' 2>/dev/null)
break
done
if [ -z "$HN_NET" ]; then
for lb_n in "$@"; do
[ "$(uci -q get "network.$lb_n.proto")" = static ] || continue
lb_a=$(uci -q get "network.$lb_n.ipaddr" | awk '{ print $1 }'); [ -n "$lb_a" ] || continue
HN_NET=$lb_n; HN_IP=${lb_a%%/*}
case "$lb_a" in */*) HN_PFX=${lb_a#*/} ;; *) HN_PFX=$(wf_maskbits "$(uci -q get "network.$lb_n.netmask")") ;; esac
HN_DEV=$(ifstatus "$lb_n" 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null); [ -n "$HN_DEV" ] || HN_DEV=$(uci -q get "network.$lb_n.device")
break
done
fi
[ -n "$HN_NET" ] || return 1
echo "$HN_NET ${HN_DEV:--} $HN_IP"
}
wf_adgcmd() {
lb_a=
for lb_s in adguardhome AdGuardHome; do
lb_a=$(ubus call service list "{\"name\":\"$lb_s\"}" 2>/dev/null | jsonfilter -e '@[*].instances[*].command[*]' 2>/dev/null)
[ -n "$lb_a" ] && break
done
if [ -z "$lb_a" ]; then for lb_p in $(pidof AdGuardHome 2>/dev/null); do lb_a=$(tr '\0' '\n' < "/proc/$lb_p/cmdline" 2>/dev/null); [ -n "$lb_a" ] && break; done; fi
[ -n "$lb_a" ] || lb_a=$(grep -oE -- "(-c|--config)[ =]+[\"']?/[A-Za-z0-9._/-]+" /etc/init.d/adguardhome 2>/dev/null | head -n 1 | sed 's#^[^/]*#--config=#')
echo "$lb_a" | awk 'p { print; exit } $0 == "-c" || $0 == "--config" { p = 1; next } /^--config=/ { sub(/^--config=/, ""); print; exit }' |
while read -r lb_f; do case "$lb_f" in /*) [ -f "$lb_f" ] && echo "$lb_f" ;; esac; done
}
adgyaml() {
lb_y=
for lb_c in $(uci -q get adguardhome.config.config_file) $(uci -q get adguardhome.config.config); do [ -f "$lb_c" ] && { lb_y=$lb_c; break; }; done
[ -n "$lb_y" ] || lb_y=$(wf_adgcmd | sed -n 1p)
if [ -z "$lb_y" ]; then for lb_c in /etc/adguardhome/adguardhome.yaml /etc/adguardhome.yaml /opt/AdGuardHome/AdGuardHome.yaml; do [ -f "$P0$lb_c" ] && { lb_y=$lb_c; break; }; done; fi
printf '%s\n' "${lb_y:--}" > "$P0/tmp/wf-adgyaml" 2>/dev/null
[ -n "$lb_y" ] || return 1
echo "$lb_y"
}
adgaddr() {
lb_y=$(adgyaml) || return 1
lb_a=$(awk '/^http:/ { f = 1; next } f && /^[^ \t#]/ { f = 0 } f && /^[ \t]+address:/ { print $2; exit }' "$lb_y" 2>/dev/null | tr -d "\"'")
if [ -n "$lb_a" ]; then
case "$lb_a" in
\[*\]:[0-9]*) lb_h=${lb_a%%]*}; lb_h=${lb_h#?}; lb_p=${lb_a##*]:} ;;
*:[0-9]*) lb_h=${lb_a%:*}; lb_p=${lb_a##*:} ;;
*) return 1 ;;
esac
else
lb_p=$(awk '/^bind_port:/ { print $2; exit }' "$lb_y" 2>/dev/null | tr -d "\"'")
lb_h=$(awk '/^bind_host:/ { print $2; exit }' "$lb_y" 2>/dev/null | tr -d "\"'[]")
fi
case "$lb_p" in ''|*[!0-9]*) return 1 ;; esac
case "$lb_h" in ''|0.0.0.0|::)
if [ "$1" = casa ]; then homenet >/dev/null; lb_h=$HN_IP; [ -n "$lb_h" ] || return 1; else lb_h=127.0.0.1; fi ;;
esac
case "$lb_h" in *:*) lb_h="[$lb_h]" ;; esac
echo "$lb_h:$lb_p"
}
wf_curlq() {
lb_r=$(printf '\r')
printf '"%s"' "$(printf '%s\n' "$1" | sed -e 's/[\\"]/\\&/g' -e "s/$lb_r/\\\\r/g" | sed -e ':a' -e '$!N' -e '$!ba' -e 's/\n/\\n/g')"
}
wf_ifname() {
lb_i=$1; lb_m=$1; lb_p=$(uci -q get "network.$lb_i.proto")
if [ -z "$lb_p" ]; then
lb_m=${lb_i%_[46]}; lb_d=$(uci -q get "network.$lb_m.device"); case "$lb_d" in @?*) lb_m=${lb_d#@} ;; esac
lb_p=$(uci -q get "network.$lb_m.proto")
fi
[ "$lb_p" = wireguard ] && case "$lb_i" in wgout) ;; wgo|wgo*[!0-9]*) lb_t="Server VPN|VPN Server" ;; wgo*) ;; *) lb_t="Server VPN|VPN Server" ;; esac
lb_hz=$(wf_homezone); set -- $lb_hz
[ -z "$lb_t" ] && [ $# -gt 1 ] && shift && case " $* " in *" $lb_i "*) lb_t="Rete Di Casa|Home Network" ;; esac
lb_z=$(uci -q show firewall 2>/dev/null | awk -v i="$lb_i" '
		{ e = index($0, "="); if (!e) next; k = substr($0, 1, e - 1); v = substr($0, e + 1); gsub(/\047/, "", v)
		  n = split(k, p, "."); if (n == 2 && v == "zone") z[++c] = p[2]; if (n == 3) o[p[2], p[3]] = v }
		END { for (j = 1; j <= c; j++) { s = z[j]; if (!index(" " o[s, "network"] " ", " " i " ")) continue
			if (tolower(o[s, "name"]) ~ /guest/) { r = "g"; break }
			if (r != "") continue
			if (o[s, "masq"] == "1" || o[s, "masq"] == "true") r = "w"; else if (o[s, "name"] != "vpnout") r = "s" }
		  print r }')
[ -z "$lb_t" ] && { [ "$lb_i" = guest ] || [ "$lb_z" = g ]; } && lb_t="Rete Ospiti|Guest Network"
[ -z "$lb_t" ] && case "$lb_i" in
iot) lb_t="Dispositivi Smart|Smart Devices" ;;
wgout) lb_t="Client VPN|Client VPN" ;;
wgo|wgo*[!0-9]*) ;;
wgo*) lb_n=$(echo "${lb_i#wgo}" | sed 's/^0*//; s/^$/0/'); lb_n=$((lb_n + 1)); lb_t="Client VPN $lb_n|Client VPN $lb_n" ;;
esac
[ -z "$lb_t" ] && [ "$lb_p" = wireguard ] && lb_t="Server VPN|VPN Server"
[ -z "$lb_t" ] && [ "$lb_z" = s ] && [ "$lb_p" = static ] && case "$lb_i" in
*[Ss][Mm][Aa][Rr][Tt]*) lb_t="Dispositivi Smart|Smart Devices" ;;
*) lb_t="Rete Separata|Separate Network" ;;
esac
[ -z "$lb_t" ] && case "$lb_p" in modemmanager|qmi|mbim|ncm|3g|wwan|qcm) lb_t="Linea SIM|SIM Line" ;; esac
[ -z "$lb_t" ] && case "$lb_p" in dhcpv6|6in4|6to4|6rd|dslite|map) lb_t="Linea IPv6|IPv6 Line" ;; esac
[ -z "$lb_t" ] && [ -n "$lb_i" ] && [ "$lb_z" != s ] && { lb_b=$(uci -q get wrtfreedom.fo.backup); [ "$lb_b" = "$lb_i" ] || [ "$lb_b" = "$lb_m" ]; } &&
lb_t="Riserva|Backup"
[ -n "$lb_t" ] || { [ "$lb_z" = s ] && lb_t="Rete|Network"; } || lb_t="Linea|Line"
if [ "$EN" = 1 ]; then printf '%s' "${lb_t#*|}"; else printf '%s' "${lb_t%%|*}"; fi
lb_t=
}

wf_btnbase() {
case "$1" in
[Rr][Ee][Ss][Ee][Tt]) lb_t="Tasto Di Ripristino|Reset Button" ;;
[Ww][Pp][Ss]) lb_t="Tasto WPS|WPS Button" ;;
[Rr][Ee][Bb][Oo][Oo][Tt]) lb_t="Tasto Di Riavvio|Restart Button" ;;
*) lb_t="Tasto|Button" ;;
esac
}
wf_btnname() {
wf_btnbase "$1"; lb_b=$lb_t; lb_k=0; lb_n=0
for lb_f in $(ls /etc/rc.button 2>/dev/null | LC_ALL=C sort); do
wf_btnbase "$lb_f"; [ "$lb_t" = "$lb_b" ] && lb_k=$((lb_k + 1))
[ "$lb_f" = "$1" ] && { lb_n=$lb_k; break; }
done
lb_t=$lb_b; [ "$lb_n" -gt 1 ] && lb_t="${lb_t%%|*} $lb_n|${lb_t#*|} $lb_n"
if [ "$EN" = 1 ]; then printf '%s' "${lb_t#*|}"; else printf '%s' "${lb_t%%|*}"; fi
lb_t=; lb_b=
}

wf_inact() {
lb_m=$(uci -q get wrtfreedom.pres.inact); lb_c=0
if [ "$1" = on ]; then
for lb_s in $(uci -q -X show wireless 2>/dev/null | sed -n "s/^wireless\.\([A-Za-z0-9_]*\)=wifi-iface$/\1/p"); do
lb_v=$(uci -q get "wireless.$lb_s.mode"); [ -z "$lb_v" ] || [ "$lb_v" = ap ] || continue
uci -q get "wireless.$lb_s.max_inactivity" >/dev/null && continue
uci set "wireless.$lb_s.max_inactivity=900"; lb_c=1
case " $lb_m " in *" $lb_s "*) ;; *) lb_m="${lb_m:+$lb_m }$lb_s" ;; esac
done
if [ $lb_c = 1 ]; then
uci commit wireless
uci -q get wrtfreedom.pres >/dev/null || uci set wrtfreedom.pres=pres
uci set wrtfreedom.pres.inact="$lb_m"; uci commit wrtfreedom
fi
elif [ "$1" = off ]; then
for lb_s in $lb_m; do
[ "$(uci -q get "wireless.$lb_s.max_inactivity")" = 900 ] && { uci -q delete "wireless.$lb_s.max_inactivity"; lb_c=1; }
done
[ $lb_c = 1 ] && uci commit wireless
[ -n "$lb_m" ] && { uci -q delete wrtfreedom.pres.inact; uci commit wrtfreedom; }
fi
[ $lb_c = 1 ] && echo 1
lb_m=; lb_s=; lb_v=; lb_c=
}

wf_dddef() {
case "$1" in
4|6) lb_v=0; [ "$1" = 6 ] && lb_v=1
lb_d=$(sed -n "s/.*use_ipv6[[:space:]]*-eq[[:space:]]*${lb_v}[[:space:]]*\][[:space:]]*&&[[:space:]]*ip_network=\"\([^\"]*\)\".*/\1/p" "$P0/usr/lib/ddns/dynamic_dns_updater.sh" 2>/dev/null | sed -n 1p) ;;
*) lb_d=$(sed -n 's/^[[:space:]]*config_get[[:space:]]\{1,\}interface[[:space:]]\{1,\}[^[:space:]]\{1,\}[[:space:]]\{1,\}interface[[:space:]]\{1,\}"\{0,1\}\([A-Za-z0-9_.-]\{1,\}\)"\{0,1\}[[:space:]]*$/\1/p' "$P0/etc/hotplug.d/iface/95-ddns" 2>/dev/null | sed -n 1p)
[ -n "$lb_d" ] || lb_d=$(sed -n 's/.*config_get[[:space:]][^[:space:]]*[[:space:]]"[^"]*"[[:space:]]interface[[:space:]]"\([^"]*\)".*/\1/p' "$P0/usr/lib/ddns/dynamic_dns_functions.sh" 2>/dev/null | sed -n 1p) ;;
esac
[ -n "$lb_d" ] && echo "$lb_d"; lb_v=$?; lb_d=; return $lb_v
}

wf_port80() {
lb_e=$P0/etc/wrtfreedom; lb_w=$lb_e/port80.warn; lb_k=/tmp/wf-port80.lock
[ -f "$P0/etc/init.d/lighttpd" ] || { rm -f "$lb_w"; return 0; }
lb_on=0; lb_uh=0
for lb_f in "$P0"/etc/rc.d/S*; do
case "${lb_f##*/}" in S[0-9]lighttpd|S[0-9][0-9]lighttpd|S[0-9][0-9][0-9]lighttpd) lb_on=1 ;;
S[0-9]uhttpd|S[0-9][0-9]uhttpd|S[0-9][0-9][0-9]uhttpd) lb_uh=1 ;; esac
done
[ $lb_on = 1 ] || { rm -f "$lb_w"; lb_on=; lb_uh=; return 0; }
[ $lb_uh = 1 ] && awk '$1 ~ /^(list|option)$/ && $2 == "listen_http" { for (i = 3; i <= NF; i++) { v = $i; gsub(/[\047"]/, "", v); if (v ~ /(^|:)80$/) f = 1 } } END { exit !f }' "$P0/etc/config/uhttpd" 2>/dev/null || lb_uh=0
[ $lb_uh = 1 ] || { rm -f "$lb_w"; lb_on=; lb_uh=; return 0; }
set -- "$P0/etc/lighttpd/lighttpd.conf"; for lb_f in "$P0"/etc/lighttpd/conf.d/*.conf; do [ -f "$lb_f" ] && set -- "$@" "$lb_f"; done
lb_c=$(awk '{ sub(/#.*/, "") }
		/^[ \t]*server\.port[ \t]*[:]?=/ { v = $0; sub(/^[^=]*=[ \t]*/, "", v); gsub(/[ \t"]/, "", v); sp = 1; if (v != "80") u = 1; else p80 = 1 }
		/^[ \t]*server\.bind[ \t]*[:]?=/ { u = 1 }
		/\$SERVER\[[ \t]*"socket"/ { u = 1; if ($0 ~ /:80"/) p80 = 1 }
		END { if (!sp) p80 = 1; print (u ? "u" : "-") (p80 ? "p" : "-") }' "$@" 2>/dev/null)
lb_nas=0
for lb_f in "$lb_e/nas.json" "$lb_e/nas-dav.conf" "$lb_e/nasx-web.conf" "$P0/etc/init.d/wf-nasdav" "$P0/etc/init.d/wf-nasx"; do [ -f "$lb_f" ] && lb_nas=1; done
lb_l=$(uci -q get wrtfreedom.ui.lang 2>/dev/null)
lb_t() { if [ "$lb_l" = en ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
[ -d $lb_k ] && [ -n "$(find $lb_k -maxdepth 0 -mmin +1 2>/dev/null)" ] && rmdir $lb_k 2>/dev/null
mkdir $lb_k 2>/dev/null || { lb_on=; lb_uh=; lb_c=; lb_nas=; return 0; }
if [ "$lb_nas" = 1 ] && [ "${lb_c%?}" = - ]; then
"$P0/etc/init.d/lighttpd" stop >/dev/null 2>&1; "$P0/etc/init.d/lighttpd" disable >/dev/null 2>&1
[ -f "$lb_e/svc.txt" ] && grep -qx 'lighttpd 1' "$lb_e/svc.txt" && sed -i 's/^lighttpd 1$/lighttpd 0/' "$lb_e/svc.txt"
rm -f "$lb_w"
lb_m="lighttpd di serie (messo per il NAS) spento e tolto dall'avvio: la porta 80 resta a uhttpd"
logger -t wrtfreedom "$lb_m" 2>/dev/null; echo "$lb_m"
[ -f "$P0/usr/share/wrtfreedom/event.sh" ] && sh "$P0/usr/share/wrtfreedom/event.sh" cron port80 sys "🌐 $(lb_t "Interfaccia Del Router ¦ Porta 80 liberata ¦ lighttpd di serie spento" "Router Interface ¦ Port 80 freed ¦ Default lighttpd stopped")" >/dev/null 2>&1 </dev/null
if [ -z "$P0" ] && pidof uhttpd >/dev/null 2>&1 && ! awk '$4 == "0A" && $2 ~ /:0050$/ { f = 1 } END { exit !f }' /proc/net/tcp /proc/net/tcp6 2>/dev/null; then
( sleep 3; /etc/init.d/uhttpd restart ) >/dev/null 2>&1 </dev/null &
logger -t wrtfreedom "uhttpd riavviato: riprende la porta 80" 2>/dev/null; echo "uhttpd riavviato: riprende la porta 80"
fi
elif [ "${lb_c#?}" = p ] && [ ! -f "$lb_w" ]; then
mkdir -p "$lb_e"; date +%s > "$lb_w"
lb_m="lighttpd con impostazioni dell'utente sulla porta 80 insieme a uhttpd: non toccato, solo l'avviso"
logger -t wrtfreedom "$lb_m" 2>/dev/null; echo "$lb_m"
[ -f "$P0/usr/share/wrtfreedom/event.sh" ] && sh "$P0/usr/share/wrtfreedom/event.sh" cron port80_user sys "⚠️ $(lb_t "Interfaccia Del Router ¦ lighttpd sulla porta 80 con uhttpd ¦ Impostazioni tue: non lo tocco ¦ All'avvio può togliere la porta 80 all'app: cambia la sua porta" "Router Interface ¦ lighttpd on port 80 with uhttpd ¦ Your settings: left alone ¦ At startup it can take port 80 from the app: change its port")" >/dev/null 2>&1 </dev/null
elif [ "${lb_c#?}" != p ]; then rm -f "$lb_w"; fi
rmdir $lb_k 2>/dev/null
lb_on=; lb_uh=; lb_c=; lb_nas=; lb_m=; lb_l=; lb_f=
}

wf_mntof() {
[ -n "$1" ] || return 0
case "$1" in *[!A-Za-z0-9._-]*) ;; *)
if [ -s /tmp/wf-nas/mnt.json ]; then
lb_mj=$(jsonfilter -i /tmp/wf-nas/mnt.json -e "@[\"$1\"]" 2>/dev/null)
[ -n "$lb_mj" ] && awk -v m="$lb_mj" '{ p = $2; gsub(/\\040/, " ", p) } p == m { f = 1; exit } END { exit !f }' "$2/proc/mounts" && { printf '%s\n' "$lb_mj"; return 0; }
fi ;;
esac
block info 2>/dev/null | while IFS= read -r lb_ln; do
lb_d=${lb_ln%%:*}; lb_u=$(echo "$lb_ln" | sed -n 's/.* UUID="\([^"]*\)".*/\1/p' | tr 'A-F' 'a-f')
[ "$lb_u" = "$1" ] || [ "${lb_d##*/}" = "$1" ] || continue
awk -v d="$lb_d" '$1 == d { gsub(/\\040/, " ", $2); print $2; exit }' "$2/proc/mounts"; break
done
}

lb_pl=/tmp/wf-nas/passwd.lock
wf_pwstale() {
lb_pt=$(date -r $lb_pl +%s 2>/dev/null) || return 1; lb_pp=$(cat $lb_pl/pid 2>/dev/null)
{ [ -n "$lb_pp" ] && ! kill -0 "$lb_pp" 2>/dev/null; } || [ $(( $(date +%s) - lb_pt )) -gt 10 ]
}
wf_pwlock() {
lb_pi=0
while ! mkdir $lb_pl 2>/dev/null; do
lb_pi=$((lb_pi + 1)); [ $lb_pi -gt 50 ] && return 1
if wf_pwstale; then
lb_pb=$lb_pl.brk; lb_pt=$(date -r $lb_pb +%s 2>/dev/null) && [ $(( $(date +%s) - lb_pt )) -gt 10 ] && rmdir $lb_pb 2>/dev/null
if mkdir $lb_pb 2>/dev/null; then wf_pwstale && rm -rf $lb_pl; rmdir $lb_pb; continue; fi
fi
sleep 0.1 2>/dev/null || sleep 1
done
echo $$ > $lb_pl/pid
}
wf_pwunlock() { [ "$(cat $lb_pl/pid 2>/dev/null)" = $$ ] && rm -rf $lb_pl; true; }
wf_fadd() { cp -p "$1" "$1.wf$$" && echo "$2" >> "$1.wf$$" && mv -f "$1.wf$$" "$1" || { rm -f "$1.wf$$"; return 1; }; }
wf_nextid() {
lb_ik=${1##*/}; lb_il=$(awk -v k="$lb_ik" '$1 == k { print $2; exit }' "$2" 2>/dev/null); case "$lb_il" in ''|*[!0-9]*) lb_il=0 ;; esac
lb_in=$(awk -F: -v l="$lb_il" '$3 >= 2000 && $3 < 3000 { if ($3 > m) m = $3 } END { if (l + 0 > m + 0) m = l; n = (m ? m + 1 : 2000); if (n < 3000) print n }' "$1")
[ -n "$lb_in" ] || return 0
{ awk -v k="$lb_ik" '$1 != k' "$2" 2>/dev/null; echo "$lb_ik $lb_in"; } > "$2.t" && mv -f "$2.t" "$2" || { rm -f "$2.t"; return 0; }
echo "$lb_in"
}

wf_evp() { [ -f $W/event.sh ] || return 0
case "$OWN" in [a-z]*) case "$OWN" in admin|*[!a-z0-9]*) ;; *)
WF_SOLO=1 sh $W/event.sh cron "$1" "$2" "$3" "$OWN" >/dev/null 2>&1
case "$1" in *_ok|*_done) return 0 ;; esac
lb_m=$(pmsg "$1" "$(js "$NJ" "print(N.users?.[\"$OWN\"]?.vis ?? \"$OWN\")")")
sh $W/event.sh cron "$1" "$2" "$lb_m" >/dev/null 2>&1; logger -t wrtfreedom "$lb_m" 2>/dev/null; return 0 ;; esac ;; esac
sh $W/event.sh cron "$1" "$2" "$3" >/dev/null 2>&1; logger -t wrtfreedom "$3" 2>/dev/null; true; }

case "${0##*/}" in lib.sh) case "$1" in homenet|adgyaml|adgaddr) lb_c=$1; shift; "$lb_c" "$@" ;; inact) shift; wf_inact "$@" ;; port80) wf_port80 ;; udir) shift; wf_udir "$@" ;; *) echo "uso: lib.sh homenet | adgyaml | adgaddr [casa] | inact on|off | port80 | udir own k [sub]" >&2; exit 2 ;; esac ;; esac
