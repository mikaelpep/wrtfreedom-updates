LOG() { echo "## $*"; }
PM=apk; command -v apk >/dev/null 2>&1 || PM=opkg
LOG "Installo bash e fping"
if [ $PM = apk ]; then apk update >/dev/null 2>&1; apk add bash fping; else opkg update >/dev/null 2>&1; opkg install bash fping; fi || { LOG "ERRORE bash o fping non installati: il router è collegato a internet?"; exit 1; }
for c in tar grep cmp mktemp jsonfilter mkfifo sha256sum; do command -v $c >/dev/null 2>&1 || { LOG "ERRORE manca il comando $c sul router"; exit 1; }; done
[ -d /var/run/cake-autorate ] && { LOG "Fermo l'istanza in esecuzione"; /etc/init.d/cake-autorate stop 2>/dev/null; rm -rf /var/run/cake-autorate; }
LOG "Scarico l'installer ufficiale da GitHub"
C=495038fd673a2146be08c2c4b76f77125c3c274b
F=/tmp/cake-autorate_setup.sh
if command -v curl >/dev/null 2>&1; then curl -fsSL -o $F https://raw.githubusercontent.com/lynxthecat/cake-autorate/495038fd673a2146be08c2c4b76f77125c3c274b/setup.sh; else wget -q -O $F https://raw.githubusercontent.com/lynxthecat/cake-autorate/495038fd673a2146be08c2c4b76f77125c3c274b/setup.sh; fi || { rm -f $F; LOG "ERRORE download non riuscito"; exit 1; }
[ "$(sha256sum $F | cut -d' ' -f1)" = 2c277c30c9eab109052f7ec4af2a25ab01b866c12d9096fe1b5dd48030f9fff8 ] || { rm -f $F; LOG "ERRORE l'installer scaricato non è quello previsto (impronta diversa): niente è stato installato"; exit 1; }
LOG "Installo cake-autorate (configurazione esistente conservata)"
Q=/tmp/cake-autorate_q; O=/tmp/cake-autorate_out; rm -f $Q $O
mkfifo $Q || { rm -f $F; LOG "ERRORE coda per le risposte non creata"; exit 1; }
__CAKE_AUTORATE_SETUP_SH_EXEC_COMMIT=$C sh $F lynxthecat/cake-autorate v3.2.2 <$Q >$O 2>&1 &
P=$!
exec 3>$Q
a=0; i=0; r=
while kill -0 $P 2>/dev/null; do
sleep 1; i=$((i+1))
k=$(grep -oE '\[[YyNn]/[YyNn]\]' $O 2>/dev/null | wc -l)
e=$(grep -oE 'Continue with installation\? \[Y/n\]|Previous configuration present - keep it\? \[Y/n\]' $O 2>/dev/null | wc -l)
if [ $k -gt $e ] || [ $i -ge 600 ]; then kill $P 2>/dev/null; r=no; break; fi
while [ $a -lt $e ]; do echo y >&3; a=$((a+1)); done
done
exec 3>&-
wait $P
cat $O; rm -f $F $Q $O
[ -n "$r" ] && { LOG "ERRORE l'installer ha fatto una domanda non prevista o non ha finito in 10 minuti: fermato"; exit 1; }
if [ -x /etc/init.d/cake-autorate ] && [ -f /root/cake-autorate/cake-autorate.sh ]; then
grep -qxF /root/cake-autorate/ /etc/sysupgrade.conf 2>/dev/null || echo /root/cake-autorate/ >> /etc/sysupgrade.conf
grep -qxF /etc/init.d/cake-autorate /etc/sysupgrade.conf 2>/dev/null || echo /etc/init.d/cake-autorate >> /etc/sysupgrade.conf
sh /usr/share/wrtfreedom/sqmline.sh ar
LOG "OK installato: non è ancora attivo, impostalo e avvialo dalla pagina SQM"
else LOG "ERRORE installazione non riuscita"; exit 1; fi
