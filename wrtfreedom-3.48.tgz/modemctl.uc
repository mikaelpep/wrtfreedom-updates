'use strict';
import { popen, readfile, writefile, unlink, stat, rename } from 'fs';

const M = loadfile(getenv('WF_MODEMUC') ?? '/usr/share/wrtfreedom/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function ug(k) { return trim(sh('uci -q get ' + k)); }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
const EN = ug('wrtfreedom.ui.lang') == 'en';
function t(it, en) { return EN ? en : it; }
function ev(kind, text, quiet) { sh((quiet ? 'WF_Q=1 ' : '') + 'sh /usr/share/wrtfreedom/event.sh wd ' + q(kind) + ' ' + q(text) + ' >/dev/null 2>&1'); sh('logger -t wrtfreedom-modem ' + q(text)); }
function online() {
if (!M.lineup()) return false;
for (let h in [ '1.1.1.1', '8.8.8.8', '9.9.9.9' ]) if (length(sh('ping -c 1 -W 3 ' + h + ' >/dev/null 2>&1 && echo ok'))) return true;
return length(sh('wget -q -T 6 -O /dev/null http://connectivitycheck.gstatic.com/generate_204 >/dev/null 2>&1 && echo ok')) > 0;
}
function words(s) { return filter(split(trim(s ?? ''), /\s+/), length); }
function lockapply(L, N) {
let D = M.drv(M.id());
if (!D || !D.lock) return;
for (let c in M.lockcmds(D, L, N)) M.at(c);
}

function tgtext(c) {
let known = M.id().mm || M.id().vendor;
let fresh = time() - (stat('/tmp/wf-modem.ts')?.mtime ?? 0) < 15;
if (!fresh) sh(M.readcmd());
if (!known) sh(M.readcmd());
let St = M.state(), n = St.n, I = St.id, D = St.D, L = [], v = (x, u) => (x == null || x == '') ? '?' : x + (u ?? '');
let lte = n.lte, nr = n.nr, nrname = nr?.sa ? '5G SA' : '5G NSA';
let H = (it, en) => '@@H 🌐 ' + t(it, en);
if (c == 'segnale') {
push(L, H('Segnale', 'Signal'));
if (lte) push(L, '4G' + (lte.band ? ' B' + lte.band : '') + ': RSRP ' + v(lte.rsrp, ' dBm'), 'RSRQ: ' + v(lte.rsrq, ' dB') + ' · SINR: ' + v(lte.sinr));
if (nr) push(L, nrname + (nr.band ? ' n' + nr.band : '') + ': RSRP ' + v(nr.rsrp, ' dBm'), 'RSRQ: ' + v(nr.rsrq, ' dB') + ' · SINR: ' + v(nr.sinr));
if (!lte && !nr) { let m = match(M.at('AT+CSQ'), /\+CSQ: *([0-9]+)/); push(L, m && m[1] != '99' ? 'RSSI: ' + (-113 + 2 * +m[1]) + ' dBm' : t('Non disponibile', 'Not available')); }
}
else if (c == 'cella') {
push(L, H('Cella', 'Cell'));
if (lte) {
push(L, '4G' + (lte.band ? ' B' + lte.band : '') + ' · PCI ' + v(lte.pci), 'TAC: ' + v(lte.tac) + ' · EARFCN: ' + v(lte.earfcn));
if (lte.cid && match(lte.cid, /^[0-9A-Fa-f]+$/)) push(L, 'Cell ID: ' + lte.cid, 'eNB: ' + (hex(lte.cid) >> 8));
}
if (nr) push(L, nrname + (nr.band ? ' n' + nr.band : '') + ' · PCI ' + v(nr.pci), 'ARFCN: ' + v(nr.arfcn));
if (!lte && !nr) push(L, t('Non disponibile', 'Not available'));
}
else if (c == 'bande') {
let B = M.bands();
push(L, H('Bande', 'Bands'), t('In uso', 'In use') + ': ' + (length(n.ca) ? join(' + ', n.ca) : '?'));
if (B) {
push(L, t('4G abilitate', '4G enabled') + ': ' + join(' ', map(B.cur.lte, (x) => 'B' + x)));
if (length(B.sup.nr)) push(L, '5G NSA: ' + (length(B.cur.nr) ? join(' ', map(B.cur.nr, (x) => 'n' + x)) : t('nessuna', 'none')));
push(L, t('Modalità', 'Mode') + ': ' + (B.mode == 'lte' ? t('solo 4G', '4G only') : '4G + 5G NSA'));
}
}
else if (c == 'operatore' || c == 'rete_mobile') {
let tech = nr ? (lte ? '5G NSA' : nrname) : lte ? (length(filter(n.ca, (x) => substr(x, 0, 1) == 'B')) > 1 ? '4G LTE-A' : '4G LTE') : ('5gnr' in n.at ? '5G' : length(n.at) ? '3G' : '?');
if (c == 'operatore') push(L, H('Operatore', 'Operator'), t('Nome', 'Name') + ': ' + (n.op || '?'), t('Rete', 'Network') + ': ' + tech);
else {
push(L, H('Rete Mobile', 'Mobile Network'), t('Tecnologia', 'Technology') + ': ' + tech);
if (length(n.ca)) push(L, t('Bande', 'Bands') + ': ' + join(' + ', n.ca));
if (lte?.earfcn) push(L, t('Canale', 'Channel') + ': ' + lte.earfcn);
}
}
else if (c == 'celle') {
let o = '', sent = 0, okn = 0;
if (D && D.neigh) for (let x in D.neigh) { let r = M.at(x); sent++; if (M.atok(r)) okn++; o += r + '\n'; }
let nb = D && D.parse ? (D.parse(o).nb ?? []) : [];
if (!length(nb)) nb = n.nb ?? [];
if (!length(nb) && sent > 0 && okn == 0) return '@@H ⚠️ ' + t('Celle Vicine', 'Nearby Cells') + ' ¦ ' + t('Il modem non ha risposto', 'The modem did not respond') + ' ¦ ' + t('Riprova tra poco', 'Try again shortly');
if (!length(nb)) return H('Celle Vicine', 'Nearby Cells') + ' ¦ ' + t('Nessuna letta dal modem', 'None read by the modem');
push(L, H('Celle Vicine', 'Nearby Cells'));
for (let x in slice(nb, 0, 15)) push(L, '• ' + (x.band ? 'B' + x.band : 'LTE') + ' · PCI ' + x.pci + ' · ' + v(x.rsrp, ' dBm'));
}
else if (c == 'temp_modem') {
if (!length(n.temp ?? [])) return H('Modem', 'Modem') + ' ¦ ' + t('Temperatura non letta', 'Temperature not read');
let mx = n.temp[0]; for (let x in n.temp) if (x > mx) mx = x;
push(L, H('Modem', 'Modem'), t('Temperatura', 'Temperature') + ': ' + mx + ' °C');
}
else if (c == 'sim') {
push(L, H('SIM', 'SIM'));
let sj = null; try { sj = json(sh('mmcli -i any -J 2>/dev/null') || 'null')?.sim?.properties; } catch (e) {}
if (sj) { push(L, t('Stato', 'Status') + ': ' + (sj.active == 'yes' ? t('attiva', 'active') : v(sj.active))); if (sj['operator-name']) push(L, t('Operatore', 'Operator') + ': ' + sj['operator-name']); if (sj.iccid) push(L, 'ICCID: …' + substr(sj.iccid, -4)); }
else {
let p = match(M.at('AT+CPIN?'), /\+CPIN: *([^\r\n]+)/); push(L, t('Stato', 'Status') + ': ' + (p ? p[1] : '?'));
let i = match(M.at('AT+CCID'), /([0-9]{18,20})/) ?? match(M.at('AT+ICCID'), /([0-9]{18,20})/); if (i) push(L, 'ICCID: …' + substr(i[1], -4));
}
}
else if (c == 'solo4g' || c == 'standard') {
if (!(I?.mm || I?.vendor)) return join('\n', [ H('Modem', 'Modem'), t('Nessun modem', 'No modem'), t('Collegalo e riprova', 'Connect it and try again') ]);
let r = M.setmode(c == 'solo4g' ? 'lte' : 'nr');
if (r.ok) push(L, H('Modem', 'Modem'), c == 'solo4g' ? t('In solo 4G', 'In 4G only') : t('In 4G + 5G NSA', 'In 4G + 5G NSA'),
t('Senza linea, torna com\'era', 'No line: it goes back'), t('Entro 3 minuti', 'Within 3 minutes'));
else push(L, '@@H ⚠️ Modem', t('Comando non accettato', 'Command not accepted'), ...r.errors);
}
else return t('comando sconosciuto', 'unknown command');
return join('\n', L);
}

let cmd = ARGV[0];
if (cmd == 'guard') {
let P = null; try { P = json(readfile('/etc/wrtfreedom/modem.prev') || 'null'); } catch (e) {}
if (!P || time() - P.t > 900) exit(0);
let ok = online();
if (!ok) { sh('sleep 30'); ok = online(); }
if (ok) { unlink('/etc/wrtfreedom/modem.prev'); exit(0); }
ev('restore', '🌐 Modem ¦ ' + t('Impostazioni di prima rimesse', 'Previous settings restored') + ' ¦ ' + t('Linea non tornata col cambio', 'No line after the change'));
M.bandsset(P.lte, P.nr, P.mode);
lockapply(P.locklte, P.locknr);
sh('uci set wrtfreedom.lock=celllock; ' + (length(P.locklte) ? 'uci set wrtfreedom.lock.lte=' + q(P.locklte) + '; ' : 'uci -q delete wrtfreedom.lock.lte; ') +
(length(P.locknr) ? 'uci set wrtfreedom.lock.nr=' + q(P.locknr) + '; ' : 'uci -q delete wrtfreedom.lock.nr; ') + 'uci commit wrtfreedom; rm -f /tmp/wf-q5g.*');
unlink('/etc/wrtfreedom/modem.prev');
exit(0);
}
if (cmd == 'boot') {
let I = null;
for (let i = 0; i < 60; i++) {
sh('o=$(mmcli -m any -J 2>/dev/null); [ -n "$o" ] && echo "$o" > /tmp/wf-modem.mm.$$ && mv -f /tmp/wf-modem.mm.$$ /tmp/wf-modem.mm');
I = M.id(true);
if (I.mm || M.atok(M.at('AT'))) break;
sh('sleep 5');
}
if (!I || !I.present) exit(0);
if (!M.id().vendor && !stat('/tmp/wf-modem.ati')) { sh('sh /usr/share/wrtfreedom/at.sh ATI > /tmp/wf-modem.ati 2>/dev/null'); I = M.id(true); }
let L = words(ug('wrtfreedom.modem.lte')), N = words(ug('wrtfreedom.modem.nr')), mode = ug('wrtfreedom.modem.mode');
if (length(L)) {
let B = M.bands();
if (B && (join(' ', B.cur.lte) != join(' ', sort(L, (a, b) => +a - +b)) || (mode != 'lte' && length(B.sup.nr) && join(' ', B.cur.nr) != join(' ', sort(N, (a, b) => +a - +b))))) {
let r = M.bandsset(L, N, mode || 'nr');
ev('bands', (r.ok ? '🌐 ' : '⚠️ ') + 'Modem ¦ ' + t('Bande rimesse all\'accensione', 'Bands restored at power on') + (r.ok ? '' : ' ¦ ' + join(', ', r.errors)));
}
}
if (ug('wrtfreedom.lock.boot') == '1' && !length(sh('command -v 5g-lock'))) {
let LL = ug('wrtfreedom.lock.lte'), NN = ug('wrtfreedom.lock.nr');
if (length(LL)) { lockapply(LL, NN); ev('lock', '🌐 Modem ¦ ' + t('Blocco cella rimesso', 'Cell lock restored') + ' ¦ ' + t('All\'accensione', 'At power on'), true); }
}
exit(0);
}
function nrset(m) {
let I = M.id(), D = M.drv(I), err = '';
if (D && D.nrmode) { for (let c in D.nrmode(m)) { let o = M.at(c); if (!M.atok(o)) { sh('sleep 2'); o = M.at(c); } if (!M.atok(o)) err = c + ' → ' + (trim(o) || 'nessuna risposta'); } }
else if (I.mm) {
let am = m == 'sa' ? '5g' : '5g|4g', o = M.mmcli('--set-allowed-modes=' + q(am) + (m == 'sa' ? '' : ' --set-preferred-mode=5g'));
M.cmdlog('mmcli --set-allowed-modes=' + am, o);
if (match(o, /error/i) && !match(o, /already|unchanged|same/i)) err = 'ModemManager: ' + trim(o);
let mi = M.mobif();
if (!length(err) && mi && mi[1] == 'modemmanager') sh('uci set network.' + mi[0] + '.allowedmode=' + q(am) + '; ' + (m == 'sa' ? 'uci -q delete network.' + mi[0] + '.preferredmode; ' : 'uci set network.' + mi[0] + '.preferredmode=5g; ') + 'uci commit network');
}
else err = t('questo modem non permette di scegliere il 5G da qui', 'this modem does not allow choosing 5G from here');
if (!length(err)) sh('uci set wrtfreedom.modem=modem; uci set wrtfreedom.modem.nrmode=' + m + '; uci commit wrtfreedom');
return err;
}
if (cmd == 'nrmode') {
let m = ARGV[1] ?? '', F = '/tmp/wf-nrmode.json';
if (index([ 'nsa', 'auto', 'sa' ], m) < 0) { print('uso: modemctl.uc nrmode nsa|auto|sa\n'); exit(1); }
let prev = ug('wrtfreedom.modem.nrmode') || 'nsa', was = M.lineup();
wjs(F, { t: time(), mode: m, busy: true });
let err = nrset(m);
if (length(err) || !was || m == prev) { wjs(F, { t: time(), mode: m, ok: !length(err), err: err }); exit(length(err) ? 1 : 0); }
wjs(F, { t: time(), mode: m, ok: true, err: '', wait: true });
sh('sleep 180');
let ok = online();
if (!ok) { sh('sleep 30'); ok = online(); }
let restored = false;
if (!ok) {
nrset(prev); restored = true;
ev('restore', '🌐 Modem ¦ ' + t('Modalità di prima rimessa', 'Previous mode restored') + ' ¦ ' + t('Linea non tornata col 5G', 'No line after the 5G change'));
}
wjs(F, { t: time(), mode: restored ? prev : m, ok: ok, err: '', restored: restored });
exit(0);
}
if (cmd == 'tg') { print(tgtext(ARGV[1] ?? ''), '\n'); exit(0); }
if (cmd == 'restart') { let w = M.restart(); print(length(w) ? 'ok ' + w + '\n' : 'ERRORE il modem non ha accettato il riavvio\n'); exit(length(w) ? 0 : 1); }
if (cmd == 'report') { print(M.report(), '\n'); exit(0); }
if (cmd == 'bands') { M.bands(); exit(0); }
print('uso: modemctl.uc guard|boot|restart|report|bands|nrmode <modo>|tg <comando>\n');
