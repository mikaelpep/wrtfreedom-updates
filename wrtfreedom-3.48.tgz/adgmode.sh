#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
set -f	# niente glob: i server come [/lan/]… restano com'erano
W=/usr/share/wrtfreedom; S=/etc/wrtfreedom/adgmode; N=/etc/wrtfreedom/adgmode.new; FB=/etc/wrtfreedom/dnsfb.state
J=/tmp/wf-adgmode.json; LK=/tmp/wf-adgmode.lock; PD=/tmp/wf-adgmode.pend; CNT=/tmp/wf-dnsfb.n
EN=0; if [ -n "$WF_LANG" ]; then [ "$WF_LANG" = en ] && EN=1; else [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1; fi
DFO=$WF_DF; unset WF_LANG WF_DF
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { q_=; [ -f /tmp/wf-ritorno.pid ] && q_=1; WF_Q=$q_ sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1; }
st() { printf '{"st":"%s","msg":"%s","t":%s,"until":%s}\n' "$1" "$2" "$(date +%s)" "${3:-0}" > $J.t && mv $J.t $J; }
TMO=; command -v timeout >/dev/null 2>&1 && TMO="timeout 8"
ans() { o=$($TMO nslookup openwrt.org "$1" 2>&1) && return 0
case "$o" in *"can't find"*|*NXDOMAIN*|*SERVFAIL*|*REFUSED*) return 0 ;; esac; return 1; }
waitans() { i=0; while [ $i -lt "${2:-10}" ]; do ans "$1" && return 0; sleep 2; i=$((i+1)); done; return 1; }
yaml() { sh $W/lib.sh adgyaml 2>/dev/null; }	# file di AdGuard: una regola sola in lib.sh
ainit() { for s in adguardhome AdGuardHome; do [ -x /etc/init.d/$s ] && { echo $s; return; }; done; }
dsec() { uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=dnsmasq$/\1/p"; }
yval() { awk -v k="$2" '/^[^ #]/{d=($0 ~ /^dns:/)} d && $0 ~ "^  "k":" {sub("^  "k":[ \t]*",""); gsub(/["\047]/,""); print; exit}' "$1"; }
yblk() { awk -v k="$2" '/^[^ #]/{d=($0 ~ /^dns:/); p=0; next} d{ if (p && ($0 ~ /^    / || $0 ~ /^  - /)) {print; next} p=0; if ($0 ~ "^  "k":") {print; p=1} }' "$1"; }
yitems() { yblk "$1" "$2" | sed -n 's/^ *- *//p'; }
fmode() { ls -lnL "$1" 2>/dev/null | awk 'NR == 1 { m = 0; for (i = 2; i <= 10; i++) m = m * 2 + (substr($1, i, 1) ~ /[rwxst]/); printf "%s:%s %o\n", $3, $4, m }'; }
fown() { [ -n "$2" ] && [ ! -L "$1" ] || return 0; chown "${2% *}" "$1" 2>/dev/null; chmod "${2#* }" "$1" 2>/dev/null; return 0; }
ymv() { m_=$(fmode "$1"); mv "$1.wf" "$1" && fown "$1" "$m_"; }
yset() {	# yset <file di AdGuard> <blocchi>: chiavi sostituite (le mancanti in fondo al blocco dns), il resto com'è
awk -v R="$2" '
	BEGIN { while ((getline l < R) > 0) { if (l ~ /^  [a-z_]+:/) { k = l; sub(/^  /, "", k); sub(/:.*/, "", k); o[++n] = k; b[k] = l } else b[k] = b[k] "\n" l } }
	function rest() { for (i = 1; i <= n; i++) if (!(o[i] in done)) print b[o[i]] }
	/^[^ #]/ { if (d) rest(); d = ($0 ~ /^dns:/); s = 0; print; next }
	d { if (s) { if ($0 ~ /^    / || $0 ~ /^  - /) next; s = 0 }
		if (match($0, /^  [a-z_]+:/)) { k = substr($0, 3, RLENGTH - 3); if (k in b) { print b[k]; done[k] = 1; s = 1; next } } }
	{ print }
	END { if (d) rest() }' "$1" > "$1.wf" && ymv "$1"
}
ydel() {	# ydel <file di AdGuard> <chiavi>: chiavi tolte dal blocco dns (con le loro righe)
awk -v K=" $2 " '
	/^[^ #]/ { d = ($0 ~ /^dns:/); s = 0; print; next }
	d { if (s) { if ($0 ~ /^    / || $0 ~ /^  - /) next; s = 0 }
		if (match($0, /^  [a-z_]+:/)) { k = substr($0, 3, RLENGTH - 3); if (index(K, " " k " ")) { s = 1; next } } }
	{ print }' "$1" > "$1.wf" && ymv "$1"
}
freeport() { u=" $(awk 'NR>1{split($2,a,":");print a[2]}' /proc/net/udp /proc/net/udp6 2>/dev/null; awk 'NR>1&&$4=="0A"{split($2,a,":");print a[2]}' /proc/net/tcp /proc/net/tcp6 2>/dev/null) "
u=$(echo $u); for p; do case " $u " in *" $(printf '%04X' $p) "*) ;; *) echo $p; return 0 ;; esac; done; return 1; }
homeips() {
WANN=" $(for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do uci -q get firewall.$z.network; done | tr '\n' ' ') " ucode -e '
let u = require("ubus").connect(), d = u ? u.call("network.interface", "dump") : null, w = getenv("WANN"), r = [], m = [];
for (let i in d?.interface ?? []) {
	let n = i.interface;
	if (!i.up || n == "loopback" || index(w, " " + n + " ") >= 0 || match(n, /^wgo(ut|[0-9]+)$/)) continue;
	for (let a in i["ipv4-address"] ?? []) { push(r, a.address); push(m, n + "=" + a.address); }
	for (let a in [ ...(i["ipv6-address"] ?? []), ...map(i["ipv6-prefix-assignment"] ?? [], (p) => p["local-address"] ?? {}) ])
		if (match(a.address ?? "", /^f[cd]/i)) push(r, a.address);
}
print(join(" ", uniq(r)) + "\n" + join(" ", uniq(m)) + "\n");' 2>/dev/null
}
alive() { for p in $(pgrep -f 'adgmode\.sh (direct|back|rebind)' 2>/dev/null); do [ "$p" != $$ ] && [ "$p" != $PPID ] && return 0; done; return 1; }
lock() { i=0; while ! mkdir $LK 2>/dev/null; do
a=$(( $(date +%s) - $(date -r $LK +%s 2>/dev/null || date +%s) ))
if { [ $a -gt 300 ] && ! alive; } || [ $a -gt 900 ]; then rmdir $LK; continue; fi
[ "$1" = try ] && exit 0; [ $i -ge 30 ] && exit 1; sleep 1; i=$((i+1)); done
trap 'rmdir $LK 2>/dev/null' EXIT; }
detect() {
MODE=other; Y=$(yaml); A=$(ainit); D=$(dsec | sed -n 1p); AP=; DP=
[ -n "$Y" ] && [ -n "$A" ] && [ -n "$D" ] || return 1
AP=$(yval "$Y" port); DP=$(uci -q get dhcp.$D.port); DP=${DP:-53}
if [ "$AP" = 53 ] && [ "$DP" != 53 ]; then MODE=direct
elif [ "$DP" = 53 ] && uci -q get dhcp.$D.server | tr ' ' '\n' | grep -qxE "(127\.0\.0\.1|::1|localhost)#$AP"; then MODE=std; fi
return 0
}
DC=/tmp/wf-adgdet
detc() {
read u_ _ </proc/uptime 2>/dev/null; u_=${u_%.*}; u_=${u_:-0}
if [ -f $DC ] && [ ! -s /tmp/.uci/dhcp ]; then
. $DC; ok_=1
case "$DU" in ''|*[!0-9]*) ok_=0 ;; *) [ "$u_" -ge "$DU" ] && [ "$u_" -lt $((DU + 300)) ] || ok_=0 ;; esac
for f_ in /etc/config/dhcp /etc/config/adguardhome "$Y" /etc/init.d "/etc/init.d/$A"; do
[ -e "$f_" ] && ! [ $DC -nt "$f_" ] && ok_=0
done
[ -n "$Y" ] && [ -f "$Y" ] && [ -n "$A" ] && [ -n "$D" ] || ok_=0
[ $ok_ = 1 ] && return 0
fi
detect || { [ -f $DC ] && rm -f $DC; return 1; }
printf "MODE='%s'\nY='%s'\nA='%s'\nD='%s'\nAP='%s'\nDP='%s'\nDU='%s'\n" "$MODE" "$Y" "$A" "$D" "$AP" "$DP" "$u_" > $DC.t && mv $DC.t $DC
return 0
}
memok() { [ -f $W/mem.uc ] || return 0; ucode $W/mem.uc check adguard </dev/null >/dev/null 2>&1; [ $? != 1 ]; }
memap() { [ -f $W/mem.uc ] && ucode $W/mem.uc apply </dev/null >/dev/null 2>&1; return 0; }
svc() { /etc/init.d/$A "$1" >/dev/null 2>&1; r_=$?; case "$1" in start|restart) memap ;; esac; return $r_; }
dnsm() { uci commit dhcp; /etc/init.d/dnsmasq restart >/dev/null 2>&1; }
pubneed() {	# servono server pubblici? (nessun server di dnsmasq e niente server dell'operatore)
[ -n "$(uci -q get dhcp.$D.server)" ] && return 1
[ "$(uci -q get dhcp.$D.noresolv)" = 1 ] && return 0
rf=$(uci -q get dhcp.$D.resolvfile); grep -q '^nameserver' "${rf:-/tmp/resolv.conf.d/resolv.conf.auto}" 2>/dev/null && return 1; return 0; }
v6lo() { grep -q '^00000000000000000000000000000001 ' /proc/net/if_inet6 2>/dev/null && echo '::1'; }

pinst() { ubus call service list "{\"name\":\"$A\"}" 2>/dev/null | grep -q '"instances"'; }
alv() { pidof AdGuardHome adguardhome >/dev/null 2>&1; }	# processo di AdGuard vivo
upsec() { read u_ _ </proc/uptime 2>/dev/null; echo "${u_%.*}"; }	# secondi dall'accensione
fbsave() { printf "MODE='%s'\nSRVD='%s'\nNR='%s'\nNP='%s'\nPUB='%s'\nT='%s'\nTRY='%s'\nNEXT='%s'\nUS='%s'\n" "$MODE" "$SRVD" "$NR" "$NP" "$PUB" "${T:-$(date +%s)}" "${TRY:-0}" "${NEXT:-0}" "${US:-0}" > $FB.t && mv $FB.t $FB; }
fbpub() { PUB=; pubneed && { PUB='9.9.9.9 1.1.1.1'; for s in $PUB; do uci add_list dhcp.$D.server=$s; done; }; }
fb_down() {	# AdGuard fermo: il DNS di casa ai server dell'operatore (o pubblici)
SRVD=; NR=$(uci -q get dhcp.$D.noresolv); NP=; T=; TRY=0; NEXT=0; US=0
if [ $MODE = std ]; then
for s in $(uci -q get dhcp.$D.server); do case "$s" in 127.0.0.1#"$AP"|::1#"$AP"|localhost#"$AP") SRVD="$SRVD $s"; uci -q del_list dhcp.$D.server="$s" ;; esac; done
[ "$NR" = 1 ] && uci set dhcp.$D.noresolv=0
pinst && /etc/init.d/$A enabled || US=1	# solo per app e dnsfb get (il restart di do_check chiede già pinst)
else
pinst || US=1	# prima di «svc stop», che lo toglie da procd
svc stop; NP=$DP; uci -q delete dhcp.$D.port; NEXT=$(( $(date +%s) + 600 ))
fi
fbpub; SRVD=${SRVD# }; fbsave; dnsm; rm -f $CNT
ev adg_down "🔒 AdGuard Home ¦ $(t "Non risponde" "Not answering") ¦ $(t "In uso il DNS dell'operatore" "Provider DNS in use")"
}
fb_later() { TRY=$((TRY+1)); NEXT=$(( $(date +%s) + ( TRY < 6 ? 600 : 3600 ) )); fbsave; }	# prossima prova più tardi
fb_up() {	# AdGuard di nuovo pronto: DNS di casa rimesso com'era
. "$FB"; D=$(dsec | sed -n 1p); MW=
if [ "$MODE" = std ]; then
for s in $PUB; do uci -q del_list dhcp.$D.server=$s; done
for s in $SRVD; do uci -q del_list dhcp.$D.server="$s"; uci add_list dhcp.$D.server="$s"; done
if [ -n "$NR" ]; then uci set dhcp.$D.noresolv="$NR"; else uci -q delete dhcp.$D.noresolv; fi
dnsm
else
if [ "${US:-0}" = 1 ] || ! /etc/init.d/$A enabled; then pinst || { fb_later; return 1; }; US=0; fbsave; fi
memok || MW=" ¦ $(t "Poca memoria libera" "Low free memory")"
svc start; i=1
while ! alv; do
[ $i -ge 3 ] && { svc stop; fb_later; return 1; }; sleep 2; i=$((i+1))
done
for s in $PUB; do uci -q del_list dhcp.$D.server=$s; done
uci set dhcp.$D.port="$NP"; dnsm; svc restart
if ! waitans 127.0.0.1 3; then
svc stop; uci -q delete dhcp.$D.port; fbpub; dnsm; fb_later; return 1
fi
fi
rm -f $FB $CNT
ev adg_up "🔒 AdGuard Home ¦ $(t "Risponde di nuovo" "Answering again") ¦ $(t "DNS di casa protetto" "Home DNS protected")$MW"
}
do_check() {
lock try
recover && exit 0
if [ -f $FB ]; then
detc || exit 0
. "$FB"
if [ "$MODE" = std ]; then
if ans "127.0.0.1:$AP"; then fb_up
else
nw=$(date +%s); ag=0; case "$T" in ''|*[!0-9]*) ;; *) ag=$((nw - T));; esac
[ $ag -lt 0 ] && { ag=600; NEXT=0; T=$nw; }
[ "$nw" -ge "${NEXT:-0}" ] && /etc/init.d/$A enabled && pinst && { ! alv || [ $ag -ge 600 ]; } &&
{ svc restart; fb_later; }
fi
elif [ "$(date +%s)" -ge "${NEXT:-0}" ]; then fb_up; fi
exit 0
fi
if [ -n "$DFO" ]; then [ "$DFO" = 1 ] || exit 0; else [ "$(uci -q get wrtfreedom.dnsfb.on)" = 1 ] || exit 0; fi
[ -f $PD ] && exit 0
detc || exit 0
case $MODE in std) tg="127.0.0.1:$AP" ;; direct) tg=127.0.0.1 ;; *) exit 0 ;; esac
ans "$tg" && { [ -f $CNT ] && rm -f $CNT; exit 0; }
[ "$(upsec)" -lt 180 ] && alv && exit 0
ans 9.9.9.9 || ans 1.1.1.1 || { [ -f $CNT ] && rm -f $CNT; exit 0; }
n=$(( $(cat $CNT 2>/dev/null || echo 0) + 1 )); echo $n > $CNT
[ $n = 1 ] && { sh /usr/share/wrtfreedom/bb.sh dns >/dev/null 2>&1 & }
[ $n -ge 2 ] && fb_down
}

ldoms() {
{ for x in $(uci -q get dhcp.$D.address) $([ "$1" = all ] && uci -q get dhcp.$D.local) $([ "$1" = all ] && uci -q get dhcp.$D.server) \
		$([ "$1" = all ] && uci -q get dhcp.$D.nftset) $([ "$1" = all ] && uci -q get dhcp.$D.ipset); do
case "$x" in /*/*) x=${x#/}; echo "${x%/*}" | tr '/' '\n' ;; esac; done
uci -q show dhcp | sed -n -e "s/^dhcp\.[^.]*\.name='\(.*\)'$/+\1/p" -e "s/^dhcp\.[^.]*\.cname='\(.*\)'$/+\1/p"
} | awk -v d="$DOM" '{ $0 = tolower($0); p = sub(/^\+/, ""); sub(/^\*\./, ""); gsub(/^\.+|\.+$/, "") }
		p && !index($0, ".") { next }
		!/^[a-z0-9_][a-z0-9_-]*(\.[a-z0-9_][a-z0-9_-]*)*$/ || $0 == d || substr($0, length($0) - length(d)) == "." d { next }
		!($0 in s) { o[++n] = $0; s[$0] = p }
		!p { s[$0] = 0 }
		END { for (i = 1; i <= n; i++) print (s[o[i]] ? "=" : "") o[i] }' | tr '\n' ' '
}
nsa() { case "$1" in -*|"") return ;; esac; $TMO nslookup -type=a "$1" "$2" 2>/dev/null | sed '1,/^Address/d' | sed -n 's/^Address[^:]*: *\([0-9][0-9.]*\)\( .*\)\{0,1\}$/\1/p' | sort | tr '\n' ' '; }
yhas() { for u in $YUP; do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; case "$v" in "[/"*) case "${v%%]*}" in *"/$1/"*) return 0 ;; esac ;; esac; done; return 1; }
ours() { case "$1" in
"[/*."*"/]#") ox=${1#"[/*."}; ox="=${ox%"/]#"}" ;;
"[/"*"/]127.0.0.1:$NP") ox=${1#"[/"}; ox=${ox%"/]127.0.0.1:$NP"} ;;
*) return 1 ;; esac
case " $DOM $LDOM " in *" $ox "*|*" =$ox "*) return 0 ;; esac; return 1; }
lent() { for lx in $DOM $LDOM; do case "$lx" in =*) echo "    - '[/${lx#=}/]127.0.0.1:$NP'"; echo "    - '[/*.${lx#=}/]#'" ;; *) echo "    - '[/$lx/]127.0.0.1:$NP'" ;; esac; done; }
lfree() { lf=; for lx in $1; do yhas "${lx#=}" || lf="$lf $lx"; done; echo "${lf# }"; }
oget() { sed -n "s/^$1='\(.*\)'$/\1/p" $S/orig; }
oput() { awk -v k="$1" -v v="$2" 'BEGIN { q = sprintf("%c", 39) } index($0, k "=") == 1 { print k "=" q v q; f = 1; next } { print } END { if (!f) print k "=" q v q }' $S/orig > $S/orig.t && mv $S/orig.t $S/orig; }
newblocks() {	# blocchi del file di AdGuard per lo schema diretto ($1 = file di uscita); LDOM = nomi aggiunti davvero
YUP=$(yitems "$Y" upstream_dns); LDOM=$(lfree "$LDOM")
{ echo "  bind_hosts:"; for a in 127.0.0.1 $(v6lo) $IPS; do echo "    - '$a'"; done
echo "  port: 53"
echo "  upstream_dns:"; g=0
for u in $YUP; do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; case "$v" in "[/$DOM/]"*|"127.0.0.1:$NP") continue ;; "[/"*) ;; *) g=1 ;; esac; echo "    - $u"; done
[ $g = 1 ] || echo "    - https://dns10.quad9.net/dns-query"
lent
echo "  local_ptr_upstreams:"; echo "    - 127.0.0.1:$NP"
echo "  use_private_ptr_resolvers: true"; } > "$1"
}
opt6() {
CH=0; NA=
for s in $(uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=dhcp$/\1/p"); do
[ "$(uci -q get dhcp.$s.ignore)" = 1 ] && continue
n=$(uci -q get dhcp.$s.interface); ip=
for x in $MAP; do [ "${x%%=*}" = "$n" ] && { ip=${x#*=}; break; }; done; [ -n "$ip" ] || continue
o=; for x in $ADD6; do [ "${x%%|*}" = "$s" ] && o=${x#*|}; done
if [ -n "$o" ]; then
[ "$o" = "6,$ip" ] || { uci -q del_list dhcp.$s.dhcp_option="$o"; uci add_list dhcp.$s.dhcp_option="6,$ip"; CH=1; }
else
case " $(uci -q get dhcp.$s.dhcp_option) " in *" 6,"*|*" option:dns-server,"*) continue ;; esac
uci add_list dhcp.$s.dhcp_option="6,$ip"; CH=1
fi
NA="$NA $s|6,$ip"
done
for x in $ADD6; do case " $NA " in *" ${x%%|*}|"*) ;; *) NA="$NA $x" ;; esac; done	# reti spente: restano com'erano
ADD6=${NA# }
}
rb_full() {	# ritorno completo alla copia (entro i 120 s, oppure dopo un cambio interrotto)
svc stop; uci -q revert dhcp; cp $N/dhcp /etc/config/dhcp; cp $N/yaml "$Y"; fown "$Y" "$(cat $N/ymode 2>/dev/null)"; /etc/init.d/dnsmasq restart >/dev/null 2>&1; svc start
rm -rf $N $PD /tmp/wf-adgmode.ok /tmp/wf-adgmode.no
st back "$(printf '%s' "$1" | sed 's/ ¦ /: /g')"; ev adg_mode "⚠️ AdGuard Home ¦ $1"
}
recover() {	# cambio interrotto a metà (adgmode.new rimasto, nessun adgmode vivo): 0 = sistemato, 1 = niente da fare
[ -d $N ] && ! alive || return 1
detect
if [ -f $N/dhcp ] && [ -f $N/yaml ] && [ -n "$Y" ] && [ -n "$A" ]; then
rb_full "$(t "Cambio interrotto ¦ DNS rimesso com'era" "Change interrupted ¦ DNS restored")"
elif [ ! -f $N/dhcp ] && [ ! -f $N/yaml ] && [ -f $N/orig ]; then
rm -rf $S; mv $N $S; rm -f $PD	# interrotto subito dopo la conferma: lo schema diretto resta
else
rm -rf $N $PD	# interrotto durante la copia: niente era ancora cambiato
fi
return 0
}
do_recover() { alive && exit 0; [ -d $N ] || exit 0; rmdir $LK 2>/dev/null; lock try; recover; }
do_direct() {
lock; recover; st run "$(t "Cambio in corso" "Switching")"
detect || { st err "$(t "AdGuard Home o il server dei nomi del router non trovati" "AdGuard Home or the router name server not found")"; exit 1; }
[ -f $FB ] && { st err "$(t "DNS di riserva in uso: AdGuard non risponde" "Backup DNS in use: AdGuard is not answering")"; exit 1; }
[ "$MODE" = std ] || { st err "$(t "Schema del DNS non riconosciuto (serve il server dei nomi del router sulla 53 che inoltra ad AdGuard)" "Unknown DNS layout (needs the router name server on 53 forwarding to AdGuard)")"; exit 1; }
[ "$(dsec | wc -l)" = 1 ] || { st err "$(t "Più server dei nomi del router: cambio non gestito" "Several router name servers: not supported")"; exit 1; }
NP=$(freeport 54 5354 1053 10053) || { st err "$(t "Nessuna porta libera per il server dei nomi del router" "No free port for the router name server")"; exit 1; }
H=$(homeips); IPS=$(echo "$H" | sed -n 1p); MAP=$(echo "$H" | sed -n 2p)
[ -n "$IPS" ] || { st err "$(t "Reti di casa non trovate" "Home networks not found")"; exit 1; }
DOM=$(uci -q get dhcp.$D.domain)
rm -rf $N; mkdir -p $N && cp /etc/config/dhcp $N/dhcp && cp "$Y" $N/yaml && fmode "$Y" > $N/ymode || { st err "$(t "Copia non riuscita (spazio pieno?)" "Backup failed (storage full?)")"; rm -rf $N; exit 1; }
for k in bind_hosts port local_ptr_upstreams use_private_ptr_resolvers; do yblk "$Y" $k; done > $N/orig.y
YNO=; for k in local_ptr_upstreams use_private_ptr_resolvers; do [ -n "$(yblk "$Y" $k)" ] || YNO="$YNO $k"; done
SRVD=; NR=$(uci -q get dhcp.$D.noresolv); ADD6=; LDOM=$(ldoms all)
newblocks $N/new.y
svc stop; yset "$Y" $N/new.y
uci set dhcp.$D.port=$NP
for s in $(uci -q get dhcp.$D.server); do case "$s" in 127.0.0.1#"$AP"|::1#"$AP"|localhost#"$AP") SRVD="$SRVD $s"; uci -q del_list dhcp.$D.server="$s" ;; esac; done
[ -z "$(uci -q get dhcp.$D.server)" ] && [ "$NR" = 1 ] && uci set dhcp.$D.noresolv=0
opt6	# con una porta diversa dalla 53 dnsmasq non annuncia più il DNS nel DHCP
printf "DP='%s'\nAP='%s'\nNP='%s'\nSRVD='%s'\nNR='%s'\nADD6='%s'\nDOM='%s'\nLDOM='%s'\nYNO='%s'\n" "$DP" "$AP" "$NP" "${SRVD# }" "$NR" "$ADD6" "$DOM" "$LDOM" "${YNO# }" > $N/orig
dnsm; svc start
IP4=; for a in $IPS; do case "$a" in *.*) IP4=$a; break ;; esac; done
if ! waitans 127.0.0.1 5 || { [ -n "$IP4" ] && ! waitans "$IP4" 5; }; then rb_full "$(t "Porta 53 senza risposta ¦ DNS rimesso com'era" "No answer on port 53 ¦ DNS restored")"; exit 1; fi
waitans 127.0.0.1:$NP 3 || { rb_full "$(t "Router muto sulla porta $NP ¦ DNS rimesso com'era" "No router answer on port $NP ¦ DNS restored")"; exit 1; }
HN=$(uci -q get system.@system[0].hostname); bad=; n=0; ok=0
for x in ${DOM:+${HN:+$HN.$DOM}} $(ldoms); do
x=${x#=}; case "$x" in -*|*[!A-Za-z0-9_.-]*) continue ;; esac
[ $n -ge 10 ] && break; n=$((n+1)); w=$(nsa "$x" 127.0.0.1:$NP); [ -n "$w" ] || continue; i=0
while [ "$(nsa "$x" 127.0.0.1)" != "$w" ]; do [ $i -ge 2 ] && { bad=$x; break 2; }; sleep 2; i=$((i+1)); done
ok=$((ok+1))
done
[ -z "$bad" ] && [ $n -gt 0 ] && [ $ok = 0 ] && { rb_full "$(t "Nomi locali senza risposta ¦ DNS rimesso com'era" "Local names not answering ¦ DNS restored")"; exit 1; }
[ -n "$bad" ] && { rb_full "$(t "Risposte diverse per $bad ¦ DNS rimesso com'era" "Different answers for $bad ¦ DNS restored")"; exit 1; }
id=$(date +%s); echo $id > $PD; rm -f /tmp/wf-adgmode.ok /tmp/wf-adgmode.no
st wait "$(t "AdGuard risponde ai dispositivi: conferma entro 120 s" "AdGuard answers devices: confirm within 120 s")" $((id + 120))
i=0; while [ $i -lt 60 ]; do
[ -f /tmp/wf-adgmode.ok ] && break
[ -f /tmp/wf-adgmode.no ] && { rb_full "$(t "Cambio annullato ¦ DNS rimesso com'era" "Change cancelled ¦ DNS restored")"; exit 0; }
sleep 2; i=$((i+1))
done
[ -f /tmp/wf-adgmode.ok ] || { rb_full "$(t "Nessuna conferma entro 120 s ¦ Rimesso com'era" "No confirmation in 120 s ¦ Restored")"; exit 0; }
rm -f $N/dhcp $N/yaml $N/ymode $N/new.y; rm -rf $S; mv $N $S; rm -f $PD /tmp/wf-adgmode.ok
[ -z "$(uci -q get wrtfreedom.dnsfb.on)" ] && { uci -q get wrtfreedom.dnsfb >/dev/null || uci set wrtfreedom.dnsfb=dnsfb; uci set wrtfreedom.dnsfb.on=1; uci commit wrtfreedom; }
st ok "$(t "AdGuard risponde ai dispositivi" "AdGuard answers devices")"
ev adg_mode "🔒 AdGuard Home ¦ $(t "Risponde ai dispositivi" "Answers devices directly") ¦ $(t "DNS del router sulla $NP" "Router DNS on port $NP")"
}
do_back() {
lock; recover; st run "$(t "Cambio in corso" "Switching")"
detect || { st err "$(t "AdGuard Home o il server dei nomi del router non trovati" "AdGuard Home or the router name server not found")"; exit 1; }
FBM=; [ -f $FB ] && FBM=$(sed -n "s/^MODE='\(.*\)'$/\1/p" $FB)
[ "$MODE" = direct ] || [ "$FBM" = direct ] || { st err "$(t "AdGuard non risponde già direttamente" "AdGuard is not answering directly")"; exit 1; }
SRVD=; NR=; ADD6=; DOM=; LDOM=; YNO=; NP=$DP
if [ "$FBM" = direct ]; then NP=$(sed -n "s/^NP='\(.*\)'$/\1/p" $FB); PUB=$(sed -n "s/^PUB='\(.*\)'$/\1/p" $FB); for s in $PUB; do uci -q del_list dhcp.$D.server=$s; done; rm -f $FB $CNT; fi
[ -f $S/orig ] && . $S/orig
DOM=${DOM:-$(uci -q get dhcp.$D.domain)}
TY=/tmp/wf-adgmode.y; : > $TY
if [ -f $S/orig.y ] && [ -s $S/orig.y ]; then cat $S/orig.y > $TY
else	# schema diretto non fatto dall'app: AdGuard su 127.0.0.1 e una porta libera
AP=$(freeport 3053 5335 15353) || { st err "$(t "Nessuna porta libera per AdGuard" "No free port for AdGuard")"; exit 1; }
DP=53; SRVD="127.0.0.1#$AP"; NR=1
printf "  bind_hosts:\n    - '127.0.0.1'\n  port: %s\n  local_ptr_upstreams:\n    - 127.0.0.1:53\n  use_private_ptr_resolvers: true\n" "$AP" >> $TY
fi
{ echo "  upstream_dns:"; for u in $(yitems "$Y" upstream_dns); do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; echo "    - $u"; done; } >> $TY
svc stop; yset "$Y" $TY; rm -f $TY; [ -n "$YNO" ] && ydel "$Y" "$YNO"
if [ "${DP:-53}" = 53 ]; then uci -q delete dhcp.$D.port; else uci set dhcp.$D.port="$DP"; fi
for s in $SRVD; do uci -q del_list dhcp.$D.server="$s"; uci add_list dhcp.$D.server="$s"; done
if [ -n "$NR" ]; then uci set dhcp.$D.noresolv="$NR"; else uci -q delete dhcp.$D.noresolv; fi
for x in $ADD6; do uci -q del_list "dhcp.${x%%|*}.dhcp_option=${x#*|}"; done
dnsm; svc start; rm -rf $S
if ! waitans 127.0.0.1 10; then detect; [ "$MODE" = std ] && fb_down; fi
st ok "$(t "DNS come prima: il server dei nomi del router sulla 53 inoltra ad AdGuard" "DNS as before: the router name server on 53 forwards to AdGuard")"
ev adg_mode "🔒 AdGuard Home ¦ $(t "DNS come prima" "DNS as before") ¦ $(t "Il router inoltra ad AdGuard" "Router forwards to AdGuard")"
}
do_rebind() {
sleep 3; lock try
[ -f $S/orig ] && [ ! -f $FB ] && [ ! -f $PD ] || exit 0
detect && [ "$MODE" = direct ] || exit 0
H=$(homeips); IPS=$(echo "$H" | sed -n 1p); MAP=$(echo "$H" | sed -n 2p); [ -n "$IPS" ] || exit 0
ADD6=$(oget ADD6); opt6
if [ $CH = 1 ]; then oput ADD6 "$ADD6"; dnsm; fi
DOM=$(oget DOM); NP=$(oget NP); LDOM=$(oget LDOM); YUP=$(yitems "$Y" upstream_dns); NL=$(lfree "$(ldoms all)")
TY=/tmp/wf-adgmode.y; : > $TY
if [ -n "$NP" ] && [ "$NL" != "$LDOM" ]; then
{ echo "  upstream_dns:"; for u in $YUP; do v=$(echo "$u" | tr -d "'\""); ours "$v" && continue; echo "    - $u"; done
LDOM=$NL; lent; } > $TY
oput LDOM "$LDOM"
fi
cur=$(yitems "$Y" bind_hosts | tr -d "'\"" | sort | tr '\n' ' '); new=$(for a in 127.0.0.1 $(v6lo) $IPS; do echo $a; done | sort | tr '\n' ' ')
[ "$cur" = "$new" ] && [ ! -s $TY ] && ans 127.0.0.1 && { rm -f $TY; exit 0; }
{ echo "  bind_hosts:"; for a in 127.0.0.1 $(v6lo) $IPS; do echo "    - '$a'"; done; } >> $TY
if ! pinst || ! /etc/init.d/$A enabled; then yset "$Y" $TY; rm -f $TY; exit 0; fi
svc stop; yset "$Y" $TY; rm -f $TY; svc start
waitans 127.0.0.1 10 && exit 0
[ "$(uci -q get wrtfreedom.dnsfb.on)" = 1 ] && [ "$(upsec)" -ge 180 ] && fb_down
}

case "$1" in
direct) do_direct ;;
back) do_back ;;
check) do_check ;;
rebind) do_rebind ;;
recover) do_recover ;;
*) echo "uso: adgmode.sh direct|back|check|rebind|recover"; exit 1 ;;
esac
exit 0
