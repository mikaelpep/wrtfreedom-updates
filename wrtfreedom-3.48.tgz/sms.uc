'use strict';
import { readfile, writefile, popen, stat, mkdir, rmdir } from 'fs';

const OUT = '/tmp/wf-sms.json', SEEN = '/etc/wrtfreedom/sms.seen', W = '/usr/share/wrtfreedom', LOCK = '/tmp/wf-sms.lock';
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function cutb(s, n) {
s = '' + s;
if (length(s) <= n) return s;
while (n > 0 && (ord(s, n) & 192) == 128) n--;
return substr(s, 0, n);
}
function cut(s, n) {
s = '' + s;
if (length(s) <= n) return s;
let c = cutb(s, n - 3), sp = rindex(c, ' '), lf = rindex(c, '\n');
if (lf > sp) sp = lf;
if (sp > length(c) * 0.8) c = substr(c, 0, sp);
return rtrim(c) + '…';
}
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function uo(sec, opt) {
let s = false;
for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
if (m && m[1] == opt) return m[2];
}
return '';
}
function js(c) { try { return json(sh(c)); } catch (e) { return null; } }
const EN = uo('ui', 'lang') == 'en';
function t(it, en) { return EN ? en : it; }
function has(c) { for (let d in split(getenv('PATH') ?? '/usr/sbin:/usr/bin:/sbin:/bin', ':')) if (length(d) && stat(d + '/' + c)) return true; return false; }
let MI = 'any';
function mmok() {
let s = stat('/tmp/wf-modem.mm');
if (s && time() - s.mtime < 300) {
let j = null; try { j = json(readfile('/tmp/wf-modem.mm') ?? 'null'); } catch (e) {}
if (j?.modem?.generic?.model) { MI = match('' + (j.modem['dbus-path'] ?? ''), /\/Modem\/([0-9]+)$/)?.[1] ?? 'any'; return true; }
}
return has('mmcli') && match(sh('mmcli -L 2>/dev/null'), /\/Modem\/[0-9]+/) != null;
}
function at(c) { return sh('sh ' + W + '/at.sh ' + q(c) + ' 2>/dev/null'); }
function lock() {
if (mkdir(LOCK)) return true;
let s = stat(LOCK);
if (s && time() - s.mtime < 300) return false;
rmdir(LOCK); return !!mkdir(LOCK);
}
function prev() { try { return json(readfile(OUT) ?? 'null'); } catch (e) { return null; } }

function mmpid() {
let p = null;
try {
let u = require('ubus').connect(), r = u ? u.call('service', 'list', { name: 'modemmanager' }) : null;
for (let n in r?.modemmanager?.instances ?? {}) { let i = r.modemmanager.instances[n]; if (i?.running && i?.pid) { p = '' + i.pid; break; } }
} catch (e) { p = null; }
return p ?? trim(sh('pidof ModemManager 2>/dev/null'));
}
function mmread(mp) {
let J = js('mmcli -m ' + MI + ' --messaging-list-sms -J 2>/dev/null');
if (J == null && MI != 'any') J = js('mmcli -m any --messaging-list-sms -J 2>/dev/null');
let P = J?.['modem.messaging.sms'] ?? [], old = {}, L = [], pv = prev();
if (pv?.mp == mp) for (let s in (pv?.list ?? [])) old[s.id] = s;
for (let p in P) {
let id = '' + split(p, '/')[-1];
if (old[id] && old[id].via == 'mm' && old[id].state != 'receiving') { push(L, old[id]); continue; }
let s = js('mmcli -s ' + q(p) + ' -J 2>/dev/null')?.sms;
if (!s) continue;
let c = s.content ?? {}, pr = s.properties ?? {};
push(L, { id: id, via: 'mm', num: c.number ?? '', text: c.text ?? '', time: pr.timestamp ?? '', state: pr.state ?? '',
dir: (pr['pdu-type'] == 'submit') ? 'out' : 'in' });
}
return L;
}
function atread(o) {
let L = [], cur = null;
for (let l in split(o, '\n')) {
l = trim(l);
let m = match(l, /^\+CMGL: *([0-9]+),"([^"]*)","([^"]*)",[^,]*,"([^"]*)"/);
if (m) { cur = { id: m[1], via: 'at', num: m[3], text: '', time: m[4], state: m[2], dir: index(m[2], 'STO') >= 0 ? 'out' : 'in' }; push(L, cur); continue; }
if (cur && length(l) && l != 'OK' && !match(l, /^\+CM[GS] ERROR/)) cur.text += (length(cur.text) ? '\n' : '') + l;
}
return L;
}
function atok(o) { o = trim(o); return length(o) > 0 && index(o, 'ERROR: nessuno strumento') != 0; }
function via() { return mmok() ? 'mm' : (atok(at('AT')) ? 'at' : ''); }

let cmd = ARGV[0];
if (cmd == 'refresh') {
let ok = lock();
for (let i = 0; !ok && ARGV[1] == 'wait' && i < 30; i++) { sh('sleep 1'); ok = lock(); }
if (!ok) exit(0);
let v = mmok() ? 'mm' : '', mp = v == 'mm' ? mmpid() : '', L = [];
if (v == 'mm') L = mmread(mp);
else {
let o = sh('sh ' + W + '/at.sh AT AT+CMGF=1 ' + q('AT+CMGL="ALL"') + ' 2>/dev/null');
if (atok(o)) { v = 'at'; L = atread(o); }
}
writefile(OUT, sprintf('%J', { t: time(), via: v, mp: mp, send: v == 'mm' || has('sms_tool'), list: L }));
let sf = readfile(SEEN), first = sf == null || index(sf, 'k2\n') != 0, seen = {}, add = '', cur = {};
if (first && v == '') { rmdir(LOCK); exit(0); }
if (first) sf = 'k2\n';
for (let x in split(sf, '\n')) if (length(x)) seen[x] = 1;
let tn = (x) => { let d = match('' + x, /^([0-9]{2,4})[-\/]([0-9]{1,2})[-\/]([0-9]{1,2})[T, ]+([0-9]{1,2}):([0-9]{1,2})/); return d ? sprintf('%02d%02d%02d%02d%02d', +d[1] % 100, +d[2], +d[3], +d[4], +d[5]) : '' + x; };
for (let s in L) {
let k = s.num + '|' + tn(s.time) + '|' + substr(replace(trim(s.text), /[[:space:]]+/g, ' '), 0, 40);
if (s.dir == 'in') cur[k] = 1;
if (s.dir != 'in' || seen[k]) continue;
add += k + '\n';
let tx = join(' ¦ ', filter(map(split(replace(trim(s.text), '\r', ''), '\n'), (x) => trim(x)), (x) => length(x)));
if (!first) sh('sh ' + W + '/event.sh cron sms net ' + q('🌐 SMS ¦ ' + t('Da', 'From') + ' ' + replace(s.num, /[[:space:]|]+|¦/g, ' ') + ' ¦ ' + cut(tx, 3000)) + ' >/dev/null 2>&1');
}
if (first || length(add)) {
let K = filter(split(sf + add, '\n'), (x) => length(x) && x != 'k2'), n = length(K), o = 'k2\n';
for (let i = 0; i < n; i++) if (i >= n - 300 || cur[K[i]]) o += K[i] + '\n';
writefile(SEEN, o);
}
rmdir(LOCK);
exit(0);
}
if (cmd == 'send') {
let num = ARGV[1] ?? '', text = trim(readfile(ARGV[2] ?? '') ?? '');
if (!match(num, /^\+?[0-9]{3,20}$/) || !length(text)) { print('## ERRORE ' + t('numero o testo non validi', 'invalid number or text') + '\n'); exit(1); }
if (mmok()) {
let p = trim(match(sh('mmcli -m any ' + q("--messaging-create-sms=text='" + replace(text, "'", '’') + "',number='" + num + "'") + ' 2>&1'), /\/org\/freedesktop\/ModemManager1\/SMS\/[0-9]+/)?.[0] ?? '');
if (!length(p)) { print('## ERRORE ' + t('il modem non ha creato il messaggio', 'the modem did not create the message') + '\n'); exit(1); }
let o = sh('mmcli -s ' + q(p) + ' --send 2>&1');
if (index(o, 'successfully') < 0) { print('## ERRORE ' + trim(o) + '\n'); exit(1); }
} else if (has('sms_tool')) {
let port = trim(sh('sh ' + W + '/at.sh --port 2>/dev/null'));
let o = sh('sms_tool -d ' + q(port) + ' send ' + q(num) + ' ' + q(text) + ' 2>&1');
if (match(o, /error|fail/i)) { print('## ERRORE ' + trim(o) + '\n'); exit(1); }
} else { print('## ERRORE ' + t('per inviare serve il Gestore Del Modem o sms_tool (da Software)', 'sending needs the Modem Manager or sms_tool (from Software)') + '\n'); exit(1); }
print('## OK ' + t('SMS inviato a', 'SMS sent to') + ' ' + num + '\n');
sh('ucode ' + W + '/sms.uc refresh wait >/dev/null 2>&1');
exit(0);
}
if (cmd == 'delete') {
let id = '' + (ARGV[1] ?? '');
if (!match(id, /^[0-9]{1,6}$/)) { print('## ERRORE ' + t('messaggio non valido', 'invalid message') + '\n'); exit(1); }
let v = via(), e = '';
if (v == 'mm') {
let o = sh('mmcli -m any --messaging-delete-sms=' + id + ' 2>&1; echo "## $?"'), m = match(o, /## ([0-9]+)[[:space:]]*$/);
if (!m || m[1] != '0') e = trim(replace(o, /## [0-9]+[[:space:]]*$/, '')) || t('il modem non ha cancellato il messaggio', 'the modem did not delete the message');
}
else if (v == 'at') {
let o = at('AT+CMGD=' + id);
if (match(o, /ERROR/) || !match(o, /(^|[\r\n])OK[\r\n]*/)) e = trim(o) || t('il modem non risponde', 'the modem is not responding');
}
else e = t('modem non pronto', 'modem not ready');
if (length(e)) { print('## ERRORE ' + cut(e, 200) + '\n'); exit(1); }
let t0 = time();
sh('ucode ' + W + '/sms.uc refresh wait >/dev/null 2>&1');
let P = prev();
if ((stat(OUT)?.mtime ?? 0) >= t0 && P?.via == v && length(filter(P?.list ?? [], (x) => '' + x.id == id))) { print('## ERRORE ' + t('il messaggio è ancora nel modem', 'the message is still in the modem') + '\n'); exit(1); }
print('## OK ' + t('SMS eliminato', 'SMS deleted') + '\n');
exit(0);
}
print('uso: sms.uc refresh|send <numero> <file>|delete <id>\n');
exit(1);
