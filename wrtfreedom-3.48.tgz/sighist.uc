'use strict';
import { readfile, writefile, popen, stat, mkdir, rmdir, rename, open, unlink } from 'fs';

const W = '/usr/share/wrtfreedom', D24 = '/tmp/wf-sighist.24h', DR = '/tmp/wf-sighist.drops', TMP = '/tmp/wf-sighist.7d.json',
ETC = '/etc/wrtfreedom/sighist.json', LOCK = '/tmp/wf-sighist.lock', LDROPS = '/tmp/wf-line.drops';
const M = loadfile(getenv('WF_MODEMUC') ?? W + '/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function load(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
function num(x) { if (x == null || x === '') return null; let n = +x; return n != n ? null : n; }
function v(x) { return x == null ? '-' : sprintf('%.1f', x); }
function acc(a, x) {
if (x == null) return a;
if (!a) return [ x, 1, x, x ];
return [ a[0] + x, a[1] + 1, x < a[2] ? x : a[2], x > a[3] ? x : a[3] ];
}
function avg(a) { return a ? +sprintf('%.1f', a[0] / a[1]) : null; }
function summary(c) {
if (!c) return null;
let best = '', bn = -1;
for (let k in c.tc ?? {}) if (c.tc[k] > bn) { bn = c.tc[k]; best = k; }
return { h: c.h, n: c.n, tech: best, lr: c.lr ? [ avg(c.lr), c.lr[2], c.lr[3] ] : null, lq: avg(c.lq), ls: c.ls ? [ avg(c.ls), c.ls[2] ] : null,
nr: c.nr ? [ avg(c.nr), c.nr[2], c.nr[3] ] : null, nq: avg(c.nq), ns: c.ns ? [ avg(c.ns), c.ns[2] ] : null, drops: c.drops, down: c.down, nosig: c.nosig };
}
function persist(S) {
S.st = time();
mkdir('/etc/wrtfreedom');
writefile(ETC + '.t', sprintf('%J', { h: S.h, cur: S.cur, st: S.st })); rename(ETC + '.t', ETC);
}

let cmd = ARGV[0];
if (cmd != 'tick' && cmd != 'save') { print('uso: sighist.uc tick|save\n'); exit(1); }
if (cmd == 'save') { let i = 0; while (!mkdir(LOCK) && ++i < 20) sleep(1000); if (i >= 20) { rmdir(LOCK); mkdir(LOCK); } }
else if (!mkdir(LOCK)) { let s = stat(LOCK); if (s && time() - s.mtime < 300) exit(0); rmdir(LOCK); if (!mkdir(LOCK)) exit(0); }
function done(c) { rmdir(LOCK); exit(c); }

let S = load(TMP) ?? load(ETC) ?? { h: [] }, now = time(), hr = now - now % 3600;
S.h = S.h ?? [];
if (cmd == 'save') { if (length(S.h) || S.cur) persist(S); done(0); }

let I = M.id();
if (!I.present) done(0);
let ts = stat('/tmp/wf-modem.ts');
if (!ts || now - ts.mtime > 115) sh('( ' + M.readcmd() + ' ) >/dev/null 2>&1');
let st = M.state(), n = st.n, tech = M.tech(n);
let lr = num(n.lte?.rsrp), lq = num(n.lte?.rsrq), ls = num(n.lte?.sinr), nr = num(n.nr?.rsrp), nq = num(n.nr?.rsrq), ns = num(n.nr?.sinr);
let L = load('/tmp/wf-line.json'), up = (L && now - +(L.t ?? 0) < 30) ? (L.ok ? 1 : 0) : null;
let drops = [];
if (stat(LDROPS)?.size > 0 && rename(LDROPS, LDROPS + '.f')) { drops = filter(map(split(readfile(LDROPS + '.f') ?? '', '\n'), (x) => +x), (x) => x > 0); unlink(LDROPS + '.f'); }
if (length(drops)) { let f = open(DR, 'a'); if (f) { for (let d in drops) f.write(d + '\n'); f.close(); } }

if (S.cur && S.cur.h != hr) {
push(S.h, summary(S.cur));
S.h = filter(S.h, (x) => x && x.h > now - 7 * 86400);
S.cur = null;
let keep = (f) => { let o = ''; for (let l in split(readfile(f) ?? '', '\n')) if (length(l) && +split(l, ' ')[0] > now - 86400) o += l + '\n'; writefile(f + '.t', o); rename(f + '.t', f); };
keep(D24); keep(DR);
if (!S.st || now - S.st >= 6 * 3600) persist(S);
}
let c = S.cur ?? { h: hr, n: 0, tc: {}, drops: 0, down: 0, nosig: 0 };
c.n++;
if (length(tech)) c.tc[tech] = (c.tc[tech] ?? 0) + 1; else c.nosig++;
c.lr = acc(c.lr, lr); c.lq = acc(c.lq, lq); c.ls = acc(c.ls, ls); c.nr = acc(c.nr, nr); c.nq = acc(c.nq, nq); c.ns = acc(c.ns, ns);
c.drops += length(drops);
if (up === 0) c.down++;
S.cur = c;
S.now = summary(c);
S.t = now;
let f = open(D24, 'a');
if (f) { f.write(join(' ', [ now, length(tech) ? tech : '-', v(lr), v(lq), v(ls), v(nr), v(nq), v(ns), up == null ? '-' : up ]) + '\n'); f.close(); }
writefile(TMP + '.t', sprintf('%J', S)); rename(TMP + '.t', TMP);
done(0);
