#!/usr/bin/ucode
'use strict';
import { readfile, writefile, unlink, popen, stat, rename, mkdir, rmdir } from 'fs';

const W = '/usr/share/wrtfreedom', IPF = '/tmp/wf-vpnip.json', STF = '/tmp/wf-vpn.json', USEF = '/tmp/wf-vpnuse.json', USEP = '/etc/wrtfreedom/vpnuse.json';
const WSF = '/etc/wrtfreedom/vpnws.json';
const REQ = '/tmp/wf-vpnreq.json', REQRX = /^\/tmp\/wf-vpnreq(\.[0-9a-f]{1,16})?\.json$/, LEAKF = '/tmp/wf-vpnleak.json', KEY = /^[A-Za-z0-9+\/]{42,43}=$/;
const NORD = 'https://api.nordvpn.com/v1/', MULL = 'https://api.mullvad.net/', PIACA = W + '/pia-ca.crt', AZIRE = 'https://api.azirevpn.com/v3/', IVPN = 'https://api.ivpn.net/';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function cutb(s, n) {
s = '' + s;
if (length(s) <= n) return s;
while (n > 0 && (ord(s, n) & 192) == 128) n--;
return substr(s, 0, n);
}
function cut(s, n) {
s = '' + s;
if (length(s) <= n) return s;
let c = cutb(s, n - 3), sp = rindex(c, ' '), lf = rindex(c, '\n');
if (lf > sp) sp = lf;
if (sp > length(c) * 0.8) c = substr(c, 0, sp);
return rtrim(c) + '…';
}
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function ug(k) { return trim(sh('uci -q get ' + k + ' 2>/dev/null')); }
function rd(f) { try { return json(readfile(f) ?? 'null'); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
let EN = null;	/* lingua: la imposta cfg() (ui.lang), niente uci get a parte */
function say(s) { print(s + '\n'); }
const CURL = stat('/usr/bin/curl') != null;
function kfile(s) {
let r = readfile('/dev/urandom', 8) ?? '', n = '';
for (let i = 0; i < 8; i++) n += sprintf('%02x', ord(r, i) ?? (time() + i) % 256);
mkdir('/tmp/.wf-k', 448);
let f = '/tmp/.wf-k/' + n;
writefile(f, s);
return f;
}
function cq(s) { return '"' + replace(replace(replace(replace('' + s, '\\', '\\\\'), '"', '\\"'), '\n', '\\n'), '\r', '\\r') + '"'; }
function get(url, o) {
o = o ?? {};
let c, kf = null;
if (CURL) {
let D = '';
for (let k, v in (o.data ?? {})) D += 'data-urlencode = ' + cq(k + '=' + v) + '\n';
if (o.body != null) D += 'data = ' + cq(o.body) + '\n';
if (o.hide) D += 'url = ' + cq(url) + '\n';
if (o.auth || o.bearer || length(D))
kf = kfile((o.auth ? 'user = ' + cq(o.auth) + '\n' : '') + (o.bearer ? 'header = ' + cq('Authorization: Bearer ' + o.bearer) + '\n' : '') + D);
c = 'curl -s -m 15 ' + (kf ? '-K ' + q(kf) + ' ' : '') + (o.via ? '--interface ' + q(o.via) + ' ' : '') + (o.code ? "-w '\\n%{http_code}' " : '') + (o.extra ?? '') + (o.hide ? '' : q(url));
}
else if (o.auth || o.bearer || o.data || o.body != null || o.hide) return o.code ? { code: 0, r: null } : null;
else c = 'uclient-fetch -q -T 15 -O - ' + q(url);
let r = sh(c + ' 2>/dev/null'), hc = 0;
if (kf) unlink(kf);
if (o.code) { let i = rindex(r, '\n'); hc = int(i >= 0 ? substr(r, i + 1) : r) || 0; r = i >= 0 ? substr(r, 0, i) : ''; }
if (!o.raw) { try { r = json(r); } catch (e) { r = null; } }
return o.code ? { code: hc, r: r } : r;
}
function urlenc(s) {
let o = '';
for (let i = 0; i < length(s); i++) { let c = ord(s, i); o += ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 46 || c == 95 || c == 126) ? chr(c) : sprintf('%%%02X', c); }
return o;
}
function call(o) { try { return json(sh('ubus -t 30 call wrtfreedom vpnout ' + q(sprintf('%J', o)) + ' 2>/dev/null')); } catch (e) { return null; } }
function ev(type, txt, al, quiet) { sh((quiet ? 'WF_Q=1 ' : '') + 'sh ' + W + '/event.sh cron ' + type + ' ' + (al === false ? 'info' : 'net') + ' ' + q(txt) + ' >/dev/null 2>&1'); }
function ob(C, k, d) { let v = (C.vpnout ?? {})[k]; return v == null || v == '' ? d : v == '1'; }
function today() { let n = localtime(time()); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
const EVF = '/etc/wrtfreedom/vpnev.json', EVT = '/tmp/wf-vpnev.json';
function evrec(k, x) {
let L = rd(EVT) ?? rd(EVF) ?? [];
push(L, { t: time(), d: today(), k: k, x: x });
while (length(L) > 40) shift(L);
writefile(EVT + '.t', sprintf('%J', L)); rename(EVT + '.t', EVT);
}
function evsave() {
let a = readfile(EVT);
if (a != null && a != readfile(EVF)) { writefile(EVF + '.t', a); rename(EVF + '.t', EVF); }
}
function usesave(U) { let s = sprintf('%J', U); if (s != readfile(USEP)) { writefile(USEP + '.t', s); rename(USEP + '.t', USEP); } }
function ukey(sec, o, v) { let f = kfile('set wrtfreedom.' + sec + '.' + o + '=' + q(v) + '\n'); return 'uci -q batch < ' + f + '; rm -f ' + f + '; '; }
function pubkey(priv) { let f = kfile(priv + '\n'); return trim(sh('wg pubkey < ' + f + ' 2>/dev/null; rm -f ' + f)); }
function newkey() { return trim(sh('wg genkey 2>/dev/null')); }
const CFGC = '/tmp/.wf-k/vpncfg.json';
function cfgsig() {
let r = '';
for (let f in [ '/etc/config/wrtfreedom', '/tmp/.uci/wrtfreedom' ]) { let s = stat(f); r += (s ? s.mtime + ':' + s.size + ':' + s.inode : '-') + '|'; }
return r;
}
function cfg() {
let k = cfgsig(), c = substr(k, 0, 2) == '-|' ? null : rd(CFGC);	/* senza il file (mai sul router) niente ricordo */
if (type(c) == 'object' && c.k == k && type(c.C) == 'object' && time() - +(c.t ?? 0) < 300 && +(c.t ?? 0) <= time()) {
EN = (c.C.ui ?? {}).lang == 'en';
return c.C;
}
let C = {};
for (let l in split(sh('uci -q show wrtfreedom'), '\n')) {
let m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)=([A-Za-z0-9_]+)$/);
if (m) { C[m[1]] = C[m[1]] ?? {}; C[m[1]]['.type'] = m[2]; continue; }
m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)=(.*)$/);
if (!m) continue;
let vals = [], s = m[3], v = match(s, /'([^']*)'/g);
for (let x in (v ?? [])) push(vals, x[1]);
C[m[1]] = C[m[1]] ?? {};
C[m[1]][m[2]] = length(vals) > 1 ? vals : (vals[0] ?? '');
}
EN = (C.ui ?? {}).lang == 'en';
if (substr(k, 0, 2) != '-|' && length(keys(C)) && cfgsig() == k) { mkdir('/tmp/.wf-k', 448); wj(CFGC, { k: k, t: time(), C: C }); }
return C;
}
function t(it, en) { if (EN == null) cfg(); return EN ? en : it; }
function vh(R, w, s) { return (w ? '⚠️ ' : '🔐 ') + join(' ¦ ', [ s ?? t('Client VPN', 'VPN Client'), ...filter(R, (r) => length(r)) ]); }
function arr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }
function tuns(C) {
let r = [];
for (let k, s in C) if (s['.type'] == 'vpntun') push(r, { id: k, n: +(s.n ?? 0), prof: s.prof ?? '', on: s.on != '0', fb: s.fb == '1', mode: s.mode ?? '', devs: arr(s.devs) });
return sort(r, (a, b) => a.n - b.n);
}
function ifn(n) { return n == 0 ? 'wgout' : 'wgo' + n; }
function pingok(I, ip) {
try { return system([ 'ping', '-c', '2', '-W', '2', '-I', I, ip ]) == 0; }
catch (e) { return trim(sh('ping -c 2 -W 2 -I ' + q(I) + ' ' + q(ip) + ' >/dev/null 2>&1 && echo 1')) == '1'; }
}
function ifopt(I) {
let F = readfile((getenv('WF_CFGDIR') ?? '/etc/config/') + 'network');
if (F == null || stat('/tmp/.uci/network')) return { disabled: ug('network.' + I + '.disabled'), auto: ug('network.' + I + '.auto') };
let R = {}, cur = false;
for (let l in split(F, '\n')) {
if (match(l, /^[ \t]*config[ \t]/)) { let c = match(l, /^[ \t]*config[ \t]+[^ \t]+[ \t]+['"]?([A-Za-z0-9_]+)['"]?([ \t].*)?$/); cur = c != null && c[1] == I; continue; }
if (!cur) continue;
let m = match(l, /^[ \t]*option[ \t]+(disabled|auto)[ \t]+['"]?([^'" \t]*)['"]?/);
if (m) R[m[1]] = m[2];
}
return R;
}
let UBC = null;
function ifoff(I) {
let O = ifopt(I);
if (O.disabled == '1' || O.auto == '0') return true;
let U = null;
if (UBC == null) { try { UBC = require('ubus').connect() ?? false; } catch (e) { UBC = false; } }
if (UBC) U = UBC.call('network.interface.' + I, 'status', {});
else try { U = json(sh('ubus call network.interface.' + I + ' status 2>/dev/null') || '{}'); } catch (e) {}
return U?.autostart === false;
}
function inwin(s, lt) {
let hm = sprintf('%02d:%02d', lt.hour, lt.min), d = lt.wday == 0 ? 7 : lt.wday, yd = d == 1 ? 7 : d - 1, days = '' + (s.days ?? ''), f = s['from'] ?? '', to = s.to ?? '';
if (!match(f, /^[0-9]{2}:[0-9]{2}$/) || !match(to, /^[0-9]{2}:[0-9]{2}$/)) return false;
if (f < to) return index(days, '' + d) >= 0 && hm >= f && hm < to;
if (f > to) return (index(days, '' + d) >= 0 && hm >= f) || (index(days, '' + yd) >= 0 && hm < to);
return false;
}
function wsfix(C, m0, raise) {
let Ws = rd(WSF);
if (type(Ws) != 'object' || !length(keys(Ws)) || +((C.vpnout ?? {}).pause_until ?? 0)) return false;
let lt = localtime(time()), up = false, ch = false;
for (let k in keys(Ws)) {
let s = C[k], live = s && s['.type'] == 'vpnsched' && s.on != '0' && s.act != 'place' && inwin(s, lt);
if (m0 && live && !m0.on) continue;
delete Ws[k]; ch = true;
if (m0 && !m0.on && !live) up = true;
}
if (ch) { if (length(keys(Ws))) wj(WSF, Ws); else unlink(WSF); }
if (!up || !raise || length(keys(Ws))) return false;
let r = call({ action: 'topts', tid: m0.id, on: true });
return !!r && !r.error;
}
function reqrun(R, bg) {
let f = '/tmp/wf-vpnreq.' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '' + time(), /[^0-9a-f]/g, ''), 0, 12) + '.json';
wj(f, R);
sh(bg ? '( ucode ' + W + '/vpnctl.uc connect ' + f + ' ) >/dev/null 2>&1 &' : 'ucode ' + W + '/vpnctl.uc connect ' + f + ' >/dev/null 2>&1');
}
function lineoff() { let j = rd('/tmp/wf-line.json') ?? {}; return j.ok === false && j.active != 'backup'; }
function linecc() {
let f = '/tmp/wf-linecc', s = stat(f);
if (s && time() - s.mtime < 86400) return trim(readfile(f) ?? '');
let y = get(NORD + 'helpers/ips/insights') ?? {}, cc = match('' + (y.country_code ?? ''), /^[A-Z]{2}$/) ? y.country_code : '';
if (length(cc)) writefile(f, cc);
return cc;
}

function fastest(L) {
if (length(L) <= 1) return L[0];
let f = '/tmp/wf-vpnping.' + time(), c = '';
for (let i = 0; i < length(L); i++) c += '( ping -c 3 -W 1 -q ' + q(L[i].ip) + " 2>/dev/null | sed -n 's|.*= [0-9.]*/\\([0-9.]*\\)/.*|" + i + " \\1|p' >> " + f + ' ) & ';
sh(c + 'wait');
let best = null, bt = 1e9;
for (let l in split(readfile(f) ?? '', '\n')) { let x = split(trim(l), ' '); if (length(x) == 2 && +x[1] < bt) { bt = +x[1]; best = +x[0]; } }
unlink(f);
if (best != null) { L[best].ms = bt; return L[best]; }
return L[0];
}

const P = {
nord: {
login: function(C) {
if (!CURL) return t('Serve curl: installalo da Software', 'curl is needed: install it from Software');
let r = get(NORD + 'users/services/credentials', { auth: 'token:' + ((C.va_nord ?? {}).token ?? '') });
if (r && match('' + (r.nordlynx_private_key ?? ''), KEY)) { sh(ukey('va_nord', 'key', r.nordlynx_private_key) + 'uci commit wrtfreedom'); return null; }
if (r) { sh('uci -q delete wrtfreedom.va_nord; uci commit wrtfreedom'); return t('NordVPN ha rifiutato il token (non valido, scaduto o revocato): generane uno nuovo e controlla che l\'abbonamento sia attivo', 'NordVPN rejected the token (invalid, expired or revoked): generate a new one and check the subscription is active'); }
return t('NordVPN non risponde: controlla la connessione e riprova', 'NordVPN is not responding: check the connection and try again');
},
places: function() {
let out = [];
for (let c in arr(get(NORD + 'servers/countries'))) if (+c.serverCount > 0 && match(c.code ?? '', /^[A-Z]{2}$/)) push(out, { id: '' + c.id, name: c.name, cc: c.code, n: c.serverCount });
return out;
},
servers: function(C, place, skip, n) {
let out = [];
let cf = place == 'auto' ? '' : '&filters%5Bcountry_id%5D=' + int(+place);
for (let s in arr(get(NORD + 'servers/recommendations?filters%5Bservers_technologies%5D%5Bidentifier%5D=wireguard_udp' + cf + '&limit=' + (n ?? 8)))) {
let pub = null;
for (let tc in (s.technologies ?? [])) if (tc.identifier == 'wireguard_udp') for (let m in (tc.metadata ?? [])) if (m.name == 'public_key') pub = m.value;
let loc = ((s.locations ?? [])[0] ?? {}).country ?? {};
if (s.status == 'online' && s.hostname != skip && s.station != skip && match(pub ?? '', KEY) && match(s.station ?? '', /^[0-9.]+$/))
push(out, { ip: s.station, pub: pub, host: s.hostname, name: s.name ?? s.hostname, cc: loc.code ?? '', city: (loc.city ?? {}).name ?? '', load: s.load, id: s.id });
}
return out;
},
conf: function(C, s) {
return '[Interface]\nPrivateKey = ' + (C.va_nord ?? {}).key + '\nAddress = 10.5.0.2/32\nDNS = 103.86.96.100, 103.86.99.100\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.ip + ':51820\n';
}
},
mullvad: {
login: function(C) {
if (!CURL) return t('Serve curl: installalo da Software', 'curl is needed: install it from Software');
let A = C.va_mullvad ?? {}, priv = match(A.priv ?? '', KEY) ? A.priv : newkey();
let x = get(MULL + 'wg', { data: { account: A.account ?? '', pubkey: pubkey(priv) }, raw: true, code: true }), r = trim(x.r ?? '');
let m = match(r, /^([0-9.]+\/[0-9]+)/);
if (m) { sh(ukey('va_mullvad', 'priv', priv) + 'uci set wrtfreedom.va_mullvad.addr=' + q(m[1]) + '; uci commit wrtfreedom'); return null; }
if (match(r, /too many/i)) return t('Account Mullvad con già 5 chiavi: togline una dal sito mullvad.net e riprova', 'Mullvad account already has 5 keys: remove one on mullvad.net and try again');
if (x.code == 401 || x.code == 403 || x.code == 404 || match(r, /invalid.{0,12}account|account.{0,24}(invalid|not found|does not exist|expired|unknown)|no such account/i)) {
sh('uci -q delete wrtfreedom.va_mullvad; uci commit wrtfreedom');
return t('Account Mullvad non valido o scaduto', 'Mullvad account not valid or expired') + (length(r) ? ' (' + cut(r, 80) + ')' : '');
}
if (x.code) return t('Mullvad non ha accettato la richiesta, riprova tra poco', 'Mullvad did not accept the request, try again shortly') + ' (HTTP ' + x.code + (length(r) && substr(r, 0, 1) != '<' ? ': ' + cut(r, 80) : '') + ')';
return t('Mullvad non risponde: controlla la connessione e riprova', 'Mullvad is not responding: check the connection and try again');
},
places: function() {
let d = get(MULL + 'public/relays/wireguard/v2'), L = {}, out = [];
for (let r in arr(((d ?? {}).wireguard ?? {}).relays)) if (r.active) { let loc = r.location; L[loc] = (L[loc] ?? 0) + 1; }
for (let k, n in L) { let x = ((d ?? {}).locations ?? {})[k] ?? {}; push(out, { id: k, name: x.country ?? k, cc: uc(split(k, '-')[0]), city: x.city ?? '', n: n }); }
return out;
},
servers: function(C, place, skip, n) {
let d = get(MULL + 'public/relays/wireguard/v2'), LOC = (d ?? {}).locations ?? {}, out = [], R = arr(((d ?? {}).wireguard ?? {}).relays);
let want = place == 'auto' ? lc(linecc()) + '-' : place, okp = (l) => place == 'auto' ? substr(l, 0, 3) == want : l == place;
if (place == 'auto' && !length(filter(R, (r) => r.active && okp(r.location)))) { want = 'se-'; }
for (let r in R)
if (r.active && okp(r.location) && r.ipv4_addr_in != skip && match(r.public_key ?? '', KEY))
push(out, { ip: r.ipv4_addr_in, pub: r.public_key, host: r.hostname, name: r.hostname, cc: uc(split(r.location, '-')[0]), city: (LOC[r.location] ?? {}).city ?? '' });
return slice(out, 0, n ?? 8);
},
conf: function(C, s) {
let A = C.va_mullvad ?? {};
return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + A.addr + '\nDNS = 10.64.0.1\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.ip + ':51820\n';
}
},
pia: {
tok: function(C) {
let A = C.va_pia ?? {}, x = get('https://www.privateinternetaccess.com/api/client/v2/token', { data: { username: A.user ?? '', password: A.pass ?? '' }, code: true });
return { token: x.r && x.r.token ? x.r.token : null, deny: x.code == 401 || x.code == 403 };
},
token: function(C) { return this.tok(C).token; },
login: function(C) {
if (!CURL) return t('Serve curl: installalo da Software', 'curl is needed: install it from Software');
let k = this.tok(C);
if (k.token) {
let A = C.va_pia ?? {};
if (!match(A.priv ?? '', KEY)) sh(ukey('va_pia', 'priv', newkey()) + 'uci commit wrtfreedom');
return null;
}
if (!k.deny) return t('PIA non risponde: controlla la connessione e riprova', 'PIA is not responding: check the connection and try again');
sh('uci -q delete wrtfreedom.va_pia; uci commit wrtfreedom');
return t('Utente o password di PIA non validi, o abbonamento scaduto', 'PIA username or password not valid, or subscription expired');
},
list: function() {
let r = get('https://serverlist.piaservers.net/vpninfo/servers/v6', { raw: true });
try { return json(split(r, '\n')[0]); } catch (e) { return null; }
},
places: function() {
let out = [];
for (let g in arr((this.list() ?? {}).regions)) if (!g.offline && length(arr((g.servers ?? {}).wg)))
push(out, { id: g.id, name: g.name, cc: uc(g.country ?? ''), n: length(g.servers.wg) });
return out;
},
servers: function(C, place, skip, n) {
let out = [];
let G = arr((this.list() ?? {}).regions), cc = place == 'auto' ? linecc() : '';
if (place == 'auto' && !length(filter(G, (g) => uc(g.country ?? '') == cc && !g.offline))) cc = 'CH';
for (let g in G) if (place == 'auto' ? uc(g.country ?? '') == cc && !g.offline : g.id == place)
for (let s in arr((g.servers ?? {}).wg)) if (s.ip != skip) push(out, { ip: s.ip, host: s.cn, name: g.name, cc: uc(g.country ?? ''), city: '' });
return slice(out, 0, n ?? 8);
},
conf: function(C, s) {
let tk = this.token(C), A = C.va_pia ?? {};
if (!tk) return null;
let r = get('https://' + s.host + ':1337/addKey?pt=' + urlenc(tk) + '&pubkey=' + urlenc(pubkey(A.priv)),
{ hide: true, extra: '--connect-to ' + q(s.host + '::' + s.ip + ':') + ' --cacert ' + q(PIACA) + ' ' });
if (!r || r.status != 'OK') return null;
return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + r.peer_ip + '/32\nDNS = ' + ((r.dns_servers ?? [])[0] ?? '10.0.0.243') + '\n\n[Peer]\nPublicKey = ' + r.server_key + '\nEndpoint = ' + r.server_ip + ':' + r.server_port + '\n';
}
},
azire: {
login: function(C) {
if (!CURL) return t('Serve curl: installalo da Software', 'curl is needed: install it from Software');
let A = C.va_azire ?? {}, priv = match(A.priv ?? '', KEY) ? A.priv : newkey();
let r = get(AZIRE + 'ips', { bearer: A.token ?? '', extra: '-X POST -H ' + q('Content-Type: application/json') + ' -d ' + q(sprintf('%J', { key: pubkey(priv) })) + ' ' });
let x = (r ?? {}).data ?? r ?? {}, a = '' + (x.ipv4_address ?? '');
if (match(a, /^[0-9.]+(\/[0-9]+)?$/)) {
if (index(a, '/') < 0) a += '/32';
sh(ukey('va_azire', 'priv', priv) + 'uci set wrtfreedom.va_azire.addr=' + q(a) + '; uci set wrtfreedom.va_azire.dns=' + q(arr(x.dns)[0] ?? '91.231.153.2') + '; uci set wrtfreedom.va_azire.ipid=' + q('' + (x.id ?? '')) + '; uci commit wrtfreedom');
return null;
}
if (r) { sh('uci -q delete wrtfreedom.va_azire; uci commit wrtfreedom'); return t('AzireVPN ha rifiutato il token: creane uno nuovo nel Manager', 'AzireVPN rejected the token: create a new one in the Manager') + (r.message ? ' (' + substr(r.message, 0, 80) + ')' : ''); }
return t('AzireVPN non risponde: controlla la connessione e riprova', 'AzireVPN is not responding: check the connection and try again');
},
list: function() { return arr((get(AZIRE + 'locations') ?? {}).locations); },
places: function() {
let out = [];
for (let l in this.list()) if (match(l.name ?? '', /^[a-z0-9-]{2,20}$/)) push(out, { id: l.name, name: l.country ?? l.name, cc: uc(l.iso ?? ''), city: l.city ?? '', n: 1 });
return out;
},
servers: function(C, place, skip, n) {
let L = this.list(), cc = place == 'auto' ? lc(linecc()) : '';
if (place == 'auto' && !length(filter(L, (l) => l.iso == cc))) cc = 'se';
let out = [];
for (let l in L) if ((place == 'auto' ? l.iso == cc : l.name == place) && l.pool != skip && match(l.pubkey ?? '', KEY))
push(out, { ip: l.pool, host: l.pool, pub: l.pubkey, name: l.city ?? l.name, cc: uc(l.iso ?? ''), city: l.city ?? '' });
return slice(out, 0, n ?? 8);
},
conf: function(C, s) {
let A = C.va_azire ?? {};
return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + A.addr + '\nDNS = ' + (A.dns || '91.231.153.2') + '\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.host + ':51820\n';
}
},
ivpn: {
login: function(C) {
if (!CURL) return t('Serve curl: installalo da Software', 'curl is needed: install it from Software');
let A = C.va_ivpn ?? {}, priv = match(A.priv ?? '', KEY) ? A.priv : newkey();
let r = get(IVPN + 'v4/session/new', { body: sprintf('%J', { username: A.account ?? '', wg_public_key: pubkey(priv), force: false }), extra: '-H ' + q('Content-Type: application/json') + ' ' });
let ip = '' + (((r ?? {}).wireguard ?? {}).ip_address ?? '');
if (r && r.status == 200 && r.token && match(ip, /^[0-9.]+$/)) {
sh(ukey('va_ivpn', 'priv', priv) + ukey('va_ivpn', 'stoken', r.token) + 'uci set wrtfreedom.va_ivpn.addr=' + q(ip + '/32') + '; uci commit wrtfreedom');
return null;
}
if (r && r.status) {
sh('uci -q delete wrtfreedom.va_ivpn; uci commit wrtfreedom');
return r.status == 602 ? t('Account IVPN con troppi dispositivi collegati: esci da uno dal sito ivpn.net e riprova', 'IVPN account has too many devices: sign out one on ivpn.net and try again')
: t('Numero di account IVPN non valido o abbonamento scaduto', 'IVPN account ID not valid or subscription expired') + (r.message ? ' (' + substr(r.message, 0, 80) + ')' : '');
}
return t('IVPN non risponde: controlla la connessione e riprova', 'IVPN is not responding: check the connection and try again');
},
list: function() { return arr((get(IVPN + 'v5/servers.json') ?? {}).wireguard); },
pid: function(g) { return replace('' + (g.gateway ?? ''), /\.wg\.ivpn\.net$/, ''); },
places: function() {
let out = [];
for (let g in this.list()) { let id = this.pid(g); if (match(id, /^[a-z0-9-]{2,20}$/)) push(out, { id: id, name: g.country ?? id, cc: uc(g.country_code ?? ''), city: g.city ?? '', n: length(arr(g.hosts)) }); }
return out;
},
servers: function(C, place, skip, n) {
let G = this.list(), cc = place == 'auto' ? linecc() : '';
if (place == 'auto' && !length(filter(G, (g) => uc(g.country_code ?? '') == cc))) cc = 'CH';
let out = [];
for (let g in G) if (place == 'auto' ? uc(g.country_code ?? '') == cc : this.pid(g) == place)
for (let h in arr(g.hosts)) if (h.host != skip && match(h.public_key ?? '', KEY))
push(out, { ip: h.host, host: h.hostname, pub: h.public_key, name: h.hostname, cc: uc(g.country_code ?? ''), city: g.city ?? '', load: h.load != null ? int(h.load + 0.5) : null });
return slice(out, 0, n ?? 8);
},
conf: function(C, s) {
let A = C.va_ivpn ?? {};
return '[Interface]\nPrivateKey = ' + A.priv + '\nAddress = ' + A.addr + '\nDNS = 172.16.0.1\n\n[Peer]\nPublicKey = ' + s.pub + '\nEndpoint = ' + s.ip + ':2049\n';
}
}
};

const ACCF = '/tmp/wf-vpnacc.json', PN = { nord: 'NordVPN', mullvad: 'Mullvad', pia: 'Private Internet Access', azire: 'AzireVPN', ivpn: 'IVPN' };
function acccheck() {
let C = cfg(), out = rd(ACCF) ?? {}, now = time();
for (let p in keys(PN)) {
let A = C['va_' + p];
if (!A) { delete out[p]; continue; }
let r = { t: now, ok: null, exp: '' };
if (p == 'nord') {
let L = get(NORD + 'users/services', { auth: 'token:' + (A.token ?? '') });
if (type(L) == 'array') { r.ok = true; for (let s in L) if ((s.service ?? {}).identifier == 'vpn') r.exp = substr(s.expires_at ?? '', 0, 10); }
else if (L && L.errors) r.ok = false;
}
else if (p == 'mullvad') {
let tk = get(MULL + 'auth/v1/token', { body: sprintf('%J', { account_number: A.account ?? '' }), extra: '-H ' + q('Content-Type: application/json') + ' ' });
if (tk && tk.access_token) {
let me = get(MULL + 'accounts/v1/accounts/me', { bearer: tk.access_token });
r.ok = true; r.exp = substr((me ?? {}).expiry ?? '', 0, 10);
}
else if (tk && tk.code) r.ok = false;
}
else if (p == 'pia') { let k = P.pia.tok(C); r.ok = k.token ? true : k.deny ? false : null; }
else if (p == 'azire' && CURL) {
let L = get(AZIRE + 'ips', { bearer: A.token ?? '' });
if (L && L.message) r.ok = false; else if (L) r.ok = true;
}
else if (p == 'ivpn' && CURL) {
let x = get(IVPN + 'v4/session/status', { body: sprintf('%J', { session_token: A.stoken ?? '' }), extra: '-H ' + q('Content-Type: application/json') + ' ' });
if (x && x.status == 200) { r.ok = true; let u = +((x.service_status ?? {}).active_until ?? 0); if (u > 0) r.exp = trim(sh('date -d @' + int(u) + ' +%Y-%m-%d 2>/dev/null')); }
else if (x && x.status) r.ok = false;
}
let o = out[p] ?? {}, al = ob(C, 'al_exp', true), said = o.said ?? (o.ok === false);
let act = length(filter(tuns(C), (x) => x.on && (C[x.prof] ?? {}).prov == p)) > 0;
if (r.ok === true) said = false;
if (r.ok === false && !said && act) {
said = true;
ev('vpnacc', vh([ t('Accesso rifiutato', 'Access rejected'), t('Rifai l\'accesso nell\'app', 'Sign in again in the app') ], true, PN[p]), al);
}
if (length(r.exp)) {
let d = trim(sh('date -d ' + q(r.exp + ' 00:00') + ' +%s 2>/dev/null')), left = length(d) ? int((+d - now) / 86400) : 999;
if (left <= 7 && o.warn != r.exp) { r.warn = r.exp; ev('vpnacc', vh([ t('Abbonamento in scadenza', 'Subscription expiring'), t('Scade il ', 'Expires on ') + r.exp ], false, PN[p]), al); }
else r.warn = o.warn;
}
if (r.ok == null) { r.ok = o.ok; r.exp = r.exp || o.exp; r.err = 'net'; }
r.said = said;
out[p] = r;
}
wj(ACCF, out);
}
let cmd = ARGV[0] ?? '';

if (cmd == 'login') {
let p = ARGV[1] ?? '', S = P[p];
if (!S) { say('❌ ' + t('Servizio non valido', 'Invalid service')); exit(1); }
say('🔐 ' + t('Controllo l\'accesso…', 'Checking access…'));
let e = S.login(cfg());
if (e) { say('❌ ' + e); exit(1); }
acccheck();
say('✅ ' + t('Accesso riuscito', 'Signed in'));
exit(0);
}

if (cmd == 'acccheck') { acccheck(); exit(0); }

if (cmd == 'places') {
let p = ARGV[1] ?? '', S = P[p];
if (!S) exit(1);
let L = S.places();
if (length(L)) wj('/tmp/wf-vpnplaces-' + p + '.json', sort(L, (a, b) => a.name + a.city < b.name + b.city ? -1 : 1));
exit(0);
}

if (cmd == 'rotate') {
let C = cfg();
for (let x in tuns(C)) {
let pr = C[x.prof] ?? {};
if (!x.on || !P[pr.prov] || !length(pr.place ?? '')) continue;
reqrun({ tid: x.id, n: x.n, prov: pr.prov, place: pr.place, skip: pr.prov == 'pia' ? '' : (pr.host ?? ''), why: 'rot' });
}
exit(0);
}

if (cmd == 'connect') {
let RF = match(ARGV[1] ?? '', REQRX) ? ARGV[1] : REQ, R = rd(RF) ?? {}, S = P[R.prov], C = cfg();
let fin = (c) => { if (RF != REQ) unlink(RF); exit(c); };
if (!S) { say('❌ ' + t('Richiesta non valida', 'Invalid request')); fin(1); }
say('🌍 ' + t('Cerco i server…', 'Looking for servers…'));
let L = S.servers(C, R.place, R.skip ?? '', length(R.host ?? '') ? 20 : 8), s = null;
if (length(R.host ?? '')) L = filter(L, (y) => y.host == R.host || y.ip == R.host);
if (!length(L)) { say('❌ ' + t(length(R.host ?? '') ? 'Server non disponibile: scegline un altro' : 'Nessun server disponibile in questo paese', length(R.host ?? '') ? 'Server not available: choose another one' : 'No server available in this country')); fin(1); }
let LD = filter(L, (y) => y.load != null);
if ((C.vpnout ?? {}).pick == 'load' && length(LD) && length(L) > 1) { s = sort(LD, (a, b) => a.load - b.load)[0]; say('📉 ' + t('Server meno carico', 'Least loaded server') + ': ' + s.load + '%'); }
else {
if (length(L) > 1) say('⏱️ ' + t('Misuro la velocità di risposta di ' + length(L) + ' server…', 'Measuring the response time of ' + length(L) + ' servers…'));
s = fastest(L);
}
let conf = S.conf(C, s);
if (!conf) { say('❌ ' + t('Il server non ha accettato il collegamento: riprova', 'The server did not accept the connection: try again')); fin(1); }
let r = call({ action: 'setprof', req: RF, conf: conf, cc: s.cc, city: s.city, sname: s.host, name: R.prov == 'pia' ? s.name : '', pname: R.pname ?? '', srvid: s.id != null ? '' + s.id : '' });
if (!r || r.error) { say('❌ ' + (r ? r.error : t('configurazione non riuscita', 'configuration failed'))); fin(1); }
say('✅ ' + s.name + (length(s.city) ? ' · ' + s.city : '') + (s.ms != null ? ' · ' + int(s.ms) + ' ms' : '') + (s.load != null ? ' · ' + t('carico', 'load') + ' ' + s.load + '%' : ''));
let why = { load: t('carico alto', 'high load'), ping: t('ping alto', 'high ping'), down: t('non rispondeva', 'not responding'), ip: t('nuovo IP', 'new IP'), sched: t('orario', 'schedule') }[R.why ?? ''];
if (why) {
let nm = s.name + (length(s.city) ? ' · ' + s.city : '');
evrec('sw', nm + ' · ' + why);
ev('vpnsvc_sw', vh([ t('Nuovo server', 'New server') + ': ' + why, nm ]), ob(C, 'al_sw', false));
}
fin(0);
}

if (cmd == 'srvlist') {
let p = ARGV[1] ?? '', pl = ARGV[2] ?? '', S = P[p];
if (!S || !match(pl, /^[A-Za-z0-9_-]{1,40}$/)) exit(1);
let L = S.servers(cfg(), pl, '', 20);
if (length(L)) wj('/tmp/wf-vpnsrv-' + p + '-' + pl + '.json', map(L, (y) => ({ host: y.host, name: y.name, city: y.city, cc: y.cc, load: y.load })));
exit(0);
}

if (cmd == 'boot') {
let C = cfg(), m0 = filter(tuns(C), (x) => x.n == 0)[0], V = C.vpnout ?? {};
if (!length(tuns(C))) exit(0);
for (let i = 0; i < 60 && !length(trim(sh('ubus list wrtfreedom 2>/dev/null'))); i++) sh('sleep 2');
let pu = +(V.pause_until ?? 0);
if (pu > time()) exit(0);
if (pu) {
call({ action: 'resume' });
C = cfg(); V = C.vpnout ?? {}; m0 = filter(tuns(C), (x) => x.n == 0)[0];
}
let up = wsfix(C, m0, V.boot != '0');
if (up) m0.on = true;
if (m0 && V.boot == '0' && m0.on) { call({ action: 'topts', tid: m0.id, on: false }); exit(0); }
let tf = filter(tuns(C), (x) => length(x.devs) || (x.n == 0 && x.mode != 'dev' && x.mode != 'except'))[0];
if (!up && tf && stat('/usr/share/nftables.d')?.type == 'directory') {
let nm = match(sh('uci -q show network'), /network\.wgout_r[0-9]{1,4}\.mark=/) && !stat('/usr/share/nftables.d/table-post/42-wrtfreedom-vpnmac.nft');
let nd = (V.dns == 'vpn' || V.dns == 'own') && length(filter(tuns(C), (x) => x.on && !x.fb)) && !stat('/usr/share/nftables.d/chain-pre/dstnat/40-wrtfreedom-vpndns.nft');
if (nm || nd) call({ action: 'topts', tid: tf.id });
}
if (!m0 || V.boot == '0') exit(0);
if (!m0.on) exit(0);
let pr = C[m0.prof] ?? {};
if (match(V.bootpl ?? '', /^[A-Za-z0-9_-]{1,40}$/) && P[pr.prov] && V.bootpl != pr.place) {
for (let i = 0; i < 45 && !match(sh('ping -c 1 -W 2 1.1.1.1 2>/dev/null'), /time=/); i++) sh('sleep 2');
reqrun({ tid: m0.id, n: 0, prov: pr.prov, place: V.bootpl, pname: V.bootpn ?? '', skip: '', why: 'boot' });
}
exit(0);
}

if (cmd == 'newdev') {
let C = cfg(), m0 = filter(tuns(C), (x) => x.n == 0)[0], s = m0 ? C[m0.id] : null, mac = lc(ARGV[1] ?? ''), ip = ARGV[2] ?? '';
if (!s || s.mode != 'dev' || !ob(C, 'newdev', false) || !match(mac, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) || !match(ip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) exit(0);
let D = arr(s.devs);
if (length(filter(D, (d) => index(lc(d), mac) == 0))) exit(0);
push(D, mac + '|' + ip + '|' + replace(substr(ARGV[3] ?? '', 0, 40), /[^A-Za-z0-9 ._-]/g, ''));
call({ action: 'topts', tid: m0.id, devs: D });
exit(0);
}

function vaddr(I) { return trim(sh('ip -4 -o addr show dev ' + I + " 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n 1")); }

function ipcheck() {
let out = {}, C = cfg();
for (let x in tuns(C)) {
let I = ifn(x.n), r = { t: time() };
if (!x.on || !length(vaddr(I))) r.err = 'down';
else if (!CURL) r.err = 'curl';
else {
let y = get(NORD + 'helpers/ips/insights', { via: I });
if (y && y.ip) { r.ip = y.ip; r.cc = y.country_code ?? ''; r.country = y.country ?? ''; r.city = y.city ?? ''; r.org = y.isp ?? ''; r.prot = !!y.protected; }
else {
y = get('https://ifconfig.co/json', { via: I });
if (y && y.ip) { r.ip = y.ip; r.cc = y.country_iso ?? ''; r.country = y.country ?? ''; r.city = y.city ?? ''; r.org = y.asn_org ?? ''; }
else r.err = 'noanswer';
}
}
out[x.id] = r;
}
wj(IPF, out);
return out;
}
if (cmd == 'ipcheck') { ipcheck(); exit(0); }

const FWF = { dns: '/usr/share/nftables.d/chain-pre/dstnat/40-wrtfreedom-vpndns.nft', mac: '/usr/share/nftables.d/table-post/42-wrtfreedom-vpnmac.nft' };
const FWB = '/tmp/wf-vpnnft', FWN = '/tmp/wf-vpnnft.new', FWE = '/tmp/wf-vpnfw.json', FW4 = '/sbin/fw4', INITD = '/etc/init.d/';
const FWL = '/tmp/wf-fw.lock';
function fwlock() {
for (let i = 0; i < 60; i++) {
if (mkdir(FWL)) return true;
let s = stat(FWL);
if (s && time() - s.mtime > 120) rmdir(FWL); else sh('sleep 1');
}
return false;
}
if (cmd == 'fwapply') {
let G = fwlock(), out = '', rc = 0;
if (stat(FWN)) {
sh('rm -rf ' + q(FWB) + '; mkdir -p ' + q(FWB));
for (let k, f in FWF) {
if (stat(f)) sh('cp -p ' + q(f) + ' ' + q(FWB + '/' + k) + ' 2>/dev/null');
if (stat(FWN + '/' + k)) sh('mkdir -p ' + q(replace(f, /\/[^\/]*$/, '')) + '; cp ' + q(FWN + '/' + k) + ' ' + q(f) + ' 2>/dev/null');
else unlink(f);
}
sh('rm -rf ' + q(FWN));
}
if (stat(FW4)) {
out = sh(FW4 + ' -q check 2>&1; echo "__R=$?"');
let m = match(out, /__R=([0-9]{1,3})[[:space:]]*$/);
rc = m ? +m[1] : 1;
out = trim(replace(out, /__R=[0-9]{1,3}[[:space:]]*$/, ''));
}
if (rc != 0) {
for (let k, f in FWF) {
if (stat(FWB + '/' + k)) sh('cp -p ' + q(FWB + '/' + k) + ' ' + q(f) + ' 2>/dev/null');
else unlink(f);
}
let e = t('Il firewall ha rifiutato le regole nuove del Client VPN: rimesse quelle di prima, firewall non ricaricato. Controlla le regole aggiunte a mano al firewall',
'The firewall rejected the new VPN Client rules: previous ones restored, firewall not reloaded. Check the rules added by hand to the firewall');
wj(FWE, { t: time(), err: e, out: cut(out, 400) });
ev('vpnfw', vh([ t('Regole nuove rifiutate', 'New rules rejected'), t('Rimesse quelle di prima', 'Previous ones restored'), t('Controlla le regole a mano', 'Check the rules added by hand') ], true, t('Firewall Del Client VPN', 'VPN Client Firewall')));
sh('rm -rf ' + q(FWB));
if (G) rmdir(FWL);
exit(1);
}
unlink(FWE);
sh('rm -rf ' + q(FWB));
sh(INITD + 'firewall reload >/dev/null 2>&1');
if (G) rmdir(FWL);
sh(INITD + 'network reload >/dev/null 2>&1; ' + INITD + 'dnsmasq reload >/dev/null 2>&1');
sh('ucode ' + W + '/vpnctl.uc sync >/dev/null 2>&1');
exit(0);
}

if (cmd == 'sync') {
sh('sleep 3');
let up = [];
for (let x in tuns(cfg())) {
let I = ifn(x.n);
if (!x.on) continue;
let pk = ug('network.' + I + '_peer.public_key'), live = split(trim(sh('wg show ' + q(I) + ' peers 2>/dev/null')), '\n');
let me = trim(sh('uci -q get network.' + I + '.private_key 2>/dev/null | wg pubkey 2>/dev/null')), mel = trim(sh('wg show ' + q(I) + ' public-key 2>/dev/null'));
if (!length(vaddr(I)) || !length(pk) || index(live, pk) < 0 || (length(me) && me != mel)) { sh('ifup ' + q(I) + ' >/dev/null 2>&1'); push(up, I); }
}
let hs = (I) => { let h = 0; for (let l in split(trim(sh('wg show ' + q(I) + ' latest-handshakes 2>/dev/null')), '\n')) { let f = split(trim(l), '\t'); if (+f[1] > h) h = +f[1]; } return h; };
for (let i = 0; i < 15 && length(up); i++) { sh('sleep 2'); up = filter(up, (I) => !(length(vaddr(I)) && hs(I) > 0)); }
ipcheck();
exit(0);
}

if (cmd == 'leak') {
let C = cfg(), id = ARGV[1] ?? '', x = filter(tuns(C), (y) => y.id == id)[0];
if (!x) { say('❌ ' + t('Collegamento non trovato', 'Connection not found')); exit(1); }
let I = ifn(x.n), pr = C[x.prof] ?? {}, dm = (C.vpnout ?? {}).dns, vdns = dm == 'vpn' ? arr(pr.dns)[0] : dm == 'own' ? arr((C.vpnout ?? {}).dnsc)[0] : null;
if (!length(vaddr(I))) { say('❌ ' + t('Il collegamento non è attivo', 'The connection is not active')); exit(1); }
say('🧪 ' + t('Controllo in corso (circa 15 secondi)…', 'Checking (about 15 seconds)…'));
let key = trim(get('https://bash.ws/id', { via: I, raw: true }));
if (!match(key, /^[a-z0-9]{8,40}$/)) { say('❌ ' + t('Il servizio di controllo non risponde: riprova più tardi', 'The test service is not responding: try again later')); exit(1); }
let srv = vdns ?? '127.0.0.1', c = '';
for (let i = 1; i <= 10; i++) c += '( nslookup ' + i + '.' + key + '.bash.ws ' + q(srv) + ' >/dev/null 2>&1 ) & ';
sh(c + 'wait; sleep 2');
let R = arr(get('https://bash.ws/dnsleak/test/' + key + '?json', { via: I })), line = get(NORD + 'helpers/ips/insights') ?? {};
let dns = filter(R, (y) => y.type == 'dns'), mine = filter(R, (y) => y.type == 'ip')[0] ?? {}, isp = lc(line.isp ?? '');
let asn = (s) => { let m = match('' + (s ?? ''), /^[ \t]*(AS)?([0-9]+)/i); return m ? m[2] : ''; };
let la = asn(line.isp_asn ?? line.asn), lo = isp;
if (!length(la)) { let y = get('https://ifconfig.co/json') ?? {}; la = asn(y.asn); lo = lc(y.asn_org ?? ''); if (!length(line.isp ?? '')) line.isp = y.asn_org ?? ''; }
if (length(la) && la == asn(mine.asn)) { la = ''; lo = ''; isp = ''; }
let same = (y) => {
let da = asn(y.asn), n = lc(y.asn ?? '');
if (length(da) && length(la)) return da == la;
return (length(isp) && index(n, split(isp, ' ')[0]) >= 0) || (length(lo) && index(n, split(lo, ' ')[0]) >= 0);
};
let leak = length(filter(dns, same)) > 0;
let res = { t: time(), tid: id, ok: length(dns) > 0 && !leak, leak: leak, ip: mine.ip ?? '', dns: map(dns, (y) => ({ ip: y.ip, country: y.country_name ?? '', asn: y.asn ?? '' })), line: line.isp ?? '' };
wj(LEAKF, res);
if (!length(dns)) say('⚠️ ' + t('Nessuna risposta DNS letta: riprova', 'No DNS answer seen: try again'));
else {
for (let y in dns) say('• ' + y.ip + ' · ' + (y.country_name ?? '') + ' · ' + (y.asn ?? ''));
say(leak ? '⚠️ ' + t('Perdita: il DNS dell\'operatore (' + line.isp + ') vede i siti che visiti', 'Leak: your provider\'s DNS (' + line.isp + ') sees the sites you visit')
: '✅ ' + t('Nessuna perdita: il tuo operatore non vede i nomi dei siti', 'No leak: your provider does not see the site names'));
}
exit(0);
}

function adgyaml() {
let s = false, u = {};
for (let l in split(readfile('/etc/config/adguardhome') ?? '', '\n')) {
if (match(l, /^[ \t]*config[ \t]/)) { s = match(l, /^[ \t]*config[ \t]+[^ \t]+[ \t]+['"]?config['"]?[ \t]*$/) != null; continue; }
let m = s ? match(l, /^[ \t]*option[ \t]+(config_file|config)[ \t]+['"]?([^'"]{1,255})/) : null;
if (m) u[m[1]] = trim(m[2]);
}
for (let f in [ u.config_file, u.config ]) if (length(f) && stat(f)) return f;
let c = stat('/tmp/wf-adgyaml'), y = c ? trim(readfile('/tmp/wf-adgyaml') ?? '') : '';
if (y == '-' && time() - c.mtime < 60) return null;
if (length(y) && y != '-' && time() - c.mtime < 600 && stat(y)) return y;
y = trim(sh('sh /usr/share/wrtfreedom/lib.sh adgyaml 2>/dev/null'));
return length(y) && stat(y) ? y : null;
}
function dnsips() {
let H = [], add = (h) => { h = trim('' + h); if (length(h) && index(H, h) < 0) push(H, h); };
for (let y in [adgyaml()]) {
if (!y) break;
let sec = false;
for (let l in split(readfile(y) ?? '', '\n')) {
if (match(l, /^ *(upstream_dns|bootstrap_dns|fallback_dns):/)) { sec = true; continue; }
if (sec && !match(l, /^ *- /)) { sec = false; continue; }
if (!sec) continue;
let v = replace(replace(trim(substr(trim(l), 2)), /^["']|["']$/g, ''), /^\[\/[^]]*\/\]/, '');
let m = match(v, /^[a-z0-9]+:\/\/\[?([^]\/:]+)/) ?? match(v, /^([0-9.]+)(:[0-9]+)?$/);
if (m) add(m[1]);
}
break;
}
if (!length(H)) for (let x in split(trim(sh('uci -q get dhcp.@dnsmasq[0].server')), ' ')) { let m = match(x, /^([0-9]{1,3}(\.[0-9]{1,3}){3})(#[0-9]+)?$/); if (m) add(m[1]); }
let U = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
let ips = [], pub = (ip) => !match(ip, /^(127|0)\./) && !U.privip(ip);
for (let h in H) {
let L = match(h, /^[0-9.]+$/) ? [h] : map(filter(split(sh('nslookup ' + q(h) + ' 127.0.0.1 2>/dev/null'), '\n'), (l) => match(l, /^Address[ 0-9:]*: *[0-9.]+$/)), (l) => trim(split(l, ':')[1]));
for (let ip in L) if (match(ip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) && pub(ip) && index(ips, ip) < 0) push(ips, ip);
}
return slice(ips, 0, 16);
}

if (cmd == 'tick') {
const LK = '/tmp/wf-vpntick.lock';
if (!mkdir(LK)) { let ls = stat(LK); if (ls && time() - ls.mtime < 300) exit(0); rmdir(LK); if (!mkdir(LK)) exit(0); }
let now = time(), C = cfg(), V = C.vpnout ?? {}, S = rd(STF) ?? {}, kill = ob(C, 'kill', true), auto = ob(C, 'auto', true), T = tuns(C), ipnow = false;
let lt = localtime(now), day = today(), hm = sprintf('%02d:%02d', lt.hour, lt.min), dow = '' + (lt.wday == 0 ? 7 : lt.wday), swd = false;	/* dow 1 = lunedì … 7 = domenica */
let WAIT = +(V.wait ?? 0) || 120;
let noline = lineoff();
let sw = (x, pr, why, place, pname) => {
swd = true;
reqrun({ tid: x.id, n: x.n, prov: pr.prov, place: place ?? pr.place, pname: pname ?? '', skip: pr.prov == 'pia' || place ? '' : (pr.host ?? ''), why: why }, true);
};
let wg = {};
for (let l in split(trim(sh('wg show all dump 2>/dev/null')), '\n')) { let f = split(l, '\t'); if (length(f) >= 8) wg[f[0]] = { hs: +f[5], rx: +f[6], tx: +f[7], ep: match(f[3], /^([0-9]{1,3}(\.[0-9]{1,3}){3}):[0-9]+$/)?.[1] }; }
const AGF = '/tmp/wf-vpnctl.again', DN = 30, PWN = 3;
let again = false;
let fresh = (I, w, pr, s) => {
let ip = filter(arr(pr.dns), (y) => match(y, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/))[0] ?? '1.1.1.1', g = s.lrx != null && w.rx > s.lrx;
s.lrx = w.rx;
if (pingok(I, ip)) { s.pw = true; s.pf = 0; s.pf0 = 0; return true; }
if (s.pw) {
s.pf0 = +(s.pf0 ?? 0) || now; s.pf = +(s.pf ?? 0) + 1;
if (s.pf >= PWN && w.hs > 0 && w.hs >= s.pf0) { s.pw = false; s.pf = 0; s.pf0 = 0; return true; }
if (!s.down) again = true;
return g;
}
if (w.hs > 0 && now - w.hs < 180) return true;
let hs = 0;
for (let l in split(trim(sh('wg show ' + q(I) + ' latest-handshakes 2>/dev/null')), '\n')) { let f = split(trim(l), '\t'); if (+f[1] > hs) hs = +f[1]; }
w.hs = hs || w.hs;
return hs > 0 && time() - hs < 180;
};
let U = rd(USEF) ?? rd(USEP) ?? { t: {} }, dt = now - (S._at ?? now);
U.av = U.av ?? {};
for (let x in T) {
let I = ifn(x.n), w = wg[I], s = S[x.id] ?? {}, pr = C[x.prof] ?? {}, name = (pr.city || pr.name || pr.host || 'VPN') + (pr.cc ? ' (' + pr.cc + ')' : '');
let alive = w && (x.on ? fresh(I, w, pr, s) : w.hs > 0 && now - w.hs < 180);
let moff = x.on && !w && ifoff(I);
if (w) {
let u = U.t[x.id] ?? { d: {} }, l = u.l ?? [0, 0], drx = w.rx >= l[0] ? w.rx - l[0] : w.rx, dtx = w.tx >= l[1] ? w.tx - l[1] : w.tx, d = u.d[day] ?? [0, 0];
u.d[day] = [d[0] + drx, d[1] + dtx]; u.l = [w.rx, w.tx];
let ks = sort(keys(u.d)); while (length(ks) > 62) delete u.d[shift(ks)];
U.t[x.id] = u;
}
if (x.n == 0 && x.on && !moff && dt > 0 && dt <= 120) { let a = U.av[day] ?? [0, 0]; U.av[day] = [a[0] + (alive ? dt : 0), a[1] + dt]; }
if (!x.on || moff) { delete S[x.id]; continue; }
if (alive) {
s.since = s.since || now;
let pe = '' + (w.ep ?? pr.host ?? '');
if (s.pe != pe || !(now - +(s.pa ?? 0) < 55) || +(s.pa ?? 0) > now + 60) {
let pm = match(sh('ping -c 1 -W 1 ' + q(pe) + ' 2>/dev/null'), /time=([0-9.]+)/);
s.ping = pm ? int(+pm[1] + 0.5) : null; s.pa = now; s.pe = pe;
}
if (pr.prov == 'nord' && match(pr.srvid ?? '', /^[0-9]+$/) && now - (s.lt ?? 0) >= 600) {
s.lt = now;
let L = get(NORD + 'servers?filters%5Bservers.id%5D=' + pr.srvid + '&limit=1');
if (type(L) == 'array' && L[0] && '' + L[0].id == pr.srvid) s.load = L[0].load;
}
let can = P[pr.prov] && length(pr.place ?? '') && now - (s.sw ?? 0) >= 900;
if (ob(C, 'swping', false) && s.ping != null && s.ping > (+V.pingmax || 150)) s.hp = s.hp || now; else s.hp = 0;
let hl = ob(C, 'swload', false) && s.load != null && s.load > (+V.loadmax || 70), hp = s.hp && now - s.hp >= 300;
if (can && !swd && (hl || hp)) { s.sw = now; s.hp = 0; s.load = null; s.lt = 0; sw(x, pr, hl ? 'load' : 'ping'); }
}
else { s.since = 0; s.pa = 0; }
if (alive) {
if (x.fb) call({ action: 'fallback', tid: x.id, on: false });
if (s.down) {
let mins = int((now - (s.bad || now)) / 60);
ev('vpnsvc_up', vh([ t('Di nuovo collegato', 'Connected again') + (mins > 0 ? t(' dopo ', ' after ') + mins + ' min' : ''), name ]), ob(C, 'al_up', true));
evrec('up', name + (mins > 0 ? ' · ' + mins + ' min' : ''));
s.ipt = 0;
}
s.down = false; s.bad = 0; s.rt = 0;
if (now - (s.ipt ?? 0) >= 900) { s.ipt = now; ipnow = true; }
}
else {
if (noline && !s.down) { s.bad = now; s.rt = 0; S[x.id] = s; continue; }
s.bad = s.bad || now;
if (!s.down) again = true;
if (!s.down && now - s.bad >= DN) {
s.down = true;
ev('vpnsvc_down', vh([ t('Il server non risponde', 'Server not responding'), name, kill ? t('Dispositivi bloccati', 'Devices blocked') : t('Dispositivi senza VPN', 'Devices without VPN') ]), ob(C, 'al_down', true));
evrec('down', name);
}
if (s.down && !kill && !x.fb) {
call({ action: 'fallback', tid: x.id, on: true });
ev('vpnsvc_fb', vh([ t('Dispositivi senza VPN', 'Devices without VPN'), t('Finché il server non torna', 'Until the server is back'), name ], true), true, true);
}
if (s.down && auto && !noline) {
let p = pr.prov ?? '';
if (!s.rt || (!(P[p] && length(pr.place ?? '')) && now - s.rt >= (WAIT > 600 ? WAIT : 600))) { s.rt = now; sh('ifup ' + I + ' >/dev/null 2>&1'); }
else if (P[p] && length(pr.place ?? '') && !swd && now - s.rt >= WAIT && now - (s.sw ?? 0) >= 600) {
s.sw = now; s.rt = now;
sw(x, pr, 'down');
}
}
}
S[x.id] = s;
}
S._at = now;
let ids = {}; for (let x in T) ids[x.id] = 1;
for (let k in keys(S)) if (substr(k, 0, 1) != '_' && !ids[k]) delete S[k]; else if (substr(k, 0, 2) == '_s' && !C[substr(k, 2)]) delete S[k];
for (let k in keys(U.t)) if (k != '_gone' && !ids[k]) {
let g = U.t._gone ?? { d: {} };
for (let dd, v in (U.t[k].d ?? {})) { let o = g.d[dd] ?? [0, 0]; g.d[dd] = [o[0] + (v[0] ?? 0), o[1] + (v[1] ?? 0)]; }
let gs = sort(keys(g.d)); while (length(gs) > 62) delete g.d[shift(gs)];
U.t._gone = g; delete U.t[k];
}
let ak = sort(keys(U.av)); while (length(ak) > 62) delete U.av[shift(ak)];
wj(USEF, U);
if (now - (+(readfile('/tmp/wf-vpnuse.saved') ?? 0)) >= 3600) { usesave(U); evsave(); writefile('/tmp/wf-vpnuse.saved', '' + now); }
let m0 = filter(T, (x) => x.n == 0)[0], p0 = m0 ? (C[m0.prof] ?? {}) : {};
if (wsfix(C, m0, true)) m0.on = true;
if (m0) for (let k, s in C) {
if (s['.type'] != 'vpnsched' || s.on == '0' || index('' + (s.days ?? ''), dow) < 0) continue;
let st = hm == s['from'] ? 'a' : hm == s.to ? 'b' : null;
if (!st || S['_s' + k] == st + day) continue;
S['_s' + k] = st + day;
if (s.act == 'place') {
let qa = C['va_' + s.prov] ?? {};
if (P[s.prov] && !swd && m0.on) sw(m0, { prov: s.prov, place: '', host: '' }, 'sched', st == 'a' ? s.place : (length(qa.qplace ?? '') ? qa.qplace : 'auto'), st == 'a' ? s.pname : (qa.qname ?? ''));
}
else {
let Ws = rd(WSF) ?? {}, was = Ws[k];
if (st == 'a' && m0.on) Ws[k] = true; else if (!(st == 'b' && +(V.pause_until ?? 0))) delete Ws[k];
if (Ws[k] != was) { if (length(keys(Ws))) wj(WSF, Ws); else unlink(WSF); }
if (st == 'a' && m0.on) call({ action: 'topts', tid: m0.id, on: false });
else if (st == 'b' && was && !(+(V.pause_until ?? 0))) call({ action: 'topts', tid: m0.id, on: true });
}
}
if (m0 && m0.on && ob(C, 'ipday', false) && hm == (V.ipat || '04:00') && S._ipd != day && P[p0.prov] && length(p0.place ?? '') && !swd) { S._ipd = day; sw(m0, p0, 'ip'); }
if (ipnow) ipcheck();
if (now - (S._acct ?? 0) >= 86400) { S._acct = now; acccheck(); }
if ((!V.dns || V.dns == 'adg') && m0 && m0.on && !m0.fb && m0.mode != 'dev' && now - (S._dnst ?? 0) >= 600) { S._dnst = now; call({ action: 'dnsips', ips: dnsips() }); }
wj(STF, S);
if (again) writefile(AGF, ''); else unlink(AGF);
rmdir(LK);
exit(0);
}

if (cmd == 'save') { let U = rd(USEF); if (U) usesave(U); evsave(); exit(0); }

warn('uso: ucode vpnctl.uc login|places <servizio> | connect | ipcheck | sync | leak <collegamento> | srvlist <servizio> <paese> | boot | newdev <mac> <ip> <nome> | tick | save\n');
exit(1);
