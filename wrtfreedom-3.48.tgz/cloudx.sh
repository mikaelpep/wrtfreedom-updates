#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH
umask 077
XR=; [ -n "$WF_CLOUDROOT" ] && [ ! -e /etc/openwrt_release ] && XR=$WF_CLOUDROOT
XW=$XR/usr/share/wrtfreedom; XE=$XR/etc/wrtfreedom; XCJ=$XE/cloud.json; XCF=$XE/cloud-rclone.conf; XLJ=$XE/cloud-links.json
XD=/tmp/wf-cloud
: "${WF_NASETC:=$XE}"
[ -f $XW/lib.sh ] && . $XW/lib.sh
XRT=$(wf_udir admin router 2>/dev/null)
XLNK=$(wf_udir admin lnk 2>/dev/null); XLNK=${XLNK##*/}; XLNK=${XLNK:-/}
XINB=$(wf_udir admin inbox 2>/dev/null); XINB=${XINB##*/}; XINB=${XINB:-/}
XCT=60; [ -n "$XR" ] && [ -n "$WF_CLOUDTICK" ] && XCT=$WF_CLOUDTICK
mkdir -p $XD/res $XD/jobs $XD/log $XD/dl $XD/ph && chmod 700 $XD
[ -f $XW/cloudline.sh ] && . $XW/cloudline.sh
command -v cl_check >/dev/null 2>&1 || cl_check() { echo "ok off 0 fix"; }
command -v cl_add >/dev/null 2>&1 || cl_add() { true; }
command -v cl_in >/dev/null 2>&1 || cl_in() { true; }
command -v cl_mem >/dev/null 2>&1 || cl_mem() { return 1; }
command -v cl_env >/dev/null 2>&1 || cl_env() { CL_MOK=; if [ "$(cat $XD/tier 2>/dev/null)" = A ]; then CL_RMEM="--buffer-size 1M --transfers 1 --checkers 2"; else CL_RMEM="--buffer-size 4M --transfers 2 --checkers 4"; fi; }
command -v cl_why >/dev/null 2>&1 || cl_why() { case "$1" in queue|slot) echo 'In coda|Queued' ;; *) echo 'In attesa|Waiting' ;; esac; }
x_e() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r\t'; }
x_alive() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }
x_boot() {
if [ -n "$XR" ]; then [ -n "$WF_UPTIME" ] && [ "$WF_UPTIME" -lt 600 ] 2>/dev/null; return; fi
u_=; read -r u_ _ </proc/uptime 2>/dev/null; u_=${u_%.*}; [ -n "$u_" ] && [ "$u_" -lt 600 ] 2>/dev/null
}
x_msg() {
case "$2" in
none) set -- "$1" 'Account non trovato' 'Account not found' ;;
relink) set -- "$1" 'Account da ricollegare' 'Account needs reconnecting' ;;
space|full) set -- "$1" 'Spazio nel cloud finito' 'Cloud storage full' ;;
path) set -- "$1" 'Cartella non valida' 'Invalid folder' ;;
exists) set -- "$1" "C'è già un file con questo nome" 'A file with this name already exists' ;;
bk) set -- "$1" 'Cartella di un backup: si apre da Ripristina' 'Backup folder: open it from Restore' ;;
crypt) set -- "$1" 'Le cartelle dei backup non si condividono' 'Backup folders cannot be shared' ;;
caps) set -- "$1" 'Questo servizio non lo permette' 'This service does not allow it' ;;
big) set -- "$1" 'File troppo grande per questo router' 'File too large for this router' ;;
disk) set -- "$1" 'Collega il disco del NAS' 'Connect the NAS disk' ;;
ro) set -- "$1" 'Disco in sola lettura' 'Disk is read-only' ;;
net) set -- "$1" 'Internet non raggiungibile' 'Internet unreachable' ;;
sim) set -- "$1" 'Aspetta la linea fissa o le ore della SIM' 'Waiting for the fixed line or the SIM hours' ;;
busy) set -- "$1" 'Account occupato: riprova fra poco' 'Account busy: try again shortly' ;;
bakpass) set -- "$1" 'Scegli prima la Password Della Copia' 'Choose the Backup Password first' ;;
pkg) set -- "$1" 'Serve installare Cloud in Software' 'Install Cloud in Software first' ;;
trash) set -- "$1" 'Servizio senza cestino: togli i file uno alla volta' 'No trash on this service: delete files one by one' ;;
act) set -- "$1" 'Azione sconosciuta' 'Unknown action' ;;
media) set -- "$1" 'Questo file non si può riprodurre' 'This file cannot be played' ;;
rev) set -- "$1" 'Versione non trovata' 'Version not found' ;;
nomain) set -- "$1" 'Manca il Disco Principale' 'Main Drive missing' ;;
private) set -- "$1" "Cartella di un'altra persona" "Another person's folder" ;;		admin) set -- "$1" "Solo l'Amministratore" 'Administrator only' ;;
quota_full) set -- "$1" 'Spazio finito: libera spazio o chiedi più spazio' 'Space used up: free some space or ask for more space' ;;
cquota) set -- "$1" 'Spazio Cloud finito: libera spazio o chiedi più spazio' 'Cloud space full: free some space or ask for more' ;;
check) set -- "$1" 'Copia non uguale: la partenza resta' 'Copy does not match: the source stays' ;;
cmig) set -- "$1" 'Cartella in cifratura in questo momento: riprova fra poco' 'Folder being encrypted right now: try again shortly' ;;
cpriv) set -- "$1" 'Cartella privata cifrata: usa Condividi' 'Encrypted private folder: use Share' ;;
*) set -- "$1" 'Non riuscito' 'Failed' ;;
esac
if [ "$1" = en ]; then printf '%s' "$3"; else printf '%s' "$2"; fi
}
x_hc() { printf '(error|status|code|http)[^0-9a-z]{0,3}%s([^0-9]|$)|[(]%s [a-z]' "$1" "$1"; }
x_tr() {
if grep -qiE "invalid_grant|unauthori[sz]ed|token (expired|revoked|rejected)|invalid access_token|log ?in (required|failed)|\"result\": ?(1000|2000)([^0-9]|\$)|$(x_hc 401)" "$1" 2>/dev/null; then echo relink
elif grep -qiE "ratelimitexceeded|rate ?limit|uploadlimitexceeded|too_many_requests|activitylimitreached|too many|\"result\": ?4000([^0-9]|\$)|$(x_hc 429)" "$1" 2>/dev/null; then echo busy
elif grep -qiE "quota|storage.*full|insufficient|no space|\"result\": ?2008([^0-9]|\$)|$(x_hc 507)" "$1" 2>/dev/null; then echo space
elif grep -qiE 'no such host|dial tcp|i/o timeout|timeout|network is unreachable|connection refused|"result": ?500[01]([^0-9]|$)' "$1" 2>/dev/null; then echo net
elif grep -qiE 'already exists|"result": ?2004([^0-9]|$)' "$1" 2>/dev/null; then echo exists
elif grep -qiE '"result": ?2044([^0-9]|$)' "$1" 2>/dev/null; then echo media
elif grep -qiE "directory not found|object not found|not found|\"result\": ?(2005|2009|2002)([^0-9]|\$)|$(x_hc 404)" "$1" 2>/dev/null; then echo path
else echo fail; fi
}
x_lsed() { sed -e 's#[A-Za-z][A-Za-z0-9+.-]*://[^ "'"'"'<>]*#<link>#g' -e 's#\(access_token\|auth\|linkpassword\|password\|code\)=[^&" ]*#\1=<->#g' "$@" 2>/dev/null; }
x_log() {
[ -f "$LOG" ] || return 0
x_lsed -i "$LOG"
[ "$(wc -c < "$LOG" 2>/dev/null)" -gt 65536 ] 2>/dev/null && { tail -c 32768 "$LOG" > "$LOG.t"; mv "$LOG.t" "$LOG"; }
true
}
x_logw() {
[ -f "$LOG" ] || return 0
x_lsed "$LOG" > "$LOG.t" || { rm -f "$LOG.t"; return 0; }
if [ "$(wc -c < "$LOG.t")" -gt 65536 ] 2>/dev/null; then tail -c 32768 "$LOG.t" > "$LOG"; else cat "$LOG.t" > "$LOG"; fi
rm -f "$LOG.t"
}
x_vars() {
XF=$1; shift
XF=$XF XK="$*" ucode -e '
let N = {};
try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {}
if (type(N) != "object") N = {};
function q(s) { return "\x27" + replace(s, "\x27", "\x27\\\x27\x27") + "\x27"; }
for (let k in split(getenv("XK"), " ")) {
	let v = N[k], s = "";
	if (type(v) == "array") s = join("\n", filter(v, (x) => type(x) == "string" && !match(x, /[\n\r]/)));
	else if (type(v) == "bool") s = v ? "1" : "0";
	else if (type(v) == "object") s = sprintf("%J", v);
	else if (v != null) s = "" + v;
	print("J_", k, "=", q(s), "\n");
}' 2>/dev/null
}
x_jget() { printf '%s' "$1" | XQ=$2 ucode -e 'let N = null; try { N = json(require("fs").stdin.read("all")); } catch (e) {} if (type(N) == "object") { let v = call(loadstring("return " + getenv("XQ")), null, { N }); if (v != null) print(v); }' 2>/dev/null; }
x_shl() {
[ -n "$2" ] || [ -z "$XAO" ] || [ "$XAO" = admin ] || return 1
command -v wf_udir >/dev/null 2>&1 || return 1
sl_s=$(wf_udir shared root) && [ -n "$sl_s" ] || return 1
sl_r=${sl_s%/*}; sl_n=${sl_s##*/}
case "$1/" in "$sl_r"/*/"$sl_n"/*) ;; *) return 1 ;; esac
sl_t=${1#"$sl_r"/}; sl_v=${sl_t%%/*}; sl_t=${sl_t#"$sl_v"/}
case "$sl_t" in "$sl_n") sl_e= ;; "$sl_n"/*) sl_e=${sl_t#"$sl_n"} ;; *) return 1 ;; esac
[ "$sl_v" != "$sl_n" ] && [ "$sl_v" != Amministratore ] || return 1
for sl_u in $(x_cusers); do
[ "$(wf_udir "$sl_u" root)" = "$sl_r/$sl_v" ] && { printf '%s%s' "$sl_s" "$sl_e"; return 0; }
done
return 1
}
x_path() {
p=$(printf '%s' "$1" | sed 's#^/*##; s#/*$##')
case "/$p/" in */../*|*/./*) return 1 ;; esac
printf '%s' "$p" | grep -q '[[:cntrl:]]' && return 1
if [ -n "$XPU" ]; then
case "$p/" in "$XPU"/*|"$XPS"/*) ;; Utenti/*) return 1 ;; *) p=$XPU${p:+/$p} ;; esac
fi
q_=$(x_shl "$p") && p=$q_
printf '%s' "$p"
}
x_own() {
XOWN=${1:-admin}; XPU=''; XPS=''
[ "$XOWN" = admin ] && return 0
case "$XAO" in
"$XOWN") return 0 ;;
''|admin) XPU=$(wf_udir "$XOWN" root) && XPS=$(wf_udir shared root) && [ -n "$XPU" ] && [ -n "$XPS" ] || { XPU=; return 1; } ;;
*) return 1 ;;
esac
}
x_bleaves() {
WF_NASETC=$WF_NASETC WF_U=${WF_UCFGUC:-$XW/ucfg.uc} WF_BO=$1 ucode -e 'let U = loadfile(getenv("WF_U"))(), o = getenv("WF_BO"), b = U.udir(o, "root");
if (b == null || type(U.ubase) != "function") exit(1);
let X = [ U.udir(o, "tm"), U.udir(o, "fh"), U.udir(o, "sync") ];
if (o != "shared") for (let t in keys(U.UDIR.types)) push(X, U.udir(o, "dl", t));
/* 18/11 sera (scelta dell utente): l Amministratore nel cloud non ha Download né File Caricati (solo sul disco) */
let XA = o == "admin" ? [ U.udir(o, "dl"), U.udir(o, "up") ] : [];
let L = filter(U.ubase(), (p) => type(p) == "string" && substr(p, 0, length(b) + 1) == b + "/" && index(X, p) < 0 &&
	!length(filter(XA, (a) => type(a) == "string" && (p == a || substr(p, 0, length(a) + 1) == a + "/"))));
for (let p in L) if (!length(filter(L, (q) => substr(q, 0, length(p) + 1) == p + "/"))) print(p, "\n");' </dev/null 2>/dev/null
}
x_bmoves() {
if [ "$1" = shared ]; then
m=$(wf_udir shared mold) || return 0
for t in video music photo; do n=$(wf_udir shared media $t) && printf '%s/%s\t%s\n' "$m" "${n##*/}" "$n"; done
printf '%s\t\n' "$m"
return 0
fi
r=$(wf_udir "$1" root) && wf_udir "$1" priv >/dev/null && m=$(wf_udir "$1" mold) || return 0
for t in video music photo; do n=$(wf_udir "$1" media $t) && ob_=$(wf_udir shared media $t) && printf '%s/%s\t%s\n' "$m" "${ob_##*/}" "$n"; done
n=$(wf_udir "$1" backup) && printf '%s/Backup\t%s\n' "$r" "$n"
n=$(wf_udir "$1" sync) && printf '%s/Sincronizzazioni\t%s\n' "$r" "$n"
n=$(wf_udir "$1" phones) && printf '%s/Foto Del Telefono\t%s\n' "$r" "$n"
ob_=$(wf_udir "$1" pold) && n=$(wf_udir "$1" media photo) && printf '%s\t%s\n' "$ob_" "$n"
ob_=$(wf_udir "$1" phold) && n=$(wf_udir "$1" phones) && printf '%s\t%s\n' "$ob_" "$n"
}
x_cmove() {
mo=0; tb=$(printf '\t')
x_bmoves "$1" > $XD/base/m.$$
while IFS="$tb" read -r a b; do
[ -n "$a" ] || continue
if [ -z "$b" ]; then
ra=$(x_rp "$a" r); o_=$(x_rcl lsf "$ra" --max-depth 1 </dev/null 2>/dev/null) && [ -z "$o_" ] && x_r rmdir "$ra"
continue
fi
ra=$(x_rp "$a" r); rb=$(x_rp "$b")
x_rcl lsf "$ra" --max-depth 1 </dev/null >/dev/null 2>&1 || continue
if x_rcl lsf "$rb" --max-depth 1 </dev/null >/dev/null 2>&1; then
echo "passaggio: cartella vecchia e nuova ci sono tutte e due, lasciate come sono" >> "$LOG"; continue
fi
x_r moveto "$ra" "$rb" || { mo=1; printf '%s\n' "$b" >> $XD/base/f.$$; }
done < $XD/base/m.$$
rm -f $XD/base/m.$$
return $mo
}
x_mkd() {
[ "$XS" = drive ] || { x_r mkdir "$1"; return; }
K_m=$XD/mk-$J_id.lk; n_m=0
until mkdir "$K_m" 2>/dev/null; do
x_alive "$(cat "$K_m/pid" 2>/dev/null)" || { rm -rf "$K_m"; continue; }
n_m=$((n_m + 1)); [ $n_m -ge 20 ] && return 1; sleep 1
done
echo $$ > "$K_m/pid"
x_r mkdir "$1"; r_m=$?
pa_m=${1%/*}; [ "$pa_m" = "$1" ] && pa_m=${1%%:*}:
[ $r_m = 0 ] && x_rcl dedupe --dedupe-mode merge --max-depth 1 "$pa_m" </dev/null >/dev/null 2>&1
rm -rf "$K_m"; return $r_m
}
x_cbase() {
{ [ -z "$XAO" ] || [ "$XAO" = admin ]; } || return 1
[ -n "$1" ] || return 1
bo=
if [ "$1" = "$(wf_udir shared root)" ]; then bo=shared
elif [ -n "$XPU" ]; then [ "$1" = "$XPU" ] && bo=$XOWN
elif [ "$XOWN" = admin ]; then
for u in admin $(x_cusers); do
[ "$1" = "$(wf_udir "$u" root)" ] && { bo=$u; break; }
done
fi
[ -n "$bo" ] || return 1
x_cbo "$bo"
}
x_cusers() {
XN=$XE/nas.json ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XN")) ?? "{}"); } catch (e) {} for (let u, x in (type(N?.users) == "object" ? N.users : {})) if (type(x) == "object" && !x.cam && match(u, /^[A-Za-z0-9._-]{1,64}$/)) print(u, "\n");' 2>/dev/null
}
x_cbmk() { printf '%s/base/%s.5.%s' "$XD" "$J_id" "$(printf '%s' "$1" | md5sum | cut -c1-32)"; }
x_crwant() {
XCW=; XCWT=
[ -s "$XCC" ] && [ -n "$J_id" ] && command -v wf_crsec >/dev/null 2>&1 || return 1
XCWT=$(XF=$XCC XA=$J_id ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {}
let a = type(N?.accts) == "object" ? N.accts[getenv("XA")] : null;
if (N?.on === true && N?.keyok === true && type(a) == "object" && (a.st == "mig" || a.st == "on")) print(int(N.t_on ?? 0), "\n");' 2>/dev/null)
[ -n "$XCWT" ] && XCW=$(wf_crsec "$J_id" "$1") && [ -n "$XCW" ]
}
x_crsok() {
grep -qxF "[$XCW]" "$XCF" 2>/dev/null && return 0
[ -e $XD/.crkey ] || [ ! -f $XW/cloud.sh ] && return 1
sh $XW/cloud.sh cryptset "$J_id" </dev/null >/dev/null 2>&1
grep -qxF "[$XCW]" "$XCF" 2>/dev/null || return 1
case "$RCLONE_CONFIG" in "$XD"/ro.*) cp "$XCF" "$RCLONE_CONFIG" && chmod 600 "$RCLONE_CONFIG" ;; esac
true
}
x_cfadd() {
r0_=$(wf_udir "$1" root) && [ -n "$r0_" ] || return 1
{ cat $XD/base/l.$$; x_rcl lsf --dirs-only "$RM:$r0_" </dev/null 2>/dev/null | sed 's|/$||' | grep -vE '^[0-9a-v]{26,}$' | sed "s|^|$r0_/|"; } |
while IFS= read -r l; do [ -n "$l" ] && x_cs "$l" && case "$XCT" in enc|mig) printf '%s\n' "$XCK" ;; esac; done | sort -u > $XD/base/k.$$
XF=$XCC XA=$J_id XK=$XD/base/k.$$ ucode -e 'let fs = require("fs"), N = {}; try { N = json(fs.readfile(getenv("XF")) ?? "{}"); } catch (e) {}
let f = type(N?.accts?.[getenv("XA")]?.f) == "object" ? N.accts[getenv("XA")].f : {}, h = {};
for (let k in keys(f)) h[lc(k)] = true;
for (let k in split(fs.readfile(getenv("XK")) ?? "", "\n")) if (length(k) && !h[lc(k)]) print(k, "\n");' </dev/null > $XD/base/n.$$ 2>/dev/null || { rm -f $XD/base/k.$$ $XD/base/n.$$; return 1; }
fo_=0
while IFS= read -r k_; do
[ -n "$k_" ] || continue
cp_="$RM:$r0_/${k_#*/}"
x_rcl lsf -R --files-only "$cp_" </dev/null > $XD/base/c.$$ 2>/dev/null; r_=$?
case $r_ in 0|3) ;; *) fo_=1; continue ;; esac
v_=enc; [ -s $XD/base/c.$$ ] && v_=mig
sh $XW/cloudcr.sh fadd "$J_id" "$k_" $v_ </dev/null >/dev/null 2>&1 || { fo_=1; continue; }
[ $v_ = enc ] && [ $r_ = 0 ] && x_r rmdirs "$cp_"
done < $XD/base/n.$$
rm -f $XD/base/k.$$ $XD/base/n.$$ $XD/base/c.$$
return $fo_
}
x_cbo() {
bo=$1
mk=$(x_cbmk "$bo"); fk=; cw_=
x_crwant "$bo" && { cw_=1; fk=$mk.f$XCWT; }
[ -f "$mk" ] && { [ -z "$cw_" ] || [ -f "$fk" ]; } && return 1
mkdir -p $XD/base; ok=1; : > $XD/base/f.$$
if [ -n "$cw_" ] && ! x_crsok; then rm -f $XD/base/f.$$; return 0; fi
[ -f "$mk" ] || x_cmove "$bo" || ok=
x_bleaves "$bo" > $XD/base/l.$$ || ok=
fo=1; [ -n "$cw_" ] && { [ -n "$ok" ] && x_cfadd "$bo" || fo=; }
while IFS= read -r l; do
[ -n "$l" ] || continue
sk_=
while IFS= read -r f_; do case "$l/" in "$f_"/*) sk_=1; break ;; esac; done < $XD/base/f.$$
[ -n "$sk_" ] && continue
x_mkd "$(x_rp "$l")" || ok=
done < $XD/base/l.$$
[ -n "$ok" ] && while IFS= read -r l; do [ -n "$l" ] && { x_r lsf --dirs-only --max-depth 1 "$(x_rp "$l")" >/dev/null 2>&1 || ok=; }; done < $XD/base/l.$$
rm -f $XD/base/l.$$ $XD/base/f.$$
[ -n "$ok" ] && : > "$mk"
[ -n "$ok" ] && [ -n "$fo" ] && [ -n "$cw_" ] && : > "$fk"
return 0
}
c_cbase() {
x_acct "$1" || exit 0; J_id=$1
{ [ -z "$XAO" ] || [ "$XAO" = admin ]; } || exit 0
command -v rclone >/dev/null 2>&1 || exit 0
XO_=; for bw_ in shared admin $(x_cusers); do
[ -n "$(wf_udir "$bw_" root 2>/dev/null)" ] || continue
if [ ! -f "$(x_cbmk "$bw_")" ] || { x_crwant "$bw_" && [ ! -f "$(x_cbmk "$bw_").f$XCWT" ]; }; then XO_="$XO_ $bw_"; fi
done
[ -n "$XO_" ] || exit 0
case "$(cl_check cbase '' 2>/dev/null)" in ok*) ;; *) exit 0 ;; esac
mkdir -p $XD/base
K_=$XD/base/$1.lk; if ! mkdir "$K_" 2>/dev/null; then x_alive "$(cat "$K_/pid" 2>/dev/null)" && exit 0; rm -rf "$K_"; mkdir "$K_" 2>/dev/null || exit 0; fi
echo $$ > "$K_/pid"; LOG=$XD/log/cbase-$1; : > "$LOG"
JOB=cbase-$1; XSL=
trap 'x_slput; rm -rf "$K_"; rm -f "$XRO" $XD/base/l.$$ $XD/base/m.$$ $XD/base/f.$$ $XD/base/k.$$ $XD/base/n.$$ $XD/base/c.$$' EXIT
cw_=0
while :; do
if ! x_boot && { [ ! -f $XW/cloud.sh ] || sh $XW/cloud.sh slot get "$JOB" "$1" $$ >/dev/null 2>&1; }; then [ -f $XW/cloud.sh ] && XSL=$1; break; fi
[ -f $XW/cloud.sh ] && sh $XW/cloud.sh slot put "$JOB" >/dev/null 2>&1
[ "$WF_CBWAIT" = 1 ] && [ $cw_ -lt 90 ] || exit 0
cw_=$((cw_ + 1)); sleep 10
done
x_rdconf "$1" || exit 0
if cl_mem rclonepush && [ "$CL_GO" -ge 32 ]; then export GOMEMLIMIT=${CL_GO}MiB; elif [ "$(cat $XD/tier 2>/dev/null)" = A ]; then export GOGC=20; fi
for bw_ in $XO_; do x_cbo "$bw_"; done
x_gen "$1"; x_log; exit 0
}
c_cbroot() {
x_acct "$1" || exit 0
{ [ -z "$XAO" ] || [ "$XAO" = admin ]; } || exit 0
printf '%s' "$2" | grep -qE '^[A-Za-z0-9._-]{1,64}$' || exit 2
command -v rclone >/dev/null 2>&1 || exit 0
p_=$(wf_udir "$2" root 2>/dev/null) && [ -n "$p_" ] || exit 0
case "$(cl_check cbase '' 2>/dev/null)" in ok*) ;; *) exit 0 ;; esac
mkdir -p $XD/log; J_id=$1; LOG=$XD/log/cbase-$1; : > "$LOG"
trap 'rm -f "$XRO"' EXIT
x_rdconf "$1" || exit 0
x_mkd "$RM:$p_"; r_=$?
x_gen "$1"; x_log; exit $r_
}
x_bkdir() {
case "$1" in
'WrtFreedom/Backup'|'WrtFreedom Backup') return 0 ;;
'Utenti/Cartella Condivisa/'*) return 1 ;;
Utenti/*/Backup) r=${1#Utenti/}; [ "${r%/Backup}" = "${r%%/*}" ] ;;
*) return 1 ;;
esac
}
x_iscrypt() {
case "$2/" in "$XRT"/*|'WrtFreedom/Router/'*|'WrtFreedom Router/'*) return 0 ;; esac
x=$2; while :; do x_bkdir "$x" && return 0; [ "${x%/*}" = "$x" ] && break; x=${x%/*}; done
awk -v A="wf$1:" -v P="$2/" '
		/^\[/ { t = 0; r = "" } /^type *= *crypt/ { t = 1 }
		/^remote *= */ { r = $0; sub(/^remote *= */, "", r) }
		t && r != "" && index(r, A) == 1 { f = substr(r, length(A) + 1); sub(/^\/+/, "", f); sub(/\/+$/, "", f)
			# 3.44: le sezioni crypt delle persone (sopra Utenti/<vis>) non sono backup: passano da x_rp
			if (f ~ /^Utenti\/[^\/]+$/) next
			if (f == "" || index(P, f "/") == 1) { print "1"; exit } }' "$XCF" 2>/dev/null | grep -q 1
}
x_acct() {
printf '%s' "$1" | grep -qE '^a[0-9]{1,2}$' || return 1
grep -qx "\[wf$1\]" "$XCF" 2>/dev/null || return 1
RM=wf$1; XS=$(XA=$1 XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} for (let a in (N.accounts ?? [])) if (a.id == getenv("XA")) { print(a.svc ?? "", "\t", type(a.user) == "string" && match(a.user, /^[A-Za-z0-9._-]{1,64}$/) ? a.user : ""); break; }' 2>/dev/null)
XAO=${XS#*	}; [ "$XAO" = "$XS" ] && XAO=; XS=${XS%%	*}
[ -n "$XS" ] || XS=$(awk -v S="[wf$1]" '$0 == S { f = 1; next } /^\[/ { f = 0 } f && /^type *= */ { sub(/^type *= */, ""); print; exit }' "$XCF")
XHD=; [ "$XS" = b2 ] && XHD=1
true
}
XCC=$XE/cloud-cifra.json
x_cs() {
XCS=; XCP=; XCV=; XCO=; XCK=; XCT=clear
{ [ -z "$XAO" ] || [ "$XAO" = admin ]; } && [ -s "$XCC" ] && [ -n "$J_id" ] && command -v wf_cpriv >/dev/null 2>&1 || return 1
c_=$(wf_cpriv "$1") || c_=; r_=
if [ -z "$c_" ]; then c_=$(wf_cpriv "$1/x") && [ -n "$c_" ] || return 1; r_=1; fi
tb_=$(printf '\t')
XCO=${c_%%"$tb_"*}; c_=${c_#*"$tb_"}; XCV=${c_%%"$tb_"*}; c_=${c_#*"$tb_"}; t_=${c_%%"$tb_"*}; XCP=${c_#*"$tb_"}
[ -n "$r_" ] && { XCP=${XCP%x}; XCP=${XCP%/}; }
XCS=$(wf_crsec "$J_id" "$XCO") && [ -n "$XCS" ] && grep -qxF "[$XCS]" "$XCF" 2>/dev/null || { XCS=; return 1; }
XCK=$XCV/$t_
XCT=$(XF=$XCC XA=$J_id XK=$XCK ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {}
let a = type(N) == "object" && type(N.accts) == "object" ? N.accts[getenv("XA")] : null, st = type(a) == "object" ? a.st : "";
if (st != "mig" && st != "on" && st != "back") { print("clear"); exit(0); }
let k = lc(getenv("XK")), f = null;
for (let x, v in (type(a.f) == "object" ? a.f : {})) if (lc(x) == k) f = v;
print(f == "clear" || f == "mig" || f == "enc" || f == "back" ? f : (st == "on" ? "enc" : st));' 2>/dev/null)
[ -n "$r_" ] && [ -n "$XCT" ] && [ "$XCT" != clear ] && XCT=root
case "$XCT" in mig|enc|back|root) return 0 ;; esac
XCT=clear; XCS=; return 1
}
x_has() { x_rcl lsjson --stat "$1" </dev/null >/dev/null 2>&1; }
x_rp() {
x_cs "$1" || { printf '%s:%s' "$RM" "$1"; return 0; }
case "$XCT" in
enc) ;;
mig) if [ "$2" = r ] && ! x_has "$XCS:$XCP"; then printf '%s:%s' "$RM" "$1"; return 0; fi ;;
back) { [ "$2" = r ] && x_has "$XCS:$XCP"; } || { printf '%s:%s' "$RM" "$1"; return 0; } ;;
*) printf '%s:%s' "$RM" "$1"; return 0 ;;
esac
printf '%s:%s' "$XCS" "$XCP"
}
x_rpo() {
x_cs "$1" || return 0
case "$XCT" in mig) printf '%s:%s' "$RM" "$1" ;; back|root) printf '%s:%s' "$XCS" "$XCP" ;; esac
}
x_both() { a_=$(x_rp "$1"); b_=$(x_rpo "$1"); case "$a_" in "$RM:"*) printf '%s\n' "$a_" ${b_:+"$b_"} ;; *) printf '%s\n' ${b_:+"$b_"} "$a_" ;; esac; }
x_sides() {
a_=$(x_rp "$1"); b_=$(x_rpo "$1")
[ -n "$b_" ] || { printf '%s\n' "$a_"; return 0; }
for s_ in "$a_" "$b_"; do x_has "$s_" && printf '%s\n' "$s_"; done; true
}
x_cmig() {
x_cs "$1" || return 0
case "$XCT" in mig|back) ;; *) return 0 ;; esac
f_=$XD/cr/$J_id.cur; [ -s "$f_" ] || return 0
read -r k_ < "$f_"; p_=$(cat "$XD/cr/$J_id.lk/pid" 2>/dev/null)
x_alive "$p_" && [ "$(printf '%s' "$k_" | tr 'A-Z' 'a-z')" = "$(printf '%s' "$XCK" | tr 'A-Z' 'a-z')" ] && return 1
true
}
x_cmr() {
[ -n "$1" ] || return 1
c_=$(printf '%s' "$1" | ucode -e 'let m = null; try { m = json(require("fs").stdin.read("all")); } catch (e) {}
function ok(s) { return type(s) == "string" && match(s, /^wf[a-z0-9]{1,40}$/) != null; }
function pt(s) { return type(s) == "string" && !match(s, /[[:cntrl:]]/) && !match("/" + s + "/", /\/\.\.?\//); }
if (type(m) != "object" || !ok(m.sec) || !pt(m.path)) exit(1);
let a = type(m.alt) == "object" && ok(m.alt.sec) && pt(m.alt.path) ? m.alt.sec + ":" + m.alt.path : "";
print(m.st ?? "", "\t", m.sec + ":" + m.path, "\t", a);' 2>/dev/null) && [ -n "$c_" ] || return 1
tb_=$(printf '\t'); s_=${c_%%"$tb_"*}; c_=${c_#*"$tb_"}; r1_=${c_%%"$tb_"*}; r2_=${c_#*"$tb_"}
grep -qxF "[${r1_%%:*}]" "$XCF" 2>/dev/null || return 1
case "$s_" in
mig) if [ -n "$r2_" ] && ! x_has "$r1_"; then printf '%s' "$r2_"; else printf '%s' "$r1_"; fi ;;
back) if [ -n "$r2_" ] && x_has "$r2_"; then printf '%s' "$r2_"; else printf '%s' "$r1_"; fi ;;
*) printf '%s' "$r1_" ;;
esac
}
x_cuniq() { XUN=$2; x_exists "${1:+$1/}$XUN" || return 0; ub=$2; ux=; case "$ub" in ?*.*) ux=.${ub##*.}; ub=${ub%.*} ;; esac
ui=2; while x_exists "${1:+$1/}$ub ($ui)$ux" && [ $ui -lt 100 ]; do ui=$((ui + 1)); done; XUN="$ub ($ui)$ux"; }
x_pp() {
XPD=; PP=$1; s_=$(x_cmr "$J_cm") || s_=$(x_rp "$1" r)
case "$s_" in "$RM:"*) PP=${s_#*:}; return 0 ;; esac
c_=${s_%%:*}; p_=${s_#*:}
b_=$(awk -v S="[$c_]" '$0 == S { f = 1; next } /^\[/ { f = 0 } f && /^remote *= */ { sub(/^remote *= */, ""); print; exit }' "$XCF")
[ "${b_%%:*}" = "$RM" ] || return 1
e_=$(x_rcl cryptdecode --reverse "$c_:" "$p_" </dev/null 2>/dev/null | head -n 1 | cut -f2 | sed 's/^ *//; s/ *$//')
[ -n "$e_" ] || return 1
b_=${b_#*:}; b_=${b_#/}; b_=${b_%/}
XPD=1; PP=${b_:+$b_/}$e_
}
x_ctok() {
XTU=; XTX=; mkdir -p $XD/dl /tmp/wf-nas/x/st
j_=$(XN=$2 XX=$(( $(date +%s) + 3600 )) ucode -e 'let fs = require("fs"), s = fs.readfile("/dev/urandom", 36) ?? "", A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", t = "", j = "j";
if (length(s) < 36) exit(1);
for (let i = 0; i + 2 < 24; i += 3) { let v = (ord(s, i) << 16) | (ord(s, i + 1) << 8) | ord(s, i + 2); t += substr(A, (v >> 18) & 63, 1) + substr(A, (v >> 12) & 63, 1) + substr(A, (v >> 6) & 63, 1) + substr(A, v & 63, 1); }
for (let i = 24; i < 36; i++) j += substr("abcdefghijklmnopqrstuvwxyz0123456789", ord(s, i) % 36, 1);
print(j, " ", t);' 2>/dev/null) || return 1
jj=${j_% *}; tk=${j_#* }; [ -n "$jj" ] && [ -n "$tk" ] || return 1
O_=$XD/dl/$jj
x_rcl cat "$1" --count "$3" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" > "$O_" && [ -s "$O_" ] || { rm -f "$O_"; return 1; }
chmod 600 "$O_"
XTX=$(( $(date +%s) + 3600 ))
XN=$2 XO=$O_ XJ=$jj XT=$tk XX=$XTX ucode -e 'let fs = require("fs"), n = time(), j = getenv("XJ"), t = getenv("XT"), x = +getenv("XX");
let ok = fs.writefile("/tmp/wf-nas/x/st/" + t + ".json", sprintf("%J", { p: getenv("XO"), n: getenv("XN"), t: n, a: n, cloud: j, x: x })) && fs.writefile(getenv("XO") + ".tok", sprintf("%J", { tk: t, x: x }));
exit(ok ? 0 : 1);' 2>/dev/null || { rm -f "$O_" "$O_.tok" "/tmp/wf-nas/x/st/$tk.json"; return 1; }
chmod 600 "/tmp/wf-nas/x/st/$tk.json" "$O_.tok" 2>/dev/null
XTU=/cgi-bin/wf-nasx/t/$tk/$(XN=$2 ucode -e 'let s = getenv("XN"), o = ""; for (let i = 0; i < length(s); i++) { let c = substr(s, i, 1); o += match(c, /^[A-Za-z0-9._~-]$/) ? c : sprintf("%%%02X", ord(s, i)); } print(o);' 2>/dev/null)
}
x_cflow() {
XTU=; XTX=; s_=${1%%:*}
grep -qxF "[$s_]" "$XCF" 2>/dev/null || return 1
if printf '%s' "$s_" | grep -qE '^wfa[0-9]{1,2}$'; then XCFF=$XCF; else XCFF=; fi
b_=$(awk -v S="[$s_]" '$0 == S { f = 1; next } /^\[/ { f = 0 } f && /^remote *= */ { sub(/^remote *= */, ""); print; exit }' "$XCF")
b_=${b_%%:*}; [ "$b_" = "$s_" ] && b_=
mkdir -p $XD/fl /tmp/wf-nas/x/st && chmod 700 $XD/fl
XL=$XD/fl ucode -e 'let fs = require("fs"), d = getenv("XL"), n = time(), U = {};
for (let f in fs.lsdir("/tmp/wf-nas/x/st") ?? []) { let v = null; try { v = json(fs.readfile("/tmp/wf-nas/x/st/" + f) ?? ""); } catch (e) {}
	if (type(v) == "object" && type(v.cr) == "object" && type(v.cr.f) == "string" && n < (v.x ?? 0)) U[v.cr.f] = true; }
for (let f in fs.lsdir(d) ?? []) { let p = d + "/" + f, s = fs.lstat(p);
	if (s && match(f, /\.conf(\.[0-9]+)?$/) && (n - s.mtime >= 43200 || (match(f, /\.conf$/) && !U[p]))) fs.unlink(p); }' 2>/dev/null
if [ -z "$XCFF" ]; then
( umask 077; awk -v A="[$s_]" -v B="${b_:+[$b_]}" '/^\[/ { f = ($0 == A || $0 == B) }
			f && /^token[ \t]*=/ { gsub(/"refresh_token"[ \t]*:[ \t]*"[^"]*"[ \t]*,?[ \t]*/, ""); gsub(/,[ \t]*}/, "}") } f' "$XCF" > "$XD/fl/$s_.conf.$$" ) &&
mv -f "$XD/fl/$s_.conf.$$" "$XD/fl/$s_.conf" || { rm -f "$XD/fl/$s_.conf.$$"; return 1; }
XCFF=$XD/fl/$s_.conf
fi
XTX=$(( $(date +%s) + 43200 ))
tk=$(XR=$1 XF=$XCFF XS=$3 XN=$2 XX=$XTX ucode -e 'let fs = require("fs"), s = fs.readfile("/dev/urandom", 24) ?? "", A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", t = "", n = time();
if (length(s) < 24) exit(1);
for (let i = 0; i + 2 < 24; i += 3) { let v = (ord(s, i) << 16) | (ord(s, i + 1) << 8) | ord(s, i + 2); t += substr(A, (v >> 18) & 63, 1) + substr(A, (v >> 12) & 63, 1) + substr(A, (v >> 6) & 63, 1) + substr(A, v & 63, 1); }
let ok = fs.writefile("/tmp/wf-nas/x/st/" + t + ".json", sprintf("%J", { cr: { r: getenv("XR"), f: getenv("XF"), s: +getenv("XS") }, n: getenv("XN"), t: n, a: n, x: +getenv("XX") }));
if (!ok) exit(1);
print(t);' 2>/dev/null) && [ -n "$tk" ] || return 1
chmod 600 "/tmp/wf-nas/x/st/$tk.json" 2>/dev/null
XTU=/cgi-bin/wf-nasx/t/$tk/$(XN=$2 ucode -e 'let s = getenv("XN"), o = ""; for (let i = 0; i < length(s); i++) { let c = substr(s, i, 1); o += match(c, /^[A-Za-z0-9._~-]$/) ? c : sprintf("%%%02X", ord(s, i)); } print(o);' 2>/dev/null)
}
x_cmax() {
lm=$(XF=$XCJ XK=$1 ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} print(int(N.lim?.[getenv("XK")] ?? 0));' 2>/dev/null)
[ "${lm:-0}" -gt 0 ] 2>/dev/null || { if [ "$(cat $XD/tier 2>/dev/null)" = A ]; then lm=$2; else lm=$3; fi; }
fr=$(df -k /tmp 2>/dev/null | awk 'NR == 2 { print int($4 * 512) }')
b_=$((lm * 1048576)); [ -n "$fr" ] && [ "$fr" -lt "$b_" ] && b_=$fr
echo "$b_"
}
x_rdconf() {
export RCLONE_CONFIG=$XCF RCLONE_CACHE_DIR=$XD/rclone-cache
l=$XD/acct-$1.lock; p=$(cat "$l/pid" 2>/dev/null || cat "$l" 2>/dev/null)
{ x_alive "$p" && [ "$p" != $$ ]; } || return 0
e=$(awk -v S="[wf$1]" '$0 == S { f = 1; next } /^\[/ { f = 0 } f && /^token *= */ { if (match($0, /"expiry":"[^"]*"/)) print substr($0, RSTART + 10, RLENGTH - 11); exit }' "$XCF")
case "$e" in
''|0001-*) ;;
*) d=$(printf '%s' "$e" | sed -n 's/^\([0-9-]*\)T\([0-9:]*\).*$/\1 \2/p'); o=$(printf '%s' "$e" | sed -n 's/^.*\([+-]\)\([0-9][0-9]\):\([0-9][0-9]\)$/\1 \2 \3/p')
s=$(date -u -d "$d" +%s 2>/dev/null) || return 1
[ -n "$o" ] && set -- "$1" $o && { if [ "$2" = + ]; then s=$((s - ${3#0} * 3600 - ${4#0} * 60)); else s=$((s + ${3#0} * 3600 + ${4#0} * 60)); fi; }
[ "$s" -gt $(( $(date +%s) + 900 )) ] || return 1 ;;
esac
XRO=$XD/ro.$$.conf; cp "$XCF" "$XRO" && chmod 600 "$XRO" && export RCLONE_CONFIG=$XRO
}
x_pc() {
a=$1; m=$2; tm=$3; shift 3
XB=$XD/pc.$$.body; XG=$XD/pc.$$.args
: > "$XG"; for x in "$@"; do printf '%s' "$x" | tr '\n\r' '  ' >> "$XG"; printf '\n' >> "$XG"; done
h=$(XA=$a XF=$XCF XJ=$XCJ XB=$XB XG=$XG ucode -e '
let fs = require("fs"), S = "[wf" + getenv("XA") + "]", f = false, tok = "", host = "", c = fs.readfile(getenv("XF")) ?? "";
for (let l in split(c, "\n")) {
	if (substr(l, 0, 1) == "[") { f = (l == S); continue; }
	if (!f) continue;
	let m = match(l, /^token *= *(.*)$/);
	if (m) try { tok = json(m[1]).access_token ?? ""; } catch (e) {}
	m = match(l, /^hostname *= *([a-z0-9.-]+)$/);
	if (m) host = m[1];
}
if (host == "") { try { for (let x in (json(fs.readfile(getenv("XJ")) ?? "{}").accounts ?? [])) if (x.id == getenv("XA")) host = x.host ?? ""; } catch (e) {} }
if (!match(host, /^[a-z0-9.-]*pcloud\.com$/)) host = "api.pcloud.com";
if (tok == "") exit(1);
function ue(s) { let o = ""; for (let i = 0; i < length(s); i++) { let c = substr(s, i, 1); o += match(c, /^[A-Za-z0-9._~-]$/) ? c : sprintf("%%%02X", ord(s, i)); } return o; }
let b = "access_token=" + ue(tok);
for (let x in split(fs.readfile(getenv("XG")) ?? "", "\n")) { let i = index(x, "="); if (i > 0) b += "&" + substr(x, 0, i) + "=" + ue(substr(x, i + 1)); }
fs.writefile(getenv("XB"), b);
print(host);' 2>/dev/null) || { rm -f "$XB" "$XG"; echo '{"result":1000}'; return 0; }
rm -f "$XG"
if command -v curl >/dev/null 2>&1; then curl -s -m "$tm" -H 'Expect:' --data-binary "@$XB" "https://$h/$m" </dev/null 2>/dev/null
elif wget --help 2>&1 | grep -q -- '--post-file'; then wget -q -T "$tm" -O - --post-file="$XB" "https://$h/$m" </dev/null 2>/dev/null
else uclient-fetch -q -T "$tm" -O - --post-file "$XB" "https://$h/$m" </dev/null 2>/dev/null; fi
rm -f "$XB"
}
x_pcok() {
r=$(x_jget "$1" 'N.result')
[ "$r" = 0 ] && return 0
printf '{"result": %s}\n' "${r:-5000}" > "$LOG.pc"; XC=$(x_tr "$LOG.pc"); rm -f "$LOG.pc"
[ -z "$r" ] && XC=net
return 1
}
x_pcokf() {
r=$(XF=$1 ucode -e 'let N = null; try { N = json(require("fs").readfile(getenv("XF")) ?? ""); } catch (e) {} if (type(N) == "object" && type(N.result) == "int") print(N.result);' 2>/dev/null)
[ "$r" = 0 ] && return 0
x_pcok "{\"result\":${r:-null}}"
}

x_gen() {
for a_ in "$@"; do
printf '%s' "$a_" | grep -qE '^a[0-9]{1,3}$' || continue
v_=$(tr -d '-' < /proc/sys/kernel/random/uuid 2>/dev/null | cut -c1-10); [ -n "$v_" ] || v_=$(date +%s).$$
printf '%s\n' "$v_" > "$XD/gen-$a_.$$" && mv -f "$XD/gen-$a_.$$" "$XD/gen-$a_" || rm -f "$XD/gen-$a_.$$"
done
true
}
x_res() {
case "$J_act" in mkdir|move|rm|restore|revert|upreq|link) x_gen "$J_id" ;; esac
printf '%s\n' "$1" > "$XD/res/$REQ.json.$$" && mv "$XD/res/$REQ.json.$$" "$XD/res/$REQ.json"
}
x_rerr() { x_log; rm -f "$XRO"; x_res "{\"error\":\"$(x_e "$(x_msg it "$1")")\",\"error_en\":\"$(x_e "$(x_msg en "$1")")\",\"code\":\"$1\"$XRX}"; exit 0; }
x_req() {
REQ=$1; printf '%s' "$REQ" | grep -qE '^[A-Za-z0-9_-]{1,40}$' || exit 2
F=$XD/req/$REQ.json; [ -f "$F" ] || exit 2
LOG=$XD/log/r-$REQ; : > "$LOG"
eval "$(x_vars "$F" id path q to name paths expire pass max msg max_mb to_nas act disk trash size rev off kind tids own ppl cm pub mode empty forever du)"
command -v rclone >/dev/null 2>&1 || x_rerr pkg
x_acct "$J_id" || x_rerr none
x_own "$J_own" || x_rerr none
x_rdconf "$J_id" || x_rerr busy
XP=$(x_path "$J_path") || x_rerr path
XFL=1; [ "$(cat $XD/tier 2>/dev/null)" = A ] && XFL=
if cl_mem rclonepush && [ "$CL_GO" -ge 32 ]; then export GOMEMLIMIT=${CL_GO}MiB; elif [ -z "$XFL" ]; then export GOGC=20; fi
trap 'rm -f "$XRO"' EXIT
}
x_rcl() { ( cl_in; exec rclone "$@" ${XHD:+--b2-hard-delete} --contimeout 15s --timeout 60s ); }
x_r() { x_rcl "$@" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG"; }

c_about() {
x_req "$1"
o=$(x_r about "$RM:" --json) || x_rerr "$(x_tr "$LOG")"
o=$(printf '%s' "$o" | ucode -e 'let a = null; try { a = json(require("fs").stdin.read("all")); } catch (e) {} let r = { t: time() }; if (type(a) == "object") for (let k in [ "total", "used", "free" ]) if (type(a[k]) == "int" && a[k] >= 0) r[k] = a[k]; printf("%J\n", r);' 2>/dev/null)
[ -n "$o" ] || x_rerr fail
x_log; x_res "$o"
}
x_lst() {
( cl_in; exec ${XTM:+timeout "$XTM"} rclone "$@" ${XHD:+--b2-hard-delete} --contimeout 15s --timeout 60s ); r_=$?
{ [ $r_ = 124 ] || [ $r_ = 143 ]; } && [ -n "$XTM" ] && : > "$o.t"
return $r_
}
c_ls() {
x_req "$1"
XTM=; command -v timeout >/dev/null 2>&1 && XTM=${WF_LSTM:-60}
mx=$(XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} let m = int(N.lim?.ls_max ?? 50000); print(m >= 100 && m <= 500000 ? m : 50000);' 2>/dev/null)
mx=${mx:-50000}
o=$XD/ls.$$; trap 'rm -f "$XRO" "$o" "$o".*' EXIT
if [ "$J_du" = 1 ]; then
x_both "$XP" > "$o.d"; tb_=0; tc_=0
while IFS= read -r s_; do
x_has "$s_" || continue
v_=$(x_lst size "$s_" --json --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s) == "object") print(int(s.bytes ?? 0), " ", int(s.count ?? 0));' 2>/dev/null)
[ -f "$o.t" ] && { x_log; x_res '{"bytes":0,"count":0,"more":true}'; exit 0; }
[ -n "$v_" ] || x_rerr "$(x_tr "$LOG")"
tb_=$((tb_ + ${v_% *})); tc_=$((tc_ + ${v_#* }))
done < "$o.d"
x_log; x_res "{\"bytes\":$tb_,\"count\":$tc_,\"more\":false}"; exit 0
fi
L1=$RM:$XP; L2=; XE1=0
if x_cs "$XP"; then case "$XCT" in enc) L1=$XCS:$XCP; XE1=1 ;; *) L2=$XCS:$XCP ;; esac; fi
if [ -n "$J_q" ]; then
qq=$(printf '%s' "$J_q" | tr -d '*?[]{}\\\n\r' | ucode -e 'let s = require("fs").stdin.read("all") ?? "", n = 0, i = 0;
for (; i < length(s); i++) if ((ord(s, i) & 192) != 128 && ++n > 80) break;
print(substr(s, 0, i));' 2>/dev/null)
[ -n "$qq" ] || x_rerr path
x_lst lsf "$L1" -R --format pst --separator '	' --include "*$qq*" --include "*$qq*/**" --ignore-case ${XFL:+--fast-list} \
			--log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | sed -n "1,$((mx + 1))p" > "$o"
[ -n "$L2" ] && x_lst lsf "$L2" -R --format pst --separator '	' --include "*$qq*" --include "*$qq*/**" --ignore-case ${XFL:+--fast-list} \
			</dev/null 2>/dev/null | sed -n "1,$((mx + 1))p" > "$o.c"
else
[ "$XS" != pcloud ] && x_phin "$XP" && x_phbg
x_lst lsf "$L1" --format pst --separator '	' --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | sed -n "1,$((mx + 1))p" > "$o"
[ -n "$L2" ] && x_lst lsf "$L2" --format pst --separator '	' </dev/null 2>/dev/null | sed -n "1,$((mx + 1))p" > "$o.c"
fi
LCT=$XCT; LCS=$XCS
if [ ! -s "$o" ] && [ -s "$LOG" ] && [ -n "$XPU" ] && { [ "$XP" = "$XPU" ] || [ "$XP" = "$XPS" ]; } && [ "$(x_tr "$LOG")" = path ]; then
: > "$LOG"; x_mkd "$(x_rp "$XP")" || { rm -f "$o"; x_rerr "$(x_tr "$LOG")"; }
: > "$LOG"
fi
[ -s "$o" ] || [ -s "$o.c" ] || { [ -s "$LOG" ] && { rm -f "$o" "$o.c" "$o.x"; x_rerr "$(x_tr "$LOG")"; }; }
[ -s "$o.c" ] && : > "$LOG"
if [ -z "$J_q" ] && x_cbase "$XP"; then
: > "$LOG"
x_rcl lsf "$L1" --format pst --separator '	' --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | sed -n "1,$((mx + 1))p" > "$o.2"
if [ -s "$o.2" ]; then mv "$o.2" "$o"; else rm -f "$o.2"; fi
[ -n "$L2" ] && x_rcl lsf "$L2" --format pst --separator '	' </dev/null 2>/dev/null | sed -n "1,$((mx + 1))p" > "$o.c"
: > "$LOG"
fi
if [ "$LCT" = root ] && [ -s "$o" ]; then
cut -f1 "$o" | sed 's#/.*#/#' | sort -u > "$o.n"
set --; while IFS= read -r n_; do [ -n "$n_" ] && set -- "$@" "$n_"; done < "$o.n"
[ $# -gt 0 ] && x_rcl cryptdecode "$LCS:" "$@" </dev/null 2>/dev/null | awk -F '\t' '$2 !~ /Failed to decrypt/ { sub(/ +$/, "", $1); sub(/\/$/, "", $1); print $1 }' > "$o.x"
rm -f "$o.n"
fi
XSH=; XSHT=
if [ -z "$J_q" ] && [ -n "$XP" ]; then
XSH=$(x_shl "$XP/$(wf_udir shared root | sed 's#.*/##')") || XSH=
[ -n "$XSH" ] && XSHT=$(x_rcl lsjson --stat "$(x_rp "$XSH")" </dev/null 2>/dev/null | ucode -e 'let o = null; try { o = json(require("fs").stdin.read("all")); } catch (e) {} let t = "" + (o?.ModTime ?? ""); if (match(t, /^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:]{8}/)) print(substr(t, 0, 10) + " " + substr(t, 11, 8));' 2>/dev/null)
fi
r=$(XO=$o XM=$mx XP=$XP XS=$XS XA=$J_id XL=$XLJ XQ=$J_q XR=$F XE1=$XE1 XSH=$XSH XSHT=$XSHT ucode -e '
let fs = require("fs"), m = int(getenv("XM")), P = getenv("XP"), it = [], more = !!fs.stat(getenv("XO") + ".t"), sh = {}, H = [];
try { for (let l in (json(fs.readfile(getenv("XL")) ?? "{}").items ?? [])) if (l.id == getenv("XA")) sh[l.path] = true; } catch (e) {}
try { H = map(filter(json(fs.readfile(getenv("XR")) ?? "{}").hide ?? [], (h) => type(h) == "string" && length(h)), lc); } catch (e) { H = []; }
/* 3.44: voci del crypt (enc) prima, poi quelle del chiaro senza i nomi già visti e senza i nomi cifrati (.x) */
let SL = [], SN = {}, DR = {};
for (let l in split(fs.readfile(getenv("XO") + ".x") ?? "", "\n")) if (l != "") DR[l] = true;
for (let l in split(fs.readfile(getenv("XO") + ".c") ?? "", "\n")) if (l != "") { let n0 = replace(split(l, "\t")[0], /\/$/, ""); if (!SN[n0]) { SN[n0] = true; push(SL, [ l, true ]); } }
for (let l in split(fs.readfile(getenv("XO")) ?? "", "\n")) if (l != "") { let n0 = replace(split(l, "\t")[0], /\/$/, ""); if (!SN[n0] && !DR[split(n0, "/")[0]]) push(SL, [ l, getenv("XE1") == "1" ]); }
for (let L in SL) {
	let l = L[0];
	if (length(it) >= m) { more = true; break; }
	let c = split(l, "\t"), n = c[0], d = substr(n, -1) == "/";
	if (d) n = substr(n, 0, length(n) - 1);
	if (getenv("XS") == "pcloud" && P == "" && n == "Crypto Folder") continue;
	/* NF 6: Cestino di WrtFreedom (.wf-trash alla radice) mai in Sfoglia né in Cerca */
	if (P == "" && (n == ".wf-trash" || substr(n, 0, 10) == ".wf-trash/")) continue;
	let full = (P == "" ? "" : P + "/") + n, x = { name: n, dir: d, size: d ? 0 : int(c[1] ?? 0), mtime: c[2] ?? "", shared: !!sh[full] };
	if (L[1]) x.enc = true;
	let lf = lc(full), hv = null;
	for (let h in H) if (lf == h) hv = "lock"; else if (substr(lf, 0, length(h) + 1) == h + "/") hv = "in";
	if (hv == "in" || (hv == "lock" && (!d || length(getenv("XQ") ?? "")))) continue;
	if (hv == "lock") { x.lock = true; x.shared = false; push(it, x); continue; }
	/* dentro la cartella dei backup (Utenti/<persona>/Backup, mai in Cartella Condivisa; o quelle delle versioni di prima):
	   ogni cartella è un backup, bk = il suo nome */
	if (d && (P == "WrtFreedom/Backup" || P == "WrtFreedom Backup" || (match(P, /^Utenti\/[^\/]+\/Backup$/) && !match(P, /^Utenti\/Cartella Condivisa\//)))) x.bk = n;
	push(it, x);
}
/* 19/11: voce «Cartella Condivisa» nella cartella di una persona (XSH = percorso vero), solo se manca */
let S = getenv("XSH") ?? "", sn = replace(S, /^.*\//, "");
if (length(S) && !length(filter(it, (x) => x.name == sn))) push(it, { name: sn, dir: true, size: 0, mtime: getenv("XSHT") ?? "", shared: !!sh[S] });
printf("%J\n", { items: it, path: P, more });' 2>/dev/null)
rm -f "$o" "$o.c" "$o.x"; [ -n "$r" ] || x_rerr fail
x_log; x_res "$r"
}
x_exists() { pa=${1%/*}; [ "$pa" = "$1" ] && pa=; po=$(x_rpo "$pa")
{ x_r lsf "$(x_rp "$pa")" --max-depth 1; [ -n "$po" ] && x_rcl lsf "$po" --max-depth 1 </dev/null 2>/dev/null; } | sed 's#/$##' | grep -qxF "${1##*/}"; }
x_vq() {
[ -f "$XD/mnt/$J_id.pport" ] && [ -f "$XW/cloudmnt.sh" ] || return 1
q_=$(sh "$XW/cloudmnt.sh" rc "$J_id" view vfs/queue </dev/null 2>/dev/null) && [ -n "$q_" ] || return 1
printf '%s' "$q_" | XP=$1 ucode -e 'let q = null; try { q = json(require("fs").stdin.read("all")); } catch (e) {}
let p = getenv("XP");
for (let x in (type(q?.queue) == "array" ? q.queue : [])) { let n = "Utenti/" + (x?.name ?? "");
	if (n == p || substr(n, 0, length(p) + 1) == p + "/") exit(0); }
exit(1);' 2>/dev/null
}
x_hk() {
case "$XAO" in ''|admin) ;; *) return 0 ;; esac
[ "$XOWN" = admin ] && h_='*' || h_=$XOWN
[ -n "$h_" ] || return 0
printf '%s\n' "$h_" >> $XD/home.dirty
XU=${WF_CLOUDUC:-$XW/cloud.uc}; [ -f "$XU" ] && ( ucode "$XU" ukick </dev/null >/dev/null 2>&1 & )
true
}
XWT=.wf-trash; XWTD=30; XWTM=5000
x_wtis() { case "$XS" in pcloud|drive|onedrive|dropbox|'') return 1 ;; esac; true; }
x_wtread() {
x_rcl cat "$RM:$XWT/.wf-list" </dev/null > "$1" 2>/dev/null; rc_=$?
[ $rc_ = 0 ] && return 0
: > "$1"
[ $rc_ = 3 ] || [ $rc_ = 4 ]
}
x_wtflush() {
[ -s "$XWN" ] || return 0
k0_=$K; x_lkget "wt-$J_id"; o_=$XD/wtf.$$; pf_=$XD/wt-$J_id.pend
if x_wtread "$o_"; then
cat "$pf_" "$XWN" 2>/dev/null >> "$o_"
n_=$(grep -c . "$o_")
if [ "$n_" -gt $XWTM ]; then
head -n $((n_ - XWTM)) "$o_" | cut -f1 > "$o_.x"; tail -n $XWTM "$o_" > "$o_.k"; mv "$o_.k" "$o_"
while IFS= read -r t_; do x_rcl purge "$RM:$XWT/$t_" </dev/null >/dev/null 2>&1; done < "$o_.x"
fi
if x_rcl rcat "$RM:$XWT/.wf-list" < "$o_" >/dev/null 2>&1; then rm -f "$pf_"; else cat "$XWN" >> "$pf_"; fi
else cat "$XWN" >> "$pf_"; fi
rm -f "$o_" "$o_.x" "$o_.k"; : > "$XWN"; rm -f "$XD/trash-$J_id.json"
x_lkput "wt-$J_id"; K=$k0_
}
x_wtdrop() {
k0_=$K; x_lkget "wt-$J_id"; o_=$XD/wtd.$$; pf_=$XD/wt-$J_id.pend
if x_wtread "$o_"; then
cat "$pf_" 2>/dev/null >> "$o_"
awk -F '\t' -v M="${2:-0}" 'NR == FNR { d[$1] = 1; next } !($1 in d) && $2 + 0 >= M + 0' "$1" "$o_" > "$o_.k"
if [ -s "$o_.k" ]; then x_rcl rcat "$RM:$XWT/.wf-list" < "$o_.k" >/dev/null 2>&1 && rm -f "$pf_"
else x_rcl deletefile "$RM:$XWT/.wf-list" </dev/null >/dev/null 2>&1; rm -f "$pf_"; fi
fi
rm -f "$o_" "$o_.k" "$XD/trash-$J_id.json"
x_lkput "wt-$J_id"; K=$k0_
}
x_wtput() {
st_=$(x_rcl lsjson --stat "$1" </dev/null 2>/dev/null | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s) == "object") print(s.IsDir ? 1 : 0, " ", s.IsDir || !(s.Size > 0) ? 0 : int(s.Size));' 2>/dev/null)
[ -n "$st_" ] || { x_r lsjson --stat "$1" >/dev/null; return 1; }
XWK=$((XWK + 1)); tid_=w$(date +%s)$(printf '%04d' $(( ($$ * 13 + XWK) % 10000 )))
x_r moveto "$1" "$RM:$XWT/$tid_/${2##*/}" || return 1
printf '%s\t%s\t%s\t%s\t/%s\n' "$tid_" "$(date +%s)" "${st_% *}" "${st_#* }" "$2" >> "$XWN"
}
c_wtrm() {
XWN=$XD/wtn.$$; : > "$XWN"; XWK=0
trap 'x_wtflush; rm -f "$XRO" "$XWN" $XD/op.$$ $XD/op.$$.s; [ -z "$XHC" ] || x_hk' EXIT
if [ "$J_empty" = 1 ]; then
[ -z "$XPU" ] || x_rerr admin
k0_=$K; x_lkget "wt-$J_id"
x_r purge "$RM:$XWT"; rc_=$?
x_lkput "wt-$J_id"; K=$k0_
[ $rc_ = 0 ] || [ $rc_ = 3 ] || x_rerr "$(x_tr "$LOG")"
: > "$LOG"; rm -f "$XD/wt-$J_id.pend" "$XD/trash-$J_id.json"
x_log; x_res '{"ok":true}'; exit 0
fi
[ -n "$J_paths" ] || x_rerr path
printf '%s\n' "$J_paths" > $XD/op.$$; k=0
while IFS= read -r p; do
XRX=",\"done\":$k"; k=$((k + 1))
p=$(x_path "$p") && [ -n "$p" ] || x_rerr path
x_vq "$p" && x_rerr busy
x_cmig "$p" || x_rerr cmig
x_sides "$p" > $XD/op.$$.s; [ -s $XD/op.$$.s ] || x_rerr path
XHC=1
while IFS= read -r s; do
case "$s" in
"$RM:"*) x_wtput "$s" "$p" || x_rerr "$(x_tr "$LOG")" ;;
*) x_r deletefile "$s" 2>/dev/null || { : > "$LOG"; x_r purge "$s" || x_rerr "$(x_tr "$LOG")"; } ;;
esac
done < $XD/op.$$.s
done < $XD/op.$$
x_wtflush
[ -f "$XW/cloudmnt.sh" ] && ( sh "$XW/cloudmnt.sh" refresh "$J_id" </dev/null >/dev/null 2>&1 & )
x_log; x_res '{"ok":true}'; exit 0
}
x_wtbuild() {
x_wtread "$o" || x_rerr fail
cat "$XD/wt-$J_id.pend" >> "$o" 2>/dev/null
x_rcl lsf -R --max-depth 2 "$RM:$XWT" </dev/null > "$o.d" 2>/dev/null; rc_=$?
[ $rc_ = 0 ] || [ $rc_ = 3 ] || x_rerr fail
XO=$o XK=$K XN=$$ XDY=$XWTD ucode -e 'let fs = require("fs"), o = getenv("XO"), D = {}, L = [], seen = {}, lim = time() - int(getenv("XDY")) * 86400;
for (let l in split(fs.readfile(o + ".d") ?? "", "\n")) { let m = match(l, /^(w[0-9]+)\/([^\/]+)(\/?)$/); if (m) D[m[1]] = { name: m[2], dir: m[3] == "/" }; }
for (let l in split(fs.readfile(o) ?? "", "\n")) { let c = split(l, "\t"); if (length(c) < 5 || !D[c[0]] || seen[c[0]]) continue; seen[c[0]] = true;
	let t = int(c[1]); if (t < lim) continue;
	push(L, { tid: c[0], name: D[c[0]].name, path: c[4], dir: D[c[0]].dir, size: int(c[3]), t: t, wf: true }); }
for (let k, v in D) if (!seen[k] && match(k, /^w[0-9]{10,24}$/)) { let t = int(substr(k, 1, 10)); if (t >= lim) push(L, { tid: k, name: v.name, path: "", dir: v.dir, size: 0, t: t, wf: true }); }
L = sort(L, (a, b) => b.t - a.t);
let k = getenv("XK"), n = k + ".n." + getenv("XN"); if (!fs.writefile(n, sprintf("%J", { list: L, hid: [] })) || !fs.rename(n, k)) exit(1);' 2>/dev/null || x_rerr fail
rm -f "$o.d"
}
c_wttrash() {
o=$XD/tr.$$; K=$XD/trash-$J_id.json; trap 'rm -f "$XRO" "$o" "$o".* "$K.n.$$"' EXIT
off=$(printf '%s' "$J_off" | tr -cd '0-9'); off=${off:-0}
if [ "$off" = 0 ] || x_trold; then x_wtbuild; fi
r=$(XK=$K XOF=$off XPU=$XPU XPL=$J_ppl ucode -e "$X_TRF"'
let D = null; try { D = json(require("fs").readfile(getenv("XK")) ?? ""); } catch (e) {}
let A = type(D?.list) == "array" ? D.list : [], L = [], G = {}, R = [];
for (let x in A) { let w = whose(x); if (w == null) { push(L, x); continue; } if (type(w) != "object") continue;
	let g = G[w.own]; if (!g) { g = G[w.own] = { own: "" + w.own, own_name: "" + (w.own_name ?? w.own), n: 0 }; push(R, g); } g.n++; }
let o = +getenv("XOF"), n = length(L), out = { list: slice(L, o, o + 500), off: o, n: n, more: o + 500 < n, days: 30 };
if (length(P)) out.people = sort(R, (a, b) => a.own_name < b.own_name ? -1 : a.own_name > b.own_name ? 1 : 0);
printf("%J\n", out);' 2>/dev/null)
[ -n "$r" ] || x_rerr fail
x_log; x_res "$r"
}
x_wtsel() { XK=$K XT=$J_tids XPU=$XPU XPL=$J_ppl ucode -e "$X_TRF"'
let D = null; try { D = json(require("fs").readfile(getenv("XK")) ?? ""); } catch (e) {}
let V = {}, r = "ok", O = [];
for (let x in (type(D?.list) == "array" ? D.list : [])) if (type(x) == "object") V["" + x.tid] = x;
for (let t in split(getenv("XT") ?? "", /[ \t\n]+/)) { if (!match(t, /^w[0-9]{10,24}$/)) continue; let x = V[t];
	if (!x) { if (r == "ok") r = "miss"; continue; } if (whose(x) != null) { r = "priv"; break; } push(O, t + "\t" + x.name + "\t" + x.path); }
print(r, "\n"); for (let l in O) print(l, "\n");' 2>/dev/null; }
c_wtrestore() {
o=$XD/tr.$$; K=$XD/trash-$J_id.json; trap 'rm -f "$XRO" "$o" "$o".* "$K.n.$$"' EXIT
x_trold && x_wtbuild
x_wtsel > "$o.s"; r_=$(head -n 1 "$o.s")
[ "$r_" = miss ] && { x_wtbuild; x_wtsel > "$o.s"; r_=$(head -n 1 "$o.s"); }
[ "$r_" = priv ] && x_rerr private
[ "$r_" = miss ] && [ -n "$XPU" ] && x_rerr private
[ -n "$r_" ] || x_rerr fail
want=$(printf '%s\n' "$J_tids" | grep -c .); ok=0; : > "$o.ok"
tail -n +2 "$o.s" > "$o.l"
while IFS='	' read -r tid nm pa; do
[ -n "$tid" ] && [ -n "$nm" ] || continue
d=${pa#/}; [ -n "$d" ] || d=${XPU:+$XPU/}$nm
d=$(x_path "$d") && [ -n "$d" ] || continue
up_=${d%/*}; [ "$up_" = "$d" ] && up_=
x_cmig "$d" || continue
x_cuniq "$up_" "${d##*/}"
: > "$LOG"; x_r moveto "$RM:$XWT/$tid/$nm" "$(x_rp "${up_:+$up_/}$XUN")" || break
x_rcl rmdir "$RM:$XWT/$tid" </dev/null >/dev/null 2>&1
echo "$tid" >> "$o.ok"; ok=$((ok + 1))
done < "$o.l"
[ $ok -gt 0 ] && { XHC=1; x_wtdrop "$o.ok"; x_hk; [ -f "$XW/cloudmnt.sh" ] && ( sh "$XW/cloudmnt.sh" refresh "$J_id" </dev/null >/dev/null 2>&1 & ); }
[ $ok = 0 ] && [ -s "$LOG" ] && x_rerr "$(x_tr "$LOG")"
x_log; x_res "{\"ok\":true,\"restored\":$ok,\"left\":$((want - ok))}"
}
c_wtnight() {
command -v rclone >/dev/null 2>&1 && [ -f "$XCF" ] || return 0
case "$(cl_check wtnight '{}' 2>/dev/null)" in wait*) return 0 ;; esac
export RCLONE_CONFIG=$XCF RCLONE_CACHE_DIR=$XD/rclone-cache
lim=$(( $(date +%s) - XWTD * 86400 )); o=$XD/wtn.$$; trap 'rm -f "$o" "$o".*' EXIT
for a in $(sed -n 's/^\[wf\(a[0-9]\{1,2\}\)\]$/\1/p' "$XCF"); do
x_acct "$a" && x_wtis || continue
J_id=$a; LOG=$XD/log/wt-$a; : > "$LOG"
x_rcl lsf --dirs-only --max-depth 1 "$RM:$XWT" </dev/null > "$o" 2>/dev/null || continue
: > "$o.x"
while IFS= read -r t_; do
t_=${t_%/}
case "$t_" in w[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]*) ;; *) continue ;; esac
[ "$(printf '%s' "$t_" | cut -c2-11)" -lt "$lim" ] 2>/dev/null || continue
x_rcl purge "$RM:$XWT/$t_" </dev/null >/dev/null 2>&1 && echo "$t_" >> "$o.x"
done < "$o"
[ -s "$o.x" ] && { x_wtdrop "$o.x" "$lim"; x_gen "$a"; }
rm -f "$LOG"
done
true
}
c_cc() {
eval "$(x_vars $XD/jobs/$JOB.json to_id)"
[ -n "$J_to_id" ] && [ "$J_to_id" != "$J_id" ] || return 0
SRC=$J_id; TAB=$(printf '\t'); REN=$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.ren'); TB=0
RS=; { [ -n "$REN" ] || [ "$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.moved')" = 1 ]; } && RS=1
case "$(x_oth "$J_to_id")" in
relink) x_jerr relink ;;
ppause) x_slput; x_jw wait wc=ppause why='In Pausa' why_en='Paused' pid=0; exit 0 ;;
acct) x_slput; x_jwait acct; exit 0 ;;
esac
J_id=$J_to_id; x_acct "$J_id" && x_own "$J_own" || x_jerr none
DT=$(x_path "$J_to") || x_jerr path
x_cmig "$DT" || x_jerr cmig
printf '%s\n' "$J_paths" > $XD/flt.$$; : > $XD/flt.$$.m
while IFS= read -r p; do
[ -n "$p" ] || continue
nm=${p##*/}
un=$(printf '%s\n' "$REN" | XN=$nm awk -F '\t' '$1 == ENVIRON["XN"] { print $2; exit }')
if [ -z "$un" ]; then
x_cuniq "$DT" "$nm"; un=$XUN
REN="${REN:+$REN
}$nm$TAB$un"; x_jw run ren="$REN"
fi
printf '%s\t%s\n' "$p" "$(x_rp "${DT:+$DT/}$un")" >> $XD/flt.$$.m
done < $XD/flt.$$
J_id=$SRC; x_acct "$J_id" && x_own "$J_own" || x_jerr none
: > $XD/flt.$$.m2
while IFS='	' read -r p dd; do
p=$(x_path "$p") && [ -n "$p" ] || x_jerr path
x_cmig "$p" || x_jerr cmig
x_both "$p" > $XD/flt.$$.b; k_=0
while IFS= read -r s; do
x_has "$s" || continue
k_=1
if x_r lsjson --stat "$s" | grep '"IsDir": *true' >/dev/null; then x_run copy "$s" "$dd"; else x_run copyto "$s" "$dd"; fi
rc=$?; [ $rc = 0 ] || { rm -f $XD/flt.$$.b $XD/flt.$$.m $XD/flt.$$.m2; x_fin $rc; exit 0; }
bb=$(x_bytes); [ "${bb:-0}" -gt 0 ] 2>/dev/null && { cl_add "$bb" </dev/null >/dev/null 2>&1; TB=$((TB + bb)); }
done < $XD/flt.$$.b
[ $k_ = 1 ] || { [ "$RS" = 1 ] && continue; x_jerr path; }
printf '%s\t%s\n' "$p" "$dd" >> $XD/flt.$$.m2
done < $XD/flt.$$.m
: >> $XD/flt.$$.m2; mv -f $XD/flt.$$.m2 $XD/flt.$$.m
if [ "$J_move" = 1 ]; then
while IFS='	' read -r p dd; do
p=$(x_path "$p") || x_jerr path
[ -z "$(x_rpo "$p")" ] || x_jerr cmig
x_same "$(x_rp "$p" r)" "$dd" || x_jerr check
done < $XD/flt.$$.m
XWN=$XD/wtn.$$; : > "$XWN"; XWK=0
while IFS='	' read -r p dd; do
p=$(x_path "$p") || continue
s=$(x_rp "$p" r)
if x_wtis; then x_wtput "$s" "$p" || { x_wtflush; x_jerr "$(x_tr "$LOG")"; }
else x_r deletefile "$s" 2>/dev/null || x_r purge "$s" || x_jerr "$(x_tr "$LOG")"; fi
done < $XD/flt.$$.m
x_wtflush; rm -f "$XWN"; x_jw run moved=1
fi
rm -f $XD/flt.$$.b $XD/flt.$$.m
x_jw ok bytes="$TB" pct=100 pid=0 tries=0 err= err_en= code=; exit 0
}
c_op() {
XRX=; x_req "$1"
XHC=; trap 'rm -f "$XRO" $XD/op.$$ $XD/op.$$.s; [ -z "$XHC" ] || x_hk' EXIT
[ "$J_act" = rm ] && [ "$J_forever" != 1 ] && x_wtis && c_wtrm
if [ "$J_act" = rm ] && [ "$J_empty" = 1 ]; then
case "$XS" in pcloud|drive|onedrive) ;; *) x_rerr caps ;; esac
[ -z "$XPU" ] || x_rerr admin
x_r cleanup "$RM:" || x_rerr "$(x_tr "$LOG")"
x_log; x_res '{"ok":true}'; exit 0
fi
XFV=; [ "$J_act" = rm ] && [ "$J_forever" = 1 ] && case "$XS" in drive) XFV=--drive-use-trash=false ;; onedrive) XFV=--onedrive-hard-delete ;; pcloud) XFV=pc ;; esac
case "$J_act" in
mkdir) n=$(printf '%s' "$J_name" | tr -d '/\\\n\r'); [ -n "$n" ] && [ "$n" != . ] && [ "$n" != .. ] || x_rerr path
d=${XP:+$XP/}$n; x_cmig "$d" || x_rerr cmig; x_exists "$d" && x_rerr exists
x_r mkdir "$(x_rp "$d")" || x_rerr "$(x_tr "$LOG")" ;;
move|rm) [ -n "$J_paths" ] || x_rerr path
[ "$J_act" = move ] && { TO=$(x_path "$J_to") || x_rerr path; }
XTR=$J_trash; [ -n "$XTR" ] || case "$XS" in pcloud|drive|onedrive|dropbox) XTR=1 ;; *) XTR=0 ;; esac
printf '%s\n' "$J_paths" > $XD/op.$$
k=0
while IFS= read -r p; do
XRX=",\"done\":$k"; k=$((k + 1))
p=$(x_path "$p") && [ -n "$p" ] || x_rerr path
x_vq "$p" && x_rerr busy
if [ "$J_act" = move ]; then
if [ -n "$J_name" ]; then
n=$J_name; case "$n" in ''|.|..|*/*|*\\*) x_rerr path ;; esac
[ "$(printf '%s' "$n" | tr -d '\n\r')" = "$n" ] || x_rerr path
case "$p" in */*) d=${p%/*}/$n ;; *) d=$n ;; esac
else d=${TO:+$TO/}${p##*/}; fi
x_exists "$d" && x_rerr exists
{ x_cmig "$p" && x_cmig "$d"; } || x_rerr cmig
x_sides "$p" > $XD/op.$$.s; [ -s $XD/op.$$.s ] || x_rerr path
dd=$(x_rp "$d"); XHC=1
while IFS= read -r s; do x_r moveto "$s" "$dd" || x_rerr "$(x_tr "$LOG")"; done < $XD/op.$$.s
else
x_cmig "$p" || x_rerr cmig
x_sides "$p" > $XD/op.$$.s; [ -s $XD/op.$$.s ] || x_rerr path
XHC=1
while IFS= read -r s; do
XFI=; [ "$XFV" = pc ] && XFI=$(x_rcl lsjson --stat "$s" </dev/null 2>/dev/null | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s?.ID) == "string" && match(s.ID, /^[fd][0-9]{1,20}$/)) print(s.ID);' 2>/dev/null)
XFO=; case "$XFV" in --*) XFO=$XFV ;; esac
if ! x_r deletefile "$s" $XFO 2>/dev/null; then
if [ "$XTR" != 1 ] && x_r lsjson --stat "$s" 2>/dev/null | grep -q '"IsDir": *true'; then x_rerr trash; fi
[ "$XTR" = 1 ] || x_rerr "$(x_tr "$LOG")"
: > "$LOG"; x_r purge "$s" $XFO || x_rerr "$(x_tr "$LOG")"
fi
case "$XFI" in f*) x_pc "$J_id" trash_clear 30 "fileid=${XFI#f}" </dev/null >/dev/null 2>&1 ;; d*) x_pc "$J_id" trash_clear 30 "folderid=${XFI#d}" </dev/null >/dev/null 2>&1 ;; esac
done < $XD/op.$$.s
fi
done < $XD/op.$$ ;;
*) x_rerr act ;;
esac
[ -f "$XW/cloudmnt.sh" ] && ( sh "$XW/cloudmnt.sh" refresh "$J_id" </dev/null >/dev/null 2>&1 & )
x_log; x_res '{"ok":true}'
}
x_lpush() {
x_lkget
XL=$XLJ XI=$1 ucode -e 'let fs = require("fs"), f = getenv("XL"), N = {}; try { N = json(fs.readfile(f) ?? "{}"); } catch (e) {} if (type(N) != "object") N = {}; if (type(N.items) != "array") N.items = []; push(N.items, json(getenv("XI"))); let t = f + ".t"; fs.writefile(t, sprintf("%J\n", N)); fs.rename(t, f);' 2>/dev/null
chmod 600 "$XLJ" 2>/dev/null; x_lkput
}
x_lkget() {
n=0; K=$XD/${1:-links}.lock
until mkdir "$K" 2>/dev/null; do
p=$(cat "$K/pid" 2>/dev/null)
if { [ -n "$p" ] && ! x_alive "$p"; } || [ $(( $(date +%s) - $(date -r "$K" +%s 2>/dev/null || echo 0) )) -gt 30 ] || [ $n -gt 20 ]; then
rm -rf "$K"; continue
fi
n=$((n + 1)); sleep 1
done
echo $$ > "$K/pid"
}
x_lkput() { K=$XD/${1:-links}.lock; [ "$(cat "$K/pid" 2>/dev/null)" = $$ ] && rm -rf "$K"; true; }
x_en() { [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ]; }
t() { if x_en; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
c_linkexp() {
[ -f "$XLJ" ] || exit 0
LOG=$XD/log/linkexp; : > "$LOG"; XRO=; now=$(date +%s); XLS=$XD/lexp.$$
trap 'rm -f "$XLS" "$LOG"' EXIT
XL=$XLJ XN=$now ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XL")) ?? "{}"); } catch (e) {} for (let l in (N.items ?? [])) if (type(l) == "object" && +(l.expire ?? 0) > 0 && +l.expire <= +getenv("XN") && match(l.id ?? "", /^a[0-9]{1,2}$/)) {
		if (match("" + (l.pid ?? ""), /^[0-9]{1,20}$/)) print(l.id, " ", l.kind == "upreq" ? "upreq" : "link", " ", l.pid, "\n");
		if (l.kind == "pub" && match("" + (l.upid ?? ""), /^[0-9]{1,20}$/)) print(l.id, " upreq ", l.upid, "\n"); }' > "$XLS" 2>/dev/null
while read -r a k p; do
x_acct "$a" || continue
[ "$XS" = pcloud ] || continue
if [ "$k" = upreq ]; then x_pc "$a" deleteuploadlink 30 "uploadlinkid=$p" >/dev/null; else x_pc "$a" deletepublink 30 "linkid=$p" >/dev/null; fi
done < "$XLS"
XL=$XLJ XN=$now ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XL")) ?? "{}"); } catch (e) {} for (let l in (N.items ?? [])) if (type(l) == "object" && +(l.expire ?? 0) > 0 && +l.expire <= +getenv("XN") && match(l.id ?? "", /^a[0-9]{1,2}$/) && type(l.copy) == "string" && !match(l.copy, /[\n\r\t]/)) print(l.id, "\t", l.copy, "\n");' > "$XLS" 2>/dev/null
while IFS='	' read -r a c; do x_acct "$a" && x_lcdel "$c"; done < "$XLS"
x_lkget
XL=$XLJ XN=$now ucode -e 'let fs = require("fs"), f = getenv("XL"), N = {}; try { N = json(fs.readfile(f) ?? "{}"); } catch (e) {} if (type(N) != "object" || type(N.items) != "array") exit(0);
		let n = length(N.items); N.items = filter(N.items, (l) => !(type(l) == "object" && +(l.expire ?? 0) > 0 && +l.expire <= +getenv("XN")));
		if (length(N.items) != n) { let t = f + ".t"; fs.writefile(t, sprintf("%J\n", N)); fs.rename(t, f); } print(n - length(N.items), "\n");' 2>/dev/null
chmod 600 "$XLJ" 2>/dev/null; x_lkput
}
c_unlink() {
REQ=$1; printf '%s' "$REQ" | grep -qE '^[A-Za-z0-9_-]{1,40}$' || exit 2
F=$XD/req/$REQ.json; [ -f "$F" ] || exit 2
LOG=$XD/log/r-$REQ; : > "$LOG"; XRO=
l=$(XF=$F ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} let l = N?.link; if (type(l) == "object" && match(l.id ?? "", /^a[0-9]{1,2}$/)) print(l.id, " ", l.kind == "upreq" ? "upreq" : "link", " ", match("" + (l.pid ?? ""), /^[0-9]{1,20}$/) ? l.pid : "-", " ", l.kind == "pub" && match("" + (l.upid ?? ""), /^[0-9]{1,20}$/) ? l.upid : "-");' 2>/dev/null)
set -- $l
[ -n "$1" ] || x_rerr path
x_acct "$1" || x_rerr none
XLC_=$(XF=$F ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} let c = N?.link?.copy; if (type(c) == "string") print(c);' 2>/dev/null)
if [ "$XS" = pcloud ] && [ "$3" != - ]; then
if [ "$2" = upreq ]; then o=$(x_pc "$1" deleteuploadlink 30 "uploadlinkid=$3"); else o=$(x_pc "$1" deletepublink 30 "linkid=$3"); fi
x_pcok "$o" || [ "$XC" = path ] || x_rerr "$XC"
fi
if [ "$XS" = pcloud ] && [ "${4:--}" != - ]; then
o=$(x_pc "$1" deleteuploadlink 30 "uploadlinkid=$4"); x_pcok "$o" || [ "$XC" = path ] || x_rerr "$XC"
fi
x_lcdel "$XLC_"
x_log; x_res '{"ok":true}'
}
x_lcdel() {
case "$1" in ''|*/../*|*/./*|../*|./*) return 0 ;; esac
printf '%s' "$1" | grep -qE "^Utenti/[^/]+/$XLNK/[^/].*\$" || return 0
r_=$(x_rp "$1")
x_rcl deletefile "$r_" --log-file "$LOG" --log-level ERROR </dev/null 2>/dev/null || x_rcl purge "$r_" --log-file "$LOG" --log-level ERROR </dev/null 2>/dev/null
true
}
c_upnew() {
[ -f "$XLJ" ] || exit 0
LOG=$XD/log/upnew; : > "$LOG"; XRO=; now=$(date +%s); XLS=$XD/upn.$$; XLC=$XD/upc.$$
trap 'rm -f "$XLS" "$XLC" "$LOG" $XD/upf.$$' EXIT
XL=$XLJ XN=$now ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XL")) ?? "{}"); } catch (e) {} for (let l in (N.items ?? [])) if (type(l) == "object" && l.kind == "upreq" && !(+(l.expire ?? 0) > 0 && +l.expire <= +getenv("XN")) && match(l.id ?? "", /^a[0-9]{1,2}$/) && match(l.req ?? "", /^[A-Za-z0-9_-]{1,40}$/) && type(l.path) == "string" && !match(l.path, /[\n\r\t]/)) print(l.req, "\t", l.id, "\t", int(l.files ?? 0), "\t", l.to_nas === false ? 0 : 1, "\t", match(l.own ?? "", /^[A-Za-z0-9._-]{1,32}$/) ? l.own : "admin", "\t", l.path, "\n");' > "$XLS" 2>/dev/null
: > "$XLC"
while IFS='	' read -r rq a f tn ow p; do
x_acct "$a" || continue
[ "$XS" = pcloud ] || continue
p=$(x_path "$p") && [ -n "$p" ] || continue
o=$(x_pc "$a" listfolder 30 "path=/$p")
x_pcok "$o" || continue
n=$(x_jget "$o" 'length(filter(N.metadata?.contents ?? [], (x) => type(x) == "object" && !x.isfolder && substr("" + (x.name ?? ""), 0, 4) != ".wf-"))')
case "$n" in ''|*[!0-9]*) continue ;; esac
mv_=
case "$p" in Utenti/*/"$XINB")
if [ "$tn" = 0 ] && [ "$n" -gt 0 ]; then
J_id=$a; [ -n "$XTY" ] || XTY=$(x_tys); mv_=1
for ty in video music photo doc app other; do
D=$(wf_udir "$ow" recv $ty) && [ -n "$D" ] || { mv_=; continue; }
x_tflt $ty flat > $XD/upf.$$
x_rcl move "$(x_rp "$p" r)" "$(x_rp "$D")" --filter-from $XD/upf.$$ --ignore-case --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" || mv_=
done
rm -f $XD/upf.$$
fi ;;
esac
printf '%s %s\n' "$rq" "$([ -n "$mv_" ] && echo 0 || echo "$n")" >> "$XLC"
[ "$n" -gt "$f" ] || continue
d=$((n - f))
if x_en; then [ $tn = 1 ] && w='On the NAS tonight' || w='In the cloud'; m="🗄️ File Request ¦ $d files received ¦ $w"
else [ $tn = 1 ] && w='Sul NAS stanotte' || w='Nel cloud'; m="🗄️ Richiesta File ¦ $d file ricevuti ¦ $w"; fi
if [ -f $XW/event.sh ]; then
if [ "$ow" != admin ]; then WF_SOLO=1 sh $XW/event.sh cron cloud_upreq_new cloud "$m" "$ow" </dev/null >/dev/null 2>&1
else sh $XW/event.sh cron cloud_upreq_new cloud "$m" </dev/null >/dev/null 2>&1; fi
fi
done < "$XLS"
[ -s "$XLC" ] || exit 0
x_lkget
XL=$XLJ XC=$XLC ucode -e 'let fs = require("fs"), f = getenv("XL"), N = {}, C = {}; try { N = json(fs.readfile(f) ?? "{}"); } catch (e) {} if (type(N) != "object" || type(N.items) != "array") exit(0);
		for (let l in split(fs.readfile(getenv("XC")) ?? "", "\n")) { let c = split(l, " "); if (length(c) == 2) C[c[0]] = int(c[1]); }
		for (let l in N.items) if (type(l) == "object" && C[l.req] != null) l.files = C[l.req];
		let t = f + ".t"; fs.writefile(t, sprintf("%J\n", N)); fs.rename(t, f);' 2>/dev/null
chmod 600 "$XLJ" 2>/dev/null; x_lkput
}
x_lid() { printf 'l%s' "$(cut -c1-8 /proc/sys/kernel/random/uuid 2>/dev/null || date +%s)"; }
c_link() {
x_req "$1"
[ -n "$XP" ] || x_rerr path
x_iscrypt "$J_id" "$XP" && x_rerr crypt
if [ "$J_pub" = 1 ]; then x_cs "$XP" && x_rerr crypt; c_pub; return 0; fi
x_cs "$XP" && x_rerr cpriv
x_mklink "$XP" || x_rerr "$XC"
x_lpush "{\"req\":\"$(x_lid)\",\"id\":\"$J_id\",\"path\":\"$(x_e "$XP")\",\"kind\":\"link\",\"url\":\"$(x_e "$U")\",\"expire\":$ET,\"hits\":0,\"own\":\"$(x_e "$XOWN")\",\"t\":$(date +%s),\"pid\":\"$(x_e "$LI")\"}"
x_log; x_res "{\"url\":\"$(x_e "$U")\",\"expire\":$ET}"
}
c_pub() {
J_pass=; J_max=0
case "$J_mode" in r|rw) ;; *) x_rerr act ;; esac
case "$J_expire" in 1|7) ;; *) x_rerr act ;; esac
[ "$J_mode" = rw ] && [ "$XS" != pcloud ] && x_rerr caps
fi_=
if [ "$XS" = pcloud ]; then x_pcmk "$J_id" "$XP" || x_rerr "$XC"; fi_=$(x_jget "$o" 'N.metadata?.folderid')
else x_r mkdir "$(x_rp "$XP")" >/dev/null 2>&1; fi
x_mklink "$XP" || x_rerr "$XC"
UU=; UI=
if [ "$J_mode" = rw ]; then
XC=path
if [ -n "$fi_" ]; then
set -- "folderid=$fi_" "comment=Cartella Pubblica" "expire=$ET"
o=$(x_pc "$J_id" createuploadlink 30 "$@"); XC=fail
x_pcok "$o" && { UU=$(x_jget "$o" 'N.link'); UI=$(x_jget "$o" 'N.uploadlinkid'); }
fi
if ! printf '%s' "$UU" | grep -qE '^https?://[^ ]+$'; then
e_=$XC; [ -n "$LI" ] && x_pc "$J_id" deletepublink 30 "linkid=$LI" >/dev/null; x_rerr "$e_"
fi
fi
x_lpush "{\"req\":\"$(x_lid)\",\"id\":\"$J_id\",\"path\":\"$(x_e "$XP")\",\"kind\":\"pub\",\"mode\":\"$J_mode\",\"url\":\"$(x_e "$U")\",\"upurl\":\"$(x_e "$UU")\",\"expire\":$ET,\"hits\":0,\"own\":\"$(x_e "$XOWN")\",\"t\":$(date +%s),\"pid\":\"$(x_e "$LI")\",\"upid\":\"$(x_e "$UI")\"}"
x_log; x_res "{\"url\":\"$(x_e "$U")\",\"upurl\":\"$(x_e "$UU")\",\"mode\":\"$J_mode\",\"expire\":$ET}"
}
x_mklink() {
ex=$(printf '%s' "${J_expire:-0}" | tr -cd '0-9'); ex=${ex:-0}; [ "$ex" -gt 3650 ] && ex=3650
mx=$(printf '%s' "${J_max:-0}" | tr -cd '0-9'); mx=${mx:-0}
ET=0; [ "$ex" -gt 0 ] && ET=$(( $(date +%s) + ex * 86400 )); U=; LI=
case "$XS" in
pcloud)
set -- "path=/$1"; [ "$ET" -gt 0 ] && set -- "$@" "expire=$ET"; [ -n "$J_pass" ] && set -- "$@" "linkpassword=$J_pass"
[ "$mx" -gt 0 ] && set -- "$@" "maxdownloads=$mx"
o=$(x_pc "$J_id" getfilepublink 30 "$@")
[ "$(x_jget "$o" 'N.result')" = 0 ] || o=$(x_pc "$J_id" getfolderpublink 30 "$@")
x_pcok "$o" || return 1
U=$(x_jget "$o" 'N.link'); LI=$(x_jget "$o" 'N.linkid') ;;
drive|onedrive|dropbox|box|koofr|webdav)
XC=caps; { [ -n "$J_pass" ] || [ "$mx" -gt 0 ]; } && return 1
[ "$ex" -gt 0 ] && case "$XS" in drive|box|koofr|webdav) return 1 ;; esac
set -- link "$(x_rp "$1")"; [ "$ex" -gt 0 ] && set -- "$@" --expire "${ex}d"
U=$(x_r "$@" | sed -n 1p) || { XC=$(x_tr "$LOG"); return 1; } ;;
*) XC=caps; return 1 ;;
esac
XC=fail; printf '%s' "$U" | grep -qE '^https?://[^ ]+$'
}
x_pcmk() {
cp=; IFS_=$IFS; IFS=/
for x in $2; do
[ -n "$x" ] || continue; cp=$cp/$x
o=$(x_pc "$1" createfolderifnotexists 30 "path=$cp"); x_pcok "$o" || { IFS=$IFS_; return 1; }
done
IFS=$IFS_
}
c_upreq() {
x_req "$1"
[ "$XS" = pcloud ] || x_rerr caps
XP=$(wf_udir "$XOWN" recv) && [ -n "$XP" ] || x_rerr path
if x_cs "$XP"; then XP=$(wf_udir "$XCO" inbox) && [ -n "$XP" ] || x_rerr path; fi
x_pcmk "$J_id" "$XP" || x_rerr "$XC"
fi_=$(x_jget "$o" 'N.metadata?.folderid')
[ -n "$fi_" ] || x_rerr path
ex=$(printf '%s' "${J_expire:-0}" | tr -cd '0-9'); ex=${ex:-0}; ET=0; [ "$ex" -gt 0 ] && ET=$(( $(date +%s) + ex * 86400 ))
mb=$(printf '%s' "${J_max_mb:-0}" | tr -cd '0-9'); mb=${mb:-0}
set -- "folderid=$fi_" "comment=$(printf '%s' "$J_msg" | cut -c1-200)"
[ "$ET" -gt 0 ] && set -- "$@" "expire=$ET"; [ "$mb" -gt 0 ] && set -- "$@" "maxspace=$((mb * 1048576))"
o=$(x_pc "$J_id" createuploadlink 30 "$@"); x_pcok "$o" || x_rerr "$XC"
U=$(x_jget "$o" 'N.link'); LI=$(x_jget "$o" 'N.uploadlinkid')
printf '%s' "$U" | grep -qE '^https?://[^ ]+$' || x_rerr fail
TN=true; [ "$J_to_nas" = 0 ] && TN=false
x_lpush "{\"req\":\"$(x_lid)\",\"id\":\"$J_id\",\"path\":\"$(x_e "$XP")\",\"kind\":\"upreq\",\"url\":\"$(x_e "$U")\",\"expire\":$ET,\"hits\":0,\"files\":0,\"to_nas\":$TN,\"own\":\"$(x_e "$XOWN")\",\"t\":$(date +%s),\"pid\":\"$(x_e "$LI")\"}"
x_log; x_res "{\"url\":\"$(x_e "$U")\"}"
}
c_find() {
x_req "$1"
o=$XD/find.$$; ub=$XD/findu.$$; : > "$o"; trap 'rm -f "$XRO" "$o" "$ub"' EXIT
if [ "$XOWN" = admin ]; then
{ x_r lsf "$(x_rp Utenti)" --dirs-only --max-depth 1 | sed -n 1,200p | while IFS= read -r d; do
d=${d%/}; [ -n "$d" ] && x_bkdir "Utenti/$d/Backup" && printf 'Utenti/%s/Backup\n' "$d"; done
printf '%s\n' 'WrtFreedom/Backup' 'WrtFreedom Backup'; } > "$ub"
else
b=$(wf_udir "$XOWN" backup) && [ -n "$b" ] || x_rerr path
printf '%s\n' "$b" > "$ub"
fi
while IFS= read -r B; do
x_r lsf "$(x_rp "$B" r)" --dirs-only --max-depth 1 | sed -n 1,200p | while IFS= read -r d; do
d=${d%/}; [ -n "$d" ] || continue
i=$(x_rcl cat "$(x_rp "$B/$d/.wf-info" r)" --max-size 4096 --log-file "$LOG" --log-level ERROR </dev/null 2>/dev/null | head -c 4096)
[ -n "$i" ] && printf '%s\t%s\n' "$B/$d" "$(printf '%s' "$i" | tr -d '\n\r\t')" >> "$o"
done
done < "$ub"
[ "$XOWN" = admin ] && for B in ${XRT:+"$XRT"} 'WrtFreedom/Router' 'WrtFreedom Router'; do
x_r lsf "$(x_rp "$B" r)" --files-only --format pt --separator '	' --max-depth 1 | grep '\.wfbak	' | head -n 200 |
while IFS='	' read -r f m; do printf '%s\t{"t":"%s","crypt":true,"kind":"router"}\n' "$B/$f" "$m" >> "$o"; done
done
grep -qiE 'directory not found|not found|404' "$LOG" && : > "$LOG"
[ -s "$LOG" ] && [ ! -s "$o" ] && x_rerr "$(x_tr "$LOG")"
r=$(XO=$o ucode -e 'let it = []; for (let l in split(require("fs").readfile(getenv("XO")) ?? "", "\n")) { let c = split(l, "\t"); if (length(c) < 2) continue; let i = null; try { i = json(c[1]); } catch (e) {} if (type(i) != "object") continue; push(it, { remote: c[0], t: i.t ?? 0, crypt: !!i.crypt, kind: "" + (i.kind ?? "") }); } printf("%J\n", { items: it });' 2>/dev/null)
[ -n "$r" ] || x_rerr fail
x_log; x_res "$r"
}

x_jw() {
s=$1; shift
case "$s" in ok|err|stop) x_gen "$J_id" "${SRC:-}" "${J_to_id:-}" ;; esac
XJF=$XD/jobs/$JOB.json XS=$s XT=$XD/jobs/.$JOB.$$ ucode -e '
let fs = require("fs"), f = getenv("XJF"), J = {};
try { J = json(fs.readfile(f) ?? "{}"); } catch (e) {}
if (type(J) != "object") J = {};
J.state = getenv("XS"); J.t = time();
for (let a in ARGV) { let i = index(a, "="); if (i < 1) continue; let v = substr(a, i + 1); J[substr(a, 0, i)] = match(v, /^-?[0-9]{1,18}$/) ? int(v) : v; }
fs.writefile(getenv("XT"), sprintf("%J\n", J)); fs.rename(getenv("XT"), f);' "$@" 2>/dev/null
}
x_jwait() { XWW=$(cl_why "$1"); XWC=$1; shift; x_jw wait wc="$XWC" why="${XWW%%|*}" why_en="${XWW#*|}" pid=0 "$@"; }
x_slput() { [ -n "$XSL" ] && [ -f $XW/cloud.sh ] && sh $XW/cloud.sh slot put "$JOB" "$XSL" >/dev/null 2>&1; XSL=; true; }
x_end() { x_log; x_slput; rm -f "$XRO" $XD/flt.$$ $XD/flt.$$.b $XD/flt.$$.m $XD/flt.$$.m2 $XD/jobs/$JOB.stop; [ -z "$XHC" ] || { XHC=; x_hk; }; }
x_jerr() {
x_log; n=$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.tries'); n=$(( ${n:-0} + 1 ))
x_jw err code="$1" err="$(x_msg it "$1")" err_en="$(x_msg en "$1")" tries=$n pid=0
if [ $n -ge 3 ] && [ -f $XW/event.sh ]; then
nm=$(printf '%s' "${J_name:-$JOB}" | awk '{ if (length($0) > 22) print substr($0, 1, 21) "…"; else print }')
if [ -n "$J_own" ] && [ "$J_own" != admin ]; then
WF_SOLO=1 sh $XW/event.sh cron cloud_xfer_err cloud "⚠️ Trasferimento ¦ $nm non riuscito ¦ $(x_msg it "$1")" "$J_own" >/dev/null 2>&1
sh $XW/event.sh cron cloud_xfer_err cloud "⚠️ $(t 'Trasferimento' 'Transfer') ¦ $(x_pnm "$J_own"): $(t 'non riuscito' 'failed')" >/dev/null 2>&1
else
sh $XW/event.sh cron cloud_xfer_err cloud "⚠️ Trasferimento ¦ $nm non riuscito ¦ $(x_msg it "$1")" >/dev/null 2>&1
fi
fi
x_end; exit 0
}
x_job() {
JOB=$1; printf '%s' "$JOB" | grep -qE '^[A-Za-z0-9_-]{1,40}$' || exit 2
[ -f $XD/jobs/$JOB.json ] || exit 2
LOG=$XD/log/$JOB; : > "$LOG"; XSL=; XRO=; XHC=
eval "$(x_vars $XD/jobs/$JOB.json kind id paths disk to src url name net path rem cap keep_days night what how file own stage move max_gb expire pass max lown mb here)"
[ -n "$J_net" ] || J_net='{}'
trap 'x_end' EXIT
command -v rclone >/dev/null 2>&1 || x_jerr pkg
}
x_go() {
if [ -n "$J_own" ] && [ "$J_own" != admin ] && [ "$(XO=$J_own XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} print(N?.ppause?.[getenv("XO")] === true ? 1 : 0);' 2>/dev/null)" = 1 ]; then
x_jw wait wc=ppause why='In Pausa' why_en='Paused' pid=0; return 1
fi
if [ -f $XW/cloud.sh ]; then sh $XW/cloud.sh slot get "$JOB" "$1" >/dev/null 2>&1 || { x_jwait queue; return 1; }; XSL=$1; fi
x_line || return 1
export RCLONE_CONFIG=$XCF RCLONE_CACHE_DIR=$XD/rclone-cache
cl_env "$XS"; XMEM=$CL_RMEM
[ -z "$CL_MOK" ] && [ "$(cat $XD/tier 2>/dev/null)" = A ] && export GOGC=20
true
}
x_oth() {
o_=$(XA=$1 XF=$XCJ XS=$XD/state.json ucode -e 'let fs = require("fs"), r = (f) => { let v = null; try { v = json(fs.readfile(f) ?? "{}"); } catch (e) {} return type(v) == "object" ? v : {}; };
		let S = r(getenv("XS")), N = r(getenv("XF")), a = getenv("XA");
		if (S.accts?.[a]?.st == "relink") print("relink");
		else for (let x in (N.accounts ?? [])) if (x?.id == a && length(x.user ?? "") && x.user != "admin" && N.ppause?.[x.user] === true) { print("ppause"); break; }' 2>/dev/null)
[ -n "$o_" ] && { echo "$o_"; return 0; }
k_=$XD/acct-$1.lock
[ -d "$k_" ] && [ "$(cat "$k_/job" 2>/dev/null)" != "$JOB" ] && x_alive "$(cat "$k_/pid" 2>/dev/null)" && echo acct
true
}
x_line() {
l=$(cl_check "$JOB" "$J_net" 2>/dev/null)
set -- $l
case "$1" in
wait) x_jwait "${2:-sim}"; x_slput; return 1 ;;
esac
XBW=; XMT=; case "$2" in ''|0|-|off|off:off) ;; *) XBW="--bwlimit $2" ;; esac
[ -n "$3" ] && [ "$3" -gt 0 ] 2>/dev/null && XMT=$3
true
}
x_cap() { [ "$1" -gt 0 ] 2>/dev/null || return 0; { [ -n "$XMT" ] && [ "$XMT" -le "$1" ]; } || XMT=$1; }
x_run() {
: > "$LOG"
( cl_in; exec rclone "$@" $XMEM $XBW ${XMT:+--max-transfer $XMT --cutoff-mode soft} --use-json-log --stats 2s --stats-log-level NOTICE --log-level NOTICE --log-file "$LOG" ) </dev/null >/dev/null 2>&1 &
XP=$!; x_jw run pid=$XP why= why_en= wc=; n=0; g=0
while x_alive $XP; do
sleep 2; n=$((n + 2)); g=$((g + 2))
[ -f $XD/jobs/$JOB.stop ] && { kill -TERM $XP 2>/dev/null; wait $XP; return 254; }
s=$(tail -c 16384 "$LOG" 2>/dev/null | grep '"stats"' | tail -n 1)
[ -n "$s" ] && x_jw run $(printf '%s' "$s" | ucode -e 'let s = {}; try { s = json(require("fs").stdin.read("all")).stats ?? {}; } catch (e) {} let b = int(s.bytes ?? 0), t = int(s.totalBytes ?? 0); print("bytes=", b, " size=", t, " pct=", t > 0 ? int(b * 100 / t) : 0, " speed=", int(s.speed ?? 0));' 2>/dev/null)
if [ $n -ge 60 ]; then
n=0; l=$(cl_check "$JOB" "$J_net" 2>/dev/null)
case "$l" in wait*) kill -TERM $XP 2>/dev/null; wait $XP; set -- $l; XWHY=${2:-sim}; return 253 ;; esac
fi
if [ $g -ge 30 ] || grep -qE '://|(access_token|auth|linkpassword|password|code)=[^<]' "$LOG" 2>/dev/null; then g=0; x_logw; fi
done
wait $XP
}
x_fin() {
B=$(x_bytes); B=${B:-${2:-0}}
[ "$B" -gt 0 ] 2>/dev/null && cl_add "$B" >/dev/null 2>&1
case "$1" in
0) x_jw ok bytes="$B" pct=100 pid=0 tries=0 err= err_en= code= ;;
254) x_jw stop pid=0 ;;
253) x_jwait "$XWHY" bytes="$B" ;;
8) x_jwait cap bytes="$B" ;;
*) x_jerr "$(x_tr "$LOG")" ;;
esac
}
x_disk() {
XM=$(XI=$1 ucode -e 'let N = {}; try { N = json(require("fs").readfile("/tmp/wf-nas/x/disks.json") ?? "{}"); } catch (e) {} for (let d in (N.list ?? [])) if (d.id == getenv("XI") || (getenv("XI") == "" && !d.ro)) { print(d.mnt, d.ro ? " 1" : " 0"); break; }' 2>/dev/null)
ro=${XM##* }; XM=${XM% *}
[ -n "$XM" ] && [ -d "$XM" ] || return 1
XM=$XM awk 'BEGIN { m = ENVIRON["XM"] } { p = $2; gsub(/\\040/, " ", p); if (p == m) f = 1 } END { exit !f }' $XR/proc/mounts 2>/dev/null || return 1
[ "$2" = rw ] && [ "$ro" = 1 ] && return 2
true
}
x_dpath() {
p=$(printf '%s' "$1" | sed 's#^/*##; s#/*$##')
case "/$p/" in */../*|*/./*) return 1 ;; esac
printf '%s' "$p" | grep -q '[[:cntrl:]]' && return 1
if [ "${XOWN:-admin}" != admin ]; then
[ -n "$2" ] && [ "$2" = "$(x_main)" ] || return 1
u=$(wf_udir "$XOWN" root) && s=$(wf_udir shared root) && [ -n "$u" ] && [ -n "$s" ] || return 1
case "$p/" in "$u"/*|"$s"/*) ;; *) return 1 ;; esac
fi
q_=$(x_shl "$p" d) && p=$q_
printf '%s' "$p"
}
x_main() { XN=$XE/nas.json ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XN")) ?? "{}"); } catch (e) {} let i = N?.main?.id; if (type(i) == "string" && match(i, /^[A-Za-z0-9_.:-]{1,64}$/)) print(i);' 2>/dev/null; }
x_mainp() { [ -f $XR/tmp/wf-nas/mainpause.json ] || return 1; [ -z "$1" ] || [ "$1" = "$(x_main)" ]; }
x_full() { [ -n "$1" ] && [ "$1" != admin ] && grep -qxF -- "$1" $XR/tmp/wf-nas/full.list 2>/dev/null; }
x_bytes() { grep '"stats"' "$LOG" 2>/dev/null | tail -n 1 | ucode -e 'let s = {}; try { s = json(require("fs").stdin.read("all")).stats ?? {}; } catch (e) {} print(int(s.bytes ?? 0));' 2>/dev/null; }
x_shnew() {
[ -n "$XPS" ] || return 0
case "$1/" in "$XPS"/*) ;; *) return 0 ;; esac
[ "$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.xok')" = 1 ] && return 0
x_exists "$1" && x_jerr exists
x_jw run xok=1
}
x_uniq() { ub=$2; ux=; case "$ub" in ?*.*) ux=.${ub##*.}; ub=${ub%.*} ;; esac
ui=2; while [ -e "$1/$ub ($ui)$ux" ] || [ -L "$1/$ub ($ui)$ux" ]; do ui=$((ui + 1)); done; XUN="$ub ($ui)$ux"; }
x_reqname() {
XRN=$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.un')
[ -n "$XRN" ] && return 0
x_cuniq "$TO" "$1"; XRN=$XUN
x_jw run un="$XRN"
}
x_same() {
a_=$(x_rcl size "$1" --json </dev/null 2>/dev/null | tr -d ' \n\r\t'); b_=$(x_rcl size "$2" --json </dev/null 2>/dev/null | tr -d ' \n\r\t')
[ -n "$a_" ] && [ "$a_" = "$b_" ]
}
x_mvnas() {
printf '%s\n' "$J_paths" > $XD/flt.$$.m
while IFS= read -r p; do
p=$(x_path "$p") && [ -n "$p" ] || x_jerr path
nm=${p##*/}; un=$(printf '%s\n' "$2" | XN=$nm awk -F '\t' '$1 == ENVIRON["XN"] { print $2; exit }'); [ -n "$un" ] || un=$nm
[ -z "$(x_rpo "$p")" ] || x_jerr cmig
x_same "$(x_rp "$p" r)" "$1/$un" || x_jerr check
done < $XD/flt.$$.m
XHC=1
while IFS= read -r p; do
p=$(x_path "$p") || continue
s=$(x_rp "$p" r)
x_r deletefile "$s" 2>/dev/null || x_r purge "$s" || x_jerr "$(x_tr "$LOG")"
done < $XD/flt.$$.m
rm -f $XD/flt.$$.m; x_jw run moved=1
}
c_xfer() {
x_job "$1"
x_acct "$J_id" || x_jerr none
x_own "$J_own" || x_jerr none
case "$J_kind" in nas|url) x_full "$XOWN" && x_jerr quota_full ;; esac
[ "$J_kind" = nas ] && x_mainp "$J_disk" && x_jerr nomain
x_go "$J_id" || exit 0
case "$J_kind" in up|phone|mv|lcopy|url|copy|wtrm) XHC=1 ;; esac
if [ "$J_kind" = wtrm ]; then
XWN=$XD/wtn.$$; : > "$XWN"; XWK=0
printf '%s\n' "$J_paths" > $XD/flt.$$
while IFS= read -r p; do
p=$(x_path "$p") && [ -n "$p" ] || { x_wtflush; x_jerr path; }
x_cmig "$p" || { x_wtflush; x_jerr cmig; }
x_sides "$p" > $XD/flt.$$.b
while IFS= read -r s; do
x_has "$s" || continue
case "$s" in
"$RM:"*) x_wtput "$s" "$p" || { x_wtflush; x_jerr "$(x_tr "$LOG")"; } ;;
*) x_r deletefile "$s" 2>/dev/null || { : > "$LOG"; x_r purge "$s" || { x_wtflush; x_jerr "$(x_tr "$LOG")"; }; } ;;
esac
done < $XD/flt.$$.b
done < $XD/flt.$$
x_wtflush; rm -f "$XWN"
[ -f "$XW/cloudmnt.sh" ] && ( sh "$XW/cloudmnt.sh" refresh "$J_id" </dev/null >/dev/null 2>&1 & )
x_jw ok pct=100 pid=0 tries=0 err= err_en= code=; exit 0
fi
[ "$J_kind" = copy ] && c_cc
if [ "$J_kind" = nas ]; then TO=$(x_dpath "$J_to" "$J_disk") || x_jerr path; else TO=$(x_path "$J_to") || x_jerr path; fi
case "$J_kind" in
down)
p=$(printf '%s\n' "$J_paths" | head -n 1); p=$(x_path "$p") && [ -n "$p" ] || x_jerr path
RP=$(x_rp "$p" r)
sz=$(x_rcl lsjson --stat "$RP" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s) == "object" && !s.IsDir) print(int(s.Size ?? 0));' 2>/dev/null)
[ -n "$sz" ] || x_jerr "$(x_tr "$LOG")"
lm=$(XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} print(int(N.lim?.phone_mb ?? 0));' 2>/dev/null)
[ "${lm:-0}" -gt 0 ] 2>/dev/null || { if [ "$(cat $XD/tier 2>/dev/null)" = A ]; then lm=32; else lm=256; fi; }
fr=$(df -k /tmp 2>/dev/null | awk 'NR == 2 { print $4 * 1024 }')
{ [ "$sz" -le $((lm * 1048576)) ] && [ $((sz * 2)) -le "${fr:-0}" ]; } || x_jerr big
O=$XD/dl/$JOB; : > "$O.part"; off=0; PZ=4194304; [ "$(cat $XD/tier 2>/dev/null)" = A ] && PZ=1048576
x_jw run size="$sz" bytes=0 pct=0 pid=$$
lt=$(date +%s)
while [ $off -lt "$sz" ]; do
[ -f $XD/jobs/$JOB.stop ] && { rm -f "$O.part"; x_fin 254; exit 0; }
if [ $(( $(date +%s) - lt )) -ge "$XCT" ]; then
lt=$(date +%s); l=$(cl_check "$JOB" "$J_net" 2>/dev/null)
case "$l" in wait*) rm -f "$O.part"; [ $off -gt 0 ] && cl_add "$off" >/dev/null 2>&1; set -- $l; x_jwait "${2:-sim}" bytes=0 pct=0; exit 0 ;; esac
fi
x_rcl cat "$RP" --offset $off --count $PZ --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" >> "$O.part" || { rm -f "$O.part"; x_jerr "$(x_tr "$LOG")"; }
n=$(wc -c < "$O.part"); [ "$n" -gt $off ] || { rm -f "$O.part"; x_jerr fail; }
off=$n; x_jw run bytes=$off pct=$((off * 100 / sz))
done
mv "$O.part" "$O"; x_jw run file="$O"; x_fin 0 "$sz" ;;
nas)
x_disk "$J_disk" rw; rc=$?; [ $rc = 2 ] && x_jerr ro; [ $rc = 0 ] || x_jerr disk
D=$XM/$TO; mkdir -p "$D" 2>/dev/null || x_jerr ro
p1=$(printf '%s\n' "$J_paths" | head -n 1); p1=$(x_path "$p1") && [ -n "$p1" ] || x_jerr path
pa=${p1%/*}; [ "$pa" = "$p1" ] && pa=
{
printf '%s\n' "$J_paths" | while IFS= read -r p; do
p=$(x_path "$p") || { echo bad > $XD/flt.$$.bad; continue; }
q=${p%/*}; [ "$q" = "$p" ] && q=
[ "$q" = "$pa" ] || { echo bad > $XD/flt.$$.bad; continue; }
e=$(printf '%s' "${p##*/}" | sed 's/[][*?{}\\]/\\&/g')
printf '+ /%s\n+ /%s/**\n' "$e" "$e"
done
echo '- **'
} > $XD/flt.$$
[ -f $XD/flt.$$.bad ] && { rm -f $XD/flt.$$.bad; x_jerr path; }
SH=; if [ "${XOWN:-admin}" != admin ]; then SH=$(wf_udir shared root) || SH=; fi
case "$TO/" in "$SH"/*) ;; *) SH= ;; esac
if [ -z "$SH" ]; then
x_both "$pa" > $XD/flt.$$.b; rc=0
while IFS= read -r s_; do x_run copy "$s_" "$D" --filter-from $XD/flt.$$; rc=$?; [ $rc = 0 ] || break; done < $XD/flt.$$.b
rm -f $XD/flt.$$.b; [ $rc = 0 ] && [ "$J_move" = 1 ] && x_mvnas "$D" ''; x_fin $rc; exit 0
fi
TAB=$(printf '\t'); REN=$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.ren'); rc=0; TB=0
printf '%s\n' "$J_paths" > $XD/flt.$$
while IFS= read -r p; do
p=$(x_path "$p") && [ -n "$p" ] || x_jerr path
nm=${p##*/}
un=$(printf '%s\n' "$REN" | XN=$nm awk -F '\t' '$1 == ENVIRON["XN"] { print $2; exit }')
if [ -z "$un" ]; then
un=$nm; if [ -e "$D/$nm" ] || [ -L "$D/$nm" ]; then x_uniq "$D" "$nm"; un=$XUN; fi
REN="${REN:+$REN
}$nm$TAB$un"; x_jw run ren="$REN"
fi
RP=$(x_rp "$p" r)
if x_r lsjson --stat "$RP" | grep '"IsDir": *true' >/dev/null; then x_run copy "$RP" "$D/$un"; else x_run copyto "$RP" "$D/$un"; fi
rc=$?; [ $rc = 0 ] || break
bb=$(x_bytes); [ "${bb:-0}" -gt 0 ] 2>/dev/null && { cl_add "$bb" </dev/null >/dev/null 2>&1; TB=$((TB + bb)); }
done < $XD/flt.$$
[ $rc = 0 ] && [ "$J_move" = 1 ] && x_mvnas "$D" "$REN"
if [ $rc = 0 ]; then x_jw ok bytes="$TB" pct=100 pid=0 tries=0 err= err_en= code=; else x_fin $rc; fi ;;
up)
x_disk "$J_disk"; [ $? = 0 ] || x_jerr disk
sp=$(x_dpath "${J_src:-$(printf '%s\n' "$J_paths" | head -n 1)}" "$J_disk") && [ -n "$sp" ] || x_jerr path
S=$XM/$sp; [ -e "$S" ] || x_jerr path
n=${sp##*/}
case "$sp" in */.wf-incloud/*) x_reqname "$n"; n=$XRN ;; esac
x_shnew "${TO:+$TO/}$n"
RP=$(x_rp "${TO:+$TO/}$n")
if [ -d "$S" ]; then x_run copy "$S" "$RP"; else x_run copyto "$S" "$RP"; fi
rc=$?
if [ $rc = 0 ] && [ "$J_move" = 1 ]; then x_same "$S" "$RP" || x_jerr check; rm -rf "$S" || x_jerr ro; x_jw run moved=1; fi
x_fin $rc ;;
copy)
[ -n "$J_paths" ] || x_jerr path
TAB=$(printf '\t'); REN=$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.ren'); TB=0
printf '%s\n' "$J_paths" > $XD/flt.$$
while IFS= read -r p; do
p=$(x_path "$p") && [ -n "$p" ] || x_jerr path
case "${TO:+$TO/}" in "$p"/*) x_jerr path ;; esac
nm=${p##*/}
un=$(printf '%s\n' "$REN" | XN=$nm awk -F '\t' '$1 == ENVIRON["XN"] { print $2; exit }')
if [ -z "$un" ]; then
x_cuniq "$TO" "$nm"; un=$XUN
REN="${REN:+$REN
}$nm$TAB$un"; x_jw run ren="$REN"
fi
d=${TO:+$TO/}$un
{ x_cmig "$p" && x_cmig "$d"; } || x_jerr cmig
x_both "$p" > $XD/flt.$$.b
dd=$(x_rp "$d"); k_=0
while IFS= read -r s; do
x_has "$s" || continue
k_=1
if x_r lsjson --stat "$s" | grep '"IsDir": *true' >/dev/null; then x_run copy "$s" "$dd"; else x_run copyto "$s" "$dd"; fi
rc=$?; [ $rc = 0 ] || { rm -f $XD/flt.$$.b; x_fin $rc; exit 0; }
bb=$(x_bytes); [ "${bb:-0}" -gt 0 ] 2>/dev/null && { cl_add "$bb" </dev/null >/dev/null 2>&1; TB=$((TB + bb)); }
done < $XD/flt.$$.b
[ $k_ = 1 ] || x_jerr path
done < $XD/flt.$$
rm -f $XD/flt.$$.b
x_jw ok bytes="$TB" pct=100 pid=0 tries=0 err= err_en= code= ;;
phone)
S=$XD/ph/$JOB.part; [ -f "$S" ] || S=$XD/ph/$JOB; [ -f "$S" ] || x_jerr path
n=$(printf '%s' "$J_name" | tr -d '/\\\n\r'); [ -n "$n" ] && [ "$n" != . ] && [ "$n" != .. ] || x_jerr path
case "$JOB" in jr*) x_reqname "$n"; n=$XRN ;; esac
x_shnew "${TO:+$TO/}$n"
x_run moveto "$S" "$(x_rp "${TO:+$TO/}$n")"; rc=$?; [ $rc = 0 ] && rm -f "$S"; x_fin $rc ;;
mv)
[ -n "$J_paths" ] || x_jerr path
TB=0; XOK=$(x_jget "$(cat $XD/jobs/$JOB.json 2>/dev/null)" 'N.xok'); L=
printf '%s\n' "$J_paths" > $XD/flt.$$.b
while IFS= read -r p; do
p=$(x_path "$p") && [ -n "$p" ] || x_jerr path
if [ -n "$J_name" ]; then
n=$J_name; case "$n" in ''|.|..|*/*|*\\*) x_jerr path ;; esac
[ "$(printf '%s' "$n" | tr -d '\n\r')" = "$n" ] || x_jerr path
case "$p" in */*) d=${p%/*}/$n ;; *) d=$n ;; esac
else d=${TO:+$TO/}${p##*/}; fi
{ x_cmig "$p" && x_cmig "$d"; } || x_jerr cmig
[ "$XOK" = 1 ] || { x_exists "$d" && x_jerr exists; }
L="$L$(printf '%s\t%s' "$p" "$d")
"
done < $XD/flt.$$.b
printf '%s' "$L" > $XD/flt.$$
[ "$XOK" = 1 ] || x_jw run xok=1
while IFS='	' read -r p d; do
x_sides "$p" > $XD/flt.$$.b
if [ "$XOK" = 1 ]; then while IFS= read -r s; do x_has "$s" && printf '%s\n' "$s"; done < $XD/flt.$$.b > $XD/flt.$$.c; mv $XD/flt.$$.c $XD/flt.$$.b; fi
[ -s $XD/flt.$$.b ] || { [ "$XOK" = 1 ] && continue; x_jerr path; }
dd=$(x_rp "$d")
while IFS= read -r s; do
x_run moveto "$s" "$dd"; rc=$?; [ $rc = 0 ] || { x_fin $rc; exit 0; }
bb=$(x_bytes); [ "${bb:-0}" -gt 0 ] 2>/dev/null && { cl_add "$bb" </dev/null >/dev/null 2>&1; TB=$((TB + bb)); }
done < $XD/flt.$$.b
done < $XD/flt.$$
x_jw ok bytes="$TB" pct=100 pid=0 tries=0 err= err_en= code= ;;
lcopy)
p=$J_src; [ -n "$p" ] || p=$(printf '%s\n' "$J_paths" | head -n 1); [ -n "$p" ] || p=$J_path
p=$(x_path "$p") && [ -n "$p" ] && x_cs "$p" || x_jerr path
LO=$XCO; [ "$XCO" = shared ] && LO=$J_lown
case "$LO" in ''|shared|*[!A-Za-z0-9._-]*) x_jerr path ;; esac
LD=$(wf_udir "$LO" lnk) && [ -n "$LD" ] || x_jerr path; [ -n "$J_to" ] && [ "$TO" != "$LD" ] && x_jerr path
RP=$(x_rp "$p" r)
sz=$(x_rcl size "$RP" --json --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s) == "object" && type(s.bytes) == "int") print(s.bytes);' 2>/dev/null)
[ -n "$sz" ] || x_jerr "$(x_tr "$LOG")"
lm=$(printf '%s' "$J_mb" | tr -cd '0-9')
[ "${lm:-0}" -gt 0 ] 2>/dev/null || lm=$(XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} print(int(N.lim?.lcopy_mb ?? 0));' 2>/dev/null)
[ "${lm:-0}" -gt 0 ] 2>/dev/null || { if [ "$(cat $XD/tier 2>/dev/null)" = A ]; then lm=256; else lm=2048; fi; }
[ "$sz" -le $((lm * 1048576)) ] || x_jerr big
x_cuniq "$LD" "${p##*/}"; CP="$LD/$XUN"
if x_r lsjson --stat "$RP" | grep '"IsDir": *true' >/dev/null; then x_run copy "$RP" "$(x_rp "$CP")"; else x_run copyto "$RP" "$(x_rp "$CP")"; fi
rc=$?; [ $rc = 0 ] || { x_fin $rc; exit 0; }
B=$(x_bytes); [ "${B:-0}" -gt 0 ] 2>/dev/null && cl_add "$B" >/dev/null 2>&1
: > "$LOG"; x_mklink "$CP" || { x_lcdel "$CP"; x_jerr "$XC"; }
x_lpush "{\"req\":\"$(x_lid)\",\"id\":\"$J_id\",\"path\":\"$(x_e "$p")\",\"copy\":\"$(x_e "$CP")\",\"kind\":\"link\",\"url\":\"$(x_e "$U")\",\"expire\":$ET,\"hits\":0,\"own\":\"$(x_e "$XOWN")\",\"t\":$(date +%s),\"pid\":\"$(x_e "$LI")\"}"
XJF=$XD/jobs/$JOB.json XU=$U XT=$XD/jobs/.$JOB.$$ ucode -e 'let fs = require("fs"), f = getenv("XJF"), J = {}; try { J = json(fs.readfile(f) ?? "{}"); } catch (e) {} if (type(J) != "object") J = {}; J.url = getenv("XU"); fs.writefile(getenv("XT"), sprintf("%J\n", J)); fs.rename(getenv("XT"), f);' 2>/dev/null
x_jw ok expire="$ET" copy="$CP" bytes="${B:-0}" pct=100 pid=0 tries=0 err= err_en= code= ;;
url)
printf '%s' "$J_url" | grep -qE '^https?://[^[:space:][:cntrl:]]+$' || x_jerr path
[ "$J_here" = 1 ] && [ -n "$TO" ] || { TO=$(wf_udir "$XOWN" dl) && [ -n "$TO" ] || x_jerr path; }
RP=$(x_rp "$TO")
if [ "$XS" = pcloud ] && [ "$RP" = "$RM:$TO" ]; then
x_jw run pid=$$ pct=0
x_pcmk "$J_id" "$TO" || x_jerr "$XC"
set -- "url=$J_url" "path=/$TO"; [ -n "$J_name" ] && set -- "$@" "target=$(printf '%s' "$J_name" | tr -d '/\\\n\r')"
x_pc "$J_id" downloadfile 7200 "$@" > $XD/pc.$$.out &
XP=$!; while x_alive $XP; do sleep 2; [ -f $XD/jobs/$JOB.stop ] && { kill -TERM $XP 2>/dev/null; rm -f $XD/pc.$$.out $XD/pc.$$.body $XD/pc.$$.args; x_fin 254; exit 0; }; done
o=$(cat $XD/pc.$$.out 2>/dev/null); rm -f $XD/pc.$$.out
x_pcok "$o" || x_jerr "$XC"
x_jw ok pct=100 pid=0 tries=0 err= err_en= code=
else
RCLONE_JSON=$(XU=$J_url XF="${RP%%:*}:" XT=${RP#*:} ucode -e 'print(sprintf("%J", { fs: getenv("XF"), remote: getenv("XT"), url: getenv("XU"), autoFilename: true, noClobber: true }));' 2>/dev/null) || x_jerr path
export RCLONE_JSON; x_run rc --loopback operations/copyurl; rc=$?; unset RCLONE_JSON; x_fin $rc
fi ;;
*) x_jerr act ;;
esac
}
c_router() {
if [ -n "$1" ]; then x_job "$1"
else JOB=rt$(date +%Y%m%d%H%M); printf '{"job":"%s","kind":"router","name":"Copia Del Router","state":"wait","t":%s}\n' "$JOB" "$(date +%s)" > $XD/jobs/$JOB.json; x_job "$JOB"; fi
eval "$(XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} let r = N.router ?? {}, k = int(r.keep ?? 8); if (k < 1 || k > 52) k = 8; print("RA=\x27", match(r.acct ?? "", /^a[0-9]{1,2}$/) ? r.acct : "", "\x27 RK=", k, "\n");' 2>/dev/null)"
J_id=$RA; x_acct "$RA" || x_jerr none
{ [ -z "$XAO" ] || [ "$XAO" = admin ]; } && [ -n "$XRT" ] || x_jerr path
[ -s $XE/backup.pw ] || x_jerr bakpass
x_go "$RA" || exit 0
h=$( (uci -q get system.@system[0].hostname 2>/dev/null || cat /proc/sys/kernel/hostname) | tr -c 'A-Za-z0-9_-' '-' | cut -c1-30 | sed 's/-*$//')
N=${h:-router}-$(date +%Y%m%d-%H%M).wfbak; F=$XD/rt.$$.wfbak
o=$(sh $XW/backup.sh create "$F" app $XE/backup.pw 2>/dev/null)
{ printf '%s' "$o" | grep -q '"enc":true' && [ -s "$F" ]; } || { rm -f "$F"; x_rset false; x_jerr fail; }
RT=$(x_rp "$XRT")
x_r mkdir "$RT"
x_run copyto "$F" "$RT/$N"; rc=$?; rm -f "$F"
[ $rc = 0 ] || { x_rset false; x_fin $rc; exit 0; }
: > "$LOG"
x_rcl lsf "$RT" --files-only --max-depth 1 --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" |
grep -E "^${h:-router}-[0-9]{8}-[0-9]{4}\.wfbak$" | sort -r | tail -n +$((RK + 1)) | while IFS= read -r f; do
x_rcl deletefile "$RT/$f" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG"
done
x_rset true; x_fin 0
}
x_rset() {
[ -f "$XCJ" ] || return 0
x_lkget cj
XF=$XCJ XO=$1 XT=$XCJ.x$$ ucode -e 'let fs = require("fs"), N = null; try { N = json(fs.readfile(getenv("XF"))); } catch (e) {} if (type(N) != "object") exit(0); if (type(N.router) != "object") N.router = {}; N.router.ok = getenv("XO") == "true"; if (N.router.ok) N.router.last = time(); fs.writefile(getenv("XT"), sprintf("%J\n", N)); fs.rename(getenv("XT"), getenv("XF"));' 2>/dev/null
chmod 644 "$XCJ" 2>/dev/null; x_lkput cj
}
c_rtget() {
x_job "$1"
XG=$XD/dl/rg.$$.wfbak; XBF=$XR/tmp/backup.tar.gz
trap 'x_end; rm -f "$XG"' EXIT
x_acct "$J_id" || x_jerr none
[ "${J_own:-admin}" = admin ] || x_jerr path
P=$(x_path "$J_file") || x_jerr path
case "$P" in *.wfbak) ;; *) x_jerr path ;; esac
case "${P%/*}" in "$XRT"|'WrtFreedom/Router'|'WrtFreedom Router') ;; *) x_jerr path ;; esac
[ -s $XE/backup.pw ] || x_jerr bakpass
[ -f $XR/tmp/wf-restore.pending ] && x_jerr busy
x_go "$J_id" || exit 0
RP=$(x_rp "$P" r)
sz=$(x_rcl lsjson --stat "$RP" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s) == "object" && !s.IsDir) print(int(s.Size ?? 0));' 2>/dev/null)
[ -n "$sz" ] || x_jerr "$(x_tr "$LOG")"
fr=$(df -k /tmp 2>/dev/null | awk 'NR == 2 { print $4 * 1024 }')
[ $((sz * 3)) -le "${fr:-0}" ] || x_jerr big
rm -f "$XG"
x_run copyto "$RP" "$XG"; rc=$?
[ $rc = 0 ] || { rm -f "$XG"; x_fin $rc; exit 0; }
chmod 600 "$XG" 2>/dev/null
[ "$(head -c 7 "$XG" 2>/dev/null)" = "WFBAK1 " ] || x_jerr fail
o=$(sh $XW/backup.sh inspect "$XG" $XE/backup.pw 2>/dev/null)
case "$o" in
*'"ok":true'*) ;;
*'"code":"pass"'*|*'"code":"needpass"'*) x_jerr bakpass ;;
*) x_jerr fail ;;
esac
{ mv -f "$XG" "$XBF" && chmod 600 "$XBF"; } || { rm -f "$XBF"; x_jerr fail; }
x_fin 0 "$sz"
}
x_tys() { XN=$XW/nastipi.uc ucode -e 'let T = {}; try { T = loadfile(getenv("XN"))() ?? {}; } catch (e) {} for (let k, l in { video: T.vid, music: T.mus, photo: T.img, doc: T.doc, app: T.app }) print(k, " ", join(" ", filter(type(l) == "array" ? l : [], (e) => type(e) == "string" && match(e, /^[a-z0-9]{1,8}$/))), "\n");' 2>/dev/null; }
x_tflt() {
printf '%s\n' '- .wf-*/**' '- .wf-*'
[ "$2" = flat ] && echo '- /*/**'
if [ "$1" = other ]; then
printf '%s\n' "$XTY" | while read -r _ e; do for x in $e; do echo "- *.$x"; done; done
else
printf '%s\n' "$XTY" | while read -r k e; do [ "$k" = "$1" ] && for x in $e; do echo "+ *.$x"; done; done
echo '- **'
fi
}
c_media() {
umask 022
x_job "$1"
x_acct "$J_id" || x_jerr none
x_own "$J_own" || x_jerr none
x_mainp && x_jerr nomain
MD=$(x_main); [ -n "$MD" ] || x_jerr nomain
x_disk "$MD" rw; rc=$?; [ $rc = 2 ] && x_jerr ro; [ $rc = 0 ] || x_jerr disk
TO=$(wf_udir shared media) && [ -n "$TO" ] || x_jerr path
x_go "$J_id" || exit 0
mkdir -p "$XM/$TO" 2>/dev/null || x_jerr ro
XTY=$(x_tys)
XB=0
for ty in video music photo; do
SP=$(wf_udir shared media $ty) && [ -n "$SP" ] || x_jerr path
D=$SP
[ -z "$J_paths" ] || printf '%s\n' "$J_paths" | sed 's#^/*##; s#/*$##' | grep -qxF "$SP" || continue
x_tflt $ty > $XD/flt.$$
x_both "$SP" > $XD/flt.$$.b
while IFS= read -r s_; do
x_run copy "$s_" "$XM/$D" --filter-from $XD/flt.$$ --ignore-case; rc=$?
[ $rc = 0 ] || { rm -f $XD/flt.$$.b; x_fin $rc; exit 0; }
done < $XD/flt.$$.b
rm -f $XD/flt.$$.b
b=$(x_bytes); [ "${b:-0}" -gt 0 ] 2>/dev/null && { cl_add "$b" >/dev/null 2>&1; XB=$((XB + b)); }
done
x_jw ok bytes="$XB" pct=100 pid=0 tries=0 err= err_en= code=
[ -f $XW/nasvc.sh ] && sh $XW/nasvc.sh dlnascan >/dev/null 2>&1 </dev/null
true
}
XKD=3
XCV='\.(mp4|mkv|avi|mov|dav|264|265|h264|h265|ts|asf|m4v|3gp)$'; XCI='\.(mp4|mkv|avi|mov|dav|264|265|h264|h265|ts|asf|m4v|3gp|jpg|jpeg)$'
x_camlim() {
mb=$(awk -v g="${J_max_gb:-0}" 'BEGIN { if (g ~ /^[0-9]+(\.[0-9]+)?$/ && g + 0 > 0) printf "%.0f", g * 1073741824 }')
[ -n "$mb" ] || return 0
b=$(awk -v S="[$J_rem]" '$0 == S { f = 1; next } /^\[/ { f = 0 } f && /^remote *= */ { sub(/^remote *= */, ""); print; exit }' "$XCF")
b=${b%%:*}; printf '%s' "$b" | grep -qE '^wf[a-z0-9]{1,20}$' && grep -qx "\[$b\]" "$XCF" || b=$J_rem
ct=$(date -d "@$(( $(date +%s) - XKD * 86400 ))" '+%Y-%m-%d %H:%M:%S' 2>/dev/null) || return 0
LC=$XD/log/$JOB.lim; CL=$XD/cl.$$; : > "$LC"
x_rcl lsf "$b:" -R --files-only --format tsp --separator '	' --log-file "$LC" --log-level ERROR </dev/null 2>>"$LC" > "$CL" || { rm -f "$CL" "$LC"; return 0; }
ov=$(LC_ALL=C sort "$CL" | awk -F '	' -v M="$mb" -v C="$ct" -v O="$CL.d" -v R="$XCI" '
		{ p = $0; sub(/^[^\t]*\t[^\t]*\t/, "", p); if (tolower(p) !~ R) next; n++; t[n] = $1; s[n] = $2 + 0; f[n] = p; tot += $2 }
		END { nd = tot - M; for (i = 1; i <= n && nd > 0; i++) if (t[i] < C) { print f[i] > O; nd -= s[i] } print (nd > 0 ? 1 : 0) }')
[ -s "$CL.d" ] && x_rcl delete "$b:" --files-from-raw "$CL.d" --log-file "$LC" --log-level ERROR </dev/null 2>>"$LC"
rm -f "$CL" "$CL.d" "$LC"
[ "$ov" = 1 ] && [ -f $XW/event.sh ] && [ "$(cat $XD/camlim.day 2>/dev/null)" != "$(date +%Y%m%d)" ] || return 0
date +%Y%m%d > $XD/camlim.day
if x_en; then m_="🗄️ Cameras ¦ At The Cloud Limit ¦ Last $XKD Days Kept ¦ Raise the cloud cap"
else m_="🗄️ Telecamere ¦ Al Limite Nel Cloud ¦ Tenuti Gli Ultimi $XKD Giorni ¦ Alza il Tetto nel cloud"; fi
sh $XW/event.sh cron nas_cams_limit nas "$m_" admin </dev/null >/dev/null 2>&1; true
}
c_camup() {
x_job "$1"
x_acct "$J_id" || x_jerr none
printf '%s' "$J_rem" | grep -qE '^wf[a-z0-9]{1,20}[xy]$' && grep -qx "\[$J_rem\]" "$XCF" || x_jerr path
MV=copy
if [ -n "$J_stage" ]; then
s_=${J_stage#/tmp/wf-nas/camcloud/}
{ [ "$s_" != "$J_stage" ] && printf '%s' "$s_" | grep -qE '^[A-Za-z0-9_-][A-Za-z0-9_.-]{0,63}$' && [ -d "$J_stage" ]; } || x_jerr path
SD=$J_stage; [ "$J_move" = 1 ] && MV=move
else
x_disk "$J_disk"; [ $? = 0 ] || x_jerr disk
SP=$(x_path "$J_src") || x_jerr path; [ -d "$XM/$SP" ] || x_jerr path
SD=$XM/$SP
fi
x_go "$J_id" || exit 0
cap=$(printf '%s' "${J_cap:-0}" | tr -cd '0-9'); cap=${cap:-0}
if [ "$J_night" = 1 ]; then
k=$(printf '%s' "${J_keep_days:-0}" | tr -cd '0-9'); k=${k:-0}
[ "$k" -gt 0 ] && [ "$k" -lt $XKD ] && k=$XKD
[ "$k" -gt 0 ] && { x_run delete "$J_rem:" --min-age "${k}d"; rc=$?; [ $rc = 0 ] || { x_fin $rc; exit 0; }; }
fi
XMT0=$XMT; x_cap "$cap"
wh=$J_what; hw=$J_how
[ -n "$wh" ] && [ -n "$hw" ] || {
o=$(XN=$XE/nas.json ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XN")) ?? "{}"); } catch (e) {} let c = N?.rec?.cloud ?? {}; print(c.what ?? "", " ", c.how ?? "");' 2>/dev/null)
[ -n "$wh" ] || wh=${o%% *}; [ -n "$hw" ] || hw=${o#* }
}
case "$wh" in motion|alarm) ;; *) wh=all ;; esac
case "$hw" in cont) ty=$XCV ;; *) ty=$XCI ;; esac
al='(alarm|(^|/)al[-_]|[-_]al[-_.]|[-_]io[-_.])'
case "$wh" in motion) ev="(motion|(^|/)md[-_]|[-_]md[-_.]|event|evt|$al)" ;; alarm) ev=$al ;; *) ev= ;; esac
FL=$XD/flt.$$; ag='-mmin -120'; [ -n "$J_stage" ] && ag=
( cd "$SD" && find . -type f $ag -mmin +1 2>/dev/null ) | sed 's#^\./##' | grep -v '\(^\|/\)\.' | grep -iE "$ty" |
{ if [ -n "$ev" ]; then grep -iE "$ev"; else cat; fi; } > "$FL"
[ -s "$FL" ] || { x_slput; x_jw ok bytes=0 pct=100 pid=0 tries=0 err= err_en= code=; exit 0; }
x_run $MV "$SD" "$J_rem:" --files-from-raw "$FL" --no-traverse; rc=$?
case $rc in 0|8) x_camlim ;; esac
if [ $rc = 8 ] && [ "$cap" -gt 0 ] && [ "$XMT" = "$cap" ] && { [ -z "$XMT0" ] || [ "$cap" -lt "$XMT0" ]; } && [ -f $XW/event.sh ] && [ "$(cat $XD/camcap.day 2>/dev/null)" != "$(date +%Y%m%d)" ]; then
date +%Y%m%d > $XD/camcap.day
sh $XW/event.sh cron cloud_camcap cloud "🗄️ Copia Fuori Casa ¦ Tetto di oggi raggiunto ¦ $(( cap / 1048576 )) MB" >/dev/null 2>&1
fi
x_fin $rc
}
c_recv() {
JOB=recv; printf '{"job":"recv","kind":"recv","name":"Ricevuti","state":"wait","t":%s}\n' "$(date +%s)" > $XD/jobs/recv.json
x_job recv
XLS=$XD/recv.$$; trap 'x_end; rm -f "$XLS"' EXIT
XL=$XLJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XL")) ?? "{}"); } catch (e) {} for (let l in (N.items ?? [])) if (l.kind == "upreq" && match(l.id ?? "", /^a[0-9]{1,2}$/) && !match(l.path ?? "", /[\n\r\t]/)) print(l.id, "\t", l.path, "\t", type(l.own) == "string" && match(l.own, /^[A-Za-z0-9._-]{1,64}$/) ? l.own : "admin", "\t", l.to_nas !== false ? 1 : 0, "\n");' > "$XLS" 2>/dev/null
[ -s "$XLS" ] || { x_jw ok pid=0; exit 0; }
dk=
if grep -q '	1$' "$XLS"; then
if x_mainp; then dk=nomain
else
MD=$(x_main)
if [ -z "$MD" ]; then dk=disk; else x_disk "$MD" rw; rc=$?; [ $rc = 2 ] && dk=ro; [ $rc = 0 ] || [ $rc = 2 ] || dk=disk; fi
fi
fi
XTY=$(x_tys); ok=0; bad=; XSR=$(wf_udir shared root) || XSR=/
while IFS='	' read -r a p ow tn; do
x_acct "$a" || continue; J_id=$a
p=$(x_path "$p") && [ -n "$p" ] || continue
R=$(wf_udir "$ow" recv) && [ -n "$R" ] || continue
if [ "$tn" = 1 ]; then
[ -n "$dk" ] && { bad=$dk; continue; }
x_full "$ow" && { bad=quota_full; continue; }
B=$XM/
else B=; fi
x_go "$a" || { bad=later; continue; }
for ty in video music photo doc app other; do
D=$(wf_udir "$ow" recv $ty) && [ -n "$D" ] || continue
case "$D/" in "$XSR"/*) continue ;; esac
[ "$tn" = 1 ] && { mkdir -p "$XM/$D" 2>/dev/null || { bad=ro; break; }; }
x_tflt $ty flat > $XD/flt.$$
if [ -n "$B" ]; then DD=$B$D; else DD=$(x_rp "$D"); fi
x_run move "$(x_rp "$p" r)" "$DD" --filter-from $XD/flt.$$ --ignore-case; rc=$?
[ $rc = 0 ] || { bad=$(x_tr "$LOG"); break; }
done
x_slput; x_gen "$a"
[ $rc = 0 ] && ok=$((ok + 1))
done < "$XLS"
if [ -n "$bad" ] && [ "$bad" != later ]; then x_jerr "$bad"; fi
x_jw ok pid=0
}

c_thumbs() {
x_req "$1"
[ "$XS" = pcloud ] || x_rerr caps
o=$XD/th.$$; trap 'rm -f "$XRO" "$o".*' EXIT
sz=$(printf '%s' "$J_size" | tr -cd '0-9'); sz=${sz:-256}
: > "$o.p"
if [ -s "$XCC" ] || [ -n "$J_cm" ]; then
XF=$F ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {}
let P = type(N.paths) == "array" ? N.paths : [], K = type(N.keys) == "array" ? N.keys : P;
for (let i = 0; i < length(P) && i < 50; i++) { let p = P[i], k = type(K[i]) == "string" ? K[i] : p, m = type(N.cm) == "object" ? N.cm[p] : null;
	if (type(p) == "string" && type(k) == "string" && !match(p + k, /[[:cntrl:]]/)) print(k, "\t", p, "\t", type(m) == "object" ? sprintf("%J", m) : "", "\n"); }' > "$o.q" 2>/dev/null
np=0
while IFS='	' read -r k_ p_ m_; do
q_=$(x_path "$p_") && [ -n "$q_" ] || continue
if [ -n "$m_" ]; then r_=$(x_cmr "$m_") || continue; else x_cs "$q_" || continue; r_=$(x_rp "$q_" r); fi
case "$(printf '%s' "${q_##*.}" | tr 'A-Z' 'a-z')" in jpg|jpeg|png|gif|webp|bmp|heic|heif) ;; *) continue ;; esac
np=$((np + 1)); [ $np -gt 10 ] && break
x_ctok "$r_" "${q_##*/}" 8388609 || continue
if [ "$(wc -c < "$O_")" -gt 8388608 ]; then
rm -f "$O_" "$O_.tok" "/tmp/wf-nas/x/st/$tk.json"
z_=$(x_rcl lsjson --stat "$r_" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s) == "object" && !s.IsDir) print(int(s.Size ?? 0));' 2>/dev/null)
[ -n "$z_" ] && x_cflow "$r_" "${q_##*/}" "$z_" || continue
fi
printf '%s\t%s\n' "$k_" "$XTU" >> "$o.p"
done < "$o.q"
fi
XF=$F ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} let S = {};
for (let p in (type(N.paths) == "array" ? N.paths : [])) { if (type(p) != "string" || match(p, /[[:cntrl:]]/)) continue; let d = replace(replace(p, /\/[^\/]*$/, ""), /^\/+/, ""); if (!S[d]) { S[d] = true; print(d, "\n"); } }' > "$o.d" 2>/dev/null
n=0; : > "$o.m"
while IFS= read -r d; do
n=$((n + 1)); [ $n -gt 10 ] && break
x_pc "$J_id" listfolder 10 "path=/$d" timeformat=timestamp > "$o.l$n" </dev/null
if ! x_pcokf "$o.l$n"; then case "$XC" in relink|net|busy) x_rerr "$XC" ;; esac; rm -f "$o.l$n"; continue; fi
printf '%s\t%s\n' "$n" "$d" >> "$o.m"
done < "$o.d"
ids=$(XF=$F XO=$o ucode -e 'let fs = require("fs"), N = {}, o = getenv("XO"), M = {}, I = {}, L = [];
try { N = json(fs.readfile(getenv("XF")) ?? "{}"); } catch (e) {}
for (let l in split(fs.readfile(o + ".m") ?? "", "\n")) { let m = match(l, /^([0-9]+)\t(.*)$/); if (!m) continue;
	let D = null; try { D = json(fs.readfile(o + ".l" + m[1]) ?? ""); } catch (e) {}
	let C = {}; for (let x in (type(D?.metadata?.contents) == "array" ? D.metadata.contents : [])) if (type(x) == "object" && type(x.name) == "string") C[x.name] = x;
	M[m[2]] = C; }
let P = type(N.paths) == "array" ? N.paths : [], K = type(N.keys) == "array" ? N.keys : P;
for (let i = 0; i < length(P) && i < 50; i++) { let p = P[i]; if (type(p) != "string") continue;
	let d = replace(replace(p, /\/[^\/]*$/, ""), /^\/+/, ""), f = M[d]?.[replace(p, /^.*\//, "")];
	if (type(f) != "object" || f.isfolder === true || (f.category != 1 && f.category != 2) || f.thumb === false || type(f.fileid) != "int") continue;
	let k = "" + f.fileid; if (!I[k]) { I[k] = []; push(L, k); } push(I[k], type(K[i]) == "string" ? K[i] : p); }
fs.writefile(o + ".k", sprintf("%J", I)); print(join(",", L));' 2>/dev/null)
if [ -z "$ids" ]; then x_log; x_res "$(x_thp '{"thumbs":{},"exp":0}')"; exit 0; fi
x_pc "$J_id" getthumbslinks 10 "fileids=$ids" "size=${sz}x${sz}" crop=1 timeformat=timestamp > "$o.t" </dev/null
x_pcokf "$o.t" || x_rerr "$XC"
r=$(XO=$o ucode -e 'let fs = require("fs"), o = getenv("XO"), I = {}, D = null, R = {}, ex = 0;
try { I = json(fs.readfile(o + ".k") ?? "{}"); D = json(fs.readfile(o + ".t") ?? ""); } catch (e) {}
for (let t in (type(D?.thumbs) == "array" ? D.thumbs : [])) {
	if (type(t) != "object" || t.result !== 0 || type(t.path) != "string" || type(t.hosts?.[0]) != "string" || !match(t.hosts[0], /^[A-Za-z0-9.-]+$/) || substr(t.path, 0, 1) != "/") continue;
	let u = "https://" + t.hosts[0] + t.path;
	for (let k in (I["" + t.fileid] ?? [])) R[k] = u;
	if (type(t.expires) == "int" && (!ex || t.expires < ex)) ex = t.expires; }
printf("%J\n", { thumbs: R, exp: ex });' 2>/dev/null) || x_rerr fail
[ -n "$r" ] || x_rerr fail
x_log; x_res "$(x_thp "$r")"
}
x_thp() {
[ -s "$o.p" ] || { printf '%s' "$1"; return 0; }
printf '%s' "$1" | XO=$o.p XX=$(( $(date +%s) + 3600 )) ucode -e 'let fs = require("fs"), R = null; try { R = json(fs.stdin.read("all")); } catch (e) {}
if (type(R) != "object") R = { thumbs: {}, exp: 0 }; if (type(R.thumbs) != "object") R.thumbs = {};
let n = 0; for (let l in split(fs.readfile(getenv("XO")) ?? "", "\n")) { let c = split(l, "\t"); if (length(c) == 2) { R.thumbs[c[0]] = c[1]; n++; } }
if (n && (!R.exp || R.exp > +getenv("XX"))) R.exp = +getenv("XX");
printf("%J\n", R);' 2>/dev/null
}
x_cloc() {
RP=$(x_cmr "$J_cm") || RP=$(x_rp "$XP" r)
sz=$(x_rcl lsjson --stat "$RP" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | ucode -e 'let s = null; try { s = json(require("fs").stdin.read("all")); } catch (e) {} if (type(s) == "object" && !s.IsDir) print(int(s.Size ?? 0));' 2>/dev/null)
[ -n "$sz" ] && [ "$sz" -ge 0 ] 2>/dev/null || x_rerr "$(x_tr "$LOG")"
if [ "$1" = flow ] || [ "$sz" -gt 8388608 ]; then x_cflow "$RP" "${XP##*/}" "$sz" || x_rerr fail; return 0; fi
[ "$sz" -le "$(x_cmax phone_mb 32 256)" ] || x_rerr big
x_ctok "$RP" "${XP##*/}" "$((sz + 1))" || x_rerr "$(x_tr "$LOG")"
}
x_ev() {
[ -f $XW/event.sh ] || return 0
if x_en; then m_=$3; else m_=$2; fi
if [ -n "$4" ] && [ "$4" != admin ]; then WF_SOLO=1 sh $XW/event.sh cron "$1" cloud "$m_" "$4" </dev/null >/dev/null 2>&1
else sh $XW/event.sh cron "$1" cloud "$m_" </dev/null >/dev/null 2>&1; fi; true
}
x_pnm() { p_=$(wf_udir "$1" root 2>/dev/null) && [ -n "$p_" ] && printf '%s' "${p_##*/}" || printf '%s' "$1"; }
X_UCN='function c(s, n) { s = trim(replace(replace(replace("" + s, /[[:cntrl:]]+/g, " "), "¦", " "), "|", " ")); if (length(s) <= n) return s; while (n > 0 && (ord(s, n) & 192) == 128) n--; return substr(s, 0, n) + "…"; }'
c_revs() {
x_req "$1"
[ "$XS" = pcloud ] || x_rerr caps
[ -n "$XP" ] || x_rerr path
o=$XD/rv.$$; trap 'rm -f "$XRO" "$o" "$XD/revs-$J_id.json.$$"' EXIT
x_pp "$XP" || x_rerr path
x_pc "$J_id" listrevisions 10 "path=/$PP" timeformat=timestamp > "$o" </dev/null
x_pcokf "$o" || x_rerr "$XC"
r=$(XF=$o XK=$XD/revs-$J_id.json XN=$$ XPP=$XP XPD=$XPD ucode -e 'let fs = require("fs"), D = null; try { D = json(fs.readfile(getenv("XF")) ?? ""); } catch (e) {} let L = [];
function dz(n) { if (getenv("XPD") != "1") return n; if (n < 32) return 0; let r = n - 32; return r - 16 * int((r + 65551) / 65552); }
for (let v in (type(D?.revisions) == "array" ? D.revisions : [])) if (type(v) == "object" && type(v.revisionid) == "int")
	push(L, { rev: v.revisionid, t: type(v.created) == "int" ? v.created : 0, size: type(v.size) == "int" ? dz(v.size) : 0 });
L = sort(L, (a, b) => b.t - a.t); if (length(L) > 500) L = slice(L, 0, 500);
let m = type(D?.metadata) == "object" ? D.metadata : {}, k = getenv("XK"), t = k + "." + getenv("XN");
if (fs.writefile(t, sprintf("%J", { path: getenv("XPP"), list: map(L, (x) => ({ rev: x.rev, t: x.t })) }))) fs.rename(t, k);
printf("%J\n", { list: L, cur: { size: type(m.size) == "int" ? dz(m.size) : 0, t: type(m.modified) == "int" ? m.modified : 0 } });' 2>/dev/null)
[ -n "$r" ] || x_rerr fail
x_log; x_res "$r"
}
x_revt() { [ -s "$1" ] || return 0
ka=$(( $(date +%s) - $(date -r "$1" +%s 2>/dev/null || echo 0) ))
[ "$ka" -ge 0 ] && [ "$ka" -le 600 ] || return 0
XF=$1 XPP=$XP XRV=$rv ucode -e 'let D = null; try { D = json(require("fs").readfile(getenv("XF")) ?? ""); } catch (e) {}
if (type(D) != "object") exit(0); if (D.path != null && D.path != getenv("XPP")) exit(0);
for (let v in (type(D.list) == "array" ? D.list : (type(D.revisions) == "array" ? D.revisions : [])))
	if (type(v) == "object" && "" + (v.rev ?? v.revisionid) == getenv("XRV") && type(v.t ?? v.created) == "int" && (v.t ?? v.created) > 0) { print(v.t ?? v.created); break; }' 2>/dev/null; }
c_revert() {
x_req "$1"
[ "$XS" = pcloud ] || x_rerr caps
[ -n "$XP" ] || x_rerr path
x_iscrypt "$J_id" "$XP" && x_rerr bk
rv=$(printf '%s' "$J_rev" | tr -cd '0-9'); { [ -n "$rv" ] && [ "$rv" != 0 ]; } || x_rerr rev
f=$XD/rt.$$; trap 'rm -f "$XRO" "$f" "$XD/revs-$J_id.json"' EXIT
tv=$(x_revt "$XD/revs-$J_id.json")
x_pp "$XP" || x_rerr path
o=$(x_pc "$J_id" revertrevision 10 "path=/$PP" "revisionid=$rv" timeformat=timestamp </dev/null)
x_pcok "$o" || x_rerr "$XC"
x_log; x_res '{"ok":true}'; x_hk
if [ -z "$tv" ]; then
x_pc "$J_id" listrevisions 10 "path=/$PP" timeformat=timestamp > "$f" </dev/null && x_pcokf "$f" && tv=$(x_revt "$f")
rm -f "$f"
fi
rm -f "$XD/revs-$J_id.json"
m=$(XPP=$XP XTV=$tv ucode -e "$X_UCN"'
let n = c(replace(getenv("XPP") ?? "", /^.*\//, ""), 60), t = +(getenv("XTV") ?? 0), d = "", e = "";
if (t > 0) { let l = localtime(t); d = sprintf("%02d/%02d/%04d %02d:%02d", l.mday, l.mon, l.year, l.hour, l.min); e = sprintf("%04d-%02d-%02d %02d:%02d", l.year, l.mon, l.mday, l.hour, l.min); }
print("🗄️ ", n, " ¦ ", t > 0 ? "Ripristinata la versione del " + d : "Ripristinata una versione precedente", "\n");
print("🗄️ ", n, " ¦ ", t > 0 ? "Restored the version of " + e : "Restored a previous version", "\n");' 2>/dev/null)
[ -n "$m" ] && x_ev cloud_rev_revert "$(printf '%s\n' "$m" | sed -n 1p)" "$(printf '%s\n' "$m" | sed -n 2p)" "$XOWN"
true
}
x_trold() { ka=$(( $(date +%s) - $(date -r "$K" +%s 2>/dev/null || echo 0) )); [ ! -s "$K" ] || [ "$ka" -gt 120 ] || [ "$ka" -lt 0 ]; }
x_trbuild() {
x_pc "$J_id" trash_list 10 folderid=0 timeformat=timestamp > "$o.t" </dev/null
x_pcokf "$o.t" || x_rerr "$XC"
: > "$o.f"
if grep -q '"origparentfolderid": *[1-9]' "$o.t"; then
x_pc "$J_id" listfolder 10 folderid=0 recursive=1 nofiles=1 timeformat=timestamp > "$o.f" </dev/null
x_pcokf "$o.f" || x_rerr "$XC"
fi
XO=$o XK=$K XN=$$ ucode -e 'let fs = require("fs"), o = getenv("XO"), D = null, F = null, P = { "0": "" }, T = {}, L = [], H = [];
try { D = json(fs.readfile(o + ".t") ?? ""); } catch (e) {}
try { F = json(fs.readfile(o + ".f") ?? ""); } catch (e) {}
function walk(m, p) { for (let x in (type(m?.contents) == "array" ? m.contents : [])) if (type(x) == "object" && type(x.folderid) == "int" && type(x.name) == "string") { P["" + x.folderid] = p + "/" + x.name; walk(x, p + "/" + x.name); } }
if (type(F?.metadata) == "object") walk(F.metadata, "");
let C = type(D?.metadata?.contents) == "array" ? D.metadata.contents : [];
for (let x in C) if (type(x) == "object" && x.isfolder === true && type(x.folderid) == "int" && type(x.name) == "string") T["" + x.folderid] = x;
function where(id, d) { let k = "" + (id ?? 0); if (P[k] != null) return P[k]; let x = T[k]; if (!x || d > 30) return null;
	let p = where(x.origparentfolderid, d + 1); return p != null ? p + "/" + x.name : null; }
function hide(p) { if (match(p, /^\/Utenti\/[^\/]+\/Backup(\/|$)/) && !match(p, /^\/Utenti\/Cartella Condivisa\//)) return true;
	for (let r in [ "/WrtFreedom/Backup", "/WrtFreedom Backup", "/Crypto Folder" ]) if (p == r || substr(p, 0, length(r) + 1) == r + "/") return true; return false; }
for (let x in C) {
	if (type(x) != "object" || type(x.name) != "string" || !match(x.id ?? "", /^[fd][1-9][0-9]*$/)) continue;
	let pp = where(x.origparentfolderid, 0), p = pp != null ? pp + "/" + x.name : "";
	if (x.encrypted === true || hide(p)) { push(H, x.id); continue; }
	push(L, { tid: x.id, name: x.name, path: p, dir: x.isfolder === true,
		size: type(x.size) == "int" ? x.size : 0, t: type(x.modified) == "int" ? x.modified : 0 }); }
L = sort(L, (a, b) => b.t - a.t);
let k = getenv("XK"), n = k + ".n." + getenv("XN"); if (!fs.writefile(n, sprintf("%J", { list: L, hid: H })) || !fs.rename(n, k)) exit(1);' 2>/dev/null || x_rerr fail
x_trdec
}
x_trdec() {
[ -s "$XCC" ] && grep -q '^type *= *crypt' "$XCF" 2>/dev/null || return 0
XK=$K ucode -e 'let D = null; try { D = json(require("fs").readfile(getenv("XK")) ?? ""); } catch (e) {}
for (let x in (type(D?.list) == "array" ? D.list : [])) { let m = type(x) == "object" ? match(x.path ?? "", /^\/Utenti\/([^\/\t\n]+)\/([^\t\n]+)$/) : null; if (m) print(m[1], "\t", m[2], "\n"); }' > "$o.e" 2>/dev/null
[ -s "$o.e" ] || { rm -f "$o.e"; return 0; }
: > "$o.m"
cut -f1 "$o.e" | sort -u > "$o.v"
while IFS= read -r v; do
x_cs "Utenti/$v/x" || continue
set --; while IFS='	' read -r a_ b_; do [ "$a_" = "$v" ] && set -- "$@" "$b_"; done < "$o.e"
[ $# -gt 0 ] || continue
x_rcl cryptdecode "$XCS:" "$@" </dev/null 2>/dev/null | awk -F '\t' -v V="$v" '$2 !~ /Failed to decrypt/ { sub(/ +$/, "", $1); sub(/^ +/, "", $2); if ($2 != "") print V "\t" $1 "\t" $2 }' >> "$o.m"
done < "$o.v"
[ -s "$o.m" ] && XK=$K XM=$o.m XN=$$ ucode -e 'let fs = require("fs"), k = getenv("XK"), D = null, M = {};
try { D = json(fs.readfile(k) ?? ""); } catch (e) {}
if (type(D?.list) != "array") exit(0);
for (let l in split(fs.readfile(getenv("XM")) ?? "", "\n")) { let c = split(l, "\t"); if (length(c) == 3 && length(c[2])) M["/Utenti/" + c[0] + "/" + c[1]] = "/Utenti/" + c[0] + "/" + c[2]; }
for (let x in D.list) if (type(x) == "object" && M[x.path] != null) { x.path = M[x.path]; x.name = replace(x.path, /^.*\//, ""); x.enc = true; }
let n = k + ".n." + getenv("XN"); if (fs.writefile(n, sprintf("%J", D))) fs.rename(n, k);' 2>/dev/null
rm -f "$o.e" "$o.m" "$o.v"
}
X_TRF='let pu = getenv("XPU") ?? "", P = null; try { P = json(getenv("XPL") || "{}")?.l; } catch (e) {} if (type(P) != "array") P = [];
function under(p, r) { return p == r || substr(p, 0, length(r) + 1) == r + "/"; }
function whose(x) { let p = type(x?.path) == "string" ? x.path : "";
	if (length(pu)) return length(p) && under(p, "/" + pu) ? null : "";
	for (let q in P) if (type(q) == "object" && type(q.dir) == "string" && length(q.dir) > 1 && length(p) && under(p, q.dir)) return q;
	return null; }'
c_trash() {
x_req "$1"
x_wtis && { c_wttrash; exit 0; }
[ "$XS" = pcloud ] || x_rerr caps
o=$XD/tr.$$; K=$XD/trash-$J_id.json; trap 'rm -f "$XRO" "$o".* "$K.n.$$"' EXIT
off=$(printf '%s' "$J_off" | tr -cd '0-9'); off=${off:-0}
if [ "$off" = 0 ] || x_trold; then x_trbuild; fi
r=$(XK=$K XOF=$off XPU=$XPU XPL=$J_ppl ucode -e "$X_TRF"'
let D = null; try { D = json(require("fs").readfile(getenv("XK")) ?? ""); } catch (e) {}
let A = type(D?.list) == "array" ? D.list : [], L = [], G = {}, R = [];
for (let x in A) { let w = whose(x); if (w == null) { push(L, x); continue; } if (type(w) != "object") continue;
	let g = G[w.own]; if (!g) { g = G[w.own] = { own: "" + w.own, own_name: "" + (w.own_name ?? w.own), n: 0 }; push(R, g); } g.n++; }
let o = +getenv("XOF"), n = length(L), out = { list: slice(L, o, o + 500), off: o, n: n, more: o + 500 < n };
if (length(P)) out.people = sort(R, (a, b) => a.own_name < b.own_name ? -1 : a.own_name > b.own_name ? 1 : 0);
printf("%J\n", out);' 2>/dev/null)
[ -n "$r" ] || x_rerr fail
x_log; x_res "$r"
}
x_trhid() { XK=$K XT=$J_tids XPU=$XPU XPL=$J_ppl ucode -e "$X_TRF"'
let D = null; try { D = json(require("fs").readfile(getenv("XK")) ?? ""); } catch (e) {}
let V = {}, H = {}, r = "ok";
for (let x in (type(D?.list) == "array" ? D.list : [])) if (type(x) == "object") V["" + x.tid] = x;
for (let t in (type(D?.hid) == "array" ? D.hid : [])) H["" + t] = true;
for (let t in split(getenv("XT") ?? "", /[ \t\n]+/)) { if (!match(t, /^[fd][1-9][0-9]*$/)) continue; if (H[t]) { r = "bk"; break; } if (!V[t]) { r = "miss"; continue; }
	if (whose(V[t]) != null) { r = "priv"; break; } }
print(r);' 2>/dev/null; }
c_restore() {
x_req "$1"
x_wtis && { c_wtrestore; exit 0; }
[ "$XS" = pcloud ] || x_rerr caps
o=$XD/rs.$$; K=$XD/trash-$J_id.json; trap 'rm -f "$XRO" "$o".* "$K" "$K.n.$$"' EXIT
h=miss; x_trold || h=$(x_trhid)
case "$h" in ok|bk|priv) ;; *) x_trbuild; h=$(x_trhid) ;; esac
[ "$h" = miss ] && [ -n "$XPU" ] && h=priv
case "$h" in bk) x_rerr bk ;; priv) x_rerr private ;; ok|miss) ;; *) x_rerr fail ;; esac
XK=$K XT=$J_tids ucode -e 'let D = null; try { D = json(require("fs").readfile(getenv("XK")) ?? ""); } catch (e) {} let V = {};
for (let x in (type(D?.list) == "array" ? D.list : [])) if (type(x) == "object" && type(x.name) == "string") V["" + x.tid] = x.name;
for (let t in split(getenv("XT") ?? "", /[ \t\n]+/)) if (V[t] != null) print(t, "\t", V[t], "\n");' > "$o.nm" 2>/dev/null
rm -f "$K"
: > "$o.ok"
n=0; l=0; e=; e0=; c=0
for t in $J_tids; do
c=$((c + 1)); [ $c -gt 50 ] && break
case "$t" in f[1-9]*) k=fileid ;; d[1-9]*) k=folderid ;; *) continue ;; esac
v=${t#?}; case "$v" in *[!0-9]*) continue ;; esac
if [ -n "$e" ]; then l=$((l + 1)); continue; fi
r_=$(x_pc "$J_id" trash_restore 10 "$k=$v" timeformat=timestamp </dev/null)
if x_pcok "$r_"; then n=$((n + 1)); printf '%s\n' "$t" >> "$o.ok"; else l=$((l + 1)); case "$XC" in relink|net|busy|space) e=$XC ;; *) e0=$XC ;; esac; fi
done
[ "$n" -gt 0 ] || x_rerr "${e:-${e0:-path}}"
x_log; x_res "{\"ok\":true,\"restored\":$n,\"left\":$l}"; x_hk
m=$(XO=$o XN=$n XL=$l ucode -e "$X_UCN"'
let fs = require("fs"), o = getenv("XO"), N = {}, W = [], n = +getenv("XN"), l = +getenv("XL");
for (let x in split(fs.readfile(o + ".nm") ?? "", "\n")) { let m = match(x, /^([fd][0-9]+)\t(.+)$/); if (m) N[m[1]] = m[2]; }
for (let t in split(fs.readfile(o + ".ok") ?? "", "\n")) if (N[t] != null && length(W) < 3) push(W, c(N[t], 40));
let r = n - length(W), w = join(", ", W);
let it = "🗄️ Cestino Di pCloud ¦ " + (n == 1 ? "Ripristinato 1" : "Ripristinati " + n) + (length(W) ? ": " + w + (r > 0 ? " e altri " + r : "") : "") + (l > 0 ? " ¦ " + l + (l == 1 ? " non ripristinato" : " non ripristinati") : "");
let en = "🗄️ pCloud Trash ¦ Restored " + n + (length(W) ? ": " + w + (r > 0 ? " and " + r + " more" : "") : "") + (l > 0 ? " ¦ " + l + " not restored" : "");
print(it, "\n", en, "\n");' 2>/dev/null)
[ -n "$m" ] && x_ev cloud_trash_restore "$(printf '%s\n' "$m" | sed -n 1p)" "$(printf '%s\n' "$m" | sed -n 2p)" "$XOWN"
true
}
c_stream() {
x_req "$1"
[ -n "$XP" ] || x_rerr path
x_iscrypt "$J_id" "$XP" && x_rerr bk
if [ "$XS" != pcloud ] || [ -n "$J_cm" ] || x_cs "$XP"; then x_cloc flow; x_log; x_res "{\"url\":\"$(x_e "$XTU")\",\"hls\":\"\",\"exp\":$XTX,\"local\":true}"; exit 0; fi
if [ "$J_kind" = audio ]; then m=getaudiolink; else m=getvideolink; fi
o=$XD/st.$$; trap 'rm -f "$XRO" "$o".*' EXIT
x_pc "$J_id" "$m" 10 "path=/$XP" timeformat=timestamp > "$o.a" </dev/null
x_pcokf "$o.a" || x_rerr "$XC"
: > "$o.b"; [ "$J_kind" = audio ] || x_pc "$J_id" gethlslink 10 "path=/$XP" timeformat=timestamp > "$o.b" </dev/null
r=$(XO=$o ucode -e 'let fs = require("fs"), o = getenv("XO"), ex = 0;
function u(f) { let D = null; try { D = json(fs.readfile(f) ?? ""); } catch (e) {}
	if (type(D) != "object" || D.result !== 0 || type(D.path) != "string" || substr(D.path, 0, 1) != "/" || type(D.hosts?.[0]) != "string" || !match(D.hosts[0], /^[A-Za-z0-9.-]+$/)) return "";
	if (type(D.expires) == "int" && (!ex || D.expires < ex)) ex = D.expires;
	return "https://" + D.hosts[0] + D.path; }
let a = u(o + ".a"), b = u(o + ".b"); if (!length(a)) exit(1);
printf("%J\n", { url: a, hls: b, exp: ex });' 2>/dev/null) || x_rerr fail
x_log; x_res "$r"
}
c_photo() {
x_req "$1"
[ -n "$XP" ] || x_rerr path
x_iscrypt "$J_id" "$XP" && x_rerr bk
if [ "$XS" != pcloud ] || [ -n "$J_cm" ] || x_cs "$XP"; then x_cloc; x_log; x_res "{\"url\":\"$(x_e "$XTU")\",\"exp\":$XTX,\"local\":true}"; exit 0; fi
o=$XD/ph.$$; trap 'rm -f "$XRO" "$o".*' EXIT
x_pc "$J_id" getfilelink 10 "path=/$XP" timeformat=timestamp > "$o.a" </dev/null
x_pcokf "$o.a" || x_rerr "$XC"
r=$(XO=$o ucode -e 'let D = null; try { D = json(require("fs").readfile(getenv("XO") + ".a") ?? ""); } catch (e) {}
if (type(D) != "object" || D.result !== 0 || type(D.path) != "string" || substr(D.path, 0, 1) != "/" || type(D.hosts?.[0]) != "string" || !match(D.hosts[0], /^[A-Za-z0-9.-]+$/)) exit(1);
printf("%J\n", { url: "https://" + D.hosts[0] + D.path, exp: type(D.expires) == "int" ? D.expires : 0 });' 2>/dev/null) || x_rerr fail
x_log; x_res "$r"
}

XPH=$XD/phs
XMIT='Gennaio Febbraio Marzo Aprile Maggio Giugno Luglio Agosto Settembre Ottobre Novembre Dicembre'
XMEN='January February March April May June July August September October November December'
XBUC=${WF_NASBKUC:-$XW/nasbk.uc}
X_PHD='print(loadfile(getenv("XB"))().phdate(getenv("XF"), getenv("XN")));'
x_phown() {
if [ -n "$XAO" ] && [ "$XAO" != admin ]; then printf '%s\n' "$XAO"; return 0; fi
echo admin
XN=$XE/nas.json ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XN")) ?? "{}"); } catch (e) {} for (let u, x in (type(N?.users) == "object" ? N.users : {})) if (type(x) == "object" && !x.cam && match(u, /^[A-Za-z0-9._-]{1,64}$/)) print(u, "\n");' 2>/dev/null
}
x_phlg() {
l_=$(XF=$XE/nasx.json XO=$1 ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} let l = N?.photo?.lang?.[getenv("XO")]; if (l == "it" || l == "en") print(l);' 2>/dev/null)
[ -n "$l_" ] || { x_en && l_=en || l_=it; }
printf '%s' "$l_"
}
x_phlgput() {
XKL=/tmp/wf-nas/cmig.lock; n_=0; mkdir -p /tmp/wf-nas
until mkdir "$XKL" 2>/dev/null; do
p_=$(cat "$XKL/pid" 2>/dev/null)
if { [ -n "$p_" ] && ! x_alive "$p_"; } || [ $(( $(date +%s) - $(date -r "$XKL" +%s 2>/dev/null || echo 0) )) -gt 30 ]; then rm -rf "$XKL"; continue; fi
n_=$((n_ + 1)); [ $n_ -gt 2 ] && return 1; sleep 1
done
echo $$ > "$XKL/pid"
XF=$XE/nasx.json XO=$1 XL=$2 XP=$$ ucode -e 'let fs = require("fs"), f = getenv("XF"), o = getenv("XO"), N = {}; try { N = json(fs.readfile(f) ?? "{}") ?? {}; } catch (e) { exit(1); }
if (type(N) != "object") exit(1); if (type(N.photo) != "object") N.photo = {}; if (type(N.photo.lang) != "object") N.photo.lang = {};
let l = N.photo.lang[o]; if (l == "it" || l == "en") exit(0);
N.photo.lang[o] = getenv("XL") == "en" ? "en" : "it"; N.saved = time(); let t = f + ".c" + getenv("XP"); fs.writefile(t, sprintf("%J\n", N)); fs.rename(t, f);' 2>/dev/null
[ "$(cat "$XKL/pid" 2>/dev/null)" = $$ ] && rm -rf "$XKL"
true
}
x_phin() {
for o_ in $(x_phown); do b_=$(wf_udir "$o_" phones 2>/dev/null) && [ -n "$b_" ] || continue
case "$1/" in "$b_"/*) return 0 ;; esac
[ "$1" = "$(wf_udir "$o_" media photo 2>/dev/null)" ] && return 0
tc_=$(wf_udir "$o_" tocat 2>/dev/null) && [ -n "$tc_" ] && case "$1/" in "$tc_"/*) return 0 ;; esac
done
return 1
}
x_phbg() {
mkdir -p "$XPH"; t_=$XPH/$J_id.ls
[ -f "$t_" ] && [ $(( $(date +%s) - $(date -r "$t_" +%s 2>/dev/null || echo 0) )) -lt 120 ] && return 0
: > "$t_"; ( sh "$0" phsort "$J_id" ) </dev/null >/dev/null 2>&1 &
}
x_phsame() { XA=$1 XS=$2 ucode -e 'let o = null, a = null; try { o = json(require("fs").stdin.read("all")); a = json(getenv("XA")); } catch (e) {}
let ok = false; if (type(o) == "object" && o.Size == +getenv("XS") && type(a) == "object" && type(o.Hashes) == "object") for (let k, v in a) if (length(v) && o.Hashes[k] == v) ok = true;
exit(ok ? 0 : 1);' 2>/dev/null; }
x_phmv1() {
R_=$1; rel=$2; n_=${rel##*/}; D_=${6:-$1}
x_rcl cat --count 262144 "$R_/$rel" </dev/null > "$XPH/h.$$" 2>/dev/null
ym=$(XF=$XPH/h.$$ XN=$n_ XB=$XBUC ucode -e "$X_PHD" 2>/dev/null); rm -f "$XPH/h.$$"
[ -n "$ym" ] || ym=$(printf '%s' "$4" | tr '-' ' ')
y_=${ym% *}; m_=${ym#* }; m_=${m_#0}
case "$y_.$m_" in [12][0-9][0-9][0-9].[1-9]|[12][0-9][0-9][0-9].1[0-2]) ;; *) return 1 ;; esac
e_=$(printf '%s' "${n_##*.}" | tr 'A-Z' 'a-z'); k_=$XKF
[ "$e_" != "$n_" ] && printf ' %s ' "$XVID" | grep -q " $e_ " && k_=$XKV
set -- $XMN; shift $((m_ - 1)); d_="$y_/$(printf '%02d' "$m_") $1/$k_"
ub=$n_; ux=; case "$ub" in ?*.*) ux=.${ub##*.}; ub=${ub%.*} ;; esac
f_=$n_; i_=2
while :; do
st_=$(x_rcl lsjson --stat --hash "$D_/$d_/$f_" </dev/null 2>/dev/null); r_=$?
[ $r_ = 3 ] && break
[ $r_ = 0 ] && [ -n "$st_" ] || return 1
if printf '%s' "$st_" | x_phsame "$XHS" "$XSZ"; then x_rcl deletefile "$R_/$rel" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" && { XPHMV=1; XPHSV=1; }; return; fi
[ $i_ -ge 100 ] && return 1
f_="$ub ($i_)$ux"; i_=$((i_ + 1))
done
x_rcl moveto "$R_/$rel" "$D_/$d_/$f_" --ignore-existing --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" || return 1
XPHMV=1; XPHSV=1
d_=$rel; while case "$d_" in */*) d_=${d_%/*} ;; *) false ;; esac; do x_phrmd "$R_/$d_" || break; done
true
}
x_phrmd() {
x_rcl rmdir "$1" </dev/null >/dev/null 2>&1 && return 0
x_rcl lsf --max-depth 1 "$1" </dev/null > "$XPH/rm.$$" 2>/dev/null && [ -s "$XPH/rm.$$" ] || { rm -f "$XPH/rm.$$"; return 1; }
while IFS= read -r e_; do
case "$e_" in
.DS_Store) ;;
._?*) ! grep -qxF -e "${e_#._}" "$XPH/rm.$$" || { rm -f "$XPH/rm.$$"; return 1; } ;;
*) rm -f "$XPH/rm.$$"; return 1 ;;
esac
done < "$XPH/rm.$$"
while IFS= read -r e_; do x_rcl deletefile "$1/$e_" --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG"; done < "$XPH/rm.$$"
rm -f "$XPH/rm.$$"
x_rcl rmdir "$1" </dev/null >/dev/null 2>&1
}
x_phrme() {
x_rcl lsf -R --dirs-only --filter '- .*' --filter '- .*/**' "$1" </dev/null > "$XPH/de.$$" 2>/dev/null || { rm -f "$XPH/de.$$"; return 0; }
mo_=$(printf '%s' "$XMN" | tr ' ' '|')
if [ "$2" = cat ]; then cp "$XPH/de.$$" "$XPH/de.$$.b"; else grep -vE '^[0-9]{4}/[0-9]{2}/' "$XPH/de.$$" > "$XPH/de.$$.b"; fi
grep -vE "^[0-9]{4}/(([0-9]{2} )?($mo_)/(($XKF|$XKV)/)?)?\$" "$XPH/de.$$.b" | awk -F/ '{ print NF "\t" $0 }' | sort -rn | cut -f2- > "$XPH/de.$$"
while IFS= read -r e_; do [ -n "$e_" ] && x_phrmd "$1/${e_%/}"; done < "$XPH/de.$$"
rm -f "$XPH/de.$$" "$XPH/de.$$.b"
}
x_phside() {
R0=$1; S_=$XPH/$J_id.$(printf '%s' "$R0" | md5sum | cut -c1-16); RD_=; LR_=-R; XPHSV=
if [ "$2" = en ]; then XMN=$XMEN; XKF=Photos; XKV=Videos; else XMN=$XMIT; XKF=Foto; XKV=Video; fi
if [ -n "$3" ]; then
RD_=$R0/$3; LR_=--ignore-case
{ echo '- .*'; for e_ in $XIMG $XVID; do echo "+ /*.$e_"; done; echo '- **'; } > "$XPH/f.$$"
else
mn_=$(i_=0; for n_ in $XMN; do i_=$((i_ + 1)); printf '%02d %s,' "$i_" "$n_"; done)
{ echo '- .*'; echo '- .*/**'
printf '%s\n' '- *.[tT][mM][pP]' '- *.[pP][aA][rR][tT]' '- *.[pP][aA][rR][tT][iI][aA][lL]' '- *.[cC][rR][dD][oO][wW][nN][lL][oO][aA][dD]' '- *.[dD][oO][wW][nN][lL][oO][aA][dD]' '- *~'
[ "$4" = cat ] || echo '- /[0-9][0-9][0-9][0-9]/[0-9][0-9]/**'
echo "- /[0-9][0-9][0-9][0-9]/{${mn_%,}}/{$XKF,$XKV}/*"
echo "- /[0-9][0-9][0-9][0-9]/{$(printf '%s' "$XMN" | tr ' ' ',')}/{$XKF,$XKV}/*"
if [ "$4" = cat ]; then for e_ in $XIMG $XVID; do echo "+ *.$e_"; done; echo '- **'; fi; } > "$XPH/f.$$"
fi
x_rcl lsjson "$LR_" ${4:+--ignore-case} --files-only --hash --filter-from "$XPH/f.$$" "$R0" </dev/null > "$XPH/l.$$" 2>/dev/null; rc_=$?
rm -f "$XPH/f.$$"
[ $rc_ = 3 ] && { rm -f "$XPH/l.$$" "$S_"; return 0; }
[ $rc_ = 0 ] || { rm -f "$XPH/l.$$"; return 1; }
XF=$XPH/l.$$ ucode -e 'let L = []; try { L = json(require("fs").readfile(getenv("XF")) ?? "[]"); } catch (e) {} let n = 0, now = time();
for (let x in (type(L) == "array" ? L : [])) { if (type(x) != "object" || x.IsDir || type(x.Path) != "string" || match(x.Path, /[\t\n\r]/)) continue;
	if (++n > 2000) break; let t = "" + (x.ModTime ?? ""), ym = substr(t, 0, 7), ok = 1;
	let m = match(t, /^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})[.0-9]*(Z|([-+])([0-9]{2}):([0-9]{2}))$/);
	if (m) { let e = timegm({ year: +m[1], mon: +m[2], mday: +m[3], hour: +m[4], min: +m[5], sec: +m[6] }) - (m[8] ? (m[8] == "-" ? -1 : 1) * (+m[9] * 3600 + +m[10] * 60) : 0);
		if (type(e) == "int" && e > 0) { let l = localtime(e); ym = sprintf("%04d-%02d", l.year, l.mon); ok = now - e >= 120 ? 1 : 0; } }
	print(x.Path, "\t", int(x.Size ?? -1), "\t", t, "\t", ym, "\t", sprintf("%J", type(x.Hashes) == "object" ? x.Hashes : {}), "\t", ok, "\n"); }' > "$XPH/c.$$" 2>/dev/null
rm -f "$XPH/l.$$"; pe_=0; tb_=$(printf '\t')
while IFS="$tb_" read -r p_ s_ t_ ym_ h_ c_; do
[ -n "$p_" ] || continue
if [ "$c_" = 1 ] && grep -qxF "$p_$tb_$s_$tb_$t_" "$S_" 2>/dev/null; then
XHS=$h_ XSZ=$s_; x_phmv1 "$R0" "$p_" "$s_" "$ym_" "$h_" ${RD_:+"$RD_"} || pe_=1
else pe_=10; fi
done < "$XPH/c.$$"
cut -f1-3 "$XPH/c.$$" > "$S_"; rm -f "$XPH/c.$$"
[ -n "$XPHSV" ] && [ -z "$3" ] && x_phrme "$R0" "$4"
[ "$pe_" = 1 ] && return 1
return $pe_
}
x_phrdir() {
x_rcl lsf --max-depth 1 "$2" </dev/null >/dev/null 2>&1; rz_=$?
[ $rz_ = 3 ] && { x_r moveto "$1" "$2"; return; }
[ $rz_ = 0 ] || return 1
x_rcl lsf -R --files-only "$1" </dev/null > "$XPH/ra.$$" 2>/dev/null || { rm -f "$XPH/ra.$$"; return 1; }
x_rcl lsf -R --files-only "$2" </dev/null > "$XPH/rb.$$" 2>/dev/null || { rm -f "$XPH/ra.$$" "$XPH/rb.$$"; return 1; }
: > "$XPH/rg.$$"; : > "$XPH/rx.$$"; rt_=$(printf '\t')
while IFS= read -r rf_; do
[ -n "$rf_" ] || continue
if grep -qxF -e "$rf_" "$XPH/rb.$$"; then
rp_=; case "$rf_" in */*) rp_=${rf_%/*}/ ;; esac
ru_=${rf_##*/}; rv_=; case "$ru_" in ?*.*) rv_=.${ru_##*.}; ru_=${ru_%.*} ;; esac
ri_=2; while grep -qxF -e "$rp_$ru_ ($ri_)$rv_" "$XPH/rb.$$" && [ $ri_ -lt 10000 ]; do ri_=$((ri_ + 1)); done
printf '%s\n' "$rp_$ru_ ($ri_)$rv_" >> "$XPH/rb.$$"; printf '%s\t%s\n' "$rf_" "$rp_$ru_ ($ri_)$rv_" >> "$XPH/rx.$$"
else printf '%s\n' "$rf_" >> "$XPH/rg.$$"; printf '%s\n' "$rf_" >> "$XPH/rb.$$"; fi
done < "$XPH/ra.$$"
rz_=0
[ -s "$XPH/rg.$$" ] && { x_r move "$1" "$2" --files-from-raw "$XPH/rg.$$" || rz_=1; }
[ $rz_ = 0 ] && while IFS="$rt_" read -r rf_ rn_; do x_r moveto "$1/$rf_" "$2/$rn_" || { rz_=1; break; }; done < "$XPH/rx.$$"
rm -f "$XPH/ra.$$" "$XPH/rb.$$" "$XPH/rg.$$" "$XPH/rx.$$"
[ $rz_ = 0 ] || return 1
x_rcl rmdirs "$1" </dev/null >/dev/null 2>&1
true
}
x_phmes() {
mk_=$XPH/mes.$(printf '%s' "$1" | md5sum | cut -c1-16); [ -f "$mk_" ] && return 0
x_rcl lsf -R --dirs-only --max-depth 2 "$1" </dev/null > "$XPH/md.$$" 2>/dev/null; mz_=$?
[ $mz_ = 3 ] && { rm -f "$XPH/md.$$"; : > "$mk_"; return 0; }
[ $mz_ = 0 ] || { rm -f "$XPH/md.$$"; return 1; }
mz_=0
while IFS= read -r ml_; do
ml_=${ml_%/}; my_=${ml_%%/*}; mo_=${ml_#*/}
case "$my_" in [12][0-9][0-9][0-9]) ;; *) continue ;; esac
[ "$mo_" != "$ml_" ] && [ "${mo_#*/}" = "$mo_" ] || continue
mi_=0; mn_=
for mm_ in $XMIT $XMEN; do mi_=$((mi_ % 12 + 1)); [ "$mm_" = "$mo_" ] && { mn_=$(printf '%02d %s' "$mi_" "$mm_"); break; }; done
[ -n "$mn_" ] || continue
x_phrdir "$1/$my_/$mo_" "$1/$my_/$mn_" || mz_=1
done < "$XPH/md.$$"
rm -f "$XPH/md.$$"
[ $mz_ = 0 ] || return 1
: > "$mk_"
}
c_phsort() {
x_acct "$1" || exit 0; J_id=$1; mkdir -p "$XPH"
K_=$XPH/$1.lk; if ! mkdir "$K_" 2>/dev/null; then x_alive "$(cat "$K_/pid" 2>/dev/null)" && exit 0; rm -rf "$K_"; mkdir "$K_" 2>/dev/null || exit 0; fi
echo $$ > "$K_/pid"; LOG=$XD/log/phsort-$1; : > "$LOG"
trap 'rm -rf "$K_"; rm -f "$XPH"/*.$$' EXIT
command -v rclone >/dev/null 2>&1 || exit 0
x_rdconf "$1" || exit 0
if cl_mem rclonepush && [ "$CL_GO" -ge 32 ]; then export GOMEMLIMIT=${CL_GO}MiB; elif [ "$(cat $XD/tier 2>/dev/null)" = A ]; then export GOGC=20; fi
XVID=$(x_tys | sed -n 's/^video //p'); XIMG=$(x_tys | sed -n 's/^photo //p')
g_=0
while [ $g_ -lt 3 ]; do
g_=$((g_ + 1)); again=
cl_check phsort >/dev/null || exit 0
for o_ in $(x_phown); do
b_=$(wf_udir "$o_" phones 2>/dev/null) && [ -n "$b_" ] || continue
lg_=$(x_phlg "$o_"); XPHMV=
tc_=$(wf_udir "$o_" tocat 2>/dev/null)
if [ -n "$tc_" ] && x_cmig "$tc_"; then
for sd_ in $(x_both "$tc_" | tr ' ' '\001'); do
sd_=$(printf '%s' "$sd_" | tr '\001' ' ')
x_rcl lsf --dirs-only --max-depth 1 "$sd_" </dev/null > "$XPH/cd.$$" 2>/dev/null || continue
while IFS= read -r cn_; do
cn_=${cn_%/}; case "$cn_" in ''|.*) continue ;; esac
x_phside "$sd_/$cn_" "$lg_" '' cat </dev/null; [ $? = 10 ] && again=1
done < "$XPH/cd.$$"
rm -f "$XPH/cd.$$"
done
fi
x_cmig "$b_" || { [ -n "$XPHMV" ] && x_phlgput "$o_" "$lg_"; continue; }
for sd_ in $(x_both "$b_" | tr ' ' '\001'); do
sd_=$(printf '%s' "$sd_" | tr '\001' ' ')
x_phmes "$sd_" || continue
x_phside "$sd_" "$lg_"; [ $? = 10 ] && again=1
done
m_=$(wf_udir "$o_" media photo 2>/dev/null) && [ -n "$m_" ] && [ "${b_%/*}" = "$m_" ] && x_cmig "$m_" &&
for sd_ in $(x_both "$m_" | tr ' ' '\001'); do
sd_=$(printf '%s' "$sd_" | tr '\001' ' ')
x_phside "$sd_" "$lg_" "${b_##*/}"; [ $? = 10 ] && again=1
done
[ -n "$XPHMV" ] && x_phlgput "$o_" "$lg_"
done
x_gen "$1"
[ -n "$again" ] && [ $g_ -lt 3 ] || break
sleep "${WF_PHWAIT:-60}"
done
x_log
}
c_pubuse() {
[ -f "$XLJ" ] || exit 0
LOG=$XD/log/pubuse; : > "$LOG"; XRO=; now=$(date +%s); XLS=$XD/pu.$$; XLC=$XD/puc.$$
trap 'rm -f "$XLS" "$XLC" "$XLS".* "$LOG"' EXIT
XL=$XLJ XN=$now ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XL")) ?? "{}"); } catch (e) {} for (let l in (N.items ?? [])) if (type(l) == "object" && l.kind == "pub" && +(l.expire ?? 0) > +getenv("XN") && match(l.id ?? "", /^a[0-9]{1,2}$/) && match(l.req ?? "", /^[A-Za-z0-9_-]{1,40}$/) && match("" + (l.pid ?? ""), /^[0-9]{1,20}$/))
		print(l.req, "\t", l.id, "\t", l.pid, "\t", match("" + (l.upid ?? ""), /^[0-9]{1,20}$/) ? l.upid : "-", "\t", match(l.own ?? "", /^[A-Za-z0-9._-]{1,64}$/) ? l.own : "admin", "\t", int(l.use ?? 0), "\n");' > "$XLS" 2>/dev/null
[ -s "$XLS" ] || exit 0
case "$(cl_check pubuse '' 2>/dev/null)" in ok*) ;; *) exit 0 ;; esac
: > "$XLC"
while IFS='	' read -r rq a p u ow us; do
x_acct "$a" && [ "$XS" = pcloud ] || continue
if [ ! -f "$XLS.$a.p" ]; then
x_pc "$a" listpublinks 30 > "$XLS.$a.p" </dev/null; x_pcokf "$XLS.$a.p" || { echo '{}' > "$XLS.$a.p"; continue; }
x_pc "$a" listuploadlinks 30 > "$XLS.$a.u" </dev/null; x_pcokf "$XLS.$a.u" || echo '{}' > "$XLS.$a.u"
fi
n=$(XP_=$XLS.$a.p XU_=$XLS.$a.u XI=$p XJ=$u ucode -e 'let fs = require("fs"), P = {}, U = {}, n = 0; try { P = json(fs.readfile(getenv("XP_")) ?? "{}"); } catch (e) {} try { U = json(fs.readfile(getenv("XU_")) ?? "{}"); } catch (e) {}
			for (let l in (type(P?.publinks) == "array" ? P.publinks : [])) if ("" + l?.linkid == getenv("XI")) n += int(l.downloads ?? 0) + int(l.views ?? 0);
			for (let l in (type(U?.uploadlinks) == "array" ? U.uploadlinks : [])) if ("" + l?.uploadlinkid == getenv("XJ")) n += int(l.files ?? 0);
			print(n);' 2>/dev/null)
case "$n" in ''|*[!0-9]*) continue ;; esac
[ "$n" -gt "$us" ] || continue
printf '%s %s\n' "$rq" "$n" >> "$XLC"
[ -f $XW/event.sh ] || continue
if x_en; then m='🗄️ Home Cloud ¦ Your Invitation Was Used ¦ Public Folder'; else m='🗄️ Cloud Di Casa ¦ Il Tuo Invito È Stato Usato ¦ Cartella Pubblica'; fi
if [ "$ow" = admin ]; then sh $XW/event.sh cron nas_invite_used cloud "$m" </dev/null >/dev/null 2>&1; continue; fi
WF_SOLO=1 sh $XW/event.sh cron nas_invite_used cloud "$m" "$ow" </dev/null >/dev/null 2>&1
v_=$(wf_udir "$ow" root 2>/dev/null); v_=${v_##*/}; [ -n "$v_" ] || v_=$ow
if x_en; then m="🗄️ Home Cloud ¦ $v_: an invitation used"; else m="🗄️ Cloud Di Casa ¦ $v_: un invito usato"; fi
sh $XW/event.sh cron nas_invite_used cloud "$m" </dev/null >/dev/null 2>&1
done < "$XLS"
[ -s "$XLC" ] || exit 0
x_lkget
XL=$XLJ XC=$XLC ucode -e 'let fs = require("fs"), f = getenv("XL"), N = {}, C = {}; try { N = json(fs.readfile(f) ?? "{}"); } catch (e) {} if (type(N) != "object" || type(N.items) != "array") exit(0);
		for (let l in split(fs.readfile(getenv("XC")) ?? "", "\n")) { let c = split(l, " "); if (length(c) == 2) C[c[0]] = int(c[1]); }
		for (let l in N.items) if (type(l) == "object" && C[l.req] != null) l.use = C[l.req];
		let t = f + ".t"; fs.writefile(t, sprintf("%J\n", N)); fs.rename(t, f);' 2>/dev/null
chmod 600 "$XLJ" 2>/dev/null; x_lkput
}
c_phtick() {
x_citick
sh "$0" pubuse </dev/null >/dev/null 2>&1
XA_=$(XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} for (let a in (N.accounts ?? [])) if (match(a?.id ?? "", /^a[0-9]{1,2}$/)) print(a.id, "\n");' 2>/dev/null)
for a_ in $XA_; do sh "$0" cbase "$a_" </dev/null >/dev/null 2>&1; sh "$0" phsort "$a_" </dev/null >/dev/null 2>&1; done
}
x_phacc() {
XA_=$(XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} for (let a in (N.accounts ?? [])) if (a?.svc == "pcloud" && match(a?.id ?? "", /^a[0-9]{1,2}$/)) print(a.id, "\n");' 2>/dev/null)
for a_ in $XA_; do
x_acct "$a_" && [ "$XS" = pcloud ] || continue
J_id=$a_
for o_ in $(x_phown); do
b_=$(wf_udir "$o_" phones 2>/dev/null) && [ -n "$b_" ] || continue
x_has "$(x_rp "$b_" r)" && { echo "$a_"; break; }
m_=$(wf_udir "$o_" media photo 2>/dev/null) && [ -n "$m_" ] && x_has "$(x_rp "$m_" r)" && { echo "$a_"; break; }		done
done
}
c_phpoll() {
x_acct "$1" && [ "$XS" = pcloud ] || exit 0
mkdir -p "$XPH"; LOG=$XD/log/phpoll-$1; XPT=900; f_=$XPH/$1.diff; d_=$(cat "$f_" 2>/dev/null); o_=$XPH/d.$$
trap 'rm -f "$o_" "$XB"' EXIT
while :; do
if [ -z "$d_" ]; then
x_pc "$1" diff 30 last=0 > "$o_" </dev/null
d_=$(XF=$o_ ucode -e 'let N = null; try { N = json(require("fs").readfile(getenv("XF")) ?? ""); } catch (e) {} if (N?.result === 0 && type(N.diffid) == "int") print(N.diffid);' 2>/dev/null)
[ -n "$d_" ] || { sleep 300; continue; }
echo "$d_" > "$f_"
fi
x_pc "$1" diff "$XPT" "diffid=$d_" block=1 limit=1000 > "$o_" </dev/null
r_=$(XF=$o_ ucode -e 'let N = null; try { N = json(require("fs").readfile(getenv("XF")) ?? ""); } catch (e) {}
if (type(N) != "object" || type(N.result) != "int") exit(0);
if (N.result != 0) { print("e ", N.result); exit(0); }
let n = 0; for (let e in (N.entries ?? [])) if (e?.event == "createfile" && !e?.metadata?.isfolder) n++;
print(type(N.diffid) == "int" ? N.diffid : "x", " ", n);' 2>/dev/null)
case "$r_" in
'') sleep 30 ;;
e\ *) d_=; sleep 300 ;;
x\ *) sleep 30 ;;
*) d_=${r_% *}; echo "$d_" > "$f_"
[ "${r_#* }" -gt 0 ] 2>/dev/null && { sleep "${WF_PHWAIT:-60}"; sh "$0" phsort "$1" </dev/null >/dev/null 2>&1; } ;;
esac
[ -n "$WF_PHONCE" ] && break
done
}
c_phlisten() {
mkdir -p "$XPH"; echo $$ > "$XPH/listen.pid"
export RCLONE_CONFIG=$XCF RCLONE_CACHE_DIR=$XD/rclone-cache
trap 'for p_ in "$XPH"/poll-*.pid; do [ -f "$p_" ] && cl_kill "$(cat "$p_")"; rm -f "$p_"; done; exit 0' TERM INT
n_=0
while :; do
if [ ! -f "$XPH/acc" ] || [ $(( $(date +%s) - $(date -r "$XPH/acc" +%s 2>/dev/null || echo 0) )) -ge 3600 ]; then
x_phacc > "$XPH/acc.t" 2>/dev/null; mv -f "$XPH/acc.t" "$XPH/acc"
fi
ok_=; cl_check phsort >/dev/null && ok_=1
for p_ in "$XPH"/poll-*.pid; do
[ -f "$p_" ] || continue; a_=${p_##*/poll-}; a_=${a_%.pid}
{ [ -n "$ok_" ] && grep -qxF "$a_" "$XPH/acc"; } && continue
cl_kill "$(cat "$p_")"; rm -f "$p_"
done
if [ -n "$ok_" ]; then
while IFS= read -r a_; do
[ -n "$a_" ] || continue
x_alive "$(cat "$XPH/poll-$a_.pid" 2>/dev/null)" && continue
sh "$0" phpoll "$a_" </dev/null >/dev/null 2>&1 &
echo $! > "$XPH/poll-$a_.pid"
done < "$XPH/acc"
fi
n_=$((n_ + 1)); [ -n "$WF_PHONCE" ] && [ $n_ -ge "$WF_PHONCE" ] && break
sleep "${WF_PHLOOP:-60}" & wait $!
done
}

XIX=$XD/idx; XSP=$XD/space
x_cihash() {
case "$1" in
drive|koofr|jottacloud|s3) echo md5 ;;
box|b2|pcloud) echo sha1 ;;
onedrive) echo quickxor ;;
dropbox) echo dropbox ;;
esac
}
x_ciram() {
m_=$(awk '/^MemTotal:/ { print $2; exit }' $XR/proc/meminfo 2>/dev/null); m_=${m_:-0}
if [ "$m_" -le 163840 ]; then echo 0; elif [ "$m_" -le 307200 ]; then echo 20000; elif [ "$m_" -le 614400 ]; then echo 50000; else echo 100000; fi
}
x_cimeta() { printf '%s\n' "$2" > "$XIX/$1.json.$$" && mv -f "$XIX/$1.json.$$" "$XIX/$1.json"; }
x_cione() {
A=$1; J_id=$A; XRO=
umask 077
x_acct "$A" || return 1
now_=$(date +%s)
cl_check phsort >/dev/null 2>&1 || { x_cimeta "$A" "{\"at\":$now_,\"off\":\"line\"}"; return 0; }
x_rdconf "$A" || return 0
IW=ram; cap_=$(x_ciram); D_=
mi_=$(x_main)
if [ -n "$mi_" ] && ! x_mainp "$mi_" && x_disk "$mi_" rw && mkdir -p "$XM/.wf-index" 2>/dev/null && [ -w "$XM/.wf-index" ]; then
IW=disk; cap_=150000; [ "$(x_ciram)" -le 20000 ] && cap_=50000; D_=$XM/.wf-index
fi
IE=; ce_=0; [ "$IW" = disk ] && { IE=$XIX/$A.e.tsv; ce_=$(x_ciram); }
if [ "$IW" = ram ]; then
[ "$cap_" -gt 0 ] || { rm -f "$XIX/$A.tsv"; x_cimeta "$A" "{\"at\":$now_,\"off\":\"ram\"}"; return 0; }
D_=$XIX
fi
IF=$D_/cloud-$A.tsv; [ "$IW" = ram ] && IF=$XIX/$A.tsv
TQ=$D_/.ci-$A.$$; LOG=$XD/log/ci-$A; : > "$LOG"
trap 'rm -f "$TQ".* "$XRO"' EXIT
hs_=$(x_cihash "$XS"); fm_=pst; [ -n "$hs_" ] && fm_=psth
XTM=; command -v timeout >/dev/null 2>&1 && XTM=${WF_CIDXTM:-1800}
o=$TQ
: > "$TQ.s"; : > "$TQ.x"
if [ -z "$XAO" ] || [ "$XAO" = admin ]; then
for u_ in $(x_cusers); do
s_=$(wf_crsec "$A" "$u_" 2>/dev/null) && [ -n "$s_" ] && grep -qxF "[$s_]" "$XCF" 2>/dev/null || continue
r_=$(wf_udir "$u_" root 2>/dev/null) && [ -n "$r_" ] || continue
printf '%s\t%s\n' "$s_" "$r_" >> "$TQ.s"
x_rcl lsf "$RM:$r_" --max-depth 1 </dev/null 2>/dev/null | sed 's#/$##' | sed -n 1,500p > "$TQ.n"
set --; while IFS= read -r n_; do [ -n "$n_" ] && set -- "$@" "$n_"; done < "$TQ.n"
[ $# -gt 0 ] && x_rcl cryptdecode "$s_:" "$@" </dev/null 2>/dev/null | awk -F '\t' -v R="$r_" '$2 !~ /Failed to decrypt/ { sub(/ +$/, "", $1); sub(/\/$/, "", $1); print R "/" $1 }' >> "$TQ.x"
done
fi
od_=$(date -u -d "@$((now_ - 63072000))" '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
{ x_lst lsf "$RM:" -R --format "$fm_" ${hs_:+--hash "$hs_"} --separator '	' --log-file "$LOG" --log-level ERROR </dev/null 2>>"$LOG" | sed 's/^/c	/'
while IFS='	' read -r s_ r_; do
[ -n "$s_" ] || continue
x_lst lsf "$s_:" -R --format pst --separator '	' </dev/null 2>/dev/null | sed "s#^#e	$(printf '%s' "$r_" | sed 's/[#&\\]/\\&/g')/#"
done < "$TQ.s"
} | XC=$cap_ XCE=$ce_ XE=${IE:+$TQ.e} XO=$od_ XS=$XS XI=$TQ.i XB=$TQ.b XL=$TQ.o XP=$TQ.p XDF=$TQ.d XMF=$TQ.m XX="$(cat "$TQ.x")" awk '
BEGIN { FS = OFS = "\t"; cap = ENVIRON["XC"] + 0; old = ENVIRON["XO"]; ne = split(ENVIRON["XX"], EX, "\n"); n = 0; nd = 0; nb = 0; no = 0; np = 0; part = 0; files = 0; bytes = 0 }
{
	f = $1; p = $2; z = $3 + 0; t = $4; h = $5
	if (p == "" || ("/" p) ~ /\/\.wf/) next
	if (ENVIRON["XS"] == "pcloud" && index(p, "Crypto Folder/") == 1) next
	if (f == "c") for (i = 1; i <= ne; i++) if (EX[i] != "" && (p == EX[i] || index(p, EX[i] "/") == 1)) next
	d = substr(p, length(p)) == "/"
	if (f == "e" && ENVIRON["XE"] != "") { if (ne_ < ENVIRON["XCE"] + 0) { print p, (d ? 0 : z), t, f > ENVIRON["XE"]; ne_++ } else part = 1 }
	else if (n < cap) { print p, (d ? 0 : z), t, f > ENVIRON["XI"]; n++ } else part = 1
	if (d) next
	files++; bytes += z
	m = split(p, P, "/"); q = ""
	for (i = 1; i < m && i <= 3; i++) { q = (i == 1 ? P[i] : q "/" P[i]); if (!(q in S)) { if (nd >= 5000) break; nd++ } S[q] += z; N[q]++ }
	if (z >= 1048576) {
		if (nb < cap) { print z, p, t > ENVIRON["XB"]; nb++ }
		if (old != "" && t < old && no < cap) { print z, p, t > ENVIRON["XL"]; no++ }
		k = (h != "" && f == "c") ? "h:" h : "n:" z ":" tolower(P[m])
		if (np < cap) { print k, z, p, t, (h != "" && f == "c") ? 1 : 0 > ENVIRON["XP"]; np++ }
	}
}
END { for (q in S) print q, S[q], N[q] > ENVIRON["XDF"]; print files, bytes, part, n > ENVIRON["XMF"] }' 2>/dev/null
tm_=0; [ -f "$o.t" ] && tm_=1
x_log
if [ ! -s "$TQ.m" ] || { [ ! -s "$TQ.i" ] && [ -s "$LOG" ]; }; then
x_cimeta "$A" "{\"at\":$now_,\"off\":\"fail\",\"code\":\"$(x_tr "$LOG")\"}"; rm -f "$TQ".*; return 0
fi
: >> "$TQ.i"; : >> "$TQ.b"; : >> "$TQ.o"; : >> "$TQ.p"; : >> "$TQ.d"
read -r fi_ by_ pa_ n_ < "$TQ.m"; [ "$tm_" = 1 ] && pa_=1
sort -t '	' -k1,1nr "$TQ.b" 2>/dev/null | head -n 50 > "$TQ.b2"
sort -t '	' -k1,1nr "$TQ.o" 2>/dev/null | head -n 50 > "$TQ.o2"
sort -t '	' -k1,1 -k4,4 "$TQ.p" 2>/dev/null | awk -F '\t' 'BEGIN { g = 0 } $1 != k { if (c > 1 && g < 2000) { printf "%s", b; g++ } k = $1; c = 0; b = "" } { c++; b = b $0 "\n" } END { if (c > 1 && g < 2000) printf "%s", b }' > "$TQ.p2"
mv -f "$TQ.i" "$IF"
[ "$IW" = disk ] && rm -f "$XIX/$A.tsv"
if [ -n "$IE" ] && [ -s "$TQ.e" ]; then mv -f "$TQ.e" "$IE"; else rm -f "$XIX/$A.e.tsv"; IE=; fi
mkdir -p "$XSP"
XA=$A XT=$now_ XD0=$TQ.d XB=$TQ.b2 XL=$TQ.o2 XP=$TQ.p2 XF=$fi_ XY=$by_ XPA=$pa_ ucode -e '
let fs = require("fs"), E = getenv, rows = (f) => filter(split(fs.readfile(f) ?? "", "\n"), (l) => length(l));
function it(c) { return { path: "/" + c[1], size: int(c[0]), mtime: c[2] ?? "" }; }
let D = {};
for (let l in rows(E("XD0"))) { let c = split(l, "\t"); D["/" + c[0]] = [ int(c[1]), int(c[2]) ]; }
let G = {}, sure = true;
for (let l in rows(E("XP"))) { let c = split(l, "\t"); if (!G[c[0]]) G[c[0]] = []; push(G[c[0]], { path: "/" + c[2], size: int(c[1]), mtime: c[3] ?? "", s: c[4] == "1" }); }
let L = [], dn = 0, db = 0;
for (let k, B in G) {
	let cp = slice(B, 1, 51);
	if (!B[0].s) sure = false;
	push(L, { keep: { path: B[0].path, size: B[0].size, mtime: B[0].mtime }, copies: map(cp, (x) => ({ path: x.path, size: x.size, mtime: x.mtime })), sure: B[0].s });
	dn += length(cp); db += length(cp) * B[0].size;
}
L = slice(sort(L, (a, b) => b.keep.size * length(b.copies) - a.keep.size * length(a.copies)), 0, 100);
let R = { at: int(E("XT")), id: E("XA"), files: int(E("XF")), bytes: int(E("XY")), dirs: D,
	big: map(rows(E("XB")), (l) => it(split(l, "\t"))), old: map(rows(E("XL")), (l) => it(split(l, "\t"))),
	dup: { n: dn, groups: length(L), bytes: db, sure: sure, list: L }, partial: E("XPA") == "1" };
printf("%J\n", R);' > "$XSP/$A.json.$$" 2>/dev/null && [ -s "$XSP/$A.json.$$" ] && mv -f "$XSP/$A.json.$$" "$XSP/$A.json"
rm -f "$XSP/$A.json.$$" "$TQ".*
fe_=; [ -n "$IE" ] && fe_="\"fe\":\"$(x_e "$IE")\","
x_cimeta "$A" "{\"at\":$now_,\"f\":\"$(x_e "$IF")\",$fe_\"n\":${n_:-0},\"partial\":$([ "$pa_" = 1 ] && echo true || echo false),\"where\":\"$IW\",\"svc\":\"$XS\"}"
rm -f "$XRO"; trap - EXIT
}
c_cidx() {
mkdir -p "$XIX"; chmod 700 "$XIX"
K=$XIX/run.lk
if ! mkdir "$K" 2>/dev/null; then x_alive "$(cat "$K/pid" 2>/dev/null)" && return 0; rm -rf "$K"; mkdir "$K" 2>/dev/null || return 0; fi
echo $$ > "$K/pid"; trap 'rm -rf "$XIX/run.lk"' EXIT
command -v rclone >/dev/null 2>&1 || return 0
export RCLONE_CONFIG=$XCF RCLONE_CACHE_DIR=$XD/rclone-cache
[ "$(cat $XD/tier 2>/dev/null)" = A ] && export GOGC=20
if [ -n "$1" ]; then ( x_cione "$1" ); return 0; fi
for f_ in "$XIX"/a*.json; do
[ -f "$f_" ] || continue; a_=${f_##*/}; a_=${a_%.json}
grep -qx "\[wf$a_\]" "$XCF" 2>/dev/null && continue
rm -f "$f_" "$XIX/$a_.tsv" "$XIX/$a_.e.tsv" "$XSP/$a_.json"
mi_=$(x_main); [ -n "$mi_" ] && x_disk "$mi_" && rm -f "$XM/.wf-index/cloud-$a_.tsv"
done
for a_ in $(XF=$XCJ ucode -e 'let N = {}; try { N = json(require("fs").readfile(getenv("XF")) ?? "{}"); } catch (e) {} for (let a in (N.accounts ?? [])) if (match(a?.id ?? "", /^a[0-9]{1,2}$/)) print(a.id, "\n");' 2>/dev/null); do
[ -z "$WF_CIDXNOW" ] && [ "$(date +%H%M)" -ge 630 ] && [ "$(date +%H%M)" -lt 1200 ] && break
( x_cione "$a_" )
done
date +%Y%m%d > "$XIX/night.day"
}
x_citick() {
h_=$(date +%H%M)
[ "$h_" -ge 330 ] && [ "$h_" -lt 630 ] || return 0
[ "$(cat "$XIX/night.day" 2>/dev/null)" = "$(date +%Y%m%d)" ] && return 0
x_alive "$(cat "$XIX/run.lk/pid" 2>/dev/null)" && return 0
( sh "$0" cidx ) </dev/null >/dev/null 2>&1 &
}

case "$1" in
cidx) c_cidx "$2" ;;
phsort|phpoll|cbase) [ -n "$2" ] || exit 2; "c_$1" "$2" ;;
cbroot) [ -n "$3" ] || exit 2; c_cbroot "$2" "$3" ;;
phtick) c_phtick ;;
phlisten) c_phlisten ;;
about|ls|op|link|upreq|find|xfer|media|camup|thumbs|revs|revert|trash|restore|stream|photo) [ -n "$2" ] || exit 2; "c_$1" "$2" ;;
router) c_router "$2" ;;
rtget) [ -n "$2" ] || exit 2; c_rtget "$2" ;;
recv) c_recv ;;
unlink) [ -n "$2" ] || exit 2; c_unlink "$2" ;;
linkexp) c_linkexp ;;
pubuse) c_pubuse ;;
upnew) c_upnew ;;
wtnight) c_wtnight ;;
*) echo "uso: cloudx.sh about|ls|op|link|upreq|find|unlink|thumbs|revs|revert|trash|restore|stream|photo <req> · xfer|media|camup <job> · router [job] · rtget <job> · recv · linkexp · upnew · pubuse · phtick · phsort|phpoll|cbase <acct> · cbroot <acct> <own> · phlisten" >&2; exit 2 ;;
esac
