'use strict';
import { popen, readfile, writefile, unlink, stat, rename, mkdir, rmdir, lsdir } from 'fs';
import * as FS from 'fs';

const HIST = '/tmp/wf-health.hist', HISTE = '/etc/wrtfreedom/health.hist', ACC = '/tmp/wf-health.acc', ALS = '/tmp/wf-health.al';
const ALIVE = '/etc/wrtfreedom/health.alive', DOWNF = '/etc/wrtfreedom/health.down', BOOTS = '/etc/wrtfreedom/boots.json', BOOTT = '/tmp/wf-health.boot.json';
const SPACE = '/tmp/wf-space.json', CLEAN = '/tmp/wf-clean.json', W = '/usr/share/wrtfreedom', HERR = '/tmp/wf-health.err';
const TOK = 1735689600;
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
const lst = FS.lstat ?? stat;
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function upsec() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
function uo(sec, opt) {
let s = false;
for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == sec; continue; }
let m = s ? match(l, /^[[:blank:]]*option ([A-Za-z0-9_]+) '?([^']*)'?[[:blank:]]*$/) : null;
if (m && m[1] == opt) return m[2];
}
return '';
}
const EN = uo('ui', 'lang') == 'en';
function L(it, en) { return EN ? en : it; }
const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function lock(n, max) { return UCFG.lockdir('/tmp/wf-health.' + n + '.lock', max); }
let UB = null;
function ub(o, m, a) {
if (UB == null) { try { UB = require('ubus').connect() ?? false; } catch (e) { UB = false; } }
let r = UB ? UB.call(o, m, a ?? {}) : null;
if (r == null && UB === false) { try { r = json(sh('ubus call ' + o + ' ' + m + (a ? ' ' + q(sprintf('%J', a)) : '') + ' 2>/dev/null')); } catch (e) { r = null; } }
return r;
}
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' sys ' + q(txt) + ' >/dev/null 2>&1'); }
function fwrev() { return match(readfile('/etc/openwrt_release') ?? '', /DISTRIB_REVISION='?([^'\n]{1,80})'?/)?.[1] ?? ''; }

function histread() {
let R = [];
for (let l in split(readfile(HIST) ?? '', '\n')) {
let m = match(l, /^([0-9]{9,11}) (-|[0-9]{1,3}) (-|[0-9]{1,3}) (-|[0-9]{1,3})$/);
if (m) push(R, l);
}
return R;
}
function histadd(A) {
let now = time(), R = filter(histread(), (l) => { let t = +split(l, ' ')[0]; return t > now - 86400 - 300 && t <= now; });
let f = (v) => v == null || v < 0 ? '-' : '' + int(v);
push(R, A.b + ' ' + f(A.cpu) + ' ' + f(A.mem) + ' ' + f(A.temp));
if (length(R) > 288) R = slice(R, length(R) - 288);
writefile(HIST + '.t', join('\n', R) + '\n'); rename(HIST + '.t', HIST);
}

const RANK = { ok: 0, warn: 1, bad: 2 };
const HMIN = 2;
function altext(k, lvl, H) {
let tc = H.temp?.c, dp = H.disk?.pct, mp = H.mem?.pct, cp = H.cpu?.pct, s = '🩺 Router ¦ ';
if (lvl == 'ok') {
if (k == 'temp') return s + L('Temperatura tornata normale', 'Temperature back to normal') + (tc != null ? ' ¦ ' + tc + ' °C' : '');
if (k == 'disk') return s + L('Spazio di nuovo libero', 'Storage free again') + (dp != null ? ' ¦ ' + (100 - dp) + '% ' + L('libero', 'free') : '');
if (k == 'mem') return s + L('Memoria tornata normale', 'Memory back to normal') + (mp != null ? ' ¦ ' + mp + '% ' + L('usata', 'used') : '');
return s + L('Processore tornato tranquillo', 'Processor calm again') + (cp != null ? ' ¦ ' + cp + '%' : '');
}
if (k == 'temp') return s + (lvl == 'bad' ? L('Molto caldo', 'Very hot') : L('Caldo', 'Hot')) + ' ¦ ' + tc + ' °C';
if (k == 'disk') return s + (lvl == 'bad' ? L('Spazio pieno', 'Storage full') : L('Spazio quasi pieno', 'Storage almost full')) + ' ¦ ' + (100 - dp) + '% ' + L('libero', 'free');
if (k == 'mem') return s + L('Memoria quasi finita', 'Memory almost full') + ' ¦ ' + L('Da 2 minuti', 'For 2 minutes') + ' · ' + mp + '% ' + L('usata', 'used');
return s + L('Processore sotto sforzo', 'Processor under strain') + ' ¦ ' + L('Da 2 minuti', 'For 2 minutes') + ' · ' + cp + '%';
}
function hyst(k, lvl, prev, H) {
let p = prev ?? 'ok', T = H.th ?? {};
if (lvl == 'warn' && p == 'bad') {
if (k == 'temp' && H.temp?.c != null && H.temp.c > (T.tempbad ?? 85) - 3) return 'bad';
if (k == 'disk' && H.disk?.pct != null && H.disk.pct > (T.diskbad ?? 95) - 2) return 'bad';
return lvl;
}
if (lvl != 'ok' || p == 'ok') return lvl;
if (k == 'temp' && H.temp?.c != null && H.temp.c > (T.temp ?? 75) - 3) return prev;
if (k == 'disk' && H.disk?.pct != null && H.disk.pct > (T.disk ?? 85) - 2) return prev;
if (k == 'mem' && H.mem?.pct != null && H.mem.pct > (T.mem ?? 90) - 5) return prev;
if (k == 'cpu' && H.cpu?.pct != null && H.cpu.pct >= (T.cpu ?? 90) - 10) return prev;
return lvl;
}
function memcust() { return trim(readfile('/tmp/wf-custode-mem') ?? '') == '1'; }
function alerts(H, A) {
let S = rjs(ALS) ?? {}, al = H.al ?? {}, ch = false, mc = memcust();
let lv = { temp: H.temp?.lvl ?? 'ok', disk: H.disk?.lvl ?? 'ok',
mem: (A.mc ?? 0) >= HMIN ? 'warn' : 'ok', cpu: (A.cc ?? 0) >= HMIN ? 'warn' : 'ok' };
let val = { temp: H.temp?.c, disk: H.disk?.pct, mem: H.mem?.pct, cpu: H.cpu?.pct };
for (let k in ['temp', 'disk', 'mem', 'cpu']) {
if (k == 'mem' && mc) { if ((S.mem ?? 'ok') != 'ok') { S.mem = 'ok'; ch = true; } continue; }
if (val[k] == null) continue;
let prev = S[k] ?? 'ok', n = hyst(k, lv[k], prev, H);
if (n == prev) continue;
S[k] = n; ch = true;
if (al[k] && (RANK[n] > RANK[prev] || n == 'ok')) ev('health_' + k + (n == 'ok' ? '_ok' : ''), altext(k, n, H));
}
if (ch) wjs(ALS, S);
}

function tick() {
let lk = lock('tick', 120);
if (!lk) return;
let H = ub('wrtfreedom', 'health', { tick: true }), now = time();
if (type(H) == 'object' && !H.error) {
let b = now - now % 300, a0 = rjs(ACC) ?? {}, A = length(a0) ? a0 : null;
if (A && A.b != b) { if (A.b < b && A.b >= TOK) histadd(A); A = null; }
A = A ?? { b: b, mc: 0, cc: 0 };
let mx = (o, v) => v == null ? o : (o == null || v > o ? v : o);
A.cpu = mx(A.cpu, H.cpu?.pct); A.mem = mx(A.mem, H.mem?.pct); A.temp = mx(A.temp, H.temp?.c);
A.mc = H.mem?.pct == null ? (a0.mc ?? 0) : (H.mem.pct >= (H.th?.mem ?? 90) ? (a0.mc ?? 0) + 1 : 0);
A.cc = H.cpu?.pct == null ? (a0.cc ?? 0) : (H.cpu.pct >= (H.th?.cpu ?? 90) ? (a0.cc ?? 0) + 1 : 0);
wjs(ACC, A);
alerts(H, A);
unlink(HERR);
} else {
let n = +(readfile(HERR) ?? '0') + 1;
writefile(HERR, '' + n);
if (n == 10 && (uo('health', 'al_temp') != '0' || uo('health', 'al_disk') != '0')) ev('health_err', '⚠️ ' + L('Salute ¦ Non letta da 10 minuti ¦ Avvisi caldo e spazio fermi', 'Health ¦ Not read for 10 minutes ¦ Heat and space alerts off'));
}
let s = stat(ALIVE);
if (now >= TOK && (!s || now - s.mtime >= 21600)) { mkdir('/etc/wrtfreedom'); writefile(ALIVE + '.t', now + ' ' + fwrev() + '\n'); rename(ALIVE + '.t', ALIVE); }
rmdir(lk);
}

function fmatch(f, v, lo, hi) {
for (let p in split(f, ',')) {
let m = match(p, /^(\*|([0-9]{1,2})(-([0-9]{1,2}))?)(\/([0-9]{1,2}))?$/);
if (!m) continue;
let a = lo, b = hi, st = +(m[6] ?? 1) || 1;
if (m[1] != '*') { a = +m[2]; b = m[4] != null ? +m[4] : (m[6] != null ? hi : a); }
if (v >= a && v <= b && (v - a) % st == 0) return true;
}
return false;
}
function wd0(lt) { return lt.wday % 7; }
function cmatch(w, t) {
let lt = localtime(t), dw = wd0(lt);
let dm = fmatch(w[2], lt.mday, 1, 31), dd = fmatch(w[4], dw, 0, 7) || (dw == 0 && fmatch(w[4], 7, 0, 7));
let day = (w[2] != '*' && w[4] != '*') ? (dm || dd) : (dm && dd);
return day && fmatch(w[0], lt.min, 0, 59) && fmatch(w[1], lt.hour, 0, 23) && fmatch(w[3], lt.mon, 1, 12);
}
function downwhy(now) {
for (let l in split(readfile('/etc/crontabs/root') ?? '', '\n')) {
if (substr(ltrim(l), 0, 1) == '#') continue;
let f = match(l, /^[ \t]*([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+([^ \t]+)[ \t]+(.*)$/);
if (!f || !match(f[6], /(^|[ ;&|({])(\/sbin\/)?reboot([ ;&|)}]|$)/)) continue;
let w = slice(f, 1, 6);
if (cmatch(w, now) || cmatch(w, now - 60) || cmatch(w, now - 120)) return 'sched';
}
let evf = '/tmp/wf-events.log';	/* 2.94: sempre in RAM (copia ogni ora dal Custode) */
for (let l in split(readfile(evf) ?? '', '\n')) {
let p = split(l, '|', 4);
if (length(p) == 4 && p[1] == 'wd_reboot' && now - +p[0] < 180) return 'watchdog';
}
return 'asked';
}
function down() {
let now = time();
mkdir('/etc/wrtfreedom');
if (has(HIST)) { writefile(HISTE + '.t', readfile(HIST)); rename(HISTE + '.t', HISTE); }
wjs(DOWNF, { t: now >= TOK ? now : null, why: downwhy(now), rev: fwrev() });
}
function nightnow() {
if (uo('ledn', 'on') != '1') return false;
let hm = (s) => { let m = match(s ?? '', /^([0-9]{2}):([0-9]{2})$/); return m ? +m[1] * 60 + +m[2] : null; };
let f = hm(uo('ledn', 'from')), t = hm(uo('ledn', 'to')), lt = localtime(time()), n = lt.hour * 60 + lt.min;
if (f == null || t == null || f == t) return false;
let inw = f < t ? (n >= f && n < t) : (n >= f || n < t), dw = (f > t && n < t) ? (wd0(lt) + 6) % 7 : wd0(lt);
let days = split(trim(uo('ledn', 'days')), ' ');
return inw && (!length(days[0]) || index(days, '' + dw) >= 0);
}
function boot() {
if (!has(HIST) && has(HISTE)) writefile(HIST, readfile(HISTE));
if (nightnow()) sh('sh ' + W + '/cron.sh ledoff ' + q(replace(trim(uo('ledn', 'keep')), / +/g, ',')) + ' >/dev/null 2>&1');
sh('( sh ' + W + '/cron.sh ledbars boot ) >/dev/null 2>&1 </dev/null &');
let fm = uo('health', 'fan');
if (length(fm) && fm != 'auto') ub('wrtfreedom', 'health', { action: 'fan' });
let D = rjs(DOWNF), al = split(trim(readfile(ALIVE) ?? ''), ' '), at = +(al[0] ?? 0) || null, rev = fwrev();
unlink(DOWNF);
let lw = at;
if (at) for (let f in lsdir('/etc/wrtfreedom') ?? []) { let s = lst('/etc/wrtfreedom/' + f); if (s && s.mtime > lw) lw = s.mtime; }
let pst = length(filter(lsdir('/sys/fs/pstore') ?? [], (f) => substr(f, 0, 6) == 'dmesg-')) > 0;
let why = null, last = null;
if (D) { why = (D.rev && length(rev) && D.rev != rev) ? 'upgrade' : (D.why ?? 'asked'); last = D.t; }
else if (at) { why = (length(al[1] ?? '') && length(rev) && al[1] != rev) ? 'upgrade' : pst ? 'crash' : 'power'; last = lw; }
let unexp = why == 'power' || why == 'crash';
let say = unexp ? uo('health', 'al_boot') != '0' : why != null;
if (say) writefile('/tmp/wf-bootsaid', '' + time());
if (say && !unexp) {
let wl = { asked: L('Riavvio chiesto', 'Requested restart'), upgrade: L('Sistema aggiornato', 'System updated'),
sched: L('Riavvio programmato', 'Scheduled restart'), watchdog: L('Dal Ripristino Automatico', 'By Automatic Recovery') };
sh('WF_NORULES=1 sh ' + W + '/event.sh cron boot sys ' + q('🩺 Router ¦ ' + L('Acceso', 'Powered on') + ' ¦ ' + (wl[why] ?? why)) + ' >/dev/null 2>&1');
}
for (let i = 0; i < 60 && !has('/tmp/.wf-ntp'); i++) sh('sleep 10');
let now = time(), bt = has('/tmp/.wf-ntp') && now >= TOK ? now - upsec() : null;
let E = { t: bt, why: why, off: (bt && last && bt >= last) ? bt - last : null, approx: !D };
wjs(BOOTT, E);
if (why == null) return;
let B = rjs(BOOTS);
B = type(B) == 'array' ? B : [];
push(B, E);
if (length(B) > 20) B = slice(B, length(B) - 20);
mkdir('/etc/wrtfreedom'); wjs(BOOTS, B);
if (say && unexp) {
let m = E.off != null ? int((E.off + 59) / 60) : null;
ev('health_boot', '🩺 Router ¦ ' + (why == 'crash' ? L('Si era bloccato', 'Had frozen') + ' ¦ ' + L('Riavviato da solo', 'Restarted by itself') :
L('Riavviato da solo', 'Restarted by itself') + ' ¦ ' + L('Mancanza di corrente', 'Power cut')) +
(m != null && why == 'power' ? ' ¦ ' + L('Spento per circa ', 'Off for about ') + (m < 120 ? m + ' min' : int(m / 60) + ' h') : ''));
}
}

function kb(p) { return +(match(sh('du -sk ' + q(p) + ' 2>/dev/null'), /^([0-9]{1,15})/)?.[1] ?? 0) * 1024; }
function adgyaml() {
let s = false, u = {};
for (let l in split(readfile('/etc/config/adguardhome') ?? '', '\n')) {
if (match(l, /^[ \t]*config[ \t]/)) { s = match(l, /^[ \t]*config[ \t]+[^ \t]+[ \t]+['"]?config['"]?[ \t]*$/) != null; continue; }
let m = s ? match(l, /^[ \t]*option[ \t]+(config_file|config)[ \t]+['"]?([^'"]{1,255})/) : null;
if (m) u[m[1]] = trim(m[2]);
}
for (let f in [ u.config_file, u.config ]) if (length(f) && stat(f)) return f;
let c = stat('/tmp/wf-adgyaml'), y = c ? trim(readfile('/tmp/wf-adgyaml') ?? '') : '';
if (y == '-' && time() - c.mtime < 60) return null;
if (length(y) && y != '-' && time() - c.mtime < 600 && stat(y)) return y;
y = trim(sh('sh /usr/share/wrtfreedom/lib.sh adgyaml 2>/dev/null'));
return length(y) && stat(y) ? y : null;
}
function adgdir() {
let wd = '', y = adgyaml();
let yd = y ? replace(y, /\/[^\/]*$/, '') : '';
for (let l in split(readfile('/etc/config/adguardhome') ?? '', '\n')) { let m = match(l, /^[[:blank:]]*option workdir '?([^' ]{1,200})'?/); if (m) wd = m[1]; }
for (let d in [wd, yd, '/var/lib/adguardhome', '/etc/adguardhome', '/opt/AdGuardHome', '/opt/adguardhome'])
if (length(d) && has(d + '/data')) return d + '/data';
return null;
}
function cleanfiles() {
let now = time(), old = (f) => { let s = lst(f); return s && s.type == 'file' && now - s.mtime > 1800 ? s.size : 0; }, G = { pkg: [], tmp: [], logs: [], adg: [] };
let add = (g, f, b) => { if (b > 0) push(G[g], [f, b]); };
for (let d in ['/etc/apk/cache', '/var/cache/apk', '/var/cache/opkg'])
for (let f in lsdir(d) ?? []) if (match(f, /\.(apk|ipk)$/)) add('pkg', d + '/' + f, old(d + '/' + f));
for (let f in lsdir('/tmp') ?? []) if (match(f, /\.(apk|ipk)$/)) add('pkg', '/tmp/' + f, old('/tmp/' + f));
let BK = '/etc/wrtfreedom/bak/', bakwait = length(filter(lsdir(BK) ?? [], (d) => {
let s = stat(BK + d + '/id'), l = +(readfile(BK + d + '/lim') ?? '');
l = l > 0 ? l : (+(readfile(BK + d + '/secs') ?? '') || 120) + 30;
return s && now - s.mtime <= l && s.mtime - now <= l;
})) > 0;
for (let f in ['/tmp/firmware.bin', '/tmp/sysupgrade.img', '/tmp/wf-pkg.tgz']) add('tmp', f, old(f));
if (!bakwait) add('tmp', '/tmp/backup.tar.gz', old('/tmp/backup.tar.gz'));
for (let f in lsdir('/var/log') ?? []) if (match(f, /\.([0-9]{1,2}|old|gz)$/)) add('logs', '/var/log/' + f, old('/var/log/' + f));
let ad = adgdir();
if (ad) for (let f in lsdir(ad) ?? []) if (match(f, /^querylog\.json\.[0-9]{1,2}$/)) add('adg', ad + '/' + f, old(ad + '/' + f));
return G;
}
const CLN = {
pkg: [ 'Pacchetti Scaricati', 'Packages Downloaded', 'Si riscaricano se servono', 'Downloaded again if needed' ],
tmp: [ 'File Caricati Non Usati', 'Unused Uploaded Files', 'Firmware e copie caricati da più di 30 minuti', 'Firmware and copies uploaded over 30 minutes ago' ],
logs: [ 'Registri Vecchi', 'Old Logs', 'Solo quelli già archiviati', 'Only the archived ones' ],
adg: [ 'Registro AdGuard', 'AdGuard Log', 'Le statistiche restano', 'Statistics stay' ]
};
function space() {
let lk = lock('space', 300);
if (!lk) return;
let ov = has('/overlay/upper'), base = ov ? '/overlay/upper' : '/', I = {}, ad = adgdir();
let G = { usr: 'apps', lib: 'apps', bin: 'apps', sbin: 'apps', opt: 'apps', www: 'web', etc: 'cfg', root: 'home', home: 'home' };
let du = ov ? 'du -x -k -d 1 ' + q(base) + ' 2>/dev/null' : 'du -x -k -s /usr /lib /etc /root 2>/dev/null';
if (!ov) du = (has('/usr/bin/timeout') || has('/bin/timeout')) ? 'timeout 60 ' + du :
du + ' & p=$!; ( sleep 60; kill $p ) >/dev/null 2>&1 & w=$!; wait $p; kill $w 2>/dev/null';
for (let l in split(sh(du), '\n')) {
let m = match(l, /^([0-9]{1,15})[ \t]+(.+)$/);
if (!m || m[2] == base || m[2] == '/') continue;
let n = replace(m[2], /^.*\//, ''), g = G[n] ?? 'other';
if (!ov && index(['proc', 'sys', 'dev', 'tmp', 'var', 'overlay', 'rom', 'mnt'], n) >= 0) continue;
I[g] = (I[g] ?? 0) + +m[1] * 1024;
}
if (ad && (ov ? has(base + ad) : index(ad, '/var/') != 0 && index(ad, '/tmp/') != 0)) {
let b = kb(ov ? base + ad : ad);
if (b > 0) { I.adg = b; let g = G[split(substr(ad, 1), '/')[0]] ?? 'other'; I[g] = (I[g] ?? 0) - b; if (I[g] < 0) I[g] = 0; }
}
let NM = { apps: L('Programmi Aggiunti', 'Added Programs'), cfg: L('Impostazioni', 'Settings'), adg: 'AdGuard Home', web: L('Pagine Web', 'Web Pages'),
home: L('File Dell\'Amministratore', 'Administrator Files'), other: L('Altro', 'Other') };
let items = sort(map(filter(keys(I), (k) => I[k] > 0), (k) => ({ id: k, name: NM[k], b: I[k] })), (a, b) => b.b - a.b);
let C = cleanfiles(), cl = [];
for (let k in ['pkg', 'tmp', 'logs', 'adg']) {
let b = 0;
for (let x in C[k]) b += x[1];
if (b > 0) push(cl, { id: k, name: L(CLN[k][0], CLN[k][1]), desc: L(CLN[k][2], CLN[k][3]), b: b,
ram: length(filter(C[k], (x) => match(x[0], /^\/(tmp|var)\//))) == length(C[k]) });
}
let si = ub('system', 'info', {})?.root ?? {};
wjs(SPACE, { t: time(), mnt: ov ? '/overlay' : '/', total: +(si.total ?? 0) * 1024, used: +(si.used ?? 0) * 1024, items: slice(items, 0, 6), clean: cl });
rmdir(lk);
}
function clean(ids) {
let lk = lock('space', 300);
if (!lk) { wjs(CLEAN, { t: time(), ids: [], freed: 0, busy: true }); return; }
let C = cleanfiles(), fr = 0, done = [];

for (let k in split(ids, ',')) {
if (!C[k]) continue;
push(done, k);
for (let x in C[k]) if (unlink(x[0])) fr += x[1];
}
wjs(CLEAN, { t: time(), ids: done, freed: fr });
rmdir(lk);
space();
}

const A = ARGV[0] ?? '';
if (A == 'tick') tick();
else if (A == 'boot') boot();
else if (A == 'down') down();
else if (A == 'space') space();
else if (A == 'clean') clean('' + (ARGV[1] ?? ''));
else print('uso: ucode health.uc tick|boot|down|space|clean <pkg,tmp,logs,adg>\n');
