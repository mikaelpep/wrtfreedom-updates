#!/bin/sh
P=/tmp/wf-sqmlive
echo $$ > $P.pid
F=$P.fifo
trap 'rm -f $P.pid $F $P.q' EXIT
FF=0; rm -f $F; mkfifo $F 2>/dev/null; [ -p $F ] && exec 3<>$F && FF=1
nap() { if [ $FF = 1 ]; then read -t 1 _ <&3; else sleep 1; fi; }
n=0
while :; do
read u _ </proc/uptime; u=${u%.*}
w=0; [ -f $P.want ] && read w <$P.want
[ $((u - ${w:-0})) -lt 15 ] || break
tc qdisc show > $P.q 2>/dev/null
while read -r l; do
set -f; set -- $l; set +f; [ "$1 $2" = "qdisc cake" ] || continue
d=; b=; while [ $# -gt 1 ]; do case $1 in dev) d=$2 ;; bandwidth) b=$2 ;; esac; shift; done
[ -n "$d" ] && [ -n "$b" ] && echo "$u $d $b"
done < $P.q > $P.n
mv $P.n $P
while read l; do echo "$l"; done < $P >> $P.h
n=$((n + 1)); [ $((n % 30)) = 0 ] && { tail -n 400 $P.h > $P.h.n; mv $P.h.n $P.h; }
nap
done
