#!/bin/sh
umask 022
BASE=$(uci -q get wrtfreedom.upd.url); BASE=${BASE:-https://raw.githubusercontent.com/mikaelpep/wrtfreedom-updates/main}
W=/usr/share/wrtfreedom; PUB=$W/wrtfreedom-upd.pub; D=/tmp/wf-upd; OUT=/tmp/wf-upd.json; ERR=/tmp/wf-upd.err
mkdir -p $D
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
fk() { f_=$(df -kP /overlay 2>/dev/null | awk 'NR==2{print $4}'); [ -n "$f_" ] || f_=$(df -kP / 2>/dev/null | awk 'NR==2{print $4}'); echo "$f_"; }
fpoco() { f=$(fk); case "$f" in ''|*[!0-9]*) return 1 ;; esac; [ "$f" -lt "$1" ]; }
newer() { [ -n "$1" ] && [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -t. -k1,1n -k2,2n -k3,3n | tail -n 1)" = "$1" ]; }
get() { # url file
rm -f "$2"
if command -v uclient-fetch >/dev/null 2>&1; then uclient-fetch -q -T 30 -O "$2" "$1" >/dev/null 2>&1
elif command -v curl >/dev/null 2>&1; then curl -fsSL -m 300 -o "$2" "$1" >/dev/null 2>&1
else wget -q -T 30 -O "$2" "$1" >/dev/null 2>&1; fi
[ -s "$2" ]
}
fail() { echo "$1" > $ERR; return 1; }
check() {
command -v usign >/dev/null 2>&1 || { fail nousign; return 1; }
[ -f "$PUB" ] || { fail nokey; return 1; }
L_=$D/latest.$$.json; rm -f $L_ $L_.sig
get "$BASE/latest.json" $L_ && get "$BASE/latest.json.sig" $L_.sig || { rm -f $L_ $L_.sig; fail net; return 1; }
usign -V -q -p "$PUB" -m $L_ -x $L_.sig >/dev/null 2>&1 || { rm -f $L_ $L_.sig; fail sig; return 1; }
mv $L_ $OUT.$$ && mv $OUT.$$ $OUT; rm -f $L_.sig $ERR
}
jf() { jsonfilter -i $OUT -e "$1" 2>/dev/null; }
tg() { [ "$TG" = 1 ] && ubus call wrtfreedom tgsend "{\"bg\":true,\"text\":\"$(printf '%s' "$1" | tr '\n\r\t' '   ' | tr -d '\000-\037' | sed 's/\\/\\\\/g; s/"/\\"/g')\"}" >/dev/null 2>&1; }
cur() { cat $W/VERSION 2>/dev/null; }
up1() { r_=${1#?}; printf '%s%s' "$(printf '%s' "${1%"$r_"}" | tr 'a-z' 'A-Z')" "$r_"; }
tgok() { tg "⬆️ $(t "Aggiornamenti" "Updates") ¦ $(up1 "$1" | sed 's/: / ¦ /')"; }
tgko() { tg "⚠️ $(t "Aggiornamenti" "Updates") ¦ $(up1 "$1" | sed 's/: / ¦ /')"; }
appget() {
m=$(jf '@.pkg.minapp'); a=
[ -n "$(find /etc/wrtfreedom/appver -mtime +30 2>/dev/null)" ] || a=$(cat /etc/wrtfreedom/appver 2>/dev/null)
}
appmin() {
appget
[ -n "$m" ] && [ -n "$a" ] && newer "$m" "$a" || return 0
t "la versione $(jf '@.pkg.v') ha bisogno dell'app $m o più nuova (sul telefono $a): aggiorna prima l'app" "version $(jf '@.pkg.v') needs app $m or newer (on the phone $a): update the app first"
return 1
}
appunk() {
appget
[ -n "$m" ] && [ -z "$a" ] || return 0
t "⚠️ Aggiornamenti ¦ App non nota al router ¦ La $(jf '@.pkg.v') vuole l'app $m+ ¦ Se è più vecchia, aggiornala" "⚠️ Updates ¦ App unknown to the router ¦ $(jf '@.pkg.v') needs app $m+ ¦ If yours is older, update it"
}
ckmsg() {
case "$(cat $ERR 2>/dev/null)" in
nousign) t "manca usign: installalo dall'app" "usign is missing: install it from the app";;
sig) t "firma non valida: niente installato" "invalid signature: nothing installed";;
*) t "server non raggiungibile: il router è su internet?" "server not reachable: is the router online?";;
esac
}
UPGF=/tmp/wf-upg.json
nasold() {
E_=/etc/wrtfreedom; X_=
for f in /usr/share/wrtfreedom/nas*; do
[ -f "$f" ] || continue
printf '%s\n' "$1" | grep -qxF "${f##*/}" && continue
rm -f "$f"; X_="$X_ ${f##*/}"
done
C_=/etc/crontabs/root
if [ -n "$X_" ] && [ -f $C_ ]; then
cp $C_ $C_.wf
for b in $X_; do grep -v "/usr/share/wrtfreedom/$(printf '%s' "$b" | sed 's/\./\./g')[ ;].* # wf:[a-z0-9_]*\$" $C_.wf > $C_.wf2; mv $C_.wf2 $C_.wf; done
if cmp -s $C_ $C_.wf; then rm -f $C_.wf; else mv $C_.wf $C_; /etc/init.d/cron restart >/dev/null 2>&1; fi
fi
case " $X_ " in *" nasdl.sh "*)
for f in $E_/nas-dl-ok.sh $E_/nas-dl-err.sh /etc/init.d/wf-nasdl; do
[ -f "$f" ] && sed -i -e 's#/usr/share/wrtfreedom/nasdl\.sh dldone#/usr/share/wrtfreedom/nasvc.sh dldone#' -e 's#/usr/share/wrtfreedom/nasdl\.sh dlprep#/usr/share/wrtfreedom/nasvc.sh dlprep#' "$f"
done ;;
esac
for f in $E_/nas-bak/b*.sh; do
[ -f "$f" ] && grep -q '^TIME=' "$f" || continue
t_=$(sed -n "s/^TIME='\([0-9][0-9]:[0-9][0-9]\)'\$/\1/p" "$f" | head -n 1)
grep -qx 'ON=0' "$f" && t_=
grep -q '^MODE=' "$f" && ! grep -qx "MODE='night'" "$f" && t_=
if grep -q '^AT=' "$f"; then sed -i "s/^AT=.*/AT='$t_'/" "$f"; else echo "AT='$t_'" >> "$f"; fi
done
F_=$E_/nas-rec.sh
if [ -f $F_ ] && grep -qx 'REC_ON=0' $F_; then
k_=$(ucode -e "let N = {}; try { N = json(require('fs').readfile('$E_/nas.json') ?? '{}'); } catch (e) {} let r = N?.rec ?? {}, k = r.keep, d = k ? (k.mode == 'days' ? k.days : 0) : r.days, g = k ? (k.mode == 'size' ? k.max_gb : 0) : r.max_gb; print(r.on === true ? 1 : 0, ' ', int(d ?? 0) || 0, ' ', int(g ?? 0) || 0);" 2>/dev/null)
o_=0; d_=; g_=
[ -n "$k_" ] && { o_=${k_%% *}; d_=${k_#* }; g_=${d_#* }; d_=${d_%% *}; }
case "$d_$g_" in ''|*[!0-9]*) o_=0 ;; esac
[ "$o_" = 1 ] && sed -i -e '/^# 3\.11: registrazioni con nasrec\.sh/d' -e 's/^REC_ON=0$/REC_ON=1/' -e "s/^REC_GB=.*/REC_GB=$g_/" -e "s/^REC_DAYS=.*/REC_DAYS=$d_/" $F_
fi
true
}
devold() {
A_=/etc/wrtfreedom/devdays.json; L_=/tmp/wf-dev.lock
[ -f $A_ ] || return 0
i_=0; k_=0; while [ $i_ -lt 10 ]; do mkdir $L_ 2>/dev/null && { k_=1; break; }; sleep 1; i_=$((i_ + 1)); done
ucode -e "let fs = require('fs'), E = {}, A = {}; try { E = json(fs.readfile('/etc/wrtfreedom/devuse.json') ?? '{}') ?? {}; } catch (e) {} try { A = json(fs.readfile('$A_') ?? '{}') ?? {}; } catch (e) { exit(1); } let nw = +(A.st ?? 0) > +(E.st ?? 0), Y = E.days ?? {}; for (let k in A.days ?? {}) if (nw || Y[k] == null) Y[k] = A.days[k]; E.days = Y; if (nw) E.st = A.st; fs.writefile('/etc/wrtfreedom/devuse.json.t', sprintf('%J', E)) && fs.rename('/etc/wrtfreedom/devuse.json.t', '/etc/wrtfreedom/devuse.json') || exit(1);" 2>/dev/null && rm -f $A_
[ $k_ = 1 ] && rmdir $L_ 2>/dev/null
true
}
smbold() {
for f_ in /etc/ksmbd/ksmbd.conf.template /etc/samba/smb.conf.template; do [ -f "$f_" ] && sed -i -e '/^# wf-nas$/{N;d;}' -e '/^# wf-cloud$/{N;d;}' -e '/^# wf-nas-orig$/{N;s/^# wf-nas-orig\n#//;}' "$f_"; done
rm -f /etc/wrtfreedom/nas-smb.fp /tmp/wf-nas/follow.fp
[ -f /etc/wrtfreedom/nas.json ] || return 0
o_=true; [ "$(jsonfilter -i /etc/wrtfreedom/nas.json -e '@.smb_off' 2>/dev/null)" = true ] && o_=false
ubus -t 60 call wrtfreedom nas_shares "{\"act\":\"on\",\"on\":$o_}" >/dev/null 2>&1
true
}
ug() { jsonfilter -i $UPGF -e "$1" 2>/dev/null; }
inst() {
v=$1
case "$v" in [0-9]*.[0-9]*) ;; *) rm -rf /tmp/wfpkg; m=$(t "pacchetto senza versione" "package without version"); echo "## ERRORE $m"; tgko "$m"; return 1;; esac
U=; [ -d /overlay/upper ] && U=/overlay/upper
n=$(du -sk /tmp/wfpkg 2>/dev/null | cut -f1); o=$(du -sk $U/usr/share/wrtfreedom $U/www/wrtfreedom $U/usr/share/rpcd/ucode/wrtfreedom.uc 2>/dev/null | awk '{s+=$1} END{print s+0}')
d=$(( ${n:-0} - o )); [ $d -lt 0 ] && d=0
case "$(awk '$2=="/overlay"{o=$3} $2=="/"{r=$3} END{print o?o:r}' /proc/mounts 2>/dev/null)" in jffs2|ubifs) d=$((d / 2)) ;; esac
d=$((d + ${n:-0} / 2))
fpoco $((d + 512)) && { rm -rf /tmp/wfpkg; m=$(t "spazio insufficiente sul router: servono $((d + 512)) KB liberi, ce ne sono $f. Niente è cambiato: togli i pacchetti che non usi (Software e Aggiornamenti) e riprova" "not enough space on the router: $((d + 512)) KB free needed, $f available. Nothing changed: remove the packages you do not use (Software and Updates) and try again"); echo "## ERRORE $m"; tgko "$m"; return 1; }
newer 2.68 "$v" && [ -f /etc/wrtfreedom/bak/cron/back.sh ] && sh /etc/wrtfreedom/bak/cron/back.sh >/dev/null 2>&1
newer 2.67 "$v" && ubus -t 20 call wrtfreedom vpnwd '{"action":"restore"}' >/dev/null 2>&1
newer 2.68 "$v" && ubus -t 20 call wrtfreedom ddnswd '{"action":"restore"}' >/dev/null 2>&1
newer 2.94 "$v" && { [ -n "$(uci -q get wrtfreedom.custode.c5gwd)" ] || [ -f /etc/wrtfreedom/custode/c5gfw.json ]; } && ucode $W/custode.uc c5gback >/dev/null 2>&1
WF_CN=$(sh $W/cloudmnt.sh flush 120 </dev/null 2>/dev/null | sed -n 's/^pending=//p')
[ "${WF_CN:-0}" -gt 0 ] 2>/dev/null && echo "## $(t "Cartella Cloud: $WF_CN file non sono ancora nel cloud" "Cloud Folder: $WF_CN files are not in the cloud yet")"
PL=$(ls /tmp/wfpkg 2>/dev/null)
o=$(sh /tmp/wfpkg/install.sh 2>&1); echo "$o"; rm -rf /tmp/wfpkg
if echo "$o" | grep -q '^## OK'; then
newer 3.11 "$v" && nasold "$PL"
newer 3.33 "$v" && devold
newer 3.47 "$v" && smbold
newer 2.66 "$v" && { rm -f /etc/hotplug.d/acme/91-wrtfreedom; [ -f /etc/sysupgrade.conf ] && sed -i '\#^/etc/hotplug.d/acme/91-wrtfreedom$#d' /etc/sysupgrade.conf; }
tgok "$(t "Pacchetto Router aggiornato" "Router Package updated"): $(cur)"
else tgko "$(t "Aggiornamento non riuscito" "Update failed"): $(echo "$o" | sed -n 's/^## ERRORE //p' | tail -n 1)"; fi
}

case "$1" in
check)
check ;;
safe)
TG=0; [ "$2" = tg ] && TG=1
check || { m=$(ckmsg); echo "## ERRORE $m"; tgko "$m"; exit 1; }
v=$(jf '@.pkg.v')
newer "$v" "$(cur)" || { m="$(t "Pacchetto Router già aggiornato" "Router Package up to date"): $(cur)"; echo "## OK $(cur)"; echo "$m"; tgok "$m"; exit 0; }
m=$(appmin) || { echo "## ERRORE $m"; tgko "$m"; exit 1; }
w=$(appunk)
r=$(ubus -t 30 call wrtfreedom updsafe '{"action":"start","kind":"wf","secs":900,"appok":true}' 2>/dev/null)
if ! printf '%s' "$r" | grep -q '"started": *true'; then
m=$(printf '%s' "$r" | jsonfilter -e '@.error' 2>/dev/null); m=${m:-$(t "aggiornamento non avviato" "update not started")}
echo "## ERRORE $m"; tgko "$(t "Aggiornamento non avviato" "Update not started"): $m"; exit 1
fi
echo "## $(t "Copio le impostazioni e installo la" "Backing up the settings and installing") $v"
[ -n "$w" ] && { echo "$w"; tg "$w"; }
cp "$0" $D/follow.sh
if command -v start-stop-daemon >/dev/null 2>&1; then start-stop-daemon -S -b -m -p $D/follow.pid -x /bin/sh -- $D/follow.sh follow "$2" </dev/null >/dev/null 2>&1
elif command -v setsid >/dev/null 2>&1; then setsid sh $D/follow.sh follow "$2" </dev/null >/dev/null 2>&1 &
else ( sh $D/follow.sh follow "$2" ) </dev/null >/dev/null 2>&1 & fi
;;
follow)
TG=0; [ "$2" = tg ] && TG=1; J=0; [ "$3" = job ] && J=1; i=0; p=copy
while [ $i -lt 600 ]; do
sleep 2; i=$((i+1)); s=$(ug '@.st'); K=$(ug '@.kind'); WK=0; case "$K" in wf|local|'') WK=1;; esac
if [ $J = 1 ] && [ -n "$s" ] && [ "$s" != "$p" ]; then
p=$s
case "$s" in
install) case "$K" in
wf) echo "## $(t "Scarico, controllo la firma e installo la" "Downloading, checking the signature and installing") $(ug '@.to')" ;;
local) echo "## $(t "Installo il pacchetto dell'app" "Installing the app package") $(ug '@.to')" ;;
*) echo "## $(t "Provo senza installare, poi installo" "Trying without installing, then installing"): $(ug '@.name')" ;;
esac ;;
wait) if [ $WK = 1 ]; then echo "## $(t "Il router risponde con la versione nuova: confermo" "The router answers with the new version: confirming")"; else echo "## $(t "Il router risponde: confermo" "The router answers: confirming")"; fi ;;
esac
fi
case "$s" in
wait) ubus -t 20 call wrtfreedom updsafe '{"action":"confirm"}' >/dev/null 2>&1 ;;
ok) if [ $WK = 1 ]; then [ $J = 1 ] && echo "## OK $(cur)"; tgok "$(t "Pacchetto Router aggiornato" "Router Package updated"): $(cur)"
else [ $J = 1 ] && echo "## OK $(ug '@.name')"; tgok "$(t "Pacchetti confermati" "Packages confirmed"): $(ug '@.name')"; fi; exit 0 ;;
back) bp=$(cat /tmp/wf-bg.upg.pid 2>/dev/null); case "$bp" in ''|*[!0-9]*) ;; *) tr '\0' ' ' 2>/dev/null < /proc/$bp/cmdline | grep -q /tmp/wf-bg.upg.pid && continue;; esac
if [ $WK = 1 ]; then m="$(t "Aggiornamento non riuscito, rimessa la versione di prima" "Update failed, previous version restored"): $(ug '@.msg')"
else m="$(t "Non riuscito, impostazioni rimesse com'erano" "Failed, settings restored"): $(ug '@.msg')"; fi
[ $J = 1 ] && echo "## ERRORE $m"; tgko "$m"; exit 0 ;;
err) m="$(t "Aggiornamento non riuscito" "Update failed"): $(ug '@.msg')"; [ $J = 1 ] && echo "## ERRORE $m"; tgko "$m"; exit 0 ;;
esac
done
[ $J = 1 ] && echo "## ERRORE $(t "nessun esito dall'aggiornamento entro 20 minuti: guarda Software e Aggiornamenti" "no result from the update within 20 minutes: see Software and Updates")"
;;
install)
TG=0; [ "$2" = tg ] && TG=1
[ "$WF_UPGJOB" = 1 ] || [ "$3" = force ] || { echo "## ERRORE $(t "aggiorna dall'app, con copia e ritorno" "update from the app, with backup and rollback")"; exit 1; }
echo "## $(t "Controllo il server degli aggiornamenti" "Checking the update server")"
check || { m=$(ckmsg); echo "## ERRORE $m"; tgko "$m"; exit 1; }
v=$(jf '@.pkg.v'); f=$(jf '@.pkg.file'); h=$(jf '@.pkg.sha256')
case "$f" in ''|*[!A-Za-z0-9._-]*) echo "## ERRORE $(t "elenco degli aggiornamenti non valido" "invalid update list")"; exit 1;; esac
newer "$v" "$(cur)" || [ "$3" = force ] || { m="$(t "Pacchetto Router già aggiornato" "Router Package up to date"): $(cur)"; echo "## OK $(cur)"; echo "$m"; tgok "$m"; exit 0; }
m=$(appmin) || { echo "## ERRORE $m"; tgko "$m"; exit 1; }
echo "## $(t "Scarico la versione" "Downloading version") $v"
get "$BASE/$f" /tmp/wf-pkg.tgz || { m=$(t "download non riuscito" "download failed"); echo "## ERRORE $m"; tgko "$m"; exit 1; }
[ "$(sha256sum /tmp/wf-pkg.tgz | cut -d' ' -f1)" = "$h" ] || { rm -f /tmp/wf-pkg.tgz; m=$(t "il file scaricato non corrisponde a quello firmato" "the downloaded file does not match the signed one"); echo "## ERRORE $m"; tgko "$m"; exit 1; }
echo "## $(t "File verificato, installo" "File verified, installing")"
rm -rf /tmp/wfpkg && mkdir -p /tmp/wfpkg && tar xzf /tmp/wf-pkg.tgz -C /tmp/wfpkg || { echo "## ERRORE $(t "archivio non valido" "invalid archive")"; exit 1; }
inst "$v"
;;
local)
TG=0
[ "$WF_UPGJOB" = 1 ] || { echo "## ERRORE $(t "aggiorna con copia e ritorno (dall'app)" "update with backup and rollback (from the app)")"; exit 1; }
[ -f /tmp/wfpkg/install.sh ] || { echo "## ERRORE $(t "nessun Pacchetto Router copiato dall'app: copialo di nuovo" "no Router Package copied from the app: copy it again")"; exit 1; }
v=$(cat /tmp/wfpkg/VERSION 2>/dev/null)
echo "## $(t "Installo il pacchetto dell'app" "Installing the app package") $v"
inst "$v"
;;
notify)
[ "$(uci -q get wrtfreedom.upd.check)" = 0 ] && exit 0
check || exit 0
S=/etc/wrtfreedom/upd.seen; touch $S
v=$(jf '@.pkg.v')
if newer "$v" "$(cur)" && ! grep -qx "pkg $v" $S; then
{ tail -n 19 $S; echo "pkg $v"; } > $S.t && mv $S.t $S	# ultime 20 versioni avvisate (tetto), una scrittura sola
sh $W/event.sh upd pkg "⬆️ $(t "Pacchetto Router ¦ $v disponibile ¦ Installato $(cur)" "Router Package ¦ $v available ¦ Installed $(cur)")"
fi
a=$(jf '@.app.v'); have=$(cat /etc/wrtfreedom/appver 2>/dev/null)
if [ -n "$have" ] && newer "$a" "$have" && ! grep -qx "app $a" $S; then
{ tail -n 19 $S; echo "app $a"; } > $S.t && mv $S.t $S
sh $W/event.sh upd app "⬆️ $(t "App WrtFreedom ¦ $a disponibile ¦ Sul telefono $have" "WrtFreedom App ¦ $a available ¦ On the phone $have")"
fi
;;
status)
check
v=$(jf '@.pkg.v'); a=$(jf '@.app.v')
echo "📦 $(t "Pacchetto Router" "Router Package"): $(cur)"
if [ -f $ERR ] && [ ! -s $OUT ]; then case "$(cat $ERR)" in nousign) t "⚠️ Aggiornamenti ¦ Manca usign ¦ Controllo non possibile" "⚠️ Updates ¦ usign is missing ¦ Cannot check";; *) t "⚠️ Aggiornamenti ¦ Server non raggiungibile" "⚠️ Updates ¦ Server not reachable";; esac; echo; exit 0; fi
if newer "$v" "$(cur)"; then echo "🆕 $(t "Disponibile" "Available"): $v · /$(t aggiorna_pacchetto update_package)"; else t "✅ Aggiornato" "✅ Up to date"; echo; fi
[ -n "$a" ] && echo "📱 $(t "App WrtFreedom" "WrtFreedom app"): $a"
;;
ritorno)
RD=${2:-/tmp/wf-ritorno}; C=/etc/wrtfreedom/pacchetto.tgz; LG=/tmp/wf-ritorno.log; PFX=/tmp/wf-ritorno.pid
KC=/lib/upgrade/keep.d/wrtfreedom-copia
[ -f $PFX ] && kill -0 "$(cat $PFX)" 2>/dev/null && exit 0
echo $$ > $PFX
ev() { E=$W/event.sh; [ -f $E ] || E=$RD/event.sh; [ -f $E ] && WF_Q=$Q sh $E cron "$1" sys "$2" >/dev/null 2>&1; logger -t wrtfreedom "$2"; }
Q=; evq() { Q=1; ev "$@"; Q=; }
i=0; while [ $i -lt 150 ]; do pidof rpcd >/dev/null 2>&1 && ubus list network.interface >/dev/null 2>&1 && break; sleep 2; i=$((i + 1)); done
S1=${WF_RSLEEP:-10}; S2=${WF_RSLEEP:-60}
sleep $S1
RH=$(sed -n 's#^[^#]*https\{0,1\}://\([^/]*\)/.*#\1#p' /etc/apk/repositories.d/*.list /etc/apk/repositories /etc/opkg/distfeeds.conf 2>/dev/null | head -n 1)
RF=$(readlink -f /etc/resolv.conf 2>/dev/null); [ -n "$RF" ] || RF=/etc/resolv.conf
RO=/tmp/wf-resolv.orig; rm -f $RO
dnsfix() {
nslookup "$RH" >/dev/null 2>&1 && return 0
[ -f $RO ] || cp "$RF" $RO 2>/dev/null || : > $RO
DS=$(ubus call network.interface dump 2>/dev/null | jsonfilter -e '@.interface[*]["dns-server"][*]' 2>/dev/null)
{ echo "# wf-ritorno"; for d in $DS 1.1.1.1 8.8.8.8; do echo "nameserver $d"; done; } > "$RF"
}
DW=
if [ -n "$RH" ] && command -v nslookup >/dev/null 2>&1; then
dnsfix; ( while :; do sleep 5; dnsfix; done ) </dev/null >/dev/null 2>&1 & DW=$!
fi
dnsback() { [ -n "$DW" ] && kill $DW 2>/dev/null; DW=
[ -s $RO ] && [ "$(head -n 1 "$RF" 2>/dev/null)" = "# wf-ritorno" ] && cp $RO "$RF" 2>/dev/null
rm -f $RO; }
FV=$(. /etc/openwrt_release 2>/dev/null; echo "$DISTRIB_RELEASE $DISTRIB_REVISION"); FP=$(cat /etc/wrtfreedom/fw-prima 2>/dev/null)
[ -n "$FP" ] || FP=$(sed -n 2p /etc/wrtfreedom/pacchetto.ver 2>/dev/null)
PV=$(cat "$RD/VERSION" 2>/dev/null)
KP=1; [ -s /etc/config/wrtfreedom ] || KP=0
SV=$(cat /etc/wrtfreedom/svc.txt 2>/dev/null)
FW="$(t "Firmware aggiornato" "Firmware updated")${FP:+ ($FP → $FV)}"; [ -n "$FP" ] && [ "$FP" = "$FV" ] && FW=$(t "Firmware reinstallato" "Firmware reinstalled")
n=0; rm -f $LG; ( umask 077; : > $LG )
while :; do
[ -f "$RD/install.sh" ] || { rm -rf "$RD"; mkdir -p "$RD" && tar xzf $C -C "$RD" 2>/dev/null; }
[ -f "$RD/install.sh" ] || { r=9; break; }
sh "$RD/install.sh" > $LG 2>&1 </dev/null; r=$?
[ $r = 0 ] && break
case $r in 3|5) [ $n -lt 20 ] || break; n=$((n + 1)); sleep $S2 ;; *) break ;; esac
done
if [ $r != 0 ]; then
m=$(sed -n 's/^## ERRORE //p' $LG 2>/dev/null | tail -n 1)
ev fw_back_err "⚠️ $(t "Aggiornamenti" "Updates") ¦ $FW ¦ $(t "WrtFreedom $PV non rimesso" "WrtFreedom $PV not put back")${m:+ ¦ $m} ¦ $(t "Riprova all'avvio o dall'app" "Retry at start or from app")"
dnsback; rm -rf "$RD"; rm -f $PFX $KC; exit 1
fi
if [ $KP = 1 ]; then m=$(t "Con le sue impostazioni" "With its settings")
else m=$(t "Senza le sue impostazioni" "Without its settings"); fi
evq fw_back "⬆️ $(t "Aggiornamenti" "Updates") ¦ $FW ¦ WrtFreedom $PV $(t "rimesso" "put back") ¦ $m"
pm() { ubus -t 30 call wrtfreedom pkgmissing 2>/dev/null | jsonfilter -e '@.list[*]' 2>/dev/null | tr '\n' ' '; }
M=$(pm); ok=; K=; K2=; SP=; CFG=; MW=
if [ -n "${M% }" ]; then
AP=0; command -v apk >/dev/null 2>&1 && AP=1
if [ $AP = 1 ]; then PU='apk --wait 600 update'; PA='apk --wait 600 add'; else PU='opkg update'; PA='opkg install'; fi
pkrun() { k=0; kd=0; while :; do o=$("$@" 2>&1); r_=$?; echo "$o" >> $LG; [ $r_ = 0 ] && return 0
case "$o" in *"lock database"*|*"Could not lock"*) [ $k -lt 60 ] || return 1; k=$((k + 1)); sleep ${WF_RSLEEP:-5} ;;
*"wget"*|*"unexpected end of file"*|*"Failed to download"*|*"failed to resolve"*) [ $kd -lt 3 ] || return 1; kd=$((kd + 1)); sleep ${WF_RSLEEP:-10} ;;
*) return 1 ;; esac; done; }
L6=$(cat /proc/sys/net/ipv6/conf/lo/disable_ipv6 2>/dev/null); UB=/tmp/wf-ritorno.uci
( umask 077; uci -q show 2>/dev/null | grep -E "^[^=]+='[^']*'$" > $UB )
for f in /etc/init.d/*; do [ -f "$f" ] && echo "${f##*/}"; done > /tmp/wf-ritorno.init
if [ -f $W/mem.uc ]; then
MC=$(ucode $W/mem.uc check adguard </dev/null 2>/dev/null)
[ $? = 1 ] && { MW=1; echo "memoria: poco posto per l'installazione ($MC)" >> $LG; }
fi
i=0; until pkrun $PU; do [ $i -ge 10 ] && break; i=$((i + 1)); sleep $S2; done
MA=$M
if [ $AP = 1 ]; then AV=$(apk list --available $M 2>/dev/null); MA=
for p in $M; do case "$AV" in "$p-"[0-9]*|*"
$p-"[0-9]*) MA="$MA $p" ;; esac; done; fi
JF=0; case "$(awk '$2=="/overlay"{o=$3} $2=="/"{r=$3} END{print o?o:r}' /proc/mounts 2>/dev/null)" in jffs2|ubifs) JF=1 ;; esac
SA=; SB=
pkmib() { $PA --simulate "$@" 2>/dev/null | sed -n 's/^OK: \([0-9.]*\) MiB.*/\1/p' | tail -n 1; }
pkneed() {
if [ $AP = 1 ]; then
[ -n "$SA" ] || SA=$(pkmib)
SB=$(pkmib "$@"); NK=
[ -n "$SA" ] && [ -n "$SB" ] && NK=$(awk -v a="$SA" -v b="$SB" 'BEGIN { d = (b - a) * 1024; print (d > 0 ? int(d) + 1 : 0) }')
else
NK=$($PA --noaction "$@" 2>/dev/null | sed -n 's/^Installing \([^ ]*\) .*/\1/p' | sort -u | while read -r q_; do
opkg info "$q_" 2>/dev/null | awk '/^Installed-Size:/{i=$2} /^Size:/{s=$2} END{print (i ? i : s * 2)}'
done | awk '{t += $1} END {if (NR) print int(t / 1024) + 1}')
fi; }
fits() { FK=$(fk); case "$FK" in ''|*[!0-9]*) SB=; return 0 ;; esac
pkneed "$@"; NK=${NK:-0}; NK=$((NK + NK / 20)); [ $JF = 1 ] && NK=$((NK / 2)); NK=$((NK + 2048)); [ "$FK" -ge "$NK" ]; }
NS=; SEL=
nost() { NS="$NS $1"; echo "spazio: $1 non installato (servono $NK KB, liberi $FK)" >> $LG; }
one() { for p in $SEL; do
if fits "$p"; then pkrun $PA "$p" && SA=$SB || SA=; else nost "$p"; fi; done; }
if [ -n "$MA" ]; then
if fits $MA; then SEL=$MA; else for p in $MA; do if fits $SEL "$p"; then SEL="$SEL $p"; else nost "$p"; fi; done; fi
[ -n "$SEL" ] && { pkrun $PA $SEL || { SA=; one; }; }
fi
K=$(pm); ok=
for p in $M; do case " $K " in *" $p "*) ;; *) ok="$ok $p" ;; esac; done
SP=; K2=
for p in $K; do case " $NS " in *" $p "*) SP="$SP $p" ;; *) K2="$K2 $p" ;; esac; done
[ -n "$L6" ] && [ "$(cat /proc/sys/net/ipv6/conf/lo/disable_ipv6 2>/dev/null)" != "$L6" ] &&
echo "$L6" > /proc/sys/net/ipv6/conf/lo/disable_ipv6 && echo "IPv6 di lo rimesso a $L6" >> $LG
for p in $ok; do if [ $AP = 1 ]; then apk info -L "$p" 2>/dev/null; else opkg files "$p" 2>/dev/null; fi; done > /tmp/wf-ritorno.files
if grep -q 'lib/netifd/proto/' /tmp/wf-ritorno.files; then
/etc/init.d/network restart >/dev/null 2>&1; echo "rete riavviata (tipi di interfaccia nuovi)" >> $LG; sleep ${WF_RSLEEP:-15}
fi
CF=$(sed -n 's#^/\{0,1\}etc/config/\([^/]*\)$#\1#p' /tmp/wf-ritorno.files | sort -u)
IS=$({ sed -n 's#^/\{0,1\}etc/init\.d/\([^/]*\)$#\1#p' /tmp/wf-ritorno.files; [ -f /tmp/wf-ritorno.init ] && for f in /etc/init.d/*; do [ -f "$f" ] && echo "${f##*/}"; done | grep -vxF -f /tmp/wf-ritorno.init; } | sort -u)
for s in $IS; do
[ -x /etc/init.d/$s ] || continue
p=$(printf '%s\n' "$SV" | awk -v s="$s" '$1 == s { print $2; exit }'); [ -n "$p" ] || continue
if /etc/init.d/$s enabled 2>/dev/null; then e=1; else e=0; fi
[ "$p" = "$e" ] && continue
if [ "$p" = 0 ]; then /etc/init.d/$s stop >/dev/null 2>&1; /etc/init.d/$s disable >/dev/null 2>&1; echo "spento com'era prima: $s" >> $LG
else /etc/init.d/$s enable >/dev/null 2>&1; /etc/init.d/$s start >/dev/null 2>&1; echo "riacceso com'era prima: $s" >> $LG; fi
done
RC=
for c in $CF; do
case $c in dhcp|network|firewall|wireless|system|dropbear|uhttpd|rpcd|wrtfreedom) continue ;; esac
( umask 077; uci -q show "$c" 2>/dev/null | grep -E "^[^=]+='[^']*'$" | awk -v B=$UB -v U=/tmp/wf-ritorno.undo.$c '
				BEGIN { while ((getline l < B) > 0) { i = index(l, "="); b[substr(l, 1, i - 1)] = substr(l, i + 1) } }
				{ i = index($0, "="); k = substr($0, 1, i - 1); v = substr($0, i + 1)
				  if ((k in b) && b[k] != v) { print k "=" substr(b[k], 2, length(b[k]) - 2); print k "=" substr(v, 2, length(v) - 2) > U } }' > /tmp/wf-ritorno.set )
[ -s /tmp/wf-ritorno.set ] || { rm -f /tmp/wf-ritorno.undo.$c; continue; }
while IFS= read -r l; do uci set "$l" && echo "rimesso ${l%%=*}" >> $LG; done < /tmp/wf-ritorno.set
uci commit "$c"; RC="$RC $c"
done
for s in $IS; do
[ -x /etc/init.d/$s ] && grep -q 'USE_PROCD=1' /etc/init.d/$s && /etc/init.d/$s enabled 2>/dev/null || continue
case $s in adguardhome|AdGuardHome) [ -f /etc/wrtfreedom/dnsfb.state ] && continue ;; esac
u=$s; [ -f /etc/config/$s ] || u=$(sed -n 's/.*config_load[ "]*\([A-Za-z0-9_-]*\).*/\1/p' /etc/init.d/$s | head -n 1); u=${u:-$s}
case " $RC " in *" $u "*) ;; *) ubus call service list "{\"name\":\"$s\"}" 2>/dev/null |
jsonfilter -e '@[*].instances[*].running' 2>/dev/null | grep -qx false || continue ;; esac
/etc/init.d/$s restart >/dev/null 2>&1 && echo "riavviato $s" >> $LG
[ -f /tmp/wf-ritorno.undo.$u ] || continue
sleep ${WF_RSLEEP:-10}; /etc/init.d/$s running >/dev/null 2>&1 && continue
while IFS= read -r l; do uci set "$l"; done < /tmp/wf-ritorno.undo.$u
uci commit "$u"; /etc/init.d/$s restart >/dev/null 2>&1; echo "valori del pacchetto nuovo rimessi per $s" >> $LG
CFG="$CFG $s"; evq pkg_back_cfg "⚠️ $(t "Aggiornamenti" "Updates") ¦ $s ¦ $(t "Vecchie impostazioni scartate ¦ Usa quelle del pacchetto ¦ Controllale" "Old settings dropped ¦ Using the package ones ¦ Check them")"
done
rm -f $UB /tmp/wf-ritorno.files /tmp/wf-ritorno.init /tmp/wf-ritorno.set /tmp/wf-ritorno.undo.*
[ -n "$ok" ] && evq pkg_back "⬆️ $(t "Aggiornamenti ¦ Pacchetti reinstallati ¦ Dopo il firmware:" "Updates ¦ Packages reinstalled ¦ After the firmware:")$ok"
[ -n "$K2" ] && evq pkg_back_err "⚠️ $(t "Aggiornamenti ¦ Pacchetti non reinstallati ¦" "Updates ¦ Packages not reinstalled ¦")$K2 ¦ $(t "Riprova dall'app: Reinstalla" "Retry in the app: Reinstall")"
FK=$(fk)
[ -n "$SP" ] && evq pkg_back_err "⚠️ $(t "Aggiornamenti ¦ Non reinstallati: spazio ¦" "Updates ¦ Not reinstalled: space ¦")$SP ¦ $(t "Liberi $FK KB: libera spazio ¦ Poi Pacchetti Da Reinstallare" "$FK KB free: free some space ¦ Then Packages To Reinstall")"
fi
[ -f $W/lib.sh ] && sh $W/lib.sh port80 >> $LG 2>/dev/null </dev/null
[ -f $W/nasvc.sh ] && sh $W/nasvc.sh spare >/dev/null 2>&1 </dev/null
dnsback
FS=/etc/wrtfreedom/dnsfb.state
if [ -f $FS ] && [ -f $W/adgmode.sh ]; then
sed -i "s/^NEXT=.*/NEXT='0'/" $FS; sh $W/adgmode.sh check >/dev/null 2>&1
[ -f $FS ] && echo "AdGuard non ancora pronto: lo riprova adgmode" >> $LG || echo "AdGuard rimesso subito" >> $LG
fi
[ -f $W/mem.uc ] && ucode $W/mem.uc apply </dev/null >/dev/null 2>&1
N=$(echo $ok | wc -w)
if [ $N -eq 1 ]; then B="WrtFreedom $PV $(t "e 1 pacchetto tornati" "and 1 package back")"; elif [ $N -gt 1 ]; then B="WrtFreedom $PV $(t "e $N pacchetti tornati" "and $N packages back")"; else B="WrtFreedom $PV $(t "tornato" "back")"; fi
if [ $KP = 1 ]; then B="$B ¦ $(t "Impostazioni tenute" "Settings kept")"; else B="$B ¦ $(t "Impostazioni di serie" "Default settings")"; fi
X=
[ -n "$K2" ] && X="$X ¦ ❌ $(t "Non tornati:" "Not back:")$K2"
[ -n "$SP" ] && X="$X ¦ ❌ $(t "Senza spazio:" "No space:")$SP ($FK KB)"
[ -n "$CFG" ] && X="$X ¦ $(t "Da controllare:" "To check:")$CFG"
[ -n "$MW" ] && [ -n "$K2$SP" ] && X="$X ¦ $(t "Poca memoria libera durante l'installazione" "Low free memory while installing")"
[ -f $FS ] && X="$X ¦ $(t "AdGuard non ancora pronto" "AdGuard not ready yet")"
if [ -n "$X" ]; then ev fw_done "⚠️ $(t "Aggiornamenti" "Updates") ¦ $FW ¦ $B$X"; else ev fw_done "⬆️ $(t "Aggiornamenti" "Updates") ¦ $FW ¦ $B"; fi
rm -f /etc/wrtfreedom/fw-prima $PFX $KC; rm -rf "$RD"
;;
*)
echo "uso: upd.sh check|safe|follow|install|local|notify|status|ritorno"; exit 1 ;;
esac
