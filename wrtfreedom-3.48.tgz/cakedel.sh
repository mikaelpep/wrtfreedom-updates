LOG() { echo "## $*"; }
/etc/init.d/cake-autorate stop 2>/dev/null; /etc/init.d/cake-autorate disable 2>/dev/null
rm -rf /var/run/cake-autorate
rm -rf /root/cake-autorate /etc/init.d/cake-autorate /etc/rc.d/*cake-autorate
sed -i '\#^/root/cake-autorate/$#d;\#^/etc/init.d/cake-autorate$#d' /etc/sysupgrade.conf 2>/dev/null
LOG "OK cake-autorate rimosso"
