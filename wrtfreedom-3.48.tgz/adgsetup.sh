J=/tmp/.wf-adgset.json; N=/tmp/.wf-adgnew; C=/etc/wrtfreedom/adguard
LOG() { echo "## $*"; }
fail() { LOG "ERRORE $*"; rm -f "$J" "$N"; exit 1; }
if ! command -v curl >/dev/null 2>&1; then
LOG "Installo curl"
{ command -v apk >/dev/null && apk add curl; } >/dev/null 2>&1 || { opkg update && opkg install curl; } >/dev/null 2>&1 || fail "curl non disponibile: il router è collegato a internet?"
fi
A=; for s in adguardhome AdGuardHome; do [ -x /etc/init.d/$s ] && { A=$s; break; }; done
[ -n "$A" ] || fail "servizio di AdGuard Home non trovato: è installato?"
/etc/init.d/$A enabled 2>/dev/null || /etc/init.d/$A enable
MU=/usr/share/wrtfreedom/mem.uc
if [ -f $MU ]; then
MC=$(ucode $MU check adguard 2>/dev/null)
if [ $? = 1 ]; then
mb() { v_=$(echo "$MC" | jsonfilter -e "@.$1" 2>/dev/null); case "${v_#-}" in ''|*[!0-9]*) echo '?' ;; *) echo $((v_ / 1024)) ;; esac; }
LOG "ATTENZIONE poca memoria libera: con AdGuard restano circa $(mb dopo) MB, sotto la riserva di $(mb ris) MB: il router può rallentare (se serve spegni un servizio pesante)"
fi
fi
pidof AdGuardHome adguardhome >/dev/null || { LOG "Avvio AdGuard"; /etc/init.d/$A start; sleep 5; }
[ -f $MU ] && ucode $MU apply </dev/null >/dev/null 2>&1
WIZ=
for p in 3000 80 8080; do
[ "$(curl -s -m 4 -o /dev/null -w '%{http_code}' http://127.0.0.1:$p/control/install/get_addresses)" = 200 ] && { WIZ=$p; break; }
done
[ -n "$WIZ" ] || fail "la configurazione iniziale di AdGuard non risponde (è già configurato?)"
WEB=8080
for p in 8080 8081 8088 3001; do netstat -tln 2>/dev/null | grep -q ":$p " || { WEB=$p; break; }; done
DNS=
for p in 3053 5335 15353; do h=$(printf '%04X' $p); grep -qi ":$h " /proc/net/udp /proc/net/udp6 /proc/net/tcp /proc/net/tcp6 2>/dev/null || { DNS=$p; break; }; done
[ -n "$DNS" ] || fail "nessuna porta libera per il DNS di AdGuard"
for lb_f in /usr/share/wrtfreedom/lib.sh "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
homenet >/dev/null; LAN=$HN_IP
D=$(uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=dnsmasq$/\1/p" | head -n 1); [ -n "$D" ] || fail "dnsmasq non trovato"
BK=${WF_BAKDIR:-/etc/wrtfreedom/bak}/adgs
rm -rf "$BK"; mkdir -p "$BK" || fail "copia di dhcp non riuscita (spazio pieno?)"
printf '[ -f %s/ok ] || { rm -rf %s; exit 0; }\ncp %s/dhcp /etc/config/dhcp\nrm -rf %s\n/etc/init.d/dnsmasq restart\n' "$BK" "$BK" "$BK" "$BK" > "$BK/back.sh"
cp /etc/config/dhcp "$BK/dhcp" && : > "$BK/ok" || { rm -rf "$BK"; fail "copia di dhcp non riuscita (spazio pieno?)"; }
LOG "Configuro AdGuard: pannello sulla porta $WEB, DNS su 127.0.0.1:$DNS"
sed -i "s/\"__WEB__\"/$WEB/; s/\"__DNS__\"/$DNS/" "$J"
R=$(curl -s -m 25 -w '\n%{http_code}' -X POST -H 'Content-Type: application/json' --data-binary @"$J" http://127.0.0.1:$WIZ/control/install/configure)
rm -f "$J"
rollback() { /etc/init.d/$A stop; sh "$BK/back.sh"; }
case "$R" in *200) ;; *) rm -rf "$BK"; fail "AdGuard ha rifiutato la configurazione: $(echo "$R" | head -n 1)" ;; esac
sleep 4
LOG "Server DNS di AdGuard e nomi inversi da dnsmasq"
( umask 077; printf 'user = %s\n' "$(wf_curlq "$(cat "$N")")" > /tmp/.wf-adgc )
DC=$(curl -s -m 15 -K /tmp/.wf-adgc -o /dev/null -w '%{http_code}' -X POST -H 'Content-Type: application/json' \
	--data '{"upstream_dns":["https://dns10.quad9.net/dns-query"],"bootstrap_dns":["9.9.9.10","149.112.112.10"],"local_ptr_upstreams":["127.0.0.1:53"],"use_private_ptr_resolvers":true}' \
	http://127.0.0.1:$WEB/control/dns_config)
rm -f /tmp/.wf-adgc
[ "$DC" = 200 ] || LOG "ATTENZIONE AdGuard non ha preso i server DNS sicuri e i nomi di casa (risposta ${DC:-nessuna}): impostali dal suo pannello"
LOG "dnsmasq inoltra ad AdGuard (127.0.0.1#$DNS)"
uci -q delete dhcp.$D.port
for s in $(uci -q get dhcp.$D.server); do case "$s" in 127.0.0.1#*|::1#*) uci -q del_list dhcp.$D.server="$s" ;; esac; done
uci add_list dhcp.$D.server="127.0.0.1#$DNS"; uci set dhcp.$D.noresolv=1
uci commit dhcp; /etc/init.d/dnsmasq restart; sleep 2
LOG "Verifico che il DNS risponda"
ok=0; for _ in 1 2 3 4 5; do nslookup openwrt.org 127.0.0.1 >/dev/null 2>&1 && { ok=1; break; }; sleep 2; done
if [ $ok = 1 ]; then mkdir -p /etc/wrtfreedom; mv "$N" "$C"; chmod 600 "$C"; adgyaml >/dev/null 2>&1; LOG "OK pannello $LAN:$WEB"; rm -rf "$BK"
else rollback; fail "il DNS di AdGuard non risponde: ho rimesso tutto com'era"; fi
