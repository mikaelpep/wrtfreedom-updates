'use strict';
function cloudst(S, M) {
let st = type(M) == 'object' && match('' + M.st, /^(on|wait|err|off)$/) ? M.st : 'off';
if (type(S) != 'object' || S.on !== true) return 'off';
return st == 'off' ? 'wait' : st;
}
function smbsec(P, cf, rd) {
let r = null;
for (let e in [ [ 'smbd', 'samba4', '/etc/samba/smb.conf.template' ], [ 'ksmbd.mountd', 'ksmbd', '/etc/ksmbd/ksmbd.conf.template' ] ]) {
if (type(P) != 'object' || !P[e[0]]) continue;
r = r ?? {};
let C = cf(e[1]), pm = false;
for (let k, o in (type(C) == 'object' ? C : {})) if (match(k, /^wf_/) && type(o) == 'object' && o.name != null && o.path != null) r['' + o.name] = true;
for (let l in split(rd(e[2]) ?? '', '\n')) { let m = pm ? match(l, /^\[(.+)\]$/) : null; if (m) r[m[1]] = true; pm = l == '# wf-nas'; }
}
return r;
}
function cloudsmb(t) {
let r = [];
for (let l in split('' + (t ?? ''), '\n')) {
let c = split(l, '|');
if (length(c) < 4 || !match(c[0], /^wfcloud_/) || !length(c[1])) continue;
push(r, { name: c[1], users: filter(split(c[3], ' '), length), hidden: c[6] == '1' });
}
return r;
}
function live(NC, here, C, smb, rd, FX, sm) {
let r = [], S = type(C?.share) == 'object' ? C.share : {}, sec = type(smb) == 'object' ? smb : null;
if (type(NC) != 'object' || NC.on !== true || !smb) return r;
if (type(here) != 'object') here = {};
let F = type(FX) == 'array' ? FX : (type(NC.shares) == 'array' ? NC.shares : []);
if (NC.smb_off !== true) for (let s in F)
if (type(s) == 'object' && !s.cam && s.kind != 'cam' && here['' + s.disk] === true && (!sec || sec['' + (s.name ?? '')] === true) && index(r, '' + (s.name ?? '')) < 0) push(r, '' + (s.name ?? ''));
for (let id in sort(keys(S))) if (match(id, /^a[0-9]{1,3}$/) && cloudst(S[id], rd(id)) == 'on') {
let n = '' + (S[id].name ?? id);
push(r, n);
if (type(sm) == 'function') for (let x in cloudsmb(sm(id))) if (index(r, x.name) < 0) push(r, x.name);
}
return r;
}
return {
img: [ 'jpg', 'jpeg', 'png', 'heic', 'heif', 'gif', 'webp', 'raw', 'cr2', 'nef', 'arw', 'dng' ],
vid: [ 'mp4', 'mov', 'mkv', 'avi', 'm4v', '3gp', 'webm', 'ts', 'wmv', 'mpg', 'mpeg', 'mts', 'm2ts' ],
mus: [ 'mp3', 'flac', 'm4a', 'aac', 'ogg', 'wav', 'opus', 'wma' ],
doc: [ 'pdf', 'doc', 'docx', 'odt', 'txt', 'rtf', 'xls', 'xlsx', 'ods', 'csv', 'ppt', 'pptx', 'odp', 'key', 'pages', 'numbers', 'md', 'epub' ],
arc: [ 'zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'iso', 'img' ],
app: [ 'exe', 'msi', 'apk', 'dmg', 'pkg', 'deb', 'appimage' ],
imgweb: [ 'jpg', 'jpeg', 'png', 'gif', 'webp' ],
smbp: [ 'ksmbd.mountd', 'smbd' ],
cloudst: cloudst,
smbsec: smbsec,
cloudsmb: cloudsmb,
live: live
};
