'use strict';
import { readfile, writefile, unlink, stat, lstat, rename, mkdir, rmdir, lsdir, popen, open, readlink } from 'fs';

const W = '/usr/share/wrtfreedom', DATI = W + '/custode/funzioni.json', ST = '/tmp/wf-custode.json', HI = '/tmp/wf-custode.hist';
const LK = '/tmp/wf-custode.lock', BATT = '/tmp/wf-batt', CFG = '/etc/config/', NET = '/sys/class/net/', FWL = '/tmp/wf-fw.lock';
const FWOK = '/tmp/wf-custode.fwok';
const FWC = '/tmp/wf-custode.fw4.json';
const AGIS = '/tmp/wf-agisce', CULN = '/tmp/wf-custode.linea';
const RECON = '/tmp/wf-wd.recon';
const VPNNV = '/tmp/wf-custode.vpnnv';
const EVT = '/tmp/wf-events.log', EVS = '/etc/wrtfreedom/events.save', WANT = '/tmp/wf-want/';
const EVP = '/etc/wrtfreedom/events.log', EVOK = '/tmp/wf-events.ok';
const EVA = '/etc/wrtfreedom/events.add', EVM = '/tmp/wf-events.sv', EVDAY = 86400, EVAMAX = 500;
const HMAX = 50, EVMAX = 500, EVEVERY = 3600, VPNIFRX = /^wgo(ut|[0-9]+)$/, IFRX = /^[A-Za-z0-9_.-]{1,32}$/, IDRX = /^[a-z][a-z0-9_]{1,23}$/;
const ESPT = '/tmp/wf-custode.esp.json', ESPD = '/etc/wrtfreedom/custode', ESP = ESPD + '/esperienza.json', ESAVE = 21600;
const SPIA = '/tmp/wf-custode.spia', LEDS = '/sys/class/leds/', LSAVE = '/tmp/wf-leds.save', LEDRX = /^[A-Za-z0-9:_.-]{1,64}$/;
const TGQ = '/tmp/wf-tgq', TGQS = ESPD + '/tgq', VERF = W + '/VERSION';
const SCARTO = 5, MAX24 = 12, RITW = 90, ORA_GIORNO = 9;
const ULT = '/tmp/wf-custode.ult.json', CRF = '/etc/crontabs/root', CRT = '/tmp/wf-custode.cron', CRS = ESPD + '/cron.save';
const CRMINE = '/tmp/wf-cron.mine', TGOK = '/tmp/wf-tg.ok', DDMK = '/tmp/wf-custode.ddns';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wjs(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function cutn(s, n) { s = '' + s; if (length(s) <= n) return s; while (n > 0 && (ord(s, n) & 192) == 128) n--; return substr(s, 0, n); }
function upsec() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
function dur(s) { s = s < 0 ? 0 : s; return s < 60 ? s + ' s' : s < 3600 ? int(s / 60) + ' min' : int(s / 3600) + ' h ' + int(s % 3600 / 60) + ' min'; }
function ev(tp, txt, quiet) {
sh('( ' + (quiet ? 'WF_Q=1 ' : '') + 'sh ' + W + '/event.sh cron ' + q('custode_' + tp) + ' custode ' + q(txt) + ' ) >/dev/null 2>&1 </dev/null &');
}
function cuh(X, e, s, R) { return (e ?? '🛡️') + ' ' + join(' ¦ ', [ s ?? X.L(['Custode', 'Guardian']), ...filter(R, (r) => length(r)) ]); }
function cap(s) { s = '' + (s ?? ''); return uc(substr(s, 0, 1)) + substr(s, 1); }

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function ucread(name) { return UCFG.read(CFG + name, true); }
function ulist(v) { return type(v) == 'array' ? v : filter(split('' + (v ?? ''), /[ \t]+/), length); }

function ctx() {
let X = { now: time(), up: upsec(), C: {}, D: null };
let lt = localtime(X.now);
X.h = lt.hour; X.giorno = sprintf('%04d-%02d-%02d', lt.year, lt.mon, lt.mday);
X.cfg = (n) => X.C[n] = X.C[n] ?? ucread(n);
X.en = X.cfg('wrtfreedom').ui?.lang == 'en';
X.L = (p) => type(p) == 'array' ? (X.en ? p[1] : p[0]) : '' + (p ?? '');
X.dump = () => {
if (X.D != null) return X.D;
let r = null;
if (X.U == null) { try { X.U = require('ubus').connect() ?? false; } catch (e) { X.U = false; } }
if (X.U) { try { r = X.U.call('network.interface', 'dump'); } catch (e) { r = null; } }
if (r == null) { try { r = json(sh('ubus call network.interface dump 2>/dev/null') || 'null'); } catch (e) { r = null; } }
X.D = {};
for (let i in (type(r?.interface) == 'array' ? r.interface : [])) if (type(i) == 'object' && length(i.interface ?? '')) X.D[i.interface] = i;
return X.D;
};
return X;
}
function on1(v) { return index(['1', 'on', 'true', 'yes', 'enabled'], '' + (v ?? '')) >= 0; }
function ifoff(X, i) {
let N = X.cfg('network')[i] ?? {};
if (index(['1', 'on', 'true', 'yes', 'enabled'], N.disabled ?? '') >= 0 || index(['0', 'false', 'no', 'off'], N.auto ?? '') >= 0) return true;
if (stat('/tmp/wf-ifdown.' + i)) return true;
return X.dump()[i]?.autostart === false;
}
function fwbusy(X) { let s = stat(FWL); return s != null && X.now - s.mtime < 120; }
function batt(X, g) { let b = +trim(readfile(BATT + '/' + g) ?? ''); return b > 0 ? X.now - b : null; }

function linemain(X, li) {
let W = X.cfg('wrtfreedom'), fo = W.fo ?? {}, m = null, mm = null;
if (fo.enabled == '1' && length(fo.main ?? '') && fo.main != fo.backup) m = fo.main;
else {
let N = X.cfg('network');
for (let k, z in X.cfg('firewall')) {
if (z['.type'] != 'zone' || !on1(z.masq) || z.name == 'vpnout') continue;
for (let i in ulist(z.network)) {
let I = N[i];
if (type(I) != 'object' || I['.type'] != 'interface' || !match(i, IFRX) || match(i, VPNIFRX)) continue;
if (index(['none', 'dhcpv6', 'wireguard', '6in4', '6to4', '6rd'], I.proto ?? '') >= 0) continue;
if (index(['1', 'on', 'true', 'yes', 'enabled'], I.disabled ?? '') >= 0) continue;
let me = match('' + (I.metric ?? ''), /^[0-9]{1,9}$/) ? +I.metric : 0;
if (mm == null || me < mm) { m = i; mm = me; }
}
}
}
return (m && match(m, IFRX) && !ifoff(X, m)) ? m : li;
}
function s_linea(X) {
let b = batt(X, 'line');
if (b == null || b > 90) return { s: 'ko', sin: 'fermo' };
let J = rjs('/tmp/wf-line.json');
if (type(J) != 'object') return { s: 'wait' };
let li = '' + (J.li ?? '');
if (J.ok !== false) return { s: 'ok', obj: li };
if (!length(li) && !length(J.dev ?? '')) return { s: 'none' };
if (length(li) && ifoff(X, li)) return { s: 'off', obj: li };
let o = linemain(X, li);
return { s: 'ko', sin: 'giu', obj: match('' + o, IFRX) ? o : null };
}
function s_firewall(X) {
if (!stat('/sbin/fw4') || !stat('/etc/init.d/firewall')) return { s: 'none' };
if (!length(filter(lsdir('/etc/rc.d') ?? [], (f) => match(f, /^S[0-9]{1,3}firewall$/)))) return { s: 'off' };
if (fwbusy(X)) return { s: 'wait' };
let C = rjs(FWC), cs = stat(FWC), cm = 0, t = null;
for (let f in [CFG + 'firewall', '/etc/nftables.d', '/usr/share/nftables.d', FWOK]) { let s = stat(f); if (s && s.mtime > cm) cm = s.mtime; }
if (cs && type(C?.n) == 'array' && X.now - cs.mtime < 300 && cs.mtime > cm && cs.mtime <= X.now + 60) t = join('\n', C.n);
else {
let o = sh('nft -t list table inet fw4 2>/dev/null');
if (!length(o)) { unlink(FWC); return { s: 'ko', sin: 'giu' }; }
t = join('\n', map(match(o, /"!fw4: [^"]*"/g) ?? [], (x) => x[0]));
wjs(FWC, { n: split(t, '\n') });
}
let fo = split(trim(readfile(FWOK) ?? ''), ' '), ok = fo[1] == 'porte' ? +fo[0] : 0, cf = stat(CFG + 'firewall')?.mtime ?? 0;
for (let k, r in X.cfg('firewall')) {
if (r['.type'] != 'redirect' || index(['0', 'false', 'no', 'off'], r.enabled ?? '1') >= 0 || (r.target ?? 'DNAT') != 'DNAT') continue;
let n = '' + (r.name ?? '');
if (!match(n, /^[A-Za-z0-9 _.:+-]{1,64}$/)) continue;
if (index(t, '"!fw4: ' + n + '"') < 0) return { s: 'ko', sin: 'porte', det: n, nofix: ok > 0 && ok >= cf };
}
return { s: 'ok' };
}
function s_vpnsrv(X) {
let N = X.cfg('network'), ifc = null;
for (let k, s in N) if (s['.type'] == 'interface' && s.proto == 'wireguard' && !match(k, VPNIFRX) && length(s.listen_port ?? '')) { ifc = k; break; }
if (!ifc) return { s: 'none' };
if (!length(keys(X.dump()))) return { s: 'wait', obj: ifc };
if (ifoff(X, ifc)) return { s: 'off', obj: ifc };
let d = X.dump()[ifc], V = rjs('/tmp/wf-vpnwd.json');
if (d?.pending === true || (d?.up === true && +(d.uptime ?? 0) < 60)) return { s: 'wait', obj: ifc };
if (+(V?.p ?? 0) > 0 && X.now - V.p < 120) return { s: 'wait', obj: ifc };
if (d?.up === true && stat(NET + (d.l3_device ?? d.device ?? ifc))) return { s: 'ok', obj: ifc };
return { s: 'ko', sin: 'giu', obj: match(ifc, IFRX) ? ifc : null };
}
function s_vpncli(X) {
let C = X.cfg('wrtfreedom'), T = [], any = false;
for (let k, s in C) if (s['.type'] == 'vpntun') { any = true; if (s.on != '0') push(T, { id: k, n: +(s.n ?? 0) }); }
if (!any) { unlink(VPNNV); return { s: 'none' }; }
if (!length(T) || +(C.vpnout?.pause_until ?? 0) > X.now) { unlink(VPNNV); return { s: 'off' }; }
let S = rjs('/tmp/wf-vpn.json') ?? {};
if (!(+(S._at ?? 0) > 0) || X.now - S._at > 600) return { s: 'ko', sin: 'fermo' };
let M = rjs(VPNNV), N = {}, nv = false;
if (type(M) != 'object') M = {};
for (let x in T) if (type(S[x.id]) != 'object' && !ifoff(X, x.n == 0 ? 'wgout' : 'wgo' + x.n)) {
let t = +(M[x.id] ?? 0);
N[x.id] = t > 0 && t <= X.now + 60 ? t : X.now;
if (X.now - N[x.id] > 600) nv = true;
}
if (sprintf('%J', N) != sprintf('%J', M)) { if (length(keys(N))) wjs(VPNNV, N); else unlink(VPNNV); }
let st = 'off';
for (let x in sort(T, (a, b) => a.n - b.n)) {
let s = S[x.id];
if (type(s) != 'object') continue;
if (s.down === true) return { s: 'ko', sin: 'giu', obj: x.n == 0 ? 'wgout' : 'wgo' + x.n };
st = 'ok';
}
return nv ? { s: 'ko', sin: 'fermo' } : { s: st };
}
function s_limiti(X) {
let R = rjs('/etc/wrtfreedom/shaper.json'), act = 0, tm = 0;
if (type(R) != 'array') return { s: 'none' };
for (let r in R) {
if (type(r) != 'object' || r.meta != null) continue;
if (r.off === true || (r.until != null && !(+r.until > X.now))) continue;
act++;
if (r['from'] != null || r.to != null || length('' + (r.days ?? '')) || r.until != null) tm++;
}
if (!act) return { s: length(filter(R, (r) => type(r) == 'object' && r.meta == null)) ? 'off' : 'none' };
if (stat('/etc/wrtfreedom/shaper.bak') || fwbusy(X)) return { s: 'wait' };
if (!stat('/etc/nftables.d/90-wrtfreedom.nft')) return { s: 'ko', sin: 'file' };
let D = rjs('/tmp/wf-dev.json') ?? {};
if (+(D.nfe ?? 0) >= 3) return { s: 'ko', sin: 'nft' };
if (tm && X.now - +(D.shp?.t ?? 0) > 300) return { s: 'ko', sin: 'fermo' };
return { s: 'ok' };
}

function fresh(X, f, sec) { let s = stat(f); return s != null && X.now - s.mtime < sec && s.mtime <= X.now + 60; }
function ubq(X, o, m, a) {
if (X.U == null) { try { X.U = require('ubus').connect() ?? false; } catch (e) { X.U = false; } }
let r = null;
if (X.U) { try { r = X.U.call(o, m, a ?? {}); } catch (e) { r = null; } }
if (r == null) { try { r = json(sh('ubus call ' + o + ' ' + m + (a ? ' ' + q(sprintf('%J', a)) : '') + ' 2>/dev/null') || 'null'); } catch (e) { r = null; } }
return r;
}
function inst(X, n) {
X.P = X.P ?? {};
if (exists(X.P, n)) return X.P[n];
let r = ubq(X, 'service', 'list', { name: n });
return X.P[n] = type(r) != 'object' ? null : type(r[n]?.instances) == 'object' ? r[n].instances : {};
}
function running(I) { return length(filter(values(I ?? {}), (i) => i?.running === true)) > 0; }
function rcon(n) { let re = regexp('^S[0-9]{1,3}' + n + '$'); return length(filter(lsdir('/etc/rc.d') ?? [], (f) => match(f, re))) > 0; }
const TMO = stat('/usr/bin/timeout') || stat('/bin/timeout') ? 'timeout 3 ' : '';

function bandname(b) { return b == '2g' ? '2,4 GHz' : b == '5g' ? '5 GHz' : b == '6g' ? '6 GHz' : b == '60g' ? '60 GHz' : null; }
function wap(m) { return '' + (m ?? 'ap') == 'ap'; }
function s_wifi(X) {
let C = X.cfg('wireless'), R = filter(sort(keys(C)), (k) => C[k]['.type'] == 'wifi-device');
if (!length(R)) return { s: 'none' };
for (let k in ['restart', 'chan', 'wps']) if (fresh(X, '/tmp/wf-wifi.' + k + '.lock', 180)) return { s: 'wait' };
let cac = rjs('/tmp/wf-wifi.cac');
if (type(cac) == 'object' && cac.done === false && +(cac.end ?? 0) + 30 > X.now) return { s: 'wait' };
let W = ubq(X, 'network.wireless', 'status');
if (type(W) != 'object') return { s: 'wait' };
let on = 0;
for (let r in R) {
if (on1(C[r].disabled)) continue;
let V = filter(values(C), (s) => s['.type'] == 'wifi-iface' && s.device == r && !on1(s.disabled) && wap(s.mode));
if (!length(V)) continue;
let d = W[r], o = match(r, IFRX) ? r : null, bn = bandname(C[r].band ?? '');
if (type(d) == 'object' && d.autostart === false) continue;
on++;
if (type(d) != 'object' || (d.up !== true && d.pending !== true)) return { s: 'ko', sin: 'radio', obj: o, det: bn };
if (d.pending === true) return { s: 'wait' };
let up = filter(type(d.interfaces) == 'array' ? d.interfaces : [], (i) => match('' + (i?.ifname ?? ''), IFRX) && stat(NET + i.ifname) && wap(i.config?.mode));
if (length(up) < length(V)) {
let ss = map(up, (i) => '' + (i.config?.ssid ?? '')), m = filter(V, (s) => index(ss, '' + (s.ssid ?? '')) < 0)[0];
return { s: 'ko', sin: 'rete', obj: o, det: m && length(m.ssid ?? '') ? substr(m.ssid, 0, 32) : bn };
}
}
return { s: on ? 'ok' : 'off' };
}

function adginit() { for (let s in ['adguardhome', 'AdGuardHome']) if (stat('/etc/init.d/' + s)) return s; return null; }
function adgdns() {
let y = trim(readfile('/tmp/wf-adgyaml') ?? '');
if (!match(y, /^\/[^ ]{1,200}$/)) return null;
let d = false, bh = false, port = null, H = [];
for (let l in split(readfile(y) ?? '', '\n')) {
if (match(l, /^[^ #]/)) { d = match(l, /^dns:/) != null; bh = false; continue; }
if (!d) continue;
let m = match(l, /^  port:[ \t]*([0-9]{1,5})[ \t]*$/);
if (m) { port = +m[1]; bh = false; continue; }
if (match(l, /^  bind_hosts:/)) { bh = true; continue; }
m = bh ? match(l, /^ {2,4}- *['"]?([0-9a-fA-F.:]{2,45})/) : null;
if (m) { push(H, m[1]); continue; }
if (match(l, /^  [a-z]/)) bh = false;
}
if (!(port > 0 && port < 65536)) return null;
if (!length(H) || index(H, '127.0.0.1') >= 0 || index(H, '0.0.0.0') >= 0 || index(H, '::') >= 0) return '127.0.0.1:' + port;
let v4 = filter(H, (h) => match(h, /^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/))[0];
return v4 ? v4 + ':' + port : null;
}
const DNSF = '/tmp/wf-custode.dns', DNSL = '/tmp/wf-custode.dns.lock';
function dnsans(o) { return match(o, /@rc=0/) != null || match(o, /can't find|NXDOMAIN|SERVFAIL|REFUSED/) != null; }
function dnsok(a) {
let now = time(), s = stat(DNSF), l = stat(DNSL), r = null;
if (s && now - s.mtime < 180 && s.mtime <= now + 60) {
let t = readfile(DNSF) ?? '', i = index(t, '\n');
if (i > 0 && substr(t, 0, i) == a) r = dnsans(substr(t, i + 1));
}
if (l && (now - l.mtime >= 300 || l.mtime > now + 60)) { rmdir(DNSL); l = null; }
if (l && now - l.mtime >= 60) return false;
if (!l && mkdir(DNSL))
sh('( { echo ' + q(a) + '; ' + TMO + 'nslookup openwrt.org ' + q(a) + ' 2>&1; echo "@rc=$?"; } > ' + DNSF + '.t; mv -f ' + DNSF + '.t ' + DNSF + '; rmdir ' + DNSL + ' ) >/dev/null 2>&1 </dev/null &');
return r;
}
function s_adg(X) {
let A = adginit();
if (!A) return { s: 'none' };
if (!rcon(A)) return { s: 'off' };
if (stat('/etc/wrtfreedom/adgmode.new') || stat('/tmp/wf-adgmode.pend') || fresh(X, '/tmp/wf-adgmode.lock', 300)) return { s: 'wait' };
let fb = readfile('/etc/wrtfreedom/dnsfb.state');
if (fb != null) {
if (index(fb, "US='1'") >= 0) return { s: 'off' };
let t = +(match(fb, /T='([0-9]{1,12})'/)?.[1] ?? 0);
return t > 0 && X.now - t < 1800 && t <= X.now + 60 ? { s: 'wait' } : { s: 'ko', sin: 'riserva' };
}
let I = inst(X, A);
if (I == null) return { s: 'wait' };
if (!length(keys(I))) return { s: 'off' };
if (!running(I)) return { s: 'ko', sin: 'giu' };
if (X.cfg('wrtfreedom').dnsfb?.on == '1') return { s: stat('/tmp/wf-dnsfb.n') ? 'wait' : 'ok' };
let a = adgdns(), r = a ? dnsok(a) : true;
if (r == null) return { s: 'wait' };
if (!r) return { s: 'ko', sin: 'dns' };
return { s: 'ok' };
}

function s_ddns(X) {
if (!stat('/etc/init.d/ddns')) return { s: 'none' };
let D = X.cfg('ddns'), S = filter(values(D), (s) => s['.type'] == 'service');
if (!length(S)) return { s: 'none' };
if (!length(filter(S, (s) => s.enabled == '1'))) return { s: 'off' };
let J = rjs('/tmp/wf-ddnsname.json'), t = +(J?.t ?? 0), age = t > 0 && t <= X.now + 60 ? X.now - t : null;
let dm = stat(DDMK), lip = '' + (J?.line?.ip ?? ''), lif = '' + (J?.line?.ifc ?? '');
let cg = J?.cgnat === true && age != null && length(lip) > 0 && length(lif) > 0 && (X.dump()[lif]?.['ipv4-address'] ?? [])[0]?.address == lip;
let mx = cg ? 10800 : 1800;
if ((age == null || age > mx) && !(dm && X.now - dm.mtime < 600 && dm.mtime <= X.now + 60)) {
writefile(DDMK, '' + X.now);
sh('( ucode ' + W + '/svc.uc name ) >/dev/null 2>&1 </dev/null &');
}
if (age == null || age > mx + 1800) return { s: 'wait' };
if (J.cgnat === true) return { s: 'none' };
let wd = X.cfg('wrtfreedom').ddnswd?.on == '1';
for (let x in (type(J.list) == 'array' ? J.list : [])) {
if (type(x) != 'object' || !(x.why == 'old' || (x.why == 'none' && x.ok === false))) continue;
let id = '' + (x.id ?? ''), n = match('' + (x.name ?? ''), /^[A-Za-z0-9.-]{1,253}$/) ? x.name : null;
if (wd && match(id, /^[A-Za-z0-9_]{1,64}$/) && split(trim(readfile('/tmp/wf-cron.ddnsold.' + id) ?? ''), ' ')[1] != '1') return { s: 'wait', det: n };
return { s: 'ko', sin: x.why == 'old' ? 'vecchio' : 'nome', det: n };
}
return { s: 'ok' };
}

function s_bot(X) {
let T = X.cfg('wrtfreedom').tg ?? {};
if (!length(T.token ?? '') || !length(T.chat ?? '')) return { s: 'none' };
if (T.cmd != '1') return { s: 'off' };
let I = inst(X, 'wrtfreedom');
if (I == null) return { s: 'wait' };
let b = I.tgbot, p = '' + (b?.pid ?? ''), o = match(p, /^[0-9]{1,10}$/) ? p : null;
if (type(b) != 'object' || b.running !== true) return { s: 'ko', sin: 'fermo' };
let h = batt(X, 'tgbot');
if (h == null || h > 180) return { s: 'ko', sin: 'fermo', obj: o };
let k = +trim(readfile(TGOK) ?? '');
if (k > 0 ? X.now - k > 900 : X.up > 1200) return { s: 'ko', sin: 'tg', obj: o };
return { s: 'ok', obj: o };
}

const BAKD = '/etc/wrtfreedom/bak/', BAKMK = '/tmp/wf-custode.bakold';
function bgalive() {
let p = trim(readfile('/tmp/wf-bg.upg.pid') ?? '');
return match(p, /^[0-9]{1,10}$/) != null && index(readfile('/proc/' + p + '/cmdline') ?? '', 'wf-bg.upg.pid') >= 0;
}
function pkgon(X) {
if (bgalive()) return true;
let s = stat('/tmp/wfpkg'), a = s ? X.now - s.mtime : 0;
return s != null && a < 1800 && a > -1800;
}
function baklim(B) { let l = +(readfile(B + '/lim') ?? ''); return l > 0 ? l : (+(readfile(B + '/secs') ?? '') || 120) + 30; }
function bakwait(X) {
let r = false, upd = null;
for (let d in lsdir(BAKD) ?? []) {
let s = stat(BAKD + d + '/id');
if (!s) continue;
let l = baklim(BAKD + d), a = X.now - s.mtime;
if (a <= l && a >= -l) { r = true; continue; }
upd = upd ?? pkgon(X);
if (upd) continue;
if (stat(BAKMK)?.type == 'file') unlink(BAKMK);
mkdir(BAKMK);
if (mkdir(BAKMK + '/' + d + '.' + s.mtime))
ev('oss', cuh(X, '⚠️', null, [ X.L(['Ritorno di una modifica', 'Change rollback']), X.L(['Non riuscito', 'Did not complete']), X.L(['Controlli ripresi', 'Checks resumed']) ]));
}
for (let m in lsdir(BAKMK) ?? []) {
let i = rindex(m, '.'), s = i > 0 ? stat(BAKD + substr(m, 0, i) + '/id') : null;
if (!s || '' + s.mtime != substr(m, i + 1)) rmdir(BAKMK + '/' + m);
}
return r;
}
function crwf(t) {
let R = {};
for (let l in split(t ?? '', '\n')) {
l = rtrim(l);
let s = substr(l, 0, 6) == '#off# ' ? substr(l, 6) : l, w = match(s, / # wf:([a-z0-9_]{1,40})$/), k = null;
if (w) k = 'wf:' + w[1];
else {
let i = index(s, ' #wrtfreedom ');
if (i > 0 && match(s, /^[ \t]*[0-9*@]/)) { let m = substr(s, i + 13), j = match(m, /"i": *"([0-9a-f]{8})"/); k = j ? 'i:' + j[1] : 'm:' + m; }
}
if (k && R[k] == null) R[k] = l;
}
return R;
}
function crcopy() {
let S = rjs(CRT);
if (type(S?.r) == 'object') return S.r;
S = rjs(CRS);
if (type(S?.r) != 'object') return null;
wjs(CRT, S);
return S.r;
}
function s_cron(X) {
if (!stat('/etc/init.d/cron')) return { s: 'none' };
let cur = crwf(readfile(CRF)), old = crcopy();
if (!length(keys(cur)) && !length(keys(old ?? {}))) return { s: 'none' };
if (!rcon('cron')) return { s: 'off' };
let mt = stat(CRF)?.mtime ?? 0, mine = 0;
for (let s in [stat(CRMINE), stat('/tmp/wf-bak-cron.done'), stat('/tmp/wf-bak-upg.done')]) if (s && s.mtime > mine) mine = s.mtime;
let miss = old ? filter(keys(old), (k) => cur[k] == null) : [];
if (X.fast) { let I = inst(X, 'cron'); return I == null ? { s: 'wait' } : running(I) ? { s: 'ok' } : { s: 'ko', sin: 'fermo' }; }
if (length(miss) && !(mt > 0 && mine >= mt - 5)) {
if (bakwait(X)) return { s: 'wait' };
let nm = length(miss);
if (nm == 1) ev('cron_tolte', cuh(X, null, X.L(['Pianificazioni', 'Schedules']), [ X.L(['1 attività tolta fuori app', '1 task removed outside app']), X.L(['Resta tolta', 'Kept removed']) ]), true);
else ev('cron_tolte', cuh(X, null, X.L(['Pianificazioni', 'Schedules']), [ X.L([nm + ' attività tolte fuori app', nm + ' tasks removed outside app']), X.L(['Restano tolte', 'Kept removed']) ]), true);
}
if (old == null || sprintf('%J', old) != sprintf('%J', cur)) { let o = { v: 1, t: X.now, r: cur }; wjs(CRT, o); mkdir('/etc/wrtfreedom'); mkdir(ESPD); wjs(CRS, o); }
let I = inst(X, 'cron');
if (I == null) return { s: 'wait' };
if (!running(I)) return { s: 'ko', sin: 'fermo' };
return { s: 'ok' };
}

const NASM = '/tmp/wf-custode.nas.json', NASD = '/tmp/wf-nas/', NASGONE = 120, NASFULL = 98, NASHOT = 55,
NASSVD = [ 'ksmbd', 'smbd', 'nmbd', 'samba4', 'nfsd', 'minidlna', 'aria2', 'wf-nasdl', 'wf-nasdav', 'wf-nasftp', 'hd-idle' ];
const NASSVN = { ksmbd: [ 'Cartelle Condivise', 'Shared Folders' ], smbd: [ 'Cartelle Condivise', 'Shared Folders' ], nmbd: [ 'Cartelle Condivise', 'Shared Folders' ],
samba4: [ 'Cartelle Condivise', 'Shared Folders' ], nfsd: [ 'NFS', 'NFS' ], minidlna: [ 'Server Multimediale', 'Media Server' ], aria2: [ 'Download', 'Downloads' ],
'wf-nasdl': [ 'Download', 'Downloads' ], 'wf-nasdav': [ 'Accesso Remoto', 'Remote Access' ], 'wf-nasftp': [ 'Registrazioni Telecamere', 'Camera Recordings' ], 'hd-idle': [ 'Riposo Del Disco', 'Disk Sleep' ] };
function nasscan() { let s = stat(NASD + 'dlna.scan'); return s != null && time() - s.mtime < 10800 && s.mtime <= time() + 60; }
function nasej() {
for (let f in lsdir(NASD + 'eject') ?? []) {
if (!match(f, /\.go$/)) continue;
let t = +trim(readfile(NASD + 'eject/' + f) ?? '');
if (t > 0 && time() - t < 120 && t <= time() + 60) return true;
}
return false;
}
function nasdsh() { return stat(W + '/nasdl.sh') ? W + '/nasdl.sh' : null; }
const NASDEV = /^(sd[a-z]{1,2}[0-9]{1,3}|mmcblk[0-9]{1,2}p[0-9]{1,3}|nvme[0-9]{1,2}n[0-9]{1,2}p[0-9]{1,3}|md[0-9]{1,3})$/;
function nasname(mp, dev) { let p = filter(split('' + mp, '/'), length), n = p[length(p) - 1] ?? dev; return length(n) > 24 ? substr(n, 0, 24) : n; }
function nasbase(d) { let m = match(d, /^(nvme[0-9]+n[0-9]+|mmcblk[0-9]+)p[0-9]+$/); return m ? m[1] : replace(d, /[0-9]+$/, ''); }
function nashung(b) { let h = readfile(NASD + 'hung/' + b); return h != null && trim(h) == (readlink('/sys/class/block/' + b) ?? '?'); }
function naslnk(b, t) {
if (nashung(b)) return true;
let l = readlink('/sys/class/block/' + b), p = null;
if (!l || index(l, '/usb') < 0) return false;
for (let x in split(l, '/')) if (match(x, /^[0-9]+-[0-9.]+$/)) p = x;
if (!p) return false;
for (let id, o in rjs(NASD + 'usb.json')?.ids ?? {}) if (o?.port == p) for (let x in o.list ?? []) if (!x.test && x.t >= t - 600 && x.t <= t + 120) return true;
return false;
}
function nassv(X) {
let J = rjs('/etc/wrtfreedom/nas.json'), l = filter(type(J?.ours) == 'array' ? J.ours : [], (s) => match('' + s, /^[A-Za-z0-9_.-]{1,32}$/));
return length(l) ? l : NASSVD;
}
function nasdl(X) {
if (X.ndl != null) return X.ndl;
let f = nasdsh();
X.ndl = f != null && +trim(sh('sh ' + f + ' dlactive 2>/dev/null </dev/null') ?? '') > 0;
return X.ndl;
}
function nascp() {
for (let f in lsdir(NASD + 'jobs') ?? []) { let J = rjs(NASD + 'jobs/' + f); if (type(J) == 'object' && J.state == 'run' && index([ 'copy', 'move', 'backup' ], J.op) >= 0) return true; }
return false;
}
function nasold(X) {
let R = rjs(NASD + 'rec.json'), o = +(R?.oldest ?? 0), u = +(R?.used ?? 0);
if (type(R) != 'object' || o <= 0 || !stat(W + '/nasrec.sh')) return false;
let r = rjs('/etc/wrtfreedom/nas.json')?.rec;
if (type(r) != 'object' || r.on !== true || o >= X.now - 3 * 86400) return false;
let k = type(r.keep) == 'object' ? r.keep : ((r.days ?? 0) > 0 ? { mode: 'days', days: r.days } : (r.max_gb ?? 0) > 0 ? { mode: 'size', max_gb: r.max_gb } : { mode: 'space' });
if ((k.mode ?? 'space') == 'space') return true;
if (k.mode == 'days') return +(k.days ?? 0) > 0 && o < X.now - +k.days * 86400;
return +(k.max_gb ?? 0) > 0 && u > +k.max_gb * 1073741824;
}
function nascut(s, n) {
s = '' + s;
if (length(s) <= n) return s;
while (n > 0 && (ord(s, n) & 192) == 128) n--;
return substr(s, 0, n);
}
const NASRW = [ 60, 180, 300, 900, 1800, 3600 ];
function nasdue(X, n, t) { let d = X.now - t; return d >= NASRW[(n < length(NASRW) ? n : length(NASRW)) - 1] || d < -60; }
function nasretry(X) {
if (!X.nretry || X.nretried || nasej() || !stat(W + '/nasjob.sh')) return;
X.nretried = true;
sh('( sh ' + W + '/nasjob.sh ntfsopen ) >/dev/null 2>&1 </dev/null &');
}
function nasmanca() {
let N = rjs('/etc/wrtfreedom/nas.json');
if (type(N) != 'object' || N.on !== true || type(N.main) != 'object' || stat(NASD + 'mainpause.json')) return null;
if (type(UCFG.ubase) != 'function' || !stat(W + '/nasvc.sh')) return null;
let J = rjs(NASD + 'mnt.json'), mp = null;
for (let id in [ lc('' + (N.main.uuid ?? '')), '' + (N.main.id ?? '') ])
if (length(id) && type(J?.[id]) == 'string' && substr(J[id], 0, 1) == '/') { mp = J[id]; break; }
if (mp == null) return null;
let su = false;
for (let l in split(readfile('/proc/mounts') ?? '', '\n')) if (replace('' + (split(l, ' ')[1] ?? ''), /\\040/g, ' ') == mp) { su = true; break; }
if (!su) return null;
for (let p in UCFG.ubase(N)) if (type(p) == 'string' && length(p) && lstat(mp + '/' + p) == null) return nascut(replace(p, /^.*\//, ''), 24);
return null;
}
function s_nas(X) {
let N = rjs('/etc/wrtfreedom/nas.json');
if (type(N) != 'object') return { s: 'none' };
if (N.on !== true) return { s: 'off' };
if (nasej()) return { s: 'wait' };
let MT = {}, nm = 0;
for (let l in split(readfile('/proc/mounts') ?? '', '\n')) {
let f = split(l, ' ');
if (substr(f[0] ?? '', 0, 5) != '/dev/') continue;
let d = substr(f[0], 5), mp = replace('' + (f[1] ?? ''), /\\040/g, ' ');
if (!match(d, NASDEV) || index([ '/', '/rom', '/overlay', '/boot', '/boot/efi' ], mp) >= 0) continue;
MT[d] = { mp: mp, fs: f[2] ?? '', ro: index(split(f[3] ?? '', ','), 'ro') >= 0 };
nm++;
}
let M = rjs(NASM);
M = type(M) == 'object' ? M : {};
M.m = type(M.m) == 'object' ? M.m : {}; M.u = type(M.u) == 'object' ? M.u : {}; M.fl = type(M.fl) == 'object' ? M.fl : {};
let before = sprintf('%J', M), lavoro = false;
for (let f in lsdir(NASD + 'jobs') ?? []) { let J = rjs(NASD + 'jobs/' + f); if (type(J) == 'object' && J.state == 'run') lavoro = true; }
let res = { s: 'ok' }, hot = (r) => { if (res.s != 'ko') res = r; };
let BC = rjs(NASD + 'blk.json'), C = lsdir('/sys/class/block/') ?? [];
let uof = (d) => lc(replace(BC?.r?.[d]?.UUID ?? '', /[^A-Za-z0-9-]/g, ''));
let NG = {};
for (let f in lsdir(NASD + 'ntfs') ?? []) {
let s = stat('/sys/class/block/' + f), a = split(trim(readfile(NASD + 'ntfs/' + f) ?? ''), ' '), u = uof(f);
if (s && length(a) != 3 && length(a) != 5) continue;
if (!s || a[2] != '' + s.inode || (a[1] != '-' && length(u) && a[1] != u)) { unlink(NASD + 'ntfs/' + f); continue; }
let h = a[0] == 'try2' ? 'try' : a[0], n = length(a) == 5 ? +a[3] : (a[0] == 'try2' ? 2 : 1), t = length(a) == 5 ? +a[4] : 0;
NG[f] = h;
if (h == 'rw' || lavoro || stat(NASD + 'ejected/' + nasbase(f)) || !nasdue(X, type(n) == 'int' && n > 0 ? n : 1, type(t) == 'int' ? t : 0)) continue;
if (MT[f] ? h == 'ro' && MT[f].ro && trim(readfile(NASD + 'hib/' + f) ?? '') != '1 ' + s.inode : index([ 'no', 'try', 'ro', 'win' ], h) >= 0) X.nretry = true;
}
M.g = type(M.g) == 'object' ? M.g : {};
let nasgo = (d) => { if (stat(NASD + 'ejected/' + nasbase(d)) || lavoro) return; if (index([ 'no', 'try', 'ro', 'win' ], NG[d]) >= 0) { X.ngive = true; return; } hot({ s: 'ko', sin: 'disco', det: nasname(M.m[d].mp, d) }); };
for (let d in keys(M.m)) {
let o = M.m[d], u = '' + (o?.u ?? ''), u2 = uof(d), altro = length(u) && length(u2) && u != u2;
if (MT[d] && !altro) continue;
if (altro || !stat('/sys/class/block/' + d)) {
delete M.m[d]; delete M.u[d]; delete M.fl[d];
if (length(u)) M.g[u] = { o: o, t: M.g[u]?.t ?? X.now, up: M.g[u]?.up ?? X.up };
continue;
}
nasgo(d);
}
for (let u in keys(M.g)) {
let g = M.g[u];
let ga = g?.up != null ? X.up - +g.up : X.now - +(g?.t ?? 0);
if (type(g) != 'object' || ga >= NASGONE || ga < 0 || +(g.t ?? 0) > X.now + 60) { delete M.g[u]; continue; }
let L2 = filter(C, (c) => match(c, NASDEV) && uof(c) == u);
if (!length(L2)) continue;
delete M.g[u];
let d2 = L2[0];
if (length(L2) > 1 || MT[d2] || M.m[d2]) continue;
M.m[d2] = g.o;
nasgo(d2);
}
let sys = {};
for (let l in split(readfile('/proc/mounts') ?? '', '\n')) {
let f = split(l, ' ');
if (substr(f[0] ?? '', 0, 5) == '/dev/' && index([ '/', '/rom', '/overlay', '/boot', '/boot/efi' ], f[1]) >= 0) sys[nasbase(substr(f[0], 5))] = true;
}
if (type(BC?.r) == 'object' && join(',', sort(map(split(split('' + BC.fp, '|')[0], ','), (x) => split(x, ':')[0]))) == join(',', sort([ ...C ])) && !lavoro) {
let FS = X.cfg('fstab'), anon = true, NJ = N.disks ?? {};
for (let s, o in FS) if (o['.type'] == 'global') anon = o.anon_mount != '0';
for (let d in C) {
let I = BC.r[d], b = nasbase(d), u = lc(replace(I?.UUID ?? '', /[^A-Za-z0-9-]/g, ''));
if (MT[d] || M.m[d] || !match(d, NASDEV) || type(I) != 'object' || !length(u) || sys[b] || stat(NASD + 'ejected/' + b)) continue;
if (!match(lc(I.TYPE ?? ''), /^(ext[234]|vfat|msdos|exfat|ntfs3?|btrfs|xfs|f2fs|hfsplus)$/)) continue;
if (trim(readfile('/sys/class/block/' + b + '/device/type') ?? '') == 'MMC' || +trim(readfile('/sys/class/block/' + d + '/size') ?? '1') == 0) continue;
let on = null;
for (let s, o in FS) {
if (o['.type'] != 'mount' || (lc('' + (o.uuid ?? '')) != u && o.device != '/dev/' + d)) continue;
if (index([ '0', 'false', 'no', 'off' ], o.enabled ?? '1') >= 0) on = false; else if (on == null) on = true;
}
if (on === false || (on == null && !anon)) continue;
if (index([ 'no', 'try', 'ro' ], NG[d]) >= 0) { X.ngive = true; continue; }
let nm = NJ[u]?.name ?? (length(I.LABEL ?? '') ? I.LABEL : d);
hot({ s: 'ko', sin: 'disco', det: nascut(nm, 24) });
}
}
for (let d, v in MT) {
let was = M.m[d];
if (was && length(was.u ?? '') && length(uof(d)) && was.u != uof(d)) was = null;
M.m[d] = { mp: v.mp, fs: v.fs, rw: NG[d] == 'ro' && v.ro ? false : (was ? (was.rw === true || !v.ro) : !v.ro), u: was?.u || uof(d) };
if (v.ro && M.m[d].rw) hot({ s: 'ko', sin: 'lettura', det: nasname(v.mp, d) });
}
if (res.s == 'ok' && !lavoro && !stat(NASD + 'smb2.user') && length(filter(nassv(X), (s) => s == 'ksmbd' || s == 'samba4')) &&
running(inst(X, 'ksmbd')) && running(inst(X, 'samba4'))) res = { s: 'ko', sin: 'doppio' };
if (res.s == 'ok' && nm > 0 && !lavoro) {
let ll = [];
for (let sv in nassv(X)) { if (!rcon(sv) || (sv == 'minidlna' && nasscan())) continue; let I = inst(X, sv); if (I == null) { res = { s: 'wait' }; break; } if (!running(I)) push(ll, sv); }
if (res.s == 'ok' && length(ll)) res = { s: 'ko', sin: 'servizio', det: NASSVN[ll[0]] ? X.L(NASSVN[ll[0]]) : ll[0], obj: ll[0] };
}
let due = false, mok = filter(keys(MT), (d) => !nashung(nasbase(d)));
for (let d in mok) if (!M.u[d] || X.now - +M.u[d].t >= 240 || +M.u[d].t > X.now + 60) due = true;
if (due) {
let c = join(' ', map(mok, (d) => q(MT[d].mp)));
for (let l in split(sh('df -kP ' + c + ' 2>/dev/null'), '\n')) {
let f = split(l, /[ \t]+/), d = substr(f[0] ?? '', 0, 5) == '/dev/' ? substr(f[0], 5) : null, u = +f[2], a = +f[3];
if (d && MT[d] && u >= 0 && a >= 0 && u + a > 0) {
let b = nasbase(d), sf = NASD + 'smart/' + b + '.json', J = rjs(sf), bad = 0, A = J?.ata_smart_attributes?.table, NV = J?.nvme_smart_health_information_log;
if (type(A) == 'array') for (let t in A) if (t.id == 197 || t.id == 198) bad += +(t.raw?.value ?? 0);
if (NV) bad = +(NV.media_errors ?? 0);
if (bad > 0 && naslnk(b, stat(sf)?.mtime ?? X.now)) bad = 0;
M.u[d] = { p: int(u * 100 / (u + a)), t: X.now, temp: J?.temperature?.current ?? NV?.temperature ?? null, ok: J?.smart_status ? !!J.smart_status.passed : null, bad: bad };
}
}
}
let marg = true, nd = 0;
for (let d, v in MT) {
let nome = nasname(v.mp, d), p = +(M.u[d]?.p ?? 0), F = M.fl[d] = type(M.fl[d]) == 'object' ? M.fl[d] : {}, S = M.u[d] ?? {};
let temp = +(S.temp ?? 0), male = S.ok === false || +(S.bad ?? 0) > 0;
let cal = temp >= NASHOT || (F.h === true && temp >= NASHOT - 5);
F.h = cal;
if (p >= NASFULL) hot({ s: 'ko', sin: 'pieno', det: nome });
else if (cal) hot({ s: 'ko', sin: 'caldo', det: nome });
else if (male) hot({ s: 'ko', sin: 'rovina', det: nome });
if (!M.u[d]) continue;
nd++;
if (p >= 90 || temp >= NASHOT - 5) marg = false;
}
X.nmarg = marg && nd > 0;
if (res.s == 'ok' && !lavoro) { let c = nasmanca(); if (c != null) res = { s: 'ko', sin: 'cartelle', det: c }; }
if (sprintf('%J', M) != before) wjs(NASM, M);
return res;
}
function nasres(X, fast, quiet) {
let f = nasdsh();
if (X.nmarg !== true || f == null || !unlink(NASD + 'dl.custode')) return;
sh('( sh ' + f + ' dlresume ) >/dev/null 2>&1 </dev/null &');
let R = [ X.L([ 'Download ripresi', 'Downloads resumed' ]) ];
if (fast) sh('( sh ' + W + '/event.sh cron fast_fix custode ' + q(cuh(X, null, 'NAS', [ ...R, X.L([ 'Dal Controllo Automatico', 'By the Automatic Check' ]) ])) + ' ) >/dev/null 2>&1 </dev/null &');
else ev('fix', cuh(X, null, 'NAS', [ ...R, X.L([ 'Dal Custode', 'By the Guardian' ]) ]), quiet);
}
function nasdirs(X) {
if (nasmanca() == null) return;
let o = split(trim(sh('sh ' + W + '/nasvc.sh dirs 2>/dev/null </dev/null')), '\n'), n = +(o[length(o) - 1] ?? '');
if (!(n > 0) || fresh(X, NASD + 'once.dirs', 3600)) return;
writefile(NASD + 'once.dirs', '' + X.now);
sh('( sh ' + W + '/event.sh cron nas_dirs_fixed nas ' + q('🗄️ NAS ¦ ' + X.L([ 'Cartelle Di Base Ricreate', 'Base Folders Recreated' ]) + ' ¦ ' + n) + ' admin ) >/dev/null 2>&1 </dev/null &');
}

const MEMF = '/tmp/wf-mem.json', MEMJ = W + '/custode/memoria.json', MEMOLD = 90, MEMVAL = 180, MEMON = '/tmp/wf-custode-mem';
const SERMK = '/tmp/wf-custode.serie';
function memread(X) {
if (X.mem != null) return X.mem;
let M = rjs(MEMF);
X.mem = type(M) == 'object' && M.v == 1 && type(M.serv) == 'object' && type(M.avail) == 'int' && type(M.ris) == 'int' && M.ris > 0 ? M : false;
if (X.mem) X.mem.eta = type(M.up) == 'int' ? X.up - M.up : X.now - +(M.t ?? 0);
return X.mem;
}
function memok(X) { let M = memread(X); return M && M.eta >= -60 && M.eta <= MEMVAL ? M : null; }
function memnome(X, k) {
if (X.memn == null) { let J = rjs(MEMJ); X.memn = type(J) == 'object' && J.v == 1 && type(J.serv) == 'object' ? J.serv : {}; }
let n = X.memn[k]?.nome;
return type(n) == 'array' && length(n) == 2 && type(n[0]) == 'string' && type(n[1]) == 'string' && length(n[0]) && length(n[0]) <= 40 && length(n[1]) && length(n[1]) <= 40 ? X.L(n) : k;
}
function memmb(kb) { return int((+(kb ?? 0)) / 1024) + ' MB'; }
function s_memoria(X) {
if (!stat(W + '/mem.uc')) return { s: 'none' };
let M = memread(X);
if (!M || M.eta > MEMOLD || M.eta < -60) return X.up < 180 ? { s: 'wait' } : { s: 'ko', sin: 'fermo' };
if (M.cg === true && M.st != 'nocg')
for (let k in sort(keys(M.serv))) {
let s = M.serv[k];
if (type(s) == 'object' && s.nostro === true && +(s.n ?? 0) > 0 && s.ok === false) return { s: 'ko', sin: 'tetto', det: memnome(X, k), obj: k };
}
if (M.avail >= M.ris) return { s: 'ok' };
let big = null;
for (let k in sort(keys(M.serv))) {
let s = M.serv[k];
if (type(s) != 'object' || s.nostro === true || !(+(s.n ?? 0) > 0) || type(s.uso) != 'int' || type(s.max) != 'int' || s.uso <= s.max) continue;
if (big == null || s.uso > M.serv[big].uso) big = k;
}
if (big != null) return { s: 'ko', sin: 'estraneo', det: memnome(X, big), obj: big };
return { s: 'ko', sin: 'riserva', det: X.L([ memmb(M.avail) + ' liberi su ' + memmb(M.tot), memmb(M.avail) + ' free of ' + memmb(M.tot) ]) };
}
const MEMFR = '/tmp/wf-memfree';
function memcache() {
let M = {};
for (let l in split(readfile('/proc/meminfo') ?? '', '\n')) { let m = match(l, /^([A-Za-z]+):[ \t]+([0-9]+)/); if (m) M[m[1]] = +m[2]; }
if (!((M.MemTotal ?? 0) > 0 && (M.Cached ?? 0) + (M.Buffers ?? 0) - (M.Shmem ?? 0) >= M.MemTotal / 32)) return false;
let u = match(trim(readfile(MEMFR) ?? ''), /^([0-9]+) (-?[0-9]+)$/);
if (u) {
let a = time() - +u[1];
if (a >= 0 && a < 3600) return false;
if (a >= 0 && a < 21600 && +u[2] < M.MemTotal / 64) return false;
}
return true;
}

const CLD = '/tmp/wf-cloud/', CLSTUCK = 7200, CLMEM = 102400, CLFREE = 104857600;
function cllk(X, n) {
let s = stat(CLD + n);
if (s?.type != 'directory') return false;
let a = X.now - s.mtime;
if (n == 'rc.lock') return a > 120;
let p = trim(readfile(CLD + n + '/pid') ?? '');
return length(p) ? !(match(p, /^[0-9]{1,10}$/) && stat('/proc/' + p)) : a > 60;
}
function s_cloud(X) {
let C = rjs('/etc/wrtfreedom/cloud.json');
if (!stat(W + '/cloud.sh') || type(C) != 'object' || type(C.accounts) != 'array' || !length(C.accounts)) return { s: 'none' };
let jobs = lsdir(CLD + 'jobs') ?? [], all = lsdir(CLD) ?? [];
for (let f in sort(jobs)) {
if (!match(f, /^[A-Za-z0-9_-]{1,48}\.json$/)) continue;
let J = rjs(CLD + 'jobs/' + f), t = +(J?.t ?? 0);
if (type(J) == 'object' && J.state == 'run' && t > 0 && X.now - t >= CLSTUCK) return { s: 'ko', sin: 'fermo' };
}
for (let n in sort(all))
if (match(n, /^(slot\.[0-9]{1,2}|acct-a[0-9]{1,3}\.lock|mig\.lock|night\.lk|work\.lk|rc\.lock)$/) && cllk(X, n)) return { s: 'ko', sin: 'lucchetto' };
let mr = memok(X), m = mr ? null : match(readfile('/proc/meminfo') ?? '', /MemAvailable:[ \t]*([0-9]+)/);
let poca = mr ? mr.avail < mr.ris && +(mr.sotto ?? 0) > 0 : m != null && +m[1] < CLMEM;
if (poca && length(filter(all, (n) => match(n, /^slot\.[0-9]{1,2}$/) && stat(CLD + n)?.type == 'directory')) >= 2) return { s: 'ko', sin: 'memoria' };
let S = rjs(CLD + 'state.json')?.accts;
S = type(S) == 'object' ? S : {};
let nm = (a) => cutn(a.name ?? a.svc ?? a.id, 24), sp = null;
for (let a in C.accounts) {
if (type(a) != 'object' || !match('' + a.id, /^a[0-9]{1,3}$/) || type(S[a.id]) != 'object') continue;
let st = S[a.id].st, fr = S[a.id].free;
if (st == 'relink' || st == 'err') return { s: 'ko', sin: 'account', det: nm(a) };
if (sp == null && type(fr) == 'int' && fr >= 0 && fr < CLFREE) sp = nm(a);
}
if (sp != null) return { s: 'ko', sin: 'spazio', det: sp };
return { s: 'ok' };
}

const SONDE = {
nas: { sin: ['disco', 'lettura', 'doppio', 'servizio', 'pieno', 'caldo', 'rovina', 'cartelle'], fn: s_nas },
linea: { sin: ['giu', 'fermo'], fn: s_linea },
firewall: { sin: ['giu', 'porte'], fn: s_firewall },
vpnsrv: { sin: ['giu'], fn: s_vpnsrv },
vpncli: { sin: ['giu', 'fermo'], fn: s_vpncli },
limiti: { sin: ['file', 'nft', 'fermo'], fn: s_limiti },
wifi: { sin: ['radio', 'rete'], fn: s_wifi },
adg: { sin: ['giu', 'dns', 'riserva'], fn: s_adg },
ddns: { sin: ['vecchio', 'nome'], fn: s_ddns },
bot: { sin: ['fermo', 'tg'], fn: s_bot },
cron: { sin: ['fermo'], fn: s_cron },
cloud: { sin: ['fermo', 'lucchetto', 'memoria', 'account', 'spazio'], fn: s_cloud },
memoria: { sin: ['riserva', 'tetto', 'estraneo', 'fermo'], fn: s_memoria }
};

const RIM = {
ifup: { n: ['Riaccendi', 'Restart'], rete: true },
linea: { n: ['Ricollega La Linea', 'Reconnect The Line'], rete: true, stacca: true },
rete: { n: ['Ricarica La Rete', 'Reload The Network'], stacca: true },
fw: { n: ['Ricarica Il Firewall', 'Reload The Firewall'] },
servizio: { n: ['Riavvia I Controlli', 'Restart The Checks'] },
radio: { n: ['Riaccendi La Radio', 'Restart The Radio'], rete: true },
wifi: { n: ['Ricarica Il Wi-Fi', 'Reload The Wi-Fi'], stacca: true },
adg: { n: ['Riavvia AdGuard Home', 'Restart AdGuard Home'] },
riserva: { n: ['Passa Al DNS Di Riserva', 'Switch To The Backup DNS'] },
ddns: { n: ['Aggiorna Il Nome', 'Update The Name'] },
bot: { n: ['Riavvia Il Bot', 'Restart The Bot'] },
cron: { n: ['Riavvia Le Pianificazioni', 'Restart The Schedules'] },
nasmount: { n: ['Ricollega Il Disco', 'Reconnect The Disk'] },
nassvc: { n: ['Riavvia Il Servizio', 'Restart The Service'], rete: true },
naspausa: { n: ['Metti In Pausa I Download', 'Pause The Downloads'], vuoto: true },
nasrec: { n: ['Cancella Le Registrazioni Vecchie', 'Delete Old Recordings'], vuoto: true },
nasferma: { n: ['Ferma Copie e Download', 'Stop Copies and Downloads'], vuoto: true },
nasuno: { n: ['Tieni Un Solo Server', 'Keep One Server Only'], vuoto: true },
nasdirs: { n: ['Ricreo Le Cartelle Di Base', 'I Recreate The Base Folders'], vuoto: true },
cloudheal: { n: ['Ripara Il Cloud', 'Repair The Cloud'] },
memtetti: { n: ['Rimetti I Tetti', 'Restore The Limits'] },
memcache: { n: ['Libero La Memoria Di Passaggio', 'I Free The Temporary Memory'], vuoto: true }
};
function want(i) { mkdir('/tmp/wf-want'); writefile(WANT + i, '' + time()); }
function rcmd(X, id, obj, sin, fid, since) {
let i = match('' + (obj ?? ''), IFRX) ? obj : null;
if (RIM[id]?.rete && !i) return '';
if (id == 'ifup') { want(i); return 'ifup ' + q(i); }
if (id == 'linea') {
let a = split(trim(readfile(AGIS) ?? ''), ' '), d = X.now - +(a[1] ?? 0);
if (a[0] == 'c5g' && d >= -5 && d < 600) return null;
if (a[0] == 'wd' && d >= -5 && d < 600) return null;
let rs = stat(RECON), ra = rs ? X.now - rs.mtime : 999, g = X.now - +(since ?? X.now);
if (ra >= -60 && ra < 120) return null;
if (g >= -60 && g < 1800) { let P = inst(X, 'wrtfreedom'); if (type(P) == 'object' && P.wd?.running === true) return null; }
writefile(CULN, '' + X.now);
want(i); return 'echo ' + q(i) + ' > ' + RECON + '; ifdown ' + q(i) + '; sleep 3; date +%s > ' + q(WANT + i) + '; ifup ' + q(i) + '; rm -f ' + RECON;
}
if (id == 'rete') { want('_all'); return '/etc/init.d/network reload'; }
if (id == 'fw') {
if (!mkdir(FWL)) { if (fwbusy(X)) return null; rmdir(FWL); if (!mkdir(FWL)) return null; }
let si = match('' + (sin ?? ''), /^[a-z]{1,16}$/) ? sin : '-';
return 'if fw4 -q check; then /etc/init.d/firewall reload && echo "$(date +%s) ' + si + '" > ' + FWOK + '; fi; rmdir ' + FWL;
}
if (id == 'servizio') {
let P = inst(X, 'wrtfreedom'), k = fid == 'linea' ? 'line' : 'instance1', f = fid == 'linea' ? 'line.sh' : 'notify.sh';
let p = '' + ((type(P) == 'object' ? P[k]?.pid : null) ?? ''), c = '/proc/' + p + '/cmdline';
if (!match(p, /^[0-9]{1,10}$/) || index(readfile(c) ?? '', f) < 0) return '/etc/init.d/wrtfreedom start';
return 'kill ' + p + '; sleep 3; if grep -qs ' + f + ' ' + c + '; then kill -9 ' + p + '; fi';
}
if (id == 'radio') return 'wifi up ' + q(i);
if (id == 'wifi') return 'wifi reload';
if (id == 'adg') { let a = adginit(); return a ? '/etc/init.d/' + a + ' restart' : ''; }
if (id == 'riserva') return 'sh ' + W + '/adgmode.sh check; sleep 12; sh ' + W + '/adgmode.sh check';
if (id == 'ddns') return 'sh ' + W + '/cron.sh ddnsforce; ucode ' + W + '/svc.uc name';
if (id == 'bot') {
if (!match('' + (obj ?? ''), /^[0-9]{1,10}$/)) return '/etc/init.d/wrtfreedom reload';
let c = '/proc/' + obj + '/cmdline';
return 'kill ' + obj + '; sleep 3; if grep -qs tgbot ' + c + '; then kill -9 ' + obj + '; sleep 2; fi; /etc/init.d/wrtfreedom reload';
}
if (id == 'cron') return '/etc/init.d/cron restart';
if ((id == 'nasmount' || id == 'nassvc' || id == 'nasuno') && nasej()) return '';
if (id == 'nasmount') return stat(W + '/nasjob.sh') ? 'sh ' + W + '/nasjob.sh ntfsopen' : 'block mount';
if (id == 'nassvc') return index(nassv(X), i) >= 0 && stat('/etc/init.d/' + i) && !(i == 'minidlna' && nasscan()) ? '/etc/init.d/' + i + ' restart' : '';
if (id == 'nasuno') return stat(W + '/nasvc.sh') && !stat(NASD + 'smb2.user') ? 'sh ' + W + '/nasvc.sh spare' : '';
if (id == 'nasdirs') return !nasej() && nasmanca() != null ? 'ucode ' + W + '/custode.uc nasdirs' : '';
let ds = nasdsh();
if (id == 'naspausa') return ds && nasdl(X) ? 'sh ' + ds + ' dlpause' : '';
if (id == 'nasrec') return nasold(X) ? 'sh ' + W + '/nasrec.sh clean' : '';
if (id == 'nasferma') {
let cp = nascp(), dl = ds && nasdl(X);
if (!cp && !dl) return '';
return join('; ', filter([ cp ? 'for f in ' + NASD + 'jobs/*.json; do [ -f "$f" ] && grep -q \'"state": *"run"\' "$f" && grep -qE \'"op": *"(copy|move|backup)"\' "$f" && : > "${f%.json}.stop"; done' : null,
dl ? 'sh ' + ds + ' dlpause' : null ], length));
}
if (id == 'cloudheal') return stat(W + '/cloud.sh') ? 'sh ' + W + '/cloud.sh heal' : '';
if (id == 'memtetti') return stat(W + '/mem.uc') ? 'ucode ' + W + '/mem.uc apply' : '';
if (id == 'memcache') return stat(W + '/cron.sh') && memcache() ? 'sh ' + W + '/cron.sh memfree' : '';
return '';
}

function okpair(p) { return type(p) == 'array' && length(p) == 2 && type(p[0]) == 'string' && type(p[1]) == 'string' && length(p[0]) && length(p[1]) && length(p[0]) <= 60 && length(p[1]) <= 60; }
function okint(v, a, b) { return type(v) == 'int' && v >= a && v <= b; }
function fcheck(F, seen) {
let so = SONDE[F.sonda];
if (!okpair(F.nome)) return 'nome';
if (!so) return 'sonda';
if (type(F.dip) != 'array') return 'dip';
for (let d in F.dip) if (!seen[d]) return 'dip ' + d;
if (F.serie != null && index(['ripara', 'osserva'], F.serie) < 0) return 'serie';
if (type(F.sintomi) != 'object' || type(F.rimedi) != 'object' || type(F.soglie) != 'object') return 'sintomi';
if (length(keys(F.sintomi)) != length(so.sin) || length(keys(F.rimedi)) != length(so.sin)) return 'sintomi';
for (let s in so.sin) {
if (!okpair(F.sintomi[s])) return 'sintomo ' + s;
let L = F.rimedi[s];
if (type(L) != 'array' || length(L) > 6) return 'rimedi ' + s;
for (let i = 0; i < length(L); i++) if (!RIM[L[i]] || index(L, L[i]) != i) return 'rimedio ' + L[i];
}
let T = F.soglie;
if (!okint(T.giri_ko, 1, 120) || !okint(T.attesa, 30, 3600) || !okint(T.max_ora, 1, 3)) return 'soglie';
return null;
}
function dati() {
let D = rjs(DATI), seen = {}, ok = [], bad = {}, ids = [];
if (type(D) != 'object' || D.v != 1) return { err: 'versione' };
if (!okint(D.tetto_ora, 1, 30)) return { err: 'tetto_ora' };
if (type(D.f) != 'array' || !length(D.f) || length(D.f) > 40) return { err: 'funzioni' };
for (let F in D.f) {
if (type(F) != 'object' || !match('' + F.id, IDRX) || index(ids, F.id) >= 0) return { err: 'id' };
push(ids, F.id);
let e = fcheck(F, seen);
if (e) { bad[F.id] = F.id + ': ' + e; continue; }
seen[F.id] = true; push(ok, F);
}
if (!length(ok)) return { err: values(bad)[0] ?? 'funzioni' };
D.f = ok; D.bad = bad; D.ids = ids;
return D;
}
function sonda(X, F) {
let r = null;
try { r = SONDE[F.sonda].fn(X); } catch (e) { r = null; }
r = type(r) == 'object' && index(['ok', 'ko', 'off', 'none', 'wait'], r.s) >= 0 ? r : { s: 'wait' };
if (r.s == 'ko' && index(SONDE[F.sonda].sin, r.sin) < 0) r = { s: 'wait' };
return r;
}

const GMAX = 40;
let ECNT = null;
function gconta(E, o) {
let e = '' + o.e, i = e == 'ok' ? 0 : e == 'aiuto' ? 1 : -1, fine = index([ 'ok', 'aiuto', 'da_solo', 'troppi' ], e) >= 0;
if (type(o.f) != 'string' || (i < 0 && !fine) || o.poi != null) return;
let l = localtime(+o.t > 0 ? +o.t : time()), d = sprintf('%04d-%02d-%02d', l.year, l.mon, l.mday);
E.giorni = type(E.giorni) == 'object' ? E.giorni : {};
let G = E.giorni[d] = type(E.giorni[d]) == 'object' ? E.giorni[d] : {};
let c = G[o.f] = type(G[o.f]) == 'array' && length(G[o.f]) == 3 ? G[o.f] : [ 0, 0, 0 ];
if (i >= 0) c[i] = +c[i] + 1;
if (fine) c[2] = +c[2] + 1;
let ks = sort(keys(E.giorni));
while (length(ks) > GMAX) delete E.giorni[shift(ks)];
}
function hist(o) {
if (ECNT) gconta(ECNT, o);
let L = filter(split(readfile(HI) ?? '', '\n'), length);
push(L, sprintf('%J', o));
if (length(L) > HMAX) L = slice(L, length(L) - HMAX);
writefile(HI + '.t', join('\n', L) + '\n'); rename(HI + '.t', HI);
if (type(o.f) == 'string') {
let U = rjs(ULT);
U = type(U) == 'object' ? U : {};
let u = U[o.f] = type(U[o.f]) == 'object' ? U[o.f] : {};
u.last = o;
if (o.e == 'aiuto') u.aiuto = o.t;
wjs(ULT, U);
}
}
function bb() { sh('( sh ' + W + '/bb.sh custode ) >/dev/null 2>&1 </dev/null &'); }

function enew(X) { return { v: 1, ver: null, salvato: X.now, giorno: X.giorno, r: {}, corti: {}, ep: {}, abit: [], prima: [], agg: null, troppi: {} }; }
function eload(X) {
let E = rjs(ESPT);
if (type(E) != 'object' || E.v != 1) {
E = rjs(ESP);
if (type(E) == 'object' && E.v == 1) E.salvato = X.now;
else E = enew(X);
}
for (let k in ['r', 'corti', 'ep', 'troppi', 'giorni']) if (type(E[k]) != 'object') E[k] = {};
if (type(E.abit) != 'array') E.abit = [];
if (type(E.prima) != 'array') E.prima = [];
if (type(E.agg) != 'object') E.agg = null;
return E;
}
const C5H = '/tmp/wf-c5g.24h', C5HD = ESPD + '/c5g24.json', C5HN = 1440;
function c5hdots(n) { let s = ''; for (let p = '.'; n > 0; n = n >> 1, p += p) if (n & 1) s += p; return s; }
function c5hok(H) { return type(H) == 'object' && H.v == 1 && type(H.t) == 'int' && type(H.s) == 'string' && length(H.s) == C5HN; }
function c5hput(X, c) {
let H = rjs(C5H), m = int(X.now / 60);
if (!c5hok(H)) H = rjs(C5HD);
if (!c5hok(H)) H = { v: 1, t: m, s: c5hdots(C5HN) };
let k = m - H.t;
if (k <= 0) H.s = substr(H.s, 0, C5HN - 1) + c;
else if (k >= C5HN) H.s = c5hdots(C5HN - 1) + c;
else H.s = substr(H.s, k) + c5hdots(k - 1) + c;
H.t = m;
wjs(C5H, H);
}
function c5hsave() { let H = rjs(C5H); if (c5hok(H)) { mkdir('/etc/wrtfreedom'); mkdir(ESPD); wjs(C5HD, H); } }
function esave(X, E, force) {
let s = +(E.salvato ?? 0);
if (force || X.now - s >= ESAVE || s > X.now + 60) {
E.salvato = X.now;
mkdir('/etc/wrtfreedom'); mkdir(ESPD);
wjs(ESP, E);
c5hsave();
}
let t = sprintf('%J', E);
if (readfile(ESPT) != t) { writefile(ESPT + '.t', t); rename(ESPT + '.t', ESPT); }
}
function epulisci(E, D) {
let ids = D.ids ?? map(D.f, (F) => F.id), ok = (k) => index(ids, split(k, ':')[0]) >= 0;
for (let k in keys(E.r)) if (!ok(k)) delete E.r[k];
for (let k in keys(E.ep)) if (!ok(k)) delete E.ep[k];
for (let k in keys(E.corti)) if (!ok(k)) delete E.corti[k];
for (let k in keys(E.troppi)) if (!ok(k)) delete E.troppi[k];
E.abit = filter(E.abit, (a) => index(ids, a?.f) >= 0);
for (let d, G in E.giorni) if (type(G) == 'object') { for (let f in keys(G)) if (index(ids, f) < 0) delete G[f]; }
}
function impara(E, k, r, ok, sec) {
E.r[k] = type(E.r[k]) == 'object' ? E.r[k] : {};
let x = E.r[k][r] = type(E.r[k][r]) == 'object' ? E.r[k][r] : { ok: 0, ko: 0, s: 0 };
if (ok) { x.ok = +x.ok + 1; x.s = +(x.s ?? 0) + (sec > 0 ? sec : 0); return false; }
x.ko = +x.ko + 1;
return +x.ok == 0 && x.ko == SCARTO;
}
function scartato(E, k, r) { let x = E.r[k]?.[r]; return type(x) == 'object' && +x.ok == 0 && +x.ko >= SCARTO; }
function scala(E, F, sin) {
let k = F.id + ':' + sin, L = F.rimedi[sin] ?? [], o = [];
for (let i = 0; i < length(L); i++) if (!scartato(E, k, L[i])) push(o, { r: L[i], i: i, ok: +(E.r[k]?.[L[i]]?.ok ?? 0) });
return map(sort(o, (a, b) => b.ok - a.ok || a.i - b.i), (x) => x.r);
}
function corto(E, f, h) {
let c = E.corti[f];
if (type(c) != 'array' || length(c) != 24) { c = []; for (let i = 0; i < 24; i++) push(c, 0); }
c[h] = +c[h] + 1;
let tot = 0;
for (let v in c) tot += +v;
if (tot > 200) c = map(c, (v) => int(+v / 2));
E.corti[f] = c;
}
function giri(X, E, F) {
let g = F.soglie.giri_ko, c = E.corti[F.id];
if (type(c) == 'array' && +(c[X.h] ?? 0) >= 3) g = g * 2 > 120 ? 120 : g * 2;
return g;
}
function episodio(X, E, F, sin) {
let k = F.id + ':' + sin, L = filter(type(E.ep[k]) == 'array' ? E.ep[k] : [], (t) => X.now - t < 14 * 86400 && t <= X.now + 60);
push(L, X.now);
if (length(L) > 30) L = slice(L, length(L) - 30);
E.ep[k] = L;
let G = {};
for (let t in L) { let lt = localtime(t), d = sprintf('%d-%d', lt.mon, lt.mday); G[lt.hour] = G[lt.hour] ?? {}; G[lt.hour][d] = true; }
let old = filter(E.abit, (a) => a.f == F.id && a.sin == sin), nuove = [];
E.abit = filter(E.abit, (a) => !(a.f == F.id && a.sin == sin));
for (let h, ds in G) {
let n = length(keys(ds));
if (n < 3) continue;
let a = { f: F.id, sin: sin, h: +h, n: n };
push(E.abit, a);
if (!length(filter(old, (o) => o.h == +h))) push(nuove, a);
}
return nuove;
}

function notte(X, CU) {
let v = '' + (CU.notte ?? '');
if (v == 'off') return false;
let m = match(v, /^([0-9]{1,2})-([0-9]{1,2})$/), a = 0, b = 6;
if (m && +m[1] <= 23 && +m[2] <= 24) { a = +m[1]; b = +m[2] % 24; }
if (a == b) return false;
return a < b ? X.h >= a && X.h < b : X.h >= a || X.h < b;
}
function ritorno(X, E, F, n, L) {
let R = n.rit;
if (type(R) != 'object') { n.rit = null; return; }
let age = X.now - +(R.t ?? 0);
if (age < RITW && age >= -60) return;
if (L?.s == 'ok') { n.rit = null; return; }
if (L?.s != 'ko') { if (age > 300 || age < -60) n.rit = null; return; }
n.rit = null;
let li = '' + (R.li ?? '');
if (!match(li, IFRX)) return;
want(li);
sh('( ifup ' + q(li) + ' ) >/dev/null 2>&1 </dev/null &');
ev('ritorno', cuh(X, '⚠️', X.L(F.nome), [ X.L(['Internet non tornava', 'Internet did not come back']), X.L(['Dopo: ', 'After: ']) + X.L(RIM[R.r]?.n), X.L(['Linea riaccesa', 'Line restarted']) ]));
hist({ t: X.now, f: F.id, sin: n.isin, r: R.r, modo: n.modo, e: 'ritorno' });
if (RIM[R.r] && n.isin) impara(E, F.id + ':' + n.isin, R.r, false, 0);
}

function quiet(X) {
if (X.up < 300) return 'avvio';
if (bakwait(X)) return 'copia';
if (pkgon(X)) return 'aggiornamento';
for (let f in lsdir('/tmp/.uci') ?? []) { let s = stat('/tmp/.uci/' + f); if (s && X.now - s.mtime < 120) return 'modifica'; }
for (let f in lsdir('/tmp/wf-want') ?? []) { let v = +trim(readfile(WANT + f) ?? ''); if (v > 0 && X.now - v >= -5 && X.now - v < 60) return 'modifica'; }
return null;
}
const QOK = { memoria: [ 'avvio' ] };
function qok(w, k) { return w != null && index(QOK[k] ?? [], w) >= 0; }

const FASTK = [ 'wifi', 'firewall', 'bot', 'cron', 'nas', 'memoria' ], FMW = 180;
function fmark(k, who) { writefile(AGIS + '.' + k, who + ' ' + time()); }
function fmarked(X, k, who) {
let a = split(trim(readfile(AGIS + '.' + k) ?? ''), ' '), d = X.now - +(a[1] ?? 0);
return a[0] == who && d >= -5 && d < FMW;
}

function epnuovo(X, F, n) {
if (n.isin == n.sin) return;
if (n.isin != null && n.since && (n.aiuto || n.ko >= (n.sogl ?? F.soglie.giri_ko)))
hist({ t: X.now, f: F.id, sin: n.isin, r: null, modo: n.modo, e: 'da_solo', d: X.now - n.since, poi: n.sin });
n.isin = n.sin; n.ko = 0; n.since = null; n.step = 0; n.last = null; n.prov = []; n.aiuto = false; n.scala = null; n.ep = false; n.notte = false; n.sogl = null; n.ta = null; n.avv = false; n.px = false;
}
function step(X, D, F, n, S, E, CU, cur) {
let T = F.soglie, nome = X.L(F.nome), sx = () => cap(X.L(F.sintomi[n.isin])) + (n.det ? ' (' + n.det + ')' : ''), C = (e, R) => cuh(X, e, nome, R),
RN = (r) => X.L(RIM[r]?.n);
let mo = +(CU.max_ora ?? ''), at = +(CU.attesa ?? '');
if ((type(mo) == 'int' && mo >= 1 && mo < T.max_ora) || (type(at) == 'int' && at > T.attesa && at <= 3600))
T = { ...T, max_ora: type(mo) == 'int' && mo >= 1 && mo < T.max_ora ? mo : T.max_ora, attesa: type(at) == 'int' && at > T.attesa && at <= 3600 ? at : T.attesa };
if (F.id == 'nas') nasres(X, false, CU.avvisa == '0');
if (F.id == 'nas' && n.modo == 'ripara') nasretry(X);
if (n.s == 'ok' || n.s == 'off' || n.s == 'none') {
if (n.since && n.ko >= (n.sogl ?? T.giri_ko)) {
let d = X.now - n.since, r = n.prov[length(n.prov) - 1];
if (n.s != 'ok' || (F.id == 'nas' && X.ngive && r == 'nasmount')) hist({ t: X.now, f: F.id, sin: n.isin, r: null, modo: n.modo, e: 'scelta', d: d });
else if (n.modo == 'ripara' && r) {
ev('fix', C(null, [ sx(), X.L(['A posto in ', 'Fixed in ']) + dur(X.now - n.last), '✅ ' + RN(r) ]), CU.avvisa == '0');
hist({ t: X.now, f: F.id, sin: n.isin, r: r, modo: n.modo, e: 'ok', d: d });
if (!n.aiuto) impara(E, F.id + ':' + n.isin, r, true, X.now - n.last);
}
else {
ev('ok', C(null, [ X.L(['A posto da solo', 'Fine by itself']), X.L(['Dopo ', 'After ']) + dur(d) ]), true);
hist({ t: X.now, f: F.id, sin: n.isin, r: null, modo: n.modo, e: 'da_solo', d: d });
}
}
else if (n.s == 'ok' && n.since && n.ko > 0) corto(E, F.id, localtime(n.since).hour);
n.ko = 0; n.since = null; n.isin = null; n.step = 0; n.last = null; n.prov = []; n.aiuto = false; n.scala = null; n.ep = false; n.notte = false; n.sogl = null; n.ta = null; n.avv = false; n.px = false;
return;
}
if (n.s != 'ko') return;
epnuovo(X, F, n);
n.ko++; n.since = n.since ?? X.now;
n.sogl = giri(X, E, F);
if (n.ko < n.sogl) return;
if (F.id == 'memoria' && n.sin == 'estraneo') {
if (n.px) return;
n.px = true;
let s = memread(X)?.serv?.[n.obj], R = [ sx() ];
if (type(s) == 'object') push(R, X.L([ 'Usa ', 'Uses ' ]) + memmb(s.uso) + X.L([ ', oltre ', ', over ' ]) + memmb(s.max));
push(R, X.L([ 'Puoi frenarlo dall\'app: Custode, Memoria', 'You can slow it down from the app: Guardian, Memory' ]));
ev('memx', C('⚠️', R));
return;
}
let k = F.id + ':' + n.sin;
if (!n.ep) {
n.ep = true;
for (let a in episodio(X, E, F, n.sin))
ev('abitudine', C(null, [ sx(), X.L(['Spesso fra le ', 'Often between ']) + a.h + X.L([' e le ', ' and ']) + ((a.h + 1) % 24), a.n + ' ' + (a.n == 1 ? X.L(['giorno su 14', 'day out of 14']) : X.L(['giorni su 14', 'days out of 14'])) ]), true);
}
if (type(n.scala) == 'array' && length(filter(n.scala, (x) => index(F.rimedi[n.sin] ?? [], x) < 0))) { n.scala = null; n.step = 0; n.prov = []; n.aiuto = false; }
if (type(n.scala) != 'array') n.scala = scala(E, F, n.sin);
if (n.aiuto && n.ta == null) n.ta = X.now;
if (n.aiuto && n.modo == 'ripara' && !n.nofix && (X.now - n.ta >= 21600 || n.ta > X.now + 60)) {
n.scala = scala(E, F, n.sin); n.step = 0; n.prov = []; n.aiuto = false; n.ta = null;
}
if (n.last && n.last > X.now + 60) n.last = X.now - T.attesa;
if (n.last && X.now - n.last < T.attesa) return;
if (index(FASTK, F.id) >= 0 && fmarked(X, F.id, 'fast')) return;
let L = n.scala;
let nulla = (x) => RIM[x]?.vuoto === true && rcmd(X, x, n.obj, n.sin, F.id, n.since) === '';
if (!n.nofix && length(L) && length(filter(L, nulla)) == length(L)) return;
while (!n.nofix && n.step < length(L) && nulla(L[n.step])) n.step++;
if (n.step >= length(L) || n.nofix) {
if (n.aiuto) return;
n.aiuto = true; n.ta = X.now;
let pv = slice(n.prov, -3), m = [ sx() + X.L([' da ', ' for ']) + dur(X.now - n.since), ...map(pv, (r) => '❌ ' + RN(r)) ];
if (n.nofix) push(m, X.L(['Controlla la regola', 'Check the rule']));
else if (!length(L) && length(F.rimedi[n.sin] ?? [])) push(m, X.L(['Rimedi mai riusciti', 'Remedies never worked']));
let av = n.avv === true;
n.avv = true;
if (n.modo == 'ripara') {
let r = n.prov[length(n.prov) - 1];
if (r && impara(E, k, r, false, 0)) ev('scarto', C(null, [ sx(), '❌ ' + RN(r), X.L(['Mai riuscito: scartato', 'Never works: dropped']) ]), true);
if (!av) bb();
ev('aiuto', C('🆘', [ X.L(['Serve aiuto', 'Help needed']), ...m ]), av);
}
else ev('aiuto', C(null, [ X.L(['Chiederei aiuto', 'I would ask for help']), ...m, X.L(['Riparazione spenta', 'Repair off']) ]), av);
hist({ t: X.now, f: F.id, sin: n.sin, r: null, modo: n.modo, e: 'aiuto' });
return;
}
if (length(n.tent) >= T.max_ora || length(S.g) >= D.tetto_ora) { n.freno = true; return; }
let r = L[n.step], lin = cur.linea;
if (RIM[r].stacca && notte(X, CU) && lin?.s != 'ko') {
if (!n.notte) {
n.notte = true;
ev('notte', C(null, [ sx(), RN(r) + X.L([': di mattina', ': in the morning']), X.L(['Di notte staccherebbe la rete', 'Would cut internet at night']) ]), true);
}
return;
}
n.notte = false;
if (n.modo == 'ripara') {
let c = rcmd(X, r, n.obj, n.sin, F.id, n.since);
if (c == null) return;
let p = n.prov[length(n.prov) - 1];
if (p && impara(E, k, p, false, 0)) ev('scarto', C(null, [ sx(), '❌ ' + RN(p), X.L(['Mai riuscito: scartato', 'Never works: dropped']) ]), true);
if (length(c)) {
if (RIM[r].stacca && lin?.s == 'ok' && match('' + (lin.obj ?? ''), IFRX)) n.rit = { li: lin.obj, t: X.now, r: r };
if (index(FASTK, F.id) >= 0) fmark(F.id, 'custode');
sh('( ' + c + ' ) >/dev/null 2>&1 </dev/null &');
}
ev('prova', C(null, [ sx(), X.L(['Provo: ', 'Trying: ']) + RN(r) ]), true);
push(n.t24, X.now);
}
else ev('oss', C(null, [ sx(), X.L(['Proverei: ', 'I would try: ']) + RN(r), X.L(['Riparazione spenta', 'Repair off']) ]), true);
hist({ t: X.now, f: F.id, sin: n.sin, r: r, modo: n.modo, e: n.modo == 'ripara' ? 'prova' : 'oss' });
n.step++; n.last = X.now; push(n.tent, X.now); push(S.g, X.now); push(n.prov, r);
if (n.modo == 'ripara' && length(n.t24) >= MAX24) {
E.troppi[F.id] = X.now; n.t24 = [];
ev('troppi', C('⚠️', [ X.L(['Troppi interventi oggi', 'Too many fixes today']), X.L(['Per 24 ore solo osservo', 'Only watching for 24 hours']) ]));
hist({ t: X.now, f: F.id, sin: n.sin, r: null, modo: n.modo, e: 'troppi' });
}
}

function autoesame(X, D, E, S) {
let v = trim(readfile(VERF) ?? '');
if (!match(v, /^[0-9][0-9.]{0,15}$/)) return false;
if (E.ver == null) { E.ver = v; return false; }
if (E.ver != v) { E.agg = { da: E.ver, a: v, t: X.now, prima: E.prima, esito: null, ko: [] }; E.ver = v; esave(X, E, true); }
let A = E.agg;
if (type(A) != 'object') return false;
let nm = (id) => id == 'dati' ? X.L(['dati del Custode', 'Guardian data']) : X.L(S.f[id]?.nome ?? id);
if (A.esito == null) {
let age = X.now - +A.t;
if (age < 300 || (S.silenzio && age < 3600)) return false;
let bad = [], wt = false;
if (D.err || length(keys(D.bad ?? {}))) push(bad, 'dati');
if (!D.err) for (let id in (type(A.prima) == 'array' ? A.prima : [])) {
let s = S.f[id]?.s;
if (s == null || s == 'ok' || s == 'off' || s == 'none') continue;
if (s == 'wait' || s == 'dip') { if (age < 900) wt = true; continue; }
push(bad, id);
}
if (wt) return false;
A.esito = length(bad) ? 'ko' : 'ok'; A.ko = bad; A.fatto = X.now;
if (length(bad)) {
bb();
ev('autoesame', cuh(X, '🆘', X.L(['Aggiornamento ', 'Update ']) + v, [ X.L(['Problemi dopo l\'aggiornamento', 'Problems after the update']), ...map(slice(bad, 0, 3), (b) => '❌ ' + nm(b)), X.L(['Indietro: Software', 'Roll back: Software']) ]));
}
else ev('autoesame', cuh(X, null, X.L(['Aggiornamento ', 'Update ']) + v, [ X.L(['Tutto come prima', 'Everything as before']) ]), true);
hist({ t: X.now, f: null, sin: null, r: null, modo: null, e: 'autoesame', esito: A.esito, ko: bad, v: v });
esave(X, E, true);
return length(bad) > 0;
}
if (A.esito != 'ko' || !length(A.ko ?? [])) return false;
A.ko = filter(A.ko, (id) => id == 'dati' ? D.err != null || length(keys(D.bad ?? {})) > 0 : (S.f[id] != null && index(['ok', 'off', 'none'], S.f[id].s) < 0));
if (!length(A.ko)) {
ev('autoesame', cuh(X, null, X.L(['Aggiornamento ', 'Update ']) + A.a, [ X.L(['Di nuovo tutto a posto', 'Everything fine again']) ]), true);
return false;
}
return true;
}

function giornata(X, E, S) {
if (X.h < ORA_GIORNO || E.giorno == X.giorno) return;
E.giorno = X.giorno;
let fix = 0, oss = 0;
for (let l in split(readfile(HI) ?? '', '\n')) {
let o = null;
try { o = length(l) ? json(l) : null; } catch (e) { o = null; }
if (type(o) != 'object' || !(X.now - +o.t < 86400)) continue;
if (o.e == 'ok') fix++;
else if (o.e == 'oss') oss++;
}
let rip = [], obs = [];
for (let id, n in S.f) if (n.aiuto) push(n.modo == 'ripara' ? rip : obs, X.L(n.nome));
if (length(E.agg?.ko ?? [])) push(rip, X.L(['aggiornamento', 'update']));
let lx = (A) => map(slice(A, 0, 3), (x) => '❌ ' + cap(x));
if (length(rip)) ev('giorno', cuh(X, '🆘', null, [ X.L(['Serve aiuto per:', 'Help needed for:']), ...lx(rip) ]));
else if (length(obs)) ev('giorno', cuh(X, null, null, [ X.L(['Chiederei aiuto per:', 'I would ask help for:']), ...lx(obs), X.L(['Riparazione spenta', 'Repair off']) ]), true);
else ev('giorno', cuh(X, null, null, [ X.L(['Tutto in ordine', 'All in order']), fix ? fix + ' ' + X.L(['interventi in 24 ore', 'fixes in 24 hours']) : null, oss ? oss + ' ' + X.L(['proposte in osservazione', 'suggestions (watching)']) : null ]), true);
}

function spia(CU, need) {
let w = '' + (CU.spia ?? ''), o = split(trim(readfile(SPIA) ?? ''), '|'), on = length(o[0] ?? '') > 0, night = stat(LSAVE) != null;
if (!match(w, LEDRX) || !stat(LEDS + w)) w = '';
let keep = need && length(w) > 0 && !night;
if (on && (!keep || o[0] != w)) {
let tr = length(o[1] ?? '') ? o[1] : 'none', br = match(o[2] ?? '', /^[0-9]{1,6}$/) ? o[2] : '0';
if (night) {
let L = map(split(readfile(LSAVE) ?? '', '\n'), (l) => split(l, '|')[0] == o[0] ? o[0] + '|' + tr + '|' + br : l);
writefile(LSAVE + '.c', join('\n', L)); rename(LSAVE + '.c', LSAVE);
}
else if (match(o[0], LEDRX) && stat(LEDS + o[0])) {
writefile(LEDS + o[0] + '/trigger', tr);
if (tr == 'none') writefile(LEDS + o[0] + '/brightness', br);
}
unlink(SPIA); on = false;
}
if (keep && !on) {
let t = readfile(LEDS + w + '/trigger') ?? '', cur = match(t, /\[([^\]]+)\]/);
if (index(split(trim(replace(t, /[][]/g, '')), /[ \t\n]+/), 'timer') < 0) return false;
writefile(SPIA, w + '|' + (cur ? cur[1] : 'none') + '|' + trim(readfile(LEDS + w + '/brightness') ?? '0'));
writefile(LEDS + w + '/trigger', 'timer');
writefile(LEDS + w + '/delay_on', '100'); writefile(LEDS + w + '/delay_off', '900');
on = true;
}
return on;
}

function evabase() { let s = stat(EVS); return s ? s.mtime + ' ' + s.size : null; }
function evadd() {
let t = readfile(EVA);
if (t == null) return null;
let b = evabase(), n = index(t, '\n');
if (b == null || n < 0 || substr(t, 0, n) != '#' + b) return { a: null, p: true };
let e = rindex(t, '\n');
return { a: substr(t, n + 1, e - n), p: e != length(t) - 1 };
}
function evmerge() {
let seen = {}, L = [];
for (let l in split((readfile(EVP) ?? '') + '\n' + (readfile(EVS) ?? '') + '\n' + (evadd()?.a ?? '') + '\n' + (readfile(EVT) ?? ''), '\n')) {
if (!match(l, /^[0-9]{1,12}\|/) || seen[l]) continue;
seen[l] = true; push(L, l);
}
if (length(L) > EVMAX) L = slice(L, length(L) - EVMAX);
if (length(L)) { writefile(EVT + '.t', join('\n', L) + '\n'); rename(EVT + '.t', EVT); }
writefile(EVOK, '' + time());
}
function evfull(t) {
mkdir('/etc/wrtfreedom');
if (writefile(EVS + '.t', t) === length(t)) { rename(EVS + '.t', EVS); unlink(EVA); }
else unlink(EVS + '.t');
}
function evput(A, N) {
let b = evabase(), x = join('\n', N) + '\n';
if (A?.a != null && !A.p) {
let f = open(EVA, 'a');
if (f) { f.write(x); f.close(); return; }
}
let w = '#' + b + '\n' + (A?.a ?? '') + x;
if (writefile(EVA + '.t', w) === length(w)) rename(EVA + '.t', EVA);
else unlink(EVA + '.t');
}
function evsave(X, force) {
if (!stat(EVOK)) { evmerge(); force = true; }
let s = stat(EVS), te = stat(EVT), M = rjs(EVM), mt = +(M?.t ?? 0), b = evabase();
let sig = te ? te.mtime + ' ' + te.size + ' ' + te.inode : '';
let last = mt > 0 && mt <= X.now + 60 ? mt : (s && s.mtime <= X.now + 60 ? s.mtime : 0);
if (!force && s && X.now - last < EVEVERY && (M == null || M.b == b)) return;
let t = readfile(EVT);
if (t == null) return;
let day = !s || X.now - s.mtime >= EVDAY || s.mtime > X.now + 60, ea = stat(EVA);
if (!force && s && M?.sig == sig && M.b == b && length(sig) && !(day && ea)) { wjs(EVM, { t: X.now, sig: sig, b: b }); return; }
let A = ea ? evadd() : null, seen = {}, N = [], n = 0;
for (let l in split((s ? readfile(EVS) ?? '' : '') + '\n' + (A?.a ?? ''), '\n')) seen[l] = true;
for (let l in split(A?.a ?? '', '\n')) if (length(l)) n++;
for (let l in split(t, '\n')) if (match(l, /^[0-9]{1,12}\|/) && !seen[l]) { seen[l] = true; push(N, l); }
let pend = ea && (A?.a == null || A.p || length(A.a) > 0);
if (!s || (ea && A?.a == null)) evfull(t);
else if (length(N) || pend) {
if (force || day || A?.p || n + length(N) > EVAMAX) evfull(t);
else if (length(N)) evput(A, N);
}
wjs(EVM, { t: X.now, sig: sig, b: evabase() });
unlink(EVP);
}
function tgqsave() {
let L = sort(filter(lsdir(TGQ) ?? [], (f) => match(f, /^[0-9]{1,12}-[A-Za-z0-9_-]{1,64}$/)));
if (!length(L)) return;
if (length(L) > 100) L = slice(L, length(L) - 100);
mkdir('/etc/wrtfreedom'); mkdir(ESPD); mkdir(TGQS);
for (let f in L) { let t = readfile(TGQ + '/' + f); if (t != null) writefile(TGQS + '/' + f, t); }
}
function tgqback() {
let L = lsdir(TGQS);
if (L == null) return;
mkdir(TGQ);
for (let f in L) {
if (match(f, /^[0-9]{1,12}-[A-Za-z0-9_-]{1,64}$/) && !stat(TGQ + '/' + f)) { let t = readfile(TGQS + '/' + f); if (t != null) writefile(TGQ + '/' + f, t); }
unlink(TGQS + '/' + f);
}
rmdir(TGQS);
}
function boot() {
tgqback();
evmerge();
}
function down() {
let X = ctx();
evsave(X, true);
tgqsave();
let E = rjs(ESPT);
if (type(E) == 'object' && E.v == 1) esave(X, E, true);
else c5hsave();
unlink(MEMON);
}

function riassunto(X, E, CU, sp) {
let im = [];
for (let k, R in E.r) {
let p = split(k, ':');
for (let r, x in R) if (type(x) == 'object' && RIM[r]) push(im, { f: p[0], sin: p[1], r: r, ok: +x.ok, ko: +x.ko, s: +x.ok ? int(+(x.s ?? 0) / +x.ok) : null, scarto: +x.ok == 0 && +x.ko >= SCARTO });
}
let tr = {};
for (let f, t in E.troppi) if (X.now - t < 86400) tr[f] = t + 86400;
let rn = {};
for (let r, x in RIM) rn[r] = x.n;
return { imparato: im, abit: E.abit, agg: E.agg ? { da: E.agg.da, a: E.agg.a, t: E.agg.t, esito: E.agg.esito, ko: E.agg.ko } : null, troppi: tr, notte: notte(X, CU), spia: sp, salvato: E.salvato, rim: rn, giorni: E.giorni ?? {} };
}

const C5R = '/tmp/wf-c5g.mm', C5L = '/tmp/wf-c5g.loc', C5LK = '/tmp/wf-c5g.lock', C5ST = '/tmp/wf-c5g.json', C5D = ESPD + '/c5g.json';
const C5ACT = AGIS, C5RC = RECON, C5NTP = '/tmp/.wf-ntp', C5MM = '/usr/bin/mmcli', C5WD = '/etc/init.d/5g-watchdog';
const C5DEF = { poll: [60, 60, 3600], degr: [5, 1, 100], rwait: [180, 60, 900], cok: [300, 0, 86400], cfail: [300, 60, 86400], cfmax: [1800, 60, 86400],
aaf: [1, 0, 100], ads: [1800, 0, 86400], apf: [900, 0, 86400], amute: [1800, 0, 86400], rmin: [86400, 3600, 604800], rgrace: [900, 300, 86400] };
const C5AL = ['lost', 'fail', 'mute'];
const C5MOB = { modemmanager: true, qmi: true, mbim: true, ncm: true, '3g': true, wwan: true, qcm: true };

function c5min(s) { return int((s < 0 ? 0 : s) / 60); }
function c5ev(tp, txt, sync, quiet) {
let c = (quiet ? 'WF_Q=1 ' : '') + 'sh ' + W + '/event.sh cron ' + q('c5g_' + tp) + ' net ' + q(txt);
sh(sync ? c + ' >/dev/null 2>&1 </dev/null' : '( ' + c + ' ) >/dev/null 2>&1 </dev/null &');
}
function c5disk(M) { mkdir('/etc/wrtfreedom'); mkdir(ESPD); wjs(C5D, M); return rjs(C5D)?.rb == M.rb; }
function c5mmon() { return length(filter(lsdir('/etc/rc.d') ?? [], (f) => match(f, /^S[0-9]{1,3}modemmanager$/))) > 0; }
const C5LS = '/tmp/wf-c5g.list', C5PID = '/tmp/wf-c5g.pid', C5MMF = '/tmp/wf-modem.mm';
const C5TO = stat('/usr/bin/timeout') || stat('/bin/timeout') ? 'timeout 20 ' : '';
function c5gone(j) { let d = '' + (j?.modem?.generic?.device ?? ''); return !!match(d, /^\/sys\//) && !stat(d); }
function c5read(loc) {
if (!mkdir(C5LK)) {
let s = stat(C5LK);
if (s && time() - s.mtime < 300) return;
let p = trim(readfile(C5PID) ?? '');
if (match(p, /^[0-9]{1,10}$/) && index(readfile('/proc/' + p + '/cmdline') ?? '', 'wf-c5g') >= 0) return;
rmdir(C5LK); if (!mkdir(C5LK)) return;
}
let m = C5TO + 'mmcli ', mf = stat(C5MMF), cp = false;
if (mf && time() - mf.mtime < 50 && mf.mtime <= time() + 60) {
let o = readfile(C5MMF), j = null;
try { j = json(o ?? 'null'); } catch (e) { j = null; }
if (type(j?.modem?.generic) == 'object' && !c5gone(j)) { writefile(C5R + '.c', o); rename(C5R + '.c', C5R); cp = true; }
}
if (cp && !loc) { unlink(C5L); rmdir(C5LK); return; }
sh('sh -c ' + q('echo $$ > ' + C5PID + '; ' +
(cp ? '' : '{ ' + m + '-m any -J > ' + C5R + '.t 2>/dev/null && [ -s ' + C5R + '.t ]; } || { ' + m + '-L -J > ' + C5LS + '.t 2>/dev/null; mv -f ' + C5LS + '.t ' + C5LS + '; }; ') +
(loc ? m + '-m any --location-get -J > ' + C5L + '.t 2>/dev/null; ' : '') + (cp ? '' : 'mv -f ' + C5R + '.t ' + C5R + '; ') +
(loc ? 'mv -f ' + C5L + '.t ' + C5L : 'rm -f ' + C5L) + '; rm -f ' + C5PID + '; rmdir ' + C5LK) + ' >/dev/null 2>&1 </dev/null &');
}
function c5pres(X) {
let r = stat(C5R), j = r && X.now - r.mtime <= 150 ? rjs(C5R) : null;
if (type(j?.modem?.generic) == 'object') return !c5gone(j);
let s = stat(C5LS);
if (!s || X.now - s.mtime > 150) return null;
let L = rjs(C5LS)?.['modem-list'];
return type(L) == 'array' ? length(L) > 0 : null;
}
function c5txt(v) { return lc(type(v) == 'array' ? join(',', v) : '' + (v ?? '')); }
function c5mm(X) {
let s = stat(C5R);
if (!s) return null;
let g = rjs(C5R)?.modem?.generic, st = c5txt(g?.state);
if (X.now - s.mtime > 150 || type(g) != 'object' || index(['', 'failed', 'unknown'], st) >= 0) return { ok: false };
let cap = c5txt(g['supported-capabilities']), cur = c5txt(g['current-capabilities']), md = c5txt(g['current-modes']);
let al = match(md, /allowed: ([^;]*)/), c = rjs(C5L)?.modem?.location?.['3gpp'], cid = '' + (c?.cid ?? '');
let mp = '' + (rjs(C5R)?.modem?.['dbus-path'] ?? '');
return { ok: true, st: st, g5: index(c5txt(g['access-technologies']), '5gnr') >= 0, cap5: index(cap, '5gnr') >= 0,
al5: index(cur, '5gnr') >= 0 && (!al || match(al[1], /5g|any/) != null), cell: match(cid, /^[0-9A-Fa-f]{1,16}$/) ? cid : null,
mp: match(mp, /^\/[A-Za-z0-9\/_]{1,80}$/) ? mp : null };
}
function c5opt(X) {
let C = X.cfg('wrtfreedom').c5g ?? {}, o = { al: {} };
for (let k, d in C5DEF) {
let v = '' + (C[k] ?? '');
o[k] = match(v, /^[0-9]{1,7}$/) ? +v : d[0];
if (o[k] < d[1]) o[k] = d[1];
if (o[k] > d[2]) o[k] = d[2];
}
if (o.cfail > o.cfmax) o.cfmax = o.cfail;
o.recon = C.recon != '0'; o.reboot = C.reboot != '0'; o.cella = C.cella != '0'; o.rispetta = C.rispetta != '0';
for (let a in C5AL) o.al[a] = C['al_' + a] != '0';
o.iface = match('' + (C.iface ?? ''), IFRX) ? '' + C.iface : '';
return o;
}
function c5if(X, T) {
if (length(T.iface)) return T.iface;
let L = [];
for (let k, s in X.cfg('network')) if (s['.type'] == 'interface' && C5MOB['' + (s.proto ?? '')] === true && match(k, IFRX) && !ifoff(X, k)) push(L, k);
for (let k in L) if (X.dump()[k]?.up === true) return k;
return L[0];
}
function c5down(X, i) { let d = i ? X.dump()[i] : null; return d != null && d.up !== true; }
const C5ALTRI = [['5g-watchdog', '5g-watchdog'], ['qmodem', 'QModem'], ['qmodem_network', 'QModem'], ['modemwatchdog', 'Modem Watchdog'],
['modem-watchdog', 'Modem Watchdog'], ['wwan-keepalive', 'WWAN Keepalive'], ['lte-watchdog', 'LTE Watchdog'], ['4g-watchdog', '4G Watchdog'],
['cpe-watchdog', 'CPE Watchdog'], ['watchcat', 'Watchcat']];
function c5noti(X, i) {
let rc = lsdir('/etc/rc.d') ?? [], o = [];
let on = (n) => length(filter(rc, (f) => length(f) > length(n) && substr(f, length(f) - length(n)) == n && match(substr(f, 0, length(f) - length(n)), /^S[0-9]{1,3}$/))) > 0;
for (let a in C5ALTRI) {
if (!on(a[0]) || !stat('/etc/init.d/' + a[0]) || length(filter(o, (x) => x.n == a[1]))) continue;
if (a[0] == '5g-watchdog' && '' + (X.cfg('quectel').watchdog?.enabled ?? '1') == '0') continue;
if (a[0] == 'watchcat') {
let w = false;
for (let k, s in X.cfg('watchcat')) if (s['.type'] == 'watchcat' && (s.mode == 'ping_reboot' || (s.mode == 'restart_iface' && (s.interface ?? '') == i))) w = true;
if (!w) continue;
}
push(o, { id: a[0], n: a[1], fw: a[0] == '5g-watchdog' });
}
return o;
}
function c5altro(X, i, N) {
let d = i ? X.dump()[i] : null, u = +(d?.uptime ?? -1);
if (d?.up === true && u >= 0 && u < 600) {
let t = X.now - u, w = +trim(readfile(WANT + i) ?? '0');
if (t > X.now - X.up + 300 && !(w > 0 && w >= t - 120 && w <= t + 60) && !(N.lat > 0 && N.lat >= t - 300)) return 'linea';
}
if (N.mmt > 0 && X.now - N.mmt < 600 && !N.mmown) return 'modem';
return null;
}
function c5busy(X) {
if (stat(C5RC)) return true;
let cl = +trim(readfile(CULN) ?? '0'), dc = X.now - cl;
if (cl > 0 && dc >= -5 && dc < 180) return true;
let a = split(trim(readfile(C5ACT) ?? ''), ' '), d = X.now - +(a[1] ?? 0);
return a[0] == 'wd' && d >= -5 && d < 180;
}
function c5sel(CU) {
let v = '' + (CU.c5g ?? '');
return v == 'fw' ? 'fw' : (v == 'off' || v == '0') ? 'off' : 'wf';
}
function c5on(X, CU, con) {
let M = rjs(C5D) ?? {}, ok = con && M.m5g === true && stat(C5MM) != null && c5mmon(), s = c5sel(CU);
return { M: M, has: M.m5g === true, sel: s, on: ok && s == 'wf', wd: !ok ? 'back' : s == 'fw' ? 'fw' : 'off' };
}
const C5FWF = ESPD + '/c5gfw.json', KD = '/tmp/.wf-k';
function c5fwback(X) {
if (!stat(C5FWF)) return;
let F = rjs(C5FWF), Q = X.cfg('quectel').watchdog, b = '';
if (stat(C5WD) && type(Q) == 'object' && type(F?.prima) == 'object')
for (let k, v in F.prima) {
if (!match(k, /^[a-z0-9_]{1,40}$/) || Q[k] == null || '' + Q[k] != '' + (F.noi?.[k] ?? '')) continue;
b += v == null ? 'delete quectel.watchdog.' + k + '\n' : 'set quectel.watchdog.' + k + '=' + q(v) + '\n';
}
unlink(C5FWF);
if (!length(b)) return;
mkdir(KD, 448);
let f = KD + '/c5gfw.' + X.now;
writefile(f, b);
sh('uci -q batch < ' + f + '; rm -f ' + f + '; uci commit quectel; ( ' + C5WD + ' restart ) >/dev/null 2>&1 </dev/null &');
delete X.C.quectel;
}
function c5wd(X, w, opt) {
if (opt && w != 'fw') c5fwback(X);
let sv = '' + (X.cfg('wrtfreedom').custode?.c5gwd ?? ''), Q = X.cfg('quectel').watchdog, rs = '( ' + C5WD + ' restart ) >/dev/null 2>&1 </dev/null &';
if (w == 'fw') {
if (length(sv)) sh('uci -q delete wrtfreedom.custode.c5gwd; uci commit wrtfreedom');
return;
}
let on = w == 'off';
if (on && !length(sv)) {
if (!stat(C5WD) || type(Q) != 'object') return;
let v = Q.enabled == null ? '-' : '' + Q.enabled;
if (!match(v, /^[-0-9A-Za-z]{1,8}$/)) v = '-';
sh('uci -q get wrtfreedom.custode >/dev/null || uci set wrtfreedom.custode=custode; uci set wrtfreedom.custode.c5gwd=' + q(v) +
'; uci commit wrtfreedom; uci set quectel.watchdog.enabled=0; uci commit quectel; ' + rs);
}
else if (!on && length(sv)) {
let put = stat(C5WD) != null && type(Q) == 'object' && '' + (Q.enabled ?? '') == '0' && sv != '0';
sh((put ? (sv == '-' ? 'uci -q delete quectel.watchdog.enabled' : 'uci set quectel.watchdog.enabled=' + q(sv)) + '; uci commit quectel; ' + rs + ' ' : '') +
'uci -q delete wrtfreedom.custode.c5gwd; uci commit wrtfreedom');
}
}
function c5boot(X, N, M, d, T) {
if (X.up < T.rgrace || c5busy(X)) return false;
let rb = +(M.rb ?? 0), ago = X.now - rb;
if (rb > 0 && ((ago < 0 || M.ntp === false) ? X.up < T.rmin : ago < T.rmin)) return false;
let qq = quiet(X);
if (qq == 'copia' || qq == 'aggiornamento') return false;
M.rb = X.now; M.ntp = stat(C5NTP) != null;
if (!c5disk(M)) return false;
writefile(C5ACT, 'c5g ' + X.now);
let n = c5min(d);
c5ev('reboot', X.L(['🌐 Controllo Del 5G ¦ Modem bloccato da ' + n + ' min ¦ Internet giù ¦ Riavvio il router', '🌐 5G Check ¦ Modem stuck for ' + n + ' min ¦ Internet down ¦ Restarting the router']), true);
N.s = 'riavvio'; N.rb = M.rb;
wjs(C5ST, N);
evsave(X, true); tgqsave();
sh('( sleep 5; reboot ) >/dev/null 2>&1 </dev/null &');
return true;
}
function c5rel() { if (substr(trim(readfile(C5ACT) ?? ''), 0, 4) == 'c5g ') unlink(C5ACT); }
function c5g(X, CU, con) {
let O = c5on(X, CU, con), M = O.M, P = rjs(C5ST) ?? {}, R = c5mm(X), pr = c5pres(X);
if (pr === false && X.up >= 300 && M.m5g !== false) { M.nomod = M.m5g === true; M.m5g = false; c5disk(M); O = c5on(X, CU, con); }
if (R?.ok && (M.m5g !== R.cap5 || M.nomod)) { M.m5g = R.cap5; delete M.nomod; c5disk(M); O = c5on(X, CU, con); }
let c5slow = !O.on && M.m5g === true && M.nomod !== true;
if (stat(C5MM) && c5mmon() && (M.m5g !== false || M.nomod === true || X.now - (stat(C5R)?.mtime ?? 0) > 3600) &&
(!c5slow || X.now - (stat(C5R)?.mtime ?? 0) >= 290)) c5read(!c5slow);
if (!pkgon(X)) c5wd(X, O.wd, O.wd == 'off' || !con);
let T = c5opt(X), i = c5if(X, T), mm = stat(C5MM) != null && c5mmon();
if (O.has && R != null) c5hput(X, !R.ok ? (c5down(X, i) ? '0' : '.') : R.st != 'connected' ? '0' : R.g5 ? '5' : '4');
let N = { v: 2, t: X.now, up: X.up, on: O.on, has: O.has, mm: mm, sel: O.sel, s: O.on ? 'wait' : O.wd == 'fw' ? 'fw' : 'off', iface: i ?? null,
altri: c5noti(X, i), altro: null, rb: M.rb ?? null };
if (!O.on) { if (type(P.act) == 'object') c5rel(); wjs(C5ST, N); return N; }
N.g5 = type(P.g5) == 'bool' ? P.g5 : null; N.st = P.st ?? null; N.cell = P.cell ?? null; N.mp = P.mp ?? null;
N.mmt = +(P.mmt ?? 0); N.mmown = P.mmown === true; N.deg = +(P.deg ?? 0); N.cdu = +(P.cdu ?? 0); N.lat = +(P.lat ?? 0); N.lrs = +(P.lrs ?? 0);
N.tot = +(P.tot ?? 0); N.cf = +(P.cf ?? 0); N.nds = +(P.nds ?? 0); N.fa = P.fa ?? null; N.afl = P.afl === true; N.adl = P.adl === true;
N.aas = P.aas === true; N.pfs = +(P.pfs ?? 0); N.apf = P.apf === true; N.act = type(P.act) == 'object' ? P.act : null; N.ev = +(P.ev ?? 0);
if (+(P.t ?? 0) > 0 && P.up != null && X.up >= +P.up) {
let dr = (X.now - +P.t) - (X.up - +P.up);
if (dr > 120 || dr < -120) {
for (let k in ['nds', 'pfs', 'cdu', 'lat', 'mmt', 'ev']) if (N[k] > 0) N[k] += dr;
if (N.act) N.act.t = +N.act.t + dr;
}
}
if (!N.act && N.ev > 0 && X.now - N.ev < T.poll - 10) { N.s = P.s ?? 'wait'; wjs(C5ST, N); return N; }
N.ev = X.now;
if (R == null) { wjs(C5ST, N); return N; }
let L = (it, en) => X.L([it, en]);
let fine = () => {
if ((N.afl || N.adl) && ((N.adl && T.al.lost) || (N.afl && T.al.fail))) { let n = N.nds > 0 ? c5min(X.now - N.nds) : 0; c5ev('back', L('🌐 Controllo Del 5G ¦ 5G tornato dopo ' + n + ' min', '🌐 5G Check ¦ 5G back after ' + n + ' min')); }
N.cf = 0; N.nds = 0; N.afl = false; N.adl = false; N.fa = null; N.aas = false;
};
if (N.act) {
let a = N.act, d = X.now - +a.t;
if (R.ok && R.g5) {
N.lrs = d; N.lat = X.now; N.cdu = X.now + T.cok; N.act = null; c5rel();
c5ev('recok', L('🌐 Controllo Del 5G ¦ 5G ripreso ¦ Linea ricollegata', '🌐 5G Check ¦ 5G restored ¦ Line reconnected'), false, true);
fine();
N.deg = T.degr; N.g5 = true; N.st = R.st; N.cell = R.cell; N.s = 'ok';
}
else if (d >= T.rwait + 30) {
N.cf++; N.fa = a.cell ?? null; N.lat = X.now; N.lrs = T.rwait + 1; N.act = null; c5rel();
let b = T.cfail;
for (let k = 1; k < N.cf && b < T.cfmax; k++) b *= 2;
if (b > T.cfmax) b = T.cfmax;
N.cdu = X.now + b;
if (T.aaf > 0 && !N.afl && N.cf >= T.aaf && T.al.fail) {
let m = c5min(b);
c5ev('fail', N.cf == 1 ? L('⚠️ Controllo Del 5G ¦ 5G non torna ¦ ❌ 1 tentativo ¦ Riprovo tra ' + m + ' min', '⚠️ 5G Check ¦ 5G not coming back ¦ ❌ 1 attempt ¦ Retrying in ' + m + ' min')
: L('⚠️ Controllo Del 5G ¦ 5G non torna ¦ ❌ ' + N.cf + ' tentativi ¦ Riprovo tra ' + m + ' min', '⚠️ 5G Check ¦ 5G not coming back ¦ ❌ ' + N.cf + ' attempts ¦ Retrying in ' + m + ' min'));
N.afl = true;
}
N.deg = T.degr; N.s = 'pausa';
}
else N.s = 'ricollego';
wjs(C5ST, N);
return N;
}
if (!R.ok) {
if (c5busy(X) && !N.pfs) { N.s = 'attesa'; wjs(C5ST, N); return N; }
N.s = 'muto'; N.pfs = N.pfs || X.now;
let d = X.now - N.pfs, n = c5min(d), dn = c5down(X, i);
if (T.apf > 0 && !N.apf && d >= T.apf) {
if (T.al.mute) c5ev('mute', dn ? L('🌐 Controllo Del 5G ¦ Modem muto da ' + n + ' min ¦ Internet giù', '🌐 5G Check ¦ Modem silent for ' + n + ' min ¦ Internet down')
: L('🌐 Controllo Del 5G ¦ Modem muto da ' + n + ' min ¦ Internet funziona ancora', '🌐 5G Check ¦ Modem silent for ' + n + ' min ¦ Internet still working'));
N.apf = true;
}
if (T.reboot && T.amute > 0 && d >= T.amute && dn && !c5busy(X) && running(inst(X, 'modemmanager')) && pr === true && c5boot(X, N, M, d, T)) return N;
wjs(C5ST, N); return N;
}
if (N.pfs > 0) {
if (N.apf && T.al.mute) { let n = c5min(X.now - N.pfs); c5ev('modemok', L('🌐 Controllo Del 5G ¦ Modem di nuovo raggiungibile ¦ Dopo ' + n + ' min', '🌐 5G Check ¦ Modem reachable again ¦ After ' + n + ' min')); }
N.pfs = 0; N.apf = false;
}
if (R.mp && N.mp && R.mp != N.mp) {
let a = split(trim(readfile(C5ACT) ?? ''), ' ');
N.mmt = X.now; N.mmown = a[0] == 'wd' && X.now - +(a[1] ?? 0) < 300;
}
if (R.mp) N.mp = R.mp;
if (N.fa != null && R.cell != N.fa) { N.fa = null; N.aas = false; N.cf = 0; N.cdu = 0; }
if (N.g5 == null) { if (!R.g5 && !N.nds) N.nds = X.now; }
else if (N.g5 != R.g5) {
if (R.g5) { if (!N.lat || X.now - N.lat > T.rwait) fine(); }
else N.nds = X.now;
}
N.g5 = R.g5; N.st = R.st; N.cell = R.cell;
if (R.st != 'connected' || !R.al5) { N.deg = 0; N.s = R.st != 'connected' ? 'nolinea' : 'no5g_scelta'; }
else if (R.g5) { if (N.cf > 0 || N.afl || N.adl) fine(); N.deg = 0; N.s = 'ok'; }
else {
N.s = 'no5g';
if (N.deg < T.degr) N.deg++;
if (N.deg >= T.degr) {
if (X.now < N.cdu) N.s = 'pausa';
else if (!T.recon) N.s = 'no5g';
else if (T.cella && N.fa != null && R.cell == N.fa) {
if (!N.aas && T.al.fail) c5ev('cell', L('🌐 Controllo Del 5G ¦ 5G perso ¦ Ricollegare non serve ¦ Aspetto un\'altra cella', '🌐 5G Check ¦ 5G lost ¦ Reconnecting will not help ¦ Waiting for another cell'));
N.aas = true; N.s = 'cella';
}
else if (c5busy(X)) N.s = 'attesa';
else if (T.rispetta && (N.altro = c5altro(X, i, N)) != null) N.s = 'altro';
else if (!i) N.s = 'senzalinea';
else if (index(['copia', 'aggiornamento'], quiet(X)) >= 0) N.s = 'attesa';
else {
writefile(C5ACT, 'c5g ' + X.now);
mkdir('/tmp/wf-want');
let w = q(WANT + i), f = q(i);
sh('( echo ' + f + ' > ' + RECON + '; date +%s > ' + w + '; ifdown ' + f + '; n=0; while [ $n -lt 30 ]; do ifstatus ' + f + ' 2>/dev/null | grep -q \'"up": false\' && break; sleep 1; n=$((n+1)); done; date +%s > ' + w + '; ifup ' + f + '; rm -f ' + RECON + ' ) >/dev/null 2>&1 </dev/null &');
N.tot++; N.lat = X.now; N.act = { t: X.now, cell: R.cell }; N.s = 'ricollego';
c5ev('recon', L('🌐 Controllo Del 5G ¦ 5G assente ¦ Ricollego la linea', '🌐 5G Check ¦ 5G missing ¦ Reconnecting the line'), false, true);
}
}
if (T.ads > 0 && !N.adl && N.nds > 0 && X.now - N.nds >= T.ads && T.al.lost) {
let n = c5min(X.now - N.nds);
c5ev('lost', L('🌐 Controllo Del 5G ¦ 5G perso da ' + n + ' min ¦ Solo 4G', '🌐 5G Check ¦ 5G lost for ' + n + ' min ¦ 4G only'));
N.adl = true;
}
}
wjs(C5ST, N);
return N;
}

const FST = '/tmp/wf-fastwd.json', FLK = '/tmp/wf-fastwd.lock', FSEC = [ 30, 60, 120 ], FMAX = 2, FVER = 60, FPEND = 150, FOFF = 300;
const FTAG = { wifi: 'fastwifi', firewall: 'fastfw', bot: 'fastbot', cron: 'fastcron', nas: 'fastnas', memoria: 'fastmem' };
const FRUN = '/tmp/wf-fastwdrun.';
function fopt(C, k) {
let s = +(C[('sec_' + k)] ?? '');
return { on: '' + (C[k] ?? '1') != '0', sec: index(FSEC, s) >= 0 ? s : 30 };
}
function fdef(D, k) { return D.err ? null : filter(D.f, (F) => F.id == k)[0]; }
function fprobe(X, D, F) {
let r = sonda(X, F);
if (r.s == 'ko') for (let d in F.dip) {
let G = fdef(D, d);
if (G && sonda(X, G).s == 'ko') return { s: 'dip', dip: d };
}
return r;
}
const FCHI = [ 'Controllo Automatico', 'Automatic Check' ];
function fev(tp, txt) { sh('( sh ' + W + '/event.sh cron ' + q(tp) + ' custode ' + q(txt) + ' ) >/dev/null 2>&1 </dev/null &'); }
function freg(k, rc, kind) { sh('( ucode ' + W + '/svc.uc log ' + q('wf:' + FTAG[k]) + ' ' + rc + ' ' + kind + ' ) >/dev/null 2>&1 </dev/null &'); }
function fwhat(X, k, sin, det, rim) {
let d = length('' + (det ?? '')) ? '' + det : null;
if (k == 'wifi' && sin == 'radio') return X.L(d ? [ 'radio ' + d + ' riaccesa', d + ' radio restarted' ] : [ 'radio riaccesa', 'radio restarted' ]);
if (k == 'wifi') return X.L(d ? [ 'rete «' + d + '» riaccesa', 'network «' + d + '» restarted' ] : [ 'rete Wi-Fi riaccesa', 'Wi-Fi network restarted' ]);
if (k == 'firewall' && sin == 'porte') return X.L(d ? [ 'porta «' + d + '» rimessa', 'port «' + d + '» restored' ] : [ 'porte rimesse', 'ports restored' ]);
if (k == 'firewall') return X.L([ 'regole ricaricate', 'rules reloaded' ]);
if (k == 'bot') return X.L([ 'bot riavviato', 'bot restarted' ]);
if (k == 'nas' && sin == 'disco') return X.L(d ? [ 'disco «' + d + '» ricollegato', 'disk «' + d + '» reconnected' ] : [ 'disco ricollegato', 'disk reconnected' ]);
if (k == 'nas' && sin == 'servizio') return X.L(d ? [ 'servizio «' + d + '» riavviato', 'service «' + d + '» restarted' ] : [ 'servizio riavviato', 'service restarted' ]);
if (k == 'nas' && rim == 'nasrec') return X.L([ 'registrazioni vecchie cancellate', 'old recordings deleted' ]);
if (k == 'nas' && rim == 'nasferma') return X.L([ 'copie e download fermati', 'copies and downloads stopped' ]);
if (k == 'nas') return X.L([ 'download in pausa', 'downloads paused' ]);
if (k == 'memoria' && rim == 'memcache') return X.L([ 'memoria di passaggio liberata', 'temporary memory freed' ]);
if (k == 'memoria' && rim == 'servizio') return X.L([ 'controlli riavviati', 'checks restarted' ]);
if (k == 'memoria') return X.L([ 'tetti rimessi', 'limits restored' ]);
return X.L([ 'servizio delle attività riavviato', 'task service restarted' ]);
}
function fcap(s) { return uc(substr(s, 0, 1)) + substr(s, 1); }
function fnode(X, p) {
p = type(p) == 'object' ? p : {};
let n = { s: p.s ?? null, t: +(p.t ?? 0), ko: +(p.ko ?? 0), sin: p.sin ?? null, pend: type(p.pend) == 'object' ? p.pend : null, run: p.run ?? null };
n.fix = filter(type(p.fix) == 'array' ? p.fix : [], (t) => X.now - t < 3600 && t <= X.now + 60);
n.last = type(p.last) == 'object' ? p.last : null;
return n;
}
function fstop(X, k, n, run) {
let w = quiet(X);
if (w && !qok(w, k) && (!run || w == 'aggiornamento' || w == 'copia')) return w;
if (fmarked(X, k, 'custode')) return 'custode';
if (length(n.fix) >= FMAX) return 'tetto';
return null;
}
function ffix(X, F, k, r, n) {
if (r.nofix) return false;
let id = null, c = '';
for (let x in (F.rimedi[r.sin] ?? [])) {
id = x; c = rcmd(X, x, r.obj, r.sin, F.id, null);
if (c == null) return null;
if (length(c) || !RIM[x].vuoto) break;
}
if (!id || !length(c)) return false;
fmark(k, 'fast');
sh('( ' + c + ' ) >/dev/null 2>&1 </dev/null &');
push(n.fix, X.now);
n.pend = { t: X.now, r: id, sin: r.sin, det: r.det ?? null };
return true;
}
function fbasta(X, p, r) {
if (type(p) != 'object' || r?.s != 'ko' || r.sin != p.sin) return false;
if (p.r == 'naspausa') return !nasdl(X);
if (p.r == 'nasferma') return !nasdl(X) && !nascp();
if (p.r == 'nasrec') return !nasold(X);
return false;
}
function fdone(X, F, k, n, ok, kind) {
let p = n.pend, nome = X.L(F.nome), w = fwhat(X, k, p.sin, p.det, p.r);
if (ok) {
n.last = { t: X.now, ok: true, what: fcap(w) };
fev('fast_fix', cuh(X, null, nome, [ fcap(w), X.L([ 'Dal ', 'By the ' ]) + X.L(FCHI) ]));
}
else {
let s = X.L(F.sintomi[p.sin]) + (p.det ? ' (' + p.det + ')' : '');
n.last = { t: X.now, ok: false, what: X.L([ 'Non riparato: ', 'Not fixed: ' ]) + s };
fev('fast_fail', cuh(X, '⚠️', nome, [ X.L([ 'Non riparato', 'Not fixed' ]), fcap(s), X.L([ 'Dal ', 'By the ' ]) + X.L(FCHI) ]));
}
freg(k, ok ? 0 : 1, kind);
n.pend = null;
}
function fast() {
if (!mkdir(FLK)) { let s = stat(FLK); if (!s || time() - s.mtime < 60) return; rmdir(FLK); if (!mkdir(FLK)) return; }
let X = ctx(), P = rjs(FST), C = X.cfg('wrtfreedom').fastwd ?? {}, D = null;
X.fast = true;
let PF = type(P?.f) == 'object' ? P.f : {}, S = { v: 1, t: X.now, f: {} };
for (let k in FASTK) {
let n = fnode(X, PF[k]), o = fopt(C, k);
S.f[k] = n;
if (+(n.run ?? 0) > 0 && X.now - n.run < 180 && n.run <= X.now + 60) continue;
n.run = null;
let age = X.now - n.t, urg = k == 'memoria' && o.on && memok(X) && X.mem.avail < X.mem.ris;
if (!urg && age < (o.on ? o.sec : FOFF) - 5 && age >= -60) continue;
D = D ?? dati();
let F = fdef(D, k);
if (!F) { n.s = null; continue; }
n.t = X.now;
let r = fprobe(X, D, F);
n.s = r.s;
if (!o.on) { n.ko = 0; n.sin = null; n.pend = null; continue; }
if (k == 'nas') nasres(X, true, false);
if (k == 'nas' && !quiet(X)) nasretry(X);
if (n.pend) {
if (r.s == 'off' || r.s == 'none' || (r.s == 'ok' && X.ngive && n.pend.r == 'nasmount')) n.pend = null;
else if (r.s == 'ok' || fbasta(X, n.pend, r)) fdone(X, F, k, n, true, 'c');
else if ((r.s == 'ko' && X.now - +(n.pend.t ?? 0) >= FVER) || X.now - +(n.pend.t ?? 0) >= FPEND) fdone(X, F, k, n, false, 'c');
else continue;
}
if (r.s != 'ko') { n.ko = 0; n.sin = null; continue; }
if (n.sin != r.sin) n.ko = 0;
n.sin = r.sin; n.ko++;
if (n.ko < 2 || fstop(X, k, n, false)) continue;
if (ffix(X, F, k, r, n)) n.ko = 0;
}
wjs(FST, S);
rmdir(FLK);
}
function fupd(k, fn) {
let got = false;
for (let i = 0; i < 15 && !got; i++) {
got = mkdir(FLK);
if (got) break;
let s = stat(FLK);
if (s && time() - s.mtime >= 60) { rmdir(FLK); continue; }
sh('sleep 1');
}
let X = ctx(), P = rjs(FST);
P = type(P) == 'object' && type(P.f) == 'object' ? P : { v: 1, t: X.now, f: {} };
let n = fnode(X, P.f[k]);
fn(n, X);
P.f[k] = n;
wjs(FST, P);
if (got) rmdir(FLK);
}
function fastrun(k) {
if (index(FASTK, k) < 0) return;
let D = dati(), F = fdef(D, k), r = null, X = null;
fupd(k, (n, Y) => { n.run = Y.now; });
let esito = (ok, fix, what) => wjs(FRUN + k + '.json', { t: time(), state: ok ? 'ok' : 'err', fix: fix, msg: what });
let fine = (ok, what, rc) => { fupd(k, (n, Y) => { n.run = null; n.last = { t: Y.now, ok: ok, what: what }; if (ok) { n.ko = 0; n.sin = null; } if (rc != null) freg(k, rc, 'n'); }); esito(ok, false, what); };
if (!F) { X = ctx(); fine(false, X.L([ 'Funzione non controllata', 'Function not checked' ]), null); return; }
for (let i = 0; i < 4; i++) {
X = ctx(); X.fast = true;
r = fprobe(X, D, F);
if (r.s != 'wait' || i == 3) break;
sh('sleep 5');
}
if (r.s == 'ok') return fine(true, X.L([ 'Tutto a posto', 'All fine' ]), 0);
if (r.s == 'off') return fine(true, X.L([ 'Spento apposta', 'Turned off on purpose' ]), null);
if (r.s == 'none') return fine(true, X.L([ 'Non presente', 'Not present' ]), null);
if (r.s == 'wait') return fine(false, X.L([ 'In cambiamento: riprova fra poco', 'Changing: try again shortly' ]), null);
if (r.s == 'dip') { let G = fdef(D, r.dip); return fine(false, X.L([ 'In attesa: ', 'Waiting: ' ]) + X.L(G?.nome ?? r.dip) + ' ' + X.L([ 'non va', 'not working' ]), null); }
let st = null, s = X.L(F.sintomi[r.sin]) + (r.det ? ' (' + r.det + ')' : ''), pd = null;
fupd(k, (n, Y) => {
Y.fast = true;
st = fstop(Y, k, n, true);
if (st) return;
let f = ffix(Y, F, k, r, n);
if (f !== true) st = f === null ? 'occupato' : 'nofix';
else pd = n.pend;
});
if (st) {
let M = { aggiornamento: [ 'Aggiornamento in corso: riprova dopo', 'Update in progress: try again later' ], copia: [ 'Copia in attesa di conferma: riprova dopo', 'Backup awaiting confirmation: try again later' ],
custode: [ 'Ci sta già pensando il Custode', 'The Guardian is already on it' ], tetto: [ 'Già ' + FMAX + ' interventi in un\'ora: ci pensa il Custode', 'Already ' + FMAX + ' fixes this hour: the Guardian takes over' ],
occupato: [ 'Firewall occupato: riprova fra poco', 'Firewall busy: try again shortly' ] };
return fine(false, M[st] ? X.L(M[st]) : X.L([ 'Da controllare: ', 'To check: ' ]) + s, 1);
}
let ok = false;
for (let i = 0; i < FVER / 5 && !ok; i++) {
sh('sleep 5');
let Y = ctx();
Y.fast = true;
let rr = fprobe(Y, D, F);
ok = (rr.s == 'ok' && !(Y.ngive && pd?.r == 'nasmount')) || fbasta(Y, pd, rr);
if (rr.s == 'ok' && !ok) break;
}
let lw = null;
fupd(k, (n, Y) => { n.run = null; if (n.pend) fdone(Y, F, k, n, ok, 'n'); if (ok) { n.ko = 0; n.sin = null; } lw = n.last?.what; });
esito(ok, ok, lw ?? '');
}

const FREUSE = { wifi: [ 'ok', 'off', 'none' ], firewall: [ 'ok', 'off', 'none' ], bot: [ 'off', 'none' ], memoria: [ 'ok', 'off', 'none' ] };
function freuse(X, FP, k) {
let n = FP?.[k], t = +(n?.t ?? 0);
if (!FREUSE[k] || type(n) != 'object' || index(FREUSE[k], n.s) < 0 || !(t > 0) || t > X.now || X.now - t >= 20) return null;
return { s: n.s };
}
function memsegno(S) {
let n = S.f?.memoria, on = type(n) == 'object' && index([ 'off', 'none' ], n.s) < 0 && S.bad?.memoria == null;
if (on && trim(readfile(MEMON) ?? '') != '1') writefile(MEMON, '1');
else if (!on && stat(MEMON)) unlink(MEMON);
}
function tick() {
if (!mkdir(LK)) { let s = stat(LK); if (!s || time() - s.mtime < 110) return; rmdir(LK); if (!mkdir(LK)) return; }
mkdir(BATT); writefile(BATT + '/custode', '' + time());
let X = ctx(), P = rjs(ST) ?? {}, PF = type(P.f) == 'object' ? P.f : {}, CU = X.cfg('wrtfreedom').custode ?? {};
evsave(X, false);
let E = eload(X), on = CU.on != '0', rip = ulist(CU.ripara), fuori = ulist(CU.spente), D = dati();
ECNT = E;
let ora = (t, s) => X.now - t < s && t <= X.now + 60;
let S = { v: 1, t: X.now, on: on, silenzio: null, err: D.err ?? null, bad: D.bad ?? {}, f: {}, g:filter(type(P.g) == 'array' ? P.g : [], (t) => ora(t, 3600)), esp: null, c5g: null };
try { S.c5g = c5g(X, CU, on); } catch (e) { S.c5g = null; }
if (D.err) {
if (P.err != D.err) ev('dati', cuh(X, '⚠️', null, [ X.L(['Fermo: dati non validi', 'Stopped: data not valid']), D.err ]), true);
let sp = spia(CU, on && autoesame(X, D, E, S));
S.esp = riassunto(X, E, CU, sp);
esave(X, E, false); memsegno(S); wjs(ST, S); rmdir(LK); return;
}
if (length(keys(S.bad)) && sprintf('%J', P.bad ?? {}) != sprintf('%J', S.bad))
ev('dati', cuh(X, '⚠️', null, [ X.L(['Funzioni ferme: dati errati', 'Functions stopped: bad data']), ...slice(values(S.bad), 0, 3) ]), true);
let ser = ulist(CU.serie), nuove = filter(D.f, (F) => F.serie == 'ripara' && index(ser, F.id) < 0);
if (length(nuove) && stat(CFG + 'wrtfreedom') && !((stat('/tmp/.uci/wrtfreedom')?.size ?? 0) > 0) && !stat(SERMK)) {
let u = 'uci -q -c ' + q(CFG) + ' ', c = u + 'get wrtfreedom.custode >/dev/null || ' + u + 'set wrtfreedom.custode=custode; ';
for (let F in nuove) c += (index(rip, F.id) < 0 ? u + 'add_list wrtfreedom.custode.ripara=' + F.id + '; ' : '') + u + 'add_list wrtfreedom.custode.serie=' + F.id + '; ';
sh(c + u + 'commit wrtfreedom >/dev/null 2>&1');
if (index(ulist(ucread('wrtfreedom').custode?.serie), nuove[0].id) >= 0) { for (let F in nuove) if (index(rip, F.id) < 0) push(rip, F.id); }
else writefile(SERMK, '' + X.now);
}
if (!on) {
for (let F in D.f) {
let p = PF[F.id], none = type(p) == 'object' ? p.s == 'none' : null;
if (none == null) { let r = null; try { r = SONDE[F.sonda].fn(X); } catch (e) { r = null; } none = type(r) == 'object' && r.s == 'none'; }
S.f[F.id] = { nome: F.nome, modo: index(rip, F.id) >= 0 ? 'ripara' : 'osserva', s: none ? 'none' : 'off', ferma: true, fuori: index(fuori, F.id) >= 0,
sin: null, det: null, obj: null, ko: 0, since: null, step: 0, prov: [], aiuto: false, freno: false, dip: null };
}
spia(CU, false); S.esp = riassunto(X, E, CU, false); esave(X, E, false); memsegno(S); wjs(ST, S); rmdir(LK); return;
}
epulisci(E, D);
S.silenzio = quiet(X);
let cur = {}, FP = rjs(FST)?.f;
for (let F in D.f) {
let p = type(PF[F.id]) == 'object' ? PF[F.id] : {}, r = null;
if (index(fuori, F.id) >= 0) {
let n = { nome: F.nome, modo: index(rip, F.id) >= 0 ? 'ripara' : 'osserva', s: 'off', fuori: true, sin: null, det: null, obj: null, ko: 0, since: null, step: 0, prov: [], aiuto: false, freno: false, dip: null };
cur[F.id] = n; S.f[F.id] = n;
continue;
}
r = freuse(X, FP, F.id) ?? sonda(X, F);
let tro = +(E.troppi[F.id] ?? 0) > 0 && X.now - E.troppi[F.id] < 86400 && X.now >= E.troppi[F.id] - 60;
if (!tro) delete E.troppi[F.id];
let n = { nome: F.nome, modo: index(rip, F.id) >= 0 && !tro ? 'ripara' : 'osserva', s: r.s, sin: r.sin ?? null, det: r.det ?? null, obj: r.obj ?? null, nofix: r.nofix === true,
ko: +(p.ko ?? 0), since: p.since ?? null, isin: p.isin ?? null, step: +(p.step ?? 0), last: p.last ?? null,
tent: filter(type(p.tent) == 'array' ? p.tent : [], (t) => ora(t, 3600)), prov: type(p.prov) == 'array' ? p.prov : [], aiuto: p.aiuto === true, freno: false, dip: null,
scala: type(p.scala) == 'array' ? filter(p.scala, (x) => RIM[x] != null) : null, ep: p.ep === true, notte: p.notte === true, sogl: p.sogl ?? null,
rit: type(p.rit) == 'object' ? p.rit : null, t24: filter(type(p.t24) == 'array' ? p.t24 : [], (t) => ora(t, 86400)), pausa: tro ? E.troppi[F.id] + 86400 : null,
ta: p.ta ?? null, avv: p.avv === true, px: p.px === true };
if (n.s == 'ko' && n.isin != null) epnuovo(X, F, n);
let dg = filter(F.dip, (d) => cur[d]?.s == 'ko' || cur[d]?.s == 'dip')[0];
if (dg && n.s == 'ko') { n.s = 'dip'; n.dip = dg; }
if (n.rit) ritorno(X, E, F, n, cur.linea);
cur[F.id] = n;
if (!S.silenzio || qok(S.silenzio, F.id)) step(X, D, F, n, S, E, CU, cur);
S.f[F.id] = n;
}
let ae = autoesame(X, D, E, S);
if (!S.silenzio && (E.agg == null || E.agg.esito != null)) E.prima = filter(keys(S.f), (id) => S.f[id].s == 'ok');
giornata(X, E, S);
let need = ae || length(filter(values(S.f), (n) => (n.aiuto || n.avv) && n.modo == 'ripara')) > 0;
S.esp = riassunto(X, E, CU, spia(CU, need));
esave(X, E, false);
memsegno(S);
wjs(ST, S);
rmdir(LK);
}

const A = ARGV[0] ?? '';
if (A == 'tick') tick();
else if (A == 'boot') boot();
else if (A == 'down') down();
else if (A == 'fine') { spia({}, false); }
else if (A == 'c5gsync') { let X = ctx(), CU = X.cfg('wrtfreedom').custode ?? {}, w = c5on(X, CU, CU.on != '0').wd; c5wd(X, w, w == 'off' || CU.on == '0'); }
else if (A == 'c5gback') c5wd(ctx(), 'back', true);
else if (A == 'fast') fast();
else if (A == 'fastrun') fastrun('' + (ARGV[1] ?? ''));
else if (A == 'nasdirs') nasdirs(ctx());
else print('uso: ucode custode.uc tick|boot|down|fine|c5gsync|c5gback|fast|fastrun <funzione>|nasdirs\n');
