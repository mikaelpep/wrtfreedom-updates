'use strict';
import { popen, readfile, writefile, lsdir, stat, rename, unlink } from 'fs';

const OUT = '/tmp/wf-fw.json';
function cutb(s, n) {
s = '' + s;
if (length(s) <= n) return s;
while (n > 0 && (ord(s, n) & 192) == 128) n--;
return substr(s, 0, n);
}
function cut(s, n) {
s = '' + s;
if (length(s) <= n) return s;
let c = cutb(s, n - 3), sp = rindex(c, ' '), lf = rindex(c, '\n');
if (lf > sp) sp = lf;
if (sp > length(c) * 0.8) c = substr(c, 0, sp);
return rtrim(c) + '…';
}
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function get(url) {
if (stat('/bin/uclient-fetch') || stat('/usr/bin/uclient-fetch'))
return sh('uclient-fetch -q -T 25 -O - ' + q(url) + ' 2>/dev/null');
return sh('curl -fsSL -m 30 -A wrtfreedom ' + q(url) + ' 2>/dev/null');
}
function J(url) { let t = get(url); if (!length(t)) return null; try { return json(t); } catch (e) { return null; } }
function kv(f) {
let r = {};
for (let l in split(readfile(f) ?? '', '\n')) {
let m = match(l, /^([A-Z_]+)=(.*)$/);
if (m) r[m[1]] = replace(replace(trim(m[2]), /^['"]/, ''), /['"]$/, '');
}
return r;
}
function rnum(rev) { let m = match('' + rev, /^r(\d+)/); return m ? +m[1] : 0; }
function iso(s) {
let m = match('' + s, /^(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)/);
if (!m) return 0;
let y = +m[1], mo = +m[2], d = +m[3];
if (mo <= 2) { y--; mo += 12; }
let days = 365 * y + int(y / 4) - int(y / 100) + int(y / 400) + int((153 * (mo - 3) + 2) / 5) + d - 719469;
return days * 86400 + (+m[4]) * 3600 + (+m[5]) * 60 + (+m[6]);
}
function vcmp(a, b) {
let x = split('' + a, '.'), y = split('' + b, '.');
for (let i = 0; i < 3; i++) { let p = +(x[i] ?? 0), r = +(y[i] ?? 0); if (p != r) return p > r ? 1 : -1; }
return 0;
}

if (getenv('WF_FW_CLOUD')) {
let en = trim(sh('uci -q get wrtfreedom.ui.lang 2>/dev/null')) == 'en', L = (i, e) => en ? e : i;
let C = null;
try { C = json(readfile('/etc/wrtfreedom/cloud.json') ?? 'null'); } catch (e) {}
let T = type(C) == 'object' ? C.router : null;
const CX = '/usr/share/wrtfreedom/cloudx.sh', JD = '/tmp/wf-cloud/jobs';
if (type(T) != 'object' || T.on !== true || T.before_fw === false) exit(0);
let no = (w, we) => { print('## ', L('Copia del router nel cloud non riuscita (' + w + '): il firmware si installa lo stesso',
'Router backup to the cloud failed (' + we + '): the firmware is installed anyway'), '\n'); exit(0); };
if (!stat(CX)) no('Cloud non installato', 'Cloud not installed');
let max = +(getenv('WF_FW_CLOUDMAX') ?? 120);
if (!(max >= 1 && max <= 120)) max = 120;
let id = 'rtfw' + time(), F = JD + '/' + id + '.json';
sh('mkdir -p ' + JD + ' && chmod 700 /tmp/wf-cloud');
if (!writefile(F, sprintf('%J\n', { job: id, kind: 'router', name: 'Copia Del Router', state: 'wait', t: time() })))
no('lavoro non scritto', 'job not written');
let pid = +trim(sh('sh ' + q(CX) + ' router ' + id + ' </dev/null >/dev/null 2>&1 & echo $!'));
let alive = () => pid > 0 && trim(sh('kill -0 ' + pid + ' 2>/dev/null && echo 1')) == '1';
let job = () => { try { return json(readfile(F) ?? '{}'); } catch (e) { return {}; } };
let t0 = time();
while (alive() && time() - t0 < max) sh('sleep 1');
if (alive()) {
writefile(JD + '/' + id + '.stop', '');
for (let i = 0; i < 10 && alive(); i++) sh('sleep 1');
let p = +(job().pid ?? 0);
if (alive()) sh('kill ' + pid + (p > 0 ? ' ' + p : '') + ' 2>/dev/null');
no('oltre 2 minuti', 'over 2 minutes');
}
let J0 = job(), cl = (s) => replace('' + (s ?? ''), /[\r\n]+/g, ' ');
if (J0.state == 'ok') { print('## ', L('Copia del router salvata nel cloud', 'Router backup saved to the cloud'), '\n'); exit(0); }
if (J0.state == 'err' && length(J0.err)) no(cl(J0.err), cl(J0.err_en || J0.err));
if (J0.state == 'wait') no('linea o account non disponibili adesso', 'line or account not available now');
no('non finita', 'not finished');
}

let R = kv('/etc/openwrt_release'), O = kv('/etc/os-release');
let board = trim(readfile('/tmp/sysinfo/board_name') ?? ''), bid = replace(board, ',', '_');
let cur = { version: R.DISTRIB_RELEASE ?? '', revision: R.DISTRIB_REVISION ?? '', target: R.DISTRIB_TARGET ?? '',
date: +(O.OPENWRT_BUILD_DATE ?? 0), board: board };
let res = { t: time(), cur: cur, kind: '', newer: false, latest: null, err: '' };

let feeds = '';
for (let d in ['/etc/apk/repositories.d', '/etc/opkg'])
for (let f in (lsdir(d) ?? [])) feeds += (readfile(d + '/' + f) ?? '') + '\n';
feeds += (readfile('/etc/apk/repositories') ?? '') + '\n';
let owner = null, tag = null;
for (let l in split(feeds, '\n')) {
if (match(l, /^\s*#/)) continue;
let m = match(l, /https?:\/\/([A-Za-z0-9-]+)\.github\.io\/[^[:space:]]*\/kmods\/([A-Za-z0-9._-]+)\//);
if (m) { owner = m[1]; tag = m[2]; break; }
}
let repo = trim(sh('uci -q get wrtfreedom.fw.repo'));
const TEST = getenv('WF_FW_TEST');
if (TEST) { repo = ''; owner = null; tag = null; if (TEST != 'snapshot') cur.version = TEST; }

function asset(rel) {
let best = null;
for (let a in (rel.assets ?? [])) {
let n = a.name ?? '';
if (!match(n, /sysupgrade/)) continue;
if (length(bid) && index(n, bid) >= 0) return a;
if (!best) best = a;
}
return best;
}

let efi = !!stat('/sys/firmware/efi'), fs = match(readfile('/proc/mounts') ?? '', /(^|\n)[^ \n]+ \/rom /) ? 'squashfs' : 'ext4';
function pick(L) {
let best = null, rank = 0;
for (let i in (L ?? [])) {
let r = i.type == 'sysupgrade' ? 4 : i.type == (efi ? 'combined-efi' : 'combined') ? 2 : 0;
if (!r) continue;
if (i.filesystem == fs) r++;
if (r > rank) { rank = r; best = i; }
}
return best;
}
let prof = null;	// nome del profilo scelto (per ASU)
function image(p) {
let ps = p?.profiles ?? {}, pr = ps[bid]; prof = pr ? bid : null;
if (!pr) for (let k, v in ps) if (index(v?.supported_devices ?? [], board) >= 0) { pr = v; prof = k; break; }
if (!pr) { pr = ps.generic; prof = pr ? 'generic' : null; }
return pick(pr?.images);
}

function bare(l) { return trim(replace(l, /[<>=~@].*$/, '')); }
function added() {
let w = readfile('/etc/apk/world'), out = [], H = {};
if (w != null) {
for (let l in split(readfile('/rom/etc/apk/world') ?? '', '\n')) H[bare(l)] = true;
for (let l in split(w, '\n')) { let n = bare(l); if (length(n) && !H[n]) push(out, n); }
}
else {
for (let b in split(readfile('/rom/usr/lib/opkg/status') ?? '', '\n\n')) { let m = match(b, /Package: ([^\n]+)/); if (m) H[trim(m[1])] = true; }
for (let b in split(readfile('/usr/lib/opkg/status') ?? '', '\n\n')) {
let m = match(b, /Package: ([^\n]+)/);
if (m && match(b, /Status:[^\n]*user installed/) && !H[trim(m[1])]) push(out, trim(m[1]));
}
}
return sort(uniq(filter(out, (n) => match(n, /^[A-Za-z0-9._+-]+$/))));
}

const AURL = getenv('WF_ASU_URL') ?? 'https://sysupgrade.openwrt.org';
if (getenv('WF_ASU')) {
const AO = '/tmp/wf-asu.json';
let st = (s, m, x) => { let o = { st: s, msg: m, t: time() }; for (let k, v in (x ?? {})) o[k] = v; writefile(AO + '.t', sprintf('%J', o)); rename(AO + '.t', AO); };
let curl = (a) => { let o = sh('curl -sS -m 40 ' + a + ' 2>/dev/null'); try { return json(o); } catch (e) { return null; } };
let r = null;
try { r = json(readfile(OUT) ?? 'null'); } catch (e) {}
let A = r?.latest?.asu;
if (!A) { st('err', 'controlla prima il firmware: ASU vale solo per OpenWrt ufficiale'); exit(0); }
if (!stat('/usr/bin/curl')) { st('err', 'serve il pacchetto curl: installalo da Software, Pacchetti'); exit(0); }
let miss = {};
for (let n in (r.pk?.miss ?? [])) miss[n] = true;
let P = filter(added(), (n) => !miss[n]);
let Q = { target: A.target, profile: A.profile, version: A.version, packages: P, diff_packages: false,
client: 'wrtfreedom/' + trim(readfile('/usr/share/wrtfreedom/VERSION') ?? '') };
if (match(A.target, /^x86\//))
for (let d in ['vda2', 'sda2', 'nvme0n1p2', 'mmcblk0p2', 'hda2']) {
let z = readfile('/sys/class/block/' + d + '/size');
if (z) { Q.rootfs_size_mb = min(1024, int(+trim(z) * 512 / 1048576)); break; }
}
writefile('/tmp/wf-asu.req', sprintf('%J', Q));
st('run', 'Chiedo il firmware con i tuoi pacchetti', { n: length(P) });
let x = curl("-X POST -H 'Content-Type: application/json' --data-binary @/tmp/wf-asu.req " + q(AURL + '/api/v1/build'));
let h = x?.request_hash, i = 0;
while (x?.status == 202 && h && i++ < 90) {
st('run', x.queue_position ? 'In coda (posizione ' + x.queue_position + ')' : 'Costruisco il firmware con i tuoi pacchetti', { n: length(P) });
sleep(10000);
x = curl(q(AURL + '/api/v1/build/' + h));
}
unlink('/tmp/wf-asu.req');
let img = x?.status == 200 ? pick(x.images) : null;
if (img && x.bin_dir)
st('ok', 'Firmware pronto', { file: AURL + '/store/' + x.bin_dir + '/' + img.name, fname: img.name, sha256: img.sha256 ?? '', n: length(P) });
else {
let c = match('' + (x?.detail ?? ''), /conflicts \(([^)]+)\)/);
st('err', x == null ? 'il servizio di OpenWrt non risponde' : x.status == 202 ? 'la costruzione è troppo lenta: riprova più tardi' :
c ? 'due pacchetti aggiunti non possono stare insieme in un firmware nuovo (' + replace(c[1], /-[0-9][^,]*/g, '') + ')' :
'il servizio di OpenWrt non ha potuto costruirlo' + (x.detail ? ' (' + substr('' + x.detail, 0, 160) + ')' : ''));
}
exit(0);
}

if (!length(repo) && owner && tag) {
let rs = J('https://api.github.com/users/' + owner + '/repos?per_page=100&sort=pushed') ?? [];
let n = 0;
for (let r in rs) {
if (n++ >= 25) break;
if (r.fork) continue;
let rel = J('https://api.github.com/repos/' + r.full_name + '/releases/tags/' + tag);
if (rel && rel.tag_name == tag) {
repo = r.full_name;
sh('uci -q get wrtfreedom.fw >/dev/null || uci set wrtfreedom.fw=firmware; uci set wrtfreedom.fw.repo=' + q(repo) + '; uci set wrtfreedom.fw.auto=1; uci commit wrtfreedom');
break;
}
}
}

if (!length(repo) && owner && tag) {
res.kind = 'github'; res.tag = tag;
res.err = 'progetto del firmware personalizzato non trovato su GitHub (' + owner + '): riprovo più tardi';
}
else if (length(repo)) {
res.kind = 'github'; res.repo = repo; res.tag = tag;
let rels = J('https://api.github.com/repos/' + repo + '/releases?per_page=15');
if (type(rels) != 'array') res.err = 'GitHub non raggiungibile';
else {
let L = filter(rels, (r) => !r.draft && !r.prerelease && asset(r));
let last = L[0];
if (!last) res.err = 'nessuna release con il firmware per questo modello';
else {
let a = asset(last);
res.latest = { tag: last.tag_name, name: last.name ?? last.tag_name, date: iso(last.published_at), url: last.html_url,
file: a.browser_download_url, fname: a.name, size: a.size, notes: cut(last.body ?? '', 700) };
let mine = tag ? filter(L, (r) => r.tag_name == tag)[0] : null;
if (mine) res.cur.name = mine.name ?? mine.tag_name;
res.newer = tag ? last.tag_name != tag && (!mine || iso(last.published_at) > iso(mine.published_at))
: iso(last.published_at) > cur.date + 86400;
for (let x in (last.assets ?? []))
if (x.name == 'SHA256SUMS' || x.name == 'sha256sums') {
for (let l in split(get(x.browser_download_url), '\n')) {
let m = match(l, /^([0-9a-f]{64})\s+\*?(.+)$/);
if (m && trim(m[2]) == a.name) res.latest.sha256 = m[1];
}
}
}
}
}
else {
let base = O.FIRMWARE_URL ?? 'https://downloads.openwrt.org/';
if (substr(base, -1) != '/') base += '/';
let snap = match(cur.version, /SNAPSHOT/);
if (snap) {
res.kind = 'snapshot';
let dir = base + (cur.version == 'SNAPSHOT' ? 'snapshots/' : 'releases/' + cur.version + '/') + 'targets/' + cur.target + '/';
let p = J(dir + 'profiles.json');
if (!p) res.err = 'server di OpenWrt non raggiungibile';
else {
let img = image(p);
res.latest = { tag: p.version_code, name: 'OpenWrt ' + (p.version_number ?? cur.version) + ' ' + p.version_code,
url: dir, file: img ? dir + img.name : null, fname: img?.name, sha256: img?.sha256 };
if (img && prof) res.latest.asu = { target: cur.target, profile: prof, version: cur.version };
res.newer = rnum(p.version_code) > rnum(cur.revision);
if (!img) res.err = 'nessun firmware per ' + board + ' in questa build';
}
}
else {
res.kind = 'stable';
let V = J('https://downloads.openwrt.org/.versions.json');
if (!V) res.err = 'server di OpenWrt non raggiungibile';
else {
let ser = join('.', slice(split(cur.version, '.'), 0, 2)), best = null, major = V.stable_version;
for (let v in (V.versions_list ?? [])) {
if (match(v, /rc|SNAPSHOT/)) continue;
if (index(v, ser + '.') == 0 && vcmp(v, cur.version) > 0 && (!best || vcmp(v, best) > 0)) best = v;
}
let nv = best ?? (major && vcmp(major, cur.version) > 0 ? major : null);
res.major = !best && nv != null;
if (nv) {
let dir = base + 'releases/' + nv + '/targets/' + cur.target + '/', p = J(dir + 'profiles.json'), img = image(p);
res.latest = { tag: nv, name: 'OpenWrt ' + nv, url: dir, file: img ? dir + img.name : null, fname: img?.name, sha256: img?.sha256 };
if (img && prof) res.latest.asu = { target: cur.target, profile: prof, version: nv };
res.newer = true;
if (!img) res.err = 'nessun firmware per ' + board + ' nella ' + nv;
}
else res.latest = { tag: cur.version, name: 'OpenWrt ' + cur.version };
}
}
}

function vdir() {
let v = cur.version;
if (res.kind == 'stable') return 'releases/' + res.latest.tag;
if (res.kind == 'github') {
let m = match((res.latest.name ?? '') + ' ' + (res.latest.notes ?? ''), /OpenWrt v?([0-9]+\.[0-9]+\.[0-9]+)/);
if (m) return 'releases/' + m[1];
}
return v == 'SNAPSHOT' ? 'snapshots' : 'releases/' + v;
}
if (res.newer && res.latest) {
let A = added(), arch = R.DISTRIB_ARCH ?? '', H = {}, off = 0, uk = 0, other = [];
let base = O.FIRMWARE_URL ?? 'https://downloads.openwrt.org/';
if (substr(base, -1) != '/') base += '/';
let vd = vdir();
let rd = (u) => { let x = J(u); if (type(x?.packages) != 'object') return false; for (let n in keys(x.packages)) H[n] = true; return true; };
for (let f in ['base', 'packages', 'luci', 'routing', 'telephony', 'video'])
if (!rd(base + vd + '/packages/' + arch + '/' + f + '/index.json') && index(['base', 'packages', 'luci'], f) >= 0) off++;
rd(base + vd + '/targets/' + cur.target + '/packages/index.json');
for (let l in split(feeds, '\n')) {
let m = match(l, /^\s*(https?:\/\/[^[:space:]]+)\/(packages\.adb|Packages\.gz|Packages)\s*$/) ??
match(l, /^\s*src\/gz\s+\S+\s+(https?:\/\/[^[:space:]]*[^\/[:space:]])\/?\s*$/);
if (m && !match(m[1], /downloads\.openwrt\.org|\/kmods\//)) push(other, m[1]);
}
for (let u in uniq(other)) if (!rd(u + '/index.json')) uk++;
let ks = filter(A, (n) => match(n, /^kmod-/)), ps = filter(A, (n) => !match(n, /^kmod-/));
res.pk = { n: length(ps), kmod: length(ks), miss: [], ver: vd };
if (!length(arch) || off) res.pk.err = 'repository della versione nuova non raggiungibili';
else {
let miss = filter(ps, (n) => !H[n]);
if (uk) res.pk.unk = miss; else res.pk.miss = miss;
}
}

writefile(OUT + '.t', sprintf('%J', res));
rename(OUT + '.t', OUT);
