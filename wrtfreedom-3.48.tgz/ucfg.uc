import { readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, popen, open, readlink, error as ferr } from 'fs';

function uval0(v) {
v = trim(v ?? '');
let c = substr(v, 0, 1), o = '', i = 1, n = length(v);
if (c == "'") {
while (i < n) {
let ch = substr(v, i, 1);
if (ch == "'") { if (substr(v, i, 4) == "'\\''") { o += "'"; i += 4; continue; } break; }
o += ch; i++;
}
return o;
}
if (c == '"') {
while (i < n) {
let ch = substr(v, i, 1);
if (ch == '\\') { o += substr(v, i + 1, 1); i += 2; continue; }
if (ch == '"') break;
o += ch; i++;
}
return o;
}
return split(v, /[ \t]+/)[0] ?? '';
}
function uopen(l) {
if (index(l, "'") < 0 && index(l, '"') < 0) return false;
if (index(l, '"') < 0 && index(l, '\\') < 0 && length(split(l, "'")) % 2 == 1) return false;
let sq = false, dq = false;
for (let i = 0; i < length(l); i++) {
let ch = substr(l, i, 1);
if (sq) { if (ch == "'") sq = false; }
else if (dq) { if (ch == '\\') i++; else if (ch == '"') dq = false; }
else if (ch == '\\') i++;
else if (ch == "'") sq = true;
else if (ch == '"') dq = true;
else if (ch == '#') break;
}
return sq || dq;
}
function parse(txt, ml, uv) {
let r = {}, cur = null, cnt = {}, buf = null, uval = uv ?? uval0;
for (let l in split(txt ?? '', '\n')) {
if (ml) {
if (buf != null) { l = buf + '\n' + l; buf = null; }
if (uopen(l)) { buf = l; continue; }
}
let m = match(l, /^[ \t]*(config|option|list)[ \t]+([^ \t]+)/);
if (!m) continue;
let rest = trim(substr(l, length(m[0])));
if (m[1] == 'config') {
let t = uval(m[2]), n = length(rest) ? uval(rest) : '';
cnt[t] = (cnt[t] ?? -1) + 1;
if (!length(n)) n = '@' + t + '[' + cnt[t] + ']';
cur = r[n] = r[n] ?? { '.type': t };
}
else if (cur) {
let k = uval(m[2]), v = uval(rest);
if (m[1] == 'list') { if (type(cur[k]) != 'array') cur[k] = []; push(cur[k], v); }
else cur[k] = v;
}
}
return r;
}
function read(f, ml) { return parse(readfile(f) ?? '', ml); }

function lockdir(d, max) {
if (mkdir(d)) return d;
let s = stat(d);
if (s && time() - s.mtime > max) { rmdir(d); if (mkdir(d)) return d; }
return null;
}
const NJLK = '/tmp/wf-nas/nasjson.lock', NJPID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
function pstale(d, st) {
let s = stat(d), p = trim(readfile(d + '/pid') ?? '');
if (s == null) return false;
return p == NJPID || (match(p, /^[0-9]+$/) != null && stat('/proc/' + p) == null) || time() - s.mtime > st || s.mtime > time() + 60;
}
function pidlock(d, top, st) {
mkdir(top);
let b = d + '.brk';
for (let i = 0; i <= 20; i++) {
if (mkdir(d)) { writefile(d + '/pid', NJPID); return true; }
if (pstale(d, st)) {
let bs = stat(b);
if (bs && (time() - bs.mtime > st || bs.mtime > time() + 60)) rmdir(b);
if (mkdir(b)) {
if (pstale(d, st)) { unlink(d + '/pid'); rmdir(d); }
rmdir(b);
if (mkdir(d)) { writefile(d + '/pid', NJPID); return true; }
}
}
if (i < 20) sleep(100);
}
return false;
}
function pidunlock(d) { if (trim(readfile(d + '/pid') ?? '') == NJPID) { unlink(d + '/pid'); rmdir(d); } }
function njlock() { return pidlock(NJLK, '/tmp/wf-nas', 10); }
function njunlock() { pidunlock(NJLK); }
function njset(rd, fn, wr) {
if (!njlock()) return null;
let o = rd();
try { fn(o); wr(o); } catch (e) { o = null; }
njunlock();
return o;
}
function uvalq(s) { s = trim('' + s); let a = substr(s, 0, 1); return (a == "'" || a == '"') && substr(s, -1) == a ? substr(s, 1, length(s) - 2) : s; }

function enc(x) { return sprintf('%J', x); }
function akey(x) { return type(x) != 'object' ? null : (x.id != null ? 'i' + x.id : (x.cam != null ? 'c' + x.cam : (x.name != null ? 'n' + x.name : null))); }
function amerge(f, o, n) {
f = type(f) == 'array' ? f : []; o = type(o) == 'array' ? o : [];
let sc = (a) => !length(filter(a, (x) => type(x) == 'object' || type(x) == 'array'));
if (sc(f) && sc(o) && sc(n)) {
let r = filter(f, (x) => index(n, x) >= 0 || index(o, x) < 0);
for (let x in n) if (index(o, x) < 0 && index(r, x) < 0) push(r, x);
return r;
}
let K = (a) => { let m = {}; for (let x in a) { let k = akey(x); if (k == null || m[k]) return null; m[k] = x; } return m; };
let F = K(f), O = K(o), X = K(n);
if (!F || !O || !X) return n;
let r = [];
for (let x in f) { let k = akey(x); if (X[k] && enc(X[k]) != enc(O[k])) push(r, X[k]); else if (!O[k] || X[k]) push(r, x); }
for (let x in n) { let k = akey(x); if (!F[k] && !O[k]) push(r, x); }
return r;
}
function omerge(f, o, n) {
o = type(o) == 'object' ? o : {};
for (let k, v in n) {
if (enc(v) == enc(o[k])) continue;
if (type(v) == 'object' && type(f[k]) == 'object') omerge(f[k], o[k], v);
else if (type(v) == 'array' && type(f[k]) == 'array') f[k] = amerge(f[k], o[k], v);
else f[k] = v;
}
let nk = {};
for (let k in keys(n)) nk[k] = 1;
for (let k in keys(o)) if (!nk[k]) delete f[k];
}
function njget(f, REG) {
let s = readfile(f), N = null, O = null;
try { N = json(s ?? '{}'); O = json(s ?? '{}'); } catch (e) {}
if (type(N) != 'object') { N = {}; O = null; }
push(REG, [ N, O ]);
return N;
}
function njput(N, REG, f, wr) {
let O = null, e = null;
for (let x in REG) if (x[0] === N) e = x;
if (e) O = e[1];
if (!njlock()) return false;
let raw = readfile(f), F = null;
try { F = json(raw ?? '{}'); } catch (x) { F = null; }
if (type(F) != 'object' || O == null) F = N; else omerge(F, O, N);
let s = enc(F);
if (raw != s) wr(s, F);
njunlock();
if (e) e[1] = json(enc(N));
return true;
}

function modof(C, f) {
let s = stat(f);
if (!s) return null;
let k = s.mtime + ':' + s.size + ':' + s.inode, c = C[f];
if (c?.k == k) return c.m;
let m = null;
try { m = loadfile(f)(); } catch (e) { m = null; }
if (m != null) C[f] = { k: k, m: m }; else delete C[f];
return m;
}

const VPNCITY = { zurich: 'Zurigo', geneva: 'Ginevra', london: 'Londra', paris: 'Parigi', brussels: 'Bruxelles', frankfurt: 'Francoforte',
munich: 'Monaco Di Baviera', berlin: 'Berlino', hamburg: 'Amburgo', cologne: 'Colonia', prague: 'Praga', warsaw: 'Varsavia', lisbon: 'Lisbona',
barcelona: 'Barcellona', copenhagen: 'Copenaghen', stockholm: 'Stoccolma', athens: 'Atene', bucharest: 'Bucarest', belgrade: 'Belgrado',
dublin: 'Dublino', edinburgh: 'Edimburgo', rome: 'Roma', milan: 'Milano', turin: 'Torino', naples: 'Napoli', florence: 'Firenze',
venice: 'Venezia', moscow: 'Mosca', kyiv: 'Kiev', marseille: 'Marsiglia', lyon: 'Lione', strasbourg: 'Strasburgo', luxembourg: 'Lussemburgo',
ljubljana: 'Lubiana', zagreb: 'Zagabria', 'mexico city': 'Città Del Messico', 'sao paulo': 'San Paolo', 'são paulo': 'San Paolo',
'cape town': 'Città Del Capo', philadelphia: 'Filadelfia', 'new york': 'New York', 'tel aviv': 'Tel Aviv',
antwerp: 'Anversa', seville: 'Siviglia', nuremberg: 'Norimberga', basel: 'Basilea', bern: 'Berna', lucerne: 'Lucerna',
krakow: 'Cracovia', gdansk: 'Danzica', thessaloniki: 'Salonicco', valletta: 'La Valletta', gothenburg: 'Göteborg', kiev: 'Kiev',
'saint petersburg': 'San Pietroburgo', 'st petersburg': 'San Pietroburgo', seoul: 'Seul', beijing: 'Pechino', 'new delhi': 'Nuova Delhi',
cairo: 'Il Cairo', jerusalem: 'Gerusalemme', bogota: 'Bogotà', montreal: 'Montréal' };
const VPNCC = { CH: 'Svizzera', IT: 'Italia', DE: 'Germania', FR: 'Francia', GB: 'Regno Unito', UK: 'Regno Unito', US: 'Stati Uniti',
NL: 'Paesi Bassi', BE: 'Belgio', AT: 'Austria', ES: 'Spagna', PT: 'Portogallo', SE: 'Svezia', NO: 'Norvegia', DK: 'Danimarca',
FI: 'Finlandia', PL: 'Polonia', CZ: 'Repubblica Ceca', SK: 'Slovacchia', HU: 'Ungheria', RO: 'Romania', BG: 'Bulgaria', GR: 'Grecia',
IE: 'Irlanda', LU: 'Lussemburgo', SI: 'Slovenia', HR: 'Croazia', RS: 'Serbia', AL: 'Albania', EE: 'Estonia', LV: 'Lettonia',
LT: 'Lituania', IS: 'Islanda', CY: 'Cipro', MT: 'Malta', MD: 'Moldavia', UA: 'Ucraina', TR: 'Turchia', RU: 'Russia', CA: 'Canada',
MX: 'Messico', BR: 'Brasile', AR: 'Argentina', CL: 'Cile', JP: 'Giappone', KR: 'Corea Del Sud', SG: 'Singapore', HK: 'Hong Kong',
IN: 'India', AU: 'Australia', NZ: 'Nuova Zelanda', ZA: 'Sudafrica', IL: 'Israele', AE: 'Emirati Arabi Uniti' };
function vpnplace(city, cc) {
cc = uc('' + (cc ?? ''));
let c = VPNCITY[lc(trim('' + (city ?? '')))] ?? city ?? '', p = VPNCC[cc];
return length(c) ? c + (p ? ', ' + p : length(cc) ? ' (' + cc + ')' : '') : (p ?? cc);
}

function hk(s) {
let a = 2166136261, b = 5381;
for (let i = 0; i < length(s); i++) { let c = ord(s, i); a = ((a ^ c) * 16777619) & 0xffffffff; b = ((b * 33) ^ c) & 0xffffffff; }
return sprintf('%08x%08x', a, b);
}
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function b64raw(s) {
let o = [], v = 0, n = 0;
for (let i = 0; i < length(s); i++) {
let c = index(B64, substr(s, i, 1));
if (c < 0) continue;
v = ((v << 6) | c) & 0xffffff; n += 6;
if (n >= 8) { n -= 8; push(o, chr((v >> n) & 255)); }
}
return join('', o);
}
function b64d(s) { return type(global.b64dec) == 'function' ? global.b64dec(s) : b64raw(s); }
function decn(s) { let v = 0; for (let i = 0; i < length(s); i++) v = v * 10 + ord(s, i) - 48; return v; }
function certdates(f, dec) {
let p = readfile(f, 32768) ?? '', a = index(p, '-----BEGIN CERTIFICATE-----'), e = index(p, '-----END CERTIFICATE-----');
if (a < 0 || e < a) return null;
let d = (dec ?? b64raw)(substr(p, a + 27, e - a - 27)), T = [];
for (let i = 0; i + 15 <= length(d) && length(T) < 2; i++) {
let t = ord(d, i), n = ord(d, i + 1);
if (!((t == 23 && n == 13) || (t == 24 && n == 15))) continue;
let x = match(substr(d, i + 2, n), t == 23 ? /^([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})Z$/ : /^([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})Z$/);
if (!x) continue;
let y = decn(x[1]);
if (t == 23) y += y < 50 ? 2000 : 1900;
push(T, timegm({ year: y, mon: decn(x[2]), mday: decn(x[3]), hour: decn(x[4]), min: decn(x[5]), sec: decn(x[6]) }));
i += n + 1;
}
return length(T) == 2 ? { nb: T[0], na: T[1] } : null;
}

function fsname(t) {
t = lc(t ?? '');
if (t == 'vfat' || t == 'msdos' || t == 'fat' || t == 'fat32') return 'fat32';
if (t == 'ntfs3' || t == 'ntfs' || t == 'ntfs-3g' || t == 'fuseblk') return 'ntfs';
return t;
}
function vfs(p, DF, sv, sh, q) {
if (DF?.[p]) return DF[p];
if (sv) { let s = sv(p); if (s) return { size: s.blocks * s.frsize, free: s.bavail * s.frsize, used: (s.blocks - s.bfree) * s.frsize }; }
let l = split(trim(sh('df -kP ' + q(p) + ' 2>/dev/null')), '\n'), x = split(l[length(l) - 1] ?? '', /[ \t]+/);
if (length(x) < 4 || !match(x[1] ?? '', /^[0-9]+$/)) return { size: 0, free: 0, used: 0 };
return { size: +x[1] * 1024, used: +x[2] * 1024, free: +x[3] * 1024 };
}
function blkinfo(M, X) {
let B = X.sys + '/class/block';
let fp = join(',', map(lsdir(B) ?? [], (d) => d + ':' + (stat(B + '/' + d)?.inode ?? ''))) + '|' + join(',', map(filter(M, (m) => substr(m.dev, 0, 5) == '/dev/'), (m) => m.dev + ' ' + m.mnt));
let c = X.rj(X.run + '/blk.json');
if (type(c) == 'object' && c.fp == fp && type(c.r) == 'object') return c.r;
let r = {};
if (!X.bin || X.bin('block')) for (let l in split(X.sh('block info 2>/dev/null'), '\n')) {
let m = match(l, /^\/dev\/([^:]+): (.*)$/);
if (!m) continue;
let o = {};
for (let a in match(m[2], /([A-Z_]+)="([^"]*)"/g) ?? []) o[a[1]] = a[2];
r[m[1]] = o;
}
X.mkdirp(X.run);
X.wjr(X.run + '/blk.json', { fp: fp, r: r });
return r;
}

const SYSMNT = /^\/(|overlay|rom|boot|tmp|proc|sys|dev)$/;
function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
function nasdisks(R, N, blk) {
let M = {}, ML = [], D = [];
for (let l in split(readfile(R + '/proc/mounts') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) < 4) continue;
push(ML, { dev: p[0], mnt: unoct(p[1]) });
if (substr(p[0], 0, 5) == '/dev/' && !M[p[0]])
M[p[0]] = { mnt: unoct(p[1]), fs: p[2], ro: index(split(p[3], ','), 'ro') >= 0 };
}
let B = blk(ML);
for (let dv, a in B) {
let k = '/dev/' + dv;
if (type(a) != 'object' || !M[k] || match(M[k].mnt, SYSMNT)) continue;
if (match(a.TYPE ?? '', /^(squashfs|ubifs|jffs2|swap)$/)) continue;
let dev = replace(dv, /^.*\//, ''), id = lc(replace(a.UUID ?? '', /[^A-Za-z0-9-]/g, '')) || dev, fs = M[k].fs;
let st = N.disks?.[id]?.ro, lock = type(st) == 'bool' ? st : match(fs, /^(ntfs|ntfs3|ntfs-3g|fuseblk)$/) != null;
push(D, { id: id, dev: dev, name: N.disks?.[id]?.name ?? (length(a.LABEL) ? a.LABEL : dev), mnt: M[k].mnt, fs: fs, ro: M[k].ro || lock });
}
return D;
}
function mounted(m, ro) {
let f = m.mnt + '/.wf-disco';
if (lstat(f)) return true;
if (!match(ferr() ?? '', /No such file/)) return false;
if (ro) return lsdir(m.mnt) != null;
writefile(f, 'WrtFreedom\n');
return lstat(f) != null;
}

function badname(n) {
n = '' + n;
if (!length(n) || n == '.' || n == '..' || length(n) > 255) return true;
for (let i = 0; i < length(n); i++) { let c = ord(n, i); if (c < 32 || c == 127 || c == 47) return true; }
return false;
}
function relp(p, nobs) {
p = '' + (p ?? '');
if (length(p) > 4096 || (nobs && index(p, '\\') >= 0)) return null;
let P = [];
for (let x in split(p, '/')) { if (!length(x)) continue; if (badname(x) || substr(x, 0, 4) == '.wf-') return null; push(P, x); }
return P;
}
function bname(a) { return replace(a, /^.*\//, ''); }

function jobchk(J, id, j, alive, wr) {
let isbak = substr(id, 0, 4) == 'bak-', fm = isbak ? stat(J + '/' + id + '.json') : null;
let dead = isbak ? (fm && time() - fm.mtime > 600) : !alive(trim(readfile(J + '/' + id + '.pid') ?? ''));
if ((j.state == 'run' || j.state == 'ask') && time() - (j.t0 ?? 0) > 5 && dead) {
j.state = 'err'; j.error = 'Lavoro interrotto'; j.error_en = 'Job interrupted'; j.t1 = time();
wr(J + '/' + id + '.json', j);
}
return j;
}
function joblist(J, get, ext) {
let r = [];
ext = [ '.json', '.in', '.pid', '.ans', '.stop', '.mnt', ...(ext ?? []) ];
for (let f in lsdir(J) ?? []) {
let m = match(f, /^([0-9a-f]+|bak-[0-9A-Za-z-]+)\.json$/);
if (!m) continue;
let j = get(m[1]);
if (!j) continue;
if (j.state != 'run' && j.state != 'ask' && time() - (j.t1 ?? 0) > 86400) {
for (let e in ext) unlink(J + '/' + m[1] + e);
continue;
}
push(r, j);
}
return sort(r, (a, b) => (b.t0 ?? 0) - (a.t0 ?? 0));
}

function uiname(cd) {
let s = false, v = '';
for (let l in split(readfile(cd + 'wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { s = match(l, /^config [A-Za-z0-9_]+ '?([A-Za-z0-9_]+)'?[[:blank:]]*$/)?.[1] == 'ui'; continue; }
let m = s ? match(l, /^[[:blank:]]*option name (.*)$/) : null;
if (m) {
v = rtrim(m[1]);
if (substr(v, 0, 1) == "'" && substr(v, -1) == "'" && length(v) >= 2) v = replace(substr(v, 1, length(v) - 2), "'\\''", "'");
else if (substr(v, 0, 1) == '"' && substr(v, -1) == '"' && length(v) >= 2) v = substr(v, 1, length(v) - 2);
}
}
return trim(v);
}

const UDIR = { root: 'Utenti', shared: 'Cartella Condivisa', admin: 'Amministratore', wf: 'WrtFreedom', router: 'Router',
cams: 'Telecamere', priv: 'Cartella Personale', pub: 'Cartella Pubblica', media: 'Multimedia', docs: 'Documenti',
prog: 'Programmi', misc: 'Varie', dl: 'Download', backup: 'Backup e Sincronizzazione', phones: 'Dal Telefono',
tocat: 'Da Catalogare',
tm: 'Backup Del Mac', fh: 'Backup Del PC', recv: 'File Ricevuti', tg: 'Telegram', sync: 'Sincronizzazione', up: 'File Caricati',
lnk: 'Link Condivisi', inbox: 'Richieste File In Arrivo',
types: { video: 'Film', music: 'Musica', doc: 'Documenti', photo: 'Foto', app: 'Programmi', other: 'Varie' },
mtypes: { video: 'Film', music: 'Musica', photo: 'Foto' },
pmtypes: { photo: 'Foto e Video' } };
const UDOLD = { photo: 'Foto', phones: 'Foto Del Telefono' };
const UDFLAT = { pub: 1, backup: 1, tg: 1 };
const UDTYPED = { dl: 1, up: 1, recv: 1 };
const UTIPIF = getenv('WF_NASTIPIUC') ?? replace(sourcepath() ?? '', /[^\/]*$/, '') + 'nastipi.uc';
let UTIPI = null;
function utype(n) {
if (UTIPI == null) {
try { UTIPI = loadfile(UTIPIF)(); } catch (e) { UTIPI = null; }
if (type(UTIPI) != 'object') UTIPI = {};
}
let m = match(lc('' + (n ?? '')), /\.([a-z0-9]+)$/);
if (m) for (let k, l in { video: UTIPI.vid, music: UTIPI.mus, photo: UTIPI.img, doc: UTIPI.doc, app: UTIPI.app }) if (type(l) == 'array' && index(l, m[1]) >= 0) return k;
return 'other';
}
const UDBK = { tm: 1, fh: 1, sync: 1 };
const LKIND = [ 's', 't', 'u', 'r', 'p', 'c' ];
const NASETC = getenv('WF_NASETC') ?? '/etc/wrtfreedom';
let UNJ = null, UNJFP = null;
function unas(N) {
if (type(N) == 'object') return N;
let f = NASETC + '/nas.json', st = stat(f), fp = st ? st.mtime + ':' + st.size + ':' + st.inode : '';
if (fp != UNJFP || UNJ == null) {
UNJ = null;
try { UNJ = json(readfile(f) ?? '{}'); } catch (e) { UNJ = null; }
if (type(UNJ) != 'object') UNJ = {};
UNJFP = fp;
}
return UNJ;
}
function uname(n) {
return type(n) == 'string' && length(n) > 0 && length(n) <= 255 && substr(n, 0, 1) != '.' && !match(n, /[\/\n\r]/);
}
function usub(s) {
if (s == null || s == '') return '';
s = '' + s;
for (let x in split(s, '/')) if (!uname(x)) return null;
return s;
}
function uvis(own, N) {
if (type(own) != 'string' || !match(own, /^[A-Za-z0-9._-]+$/) || own == 'admin' || own == 'shared') return null;
N = unas(N);
let u = type(N.users) == 'object' ? N.users[own] : null, v = null;
if (type(u) == 'object') v = u.cam ? null : u.vis;
else for (let g in (type(N.gone) == 'array' ? N.gone : [])) if (type(g) == 'object' && g.user == own) { v = g.vis; break; }
return uname(v) && v != UDIR.admin && v != UDIR.shared ? v : null;
}
function udir(own, k, sub, N) {
k = k ?? 'root';
let s = usub(sub), W = UDIR.root + '/' + UDIR.admin + '/' + UDIR.wf;
if (s == null) return null;
let add = (p) => s == '' ? p : p + '/' + s;
if (k == 'router' || k == 'cams') return add(W + '/' + UDIR[k]);
if (own == 'shared') {
let b = UDIR.root + '/' + UDIR.shared;
if (k == 'root') return add(b);
if (k == 'media') return s == '' ? b : (UDIR.mtypes[sub] ? b + '/' + UDIR.mtypes[sub] : null);
if (k == 'mold') return add(b + '/' + UDIR.media);
if (k == 'docs' || k == 'prog' || k == 'misc') return add(b + '/' + UDIR[k]);
return null;
}
let v = own == 'admin' ? UDIR.admin : uvis(own, N);
if (v == null) return null;
let b = UDIR.root + '/' + v, P = b + '/' + UDIR.priv;
if (k == 'root') return add(b);
if (own == 'admin' && k == 'wf') return add(W);
if (k == 'priv') return add(P);
if (k == 'media') return s == '' ? P : (UDIR.mtypes[sub] ? P + '/' + (UDIR.pmtypes[sub] ?? UDIR.mtypes[sub]) : null);
if (k == 'mold') return add(P + '/' + UDIR.media);
if (k == 'phones') return add(P + '/' + UDIR.pmtypes.photo + '/' + UDIR.phones);
if (k == 'tocat') return add(P + '/' + UDIR.pmtypes.photo + '/' + UDIR.tocat);
if (k == 'pold') return add(P + '/' + UDOLD.photo);
if (k == 'phold') return add(P + '/' + UDIR.pmtypes.photo + '/' + UDOLD.phones);
if (k == 'docs' || k == 'prog') return add(P + '/' + UDIR[k]);
if (UDTYPED[k]) return s == '' ? b + '/' + UDIR[k] : b + '/' + UDIR[k] + '/' + (UDIR.types[sub] ?? UDIR.types.other);
if (UDFLAT[k]) return add(b + '/' + UDIR[k]);
if (k == 'lnk' || k == 'inbox') return add(b + '/' + UDIR[k]);
if (UDBK[k]) return add(b + '/' + UDIR.backup + '/' + UDIR[k]);
return null;
}
function shlnk(mnt, P, i, N) {
let nm = UDIR.shared;
if (i != 2 || type(P) != 'array' || length(P) < 3 || P[0] != UDIR.root || P[2] != nm || P[1] == nm || P[1] == UDIR.admin) return null;
let a = mnt + '/' + P[0] + '/' + P[1] + '/' + nm, l = lstat(a);
if (l?.type != 'link' || readlink(a) != '../' + nm) return null;
if (lstat(mnt + '/' + P[0])?.type != 'directory' || lstat(mnt + '/' + P[0] + '/' + P[1])?.type != 'directory' || lstat(mnt + '/' + P[0] + '/' + nm)?.type != 'directory') return null;
N = unas(N);
let G = map(filter(type(N.gone) == 'array' ? N.gone : [], (g) => type(g) == 'object' && g.user != null), (g) => '' + g.user), ok = false;
for (let u, x in (type(N.users) == 'object' ? N.users : {})) if (type(x) == 'object' && !x.cam) push(G, u);
for (let u in G) if (u != 'admin' && udir(u, 'root', null, N) == P[0] + '/' + P[1]) { ok = true; break; }
return ok ? [ P[0], nm, ...slice(P, 3) ] : null;
}
function absp(d, p) {
let P = relp(p, true);
if (P == null || !d) return null;
let a = d.mnt;
for (let i = 0; i < length(P); i++) {
a += '/' + P[i];
let s = lstat(a);
if (s && s.type == 'link') { let Q = shlnk(d.mnt, P, i); if (!Q) return null; P = Q; a = d.mnt + '/' + P[0] + '/' + P[1]; i = 1; }
}
return { abs: a, rel: '/' + join('/', P), parts: P, name: length(P) ? P[length(P) - 1] : d.name };
}
function uup(own, rel, n, N) {
let r = udir(own, 'root', null, N);
return r != null && trim('' + (rel ?? ''), '/') == r ? udir(own, 'up', utype(n), N) : null;
}
function ubase(N) {
N = unas(N);
let r = [ UDIR.root ], S = udir('shared', 'root');
push(r, S);
for (let t in [ 'video', 'music', 'photo' ]) push(r, udir('shared', 'media', t));
for (let k in [ 'docs', 'prog', 'misc' ]) push(r, udir('shared', k));
push(r, UDIR.root + '/' + UDIR.admin, udir('admin', 'wf'), udir('admin', 'router'), udir('admin', 'cams'));
push(r, udir('admin', 'up'));
for (let t in keys(UDIR.types)) push(r, udir('admin', 'up', t));
let U = type(N.users) == 'object' ? N.users : {};
for (let u in sort(keys(U))) {
if (udir(u, 'root', null, N) == null) continue;
for (let k in [ 'root', 'priv' ]) push(r, udir(u, k, null, N));
for (let t in [ 'video', 'music', 'photo' ]) push(r, udir(u, 'media', t, N));
for (let k in [ 'phones', 'tocat', 'docs', 'prog', 'pub' ]) push(r, udir(u, k, null, N));
for (let k in [ 'dl', 'up', 'recv' ]) {
push(r, udir(u, k, null, N));
for (let t in keys(UDIR.types)) push(r, udir(u, k, t, N));
}
for (let k in keys(UDFLAT)) if (k != 'pub') push(r, udir(u, k, null, N));
for (let k in keys(UDBK)) push(r, udir(u, k, null, N));
}
return r;
}
function isbase(p, N) {
p = trim('' + (p ?? ''), '/');
return p != '' && index(ubase(N), p) >= 0;
}
function upriv(W, p, N) {
if (W != null && type(W) == 'object' && !W.adm) return null;
let P = type(p) == 'array' ? map(p, (x) => '' + x) : split('' + (p ?? ''), '/');
P = map(filter(P, (x) => length(x) > 0), lc);
N = unas(N);
let U = type(N.users) == 'object' ? N.users : {}, r = null;
for (let u, x in U) {
if (type(x) != 'object' || x.cam) continue;
let b = udir(u, 'root', null, N);
if (b == null) continue;
let B = map(split(b, '/'), lc), n = length(P) < length(B) ? length(P) : length(B), eq = true;
for (let i = 0; i < n; i++) if (P[i] != B[i]) { eq = false; break; }
if (!eq) continue;
if (length(P) == length(B)) return 'lock';
if (length(P) > length(B)) return 'in';
r = 'up';
}
return r;
}
let UNX = null, UNXFP = null;
function unasx(X) {
if (type(X) == 'object') return X;
let f = NASETC + '/nasx.json', st = stat(f), fp = st ? st.mtime + ':' + st.size + ':' + st.inode : '';
if (fp != UNXFP || UNX == null) {
UNX = null;
try { UNX = json(readfile(f) ?? '{}'); } catch (e) { UNX = null; }
if (type(UNX) != 'object') UNX = {};
UNXFP = fp;
}
return UNX;
}
function cpriv(rel, N, X) {
let P = type(rel) == 'array' ? map(rel, (x) => '' + x) : split('' + (rel ?? ''), '/');
P = filter(P, (x) => length(x) > 0);
if (length(P) < 3 || lc(P[0]) != lc(UDIR.root)) return null;
N = unas(N);
let v1 = lc(P[1]), own = null, vis = null;
if (v1 == lc(UDIR.admin)) { own = 'admin'; vis = UDIR.admin; }
else if (v1 == lc(UDIR.shared)) { own = 'shared'; vis = UDIR.shared; }
else {
let U = type(N.users) == 'object' ? N.users : {};
for (let u in sort(keys(U))) { let v = uvis(u, N); if (v != null && lc(v) == v1) { own = u; vis = v; break; } }
if (own == null) for (let g in (type(N.gone) == 'array' ? N.gone : [])) {
let v = type(g) == 'object' && type(g.user) == 'string' && U[g.user] == null ? uvis(g.user, N) : null;
if (v != null && lc(v) == v1) { own = g.user; vis = v; break; }
}
if (own == null) return null;
}
let t = lc(P[2]);
if (own != 'shared' && (t == lc(UDIR.pub) || t == lc(UDIR.lnk) || t == lc(UDIR.inbox) || (own == 'admin' && t == lc(UDIR.wf)))) return null;
let L = map(P, lc);
for (let c in (type(unasx(X).cloud) == 'array' ? unasx(X).cloud : [])) {
if (type(c) != 'object' || c.kind != 'backup') continue;
for (let r in [ c.remote, c.prev_remote ]) {
let B = map(filter(split('' + (r ?? ''), '/'), (x) => length(x) > 0), lc), n = length(L) < length(B) ? length(L) : length(B), eq = length(B) > 0;
for (let i = 0; eq && i < n; i++) if (L[i] != B[i]) eq = false;
if (eq) return null;
}
}
return { own: own, vis: vis, top: P[2], rest: join('/', slice(P, 2)) };
}
function crsec(acct, own) {
if (type(acct) != 'string' || !match(acct, /^a[0-9]{1,3}$/) || type(own) != 'string' || !match(own, /^[A-Za-z0-9._-]{1,64}$/)) return null;
if (match(own, /^[a-z0-9]+$/)) return 'wf' + acct + 'c' + own;
let h = '';
for (let i = 0; i < length(own); i++) h += sprintf('%02x', ord(own, i));
return 'wf' + acct + 'x' + h;
}
const CKEYA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newkey() {
let f = open('/dev/urandom', 'r'), b = f ? f.read(24) : null, k = '';
if (f) f.close();
if (type(b) != 'string' || length(b) < 24) return null;
for (let i = 0; i < 24; i++) k += substr(CKEYA, ord(b, i) & 31, 1) + (i % 4 == 3 && i < 23 ? '-' : '');
return k;
}
function sacc(sid) {
if (type(global.WFSACC) == 'function') return !!global.WFSACC(sid);
if (trim(readfile('/proc/self/comm') ?? '') == 'rpcd') return false;
let a = sprintf('%J', { ubus_rpc_session: sid, scope: 'ubus', object: 'wrtfreedom', 'function': 'nas_users' }), r = null;
let p = popen("ubus call session access '" + a + "' 2>/dev/null", 'r');
if (!p) return false;
try { r = json(p.read('all') || '{}'); } catch (e) { r = null; }
p.close();
return r?.access === true;
}
function who(req, O) {
O = type(O) == 'object' ? O : {};
O.why = 'who';
let a = type(req?.args) == 'object' ? req.args : {}, sid = exists(a, 'ubus_rpc_session') ? a.ubus_rpc_session : req?.info?.session, N = unas(O.nj);
let U = type(N.users) == 'object' ? N.users : {};
let pers = (u, sys) => {
let x = U[u];
if (type(x) != 'object' || x.cam) return null;
if (x.blocked) { O.why = 'blocked'; return null; }
let v = uvis(u, N);
return v == null ? null : { own: u, adm: false, sys: sys, vis: v, u: u };
};
if (!exists(a, 'ubus_rpc_session') && req?.info?.session == null) {
if (a.as == null || a.as == '') return { own: 'admin', adm: true, sys: true, vis: UDIR.admin, u: null };
return type(a.as) == 'string' && a.as != 'admin' && a.as != 'shared' ? pers(a.as, true) : null;
}
if (type(sid) != 'string' || !match(sid, /^[0-9A-Za-z]+$/) || (a.as != null && a.as != '')) return null;
let R = null;
try { R = json(readfile(O.reg ?? '/tmp/wf-nas/sess.json') ?? '{}'); } catch (e) { R = null; }
let e = type(R) == 'object' ? R[sid] : null;
if (type(e) == 'object' && type(e.u) == 'string' && e.u != '') return pers(e.u, false);
let ok = false;
try { ok = type(O.acc) == 'function' ? !!O.acc(sid) : sacc(sid); } catch (x) { ok = false; }
return ok ? { own: 'admin', adm: true, sys: false, vis: UDIR.admin, u: null } : null;
}

const ZVPNOUT = /^wgo(ut|[0-9]+)$/;
function zarr(v) { return type(v) == 'array' ? v : (v == null || v == '' ? [] : split('' + v, ' ')); }
function zsh(c) { let p = popen(c + ' 2>/dev/null', 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function umkdir(mnt, rel) {
let a = '' + mnt;
for (let x in split(trim('' + (rel ?? ''), '/'), '/')) {
if (!uname(x)) return null;
let p = a + '/' + x, s = lstat(p);
if (s && s.type == 'link') return null;
if (!s) {
let ps = stat(a), e = "'" + replace(p, "'", "'\\''") + "'";
mkdir(p);
if (ps && lstat(p)?.type == 'directory') {
zsh('chown ' + ps.uid + ':' + ps.gid + ' ' + e);
zsh('chmod ' + sprintf('%o', ps.mode & 4095) + ' ' + e);
}
s = lstat(p);
}
if (s?.type != 'directory') return null;
a = p;
}
return a;
}
function privip(ip) { return match('' + (ip ?? ''), /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|169\.254\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.|f[cd]|fe80:)/) != null; }
function ipzone(ip, O) {
ip = lc(replace('' + (ip ?? ''), /^::ffff:/i, ''));
if (!match(ip, /^[0-9a-f.:]{2,45}$/)) return 'net';
let CD = O?.cfgdir ?? getenv('WF_CFGDIR') ?? '/etc/config/', F = read(CD + 'firewall');
if (!length(filter(values(F), (s) => s['.type'] == 'zone')))
return privip(ip) ? 'lan' : 'net';
let m = match(zsh("ip route get '" + ip + "'"), /(^|[ \t])dev[ \t]+([^ \t\n]+)/), d = m ? m[2] : '';
if (!length(d) || d == 'lo') return 'net';
let N = read(CD + 'network'), ifs = [];
let D = null;
try { D = json(zsh('ubus call network.interface dump') || '{}'); } catch (e) { D = null; }
for (let i in (type(D?.interface) == 'array' ? D.interface : []))
if (type(i?.interface) == 'string' && (i.l3_device == d || i.device == d) && index(ifs, i.interface) < 0) push(ifs, i.interface);
if (!length(ifs)) for (let k, s in N) {
if (s['.type'] != 'interface') continue;
if (index(zarr(s.device), d) >= 0 || index(zarr(s.ifname), d) >= 0 || k == d || (s.type == 'bridge' && 'br-' + k == d)) push(ifs, k);
}
let srv = (n) => (N[n]?.proto == 'wireguard' && !match(n, ZVPNOUT) && length('' + (N[n]?.listen_port ?? '')) > 0) || N[n]?.proto == 'openvpn';
let Z = [], home = null, alt = null;
for (let k, s in F) {
if (s['.type'] != 'zone') continue;
let nets = zarr(s.network), e = { nets: nets, devs: zarr(s.device), masq: s.masq == '1' || s.masq == 'true' || s.masq == 'yes' || s.masq == 'on', srv: length(filter(nets, srv)) > 0 };
push(Z, e);
if (!home && index(nets, 'lan') >= 0) home = e;
if (!alt && !e.masq && uc(s.input ?? '') == 'ACCEPT') alt = e;
}
home = home ?? alt;
let zof = (e) => e == home ? 'lan' : e.masq ? 'net' : e.srv ? 'vpn' : 'guest';
for (let n in ifs) {
if (N[n]?.proto == 'wireguard') return srv(n) ? 'vpn' : 'net';
for (let e in Z) if (index(e.nets, n) >= 0) return zof(e);
}
for (let e in Z) if (index(e.devs, d) >= 0) return zof(e);
return match(d, /^tailscale[0-9]*$/) ? 'vpn' : 'net';
}

const SMBD = '/usr/sbin/smbd', PASSDB = [ '/etc/samba/passdb.tdb', '/var/lib/samba/private/passdb.tdb' ];
function smbmem(R) {
let m = match(readfile('/proc/meminfo') ?? '', /MemTotal:[ \t]*([0-9]+)/), ram = m ? int(+m[1] / 1024) : 0, fl = -1, f = null;
try { f = require('fs').statvfs; } catch (e) {}
if (f) { let s = null; try { s = f('/overlay') ?? f('/'); } catch (e) {} if (s) fl = int((s.bavail ?? s.f_bavail ?? 0) * (s.frsize ?? s.f_frsize ?? s.bsize ?? 4096) / 1048576); }
return ram >= 200 && (stat(R + SMBD) != null || fl < 0 || fl >= 25);
}
const SMBPWF = '/etc/samba/smbpasswd', SMBTPL = '/etc/samba/smb.conf.template';
function smbdb(R) {
let b = 'tdbsam', p = null, f = null;
for (let l in split(readfile(R + SMBTPL) ?? '', '\n')) {
let m = match(l, /^[ \t]*passdb[ \t]+backend[ \t]*=[ \t]*([a-z]+)(:[^ \t]+)?[ \t]*$/);
if (m) { b = m[1]; p = m[2] ? substr(m[2], 1) : null; continue; }
m = match(l, /^[ \t]*smb[ \t]+passwd[ \t]+file[ \t]*=[ \t]*([^ \t]+)[ \t]*$/);
if (m) f = m[1];
}
return b == 'smbpasswd' ? { b, f: [ p ?? f ?? SMBPWF ] } : { b: 'tdbsam', f: p ? [ p ] : PASSDB };
}
function smbusers(R) {
let r = null, D = smbdb(R);
if (D.b == 'tdbsam') for (let f in D.f) {
let t = readfile(R + f);
if (t == null) continue;
r = r ?? {};
for (let s in split(t, chr(0))) if (index(s, 'USER_') >= 0) for (let m in (match(s, /USER_[a-z0-9._-]+/g) ?? [])) r[substr(m[0], 5)] = true;
}
let t = D.b == 'smbpasswd' ? readfile(R + D.f[0]) : null;
if (t != null) {
r = r ?? {};
for (let l in split(t, '\n')) {
let p = split(l, ':');
if (length(p) >= 4 && length(p[0]) && substr(p[0], 0, 1) != '#' && match(p[1], /^[0-9]+$/)) r[lc(p[0])] = true;
}
}
return r;
}
function smbadm(N) { return UDIR.admin; }
function smbready(N, X) {
let R = X?.R ?? '';
if (N?.on !== true || stat(R + SMBD) == null || type(N.users) != 'object') return false;
let P = smbusers(R);
if (P == null) return false;
let ok = (u) => P[lc('' + u)] === true, k = readfile(R + '/etc/ksmbd/ksmbdpwd.db') ?? '', a = X?.admu ?? smbadm(N);
if (index(map(split(k, '\n'), (l) => lc(split(l, ':')[0])), lc(a)) >= 0 && !ok(a)) return false;
let n = 0, S = type(N.shares) == 'array' ? N.shares : [];
for (let u, x in N.users) {
if (type(x) != 'object' || x.blocked === true) continue;
if (x.cam && !length(filter(S, (s) => s?.cam && s.cam == x.cam))) continue;
if (!x.cam && !length(x.ph ?? '')) continue;
if (!ok(u)) return false;
if (!x.cam) n++;
}
return n > 0;
}
function smbcl(R) {
let C = null;
try { C = json(readfile(R + '/etc/wrtfreedom/cloud.json') ?? 'null'); } catch (e) { C = null; }
for (let k in keys(type(C?.share) == 'object' ? C.share : {})) if (C.share[k]?.on === true) return true;
return false;
}
function smbengine(N, X) {
let R = X?.R ?? '', s4 = stat(R + SMBD) != null;
let s1 = N?.rec?.adv?.smb1 === true && length(filter(type(N?.shares) == 'array' ? N.shares : [], (s) => s?.cam)) > 0;
let want = N?.adv?.trash === true || (N?.tm?.on === true && s4) || (s4 && (X?.ro === true || smbcl(R))) || s1 || smbready(N, X);
return want && smbmem(R) ? 'samba4' : 'ksmbd';
}
function smbneed(N, X) {
let R = X?.R ?? '';
return stat(R + SMBD) == null && (X?.ro === true || smbcl(R));
}

return { uval: uval0, uvalq, uopen, parse, read, lockdir, smbengine, smbneed, smbready, smbmem, smbusers, smbadm, NJLK, NJPID, pidlock, pidunlock, njlock, njunlock, njset, amerge, omerge, njget, njput, modof,
VPNCITY, VPNCC, vpnplace, hk, b64d, b64raw, certdates, fsname, vfs, blkinfo, nasdisks, mounted, badname, relp, shlnk, absp, bname, jobchk, joblist, uiname,
UDIR, LKIND, udir, utype, uup, umkdir, ubase, isbase, upriv, cpriv, crsec, newkey, who, privip, ipzone };
