#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom; ST=/tmp/wf-line.json; KICK=/tmp/wf-line.fifo
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
[ -f $W/lib.sh ] && . $W/lib.sh
nm() { if command -v wf_ifname >/dev/null 2>&1; then wf_ifname "$1"; else t "Linea" "Line"; fi; }
lnm() { if [ -n "$LI" ]; then nm "$LI"; else t "linea" "line"; fi; }
ev() { WF_Q=$3 WF_NORULES=$4 sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1 & }
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
updev() { set -- $(ubus call "network.interface.$1" status 2>/dev/null | jsonfilter -e '@.up' -e '@.l3_device' 2>/dev/null); UD=; [ "$1" = true ] && UD=$2; }
gw() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.route[@.target="0.0.0.0"].nexthop' 2>/dev/null | head -n 1; }
up() { read now _ </proc/uptime; now=${now%.*}; }
dur() { s=$1; if [ $s -ge 3600 ]; then echo "$((s / 3600)) h $((s % 3600 / 60)) min"; elif [ $s -ge 60 ]; then echo "$((s / 60)) min"; else echo "$s s"; fi; }
probe() {
L=$HOSTS; [ -n "$2" ] || L=${HOSTS%% *}
case "$L" in *' '*) ;; *) ping -c 1 -W 1 -I "$1" "$L" >/dev/null 2>&1 & wait $!; return ;; esac
T=/tmp/wf-line.p.$$; [ -e $T ] && rm -f $T
P=; for h in $L; do ( ping -c 1 -W 1 -I "$1" "$h" >/dev/null 2>&1 && : > $T ) & P="$P $!"; done; wait $P
[ -f $T ] && rm -f $T
}
CM=/tmp/wf-line.cm; CT=/tmp/wf-line.ct
cfg() {
[ "$1" = force ] || [ ! -f /etc/config/wrtfreedom ] || [ -e /tmp/.uci/wrtfreedom ] || [ ! -f $CM ] || [ /etc/config/wrtfreedom -nt $CM ] || [ /etc/config/wrtfreedom -ot $CM ] || [ ! $CT -nt /etc/config/wrtfreedom ] || return 0
: > $CT; touch -r /etc/config/wrtfreedom $CM 2>/dev/null
FO=$(uci -q get wrtfreedom.fo.enabled); M=$(uci -q get wrtfreedom.fo.main); B=$(uci -q get wrtfreedom.fo.backup)
HOSTS=$(uci -q get wrtfreedom.fo.hosts); HOSTS=${HOSTS:-1.1.1.1 8.8.8.8 9.9.9.9}
{ [ "$FO" = 1 ] && [ -n "$M" ] && [ -n "$B" ] && [ "$M" != "$B" ]; } || FO=0
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
SA=$(uci -q get wrtfreedom.sim.auto)
SF=$(uci -q get wrtfreedom.sqm.fo)	# Segue Il Multi-WAN (SQM, 2.70)
SP=$(uci -q get wrtfreedom.sqm.fprev)	# regolazioni salvate da rimettere (2.95: il giro chiama sqmfo main solo con queste)
SD=$(uci -q get wrtfreedom.ev.sms_down); SN=$(uci -q get wrtfreedom.ev.sms_to)	# SMS Se Manca Internet (4/11)
case "$SN" in ''|*[!+0-9]*) SD=0 ;; esac
}
rtdev() {
D=; while read -r i_ d_ _ _ _ _ _ k_ _; do
[ "$d_" = 00000000 ] && [ "$k_" = 00000000 ] || continue
[ "$i_" = '*' ] || D=$i_; break
done 2>/dev/null < /proc/net/route
}
smsdown() {
ss=1; l_=0; [ -f /tmp/wf-line.sms ] && read -r l_ < /tmp/wf-line.sms
case "$l_" in ''|*[!0-9]*) l_=0 ;; esac
[ $((now + BT - l_)) -ge 3600 ] || return 0
echo $((now + BT)) > /tmp/wf-line.sms
h_=$(uci -q get wrtfreedom.ui.name); [ -n "$h_" ] || h_=$(uci -q get 'system.@system[0].hostname'); [ -n "$h_" ] || read -r h_ < /proc/sys/kernel/hostname
printf '🌐 Internet\n%s\n%s\n' "$(t "Assente da 2 minuti" "Down for 2 minutes")" "${h_:-OpenWrt}" > /tmp/wf-line.sms.txt
( o_=$(ucode $W/sms.uc send "$SN" /tmp/wf-line.sms.txt 2>&1 | tail -n 1); logger -t wrtfreedom "SMS Internet assente: $o_" ) >/dev/null 2>&1 &
}
on() { updev "$B"; d=$UD; [ -n "$d" ] || return 1; probe "$d" all || return 1; g=$(gw "$B"); [ "$g" = 0.0.0.0 ] && g=
ip route replace default ${g:+via $g} dev "$d" metric 1 protocol 99 2>/dev/null || return 1
ctold "$M"; return 0; }
ctold() { command -v conntrack >/dev/null || return 0
o_=$(ifstatus "$1" 2>/dev/null | jsonfilter -e '@["ipv4-address"][*].address' 2>/dev/null)
if [ -n "$o_" ]; then for a_ in $o_; do conntrack -D -q "$a_" >/dev/null 2>&1; done; else conntrack -F >/dev/null 2>&1; fi; return 0; }
rtdel() { ip route del default metric 1 protocol 99 2>/dev/null; }	# solo la nostra, mai una rotta dell'utente
sqmfo() {
if [ "$1" = main ]; then [ -n "$(uci -q get wrtfreedom.sqm.fprev)" ] || return 0; else [ "$SF" = 1 ] || return 0; fi
( ubus -t 20 call wrtfreedom sqm "{\"action\":\"follow\",\"go\":\"$1\"}" >/dev/null 2>&1 & )
}
lif() {
if [ $FO = 1 ]; then LI=$M; return; fi
[ -n "$D" ] && [ "$D" != "$LD" ] || return; LD=$D
c=$(ubus call network.interface dump 2>/dev/null | jsonfilter -e "@.interface[@.l3_device=\"$D\"].interface" 2>/dev/null | head -n 1)
[ -n "$c" ] && { c=${c%_4}; LI=${c%_6}; }
}
wanted() {
for f in ${LI:+/tmp/wf-want/$LI} /tmp/wf-want/_all; do
w=; [ -f "$f" ] && read w _ < "$f" 2>/dev/null; case "$w" in ''|*[!0-9]*) continue;; esac
w=$((now + BT - w)); [ $w -ge -5 ] && [ $w -lt 60 ] && return 0
done; return 1
}
offap() {
[ -n "$LI" ] || return 1
case "$(uci -q get network.$LI.disabled)" in 1|on|true|yes|enabled) return 0;; esac
[ -f /tmp/wf-ifdown.$LI ] || [ "$(ifstatus "$LI" 2>/dev/null | jsonfilter -e @.autostart 2>/dev/null)" = false ]
}
lip() { for c in $LI ${LI:+${LI}_4}; do a=$(ifstatus "$c" 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null); [ -n "$a" ] && { echo "$a"; return; }; done; }
wdlast() {
WL=/tmp/wf-wd.last; [ -f $WL ] || return; w=; x=; read w x < $WL 2>/dev/null; rm -f $WL
case "$w" in ''|*[!0-9]*) return;; esac; w=$((now + BT - w))
[ $w -ge -5 ] && [ $w -lt 600 ] && [ -n "$x" ] && printf '%s' "$x"
}
rcfix() {
[ -f /tmp/wf-wd.recon ] || return
a=$(date -r /tmp/wf-wd.recon +%s 2>/dev/null); case "$a" in ''|*[!0-9]*) return;; esac
[ $((now + BT - a)) -ge 60 ] || return
ri=; read ri _ < /tmp/wf-wd.recon 2>/dev/null; rm -f /tmp/wf-wd.recon
case "$ri" in ''|*[!A-Za-z0-9_.-]*) ;; *) mkdir -p /tmp/wf-want && date +%s > /tmp/wf-want/$ri; ifup "$ri" >/dev/null 2>&1;; esac
}
off() { rtdel; ctold "$B"; }
fobt() { echo "🌐 $(nm "$B") ¦ $(t "In uso la riserva" "Backup in use") ¦ $(nm "$M") $(t "senza internet" "without internet")"; }
nup() { a=$(lip); x_=$(wdlast); ev net_up "🌐 Internet ¦ $(t "Tornato dopo" "Back after") $(dur $1) ¦ $(lnm)${a:+ · $a}${x_:+ ¦ ✅ $x_}"; }
fomain() { ev fo_main "🌐 $(nm "$M") ¦ $(t "Linea principale tornata" "Main line back") ¦ $(t "Riserva usata per" "Backup used for") $(dur $((now - since)))" "${fq#0}"; fq=0; pb=0; since=$now; }
state() {
js="{\"ok\":$ok,\"active\":\"$act\",\"since\":$((since + BT)),\"fails\":$n,\"main\":\"$M\",\"dev\":\"$D\",\"li\":\"$LI\",\"said\":$said,\"ever\":$ever,\"fq\":$fq,\"down\":$((down + BT)),\"flap\":$fl,\"fdown\":$((fd + BT)),\"lup\":$((lu + BT))"
[ "$js" = "$pjs" ] && [ $kick = 0 ] && [ $((now - pt)) -lt 8 ] && return
pjs=$js; pt=$now
printf '%s,"t":%s}\n' "$js" $((now + BT)) > $ST.t && mv $ST.t $ST
}
trap 'rtdel; [ -f $ST ] && mv -f $ST $ST.prev; exit 0' INT TERM
up; BT=$(($(date +%s) - now)); cfg force; rtdel; rcfix
sqmfo main
act=main; ok=true; ever=0; n=0; nd=0; good=0; since=$now; down=0; said=0; LI=; LD=; lastp=-99; tick=0; D=; FD=-; LV=1500; prx=0; ptx=0; pjs=; pt=0; pr=0
fq=0; pb=0; bs=$now; t0=$now; OA=0; ss=0; PO=
FL=300; fl=0; fd=-1; lu=$((now - 99999))
[ $now -ge 300 ] && ever=1
PS=$ST.prev; [ -f $PS ] || PS=$ST
if [ -f $PS ]; then
pv() { v=$(jsonfilter -i $PS -e "@.$1" 2>/dev/null); case "$v" in ''|*[!0-9]*) v=;; esac; }
pv ever; [ "$v" = 1 ] && ever=1
pv said; [ "$v" = 1 ] && { pv down; [ -n "$v" ] && { said=1; ok=false; down=$((v - BT)); since=$down; }; }
pv lup; [ -n "$v" ] && lu=$((v - BT))
pv flap; [ "$v" = 1 ] && { pv fdown; [ -n "$v" ] && { fl=1; fd=$((v - BT)); }; }
if [ $FO = 1 ] && [ "$(jsonfilter -i $PS -e '@.active' 2>/dev/null)" = backup ]; then
pv since; [ -n "$v" ] && { pb=1; bs=$((v - BT)); since=$bs; pv fq; [ "$v" = 1 ] && fq=1; }
fi
rm -f $ST.prev
fi
mkdir -p /tmp/wf-batt
pcl() { c_=; [ -r /proc/$1/cmdline ] && read -r c_ < /proc/$1/cmdline; }
nstop() {
np_=; tk_=; [ -f /tmp/wf-notify.pid ] && read -r np_ tk_ _ < /tmp/wf-notify.pid
case "$np_" in ''|*[!0-9]*) np_=$(ubus call service list '{"name":"wrtfreedom"}' 2>/dev/null | jsonfilter -e '@.wrtfreedom.instances.instance1.pid' 2>/dev/null); tk_= ;; esac
case "$np_" in ''|*[!0-9]*) return ;; esac
pcl "$np_"; case "$c_" in *"$W/notify.sh"*) ;; *) return ;; esac
case "$tk_" in ''|*[!0-9]*) tk_= ;; *) pcl "$tk_"; pp_=; [ -r /proc/$tk_/stat ] && read -r _ _ _ pp_ _ < /proc/$tk_/stat
case "$c_" in *tick.uc*) [ "$pp_" = "$np_" ] || tk_= ;; *) tk_= ;; esac ;; esac
kill -9 "$np_" 2>/dev/null; [ -n "$tk_" ] && kill -9 "$tk_" 2>/dev/null
}
NMAX=180 NV='' NC=0 NK=''
[ -p $KICK ] || { rm -f $KICK; mkfifo $KICK 2>/dev/null; }
FF=0; K=0; [ -p $KICK ] && exec 3<>$KICK && FF=1
kq() { read -t "$1" _k <&3 || return 0; K=1; while read -t 0.01 _k <&3; do :; done; }
nap() { if [ $FF = 1 ]; then kq 1; else sleep 1 & wait $!; fi; }
while true; do
up; tick=$((tick + 1))
{ [ $((tick % 60)) = 5 ] || { [ -z "$NT" ] && [ -f /tmp/.wf-ntp ]; }; } && { [ -f /tmp/.wf-ntp ] && NT=1; BT=$(($(date +%s) - now)); }
echo $((now + BT)) > /tmp/wf-batt/line
if [ $((tick % 10)) = 7 ]; then
v_=; [ -f /tmp/wf-batt/notify ] && read -r v_ < /tmp/wf-batt/notify
if [ -z "$v_" ] || [ "$v_" != "$NV" ]; then NV=$v_; NC=$now; NK=
elif [ -z "$NK" ] && [ $((now - NC)) -gt $NMAX ]; then NK=1
nstop
logger -t wrtfreedom "line.sh: notify.sh fermo da $((now - NC)) s (battito $NV), fermato: procd lo fa ripartire"
fi
fi
if [ $((tick % 30)) = 0 ]; then cfg; { [ "$act" = main ] || [ "$SF" != 1 ] || [ $FO = 0 ]; } && [ -n "$SP" ] && sqmfo main; rcfix; fi
kick=$K; K=0
rd=0; { [ $kick = 1 ] || [ -z "$D" ]; } && rd=1
if [ $FO = 1 ]; then
os_=; [ -n "$D" ] && { read -r os_ < /sys/class/net/$D/operstate; } 2>/dev/null
if [ "$os_" != "$PO" ]; then rd=1
elif [ $FF = 1 ] && { [ "$os_" = up ] || [ "$os_" = unknown ]; }; then [ $((tick % 15)) = 1 ] && rd=1
else [ $((tick % 5)) = 1 ] && rd=1; fi
PO=$os_
else [ $((tick % 5)) = 1 ] && rd=1; fi
if [ $rd = 1 ]; then
if [ $FO = 1 ]; then updev "$M"; D=$UD
else rtdev; fi
lif
[ "$D" = "$FD" ] || { LV=1500; f_=; [ -n "$D" ] && { read -r f_ < /sys/class/net/$D/flags; } 2>/dev/null
case "$f_" in 0x[0-9a-fA-F]*) FD=$D; [ $(($f_ & 128)) = 0 ] || LV=0 ;; *) FD=; [ -n "$D" ] || FD=$D ;; esac; }
fi
{ [ $((tick % 5)) = 1 ] || [ $kick = 1 ]; } && { OA=0; [ "$ok" = false ] && offap && OA=1; }
rx=0; tx=0; [ -n "$D" ] && { { read rx </sys/class/net/$D/statistics/rx_bytes; read tx </sys/class/net/$D/statistics/tx_bytes; } 2>/dev/null; rx=${rx:-0}; tx=${tx:-0}; }
live=0; [ $((rx - prx)) -gt $LV ] && live=1	# dati veri in arrivo (non solo ARP e simili; soglia LV, vedi sopra)
if [ -z "$D" ] || [ ! -e "/sys/class/net/$D" ]; then
r=1; n=3	# linea spenta o sparita: assente subito
elif [ "$act" = backup ]; then
r=2; [ $((tick % 2)) = 1 ] && [ $kick = 0 ] || { lastp=$now; pr=1; if probe "$D" all; then r=0; else r=1; fi; }	# principale ogni 2 s
elif [ $n = 0 ] && [ $kick = 0 ] && [ $((now - lastp)) -lt 30 ] && { [ $live = 1 ] || [ "$tx" = "$ptx" ]; }; then
r=0	# dati in arrivo, oppure linea ferma: basta il ping dei 30 s
else
lastp=$now; pr=1; all=; { [ $n -gt 0 ] || [ $kick = 1 ] || [ "$ok" = false ]; } && all=1
if probe "$D" $all; then r=0; elif [ $live = 1 ]; then r=0; else r=1; fi
fi
[ $pr = 1 ] && [ -n "$D" ] && { { read rx </sys/class/net/$D/statistics/rx_bytes; read tx </sys/class/net/$D/statistics/tx_bytes; } 2>/dev/null; rx=${rx:-0}; tx=${tx:-0}; }
pr=0; prx=$rx; ptx=$tx
if [ $r = 0 ]; then
n=0; good=$((good + 1)); ever=1
if [ "$act" = backup ] && [ $good -ge 15 ]; then	# 15 risposte ogni 2 s = 30 s di fila
off; act=main; ok=true; sqmfo main; fomain
elif [ $pb = 1 ]; then	# riserva in uso prima che line.sh ripartisse, principale già buona: il ritorno
ok=true; fomain
elif [ "$act" = main ] && [ "$ok" = false ]; then
ok=true; [ $said = 1 ] && [ $fl = 0 ] && { lu=$now; fd=$down; nup $((now - down)); }; said=0; since=$now
elif [ $fl = 1 ] && [ "$act" = main ] && [ $((now - since)) -ge $FL ]; then
d_=$((since - fd)); { [ $d_ -lt 0 ] || [ $d_ -gt $now ]; } && d_=$((since - down))
fl=0; fd=-1; lu=$now; nup $d_
fi
elif [ $r = 1 ]; then
n=$((n + 1)); good=0
[ $fl = 1 ] && { [ $OA = 1 ] || wanted; } && fl=0
if [ "$act" = main ] && [ $n -ge 3 ]; then
[ "$ok" = true ] && { ok=false; down=$now; since=$now; [ -e /tmp/wf-sighist.24h ] && { echo $((now + BT)) >> /tmp/wf-line.drops; nd=$((nd + 1)); [ $nd -ge 200 ] && { nd=0; tail -n 100 /tmp/wf-line.drops > /tmp/wf-line.drops.t; mv /tmp/wf-line.drops.t /tmp/wf-line.drops; }; }; }
if [ $FO = 1 ] && on; then act=backup; said=0; sqmfo backup
if [ $pb = 1 ]; then pb=0; since=$bs; q=1
else since=$now; q=; { { [ $ever = 0 ] && [ $((now - t0)) -lt 180 ]; } || wanted || { offap && OA=1; }; } && q=1; fq=${q:-0}; fi
ev fo_backup "$(fobt)" "$q"
elif [ $said = 0 ] && { [ $ever = 1 ] || [ $((now - t0)) -ge 180 ]; } && [ $((now - down)) -ge 10 ] && ! wanted && [ $OA = 0 ]; then said=1; pb=0
sh $W/bb.sh net >/dev/null 2>&1 &	# scatola nera (2.69): fotografia del guasto
if [ $FO = 1 ]; then ev fo_none "⚠️ Internet ¦ $(t "Assente sulla principale" "Down on the main line") ¦ $(nm "$B") $(t "non disponibile" "not available")"
elif [ $fl = 1 ]; then :
elif [ $((down - lu)) -lt $FL ]; then fl=1; [ $fd -ge 0 ] || fd=$down; ev net_down "🌐 Internet ¦ $(t "Instabile" "Unstable") ¦ $(lnm) $(t "cade e torna" "keeps dropping")"
elif [ -n "$D" ] && [ -e "/sys/class/net/$D" ]; then ev net_down "🌐 Internet ¦ $(t "Assente" "Down") ¦ $(lnm) $(t "non risponde" "not answering")"
else ev net_down "🌐 Internet ¦ $(t "Assente" "Down") ¦ $(lnm) $(t "caduta" "down")"; fi
fi
fi
[ "$act" = backup ] && [ $fq = 1 ] && { [ $ever = 1 ] || [ $((now - t0)) -ge 180 ]; } && ! wanted && [ $OA = 0 ] && { fq=0; ev fo_backup "$(fobt)" "" 1; }
[ "$act" = backup ] && ! isup "$B" && { off; act=main; since=$now; sqmfo main; }
fi
state
if [ "$SD" = 1 ]; then if [ "$ok" = true ]; then ss=0; elif [ $said = 1 ] && [ $ss = 0 ] && [ $((now - down)) -ge 120 ]; then smsdown; fi; fi
if [ "$SA" = 1 ] && [ $((tick % 60)) = 30 ]; then ucode $W/sim.uc auto >/dev/null 2>&1 & fi
[ $r = 1 ] && [ "$act" = main ] && [ "$ok" = true ] && { [ $FF = 1 ] && kq 0.01; continue; }
jobs >/dev/null 2>&1
nap
done
