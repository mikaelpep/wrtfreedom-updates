'use strict';
import { stat } from 'fs';

function cr(k, a) { return regexp(a + '/usr/share/wrtfreedom/cron[.]sh[\'"]?[ \t]+' + k + 'check([ \t;&|>)\'"]|$)'); }
return {
T: {
vpn: (t) => match(t, /(^|[^A-Za-z0-9_.-])ifup([ \t\n;&|)'"]|$)/) != null && match(t, /(^|[^A-Za-z0-9_.-])wg[ \t]+show([ \t\n;&|>)'"]|$)/) != null,
ddns: (t) => match(t, /\/(nic\/)?update[?\/]|(^|[^A-Za-z0-9_.-])nsupdate([ \t\n;&|)'"]|$)|\/usr\/lib\/ddns\//) != null &&
match(t, /(^|[^A-Za-z0-9_.-])(nslookup|dig)([ \t\n;&|)'"]|$)/) != null
},
file: (f) => {
let s = substr(f, 0, 1) == '/' && index(f, '/usr/share/wrtfreedom/') != 0 ? stat(f) : null;
return s && s.type == 'file' && s.size <= 65536 ? s : null;
},
paths: (t) => map(match(t, /\/[A-Za-z0-9_.+-]+(\/[A-Za-z0-9_.+-]+)+/g) ?? [], (m) => m[0]),
SYS: /^\/(lib|usr\/lib|usr\/share|etc\/init\.d|etc\/config|etc\/hotplug\.d|proc|sys|dev)\//,
re: { vpn: cr('vpn', ''), ddns: cr('ddns', '') },
re0: { vpn: cr('vpn', '^'), ddns: cr('ddns', '^') },
hpd: getenv('WF_HPDIR') ?? '/etc/hotplug.d',
hp: { ddns: 'iface' },
hpn: (n) => match(n, /^[A-Za-z0-9_-][A-Za-z0-9._-]{0,63}$/) != null && n != '90-wrtfreedom' && n != '91-wrtfreedom'
};
