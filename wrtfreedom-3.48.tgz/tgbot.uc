#!/usr/bin/ucode
'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, mkdir, rmdir, rename, lsdir } from 'fs';
const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());

const W = '/usr/share/wrtfreedom', P = W + '/tgpresets.sh';
const OFF = '/tmp/wf-tg.offset', PEND = '/tmp/wf-tg.pend', MENU = '/tmp/wf-tg.menu', SEEN = '/tmp/wf-tg.seen.json';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function cut(s, n) {
s = '' + s;
if (length(s) <= n) return s;
while (n > 0 && (ord(s, n) & 192) == 128) n--;
return substr(s, 0, n);
}
function ulen(s) {
let n = 0;
for (let i = 0; i < length(s); i++) { let b = ord(s, i); if ((b & 192) != 128) n += b >= 240 ? 2 : 1; }
return n;
}
function fold(s, n) {
let R = [], r = '';
for (let w in split(trim('' + s), ' ')) {
if (!length(w)) continue;
if (length(r) && ulen(r) + 1 + ulen(w) > n) { push(R, r); r = w; }
else r += (length(r) ? ' ' : '') + w;
}
if (length(r)) push(R, r);
return R;
}
function pieces(s, n, max) {
let P = [];
s = '' + s;
while (length(s) && length(P) < max) {
let c = cut(s, n);
if (!length(c)) break;
push(P, c);
s = substr(s, length(c));
}
return P;
}
function rid() { return substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time()), /[^0-9a-f]/g, ''), 0, 10); }
function ug(k) { return trim(sh('uci -q get ' + k)); }
function ugs(K) {
let c = '';
for (let k in K) c += 'uci -q get wrtfreedom.' + k + '; echo @@WF@@; ';
let o = split(sh(c), '@@WF@@\n'), r = [];
for (let i = 0; i < length(K); i++) push(r, trim(o[i] ?? ''));
return r;
}
function roles(main) {
let R = {}, cur = null;
let put = () => { if (cur && cur.id) R[cur.id] = { r: cur.role ?? 'a', own: length(cur.own ?? '') ? cur.own : 'admin' }; };
for (let l in split(readfile('/etc/config/wrtfreedom') ?? '', '\n')) {
if (substr(l, 0, 7) == 'config ') { put(); cur = match(l, /^config tgchat /) ? {} : null; continue; }
let m = cur ? match(l, /^[[:blank:]]*option (id|role|own) '?([^']*)'?[[:blank:]]*$/) : null;
if (m) cur[m[1]] = m[2];
}
put();
for (let k in keys(R)) if (!match(k, /^-?[0-9]{1,20}$/) || !match(R[k].r, /^[ast]$/) || R[k].own != 'admin') delete R[k];
if (length(main)) R[main] = { r: 't', own: 'admin' };
return R;
}
const NASJ = (getenv('WF_NASETC') ?? '/etc/wrtfreedom') + '/nas.json';
function nasj() { let N = null; try { N = json(readfile(NASJ) ?? '{}'); } catch (e) { N = null; } return type(N) == 'object' ? N : {}; }
function pstate(own) {
let u = nasj().users?.[own];
if (type(u) != 'object' || u.cam || UCFG.udir(own, 'tg') == null) return null;
return u.blocked ? 'blocked' : 'ok';
}
function cfgstamp() {
let s = stat('/etc/config/wrtfreedom'), d = stat('/tmp/.uci/wrtfreedom');
return { k: (s ? s.inode + ':' + s.mtime + ':' + s.size : '') + '|' + (d ? d.inode + ':' + d.mtime + ':' + d.size : ''),
m: (s ? s.mtime : 0) > (d ? d.mtime : 0) ? s.mtime : (d ? d.mtime : 0) };
}
let CFG = null, CFGK = null, CFGT = 0;
function cfg() {
let s = cfgstamp();
if (CFG && CFGK == s.k && s.m < CFGT) return CFG;
CFGT = time();
let v = ugs([ 'tg.token', 'tg.chat', 'ui.lang', 'tg.cmd', 'tg.pset', 'tg.preset', 'ai.on', 'ai.tg', 'ui.name' ]);
CFG = { token: v[0], chat: v[1], en: v[2] == 'en', cmd: v[3], pset: v[4], preset: v[5], ai: v[6] == '1' && v[7] == '1', roles: roles(v[1]), name: v[8] }; CFGK = s.k;
return CFG;
}
let EN = false;
function L(it, en) { return EN ? en : it; }
function rname() {
let n = trim(replace(cfg().name ?? '', /[[:cntrl:]]+/g, ' '));
if (!length(n)) n = trim(readfile('/proc/sys/kernel/hostname') ?? '');
return cut(length(n) ? n : 'OpenWrt', 64);
}
function u16(s) {
let n = 0;
for (let i = 0; i < length(s); i++) { let c = ord(s, i); if ((c & 192) != 128) n += c >= 240 ? 2 : 1; }
return n;
}
function named(t, max) {
let n = rname(), b = cut(replace('' + (t ?? ''), ' ¦ ', '\n'), (max ?? 3900) - length(n) - 1), f = split(b, '\n')[0];
if (!length(b)) return { text: n, entities: [ { type: 'italic', offset: 0, length: u16(n) } ] };
let E = length(f) ? [ { type: 'bold', offset: 0, length: u16(f) } ] : [];
push(E, { type: 'italic', offset: u16(b) + 1, length: u16(n) });
return { text: b + '\n' + n, entities: E };
}
function bh(t, w) { return (w ? '⚠️' : '💬') + ' Bot ¦ ' + t; }

const CURL = length(filter([ '/usr/sbin/curl', '/usr/bin/curl', '/sbin/curl', '/bin/curl' ], (f) => stat(f) != null)) > 0;
function urlenc(s) {
s = '' + s; let o = '';
for (let i = 0; i < length(s); i++) {
let c = ord(s, i);
o += ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 46 || c == 95 || c == 126) ? chr(c) : sprintf('%%%02X', c);
}
return o;
}
let TOKEN = '', CHAT = '', ROLE = 't', OWN = 'admin';
let PERS = {}, PCHAT = {};
const TGU = (getenv('WF_NASETC') ?? '/etc/wrtfreedom') + '/tg-u', TGUT = '/tmp/wf-tg-u';
function uok(a) { return type(a) == 'string' && match(a, /^[a-z][a-z0-9]{0,19}$/) != null && a != 'admin' && a != 'shared'; }
function ucount(a, k) {
if (!uok(a)) return;
mkdir(TGUT, 448);
let f = TGUT + '/' + a + '.cnt', l = localtime(), d = sprintf('%04d%02d%02d', l.year, l.mon, l.mday), C = null;
try { C = json(readfile(f) ?? 'null'); } catch (e) { C = null; }
if (type(C) != 'object' || C.d != d) C = { d: d, cmds: 0, ia: 0 };
C = { d: d, cmds: +(C.cmds ?? 0) || 0, ia: +(C.ia ?? 0) || 0 };
C[k] = C[k] + 1;
let t = f + '.' + rid() + '.t';
if (writefile(t, sprintf('%J', C)) == null || !rename(t, f)) unlink(t);
}
const KD = '/tmp/wf-tg.k';
function kfile(url) {
mkdir(KD, 448);
let f = KD + '/' + rid();
writefile(f, 'url = "' + replace(replace(url, '\\', () => '\\\\'), '"', () => '\\"') + '"\n');
return f;
}
function api(method, params, wait) {
let qs = [];
for (let k in (params ?? {})) {
let v = params[k];
if (v == null) continue;
push(qs, k + '=' + urlenc(type(v) in ['object', 'array'] ? sprintf('%J', v) : v));
}
let url = 'https://api.telegram.org/bot' + TOKEN + '/' + method + (length(qs) ? '?' + join('&', qs) : '');
let m = wait ?? 20, o = '';
if (!CURL) return null;
let f = kfile(url); o = sh('curl -s -m ' + m + ' -K ' + f + ' 2>/dev/null'); unlink(f);
try { return json(o); } catch (e) { return null; }
}
function say(text, extra) {
let N = named(text), p = { chat_id: CHAT, text: N.text, entities: N.entities };
for (let k in (extra ?? {})) p[k] = extra[k];
return api('sendMessage', p);
}
function edit(mid, text, kb) {
let N = named(text);
return api('editMessageText', { chat_id: CHAT, message_id: mid, text: N.text, entities: N.entities, reply_markup: kb });
}
function addto(m, res) {
let tx = '' + (m.text ?? ''), E = type(m.entities) == 'array' ? m.entities : [], z = E[length(E) - 1], r = replace('' + res, ' ¦ ', '\n'), i = rindex(tx, '\n');
if (z?.type == 'italic' && i > 0 && z.offset + z.length == u16(tx)) {
let o = map(E, (e) => e), n = substr(tx, i + 1), a = cut(substr(tx, 0, i), 3890 - length(r) - length(n)) + '\n' + r;
o[length(o) - 1] = { type: 'italic', offset: u16(a) + 1, length: u16(n) };
return api('editMessageText', { chat_id: CHAT, message_id: m.message_id, text: a + '\n' + n, entities: o });
}
return api('editMessageText', { chat_id: CHAT, message_id: m.message_id, text: cut(tx + '\n\n' + r, 3900), entities: E });
}
function sendfile(kind, file, caption, ttl) {
if (!CURL) { unlink(file); return say(bh(L('File non inviato ¦ Serve il pacchetto curl', 'File not sent ¦ Needs the curl package'), true)); }
let f = kind == 'PHOTO' ? 'photo' : 'document';
let kf = kfile('https://api.telegram.org/bot' + TOKEN + '/send' + (kind == 'PHOTO' ? 'Photo' : 'Document'));
let N = named(caption ?? '', 1000);
let o = sh('curl -s -m ' + (kind == 'PHOTO' ? 120 : 600) + ' -F chat_id=' + q(CHAT) + ' -F ' + q(f + '=@' + file) + ' --form-string ' + q('caption=' + N.text) + ' --form-string ' + q('caption_entities=' + sprintf('%J', N.entities)) + ' -K ' + kf + ' 2>/dev/null');
unlink(kf);
unlink(file);
let pd = match(file, /^(\/tmp\/wf-tgf\/[0-9a-f]{1,32})\/[^\/]+$/);
if (pd) rmdir(pd[1]);
if (index(o, '"ok":true') < 0) return say(bh(L('File non inviato', 'File not sent'), true));
let mid = match(o, /"message_id":([0-9]{1,20})/);
if (ttl > 0 && mid) {
let df = kfile('https://api.telegram.org/bot' + TOKEN + '/deleteMessage');
sh('( sleep ' + int(ttl) + '; curl -s -m 30 -d chat_id=' + q(CHAT) + ' -d message_id=' + mid[1] + ' -K ' + df + '; rm -f ' + df + ' ) >/dev/null 2>&1 </dev/null &');
}
}

let CAT = null, CATM = null;
function catalog() {
let st = stat(P), m = st ? st.mtime : 0;
if (CAT && CATM == m) return CAT;
let cats = [], cmds = [];
for (let l in split(readfile(P) ?? '', '\n')) {
if (substr(l, 0, 3) == '#% ') { let f = split(substr(l, 3), '|'); push(cats, { id: f[0], it: f[1], en: f[2], icon: f[3] }); }
else if (substr(l, 0, 3) == '#@ ') {
let f = split(substr(l, 3), '|');
push(cmds, { n: f[0], en: f[1], cat: f[2], fl: f[3], need: filter(split(f[4], ','), length), it: f[5], den: f[6], ait: f[7], aen: f[8], pre: true });
}
else if (length(cmds) && substr(l, 0, 1) != '#') break;
}
push(cats, { id: 'altro', it: 'Altri', en: 'Other', icon: '➕' });
CAT = { cats, cmds }; CATM = m;
return CAT;
}
function has(c, x) { return index(c.fl ?? '', x) >= 0; }
const SAFE = [ 'stato', 'uptime', 'carico', 'memoria', 'temperatura', 'versione', 'consumo', 'ora', 'linea', 'segnale', 'sqm',
'wifi', 'ospiti', 'ospiti_on', 'ospiti_off', 'adguard', 'vpn', 'latenza' ];
function allowed(c, role, own) {
role = role ?? ROLE; own = own ?? OWN ?? 'admin';
const PCMD = [ 'scarica', 'pausa_download', 'cerca_file' ];
if (own != 'admin') return has(c, 'l') || (c.pre && index(PCMD, c.n) >= 0 && (role == 't' || !has(c, 'f')) && !PERS[own]?.offs?.[c.n]);
return role == 't' || has(c, 'l') || (role == 's' && c.pre && !has(c, 'f') && index(SAFE, c.n) >= 0);
}
function installed(cmds) {
let K = cfg(), set = {}, saved = K.pset == '1';
for (let n in split(K.preset, ' ')) if (length(n)) set[n] = true;
let out = [];
for (let c in cmds) if (has(c, 'l') || (saved ? set[c.n] : has(c, 'd'))) push(out, c);
return out;
}
let CUS = null, CUSM = null;
function custom() {
let st = stat('/etc/config/wrtfreedom'), cm = st ? st.mtime + ':' + st.size : '';
if (CUS && CUSM == cm) return CUS;
let S = {}, order = [];
for (let l in split(sh('uci -q show wrtfreedom'), '\n')) {
let m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)=tgcmd$/);
if (m) { if (!S[m[1]]) push(order, m[1]); S[m[1]] = S[m[1]] ?? {}; continue; }
m = match(l, /^wrtfreedom\.([A-Za-z0-9_]+)\.([a-z]+)='(.*)'$/);
if (m) { S[m[1]] = S[m[1]] ?? {}; S[m[1]][m[2]] = replace(m[3], "'\\''", "'"); }
}
let out = [];
for (let s in order) {
let g = S[s];
if (g.enabled == '0' || !length(g.name ?? '')) continue;
let fl = (g.confirm == '1' ? 'c' : '') + (g.askmode == 'req' ? 'a' : g.askmode == 'opt' ? 'o' : '');
push(out, { n: g.name, en: g.name, cat: g.cat || 'altro', fl: fl, need: [], it: g.desc ?? '', den: g.desc ?? '', ait: g.ask ?? '', aen: g.ask ?? '', cmd: s, user: true });
}
CUS = out; CUSM = cm;
return out;
}
function active() {
let C = catalog(), U = custom(), taken = {};
for (let c in U) taken[c.n] = true;
let A = [...filter(installed(C.cmds), (c) => has(c, 'l') || !(taken[c.n] || taken[c.en])), ...U], out = [];
for (let k in C.cats) for (let c in A) if (c.cat == k.id) push(out, c);
return { cats: C.cats, list: out };
}
function nm(c) { return EN ? c.en : c.n; }
function desc(c) { return cut(EN ? c.den : c.it, 100); }
function find(list, w) {
w = lc(w);
if (w == 'start') w = 'aiuto';
for (let c in list) if (c.n == w || c.en == w) return c;
return null;
}

function setmenu() {
let A = active(), cmds = [];
for (let c in A.list) if (has(c, 'l')) push(cmds, { command: nm(c), description: desc(c) || nm(c) });
for (let c in A.list) if (!has(c, 'l') && length(cmds) < 100 && match(nm(c), /^[a-z0-9_]{1,32}$/)) push(cmds, { command: nm(c), description: desc(c) || nm(c) });
api('setMyCommands', { commands: cmds });
}
let MSIG = {};
function pmdel(ch) {
api('deleteMyCommands', { scope: { type: 'chat', chat_id: ch } });
api('setChatMenuButton', { chat_id: ch });
}
function pmenu() {
let A = null, mb = null, R = cfg().roles;
for (let a in keys(MSIG)) if (!PERS[a]) { pmdel(MSIG[a].chat); delete MSIG[a]; }
for (let a in keys(PERS)) {
let U = PERS[a], o = MSIG[a];
if (!length(U.chat) || PCHAT[U.chat] != a || U.cmd === false || R[U.chat]) {
if (o) { pmdel(o.chat); delete MSIG[a]; }
continue;
}
A = A ?? active();
let P = map(filter(A.list, (c) => allowed(c, 't', a) && match(nm(c), /^[a-z0-9_]{1,32}$/)), (c) => ({ command: nm(c), description: desc(c) || nm(c) }));
let s = U.chat + '|' + EN + '|' + sprintf('%J', P);
if (o?.s == s) continue;
if (o && o.chat != U.chat) pmdel(o.chat);
let r = api('setMyCommands', { commands: P, scope: { type: 'chat', chat_id: U.chat } });
mb = mb ?? api('getChatMenuButton', {}) ?? {};
let bt = mb?.ok && type(mb.result) == 'object' ? mb.result : null;
if (bt?.type == 'web_app' && type(bt.web_app) == 'object') api('setChatMenuButton', { chat_id: U.chat, menu_button: bt });
else if (bt && length(P)) api('setChatMenuButton', { chat_id: U.chat, menu_button: { type: 'commands' } });
MSIG[a] = { chat: U.chat, s: r?.ok === true ? s : '' };
}
}

function kbcats() {
let A = active(), rows = [], row = [];
for (let k in A.cats) {
let n = length(filter(A.list, (c) => c.cat == k.id && !has(c, 'l') && allowed(c)));
if (!n) continue;
push(row, { text: k.icon + ' ' + (EN ? k.en : k.it), callback_data: 'c:' + k.id });
if (length(row) == 2) { push(rows, row); row = []; }
}
if (length(row)) push(rows, row);
return { inline_keyboard: rows };
}
function kbcat(id) {
let A = active(), rows = [], row = [];
for (let c in A.list) {
if (c.cat != id || has(c, 'l') || !allowed(c)) continue;
push(row, { text: '/' + nm(c), callback_data: 'r:' + c.n });
if (length(row) == 2) { push(rows, row); row = []; }
}
if (length(row)) push(rows, row);
push(rows, [{ text: L('⬅️ Categorie', '⬅️ Categories'), callback_data: 'm' }]);
return { inline_keyboard: rows };
}
function catof(id) {
for (let k in catalog().cats) if (k.id == id) return k;
return { id: id, it: id, en: id, icon: '➕' };
}
function catname(id) { let k = catof(id); return k.icon + ' ' + (EN ? k.en : k.it); }
function head(c, out) {
let ls = split(replace('' + out, ' ¦ ', '\n'), '\n'), f = ls[0] ?? '';
if (substr(f, 0, 4) == '@@H ') return substr(f, 4) + (length(ls) > 1 ? '\n' + join('\n', slice(ls, 1)) : '');
let k = catof(c.cat), w = EN ? k.en : k.it, e = k.icon, m = match(f, /^([^ A-Za-z0-9]{1,16}) (.*)$/), x = f, list = false;
if (substr(f, 0, 2) == '• ') list = true;
else if (m) {
if (m[1] in [ '🟢', '🔴', '🟠', '🟡', '⚪', '🔵' ]) list = true;
else { x = m[2]; if (m[1] in [ '⚠️', '⚠', '❌', '⛔' ]) e = '⚠️'; else if (m[1] == '🆘') e = '🆘'; }
}
x = trim(x);
if (!length(trim(out))) return e + ' ' + w + '\n' + L('Fatto', 'Done');
if (list || !length(x) || lc(x) == lc(w)) {
let d = desc(c), b = list ? join('\n', ls) : join('\n', slice(ls, 1));
return e + ' ' + w + '\n' + (length(d) ? d : L('Fatto', 'Done')) + (length(trim(b)) ? '\n' + b : '');
}
let a = ord(x, 0);
if (a >= 97 && a <= 122) x = uc(substr(x, 0, 1)) + substr(x, 1);
return e + ' ' + w + '\n' + x + (length(ls) > 1 ? '\n' + join('\n', slice(ls, 1)) : '');
}
function helptext() {
let A = active(), o = bh(L('Comandi disponibili', 'Available commands')), last = '';
for (let c in A.list) {
if (!allowed(c)) continue;
if (c.cat != last) { o += '\n\n' + catname(c.cat); last = c.cat; }
let l = '/' + nm(c) + ' - ' + desc(c);
o += '\n' + (ulen(l) <= 29 ? l : '/' + nm(c) + '\n' + join('\n', fold(desc(c), 29)));
}
return o + '\n\n' + L('/menu: pulsanti per categoria', '/menu: buttons by category');
}

function spawn(c, arg) {
let f = '/tmp/wf-tg.arg.' + rid();
writefile(f, '' + (arg ?? ''));
sh('( ucode ' + W + '/tgbot.uc run ' + q(c.n) + ' ' + f + ' ' + q(CHAT) + (OWN != 'admin' ? ' ' + q(OWN) : '') + ' ) >/dev/null 2>&1 </dev/null &');
if (OWN != 'admin') ucount(OWN, 'cmds');
}
function pend_get() { try { return json(readfile(PEND) ?? '{}') ?? {}; } catch (e) { return {}; } }
function pend_add(o) {
let P = pend_get(), id = rid(), now = time();
for (let k in keys(P)) if (now - P[k].t > 600) delete P[k];
o.t = now; o.chat = CHAT; o.own = OWN; P[id] = o;
writefile(PEND, sprintf('%J', P));
return id;
}
function yesno(id) { return { inline_keyboard: [[{ text: L('✅ Sì', '✅ Yes'), callback_data: 'y:' + id }, { text: L('✖️ No', '✖️ No'), callback_data: 'n:' + id }]] }; }
function request(c, arg, confirmed) {
if (c.n == 'menu') return say(bh(L('Scegli una categoria', 'Choose a category')), { reply_markup: kbcats() });
if (c.n == 'aiuto') {
let P = [], b = '';
for (let l in split(helptext(), '\n')) {
if (length(b) && length(b) + 1 + length(l) > 3800) { push(P, b); b = ''; }
b += (length(b) ? '\n' : '') + l;
}
if (length(b)) push(P, b);
for (let x in slice(P, 0, 3)) say(x);
return;
}
if (!allowed(c)) return say(bh(L('Non permesso in questa chat', 'Not allowed in this chat'), true));
arg = trim('' + (arg ?? ''));
if (has(c, 'a') && !length(arg))
return say('💬 /' + nm(c) + ' ¦ ' + (EN ? c.aen : c.ait), { reply_markup: { force_reply: true, input_field_placeholder: cut(EN ? c.aen : c.ait, 60) } });
if (has(c, 'c') && !confirmed) {
let id = pend_add({ n: c.n, arg: arg });
return say('💬 /' + nm(c) + (length(arg) ? ' ' + arg : '') + '?' + ' ¦ ' + desc(c) + ' ¦ ' + L('Confermi?', 'Confirm?'), { reply_markup: yesno(id) });
}
spawn(c, arg);
}
function alias(w, arg) {
let a = lc(trim(arg ?? ''));
if (!(a in ['on', 'off', 'si', 'sì', 'yes'])) return null;
let m = { wifi: 'wifi_', vpn: 'vpn_', adguard: 'adg_', ospiti: 'ospiti_', guest: 'ospiti_' }[lc(w)];
if (m && a in ['on', 'off']) return m + a;
if (lc(w) in ['riavvia', 'reboot'] && a in ['si', 'sì', 'yes']) return 'riavvia!';
return null;
}
function wf(m, a) { let o = sh('ubus -t 20 call wrtfreedom ' + m + ' ' + q(sprintf('%J', a)) + ' 2>/dev/null'); try { return length(o) ? json(o) : null; } catch (e) { return null; } }
function devquick(act, mac) {
let r = null;
try { r = json(sh('ubus call wrtfreedom quick ' + q(sprintf('%J', { act: act, mac: mac })) + ' 2>/dev/null') || 'null'); } catch (e) {}
return { ok: !!r?.ok, t: r?.ok ? (act == 'known' ? L('Segnato come conosciuto', 'Marked as known') : L('Internet bloccato ¦ Lo sblocchi dall\'app', 'Internet blocked ¦ Unblock it from the app')) : L('Non riuscito', 'Failed') };
}
function dqbody(r) { return (r.ok ? '✅ ' : '❌ ') + r.t; }
function dqhead(r) { return (r.ok ? '📱 ' : '⚠️ ') + L('Dispositivi', 'Devices') + ' ¦ ' + r.t; }
function nasuser(act, u) {
let r = wf('nas_users', { act: act, user: u });
if (r && !r.error) return { ok: true, t: act == 'ok' ? L('Va Bene: accesso confermato', 'Approved: access confirmed') : L('Accesso bloccato ¦ La cartella resta', 'Access blocked ¦ The folder is kept') };
return { ok: false, t: r?.error ? '' + ((EN ? r.error_en : null) ?? r.error) : L('Il router non ha risposto', 'The router did not answer') };
}
function nuvis(u) { let v = nasj().users?.[u]?.vis; return type(v) == 'string' && length(v) ? replace(v, /[[:cntrl:]]+/g, ' ') : u; }
function nubody(r) { return (r.ok ? '✅ ' : '❌ ') + r.t; }
function nuhead(r, u) { return (r.ok ? '🗄️ ' : '⚠️ ') + cut(nuvis(u), 60) + ' ¦ ' + r.t; }
const AICF = '/tmp/wf-ai/cf-tg.json';
function cfput(M) { writefile(AICF + '.t', sprintf('%J', M)); rename(AICF + '.t', AICF); }
function asof(a) { if (OWN != 'admin') a.as = OWN; return a; }
let AIAS = null, AIAST = 0;
function aias() {
if (AIAS == null || time() - AIAST > 600) { AIAS = match(sh('ubus -v list wrtfreedom 2>/dev/null'), /"aiask":[ ]*\{[^}]*"as":/) != null; AIAST = time(); }
return AIAS;
}
function aiask(tx) {
if (OWN != 'admin' && !aias()) return say(bh(L('Assistente IA ¦ Non attivo in questa chat', 'AI Assistant ¦ Not active in this chat'), true));
let r = wf('aiask', asof({ text: cut(tx, 2000), tg: CHAT }));
if (!r || r.error) return say('⚠️ ' + L('Assistente', 'Assistant') + ' ¦ ' + (r?.error ?? L('Il router non ha risposto ¦ Riprova', 'The router did not answer ¦ Try again')));
if (OWN != 'admin') ucount(OWN, 'ia');
api('sendChatAction', { chat_id: CHAT, action: 'typing' });
}
function aion() { return ROLE == 't' && (OWN != 'admin' ? PERS[OWN]?.ai !== false : cfg().ai); }
const TGMAX = 20 * 1048576, TGF = '/tmp/wf-tgf';
function onfile(msg) {
if (CHAT != cfg().chat && OWN == 'admin') return say(bh(L('File non salvato ¦ Solo dalla chat collegata', 'File not saved ¦ Only from the linked chat'), true));
let f = msg.document ?? msg.video ?? msg.audio ?? (type(msg.photo) == 'array' ? msg.photo[length(msg.photo) - 1] : null);
if (!match('' + (f?.file_id ?? ''), /^[A-Za-z0-9_-]{10,255}$/)) return;
if (+(f.file_size ?? 0) > TGMAX) return say('🗄️ NAS ¦ ' + L('Troppo grande per il bot ¦ Al massimo 20 MB ¦ Caricalo dall\'app', 'Too big for the bot ¦ Up to 20 MB ¦ Upload it from the app'));
let a = '/tmp/wf-tg.arg.' + rid();
writefile(a, sprintf('%J', { id: f.file_id, name: '' + (f.file_name ?? ''), size: +(f.file_size ?? 0), t: +(msg.date ?? time()),
kind: msg.document ? 'doc' : msg.video ? 'video' : msg.audio ? 'audio' : 'photo' }));
sh('( ucode ' + W + '/tgbot.uc save ' + a + ' ' + q(CHAT) + (OWN != 'admin' ? ' ' + q(OWN) : '') + ' ) >/dev/null 2>&1 </dev/null &');
api('sendChatAction', { chat_id: CHAT, action: 'typing' });
}
function savename(F, fp) {
let n = '' + (F.name ?? ''), e = match(fp, /(\.[A-Za-z0-9]{1,8})$/), x = e ? lc(e[1]) : (F.kind == 'photo' ? '.jpg' : '');
n = replace(n, /^.*[\/\\]/, '');
n = trim(replace(n, /[[:cntrl:]<>:"\/\\|?*]/g, '_'));
n = replace(replace(n, /^[. ]+/, ''), /[. ]+$/, '');
if (!length(n)) {
let l = localtime(+(F.t ?? time())), k = { photo: [ 'Foto', 'Photo' ], video: [ 'Video', 'Video' ], audio: [ 'Audio', 'Audio' ] }[F.kind] ?? [ 'File', 'File' ];
n = sprintf('%s %04d-%02d-%02d %02d.%02d.%02d', EN ? k[1] : k[0], l.year, l.mon, l.mday, l.hour, l.min, l.sec) + x;
}
if (length(n) > 150) { let m = match(n, /^(.*)(\.[A-Za-z0-9]{1,8})$/); n = m ? cut(m[1], 150 - length(m[2])) + m[2] : cut(n, 150); }
return n;
}
function freename(dir, n) {
let m = match(n, /^(.+)(\.[A-Za-z0-9]{1,8})$/), b = m ? m[1] : n, x = m ? m[2] : '';
for (let i = 1; i < 1000; i++) {
let c = i == 1 ? n : b + ' (' + i + ')' + x;
if (!lstat(dir + '/' + c)) return c;
}
return null;
}
function savefile(F) {
let H = '🗄️ NAS ¦ ', S = wf('nas_state', {});
if (type(S?.disks) != 'array') return say('⚠️ NAS ¦ ' + L('Il router non ha risposto ¦ Riprova', 'The router did not answer ¦ Try again'));
if (S.on !== true) return say(H + L('NAS spento ¦ Accendilo dall\'app', 'NAS is off ¦ Turn it on in the app'));
let D = filter(S.disks, (d) => d.main === true)[0], need = +(F.size ?? 0) + 16 * 1048576;
if (S.pause === true || type(S.main) != 'object' || !D || !D.mounted || D.ro || !match('' + (D.mnt ?? ''), /^\/[^\t\n]+$/))
return say(H + L('File non salvato ¦ Manca il Disco Principale', 'File not saved ¦ The Main Disk is missing'));
if (+(D.free ?? 0) <= need) return say(H + L('File non salvato ¦ Disco Principale pieno', 'File not saved ¦ Main Disk full'));
if (OWN != 'admin' && index(split(readfile('/tmp/wf-nas/full.list') ?? '', '\n'), OWN) >= 0)
return say(H + L('File non salvato ¦ Spazio finito ¦ Libera o chiedi più spazio', 'File not saved ¦ Space used up ¦ Free up space or ask for more'));
let tg = UCFG.udir(OWN, 'tg'), dir = tg ? D.mnt + '/' + tg : null, dok = tg != null;
if (dok) { let c = D.mnt; for (let s in split(tg, '/')) { c += '/' + s; let x = lstat(c); if (!x) { mkdir(c, 493); x = lstat(c); } if (x?.type != 'directory') { dok = false; break; } } }
if (!dok) return say(H + L('File non salvato ¦ Cartella Telegram non creata', 'File not saved ¦ Telegram folder not created'));
let dn = join(' › ', [ L('Disco Principale', 'Main Disk'), ...slice(split(tg, '/'), 1) ]);
let r = api('getFile', { file_id: F.id }), fp = r?.ok ? '' + (r.result?.file_path ?? '') : '';
if (!match(fp, /^[A-Za-z0-9_.\/-]{1,255}$/) || index(fp, '..') >= 0) return say(H + L('File non salvato ¦ Telegram non lo dà ¦ Riprova', 'File not saved ¦ Telegram does not give it ¦ Try again'));
let part = dir + '/.wf-tg-' + rid() + '.part', kf = kfile('https://api.telegram.org/file/bot' + TOKEN + '/' + fp);
sh('umask 002; curl -s -f -m 300 -o ' + q(part) + ' -K ' + kf + ' 2>/dev/null');
unlink(kf);
let ps = stat(part);
if (!ps || ps.size <= 0 || (+(F.size ?? 0) > 0 && ps.size != +F.size)) { unlink(part); return say(H + L('File non salvato ¦ Scaricamento interrotto ¦ Riprova', 'File not saved ¦ Download interrupted ¦ Try again')); }
mkdir(TGF, 448);
let lk = TGF + '/save.lock', w = 0;
while (!mkdir(lk)) {
let ls = stat(lk);
if (ls && time() - ls.mtime > 60) { rmdir(lk); continue; }
if (++w > 30) break;
sh('sleep 1');
}
let nm = freename(dir, savename(F, fp)), ok = nm != null && rename(part, dir + '/' + nm);
rmdir(lk);
if (!ok) { unlink(part); return say(H + L('File non salvato ¦ Riprova', 'File not saved ¦ Try again')); }
say(H + L('File salvato', 'File saved') + ' ¦ ' + nm + ' ¦ ' + dn);
}
function onmessage(msg) {
if (msg.document || msg.photo || msg.video || msg.audio) return onfile(msg);
let tx = trim(msg.text ?? '');
let rq = msg.reply_to_message && msg.reply_to_message.text;
if (rq && substr(tx, 0, 1) != '/') {
let w = null;
for (let l in slice(split(rq, '\n'), 0, 2)) {
let m = match(l, /^💬 \/([A-Za-z0-9_]{1,64})$/) ?? match(l, /^💬 Bot · \/([A-Za-z0-9_]{1,64}): /) ?? match(l, /^✍️ \/([A-Za-z0-9_]{1,64})/);
if (m) { w = m[1]; break; }
}
let c = w ? find(active().list, w) : null;
if (c) return request(c, tx);
}
let yw = substr(tx, 0, 1) != '/' && aion() ? lc(trim(tx)) : '';
let cw = match(yw, /^(s(i|ì)[ ,!.]*)?(confermo|conferma|confermato|procedi|vai|confirm|confirmed|go ahead)[ !.]*$/), aw = match(yw, /^(s(i|ì)|ok|okay|va bene|fallo|certo|d.accordo|yes|sure|do it)[ ,!.]*$/);
let wz = null;
if (cw || aw) { try { wz = json(readfile('/tmp/wf-ai/tg-' + CHAT + '.json') ?? '{}')?.wz; } catch (e) {} }
if ((cw || aw) && !(type(wz) == 'object' && time() - +(wz.t ?? 0) < 600)) {
let M = null, p = false;
try { M = json(readfile('/tmp/wf-ai/pend-tg.json') ?? '{}'); } catch (e) {}
for (let k in keys(type(M) == 'object' ? M : {})) if (M[k]?.tg == '' + CHAT && time() - +(M[k].t ?? 0) <= 600) p = true;
let F = null;
try { F = json(readfile(AICF) ?? '{}'); } catch (e) {}
for (let k in keys(type(F) == 'object' ? F : {})) if (F[k]?.tg == '' + CHAT && !F[k].by && time() - +(F[k].t ?? 0) <= +(F[k].secs ?? 120) + 30) p = true;
let G = pend_get();
for (let k in keys(type(G) == 'object' ? G : {})) if (G[k]?.chat == CHAT && time() - +(G[k].t ?? 0) <= 600) p = true;
if (p) return say(bh(L('Tocca ✅ sotto il messaggio', 'Tap ✅ under the message')));
if (cw) return say(bh(L('Niente da confermare ¦ Dimmi di nuovo cosa fare', 'Nothing to confirm ¦ Tell me again what to do')));
}
if (substr(tx, 0, 1) != '/') return length(tx) && aion() ? aiask(tx) : null;
let m = match(tx, /^\/([A-Za-z0-9_]+)(@[A-Za-z0-9_]+)?[ \n]*(.*)$/s);
if (!m) return;
let w = m[1], arg = m[3] ?? '', list = active().list, al = alias(w, arg);
if (al == 'riavvia!') { let c = find(list, 'riavvia'); if (c) return request(c, '', true); }
if (al) { let c = find(list, al); if (c) return request(c, ''); w = al; }
let c = al ? null : find(list, w);
if (c) return request(c, arg);
for (let x in catalog().cmds) if (x.n == lc(w) || x.en == lc(w))
return say(bh(L('/' + w + ' non installato ¦ Attivalo nell\'app ¦ Bot › Comandi Pronti', '/' + w + ' not installed ¦ Turn it on in the app ¦ Bot › Ready Commands')));
say(bh(L('Comando sconosciuto: /' + w + ' ¦ Scrivi /aiuto o /menu', 'Unknown command: /' + w + ' ¦ Type /help or /menu')));
}
function oncallback(cb) {
let d = cb.data ?? '', mid = cb.message.message_id;
api('answerCallbackQuery', { callback_query_id: cb.id });
if (d == 'm') return edit(mid, bh(L('Scegli una categoria', 'Choose a category')), kbcats());
if (substr(d, 0, 2) == 'c:') return edit(mid, catname(substr(d, 2)) + ' ¦ ' + L('Scegli un comando', 'Choose a command'), kbcat(substr(d, 2)));
if (substr(d, 0, 2) == 'r:') {
let x = substr(d, 2), p = match(x, /^([a-z0-9_]+):([a-z0-9_]+)$/), c = find(active().list, p ? p[1] : x);
return c ? request(c, p ? p[2] : '') : null;
}
if (d == 'n' || match(d, /^n:[0-9a-f]{1,32}$/)) {
let P = pend_get(), k = substr(d, 2);
if (length(k) && P[k] && (P[k].chat == null || P[k].chat == CHAT)) { delete P[k]; writefile(PEND, sprintf('%J', P)); }
return edit(mid, bh(L('Annullato', 'Cancelled')));
}
if (match(d, /^ai:[yn]:[0-9a-f]{8}$/)) {
let y = substr(d, 3, 1) == 'y', r = ROLE == 't' && (OWN == 'admin' || aias()) ? wf('aido', asof({ id: substr(d, 5), yes: y, tg: CHAT })) : { error: L('Comando non permesso qui', 'Command not allowed here') };
let res = !r ? '❌ ' + L('Il router non ha risposto', 'The router did not answer') : r.error ? '❌ ' + r.error : y ? '✅ ' + L('Confermato', 'Confirmed') : '❌ ' + L('Annullato', 'Cancelled');
return addto(cb.message, res);
}
if (match(d, /^ai:[cb]:[0-9a-f]{8}$/)) {
let y = substr(d, 3, 1) == 'c', id = substr(d, 5), M = null, res = '';
try { M = json(readfile(AICF) ?? '{}'); } catch (e) { M = null; }
let X = type(M) == 'object' ? M[id] : null;
if (ROLE != 't' || OWN != 'admin') res = '❌ ' + L('Comando non permesso qui', 'Command not allowed here');
else if (!X || X.tg != '' + CHAT || X.by || !match(X.cm ?? '', /^[a-z0-9]{2,20}$/)) res = '❌ ' + L('Richiesta già chiusa', 'Request already closed');
else {
X.by = y ? 'c' : 'b'; cfput(M);
let r = wf(X.cm, { action: y ? 'confirm' : 'back' });
if (!r || r.error) { delete X.by; cfput(M); }
res = !r ? '❌ ' + L('Il router non ha risposto\nSenza conferma torna com\'era', 'No answer from the router\nUnconfirmed, it goes back') : r.error ? '❌ ' + r.error :
y ? '✅ ' + L('Confermato: resta così', 'Confirmed: kept as it is') : '✅ ' + L('Rimesso com\'era', 'Put back as it was');
}
return addto(cb.message, res);
}
if (substr(d, 0, 5) == 'ai:p:' && length(d) > 5) {
if (!aion()) return say(bh(L('Non permesso in questa chat', 'Not allowed in this chat'), true));
addto(cb.message, '✅ ' + substr(d, 5));
return aiask(substr(d, 5));
}
if (match(d, /^d[kb]:[0-9a-f]{12}$/) && ROLE == 't' && OWN == 'admin') {
let h = substr(d, 3), mac = join(':', map([0, 2, 4, 6, 8, 10], (i) => substr(h, i, 2)));
if (substr(d, 1, 1) == 'b') {
let id = pend_add({ db: mac, mid: mid, txt: cut(cb.message.text ?? '', 3000), ent: cb.message.entities });
let a0 = split(cb.message.text ?? '', '\n')[0] ?? '', am = match(a0, /^[^ A-Za-z0-9]{1,16} (.+)$/);
return say('📱 ' + cut(am ? am[1] : a0, 60) + ' ¦ ' + L('Bloccare internet?', 'Block internet?') + ' ¦ ' + mac, { reply_markup: yesno(id) });
}
return addto(cb.message, dqbody(devquick('known', mac)));
}
let nu = match(d, /^nu:([ob]):([a-z][a-z0-9]{0,19})$/);
if (nu) {
if (ROLE != 't' || OWN != 'admin') return addto(cb.message, '❌ ' + L('Comando non permesso qui', 'Command not allowed here'));
if (nu[1] == 'o') return addto(cb.message, nubody(nasuser('ok', nu[2])));
let id = pend_add({ nb: nu[2], mid: mid, txt: cut(cb.message.text ?? '', 3000), ent: cb.message.entities });
return say('🗄️ ' + cut(nuvis(nu[2]), 60) + ' ¦ ' + L('Bloccare l\'accesso al NAS?', 'Block NAS access?') + ' ¦ ' + L('La cartella resta', 'The folder is kept'), { reply_markup: yesno(id) });
}
if (substr(d, 0, 2) == 'y:') {
let P = pend_get(), p = P[substr(d, 2)];
if (p?.nb) {
if (time() - p.t > 600 || ROLE != 't' || OWN != 'admin' || p.chat != CHAT || !match(p.nb, /^[a-z][a-z0-9]{0,19}$/)) return edit(mid, bh(L('Richiesta scaduta ¦ Ripeti il comando', 'Request expired ¦ Repeat the command'), true));
delete P[substr(d, 2)]; writefile(PEND, sprintf('%J', P));
let res = nasuser('block', p.nb);
edit(mid, nuhead(res, p.nb));
if (p.mid) addto({ message_id: p.mid, text: p.txt, entities: p.ent }, nubody(res));
return;
}
if (p?.db) {
if (time() - p.t > 600 || ROLE != 't' || OWN != 'admin' || p.chat != CHAT || !match(p.db, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/)) return edit(mid, bh(L('Richiesta scaduta ¦ Ripeti il comando', 'Request expired ¦ Repeat the command'), true));
delete P[substr(d, 2)]; writefile(PEND, sprintf('%J', P));
let res = devquick('block', p.db);
edit(mid, dqhead(res));
if (p.mid) addto({ message_id: p.mid, text: p.txt, entities: p.ent }, dqbody(res));
return;
}
let c = p ? find(active().list, p.n) : null;
if (!p || time() - p.t > 600 || ((ROLE != 't' || OWN != 'admin') && !(c && allowed(c))) || (p.chat != null && p.chat != CHAT) || (p.own ?? 'admin') != OWN) return edit(mid, bh(L('Richiesta scaduta ¦ Ripeti il comando', 'Request expired ¦ Repeat the command'), true));
delete P[substr(d, 2)]; writefile(PEND, sprintf('%J', P));
edit(mid, bh(L('Confermato', 'Confirmed') + ' ¦ /' + (c ? nm(c) : p.n) + (length(p.arg) ? ' ' + p.arg : '')));
if (c) spawn(c, p.arg);
else say(bh(L('Comando non più installato', 'Command no longer installed'), true));
}
}

function seen(ch) {
let F = SEEN, S = [];
try { S = json(readfile(F) ?? '[]') ?? []; } catch (e) {}
if (type(S) != 'array') S = [];
S = filter(S, (x) => '' + x.id != '' + ch.id);
push(S, { id: '' + ch.id, name: cut(ch.title ?? trim((ch.first_name ?? '') + ' ' + (ch.last_name ?? '')), 40), t: time() });
writefile(F, sprintf('%J', slice(S, length(S) > 10 ? length(S) - 10 : 0)));
}

function codeok(c) { return type(c) == 'string' && match(c, /^[A-Za-z0-9_-]{12}$/) != null; }
function uraw(a) {
let U = null;
try { U = json(readfile(TGU + '/' + a + '.json') ?? 'null'); } catch (e) { U = null; }
return type(U) == 'object' ? U : null;
}
function people() {
PERS = {}; PCHAT = {};
for (let f in (lsdir(TGU) ?? [])) {
let m = match(f, /^([a-z][a-z0-9]{0,19})\.json$/), U = m && uok(m[1]) ? uraw(m[1]) : null;
if (!U) continue;
let ch = match('' + (U.chat ?? ''), /^-?[0-9]{1,20}$/) ? '' + U.chat : '', off = {};
for (let n in (type(U.off) == 'array' ? U.off : [])) off['' + n] = true;
PERS[m[1]] = { chat: ch, code: codeok(U.code) ? U.code : '', until: +(U.until ?? 0) || 0, cmd: U.cmd !== false, ai: U.ai !== false, offs: off };
if (length(ch)) PCHAT[ch] = PCHAT[ch] == null ? m[1] : '';
}
}
function pneed() { return length(keys(PERS)) > 0; }
function uput(a, U) {
let f = TGU + '/' + a + '.json', t = f + '.' + rid() + '.t', FS = require('fs');
sh('umask 077; : > ' + q(t));
if (type(FS.chmod) == 'function') FS.chmod(t, 0600);
if (((stat(t)?.mode ?? 511) & 63) != 0 || writefile(t, sprintf('%J', U)) == null || !rename(t, f)) { unlink(t); return false; }
return true;
}
function ulink(m, code) {
let id = '' + m.chat.id, a = null, again = L('Tocca Collega Telegram ¦ nell\'app, di nuovo', 'Tap Connect Telegram ¦ in the app again');
for (let k in keys(PERS)) if (length(PERS[k].code) && PERS[k].code == code) { a = k; break; }
if (!a) return say(bh(L('Codice non valido', 'Invalid code') + ' ¦ ' + again, true));
if (time() > PERS[a].until) return say(bh(L('Codice scaduto', 'Code expired') + ' ¦ ' + again, true));
if (m.chat.type != 'private') return say(bh(L('Collega Telegram ¦ da una chat privata ¦ con il bot', 'Connect Telegram ¦ from a private chat ¦ with the bot'), true));
if (cfg().roles[id] || (PCHAT[id] != null && PCHAT[id] != a)) return say(bh(L('Questa chat è già collegata', 'This chat is already linked'), true));
let ps = pstate(a);
if (ps != 'ok') return say(bh(ps == 'blocked' ? L('Bloccato dall\'Amministratore', 'Blocked by the Administrator') : L('Persona non più sul NAS ¦ Chiedi all\'Amministratore', 'Person no longer on the NAS ¦ Ask the Administrator'), true));
let lk = '/tmp/wf-tg-u/' + a + '.lk', ok = false;
if (UCFG.pidlock(lk, '/tmp/wf-tg-u', 5)) {
let V = uraw(a);
try { ok = V != null && V.code == code && uput(a, { ...V, chat: id, code: '', until: 0 }); } catch (e) { ok = false; }
UCFG.pidunlock(lk);
}
if (!ok) return say(bh(L('Collegamento non riuscito', 'Link failed') + ' ¦ ' + again, true));
people();
OWN = a; ROLE = 't';
say(bh(L('Bot collegato ¦ Ricevi solo i tuoi avvisi ¦ Usi solo i tuoi comandi ¦ /menu: i tuoi comandi', 'Bot linked ¦ You get only your alerts ¦ You use only your commands ¦ /menu: your commands')));
}
function pupdate(u, m, sm) {
let id = '' + m.chat.id, a = PCHAT[id];
CHAT = id; OWN = 'admin'; ROLE = 't';
if (!length(a ?? '')) {
if (u.callback_query) api('answerCallbackQuery', { callback_query_id: u.callback_query.id });
if (sm) return ulink(m, sm[2]);
seen(m.chat);
if (m.chat.type == 'private' && match(trim(u.message?.text ?? ''), /^\/start(@[A-Za-z0-9_]+)?$/))
say(bh(L('Per collegare questa chat ¦ apri WrtFreedom ¦ e tocca Collega Telegram', 'To link this chat ¦ open WrtFreedom and ¦ tap Connect Telegram'), true));
return;
}
OWN = a;
let ps = pstate(a);
if (ps != 'ok') {
if (u.callback_query) api('answerCallbackQuery', { callback_query_id: u.callback_query.id });
return say(bh(ps == 'blocked' ? L('Bloccato dall\'Amministratore', 'Blocked by the Administrator') : L('Persona non più sul NAS ¦ Chiedi all\'Amministratore', 'Person no longer on the NAS ¦ Ask the Administrator'), true));
}
if (sm) return ulink(m, sm[2]);
if (!PERS[a].cmd) {
if (u.callback_query) api('answerCallbackQuery', { callback_query_id: u.callback_query.id });
else if (substr(trim(u.message?.text ?? ''), 0, 1) == '/') say(bh(L('Qui arrivano solo gli avvisi', 'This chat only gets alerts'), true));
return;
}
if (u.message) onmessage(u.message);
else oncallback(u.callback_query);
}

if (ARGV[0] == 'run') {
let K = ugs([ 'ui.lang', 'tg.token', 'tg.chat' ]);
EN = K[0] == 'en'; TOKEN = K[1]; CHAT = K[2];
let ua = '' + (ARGV[4] ?? ''), to = '' + (ARGV[3] ?? '');
if (length(ua)) {
if (uok(ua)) people();
let U = uok(ua) ? PERS[ua] : null;
if (!U || !length(U.chat) || U.chat != to || PCHAT[to] != ua || !U.cmd || roles(CHAT)[to] || pstate(ua) != 'ok') { if (match('' + ARGV[2], /^\/tmp\/wf-tg\.arg\./)) unlink(ARGV[2]); exit(1); }
OWN = ua; ROLE = 't';
}
if (!length(TOKEN) || !length(CHAT)) exit(1);
let n = '' + ARGV[1], af = ARGV[2], arg = af ? (readfile(af) ?? '') : '';
if (af && match(af, /^\/tmp\/wf-tg\.arg\./)) unlink(af);
let C = catalog(), c = null;
for (let x in [...custom(), ...C.cmds]) if (x.n == n) { c = x; break; }
if (!c || (OWN != 'admin' && !allowed(c))) exit(1);
if (OWN != 'admin') CHAT = to;
else if (length(to) && to != CHAT) {
let r = roles(CHAT)[to];
if (!r || r.r == 'a' || !allowed(c, r.r, r.own)) exit(1);
CHAT = to; ROLE = r.r; OWN = r.own;
}
if (c.n == 'menu' || c.n == 'aiuto') { request(c, ''); exit(0); }
api('sendChatAction', { chat_id: CHAT, action: has(c, 'f') ? 'upload_photo' : 'typing' });
let k = catof(c.cat), env = 'ARG=' + q(arg) + ' WF_CHAT=' + q(CHAT) + ' WF_ROLE=' + q(ROLE) + ' WF_OWN=' + q(OWN) + ' WF_HEAD=' + q(k.icon + '|' + (EN ? k.en : k.it)) + ' ';
let out = c.pre ? sh(env + 'sh ' + P + ' ' + q(c.n)) : sh(env + 'sh -c ' + q(ug('wrtfreedom.' + c.cmd + '.cmd')) + ' 2>&1');
out = trim(out);
let fm = match(out, /^@@(PHOTO|DOC) (\/tmp\/[^\n]+)\n?(.*)$/s);
if (fm) {
let fp = fm[2], tm = match(fp, /^(.+) ttl=([0-9]{1,5})$/);
if (tm) fp = tm[1];
if (!match(fp, /(^|\/)\.\.(\/|$)/)) { sendfile(fm[1], fp, head(c, trim(fm[3] ?? '')), +(tm ? tm[2] : 0)); exit(0); }
}
let bm = match(out, /^@@BTN(1?) ([^\n]*)\n?(.*)$/s);
if (bm) {
let rows = [], row = [], per = bm[1] == '1' ? 1 : 2;
for (let b in split(bm[2], '|')) {
let p = match(b, /^([a-z0-9_]+)=(.+)$/), cd = p ? 'r:' + c.n + ':' + p[1] : '';
if (!p || length(p[1]) > 20 || length(cd) > 64) continue;
push(row, { text: cut(p[2], 60), callback_data: cd });
if (length(row) == per) { push(rows, row); row = []; }
}
if (length(row)) push(rows, row);
out = trim(bm[3] ?? '');
say(head(c, out), length(rows) ? { reply_markup: { inline_keyboard: rows } } : null);
exit(0);
}
for (let x in pieces(head(c, out), 3800, 3)) say(x);
exit(0);
}
if (ARGV[0] == 'save') {
let K = ugs([ 'ui.lang', 'tg.token', 'tg.chat' ]), af = '' + (ARGV[1] ?? ''), F = null;
EN = K[0] == 'en'; TOKEN = K[1]; CHAT = K[2];
if (match(af, /^\/tmp\/wf-tg\.arg\.[0-9a-f]{1,32}$/)) { try { F = json(readfile(af) ?? 'null'); } catch (e) { F = null; } unlink(af); }
let to = '' + (ARGV[2] ?? ''), ua = '' + (ARGV[3] ?? ''), r = null;
if (length(ua)) {
if (uok(ua)) people();
let U = uok(ua) ? PERS[ua] : null;
if (U && length(CHAT) && length(U.chat) && U.chat == to && PCHAT[to] == ua && U.cmd && !roles(CHAT)[to]) r = { r: 't', own: ua };
}
else r = length(CHAT) ? roles(CHAT)[to] : null;
if (!length(TOKEN) || !r || r.r == 'a' || (to != CHAT && r.own == 'admin') || (r.own != 'admin' && pstate(r.own) != 'ok') || type(F) != 'object' || !match('' + (F.id ?? ''), /^[A-Za-z0-9_-]{10,255}$/)) exit(1);
CHAT = to; ROLE = r.r; OWN = r.own;
savefile(F);
exit(0);
}

for (let n in (lsdir(KD) ?? [])) {
let p = KD + '/' + n, s = match(n, /^[0-9a-f]+$/) ? lstat(p) : null;
if (s?.type == 'file' && time() - (s.mtime ?? 0) > 60) unlink(p);
}
let last = '', offn = 0;
mkdir('/tmp/wf-batt');
while (true) {
writefile('/tmp/wf-batt/tgbot', '' + time());	/* battito: il giro è vivo (prova di fumo, Custode) */
let K = cfg();
TOKEN = K.token; CHAT = K.chat; EN = K.en; ROLE = 't'; OWN = 'admin';
people();
if (!length(TOKEN) || !length(CHAT) || (K.cmd != '1' && !pneed())) {
if (++offn >= 2) sh('ubus -t 10 call service delete \'{"name":"wrtfreedom","instance":"tgbot"}\' >/dev/null 2>&1');
sh('sleep 30'); last = ''; MSIG = {}; continue;
}
offn = 0;
if (last != TOKEN + EN || stat(MENU)) { unlink(MENU); setmenu(); last = TOKEN + EN; MSIG = {}; }
pmenu();
let off = +(trim(readfile(OFF) ?? '0')) || 0;
let r = api('getUpdates', { timeout: 50, offset: off, allowed_updates: ['message', 'callback_query'] }, 65);
if (!r || !r.ok) { sh('sleep 15'); continue; }
if (writefile('/tmp/wf-tg.ok.t', '' + time()) != null) rename('/tmp/wf-tg.ok.t', '/tmp/wf-tg.ok');
people();
for (let u in r.result) {
writefile(OFF, '' + (u.update_id + 1));
try {
let m = u.message ?? u.callback_query?.message, id = m ? '' + m.chat.id : '', x = K.roles[id], rl = x?.r;
let sm = u.message ? match(trim(u.message.text ?? ''), /^\/start(@[A-Za-z0-9_]+)?[ ]+([A-Za-z0-9_-]{1,64})$/) : null;
if (sm && (x || length(PCHAT[id] ?? '')) && !length(filter(keys(PERS), (k) => length(PERS[k].code) && PERS[k].code == sm[2]))) sm = null;
if (m && !x) pupdate(u, m, sm);
else if (m && sm) { CHAT = id; ulink(m, sm[2]); }
else if (m && K.cmd != '1') { if (u.callback_query) api('answerCallbackQuery', { callback_query_id: u.callback_query.id }); }
else if (m) {
CHAT = id; ROLE = rl; OWN = x.own;
if (rl == 'a') { if (u.message && substr(trim(u.message.text ?? ''), 0, 1) == '/') say(bh(L('Qui arrivano solo gli avvisi', 'This chat only gets alerts'), true)); }
else if (u.message) onmessage(u.message);
else oncallback(u.callback_query);
}
}
catch (e) { warn('tgbot: ' + e + '\n'); }
CHAT = K.chat; ROLE = 't'; OWN = 'admin';
}
}
