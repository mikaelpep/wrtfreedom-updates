'use strict';
import { readfile, writefile, popen, stat, unlink, rename, mkdir, rmdir } from 'fs';

const W = '/usr/share/wrtfreedom', P = '/tmp/wf-sigfast', AT = W + '/at.sh', MAXT = 300, IDLE = 15;
const M = loadfile(getenv('WF_MODEMUC') ?? W + '/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function up() { return int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0])); }
function num(x) { if (x == null || x === '' || x === '--') return null; let n = +x; return n != n ? null : n; }
function at(c) { return sh('sh ' + AT + ' ' + q(c) + ' 2>/dev/null'); }
function cell(c) { return c ? { rsrp: num(c.rsrp), rsrq: num(c.rsrq), sinr: num(c.sinr), pci: c.pci ?? '', band: c.band ?? '' } : null; }

let me = split(trim(readfile('/proc/self/stat') ?? ''), ' ')[0];
if (!mkdir(P + '.lock')) {
let op = trim(readfile(P + '.pid') ?? '');
if (length(op) && index(readfile('/proc/' + op + '/cmdline') ?? '', 'sigfast') >= 0) exit(0);
rmdir(P + '.lock');
if (!mkdir(P + '.lock')) exit(0);
}
writefile(P + '.pid', me);
function bye(c) { unlink(P + '.pid'); rmdir(P + '.lock'); exit(c); }

let I = M.id(), D = M.drv(I), via = '';
if (D && D.ant && length(D.read ?? [])) via = 'at';
else if (I.mm) via = 'mm';
else if (D && length(D.read ?? [])) via = 'at';
let u0 = up(), t0 = time();
let S = { on: true, t: t0, start: t0, end: t0 + MAXT, via: via, tech: '', lte: null, nr: null, h: [], best: {} };
if (!length(via)) { S.on = false; S.err = 'modem non disponibile'; writefile(P + '.json', sprintf('%J', S)); bye(0); }
let mi = M.mmidx() || 'any';
if (via == 'mm') sh('mmcli -m ' + mi + ' --signal-setup=2 >/dev/null 2>&1');

while (true) {
let u = up(), w = +(trim(readfile(P + '.want') ?? '0'));
if (u - w > IDLE || u - u0 >= MAXT) break;
let n = { at: [] };
if (via == 'at') {
let o = D.ant ? sh('sh ' + AT + ' ' + q(D.read[0]) + ' ' + q(D.ant) + ' 2>/dev/null') : at(D.read[0]);
n = D.parse(o) ?? { nb: [] };
if (D.ant) S.ant = D.antparse(o);
} else {
let o = sh('mmcli -m ' + mi + ' --signal-get -J 2>/dev/null');
if (!length(o) && mi != 'any') { mi = 'any'; o = sh('mmcli -m any --signal-get -J 2>/dev/null'); }
let sg = null; try { sg = json(o)?.modem?.signal; } catch (e) {}
if (sg?.lte && num(sg.lte.rsrp) != null) n.lte = { rsrp: sg.lte.rsrp, rsrq: sg.lte.rsrq, sinr: sg.lte.snr };
if (sg?.['5g'] && num(sg['5g'].rsrp) != null) n.nr = { rsrp: sg['5g'].rsrp, rsrq: sg['5g'].rsrq, sinr: sg['5g'].snr };
}
let now = time();
S.t = now; S.tech = M.tech(n); S.lte = cell(n.lte); S.nr = cell(n.nr);
for (let k in [ 'lte', 'nr' ]) {
let c = S[k], b = S.best[k];
if (c?.rsrp != null && (!b || c.rsrp > b.rsrp || (c.rsrp == b.rsrp && (c.sinr ?? -99) > (b.sinr ?? -99)))) S.best[k] = { rsrp: c.rsrp, sinr: c.sinr, t: now };
}
push(S.h, [ now, S.lte?.rsrp, S.lte?.sinr, S.nr?.rsrp, S.nr?.sinr ]);
if (length(S.h) > 300) S.h = slice(S.h, length(S.h) - 300);
writefile(P + '.json.t', sprintf('%J', S)); rename(P + '.json.t', P + '.json');
sleep(via == 'mm' ? 2000 : 1000);
}
S.on = false; S.t = time();
writefile(P + '.json.t', sprintf('%J', S)); rename(P + '.json.t', P + '.json');
if (via == 'mm') sh('mmcli -m ' + mi + ' --signal-setup=10 >/dev/null 2>&1');
bye(0);
