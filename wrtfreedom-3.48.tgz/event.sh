#!/bin/sh
S="$1"
case "$S" in
iface) [ "$INTERFACE" != loopback ] && case "$INTERFACE" in wgout|wgo[0-9]|wgo[0-9][0-9]) false;; *) true;; esac && {	# wgout, wgo1…: gli avvisi del Client VPN li dà vpnctl.uc
[ "$ACTION" = ifup ] || [ "$ACTION" = ifdown ] || { [ "$ACTION" = ifupdate ] && [ "$IFUPDATE_ADDRESSES" = 1 ]; }; } || exit 0 ;;
dhcp) exit 0 ;;	# vecchio aggancio (fino alla 2.41): i dispositivi ora li segue notify.sh (evento «dev»)
usb) [ "$DEVTYPE" = usb_device ] && { [ "$ACTION" = add ] || [ "$ACTION" = remove ]; } || exit 0 ;;
block) case "$DEVNAME" in sd*[0-9]|sd[a-z]|sd[a-z][a-z]|mmcblk*p[0-9]*|nvme*p[0-9]*) ;; *) exit 0;; esac
[ "$ACTION" = add ] || [ "$ACTION" = remove ] || exit 0
case "$DEVNAME" in sd[a-z]|sd[a-z][a-z])
if [ "$ACTION" = add ]; then block info "/dev/$DEVNAME" 2>/dev/null | grep -q ' TYPE="' && : > "/tmp/wf-blkw.$DEVNAME" || exit 0
else [ -f "/tmp/wf-blkw.$DEVNAME" ] || exit 0; rm -f "/tmp/wf-blkw.$DEVNAME"; fi ;;
esac ;;
button) [ -n "$BUTTON" ] && { [ "$ACTION" = pressed ] || [ "$ACTION" = released ]; } || exit 0 ;;
ntp) [ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ] || exit 0 ;;
esac
[ "$S" = iface ] && [ "$ACTION" = ifupdate ] && { sh /usr/share/wrtfreedom/cron.sh ddnswd if "$INTERFACE" >/dev/null 2>&1; exit 0; }
ddif() { [ -x /etc/init.d/ddns ] && [ -r /etc/config/ddns ] || return 1; dt_=; de_=; df_=; dd0_=
ddd() { [ -n "$dd0_" ] || { [ -f /usr/share/wrtfreedom/lib.sh ] && . /usr/share/wrtfreedom/lib.sh && dd0_=$(wf_dddef); }
df_=$dd0_; [ -n "$df_" ]; }
ddok() { [ "$dt_" = service ] && [ "$de_" = 1 ] && { [ -n "$df_" ] || ddd; } && [ "$df_" = "$INTERFACE" ]; }
while read -r dk_ dn_ dv_; do
dn_=${dn_#[\"\']}; dn_=${dn_%[\"\']}; dv_=${dv_#[\"\']}; dv_=${dv_%[\"\']}
case "$dk_" in
config) ddok && return 0; dt_=$dn_; de_=; df_= ;;
option) case "$dn_" in enabled) de_=$dv_ ;; interface) df_=$dv_ ;; esac ;;
esac
done < /etc/config/ddns
ddok; }
DDI=; [ "$S" = iface ] && [ "$ACTION" = ifup ] && ddif && { DDI=1; ( sleep 5; sh /usr/share/wrtfreedom/cron.sh ddnswd if "$INTERFACE" up ) </dev/null >/dev/null 2>&1 & }
now=$(date +%s)
. /lib/functions.sh; config_load wrtfreedom
config_get NC ev notify; config_get L ui lang; config_get AO ai on; config_get AW ai why
config_get ETG ev tg
LOG=/tmp/wf-events.log
mkdir -p /etc/wrtfreedom
EN=0; [ "$L" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
tq() { [ -d /tmp/wf-tgq ] || mkdir -p /tmp/wf-tgq; t=$(mktemp /tmp/wf-tgq/.tXXXXXX) || return; f="/tmp/wf-tgq/${now:-$(date +%s)}-$$${t##*/.t}"; { [ -n "$KB" ] && printf '#kb:%s\n' "$KB"; [ -n "$2" ] && printf '#c:%s\n' "$2"; [ -n "$3" ] && printf '#own:%s\n' "$3"; [ -n "$4" ] && printf '#nu:%s\n' "$4"; [ -n "$3" ] && [ -n "$5" ] && printf '#ty:%s\n' "$5"; [ -n "$3" ] && [ "$6" = 1 ] && printf '#so:1\n'; printf '%s' "$1"; } > "$t" && mv "$t" "$f"; ( ucode /usr/share/wrtfreedom/tgq.uc flush ) </dev/null >/dev/null 2>&1 & }
lcount() { n_=; read -r n_ < "$1" 2>/dev/null; case "$n_" in ''|*[!0-9]*) n_=$2;; esac; n_=$((n_ + 1)); if [ $n_ -ge $2 ]; then echo 0 > "$1"; return 0; fi; echo $n_ > "$1"; return 1; }
nasurg() { case "$1" in cron_nas_failing|cron_nas_unsafe|cron_nas_ntfsno|cron_nas_full|cron_nas_user_new) return 0 ;; esac; return 1; }
OWN=
ownset() { OWN=; case "$1" in ''|admin) return ;; all) OWN=all; return ;; esac
case "$1" in [a-z]*) ;; *) return ;; esac
case "$1" in *[!a-z0-9]*) return ;; esac
[ ${#1} -le 20 ] && OWN=$1; }
log() { # tipo|categoria|testo
so_=; case "$1" in *_ok|*_done) sk_=1 ;; *) sk_=$WF_SOLO ;; esac
[ "$sk_" = 1 ] && [ -n "$OWN" ] && [ "$OWN" != all ] && [ "$1" != cron_nas_user_new ] && [ "$1" != cron_nas_user_locked ] && so_=1
if [ -n "$so_" ]; then echo "$now|$1|$2#so:$OWN|$3" >> "$LOG"; else echo "$now|$1|$2|$3" >> "$LOG"; fi
lcount /tmp/wf-events.cnt 25 && { n=$(wc -l < "$LOG"); [ "$n" -gt 550 ] && { tail -n 500 "$LOG" > "$LOG.t" && mv "$LOG.t" "$LOG"; }; }
[ -n "$OWN" ] && { echo "$now|$1|$OWN|$3" >> /tmp/wf-evown
lcount /tmp/wf-evown.cnt 15 && { n=$(wc -l < /tmp/wf-evown); [ "$n" -gt 550 ] && { tail -n 500 /tmp/wf-evown > /tmp/wf-evown.t && mv /tmp/wf-evown.t /tmp/wf-evown; }; }; }
if [ "$WF_Q" = 1 ]; then
echo "$now|$1|$3" >> /tmp/wf-evq
lcount /tmp/wf-evq.cnt 15 && { n=$(wc -l < /tmp/wf-evq); [ "$n" -gt 330 ] && { tail -n 300 /tmp/wf-evq > /tmp/wf-evq.t && mv /tmp/wf-evq.t /tmp/wf-evq; }; }
else
lc_=$2; [ "$2" = nas ] && nasurg "$1" && lc_='nas!'
to_=$OWN; nu_=; [ "$1" = cron_nas_user_new ] && { [ "$OWN" = all ] || nu_=$OWN; to_=; }
[ "$1" = cron_nas_user_locked ] && to_=
[ "$WF_NOTG" = 1 ] || [ "$ETG" = 0 ] || case " $NC " in *" $2 "*|*" $lc_ "*) tq "$3" "$lc_" "$to_" "$nu_" "$1" "$so_" ;; *) [ "$WF_TG" = 1 ] && tq "$3" "$lc_" "$to_" "$nu_" "$1" "$so_" ;; esac
fi
[ -n "$so_" ] && return 0
[ "$WF_NORULES" = 1 ] || rules "$1"
[ "$WF_NOTG" = 1 ] || [ "$WF_Q" = 1 ] || aiwhy "$1"
}
qlog() { q_=$WF_Q; WF_Q=1; log "$@"; WF_Q=$q_; }
wantmark() { mkdir -p /tmp/wf-want; for w_ in "$@"; do date +%s > "/tmp/wf-want/$w_"; done; }
uptm() { u_=$(cut -d. -f1 /proc/uptime 2>/dev/null); echo "${u_:-999}"; }
aiwhy() {
[ "$AO" = 1 ] && [ "$AW" = 1 ] || return 0
case "$1" in
cron_health_*_ok|cron_health_err) return 0 ;;	# health_err: rpcd fermo, l'IA non avrebbe i dati
wan_down|lan_down|vpn_down|cron_net_down|cron_fo_backup|cron_fo_none|cron_signal|cron_vpn_fail|cron_ddns_fail|cron_cert_fail|cron_space|cron_temp|cron_adg_down|cron_usage_full|cron_usage_slowerr|cron_sim|cron_simerr|cron_vpnsvc_down|cron_vpnacc|cron_wifi_radar|cron_dev_nft|cron_fw_attack|cron_sqm_lag|cron_backup_fail|cron_nas_backup_err|cron_nas_dl_err|cron_nas_dl_sim|cron_nas_dl_space|cron_nas_failing|cron_nas_full|cron_nas_ntfsno|cron_health_*|wd_modem|wd_reboot|wd_reconnect) ;;
*) return 0 ;;
esac
wl_=$(date -r /tmp/wf-ai/why.lock +%s 2>/dev/null) && [ $((now - wl_)) -le 120 ] && return 0
aisvcq "$1" && return 0
( ucode /usr/share/wrtfreedom/ai.uc why "$now" "$1" ) </dev/null >/dev/null 2>&1 &
}
aisvcq() {
read -r qp_ < /tmp/wf-ai/svc.pid 2>/dev/null && [ -n "${qp_##*[!0-9]*}" ] || return 1
qs_=$(date -r /tmp/wf-ai/svc.pid +%s 2>/dev/null) && [ $((now - qs_)) -le 120 ] && [ ! -e /tmp/wf-ai/svc.rest ] || return 1
case "$(tr '\0' ' ' < "/proc/$qp_/cmdline" 2>/dev/null)" in *ai.uc*serve*) ;; *) return 1 ;; esac
ql_=$(date -r /tmp/wf-ai/lock +%s 2>/dev/null) && [ $((now - ql_)) -le 150 ] && return 1
if qm_=$(date -r /tmp/wf-ai/min.json +%s 2>/dev/null) && [ $((now - qm_)) -lt 60 ]; then
for qt_ in $(jsonfilter -i /tmp/wf-ai/min.json -e '@[*].t' 2>/dev/null); do
qt_=${qt_%%.*}; case "$qt_" in ''|*[!0-9]*) continue ;; esac
[ $((now - qt_)) -lt 60 ] && return 1
done
fi
qi_=$(cut -c1-8 /proc/sys/kernel/random/uuid 2>/dev/null)
case "$qi_" in *[!0-9a-f]*|"") return 1 ;; esac
[ ${#qi_} -eq 8 ] && mkdir -m 700 /tmp/wf-ai/svc.run 2>/dev/null || return 1
printf '{"k":"why","id":"%s","bg":true,"t":%s,"e":"%s"}\n' "$qi_" "$now" "$1" > /tmp/wf-ai/svc.run/job.t &&
mv /tmp/wf-ai/svc.run/job.t /tmp/wf-ai/svc.run/job || { rm -rf /tmp/wf-ai/svc.run; return 1; }
ubus send wrtfreedom.ai '{"k":"why"}' </dev/null >/dev/null 2>&1
return 0
}
wanifs0() { for z in $(uci -q show firewall | sed -nE "s/^firewall\.([^.]*)\.masq='(1|true)'$/\1/p"); do [ "$(uci -q get firewall.$z.name)" = vpnout ] || uci -q get "firewall.$z.network"; done; }	# zona internet vera (con il NAT, mai il nome «wan» fisso)
wgif0() { wl_=$(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); for i in $wl_; do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; echo "$wl_" | head -n 1; }	# Server VPN: con la porta in ascolto, senza il Client VPN (come wgiface)
evif() {
ek_=
[ -e /tmp/.uci/firewall ] || [ -e /tmp/.uci/network ] || { ek_="$(ls -lin /etc/config/firewall /etc/config/network 2>/dev/null) $(date -r /etc/config/firewall +%s 2>/dev/null) $(date -r /etc/config/network +%s 2>/dev/null)"; set -- $ek_; ek_="$*"; }
if [ -n "$ek_" ] && [ -f /tmp/wf-evif ]; then
ec_=; EWG=; EWI=
{ IFS= read -r ec_; IFS= read -r EWG; while IFS= read -r el_; do EWI="$EWI${EWI:+
}$el_"; done; } < /tmp/wf-evif
[ "$ec_" = "$ek_" ] && return 0
fi
EWI=$(wanifs0); EWG=$(wgif0)
[ -n "$ek_" ] && printf '%s\n%s\n%s\n' "$ek_" "$EWG" "$EWI" > /tmp/wf-evif.$$ && mv -f /tmp/wf-evif.$$ /tmp/wf-evif
return 0
}
wanifs() { evif; [ -z "$EWI" ] || echo "$EWI"; }
wgif() { evif; echo "$EWG"; }
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
wgbakset() {
B_=${WF_BAKDIR:-/etc/wrtfreedom/bak}/wg
[ -f "$B_/id" ] || return 0
if [ -f "$B_/off" ]; then rm -rf "$B_"; echo "ok $(date +%s)" > /tmp/wf-bak-wg.done; return 0; fi
for f_ in "$B_"/network.*.uci; do
[ -f "$f_" ] && grep -q "^set network\.$1\." "$f_" || continue
grep -v "^set network\.$1\.disabled=" "$f_" > "$f_.t"
[ "$2" = 1 ] || echo "set network.$1.disabled='1'" >> "$f_.t"
mv "$f_.t" "$f_"
done
[ -f "$B_/back.sh" ] && sed -i 's/: wgup;.*: wgupend; //' "$B_/back.sh"
}
alog() { ( KB=; OWN=; WF_NORULES=1; now=$(date +%s); [ "$3" = tg ] && WF_NOTG=1; log rule sys "$1" ); }
actl() { act "$1" "$2" || alog "⚠️ $(t "Regole ¦ Azione non riuscita" "Rules ¦ Action failed") ¦ $3" "$1"; }
act() { # esegue un'azione, esce con l'esito (0 = riuscita)
case "$1" in
modem_restart) ucode /usr/share/wrtfreedom/modemctl.uc restart >/dev/null 2>&1 ;;
wan_reconnect) for i in $(wanifs); do wantmark "$i"; ifdown "$i"; sleep 3; wantmark "$i"; ifup "$i"; done ;;
vpn_restart) i=$(wgif); [ -n "$i" ] && { wantmark "$i"; ifup "$i"; } ;;
vpn_on) i=$(wgif); [ -n "$i" ] && { wgbakset "$i" 1; uci set network.$i.disabled=0; uci commit network; wantmark "$i"; ifup "$i"; } ;;
vpn_off) i=$(wgif); [ -n "$i" ] && { wgbakset "$i" 0; uci set network.$i.disabled=1; uci commit network; wantmark "$i"; ifdown "$i"; } ;;
wifi_on) wifi up ;;
wifi_off) wifi down ;;
wifi_toggle) if ubus call network.wireless status 2>/dev/null | grep -q '"up": true'; then wifi down; else wifi up; fi ;;
mount) block mount ;;
tg) tq "$2" ;;
cmd) sh -c "$2" >/dev/null 2>&1 ;;
sqm_on) sh /usr/share/wrtfreedom/sqmctl.sh on >/dev/null 2>&1 ;;	# SQM (2.53)
sqm_off) sh /usr/share/wrtfreedom/sqmctl.sh off >/dev/null 2>&1 ;;
esac
}
rule1() { # una regola "Quando … Allora …": $1 = sezione, $2 = evento
local r=$1 e=$2 on ev a x d lb rm rp pm
config_get on $r enabled; [ "$on" = 0 ] && return
config_get ev $r event; [ "$ev" = "$e" ] || return
case "$e" in dev_join|dev_leave)
config_get rm $r mac; config_get rp $r person; pm=; [ -n "$rp" ] && config_get pm "$rp" mac
[ -n "$rm$rp" ] && { [ -n "$EM" ] || return; case " $rm $pm " in *" $EM "*) ;; *) return ;; esac; } ;;
esac
config_get a $r action; config_get x $r arg; config_get d $r delay 0; config_get lb $r label
if [ "$d" -gt 0 ]; then
( sleep "$d"; case "$e" in
wan_down) for i in $(wanifs); do isup "$i" && exit 0; done ;;
cron_vpnsvc_down) grep -q '"down": *true' /tmp/wf-vpn.json 2>/dev/null || exit 0 ;;
cron_net_down) [ "$(jsonfilter -i /tmp/wf-line.json -e '@.ok' 2>/dev/null)" = true ] && exit 0 ;;
vpn_down) i=$(wgif); [ -n "$i" ] && isup "$i" && exit 0 ;;
if_*_down) i=${e#if_}; isup "${i%_down}" && exit 0 ;;
if_*_up) i=${e#if_}; isup "${i%_up}" || exit 0 ;;
esac
alog "⚙️ $(t "Regole ¦ Azione automatica" "Rules ¦ Automatic action") ¦ $lb" "$a"; actl "$a" "$x" "$lb" ) >/dev/null 2>&1 &
else
alog "⚙️ $(t "Regole ¦ Azione automatica" "Rules ¦ Automatic action") ¦ $lb" "$a"; actl "$a" "$x" "$lb" &
fi
}
rules() { config_foreach rule1 rule "$1"; }	# regole per questo evento
case "$S" in
send)
act tg "$2" ;;
act)
act "$2" "$3" ;;
test)
echo "$now|rule|sys|⚙️ $(t "Regole ¦ Prova dell'azione" "Rules ¦ Action test") ¦ $2" >> "$LOG"; actl "$2" "$3" "$2" ;;
iface)
[ -p /tmp/wf-line.fifo ] && echo k 1<>/tmp/wf-line.fifo	# controllo della linea (line.sh): guarda subito, senza aspettare (fifo, 2.90)
MN=${INTERFACE%_[46]}; mn_=$(uci -q get "network.$MN.device"); case "$mn_" in @?*) MN=${mn_#@} ;; esac
evif; WI=$EWI
kind=casa; case " $WI " in *" $INTERFACE "*|*" $MN "*) kind=linea;; esac; [ "$INTERFACE" = "$EWG" ] && kind=vpn
case "$ACTION" in ifup) rules "if_${INTERFACE}_up";; ifdown) rules "if_${INTERFACE}_down";; esac
[ "$ACTION" = ifup ] && { config_get gd guest dl; config_get gu guest ul; [ -n "$gd$gu" ] && ucode /usr/share/wrtfreedom/wifi.uc glimit check >/dev/null 2>&1 & }
[ "$ACTION" = ifup ] && [ $kind != linea ] && [ -f /etc/wrtfreedom/adgmode/orig ] && sh /usr/share/wrtfreedom/adgmode.sh rebind >/dev/null 2>&1 &
[ $kind = vpn ] && { grep -qE '"p": *[1-9]' /tmp/wf-vpnwd.json 2>/dev/null || { grep -qE '"state": *"run"' /tmp/wf-vpnwdrun.json 2>/dev/null &&
[ $((now - $(date -r /tmp/wf-vpnwdrun.json +%s 2>/dev/null || echo 0))) -lt 120 ]; }; } && WF_Q=1
[ "$(uptm)" -lt 180 ] && WF_Q=1
[ -f /usr/share/wrtfreedom/lib.sh ] && . /usr/share/wrtfreedom/lib.sh
nm() { if command -v wf_ifname >/dev/null 2>&1; then wf_ifname "$1"; else case $kind in linea) t "Linea" "Line" ;; vpn) t "Server VPN" "VPN Server" ;; *) t "Rete" "Network" ;; esac; fi; }
config_get FOB fo backup; config_get FOM fo main
if [ $kind = linea ]; then
ms_=$(ifstatus "$MN" 2>/dev/null); KD=$(echo "$ms_" | jsonfilter -e '@.l3_device' 2>/dev/null)
[ -n "$KD" ] || KD=$(echo "$ms_" | jsonfilter -e '@.device' 2>/dev/null); [ -n "$KD" ] || KD=${DEVICE:-$MN}
LK=/tmp/wf-evl-$(printf '%s' "$KD" | tr -c 'A-Za-z0-9_.-' _)
NM=$(nm "$MN")
lj() { jsonfilter -i /tmp/wf-line.json -e "@.$1" 2>/dev/null; }
LLI=$(lj li); LDV=$(lj dev)
BK=0; [ -n "$FOB" ] && [ "$FOB" != "$FOM" ] && { [ "$FOB" = "$INTERFACE" ] || [ "$FOB" = "$MN" ]; } && BK=1
if [ -n "$LLI" ] && { [ "$LLI" = "$MN" ] || [ "$LLI" = "$INTERFACE" ]; }; then WF_Q=1
elif [ -n "$LDV" ] && [ "$LDV" = "$KD" ]; then WF_Q=1
elif [ $BK = 1 ]; then [ "$(lj active)" = backup ] && WF_Q=1
elif [ -z "$LLI" ]; then WF_Q=1; fi
else
LK=/tmp/wf-evl-if-$(printf '%s' "$INTERFACE" | tr -c 'A-Za-z0-9_.-' _)
NM=$(nm "$INTERFACE")
fi
wantleft() {
WR=0
for w_ in "$INTERFACE" "$MN" _all; do
wt_=$(cat "/tmp/wf-want/$w_" 2>/dev/null); case "$wt_" in ''|*[!0-9]*) continue ;; esac
r_=$((wt_ + 60 - $(date +%s))); [ $r_ -gt 60 ] && r_=60; [ $r_ -gt $WR ] && WR=$r_
done
[ $WR -gt 0 ]
}
Q0=$WF_Q; WA=0; wantleft && { WA=1; WF_Q=1; }
downlater() { # $1 = tipo, $2 = testo
[ $WA = 1 ] && [ "$Q0" != 1 ] || return 0
( while wantleft; do sleep "$WR"; done
isup "$INTERFACE" && exit 0
for i in "$INTERFACE" "$MN"; do
case "$(uci -q get "network.$i.disabled")" in 1|on|true|yes|enabled) exit 0 ;; esac
case "$(uci -q get "network.$i.auto")" in 0|false|no|off) exit 0 ;; esac
done
[ -f "/tmp/wf-ifdown.$INTERFACE" ] && exit 0
[ "$(ifstatus "$INTERFACE" 2>/dev/null | jsonfilter -e '@.autostart' 2>/dev/null)" = false ] && exit 0
now=$(date +%s); WF_Q=; WF_NORULES=1; log "$1" net "$2" ) </dev/null >/dev/null 2>&1 &
}
v4up() {
for i in $WI $MN; do for j in "$i" "${i}_4"; do
[ "$j" = "$INTERFACE" ] && continue
s_=$(ifstatus "$j" 2>/dev/null) || continue
[ "$(echo "$s_" | jsonfilter -e '@.up' 2>/dev/null)" = true ] || continue
a_=$(echo "$s_" | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null); [ -n "$a_" ] || continue
[ "$j" = "$MN" ] || [ "$j" = "${MN}_4" ] || [ "$(echo "$s_" | jsonfilter -e '@.l3_device' 2>/dev/null)" = "$KD" ] || continue
echo "$a_"; return 0
done; done; return 1
}
lfirst() {
exec 9>"$LK.lk"; flock 9 2>/dev/null; lfirst_; lr_=$?; exec 9>&-; return $lr_
}
lfirst_() {
lf_=$LK; lo_=$(cat "$lf_" 2>/dev/null)
lt_=${lo_%% *}; case "$lt_" in ''|*[!0-9]*) lt_=0;; esac; la_=${lo_#* }; [ $((now - lt_)) -lt 20 ] || la_=
if [ "$ACTION" = ifdown ]; then
[ $kind = linea ] && v4up >/dev/null && return 1
echo "$now ifdown" > "$lf_"; [ "$la_" = ifdown ] && return 1; return 0
fi
case "$la_" in
ifup) return 1 ;;
"ifup noip") [ -n "$ip" ] || return 1 ;;
esac
if [ -n "$ip" ]; then echo "$now ifup" > "$lf_"; else echo "$now ifup noip" > "$lf_"; fi; return 0
}
case "$ACTION" in
ifup)
ip=$(ifstatus "$INTERFACE" 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null)
[ $kind = linea ] && [ -z "$ip" ] && ip=$(v4up)
[ $kind = linea ] && [ -z "$DDI" ] && ( sleep 5; ucode /usr/share/wrtfreedom/svc.uc ip ) </dev/null >/dev/null 2>&1 &
lfirst || exit 0
[ $kind = linea ] && [ -z "$ip" ] && { ( sleep 6; lo_=$(cat "$LK" 2>/dev/null); [ "$lo_" = "$now ifup noip" ] || exit 0
now=$(date +%s); log wan_up net "🌐 $NM ¦ $(t "Tornata" "Back")" ) </dev/null >/dev/null 2>&1 & exit 0; }
case $kind in linea) log wan_up net "🌐 $NM ¦ $(t "Tornata" "Back")${ip:+ ¦ IP $ip}";; vpn) log vpn_up net "🔐 $NM ¦ $(t "Acceso" "On")";; *) log lan_up net "📶 $NM ¦ $(t "Accesa" "On")";; esac ;;
ifdown)
lfirst || exit 0
case $kind in
linea) TX="🌐 $NM ¦ $(t "Caduta" "Down")"; log wan_down net "$TX"; downlater wan_down "$TX" ;;
vpn) TX="🔐 $NM ¦ $(t "Spento o caduto" "Off or down")"; log vpn_down net "$TX"; downlater vpn_down "$TX" ;;
*) TX="📶 $NM ¦ $(t "Spenta" "Off")"; log lan_down net "$TX"; downlater lan_down "$TX" ;;
esac ;;
esac ;;
dev)	# da notify.sh: $2 = join o leave, $3 = MAC, $4 = come è collegato (Wi-Fi 5 GHz, cavo)
rep() { R_=; r_=$1; while :; do case "$r_" in *"$2"*) R_=$R_${r_%%"$2"*}$3; r_=${r_#*"$2"} ;; *) R_=$R_$r_; return ;; esac; done; }
m=$3; EM=$m; rep "$4" _ " "; w=$R_; [ $EN = 1 ] && { [ "$w" = cavo ] && w=cable; rep "$w" , .; w=$R_; }
dcfg() { s_=$(uci -q show dhcp 2>/dev/null | awk -v m="$m" -v q="'" '{ i = index($0, "="); k = substr($0, 1, i - 1); v = substr($0, i + 1)
				sub("^" q, "", v); sub(q "$", "", v); gsub(q "\\\\" q q, q, v); split(k, a, ".")
				if (a[3] == "" && v == "dnsmasq" && D == "") D = a[2]; if (a[3] == "leasefile") F[a[2]] = v
				if (a[3] == "mac" && S == "" && index(tolower(v), m)) S = a[2]; if (a[3] == "name") N[a[2]] = v; if (a[3] == "ip") I[a[2]] = v
				if (a[3] == "x3000_label") B[a[2]] = v }
			END { f = F[D]; if (f == "") f = F["@dnsmasq[0]"]; if (f == "") f = "/tmp/dhcp.leases"
				while ((getline l < f) > 0) { split(l, p, " "); if (tolower(p[2]) == m) { li = p[3]; ln = p[4]; break } }
				b = B[S]; gsub(/[|\n]/, " ", b); printf "%s|%s|%s|%s|%s|%s", f, li, ln, I[S], N[S], b }')
LF=${s_%%|*}; s_=${s_#*|}; LI=${s_%%|*}; s_=${s_#*|}; LN=${s_%%|*}; s_=${s_#*|}; SI=${s_%%|*}; s_=${s_#*|}; SN=${s_%%|*}; SL=${s_#*|}; }
dname() { ip=; h=
if [ -z "$LF" ]; then dcfg
else l=$(awk -v m="$m" 'tolower($2)==m{print $3" "$4; exit}' "$LF" 2>/dev/null); LI=${l%% *}; LN=${l#* }; fi
[ "$LN" = "*" ] && LN=
h=${SL:-${LN:-$SN}}; ip=${LI:-$SI}
[ -n "$ip" ] || ip=$(ip -4 neigh show 2>/dev/null | awk -v m="$m" 'tolower($5)==m{print $1; exit}')
}
dalt() {
case "$m" in ?[2367abefABEF]*) t "Indirizzo Privato" "Private Address"; printf ' %s' "${m#??:??:??:??:}"; return ;; esac
v=$(awk -F'|' -v m="$m" 'BEGIN { p = substr(m, 1, 8); gsub(/:/, "", p); p = toupper(p) } !/^#/ && index(" " $3 " ", " " p " ") {print $1; exit}' /usr/share/wrtfreedom/oui.txt 2>/dev/null)
if [ -n "$v" ]; then t "Dispositivo $v" "$v Device"; else printf '%s' "$m"; fi
}
dwait() { i=0; while [ -z "$h" ] && [ $i -lt 10 ]; do sleep 2; i=$((i + 1)); dname; done; h=${h:-$(dalt)}; }
ddet() { case "$w" in cavo|cable) DC=$(t "Collegato via cavo" "Connected by cable") ;; '') DC=$(t "Collegato" "Connected") ;; *) DC="$(t "Collegato al" "Connected to") $w" ;; esac
DD=; [ -n "$ip" ] && DD=" ¦ IP $ip"; }
dname
case "$2" in
join)
if grep -qsE "^$m( |\$)" /etc/wrtfreedom/seen /tmp/wf-seen.new /tmp/wf-seen.new.f; then dwait; ddet; log dev_join dev "📱 $h ¦ $DC$DD"
else echo "$m ?" >> /tmp/wf-seen.new
dwait; ddet; case "$w" in cavo|cable|'') w=$DC ;; esac; KB=$m; log dev_new new "📱 $h ¦ $(t "Nuovo dispositivo" "New device") ¦ $w${ip:+ · $ip}"; KB=
nd=; config_get nd vpnout newdev; [ "$nd" = 1 ] && ucode /usr/share/wrtfreedom/vpnctl.uc newdev "$m" "$ip" "$h" >/dev/null 2>&1 &
fi ;;
leave) h=${h:-$(dalt)}; log dev_leave dev "📱 $h ¦ $(t "Scollegato" "Disconnected")" ;;
esac ;;
usb)
uq=0; [ "$(uptm)" -lt 180 ] && uq=1
wt_=$(cat /tmp/wf-want/_usb 2>/dev/null); case "$wt_" in ''|*[!0-9]*) ;; *) [ $((now - wt_)) -lt 90 ] && uq=1 ;; esac
case "$TYPE" in 9/*) uq=1 ;; esac
[ "$(cat "/sys$DEVPATH/bDeviceClass" 2>/dev/null)" = 09 ] && uq=1
uk=$(printf '%s' "$DEVPATH" | tr -c 'A-Za-z0-9_.-' _); mk=/tmp/wf-usbms/$uk
nf=/tmp/wf-usbname/$uk
ulog() { if [ $uq = 1 ]; then qlog "$@"; else log "$@"; fi; }
case "$ACTION" in
add) un=$(cat "/sys$DEVPATH/manufacturer" "/sys$DEVPATH/product" 2>/dev/null | awk '{ gsub(/[^ -~]|[|]/, " ")
					gsub(/  +/, " "); sub(/^ /, ""); sub(/ $/, ""); if ($0 == "") next
					if (n != "" && index(tolower($0), tolower(n)) == 1) n = $0; else n = n (n != "" ? " " : "") $0 }
				END { print substr(n, 1, 60) }')
if [ -n "$un" ]; then mkdir -p /tmp/wf-usbname; printf '%s' "$un" > "$nf"; else rm -f "$nf"; fi
( sleep 2; grep -qx 08 "/sys$DEVPATH"/*/bInterfaceClass 2>/dev/null && { mkdir -p /tmp/wf-usbms; touch "$mk"; uq=1; }
ulog usb_add usb "🔌 ${un:-USB} ¦ $(t "Dispositivo USB collegato" "USB device connected")" ) </dev/null >/dev/null 2>&1 & ;;
remove) [ -f "$mk" ] && { rm -f "$mk"; uq=1; }
un=$(cat "$nf" 2>/dev/null); rm -f "$nf"
ulog usb_remove usb "🔌 ${un:-USB} ¦ $(t "Dispositivo USB tolto" "USB device removed")" ;;
esac ;;
block)
uq=0; [ "$(uptm)" -lt 180 ] && uq=1
case "$DEVNAME" in mmcblk*) [ "$(cat "/sys/class/block/${DEVNAME%p[0-9]*}/device/type" 2>/dev/null)" = MMC ] && uq=1 ;; esac
case "$ACTION" in add) TX="🔌 USB ¦ $(t "Chiavetta o disco inserito" "USB stick or drive inserted")"; TY=disk_add;; *) TX="🔌 USB ¦ $(t "Chiavetta o disco tolto" "USB stick or drive removed")"; TY=disk_remove;; esac
NASON=0; [ "$(jsonfilter -q -i /etc/wrtfreedom/nas.json -e '@.on' 2>/dev/null)" = true ] && NASON=1
if [ "$NASON" = 1 ]; then
nf=/tmp/wf-nas/name.$DEVNAME; nb=$DEVNAME
case "$nb" in nvme*|mmcblk*) nb=${nb%p[0-9]*} ;; *) nb=${nb%%[0-9]*} ;; esac
case "$ACTION" in
add)
nn=$(block info "/dev/$DEVNAME" 2>/dev/null | sed -n 's/.* LABEL="\([^"]*\)".*/\1/p' | tr -d '\000-\037\177|' | cut -c1-24)
[ -n "$nn" ] || nn=$DEVNAME; mkdir -p /tmp/wf-nas; printf '%s' "$nn" > "$nf"
TX="🗄️ $nn ¦ $(t "Collegato" "Connected")"
( sleep 3; ucode -e "loadfile('/usr/share/wrtfreedom/nas.uc')().watch()" ) </dev/null >/dev/null 2>&1 & ;;
*) nn=$(cat "$nf" 2>/dev/null); [ -n "$nn" ] || nn=$DEVNAME; rm -f "$nf"
if [ -e "/tmp/wf-nas/ejected/$nb" ]; then TX="🗄️ $nn ¦ $(t "Tolto in sicurezza" "Safely removed")"
elif grep -qs "\"base\": *\"$nb\"" /tmp/wf-nas/seen.json; then uq=1; TX="🗄️ $nn ¦ $(t "Staccato" "Unplugged")"
else TX="🗄️ $nn ¦ $(t "Tolto" "Removed")"; fi
[ -e "/tmp/wf-nas/ejected/$nb" ] || [ ! -f /usr/share/wrtfreedom/nasjob.sh ] || \
							( sleep 2; sh /usr/share/wrtfreedom/nasjob.sh ntfsopen ) </dev/null >/dev/null 2>&1 & ;;
esac
fi
if [ $uq = 1 ]; then qlog $TY usb "$TX"; else log $TY usb "$TX"; fi ;;
button)
bf=/tmp/wf-btn-$(printf '%s' "$BUTTON" | tr -c 'A-Za-z0-9_.-' _)
[ -f /usr/share/wrtfreedom/lib.sh ] && . /usr/share/wrtfreedom/lib.sh
if command -v wf_btnname >/dev/null 2>&1; then BN=$(wf_btnname "$BUTTON"); else BN=$(t "Tasto" "Button"); fi
case "$ACTION" in
pressed) echo "$now" > "$bf"; log "button_${BUTTON}_pressed" button "⚙️ $BN ¦ $(t "Premuto" "Pressed")" ;;
released) bt=$(cat "$bf" 2>/dev/null); rm -f "$bf"; case "$bt" in ''|*[!0-9]*) bt=0 ;; esac
TX="⚙️ $BN ¦ $(t "Rilasciato" "Released")"
if [ $((now - bt)) -lt 30 ]; then qlog "button_${BUTTON}_released" button "$TX"; else log "button_${BUTTON}_released" button "$TX"; fi ;;
esac ;;
boot)
TX="🩺 Router ¦ $(t "Acceso" "Powered on")"; qlog boot sys "$TX"
( sleep 180; [ -f /tmp/wf-bootsaid ] && exit 0; now=$(date +%s); WF_NORULES=1; log boot sys "$TX" ) </dev/null >/dev/null 2>&1 & ;;
upd)	# aggiornamenti dal server (upd.sh): $2 = pkg o app, $3 = testo già nella lingua scelta
log "upd_$2" sys "$3" ;;
wd)	# Ripristino Automatico (watchdog.sh): $2 = tipo di evento, $3 = testo già nella lingua scelta
log "wd_$2" net "$3" ;;
cron)	# Pianificazioni (cron.sh): $2 = tipo, $3 = categoria (net, sys, fw…), $4 = testo già nella lingua scelta
c_=${3:-sys}; case "$2" in cloud_*|nas_cloud_*|nas_cloudbk_*) c_=cloud ;; nas_*) c_=nas ;; esac
ownset "$5"; log "cron_$2" "$c_" "$4"; OWN= ;;
ntp)	# punto 8: «Orologio sincronizzato» solo negli Eventi (riga silenziosa)
[ "$ACTION" = stratum ] && [ ! -f /tmp/.wf-ntp ] && { touch /tmp/.wf-ntp; qlog ntp sys "⚙️ $(t "Orologio ¦ Sincronizzato" "Clock ¦ Synced")"; } ;;
esac
exit 0
