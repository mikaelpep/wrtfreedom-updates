#!/usr/bin/ucode
'use strict';
import { readfile, writefile, open, lstat, stat, lsdir, mkdir, rmdir, rename, readlink, popen, stdout, stdin, unlink } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', XJ = ETC + '/nasx.json', NJ = ETC + '/nas.json', KEYF = ETC + '/nasx.key', X = '/tmp/wf-nas/x';
const PARTS = ETC + '/nasx-parts';
const CDL = '/tmp/wf-cloud/dl';
const SH = R + '/usr/share/wrtfreedom/nasx.sh', EVSH = R + '/usr/share/wrtfreedom/event.sh';
const SIDLE = 1800, SMAX = 43200, CH = 65536, XCH = 4194304, CKMAX = 43200;
const PUTMAX = 4, TMPMIN = 25165824;

function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function rid() { return substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10) || ('' + time()); }
function wjs(f, o) { let t = f + '.c' + rid(); writefile(t, sprintf('%J', o)); rename(t, f); }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
function esc(s) { return replace(replace(replace(replace('' + s, '&', '&amp;'), '<', '&lt;'), '>', '&gt;'), '"', '&quot;'); }
function hexv(h) { h = lc(h); let v = 0; for (let i = 0; i < length(h); i++) { let c = ord(h, i); v = v * 16 + (c >= 97 ? c - 87 : c - 48); } return v; }
function urldec(s) { return replace(s, /%([0-9A-Fa-f][0-9A-Fa-f])/g, (m, h) => chr(hexv(h))); }
function urlenc(s) {
s = '' + s; let o = '';
for (let i = 0; i < length(s); i++) { let c = substr(s, i, 1); o += match(c, /^[A-Za-z0-9._~-]$/) ? c : sprintf('%%%02X', ord(s, i)); }
return o;
}
function bname(a) { return replace(a, /^.*\//, ''); }
function mkdirp(p) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c, (c == X || c == '/tmp/wf-nas') ? 448 : 511); } }
function append(f, s) { let o = open(f, 'a'); if (o) { o.write(s); o.close(); } }
function short(s) { s = '' + s; return length(s) > 24 ? substr(s, 0, 23) + '…' : s; }
function hk(s) {
let a = 2166136261, b = 5381;
for (let i = 0; i < length(s); i++) { let c = ord(s, i); a = ((a ^ c) * 16777619) & 0xffffffff; b = ((b * 33) ^ c) & 0xffffffff; }
return sprintf('%08x%08x', a, b);
}

const meth = getenv('REQUEST_METHOD') ?? 'GET', head = meth == 'HEAD', now = time();
const ip = lc(replace(getenv('REMOTE_ADDR') ?? '', /^::ffff:/, '')), https = match(lc(getenv('HTTPS') ?? ''), /^(on|1)$/) != null;
const RU = getenv('REQUEST_URI') ?? '', QS = getenv('QUERY_STRING') ?? (split(RU, '?')[1] ?? '');
const SN = getenv('SCRIPT_NAME') ?? '', BASE = match(SN, /\/wf-nasx$/) ? SN : '';
let uri = split(RU, '?')[0];
if (length(BASE) && substr(uri, 0, length(BASE)) == BASE) uri = substr(uri, length(BASE));
function qp(k) { for (let x in split(QS, '&')) { let i = index(x, '='); if ((i < 0 ? x : substr(x, 0, i)) == k) return i < 0 ? '' : urldec(replace(substr(x, i + 1), /\+/g, ' ')); } return null; }

const EN = index(lc(getenv('HTTP_ACCEPT_LANGUAGE') ?? ''), 'it') != 0;
function L(it, en) { return EN ? en : it; }
const REN = match(readfile((getenv('WF_CFGDIR') ?? '/etc/config/') + 'wrtfreedom') ?? '', /option[ \t]+lang[ \t]+'?en'?/) != null;
function TL(it, en) { return REN ? en : it; }
function ev(t, txt) { detach('sh ' + q(EVSH) + ' cron ' + t + ' nas ' + q(txt)); }
let UCF = null;
function ucf() {
if (UCF == null) {
try { UCF = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')(); } catch (e) { UCF = null; }
if (type(UCF) != 'object') UCF = {};
}
return UCF;
}
function pvis(own) {
if (own == null || own == '' || own == 'admin') return null;
let U = ucf(), p = null;
if (type(U.udir) == 'function') { try { p = U.udir(own, 'root'); } catch (e) { p = null; } }
return type(p) == 'string' && length(p) ? replace(p, /^.*\//, '') : '' + own;
}

function zone(a) {
let fz = getenv('WF_NZONE') ?? '';
if (length(R) && match(fz, /^(lan|vpn|guest|net)$/)) return fz;
if (!match(a, /^[0-9a-f:.]+$/)) return 'net';
let CD = getenv('WF_CFGDIR') ?? '/etc/config/', fp = '';
for (let f in [ 'network', 'firewall' ]) { let s = stat(CD + f); fp += s ? s.mtime + '.' + s.size + '.' + s.inode + ',' : '-,'; }
let cf = X + '/nz/' + replace(a, /[^0-9a-z.]/g, '_'), cs = stat(cf), c = cs && now - cs.mtime < 60 ? split(trim(readfile(cf) ?? ''), ' ') : null;
if (c && c[1] == fp && match(c[0], /^(lan|vpn|guest|net)$/)) return c[0];
let U = null, z = 'net';
try { U = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')(); } catch (e) { U = null; }
if (type(U?.ipzone) == 'function') { try { z = U.ipzone(a); } catch (e) { z = 'net'; } }
if (!match(z, /^(lan|vpn|guest|net)$/)) z = 'net';
mkdirp(X + '/nz'); writefile(cf, z + ' ' + fp);
return z;
}
const ZN = zone(ip), home = index([ 'lan', 'vpn' ], ZN) >= 0, loc = home;

function out(s) { stdout.write(s); }
function hdr(code, H) {
let t = { '200': 'OK', '201': 'Created', '207': 'Multi-Status', '204': 'No Content', '206': 'Partial Content', '301': 'Moved Permanently', '303': 'See Other', '400': 'Bad Request', '401': 'Unauthorized',
'403': 'Forbidden', '404': 'Not Found', '405': 'Method Not Allowed', '409': 'Conflict', '410': 'Gone', '413': 'Payload Too Large', '415': 'Unsupported Media Type', '416': 'Range Not Satisfiable',
'429': 'Too Many Requests', '503': 'Service Unavailable', '507': 'Insufficient Storage' };
let s = 'Status: ' + code + ' ' + (t['' + code] ?? '') + '\r\n';
for (let k, v in H) for (let x in (type(v) == 'array' ? v : [ v ])) s += k + ': ' + x + '\r\n';
out(s + 'X-Content-Type-Options: nosniff\r\nReferrer-Policy: no-referrer\r\nCache-Control: private, no-store\r\n\r\n');
}
let NAPI = false;
let HOK = null;
function hostok(h) {
h = lc('' + (h ?? ''));
let b = match(h, /^\[([0-9a-f:.]+)\](:[0-9]+)?$/);
if (b) return true;
h = replace(h, /:[0-9]+$/, '');
if (!length(h) || !match(h, /^[a-z0-9._-]+$/)) return false;
if (match(h, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) || index(h, '.') < 0) return true;
if (match(h, /\.(lan|home\.arpa|local|internal|home|localdomain)$/)) return true;
if (HOK == null) {
let CD = getenv('WF_CFGDIR') ?? '/etc/config/', dm = match(readfile(CD + 'dhcp') ?? '', /option[ \t]+domain[ \t]+'?([A-Za-z0-9.-]+)'?/);
HOK = { 'nas.home.arpa': true };
let nb = lc(substr(replace('' + ((rjs(NJ) ?? {}).adv?.name ?? ''), /[^A-Za-z0-9-]/g, '-'), 0, 15)), hn = lc(trim(readfile('/proc/sys/kernel/hostname') ?? ''));
if (!match(nb, /[a-z]/)) nb = 'nas';
for (let x in [ nb, hn ]) if (length(x)) { HOK[x] = true; if (dm) HOK[x + '.' + lc(dm[1])] = true; }
for (let l in split(readfile(CD + 'ddns') ?? '', '\n')) {
let m = match(l, /option[ \t]+(lookup_host|domain)[ \t]+'?([A-Za-z0-9.-]+)'?/);
if (m) HOK[lc(m[2])] = true;
}
}
return HOK[h] === true;
}
function appori(o) { return match(o, /^(capacitor|https?):\/\/localhost(:[0-9]+)?$/) != null; }
function oriok(o) {
if (o == null) return true;
if (appori(o)) return true;
let hh = getenv('HTTP_HOST') ?? '';
return replace(o, /^https?:\/\//, '') == hh && hostok(hh);
}
function cors() {
let o = getenv('HTTP_ORIGIN') ?? '';
if (NAPI && !appori(o) && !(replace(o, /^https?:\/\//, '') == (getenv('HTTP_HOST') ?? '') && hostok(getenv('HTTP_HOST')))) return {};
return match(o, /^(https?|capacitor):\/\/[]A-Za-z0-9.:[-]+$/) ? { 'Access-Control-Allow-Origin': o, Vary: 'Origin', 'Access-Control-Expose-Headers': 'Content-Range, Content-Length' } : {};
}
const CSS = 'body{font:16px system-ui,sans-serif;margin:0 auto;padding:16px;max-width:720px;color:#1c1c1e;background:#f2f2f7}h1{font-size:22px;margin:8px 0 16px}' +
'a{color:#2F4BB8;text-decoration:none}.c{background:#fff;border-radius:14px;padding:4px 16px;margin:12px 0}ul{padding:0;margin:0}' +
'li{list-style:none;padding:12px 0;border-bottom:1px solid #e5e5ea;display:flex;align-items:center;gap:12px}li:last-child{border:0}' +
'li a.n{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}li img{width:44px;height:44px;object-fit:cover;border-radius:8px}' +
'small,.m{color:#8e8e93}small{white-space:nowrap}.b{display:inline-block;background:#2F4BB8;color:#fff;border:0;border-radius:22px;padding:11px 20px;font:inherit;margin:6px 6px 6px 0;cursor:pointer}' +
'.b2{background:#e5e5ea;color:#1c1c1e}input{font:inherit;padding:11px 12px;border:1px solid #c7c7cc;border-radius:12px;width:100%;box-sizing:border-box;margin:8px 0}' +
'.e{color:#d70015}@media(prefers-color-scheme:dark){body{background:#000;color:#f2f2f7}.c{background:#1c1c1e}a{color:#7F9CF7}li{border-color:#2c2c2e}.b2{background:#2c2c2e;color:#f2f2f7}input{background:#1c1c1e;color:#f2f2f7;border-color:#3a3a3c}}';
function page(title, body, js) {
return '<!doctype html><html lang="' + L('it', 'en') + '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">' +
'<title>' + esc(title) + '</title><style>' + CSS + '</style></head><body><h1>' + esc(title) + '</h1>' + body + (js ? '<script>' + js + '</script>' : '') + '</body></html>';
}
function html(code, title, body, js, H) {
let b = page(title, body, js);
hdr(code, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': length(b),
'Content-Security-Policy': "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src 'self' data:; media-src 'self'; frame-ancestors 'none'", ...(H ?? {}) });
if (!head) out(b);
exit(0);
}
function fail(code, it, en, H) { html(code, L(it, en), '', null, H); }
let SLOT = null;
const ME = readlink('/proc/self') ?? ('' + now);
function slotfree() { if (SLOT && trim(readfile(SLOT + '/pid') ?? '') == ME) { unlink(SLOT + '/pid'); rmdir(SLOT); } SLOT = null; }
function jout(code, o, H) {
slotfree();
let b = sprintf('%J', o);
hdr(code, { 'Content-Type': 'application/json', 'Content-Length': length(b), ...cors(), ...(H ?? {}) });
out(b);
exit(0);
}
function jfail(code, it, en, x) { jout(code, { error: L(it, en), ...(x ?? {}) }); }

function badname(n) {
if (!length(n) || n == '.' || n == '..' || length(n) > 255 || substr(n, 0, 1) == '.') return true;
for (let i = 0; i < length(n); i++) { let c = ord(n, i); if (c < 32 || c == 127 || c == 47 || c == 92) return true; }
return false;
}
function ucut(s, n) {
if (length(s) <= n) return s;
while (n > 0 && (ord(s, n) & 0xc0) == 0x80) n--;
return substr(s, 0, n);
}
function cleanname(n) {
n = trim(replace(replace('' + n, /[[:cntrl:]\/\\:*?"<>|]/g, '_'), /^[. ]+/, ''));
if (length(n) > 200) { let m = match(n, /(\.[A-Za-z0-9]{1,8})$/); n = ucut(n, 200 - (m ? length(m[1]) : 0)) + (m ? m[1] : ''); }
return length(n) ? n : 'file';
}
function nolink(base, parts) {
let a = base;
for (let x in parts) { a += '/' + x; let s = lstat(a); if (!s || s.type == 'link') return null; }
return a;
}
function freename(dir, n) {
let L = {};
for (let e in (lsdir(dir) ?? [])) L[lc(e)] = true;
if (!L[lc(n)] && !lstat(dir + '/' + n)) return n;
let m = match(n, /^(.+)(\.[^.]+)$/), b = m ? m[1] : n, x = m ? m[2] : '';
for (let i = 2; i < 10000; i++) {
let sfx = ' (' + i + ')' + x, c = ucut(b, 255 - length(sfx)) + sfx;
if (!L[lc(c)] && !lstat(dir + '/' + c)) return c;
}
return null;
}
function touchm(f, mt) {
if (!(mt > 0)) return;
let t = localtime(mt);
sh('touch -c -t ' + sprintf('%04d%02d%02d%02d%02d.%02d', t.year, t.mon, t.mday, t.hour, t.min, t.sec) + ' ' + q(f) + ' 2>/dev/null');
}
function freeb(p) {
let l = split(trim(sh('df -kP ' + q(p) + ' 2>/dev/null')), '\n'), x = split(l[length(l) - 1] ?? '', /[ \t]+/);
return match(x[3] ?? '', /^[0-9]+$/) ? +x[3] * 1024 : 0;
}
function fsof(p) {
let best = '', t = '';
for (let l in split(readfile('/proc/mounts') ?? '', '\n')) {
let f = split(l, ' '), m = replace(f[1] ?? '', /\\040/g, ' ');
if (length(m) > length(best) && (p == m || substr(p, 0, length(m) + 1) == m + '/' || m == '/')) { best = m; t = f[2] ?? ''; }
}
return t;
}
function palive(p) { return match('' + p, /^[0-9]+$/) != null && stat('/proc/' + p) != null; }
function slotget(dir, max) {
mkdirp(dir);
for (let i = 0; i < max; i++) {
let a = dir + '/' + i;
if (!mkdir(a)) {
let s = stat(a), p = trim(readfile(a + '/pid') ?? '');
if (!s || s.type != 'directory' || (length(p) ? palive(p) : now - s.mtime < 10)) continue;
}
writefile(a + '/pid', ME); SLOT = a;
return true;
}
return false;
}
function uhmax() {
let m = match(readfile((getenv('WF_CFGDIR') ?? '/etc/config/') + 'uhttpd') ?? '', /option[ \t]+max_requests[ \t]+'?([0-9]+)'?/);
let n = (m ? +m[1] : 3) - 2;
return n < 1 ? 1 : n;
}
function uhslot() {
let D = X + '/uh', mx = uhmax(), old = null, ot = 0;
if (slotget(D, mx)) return;
for (let i = 0; i < mx; i++) { let s = stat(D + '/' + i + '/pid'); if (s && (!old || s.mtime < ot)) { old = D + '/' + i; ot = s.mtime; } }
old = old ?? D + '/0';
writefile(old + '/pid', ME); SLOT = old;
}
function mine() { return !SLOT || trim(readfile(SLOT + '/pid') ?? '') == ME; }
const MIME = { mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', mkv: 'video/x-matroska', webm: 'video/webm', avi: 'video/x-msvideo',
ts: 'video/mp2t', mts: 'video/mp2t', m2ts: 'video/mp2t', '3gp': 'video/3gpp', mpg: 'video/mpeg', mpeg: 'video/mpeg', wmv: 'video/x-ms-wmv',
mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', wav: 'audio/wav', ogg: 'audio/ogg', opus: 'audio/ogg', wma: 'audio/x-ms-wma',
jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', heic: 'image/heic', pdf: 'application/pdf', txt: 'text/plain; charset=utf-8' };
function mimeof(n) { let m = match(lc(n), /\.([a-z0-9]{1,5})$/); return (m ? MIME[m[1]] : null) ?? 'application/octet-stream'; }
function icon(n, d) {
if (d) return '📁';
let m = mimeof(n);
return match(m, /^video/) ? '🎬' : match(m, /^audio/) ? '🎵' : match(m, /^image/) ? '🖼️' : m == 'application/pdf' ? '📄' : '📎';
}
function hs(b) {
let u = [ 'B', 'KB', 'MB', 'GB', 'TB' ], i = 0;
while (b >= 1024 && i < 4) { b /= 1024; i++; }
return (i ? replace(sprintf('%.1f', b), '.', L(',', '.')) : '' + b) + ' ' + u[i];
}
function sha256(s) {
let d = null; try { d = require('digest'); } catch (e) { d = null; }
if (type(d?.sha256) == 'function') return d.sha256(s);
mkdirp(X);
let f = X + '/.c' + rid(), p = popen('sha256sum > ' + q(f), 'w');
if (!p) return '';
p.write(s); p.close();
let o = substr(readfile(f) ?? '', 0, 64);
unlink(f);
return o;
}
function readbody(n) {
let o = [], got = 0;
while (got < n) { let c = stdin.read(n - got > CH ? CH : n - got); if (c == null || !length(c)) break; push(o, c); got += length(c); }
return join('', o);
}
function cookie(k) {
for (let x in split(getenv('HTTP_COOKIE') ?? '', ';')) { x = trim(x); let i = index(x, '='); if (i > 0 && substr(x, 0, i) == k) return substr(x, i + 1); }
return null;
}
function disk(id) { for (let x in (rjs(X + '/disks.json')?.list ?? [])) if (x.id == id) return x; return null; }
function nasoff() { return (rjs(NJ) ?? {}).on === false; }
let NJC = null;
function ownoff(own) {
own = own ?? 'admin';
if (own == 'admin') return false;
NJC = NJC ?? (rjs(NJ) ?? {});
let x = type(NJC.users) == 'object' ? NJC.users[own] : null;
return type(x) != 'object' || x.cam === true || x.blocked === true;
}
function ownfull(own) { own = own ?? 'admin'; return own != 'admin' && index(split(readfile('/tmp/wf-nas/full.list') ?? '', '\n'), own) >= 0; }
function mainpause() { return stat('/tmp/wf-nas/mainpause.json') != null; }

function prange(size) {
let qr = qp('range'), rg = getenv('HTTP_RANGE') ?? (qr != null ? (substr(qr, 0, 6) == 'bytes=' ? qr : 'bytes=' + qr) : null);
let a = 0, z = size - 1, part = false;
if (rg != null) {
let r = match(rg, /^bytes=([0-9]*)-([0-9]*)$/);
if (r && (length(r[1]) || length(r[2]))) {
if (length(r[1])) { a = +r[1]; z = length(r[2]) ? +r[2] : size - 1; }
else { let n = +r[2]; a = n >= size ? 0 : size - n; z = size - 1; }
if (z >= size) z = size - 1;
if (a >= size || a > z) fail(416, 'Pezzo non valido', 'Invalid range', { 'Content-Range': 'bytes */' + size });
part = true;
}
}
return { a: a, z: z, part: part };
}
function serve(path, nm, attach, onfirst, H0, onend) {
let s = stat(path);
if (!s || s.type != 'file') fail(404, 'Non trovato', 'Not found');
let size = s.size, P = prange(size), a = P.a, z = P.z, part = P.part;
let n = size ? z - a + 1 : 0;
if (onfirst && !head) onfirst(n, a == 0);
let H = { 'Content-Type': mimeof(nm), 'Content-Length': n, 'Accept-Ranges': 'bytes',
'Content-Disposition': (attach ? 'attachment' : 'inline') + "; filename*=UTF-8''" + urlenc(nm), ...(H0 ?? {}) };
if (part) H['Content-Range'] = 'bytes ' + a + '-' + z + '/' + size;
hdr(part ? 206 : 200, H);
if (head) exit(0);
if (!n) { if (onend) onend(); exit(0); }
let f = open(path, 'r');
if (!f) exit(0);
if (length(BASE) && n > XCH) uhslot();
if (a > 0) f.seek(a);
let k = 0;
while (n > 0) {
if ((++k & 15) == 0 && !mine()) break;
let c = f.read(n > CH ? CH : n);
if (c == null || !length(c)) break;
if (stdout.write(c) == null) break;
n -= length(c);
}
f.close();
slotfree();
if (onend && n == 0 && z == size - 1) onend();
exit(0);
}

const CFL = '/tmp/wf-cloud/fl';
function crok(cr) {
if (type(cr) != 'object' || type(cr.r) != 'string' || type(cr.f) != 'string' || type(cr.s) != 'int' || cr.s < 0) return false;
let m = match(cr.r, /^(wf[a-z0-9]{1,40}):(.*)$/);
if (!m || match(cr.r, /[[:cntrl:]]/) || match('/' + m[2] + '/', /\/\.\.?\//)) return false;
if (cr.f === ETC + '/cloud-rclone.conf' && match(m[1], /^wfa[0-9]{1,2}$/)) {
let s0 = lstat(cr.f);
return s0 != null && s0.type == 'file' && index(split(readfile(cr.f) ?? '', '\n'), '[' + m[1] + ']') >= 0;
}
if (cr.f !== CFL + '/' + m[1] + '.conf') return false;
let s = lstat(cr.f);
return s != null && s.type == 'file' && index(split(readfile(cr.f) ?? '', '\n'), '[' + m[1] + ']') >= 0;
}
function crgone(sf, cr) {
unlink(sf);
let f = type(cr) == 'object' ? cr.f : null;
if (type(f) != 'string' || !match(f, /^\/tmp\/wf-cloud\/fl\/wf[a-z0-9]{1,40}\.conf$/)) return;
for (let x in lsdir(X + '/st') ?? []) {
let v = match(x, /\.json$/) ? rjs(X + '/st/' + x) : null;
if (type(v) == 'object' && type(v.cr) == 'object' && v.cr.f === f && now < (v.x ?? 0)) return;
}
unlink(f);
}
function cserve(cr, nm, attach, H0) {
let size = cr.s, P = prange(size), a = P.a, z = P.z, n = size ? z - a + 1 : 0;
let H = { 'Content-Type': mimeof(nm), 'Content-Length': n, 'Accept-Ranges': 'bytes',
'Content-Disposition': (attach ? 'attachment' : 'inline') + "; filename*=UTF-8''" + urlenc(nm), ...(H0 ?? {}) };
if (P.part) H['Content-Range'] = 'bytes ' + a + '-' + z + '/' + size;
hdr(P.part ? 206 : 200, H);
if (head || !n) exit(0);
let p = popen('RCLONE_CONFIG=' + q(cr.f) + ' exec rclone cat --offset ' + a + ' --count ' + n + ' --log-level ERROR ' + q(cr.r) + ' 2>/dev/null', 'r');
if (!p) exit(0);
if (length(BASE) && n > XCH) uhslot();
let k = 0;
while (n > 0) {
if ((++k & 15) == 0 && !mine()) break;
let c = p.read(n > CH ? CH : n);
if (c == null || !length(c)) break;
if (stdout.write(c) == null) break;
n -= length(c);
}
p.close();
slotfree();
exit(0);
}

function u16(n) { return chr(n & 255, (n >> 8) & 255); }
function u32(n) { return chr(n & 255, (n >> 8) & 255, (n >> 16) & 255, (n >> 24) & 255); }
function u64(n) { return u32(n & 0xffffffff) + u32((n >> 32) & 0xffffffff); }
let CT = null;
function crcs(s, c) {
if (!CT) { CT = []; for (let i = 0; i < 256; i++) { let v = i; for (let k = 0; k < 8; k++) v = (v & 1) ? (0xEDB88320 ^ (v >> 1)) : (v >> 1); push(CT, v); } }
c = c ^ 0xffffffff;
for (let i = 0; i < length(s); i++) c = CT[(c ^ ord(s, i)) & 255] ^ (c >> 8);
return c ^ 0xffffffff;
}
function dost(t) {
let x = localtime(t);
if (x.year < 1980) return [ 0, 33 ];
return [ (x.hour << 11) | (x.min << 5) | int(x.sec / 2), ((x.year - 1980) << 9) | (x.mon << 5) | x.mday ];
}
function walk(abs, rel, E, depth) {
if (depth > 32) return;
for (let n in sort(lsdir(abs) ?? [])) {
if (badname(n) || substr(n, 0, 4) == '.wf-') continue;
let a = abs + '/' + n, s = lstat(a);
if (!s) continue;
if (s.type == 'directory') walk(a, rel + n + '/', E, depth + 1);
else if (s.type == 'file') push(E, { a: a, n: rel + n, s: s.size, m: s.mtime });
if (length(E) > 20000) return;
}
}
function zipsend(E, zname, ondone) {
if (length(E) > 20000) fail(413, 'Troppi file per uno ZIP: scarica una cartella alla volta', 'Too many files for one ZIP: download one folder at a time');
let off = 0, cd = 0;
for (let e in E) {
e.z = e.s >= 0xffffffff; e.off = off;
off += 30 + length(e.n) + (e.z ? 20 : 0) + e.s + (e.z ? 24 : 16);
let ext = (e.z ? 16 : 0) + (e.off >= 0xffffffff ? 8 : 0);
cd += 46 + length(e.n) + (ext ? 4 + ext : 0);
}
let n = length(E), z64 = n >= 0xffff || off >= 0xffffffff || cd >= 0xffffffff, total = off + cd + (z64 ? 76 : 0) + 22;
hdr(200, { 'Content-Type': 'application/zip', 'Content-Length': total, 'Content-Disposition': "attachment; filename*=UTF-8''" + urlenc(zname) });
if (head) exit(0);
if (length(BASE)) uhslot();
let tf = X + '/.z' + rid(), sent = 0, k = 0;
for (let e in E) {
let t = dost(e.m);
e.t = t;
if (!mine()) { slotfree(); exit(0); }
if (stdout.write(u32(0x04034b50) + u16(e.z ? 45 : 20) + u16(0x0808) + u16(0) + u16(t[0]) + u16(t[1]) + u32(0) +
(e.z ? u32(0xffffffff) + u32(0xffffffff) : u32(0) + u32(0)) + u16(length(e.n)) + u16(e.z ? 20 : 0) + e.n +
(e.z ? u16(1) + u16(16) + u64(0) + u64(0) : '')) == null) { slotfree(); exit(0); }
let f = type(e.f) == 'function' ? e.f() : open(e.a, 'r'), left = e.s, big = e.s > 262144, p = big ? popen('gzip -1 -c | tail -c 8 > ' + q(tf), 'w') : null, c32 = 0;
let fpc = () => { if (f) f.close(); if (p) p.close(); };
if (!f && type(e.f) == 'function') { fpc(); unlink(tf); slotfree(); exit(0); }
while (left > 0) {
if ((++k & 15) == 0 && !mine()) { fpc(); unlink(tf); slotfree(); exit(0); }
let c = f ? f.read(left > CH ? CH : left) : null;
if (c == null || !length(c)) { c = ''; for (let i = 0; i < (left > CH ? CH : left); i++) c += chr(0); }
if (big) p.write(c); else c32 = crcs(c, c32);
if (stdout.write(c) == null) { fpc(); unlink(tf); slotfree(); exit(0); }
left -= length(c);
}
if (f) f.close();
if (big) { p.close(); let b = readfile(tf) ?? ''; c32 = length(b) >= 4 ? (ord(b, 0) | (ord(b, 1) << 8) | (ord(b, 2) << 16) | (ord(b, 3) << 24)) : 0; unlink(tf); }
e.crc = c32;
stdout.write(u32(0x08074b50) + u32(c32) + (e.z ? u64(e.s) + u64(e.s) : u32(e.s) + u32(e.s)));
sent += e.s;
}
let C = '';
for (let e in E) {
let bo = e.off >= 0xffffffff, ext = (e.z ? u64(e.s) + u64(e.s) : '') + (bo ? u64(e.off) : '');
C += u32(0x02014b50) + u16(0x032d) + u16(e.z || bo ? 45 : 20) + u16(0x0808) + u16(0) + u16(e.t[0]) + u16(e.t[1]) + u32(e.crc) +
u32(e.z ? 0xffffffff : e.s) + u32(e.z ? 0xffffffff : e.s) + u16(length(e.n)) + u16(length(ext) ? 4 + length(ext) : 0) + u16(0) + u16(0) + u16(0) +
u32(0x81a40000) + u32(bo ? 0xffffffff : e.off) + e.n + (length(ext) ? u16(1) + u16(length(ext)) + ext : '');
if (length(C) > 65536) { stdout.write(C); C = ''; }
}
if (z64) C += u32(0x06064b50) + u64(44) + u16(45) + u16(45) + u32(0) + u32(0) + u64(n) + u64(n) + u64(cd) + u64(off) +
u32(0x07064b50) + u32(0) + u64(off + cd) + u32(1);
C += u32(0x06054b50) + u16(0) + u16(0) + u16(n >= 0xffff ? 0xffff : n) + u16(n >= 0xffff ? 0xffff : n) + u32(cd >= 0xffffffff ? 0xffffffff : cd) +
u32(off >= 0xffffffff ? 0xffffffff : off) + u16(0);
stdout.write(C);
slotfree();
if (ondone) ondone(sent);
exit(0);
}

function putchunk(part, size) {
let cr = getenv('HTTP_CONTENT_RANGE') ?? '', len = +(getenv('CONTENT_LENGTH') ?? '0'), a = 0, b = -1, tot = size;
let m1 = match(cr, /^bytes ([0-9]+)-([0-9]+)\/([0-9]+)$/), m0 = match(cr, /^bytes \*\/([0-9]+)$/);
if (m1) { a = +m1[1]; b = +m1[2]; tot = +m1[3]; }
else if (m0) { tot = +m0[1]; if (len) jfail(400, 'Pezzo non valido', 'Invalid chunk'); }
else if (qp('off') != null) { a = +qp('off'); b = a + len - 1; tot = +(qp('size') ?? -1); }
else { b = len - 1; }
if (tot != size) jfail(400, 'Grandezza del file diversa', 'Different file size');
if (len > XCH) jfail(413, 'Pezzo troppo grande', 'Chunk too large');
if (b - a + 1 != len || (len && b >= size)) jfail(400, 'Pezzo non valido', 'Invalid chunk');
let ps = lstat(part);
if (ps && ps.type != 'file') jfail(400, 'Percorso non valido', 'Invalid path');
let cur = ps ? ps.size : 0;
if (a != cur) jout(409, { off: cur, error: L('Pezzo fuori posto: riprendi da ' + cur, 'Chunk out of place: resume from ' + cur) });
if (len > 0) {
if (freeb('/tmp') < TMPMIN) jout(503, { error: L('Memoria del router quasi piena: riprova fra poco', 'Router memory almost full: try again shortly'), retry: 30 }, { 'Retry-After': '30' });
if (!slotget(X + '/put', PUTMAX)) jout(503, { error: L('Troppi caricamenti insieme: riprova fra poco', 'Too many uploads at once: try again shortly'), retry: 2 }, { 'Retry-After': '2' });
let f = open(part, 'a'), got = 0, bad = !f;
while (!bad && got < len) {
let c = stdin.read(len - got > CH ? CH : len - got);
if (c == null || !length(c)) break;
if (f.write(c) != length(c)) bad = true;
else got += length(c);
}
if (f) f.close();
if (bad) jfail(507, 'File non scritto: disco pieno o staccato', 'File not written: drive full or removed');
if (got != len) jfail(400, 'Pezzo incompleto', 'Incomplete chunk');
}
else if (!ps) writefile(part, '');
return cur + len;
}

let tok = '', kind = '';
function bfile() { return X + '/bad/' + tok + '-' + replace(ip, /[^0-9A-Za-z.]/g, '_'); }
function badn() { let b = match(readfile(bfile()) ?? '', /^([0-9]+) ([0-9]+)/); return b && now - +b[2] < 600 ? { n: +b[1], t: +b[2] } : { n: 0, t: now }; }
function passpage(bad) {
html(401, L('Link Protetto', 'Protected Link'), '<div class="c"><form method="post" action="">' +
'<p class="m">' + L('Questo link chiede la password.', 'This link asks for the password.') + '</p>' +
'<input type="password" name="p" autocomplete="current-password" autofocus required>' + (bad ? '<p class="e">' + L('Password sbagliata', 'Wrong password') + '</p>' : '') +
'<button class="b" type="submit">' + L('Apri', 'Open') + '</button></form></div>', null);
}
function gate(o) {
if (type(o.pw) != 'object') return;
let B = badn();
if (B.n >= 5) fail(429, 'Troppi tentativi: riprova fra 10 minuti', 'Too many attempts: try again in 10 minutes', { 'Retry-After': '600' });
let key = trim(readfile(KEYF) ?? ''), cn = 'wf' + substr(tok, 0, 12), cm = match(cookie(cn) ?? '', /^([0-9]+)\.([0-9a-f]+)$/);
if (length(key) && cm && +cm[1] > now && +cm[1] <= now + CKMAX && sha256(key + '|' + tok + '|' + cm[1] + '|' + o.pw.h) == cm[2]) return;
if (meth == 'POST') {
let n = +(getenv('CONTENT_LENGTH') ?? '0'), m = n > 0 && n <= 4096 ? match(readbody(n), /(^|&)p=([^&]*)/) : null;
let p = m ? urldec(replace(m[2], /\+/g, ' ')) : null;
if (p != null && length(key) && sha256(o.pw.salt + ':' + p) == o.pw.h) {
let e = now + CKMAX;
hdr(303, { Location: BASE + uri + (length(QS) ? '?' + QS : ''), 'Content-Length': 0,
'Set-Cookie': cn + '=' + e + '.' + sha256(key + '|' + tok + '|' + e + '|' + o.pw.h) + '; Path=' + BASE + '/' + kind + '/' + tok + '/; Max-Age=' + CKMAX + '; HttpOnly; SameSite=Lax' + (https ? '; Secure' : '') });
exit(0);
}
mkdirp(X + '/bad'); mkdirp(X + '/fail');
writefile(bfile(), (B.n + 1) + ' ' + B.t + ' ' + ip + '\n');
append(X + '/fail/' + tok, '1');
append(X + '/fails.log', now + '\n');
if (B.n + 1 == 5) ev('nas_link_fails', '⚠️ ' + TL('Link Di Condivisione', 'Sharing Links') + ' ¦ ' + TL('Troppi tentativi', 'Too many attempts') + ' ¦ ' + (pvis(o.own) ?? short(o.name)));
let h = 0;
for (let l in split(readfile(X + '/fails.log') ?? '', '\n')) if (length(l) && now - +l < 3600) h++;
let nc = stat(X + '/netclose');
if (h >= 30 && (!nc || now - nc.mtime >= 3600)) { writefile(X + '/netclose', '' + now); detach('sh ' + q(SH) + ' netclose'); }
if (B.n + 1 >= 5) fail(429, 'Troppi tentativi: riprova fra 10 minuti', 'Too many attempts: try again in 10 minutes', { 'Retry-After': '600' });
passpage(true);
}
if (meth != 'GET' && meth != 'HEAD') jfail(401, 'Serve la password', 'The password is required');
passpage(false);
}

function upjs(after) {
return 'const CH=' + XCH + ',T={ok:' + sprintf('%J', L('Caricato', 'Uploaded')) + ',no:' + sprintf('%J', L('Non caricato', 'Not uploaded')) +
',wt:' + sprintf('%J', L('Al sicuro nel router: va nel cloud appena è pronto', 'Safe in the router: goes to the cloud as soon as it is ready')) + '};' +
'const l=document.getElementById("l");' +
'async function up(f,li){let off=0;for(;;){const end=Math.min(off+CH,f.size);const r=await fetch(encodeURIComponent(f.name)+"?off="+off+"&size="+f.size+"&mtime="+Math.floor(f.lastModified/1000),{method:"PUT",body:f.slice(off,end)});' +
'const j=await r.json().catch(()=>({}));if(r.status==409&&j.off!=null){off=j.off;continue;}if(!r.ok)throw new Error(j.error||r.status);' +
'if(j.name){li.lastChild.textContent=j.wait?T.wt:T.ok;return;}off=j.off;li.lastChild.textContent=Math.floor(off*100/f.size)+"%";}}' +
'document.getElementById("go").onclick=async()=>{for(const f of document.getElementById("f").files){const li=document.createElement("li");' +
'li.innerHTML="<span class=n></span><small></small>";li.firstChild.textContent=f.name;l.appendChild(li);' +
'try{await up(f,li);}catch(e){li.lastChild.textContent=T.no+": "+e.message;li.lastChild.className="e";}}' + after + '};';
}

function who() {
if (!loc) return '';
for (let l in split(readfile('/tmp/dhcp.leases') ?? '', '\n')) { let f = split(l, ' '); if (f[2] == ip && length(f[3] ?? '') && f[3] != '*') return f[3]; }
return '';
}
function logacc(l, what, bytes) {
mkdirp(X + '/log'); mkdirp(X + '/seen');
let w = who(), f = X + '/log/' + tok;
if ((stat(f)?.size ?? 0) < 65536) append(f, sprintf('%J\n', { t: now, what: what, from: loc ? 'home' : 'net', who: w, bytes: bytes }));
let first = l.notify == 'first' && l.seen !== true && !stat(X + '/seen/' + tok);
let each = l.notify == 'each' && now - (stat(X + '/seen/' + tok + '.e')?.mtime ?? 0) >= 600;
if (!first && !each) return;
writefile(X + '/seen/' + tok + (each ? '.e' : ''), '');
if (pvis(l.own) != null) return;
ev('nas_link_open', '🗄️ ' + TL('Link Aperto', 'Link Opened') + ' ¦ ' + short(l.name) + ' ¦ ' +
(loc ? TL('Da casa', 'From home') + (length(w) ? ' · ' + w : '') : TL('Da internet', 'From the internet')));
}
const AMAX = 43200;
function afile() { return X + '/acc/' + replace(ip, /[^0-9A-Za-z.]/g, '_') + '@' + tok; }
function known() { let s = stat(afile()); return s != null && now - s.mtime < AMAX; }
function count() {
if (known()) return false;
mkdirp(X + '/hits'); mkdirp(X + '/acc');
append(X + '/hits/' + tok, '1'); writefile(afile(), '' + now);
return true;
}
function hit(l, what, bytes, first) { let nw = count(); if (nw || (what != 'open' && first !== false)) logacc(l, what, bytes); }
function left(l) { return (l.max ?? 0) > 0 ? l.max - ((l.hits ?? 0) + (stat(X + '/hits/' + tok)?.size ?? 0)) : null; }
function nomore(l) { if (known()) return; let r = left(l); if (r != null && r <= 0) fail(410, 'Download esauriti', 'No downloads left'); }

function reqhost() {
let h = replace(replace(getenv('HTTP_HOST') ?? '', /:[0-9]+$/, ''), /[^]A-Za-z0-9.:[-]/g, '');
return length(h) ? h : (getenv('SERVER_ADDR') ?? '');
}
function pcnm(s) { return replace('' + s, /[]\\\/:*?"<>|[[:cntrl:]]/g, '-'); }
function pcdrv(N, u) {
let s4 = split(readfile(ETC + '/nas-smb.fp') ?? '', '|')[0] == 'samba4', x = type(N?.users?.[u]) == 'object' ? N.users[u] : {};
return s4 ? 'Drive' : 'Drive ' + pcnm(x.vis ?? u ?? '');
}
function pcnb(N) { let n = substr(replace('' + (N?.adv?.name ?? ''), /[^A-Za-z0-9-]/g, '-'), 0, 15); return match(n, /[A-Za-z]/) ? n : 'NAS'; }
function pclan() {
let v4 = /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/, a = trim(readfile(X + '/lanip') ?? ''), s = lc(replace(getenv('SERVER_ADDR') ?? '', /^::ffff:/, ''));
return match(a, v4) ? a : (ZN == 'lan' && match(s, v4) ? s : reqhost());
}
function reqos() {
let ua = getenv('HTTP_USER_AGENT') ?? '';
return match(ua, /iPhone|iPad|iPod/) ? 'ios' : match(ua, /Android/) ? 'android' : match(ua, /Windows/) ? 'win' : match(ua, /Macintosh|Mac OS X/) ? 'mac' :
match(ua, /Linux|X11|CrOS/) ? 'linux' : '';
}
function connsteps() {
return {
ios: L('Apri File › Sfoglia › ··· › Connetti al server, scrivi l\'indirizzo smb, poi Utente registrato con nome e password.', 'Open Files › Browse › ··· › Connect to Server, type the smb address, then Registered User with name and password.'),
android: L('In CX File Explorer (gratis su Play Store) tocca Rete › Nuova › SMB, scrivi l\'indirizzo nel campo Host, poi il nome e la password, e apri la cartella.', 'In CX File Explorer (free on Play Store) tap Network › New › SMB, type the address in the Host field, then the name and password, and open the folder.'),
win: L('Apri Esplora File, scrivi l\'indirizzo \\\\ nella barra in alto e premi Invio, poi il nome e la password.', 'Open File Explorer, type the \\\\ address in the top bar and press Enter, then the name and password.'),
mac: L('Nel Finder: Vai › Connessione al server (⌘K), scrivi l\'indirizzo smb, poi il nome e la password.', 'In Finder: Go › Connect to Server (⌘K), type the smb address, then the name and password.'),
linux: L('Nel gestore dei file (File, Dolphin): Altre posizioni › Connetti al server, scrivi l\'indirizzo smb, poi il nome e la password.', 'In the file manager (Files, Dolphin): Other Locations › Connect to Server, type the smb address, then the name and password.')
};
}

let UBX = null;
function ub(o, fn, a, safe) {
if (UBX == null) { try { UBX = require('ubus').connect(null, 30) ?? false; } catch (e) { UBX = false; } }
if (UBX) { let x = null; try { x = UBX.call(o, fn, a); } catch (e) { x = null; } return x; }
if (!safe) return null;
let p = popen('ubus -t 30 call ' + o + ' ' + fn + ' ' + q(sprintf('%J', a)) + ' 2>/dev/null', 'r'), r = null;
if (p) { try { r = json(p.read('all')); } catch (e) { r = null; } p.close(); }
return r;
}
function nkey() {
let k = trim(readfile(KEYF) ?? '');
if (length(k) >= 16) return k;
let f = X + '/n.key';
k = trim(readfile(f) ?? '');
if (length(k) >= 16) return k;
mkdirp(X);
k = rid() + rid() + rid() + rid();
let t = f + '.t' + rid();
sh('umask 077; : > ' + q(t));
writefile(t, k); rename(t, f);
return trim(readfile(f) ?? k);
}
function ntk(n) { return substr(sha256(nkey() + '|n|' + n), 0, 32); }
function rname() {
let U = null, v = '';
try { U = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')(); } catch (e) { U = null; }
if (type(U?.uiname) == 'function') { try { v = U.uiname(getenv('WF_CFGDIR') ?? '/etc/config/'); } catch (e) { v = ''; } }
if (!length(v)) v = trim(readfile(R + '/proc/sys/kernel/hostname') ?? '');
return substr(v, 0, 64);
}
function ncookie(k, v, age) {
return k + '=' + v + '; Path=' + BASE + '/n/; Max-Age=' + age + '; HttpOnly; SameSite=Strict' + (https ? '; Secure' : '');
}
function nsset(v, age) {
if (!length(BASE)) return ncookie('wfns', v, age);
return [ 'wfns=' + v + '; Path=' + BASE + '/; Max-Age=' + age + '; HttpOnly; SameSite=Strict' + (https ? '; Secure' : ''), ncookie('wfns', '', 0) ];
}
function tkok(b) {
let n = cookie('wfnt'), o = getenv('HTTP_ORIGIN');
if (o != null && (replace(o, /^https?:\/\//, '') != (getenv('HTTP_HOST') ?? '') || !hostok(getenv('HTTP_HOST')))) return false;
return n != null && match(n, /^[0-9a-f]{20,64}$/) != null && type(b.tk) == 'string' && b.tk === ntk(n);
}
function nxmod() {
let M = null;
try { M = loadfile(getenv('WF_NASXUC') ?? '/usr/share/wrtfreedom/nasx.uc')(); } catch (e) { M = null; }
return type(M?.relay) == 'function' ? M : null;
}
function nerr(code, it, en, x) { jout(200, { error: it, error_en: en, code: code, ...(x ?? {}) }); }

function appurl() {
if (length(BASE)) return '/wrtfreedom/#nas';
if (https) return '/app/#nas';
let m = match(readfile((getenv('WF_CFGDIR') ?? '/etc/config/') + 'uhttpd') ?? '', /list[ \t]+listen_http[ \t]+'?[^ \t'\n]*:([0-9]+)'?/);
let p = m ? m[1] : '80', h = reqhost();
if (index(h, ':') >= 0 && substr(h, 0, 1) != '[') h = '[' + h + ']';
return 'http://' + h + (p == '80' ? '' : ':' + p) + '/wrtfreedom/#nas';
}
if (match(uri, /^(\/|\/nas\/?|\/n\/?)?$/)) { hdr(301, { Location: appurl(), 'Content-Length': 0 }); exit(0); }
if (uri == '/n/api') {
let Z = ZN;
NAPI = true;
let netok = Z != 'net' || (!length(BASE) && https);
{
if (meth == 'OPTIONS') {
hdr(204, { ...cors(), 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Max-Age': '600', Allow: 'POST, OPTIONS' });
exit(0);
}
if (Z == 'guest') nerr('lan_only', 'Dal Wi-Fi ospiti il NAS non si apre', 'The NAS does not open from the guest Wi-Fi');
if (!netok) nerr('lan_only', 'Solo da casa, dalla VPN o dall\'Accesso Remoto', 'Home, VPN or Remote Access only');
if (meth != 'POST') jfail(405, 'Solo POST', 'POST only');
if (!oriok(getenv('HTTP_ORIGIN'))) jfail(403, 'Richiesta da un altro sito', 'Request from another site');
if (!match(lc(getenv('CONTENT_TYPE') ?? ''), /^application\/json([ \t]*;.*)?$/)) jfail(415, 'Richiesta non valida', 'Invalid request');
let n = +(getenv('CONTENT_LENGTH') ?? '0'), b = null;
if (n > 0 && n <= 65536) { try { b = json(readbody(n)); } catch (e) { b = null; } }
if (type(b) != 'object' || type(b.act) != 'string') jfail(400, 'Richiesta non valida', 'Invalid request');
if (nasoff()) nerr('off', 'NAS spento', 'NAS off');
let act = b.act, page = tkok(b), bm = match(getenv('HTTP_AUTHORIZATION') ?? '', /^Bearer ([0-9a-f]{32})$/);
if (act == 'tk') {
let nc = cookie('wfnt'), H = null;
if (nc == null || !match(nc, /^[0-9a-f]{20,64}$/)) { nc = rid() + rid() + rid(); H = { 'Set-Cookie': ncookie('wfnt', nc, 86400) }; }
jout(200, { tk: ntk(nc), lan: home, reg: (rjs(NJ) ?? {}).reg !== false, name: rname() }, H);
}
if (b.tk != null && !page) nerr('token', 'Pagina scaduta: ricaricala', 'Page expired: reload it');
let str = (k) => type(b[k]) == 'string' ? b[k] : '';
let busy = () => nerr('busy', 'Router occupato: riprova', 'Router busy: try again');
if (index([ 'login', 'logout', 'call', 'me', 'pass', 'recover' ], act) >= 0) {
let nos = act == 'login' || act == 'recover';
if (!nos && !bm && !page) nerr('token', 'Pagina scaduta: ricaricala', 'Page expired: reload it');
let sid = bm ? bm[1] : (page ? cookie('wfns') : null), NX = nxmod();
if (!NX) busy();
let q2 = act == 'login' ? { act: 'login', user: str('user'), pass: str('pass'), dev: str('dev'), ...(page && b.pc === true ? { pc: true } : {}) } :
act == 'recover' ? { act: 'recover', user: str('user'), code: str('code'), 'new': str('new') } :
act == 'logout' ? { act: 'logout', sid: sid } :
act == 'call' ? { act: 'call', sid: sid, object: str('object'), method: str('method'), params: type(b.params) == 'object' ? b.params : {} } :
{ act: 'call', sid: sid, object: 'wrtfreedom', method: 'nas_me', params: act == 'me' ? { act: 'get' } : { act: 'pass', old: str('old'), 'new': str('new') } };
let r = null;
try { r = NX.relay(q2, ip, Z, !length(BASE) && https); } catch (e) { r = null; }
if (type(r) != 'object') busy();
let H = null;
if (act == 'login' && page && type(r.sid) == 'string' && match(r.sid, /^[0-9a-f]{32}$/)) { H = { 'Set-Cookie': nsset(r.sid, 43200) }; delete r.sid; }
else if (!bm && !nos && (act == 'logout' || r.code == 'who' || r.code == 'blocked')) H = { 'Set-Cookie': nsset('', 0) };
jout(200, r, H);
}
if (act == 'propose' || act == 'register') {
if (!home) nerr('lan_only', 'Si fa dalla rete di casa o con la VPN', 'Only from the home network or the VPN');
if (act == 'register' && !page) nerr('token', 'Pagina scaduta: ricaricala', 'Page expired: reload it');
if (act == 'propose') {
let r = ub('wrtfreedom', 'nas_me', { act: 'propose', vis: str('vis'), ip: ip, ...(page ? {} : { blind: true }) }, true);
if (type(r) != 'object') busy();
jout(200, r);
}
let a ={ act: 'register', vis: str('vis'), pass: str('pass'), read: b.read === true, ip: ip };
if (length(str('user'))) a.user = str('user');
let r = ub('wrtfreedom', 'nas_me', a, false);
if (type(r) != 'object') busy();
jout(200, r);
}
jfail(400, 'Azione sconosciuta', 'Unknown action');
}
}

function davok(u, pw) {
if (!match(u, /^[A-Za-z][A-Za-z0-9._-]{0,31}$/) || !length(pw)) return false;
let h = null, re = 'WrtFreedom NAS', L = null;
for (let l in split(readfile(ETC + '/nas-dav.digest') ?? '', '\n')) { let p = split(l, ':'); if (length(p) == 3 && p[0] == u && p[1] == re) L = p[2]; }
if (L == null) return false;
let D = null; try { D = require('digest'); } catch (e) { D = null; }
if (type(D?.md5) == 'function') h = D.md5(u + ':' + re + ':' + pw);
else {
mkdirp(X);
let f = X + '/.dv' + rid();
sh('umask 077; : > ' + q(f));
writefile(f, u + ':' + re + ':' + pw);
h = substr(trim(sh('md5sum < ' + q(f) + ' 2>/dev/null')), 0, 32);
unlink(f);
}
return h === L;
}
function rfc(t) { let g = gmtime(t); return sprintf('%s, %02d %s %04d %02d:%02d:%02d GMT', [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ][g.wday] ?? 'Mon', g.mday, [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ][g.mon - 1], g.year, g.hour, g.min, g.sec); }
if (uri == '/foto' || substr(uri, 0, 6) == '/foto/') {
{
if (ZN == 'guest') fail(403, 'Dal Wi-Fi ospiti il NAS non si apre', 'The NAS does not open from the guest Wi-Fi');
if (ZN == 'net' && (length(BASE) || !https)) fail(403, 'Solo da casa, dalla VPN o dall\'Accesso Remoto', 'Home, VPN or Remote Access only');
if (nasoff()) fail(503, 'NAS spento', 'NAS off');
let bf = X + '/fbad/' + replace(ip, /[^0-9A-Za-z.]/g, '_'), bm = match(readfile(bf) ?? '', /^([0-9]+) ([0-9]+)/), bn = bm && now - +bm[2] < 600 ? +bm[1] : 0;
if (bn >= 10) fail(429, 'Troppe password sbagliate: riprova fra 10 minuti', 'Too many wrong passwords: try again in 10 minutes');
let deny = (bad) => {
if (bad) { mkdirp(X + '/fbad'); writefile(bf, (bn + 1) + ' ' + (bm && bn ? bm[2] : now)); }
hdr(401, { 'WWW-Authenticate': 'Basic realm="WrtFreedom NAS", charset="UTF-8"', 'Content-Length': 0 }); exit(0);
};
let am = match(getenv('HTTP_AUTHORIZATION') ?? '', /^Basic ([A-Za-z0-9+\/=]+)$/), up = am ? b64dec(am[1]) : null, ci = up ? index(up, ':') : -1;
if (ci <= 0) deny(false);
let u = substr(up, 0, ci), own = u == 'Amministratore' ? 'admin' : u;
if (!davok(u, substr(up, ci + 1))) deny(true);
if (own != 'admin' && (!match(own, /^[a-z][a-z0-9]{0,19}$/) || ownoff(own))) deny(false);
let seg = filter(split(urldec(substr(uri, 5)), '/'), (x) => length(x)), nm = length(seg) ? seg[length(seg) - 1] : '';
for (let x in seg) if (x == '.' || x == '..' || badname(x)) fail(400, 'Nome non valido', 'Invalid name');
let M = null;
try { M = loadfile(getenv('WF_NASBKUC') ?? '/usr/share/wrtfreedom/nasbk.uc')(); } catch (e) { M = null; }
if (type(M?.phdav) != 'function') fail(503, 'Router occupato: riprova', 'Router busy: try again');
if (meth == 'OPTIONS') { hdr(200, { DAV: '1', Allow: 'OPTIONS, PROPFIND, PUT, MKCOL, HEAD, GET, DELETE', 'MS-Author-Via': 'DAV', 'Content-Length': 0 }); exit(0); }
if (meth == 'MKCOL') { hdr(201, { 'Content-Length': 0 }); exit(0); }
if (meth == 'DELETE') { hdr(204, { 'Content-Length': 0 }); exit(0); }
if (meth == 'PUT') {
if (!length(nm) || substr(nm, 0, 1) == '.') fail(400, 'Nome non valido', 'Invalid name');
if (ownfull(own)) fail(507, 'Spazio della persona pieno', 'Storage quota full');
if (mainpause()) fail(503, 'Disco Principale in pausa', 'Main Drive paused');
let base = M.phdavdir(own), n = +(getenv('CONTENT_LENGTH') ?? '-1');
if (type(base) != 'string' && type(M.phdavcl) == 'function') {
let cm = match(getenv('HTTP_X_OC_MTIME') ?? '', /^[0-9]{1,12}$/) ? +getenv('HTTP_X_OC_MTIME') : 0;
let r = M.phdavcl(own, nm, n >= 0 ? n : -1, cm, (k) => stdin.read(k > CH ? CH : k));
if (r?.error) {
let c = r.code == 'quota_full' ? 507 : (r.code == 'name' || r.code == 'size') ? 400 : 503;
fail(c, r.error, r.error_en ?? r.error, type(r.retry) == 'int' ? { 'Retry-After': '' + r.retry } : null);
}
hdr(r.dup ? 204 : 201, { 'Content-Length': 0 }); exit(0);
}
if (type(base) != 'string') fail(503, 'Manca il Disco Principale', 'Main Drive missing');
if (n > 0 && freeb(base) < n + 16777216) fail(507, 'Spazio non sufficiente', 'Not enough space');
if (n > 4294967295 && fsof(base) == 'vfat') fail(413, 'File oltre 4 GB: il disco FAT32 non li regge', 'File over 4 GB: the FAT32 drive cannot hold it');
let tmp = base + '/.' + nm + '.' + rid() + '.wfpart', o = open(tmp, 'w'), got = 0;
if (!o) fail(503, 'File non scritto', 'File not written');
while (n < 0 || got < n) { let c = stdin.read(n < 0 || n - got > CH ? CH : n - got); if (c == null || !length(c)) break; if (o.write(c) != length(c)) { got = -1; break; } got += length(c); }
o.close();
if (got < 0 || (n >= 0 && got != n)) { unlink(tmp); fail(400, 'File incompleto', 'Incomplete file'); }
let mt = match(getenv('HTTP_X_OC_MTIME') ?? '', /^[0-9]{1,12}$/) ? +getenv('HTTP_X_OC_MTIME') : 0;
let r = M.phdav(own, tmp, nm, mt);
if (r?.error) fail(r.code == 'quota_full' ? 507 : r.code == 'name' ? 400 : 503, r.error, r.error_en ?? r.error);
hdr(r.dup ? 204 : 201, { 'Content-Length': 0 }); exit(0);
}
let F = M.phdavls(own).files;
if (meth == 'PROPFIND') {
let cl = +(getenv('CONTENT_LENGTH') ?? '0');
if (cl > 0 && cl <= 65536) readbody(cl);
let href = BASE + '/foto' + (length(seg) ? '/' + join('/', map(seg, urlenc)) : ''), f = length(nm) ? F[nm] : null;
let fr = (h, x) => '<D:response><D:href>' + esc(h) + '</D:href><D:propstat><D:prop><D:displayname>' + esc(bname(h)) + '</D:displayname><D:resourcetype/>' +
'<D:getcontentlength>' + x[1] + '</D:getcontentlength><D:getlastmodified>' + rfc(x[2]) + '</D:getlastmodified><D:getcontenttype>' + mimeof(bname(h)) +
'</D:getcontenttype></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>';
let s = '<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:">';
if (f) s += fr(href, f);
else if (match(nm, /\.[A-Za-z0-9]{1,5}$/)) fail(404, 'Non trovato', 'Not found');
else {
s += '<D:response><D:href>' + esc(href + '/') + '</D:href><D:propstat><D:prop><D:displayname>' + esc(length(nm) ? nm : 'foto') +
'</D:displayname><D:resourcetype><D:collection/></D:resourcetype></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>';
if ((getenv('HTTP_DEPTH') ?? '1') != '0') for (let k in sort(keys(F))) s += fr(href + '/' + urlenc(k), F[k]);
}
s += '</D:multistatus>';
hdr(207, { 'Content-Type': 'application/xml; charset=utf-8', 'Content-Length': length(s) });
out(s); exit(0);
}
if (meth == 'HEAD' || meth == 'GET') {
let f = length(nm) ? F[nm] : null;
if (!f) fail(404, 'Non trovato', 'Not found');
if (head) { hdr(200, { 'Content-Type': mimeof(nm), 'Content-Length': f[1], 'Last-Modified': rfc(f[2]) }); exit(0); }
if (f[0] == null) fail(404, 'Non trovato', 'Not found');
serve(f[0], nm, false);
exit(0);
}
hdr(405, { Allow: 'OPTIONS, PROPFIND, PUT, MKCOL, HEAD, GET, DELETE', 'Content-Length': 0 }); exit(0);
}
}

function farok(own, p) {
if (loc || length(BASE) || !https || type(own) != 'string' || own == 'admin' || type(p) != 'string') return false;
let NX = nxmod(), r = false;
try { r = type(NX?.outok) == 'function' && NX.outok(own, p) === true; } catch (e) { r = false; }
return r;
}

function relof(abs) {
for (let x in (rjs(X + '/disks.json')?.list ?? [])) {
let m = '' + (x?.mnt ?? '');
if (length(m) > 1 && (abs == m || substr('' + abs, 0, length(m) + 1) == m + '/')) return substr('' + abs, length(m)) || '/';
}
return null;
}
function admpriv(own, rel, whole) {
if ((own != null && own != '' && own != 'admin') || rel == null) return false;
let U = ucf(), v = null;
if (type(U.upriv) != 'function') return false;
try { v = U.upriv(null, rel, rjs(NJ) ?? {}); } catch (e) { v = null; }
return v != null && (whole === true || v != 'up');
}

const PCZ = home;
const PCSS = ':root{--bg:#131416;--card:#1c1e21;--inner:#26292e;--line:#2a2d32;--line2:#3a3f46;--fg:#eef0f1;--fg2:#b7bcc2;--fg3:#89919b;--fg4:#6c7580;' +
'--pic:#0b0c0e;--win:#1d1f23;--blue:#3a90ff;--bluef:#006efd;--blueb:#1e2b3c;--bluel:#2c4f86;--ok:#38cc65;--okb:#1d3326;--warn:#f5a524;--warnb:#3a2d15;color-scheme:dark}' +
'@media(prefers-color-scheme:light){:root{--bg:#f2f3f5;--card:#fff;--inner:#eceef1;--line:#e1e4e8;--line2:#c6cbd1;--fg:#15171a;--fg2:#4a5058;--fg3:#69707a;--fg4:#868d96;' +
'--pic:#f5f6f8;--win:#fff;--blue:#0a64e0;--blueb:#e3eefe;--bluel:#a9c9fb;--ok:#1a8f43;--okb:#e0f4e6;--warn:#a86400;--warnb:#fcefd9;color-scheme:light}}' +
'*{box-sizing:border-box}[hidden]{display:none!important}html,body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}' +
'.top{position:sticky;top:0;z-index:5;display:flex;align-items:center;gap:10px;height:60px;padding:0 14px;background:var(--bg);border-bottom:1px solid var(--line)}' +
'.logo{width:34px;height:34px;border-radius:10px;background:var(--bluef);color:#fff;display:grid;place-items:center;flex:none}.brand{font-size:18px;letter-spacing:.02em}' +
'.tr{margin-left:auto;display:flex;align-items:center;gap:8px;min-width:0}' +
'.tr select{font:inherit;font-size:14px;font-weight:600;color:var(--fg);background:var(--card);border:1px solid var(--line);border-radius:99px;padding:6px 10px;max-width:128px;cursor:pointer}' +
'.who{display:flex;align-items:center;gap:8px;font-weight:600;font-size:14px;min-width:0}.wn{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:140px}' +
'.av{width:30px;height:30px;border-radius:50%;background:#7a4cd9;color:#fff;display:grid;place-items:center;font-weight:700;flex:none}' +
'.vh{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}' +
'main{max-width:760px;margin:0 auto;padding:22px 16px 40px}h1{margin:0 0 6px;font-size:23px;line-height:1.2;letter-spacing:-.01em}h2.h{margin:26px 0 10px;font-size:19px}' +
'.sub{margin:0 0 18px;color:var(--fg2)}.m{margin:4px 0;color:var(--fg2)}.m2{display:block;color:var(--fg3);margin-top:6px}' +
'.card,details.c{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:18px;overflow-wrap:anywhere}.stack>*+*{margin-top:14px}' +
'.lk{background:none;border:0;padding:6px 0;font:inherit;font-weight:600;color:var(--blue);cursor:pointer}' +
'.btn{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:10px 22px;border-radius:99px;font-family:inherit;font-size:15px;font-weight:600;' +
'background:var(--inner);color:var(--fg);border:0;cursor:pointer;text-decoration:none;text-align:center}.btn:disabled{opacity:.6;cursor:default}' +
'.btn.pri{background:var(--bluef);color:#fff}.btn.lg{min-height:52px;font-size:16px;width:100%}.btn.sm{min-height:36px;padding:6px 14px;font-size:14px}' +
'.sq{width:48px;height:48px;border-radius:14px;display:grid;place-items:center;background:var(--blueb);color:var(--blue);flex:none}.sq.ok{background:var(--okb);color:var(--ok)}.sq.s{width:40px;height:40px;border-radius:12px}' +
'.chip{display:inline-flex;align-items:center;font-size:13px;font-weight:600;padding:5px 12px;border-radius:99px;background:var(--inner);color:var(--fg2);white-space:nowrap}' +
'.chip.bl{background:var(--blueb);color:var(--blue)}.chip.ok{background:var(--okb);color:var(--ok)}.chip.wr{background:var(--warnb);color:var(--warn)}' +
'.note{display:flex;gap:12px;align-items:flex-start;background:var(--inner);border-radius:14px;padding:14px 16px;color:var(--fg2);font-size:15px}' +
'.note svg{flex:none;margin-top:1px}.note b,.step b,.fold b,.card b{color:var(--fg)}.note .btn{min-height:38px;padding:8px 16px;font-size:14px;margin-top:10px;background:var(--card)}' +
'.ib{color:var(--blue)}.ig{color:var(--fg2)}.iw{color:var(--warn)}' +
'.kbd{display:inline-block;font-weight:600;font-size:13px;padding:0 7px;border-radius:6px;background:var(--bg);border:1px solid var(--line2);color:var(--fg);white-space:nowrap}.nw{white-space:nowrap}' +
'.fold{display:flex;flex-wrap:wrap;gap:14px;align-items:center}.fold .fx{flex:1;min-width:150px}.fold .fx b{display:block;font-size:17px}.fold small{color:var(--fg3);font-size:14px}.fold .btn{flex:1 1 100%}' +
'.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.duo{display:grid;gap:14px;align-items:center}' +
'.opts{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}' +
'.opt{display:flex;flex-direction:column;align-items:center;gap:8px;padding:18px 8px;font:inherit;font-weight:600;color:var(--fg);cursor:pointer;text-align:center}.opt.on{border-color:var(--blue);background:var(--blueb);color:var(--blue)}' +
'.step{display:flex;flex-direction:column;gap:12px}.n{width:30px;height:30px;border-radius:50%;background:var(--bluef);color:#fff;display:grid;place-items:center;font-weight:700;font-size:14px}' +
'.step h3,.chk h3{margin:0;font-size:17px}.step p,.chk p,.ps p{margin:0;color:var(--fg2);font-size:15px}.ps h3{margin:0 0 8px;font-size:17px}.ps p+p{margin-top:8px}' +
'.pic{border-radius:12px;background:var(--pic);border:1px solid var(--line);padding:10px;display:grid;place-items:center}.pic svg{width:100%;max-width:290px;height:auto;display:block}' +
'.pic text{font-family:"Segoe UI",system-ui,-apple-system,sans-serif}.p0{fill:var(--win)}.p1{fill:var(--inner)}.p2{fill:var(--pic);stroke:var(--line2)}.p3{fill:var(--bluef)}' +
'.p4{fill:var(--blueb);stroke:var(--blue)}.p5{fill:var(--inner);stroke:var(--blue)}.p7{stroke:var(--line2)}.p8{fill:var(--bluel)}' +
'.t1{fill:var(--fg)}.tb{font-weight:600}.t2{fill:var(--fg2)}.t3{fill:var(--fg3)}.t4{fill:#fff}.t5{fill:var(--blue)}' +
'.chk .card{display:flex;flex-direction:column;gap:10px}.done{display:flex;gap:16px;align-items:center;flex-wrap:wrap}.done .hx{flex:1;min-width:180px}.done h1,.done h2{margin:0;font-size:20px}' +
'.ck{width:60px;height:60px;border-radius:50%;background:var(--okb);color:var(--ok)}.wt .ck{background:var(--blueb);color:var(--blue)}.wr .ck{background:var(--warnb);color:var(--warn)}' +
'.done .i2,.done .i3,.wt .i1,.wr .i1{display:none}.wt .i2,.wr .i3{display:block}' +
'.stp{display:flex;align-items:center;gap:12px;margin:0 0 16px;color:var(--fg3);font-size:14px;font-weight:600}.dots{display:flex;gap:6px}' +
'.dots i{width:22px;height:6px;border-radius:3px;background:var(--line2)}.dots i.on{background:var(--blue)}.dots i.ok{background:var(--bluel)}' +
'.nav{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:22px}.acts{margin-top:18px;display:flex;gap:12px;flex-wrap:wrap}' +
'.tabs{display:flex;background:var(--card);border:1px solid var(--line);border-radius:99px;padding:4px;margin-bottom:14px;overflow-x:auto}' +
'.tabs button{flex:1;border:0;background:none;font:inherit;font-size:14px;font-weight:600;padding:8px 10px;border-radius:99px;color:var(--fg2);cursor:pointer;white-space:nowrap}.tabs button.on{background:var(--bluef);color:#fff}' +
'.tp{display:none}.tp.on{display:block}' +
'.rowb{display:flex;align-items:center;gap:12px;width:100%;text-align:left;font:inherit;color:inherit;cursor:pointer;margin-top:14px}.rowb .fx{flex:1;min-width:0}.rowb b{display:block}.rowb small{display:block;color:var(--fg3)}.rowb .ar{color:var(--fg3);font-size:22px}' +
'.form{max-width:440px;margin:0 auto}.form h1{margin-top:12px}' +
'label{display:block;font-size:14px;font-weight:600;color:var(--fg2);margin:14px 0 6px}' +
'input:not([type=checkbox]){width:100%;font:inherit;padding:12px 14px;border:1px solid var(--line2);border-radius:12px;background:var(--pic);color:var(--fg)}input:focus{outline:2px solid var(--blue);outline-offset:1px}' +
'.hint{font-size:13px;color:var(--fg3);margin:6px 0 0}.err{color:var(--warn);font-size:14px;font-weight:600;margin:12px 0 0}.err:empty{display:none}' +
'label.ckb{display:flex;gap:10px;align-items:center;color:var(--fg);margin:14px 0}.ckb input{width:20px;height:20px}.form .btn.lg{margin-top:16px}.form .note{margin-top:14px}' +
'.rc{font:700 21px/1.3 ui-monospace,Menlo,Consolas,monospace;letter-spacing:.06em;padding:14px;border-radius:12px;background:var(--inner);text-align:center;margin:10px 0 0}' +
'.links{display:flex;justify-content:center;gap:28px;flex-wrap:wrap;margin-top:14px}' +
'details.c{margin-top:22px;padding:14px 18px}details.c details.c{margin-top:14px;background:var(--inner);border:0}summary{cursor:pointer;color:var(--blue);font-weight:600}details[open]>summary{margin-bottom:14px}code{overflow-wrap:anywhere}' +
'.foot{margin-top:22px;color:var(--fg4);font-size:13px;text-align:center}' +
'#t{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:var(--fg);color:var(--bg);padding:10px 18px;border-radius:20px;display:none;max-width:90%;text-align:center;font-weight:600;z-index:9}' +
'body.w [data-o]:not([data-o~=w]),body.m [data-o]:not([data-o~=m]),body.l [data-o]:not([data-o~=l]),body.a [data-o]:not([data-o~=a]),body.i [data-o]:not([data-o~=i]){display:none!important}' +
'section{display:none}section.on{display:block}' +
'@media(min-width:760px){.top{padding:0 28px}main{padding:34px 24px 44px}h1{font-size:30px}.card{padding:22px}.fold .btn{flex:0 0 auto}.duo{grid-template-columns:1fr 1fr}.opts{grid-template-columns:repeat(4,1fr)}}' +
'@media(max-width:480px){.wn{display:none}}';
const PCI = {
folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
cloud: '<path d="M7 18a4.5 4.5 0 0 1-.5-9 6 6 0 0 1 11.5 1.5A3.75 3.75 0 0 1 17.5 18z"/>',
shared: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',
shield: '<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
info: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/>',
help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .8-1 1.5M12 17h.01"/>',
star: '<path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.3 6L12 16.5 6.6 19.4l1.3-6L3.4 9.3l6-.7z"/>',
check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
phone: '<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>',
pc: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
laptop: '<rect x="4" y="5" width="16" height="11" rx="2"/><path d="M2 19h20"/>',
undo: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
warn: '<path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17h.01"/>',
user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
nas: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>'
};
function pci(k, s, cls, w) {
return '<svg' + (cls ? ' class="' + cls + '"' : '') + ' width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w ?? 2) +
'" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + PCI[k] + '</svg>';
}
function pcnote(ic, cls, h, o) { return '<div class="note"' + (o ? ' data-o="' + o + '"' : '') + '>' + pci(ic, 22, cls) + '<div>' + h + '</div></div>'; }
function pckbd(t) { return '<span class="kbd">' + t + '</span>'; }
function pcrc(x, y, w, h, r, c) { return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r + '" class="' + c + '"/>'; }
function pctx(x, y, c, sz, t, a) { return '<text x="' + x + '" y="' + y + '" class="' + c + '" font-size="' + sz + '"' + (a ? ' text-anchor="' + a + '"' : '') + '>' + esc(t) + '</text>'; }
function pcpic(b) { return '<div class="pic"><svg viewBox="0 0 250 140" aria-hidden="true">' + b + '</svg></div>'; }
function pcbk(u) {
let b = u ? (rjs('/tmp/wf-nas/bk-own.json') ?? {})[u]?.pc : null;
if (type(b) != 'object') return { n: 0, last: 0, st: 'none' };
return { n: type(b.n) == 'int' ? b.n : 0, last: type(b.last) == 'int' ? b.last : 0, st: match('' + b.st, /^(ok|run|warn|bad|off|none)$/) ? b.st : 'none' };
}
function pcme() {
let sid = cookie('wfns');
if (sid == null || !match(sid, /^[0-9a-f]{32}$/)) return null;
let NX = nxmod(), r = null;
if (!NX) return { busy: true };
try { r = NX.relay({ act: 'call', sid: sid, object: 'wrtfreedom', method: 'nas_me', params: { act: 'get' } }, ip, ZN, false); } catch (e) { r = null; }
if (type(r) != 'object') return { busy: true };
if (type(r.user) == 'string' && match(r.user, /^[A-Za-z0-9._-]{1,40}$/)) return { u: r.user, vis: '' + (r.vis ?? r.user), smb: type(r.smb) == 'object' ? r.smb : null };
let g = r.code == 'who' || r.code == 'blocked';
return { gone: g, blocked: r.code == 'blocked', busy: !g };
}
function pcsh(u, ms) {
let ok = type(ms?.cloud) == 'array', r = ub('wrtfreedom', 'nas_shares', { act: ok ? 'list' : 'get' }, true);
if (type(r) != 'object' || type(r.shares) != 'array') return null;
if (ok) r.cloud = [ { smb: map(filter(ms.cloud, (n) => type(n) == 'string' && length(n)), (n) => ({ name: n, users: [ u ] })) } ];
let o = { on: r.on !== false, nb: r.nb, lip: r.lanip, drv: null, miss: false, sh: null, fh: null, tm: null, cl: [] };
for (let s in r.shares) {
if (type(s) != 'object' || type(s.name) != 'string' || !length(s.name)) continue;
if (o.nb == null) o.nb = s.nb;
if (o.lip == null) o.lip = s.lanip;
let me = s.user == u, gone = s.missing === true;
if (me && s.kind == 'user') { if (gone) o.miss = true; else if (!o.drv) o.drv = { name: s.name, dav: type(s.dav) == 'string' && length(s.dav) ? s.dav : null }; }
else if (s.kind == 'shared' && !gone) { if (!o.sh) o.sh = s.name; }
else if (me && s.kind == 'fh' && !gone) { if (!o.fh) o.fh = s.name; }
else if (me && s.kind == 'tm' && !gone) { if (!o.tm) o.tm = s.name; }
}
for (let c in (type(r.cloud) == 'array' ? r.cloud : []))
for (let x in (type(c?.smb) == 'array' ? c.smb : []))
if (type(x?.name) == 'string' && length(x.name) && x.hidden !== true && index(type(x.users) == 'array' ? x.users : [], u) >= 0 && index(o.cl, x.name) < 0) push(o.cl, x.name);
if (!match('' + o.nb, /^[A-Za-z0-9-]{1,15}$/)) o.nb = null;
if (!match('' + o.lip, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)) o.lip = null;
return o;
}
function pcpage(code, body, js, H) {
let b = '<!doctype html><html lang="' + L('it', 'en') + '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">' +
'<title>NAS</title><style>' + PCSS + '</style></head>' + body + (js ? '<script>' + js + '</script>' : '') + '</html>';
hdr(code, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': length(b),
'Content-Security-Policy': "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'", ...(H ?? {}) });
if (!head) out(b);
exit(0);
}
if (uri == '/pc/api') {
if (!PCZ) jfail(403, 'Apri questa pagina a casa', 'Open this page at home');
if (meth != 'GET' && !head) jfail(405, 'Solo lettura', 'Read only');
let P = pcme();
if (!P?.u) jout(401, { error: L('Accesso scaduto: entra di nuovo', 'Access expired: sign in again'), code: 'who' }, P?.gone ? { 'Set-Cookie': nsset('', 0) } : null);
jout(200, { pc: pcbk(P.u) });
}
if (uri == '/pc' || uri == '/pc/') {
if (meth != 'GET' && !head) fail(405, 'Solo lettura', 'Read only', { Allow: 'GET, HEAD' });
let self = BASE + '/pc', ro = reqos(), OSM = { win: 'w', mac: 'm', linux: 'l', android: 'a', ios: 'i' }, os0 = OSM[ro] ?? 'w';
let OSN = { w: 'Windows', m: 'Mac', l: 'Linux', a: 'Android', i: L('iPhone e iPad', 'iPhone and iPad') };
let top = (P) => '<header class="top"><span class="logo">' + pci('nas', 20) + '</span><b class="brand">NAS</b>' + (!P ? '' :
'<div class="tr"><label class="vh" for="osel">' + L('Sistema', 'System') + '</label><select id="osel">' +
join('', map([ 'w', 'm', 'l', 'a', 'i' ], (k) => '<option value="' + k + '"' + (k == os0 ? ' selected' : '') + '>' + OSN[k] + '</option>')) + '</select>' +
'<span class="who"><span class="av" id="av"></span><span class="wn">' + esc(P.vis) + '</span></span>' +
'<button class="btn sm" id="out" type="button">' + L('Esci', 'Sign Out') + '</button></div>') + '</header>';
if (!PCZ) pcpage(403, '<body>' + top(null) + '<main><h1>' + L('Apri Questa Pagina A Casa', 'Open This Page At Home') + '</h1><p class="sub">' +
L('Collega il computer al Wi-Fi di casa e riapri la pagina.', 'Connect the computer to the home Wi-Fi and open the page again.') + '</p></main></body>', null);
let P = pcme(), HC = [];
if (cookie('wfpc') != null) push(HC, 'wfpc=; Path=' + self + '; Max-Age=0; SameSite=Lax');
if (P?.gone) { let x = nsset('', 0); HC = [ ...HC, ...(type(x) == 'array' ? x : [ x ]) ]; }
let H = length(HC) ? { 'Set-Cookie': HC } : null;
let lip0 = pclan(), toast = '<div id="t" role="status"></div>', foot = '<p class="foot">' +
L('Pagina del router di casa · si apre solo dalla rete di casa o dalla VPN', 'Home router page · it opens only from the home network or the VPN') + '</p>';
let T0 = { net: L('Router non raggiungibile: riprova', 'Router unreachable: try again'), cp: L('Copiato', 'Copied'),
nocp: L('Non riesco a copiare: apri Per Esperti', 'Cannot copy: open For Experts') };
let jsc = 'function gi(i){return document.getElementById(i)}function qa(s){return Array.prototype.slice.call(document.querySelectorAll(s))}' +
'function toast(t){var e=gi("t");e.textContent=t;e.style.display="block";clearTimeout(e.h);e.h=setTimeout(function(){e.style.display="none"},4000)}' +
'function post(b){return fetch(D.napi,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b),credentials:"same-origin",cache:"no-store"}).then(function(r){return r.json()})}' +
'function tk(){return TK?Promise.resolve(TK):post({act:"tk"}).then(function(j){if(!j||!j.tk)throw j;TK=j;return j})}' +
'function call(b,n){return tk().then(function(t){b.tk=t.tk;return post(b)}).then(function(j){if(j&&j.code=="token"&&!n){TK=null;return call(b,1)}return j})}' +
'function em(j){return j&&j.error?(D.en&&j.error_en||j.error):T.net}' +
'function cp(t,ok1){var a=document.createElement("textarea"),ok=false;a.value=t;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{ok=document.execCommand("copy")}catch(e){}a.remove();' +
'if(navigator.clipboard&&!ok){navigator.clipboard.writeText(t).then(function(){toast(ok1||T.cp)},function(){toast(T.nocp)});return}toast(ok?(ok1||T.cp):T.nocp)}' +
'function sec(h){var s=h&&gi(h);return s&&s.tagName=="SECTION"?h:""}' +
'function go(k,m){cur=k;qa("section").forEach(function(s){s.className=s.id==k?"on":""});scrollTo(0,0);enter(k);' +
'if(m!=2&&(location.hash!="#"+k||location.search))history[m?"replaceState":"pushState"](null,"",location.pathname+"#"+k)}' +
'addEventListener("popstate",function(){go(sec((location.hash||"").slice(1))||first(),2)});' +
'document.addEventListener("click",function(e){var b=e.target.closest("[data-go],[data-cp],[data-sys],[data-nav],[data-tab]");if(!b)return;var d=b.dataset;' +
'if(d.cp){cp(d.cp,d.t);return}if(d.sys){setos(d.sys);return}if(d.tab){tab(d.tab);return}if(d.nav){nav(d.nav);return}go(d.go)});';
let fld = (id, lb, ty, ac, v, x) => '<label for="' + id + '">' + lb + '</label><input id="' + id + '" type="' + ty + '" autocomplete="' + ac + '"' +
(ac == 'name' ? ' autocapitalize="words"' : ty == 'text' ? ' autocapitalize="none" spellcheck="false"' : '') + ' maxlength="' + (ty == 'password' ? 128 : 40) + '"' +
(v ? ' value="' + esc(v) + '"' : '') + '>' + (x ? '<p class="hint">' + x + '</p>' : '');
let back = (k) => '<div class="links"><button class="lk" type="button" data-go="' + k + '">‹ ' + L('Indietro', 'Back') + '</button></div>';

if (!P?.u) {
let u0 = qp('u');
u0 = type(u0) == 'string' && match(u0, /^[A-Za-z0-9._-]{1,40}$/) ? lc(u0) : '';
let msg = P?.blocked ? L('Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator') : P?.busy ? L('Router occupato: riprova', 'Router busy: try again') :
P?.gone ? L('Accesso scaduto: entra di nuovo', 'Access expired: sign in again') : '';
let pw2 = (a, b, lb) => fld(a, lb, 'password', 'new-password', '', L('Almeno 8 caratteri.', 'At least 8 characters.')) + fld(b, L('Ripeti La Password', 'Repeat The Password'), 'password', 'new-password');
let S = '<section id="in"><div class="card form"><span class="sq">' + pci('user', 26) + '</span><h1>' + L('Entra', 'Sign In') + '</h1><p class="sub">' +
L('Gli stessi dati dell\'app.', 'The same details as in the app.') + '</p><form id="fin" novalidate>' +
fld('iu', L('Nome Utente', 'Username'), 'text', 'username', u0) + fld('ip', 'Password', 'password', 'current-password') +
'<p class="err" id="ein" role="alert">' + esc(msg) + '</p><button class="btn pri lg" type="submit">' + L('Entra', 'Sign In') + '</button></form></div>' +
'<div class="links"><button class="lk" type="button" data-go="reg">' + L('Registrati', 'Sign Up') + '</button><button class="lk" type="button" data-go="lost">' +
L('Password Dimenticata', 'Forgot Password') + '</button></div></section>';
S += '<section id="reg"><div class="card form"><h1>' + L('Registrati', 'Sign Up') + '</h1><p class="sub">' + L('Una volta sola, dalla rete di casa.', 'Only once, from the home network.') +
'</p><form id="freg" novalidate>' + fld('rv', L('Nome Visibile', 'Display Name'), 'text', 'name', '', L('Il nome che vede la famiglia e quello della tua cartella.', 'The name the family sees and the name of your folder.')) +
fld('ru', L('Nome Utente', 'Username'), 'text', 'username', '', L('Lo scrivi per entrare: minuscole e numeri. Te lo proponiamo, puoi cambiarlo.', 'You type it to sign in: lowercase and numbers. We suggest one, you can change it.')) +
pw2('rp', 'rp2', 'Password') + pcnote('warn', 'iw', L('I tuoi file restano tuoi: l\'Amministratore non li apre. Se però cancella il tuo utente, può tenere i tuoi file e riaverli.',
'Your files stay yours: the Administrator does not open them. But if they delete your user, they can keep your files and get them back.')) +
'<label class="ckb"><input id="rr" type="checkbox">' + L('Ho Letto', 'I Have Read It') + '</label><p class="err" id="ereg" role="alert"></p>' +
'<button class="btn pri lg" type="submit">' + L('Registrati', 'Sign Up') + '</button></form></div>' + back('in') + '</section>';
S += '<section id="lost"><div class="card form"><h1>' + L('Password Dimenticata', 'Forgot Password') + '</h1><p class="sub">' + L('Serve il codice di recupero.', 'You need the recovery code.') +
'</p><form id="flost" novalidate>' + fld('lu', L('Nome Utente', 'Username'), 'text', 'username', u0) +
fld('lc', L('Codice', 'Code'), 'text', 'one-time-code', '', L('Il codice di recupero o il Codice Di Sblocco che ti ha dato l\'Amministratore.', 'The recovery code or the Unlock Code the Administrator gave you.')) +
pw2('lp', 'lp2', L('Nuova Password', 'New Password')) + '<p class="err" id="elost" role="alert"></p><button class="btn pri lg" type="submit">' + L('Cambia Password', 'Change Password') +
'</button></form></div>' + back('in') + '</section>';
S += '<section id="ok"><div class="card form"><span class="sq ok">' + pci('check', 26, null, 2.4) + '</span><h1>' + L('Fatto', 'Done') + '</h1><p class="sub"><span id="okt"></span> <b id="oku"></b>.</p>' +
'<div id="okr"><p class="m">' + L('Il tuo codice di recupero:', 'Your recovery code:') + '</p><div class="rc" id="okc"></div>' +
pcnote('warn', 'iw', L('Scrivilo e tienilo al sicuro: si vede solo adesso. Serve se dimentichi la password.', 'Write it down and keep it safe: it is shown only now. You need it if you forget the password.')) + '</div>' +
'<form id="fok" novalidate><p class="err" id="eok" role="alert"></p><button class="btn pri lg" type="submit">' + L('Entra', 'Sign In') + '</button></form></div></section>';
let D = { napi: BASE + '/n/api', self: self, en: EN, T: { ...T0, dev: L('Pagina Del Computer', 'Computer Page'), nou: L('Scrivi il Nome Utente', 'Type the Username'),
nop: L('Scrivi la password', 'Type the password'), novis: L('Scrivi il Nome Visibile', 'Type the Display Name'), nocode: L('Scrivi il codice', 'Type the code'),
p8: L('Password di almeno 8 caratteri', 'Password of at least 8 characters'), pdiff: L('Le due password sono diverse', 'The two passwords are different'),
read: L('Leggi l\'avviso sui file', 'Read the notice about the files'), lan: L('Ci si registra dalla rete di casa o con la VPN.', 'You sign up from the home network or with the VPN.'),
closed: L('Registrazione chiusa: chiedi all\'Amministratore.', 'Sign-up closed: ask the Administrator.'), okreg: L('Ti sei registrato come', 'You signed up as'),
okrec: L('Password cambiata per', 'Password changed for') } };
let js = 'var D=' + replace(sprintf('%J', D), '<', '\\u003c') + ',T=D.T,TK=null,cur="",OK={},ued=0,pt=null;' + jsc +
'function first(){return "in"}function setos(){}function tab(){}function nav(){}' +
'function er(i,t){gi(i).textContent=t||""}function bz(f,on){var b=f.querySelector("button[type=submit]");if(b)b.disabled=!!on}' +
'function enter(k){if(k=="reg")tk().then(function(t){if(!t.lan)er("ereg",T.lan);else if(t.reg===false)er("ereg",T.closed)},function(j){er("ereg",em(j))})}' +
'function login(u,p,f,ei){bz(f,1);er(ei);call({act:"login",user:u,pass:p,dev:T.dev,pc:true}).then(function(j){if(j&&j.user&&!j.error){location.replace(D.self);return}bz(f,0);er(ei,em(j))},function(){bz(f,0);er(ei,T.net)})}' +
'function ok(u,p,rc,rec){OK={u:u,p:p};gi("okt").textContent=rec?T.okrec:T.okreg;gi("oku").textContent=u;gi("okc").textContent=rc||"";gi("okr").hidden=!rc;go("ok",1)}' +
'gi("fin").addEventListener("submit",function(e){e.preventDefault();var u=gi("iu").value.trim().toLowerCase(),p=gi("ip").value;if(!u)return er("ein",T.nou);if(!p)return er("ein",T.nop);login(u,p,this,"ein")});' +
'gi("rv").addEventListener("input",function(){clearTimeout(pt);var v=this.value.trim();if(ued||!v)return;pt=setTimeout(function(){post({act:"propose",vis:v}).then(function(j){if(j&&j.user&&!ued)gi("ru").value=j.user},function(){})},400)});' +
'gi("ru").addEventListener("input",function(){ued=1});' +
'gi("freg").addEventListener("submit",function(e){e.preventDefault();var f=this,v=gi("rv").value.trim(),u=gi("ru").value.trim().toLowerCase(),p=gi("rp").value;er("ereg");' +
'if(!v)return er("ereg",T.novis);if(p.length<8)return er("ereg",T.p8);if(p!=gi("rp2").value)return er("ereg",T.pdiff);if(!gi("rr").checked)return er("ereg",T.read);' +
'var b={act:"register",vis:v,pass:p,read:true};if(u)b.user=u;bz(f,1);call(b).then(function(j){bz(f,0);if(j&&j.user&&!j.error)return ok(j.user,p,j.rc,0);er("ereg",em(j))},function(){bz(f,0);er("ereg",T.net)})});' +
'gi("flost").addEventListener("submit",function(e){e.preventDefault();var f=this,u=gi("lu").value.trim().toLowerCase(),c=gi("lc").value.trim(),p=gi("lp").value;er("elost");' +
'if(!u)return er("elost",T.nou);if(!c)return er("elost",T.nocode);if(p.length<8)return er("elost",T.p8);if(p!=gi("lp2").value)return er("elost",T.pdiff);' +
'bz(f,1);post({act:"recover",user:u,code:c,"new":p}).then(function(j){bz(f,0);if(j&&j.ok&&!j.error)return ok(u,p,j.rc,1);er("elost",em(j))},function(){bz(f,0);er("elost",T.net)})});' +
'gi("fok").addEventListener("submit",function(e){e.preventDefault();login(OK.u,OK.p,this,"eok")});' +
'var h=sec((location.hash||"").slice(1));go(h&&h!="ok"?h:"in",1)';
pcpage(200, '<body class="' + os0 + '">' + top(null) + '<main>' + S + foot + '</main>' + toast + '<noscript><p class="sub">JavaScript</p></noscript></body>', js, H);
}

let N = rjs(NJ) ?? {}, SH = pcsh(P.u, P.smb), vis = P.vis, u = esc(P.u);
let on = !nasoff() && SH != null && SH.on, nb = SH?.nb ?? pcnb(N), lip = SH?.lip ?? lip0;
let drv = on ? SH.drv : null, cls = on ? SH.cl : [], shn = on ? SH.sh : null, fhn = on ? SH.fh : null, tmn = on ? SH.tm : null;
let unc = (n) => '\\\\' + (ZN == 'vpn' ? lip : nb) + '\\' + n, smb = (n) => 'smb://' + lip + '/' + urlenc(n);
let prob = nasoff() || SH?.on === false ? pcnote('info', 'ib', L('Spento dall\'Amministratore.', 'Turned off by the Administrator.')) :
SH == null ? pcnote('warn', 'iw', L('Non riesco a leggere le cartelle del NAS: riprova fra poco.', 'Cannot read the NAS folders: try again shortly.') +
'<br><a class="btn" href="' + esc(self) + '">' + L('Riprova', 'Try Again') + '</a>') :
!drv ? pcnote('info', 'ib', L('Il Disco Principale non è collegato: la tua cartella torna quando l\'Amministratore lo ricollega.',
'The Main Drive is not connected: your folder comes back when the Administrator connects it again.')) : '';
let cpt = L('Copia L\'Indirizzo', 'Copy The Address');
let tW = L('Copiato: ora Connetti Unità Di Rete e incollalo', 'Copied: now Map Network Drive and paste it');
let tM = L('Copiato: incollalo in Connessione al server', 'Copied: paste it in Connect to Server');
let tA = L('Copiato: incollalo nel campo Host', 'Copied: paste it in the Host field'), tI = L('Copiato: incollalo in Connetti al server', 'Copied: paste it in Connect to Server');
let cpb = (v, cls, t, tt, o) => '<button class="btn' + cls + '" type="button"' + (o ? ' data-o="' + o + '"' : '') + ' data-cp="' + esc(v) + '" data-t="' + esc(tt) + '">' + t + '</button>';
let fb = (n, cls) => cpb(unc(n), cls, cpt, tW, 'w') + '<a class="btn' + cls + '" data-o="m" href="' + esc(smb(n)) + '">' + L('Apri', 'Open') + '</a>' +
cpb(smb(n), cls, cpt, tM, 'l') + cpb(lip, cls, cpt, tA, 'a') + cpb(smb(n), cls, cpt, tI, 'i');
let fcard = (ic, n, d, cls) => '<div class="card fold"><span class="sq">' + pci(ic, 26) + '</span><div class="fx"><b>' + esc(n) + '</b><small>' + d + '</small></div>' + fb(n, cls) + '</div>';
let dD = L('La tua cartella personale', 'Your personal folder'), dC = L('I file del tuo cloud', 'Your cloud files'), dS = L('La cartella di tutta la casa', 'The folder of the whole home');
let winr = '<span class="nw">' + pckbd('⊞ Windows') + ' + ' + pckbd('R') + '</span>', ctlv = '<span class="nw">' + pckbd('Ctrl') + ' + ' + pckbd('V') + '</span>';
let how = '<p class="sub"><span data-o="w">' + L('Copia l\'indirizzo, poi apri <b>Esplora File › Questo PC › ⋯ › Connetti unità di rete</b>: incollalo in <b>Cartella</b>, spunta <b>Riconnetti all\'accesso</b> e premi <b>Fine</b>. Resta in Questo PC come un disco.',
'Copy the address, then open <b>File Explorer › This PC › ⋯ › Map network drive</b>: paste it in <b>Folder</b>, tick <b>Reconnect at sign-in</b> and press <b>Finish</b>. It stays in This PC like a drive.') +
'</span><span data-o="m">' + L('Un clic e la cartella si apre nel Finder.', 'One click and the folder opens in Finder.') + '</span><span data-o="l">' +
L('Copia l\'indirizzo, poi nel gestore dei file (File, Dolphin) apri <b>Altre posizioni › Connetti al server</b> e incollalo.', 'Copy the address, then in the file manager (Files, Dolphin) open <b>Other Locations › Connect to Server</b> and paste it.') + '</span><span data-o="a">' +
L('Quattro passi con CX File Explorer, una volta sola.', 'Four steps with CX File Explorer, only once.') + '</span><span data-o="i">' +
L('Tre passi nell\'app File, una volta sola.', 'Three steps in the Files app, only once.') + '</span></p>';
let wpic = pcpic(pcrc(0, 0, 250, 140, 8, 'p0') + pcrc(0, 0, 250, 22, 0, 'p1') +
pctx(10, 15, 't2', 10, L('Sicurezza di Windows', 'Windows Security')) + pctx(20, 44, 't1 tb', 11, L('Immetti le credenziali di rete', 'Enter network credentials')) +
pcrc(20, 52, 210, 18, 3, 'p2') + pctx(26, 64, 't2', 9, P.u) + pcrc(20, 76, 210, 18, 3, 'p2') + pctx(26, 88, 't2', 9, '●●●●●●●●') +
pcrc(20, 101, 10, 10, 2, 'p3') + pctx(36, 110, 't1', 9, L('Memorizza credenziali', 'Remember my credentials')) + pcrc(150, 114, 80, 18, 4, 'p3') + pctx(190, 126, 't4', 9, 'OK', 'middle'));
let mpic = pcpic(pcrc(25, 6, 200, 128, 12, 'p0 p7') + pcrc(109, 16, 32, 32, 8, 'p3') +
pctx(125, 64, 't1 tb', 10, L('Connessione a «' + lip + '»', 'Connecting to “' + lip + '”'), 'middle') +
pcrc(45, 72, 160, 16, 4, 'p2') + pctx(51, 83, 't2', 9, P.u) + pcrc(45, 92, 160, 16, 4, 'p2') + pctx(51, 103, 't2', 9, '●●●●●●●●') +
pcrc(45, 114, 9, 9, 2, 'p3') + pctx(59, 122, 't1', 8, L('Ricorda questa password', 'Remember this password')) + pcrc(150, 113, 55, 14, 7, 'p3') +
pctx(177, 123, 't4', 8, L('Connetti', 'Connect'), 'middle'));
let cred = '<div class="card duo" data-o="w">' + wpic + '<p class="m">' + L('Solo la prima volta il computer chiede nome e password: scrivi <b>' + u + '</b> e la tua password, poi spunta <b>Memorizza credenziali</b>.',
'Only the first time the computer asks for name and password: type <b>' + u + '</b> and your password, then tick <b>Remember my credentials</b>.') + '</p></div>' +
'<div class="card duo" data-o="m">' + mpic + '<p class="m">' + L('Solo la prima volta il Mac chiede nome e password: scrivi <b>' + u + '</b> e la tua password, poi spunta <b>Ricorda questa password</b>.',
'Only the first time the Mac asks for name and password: type <b>' + u + '</b> and your password, then tick <b>Remember this password</b>.') + '</p></div>' +
'<div class="card duo" data-o="l"><p class="m">' + L('Solo la prima volta chiede nome e password: scegli <b>Utente registrato</b>, scrivi <b>' + u + '</b> e la tua password, poi <b>Ricorda per sempre</b>.',
'Only the first time it asks for name and password: choose <b>Registered User</b>, type <b>' + u + '</b> and your password, then <b>Remember forever</b>.') + '</p></div>';
let fmob = (n) => '<div class="card ps" data-o="a"><h3>' + L('Passi Su Android', 'Steps On Android') + '</h3>' +
'<p><b>1.</b> ' + L('Installa <b>CX File Explorer</b> (gratis su Play Store) e aprilo.', 'Install <b>CX File Explorer</b> (free on Play Store) and open it.') + '</p>' +
'<p><b>2.</b> ' + L('Tocca <b>Rete › Nuova › SMB</b>.', 'Tap <b>Network › New › SMB</b>.') + '</p>' +
'<p><b>3.</b> ' + L('Nel campo Host incolla <b>' + esc(lip) + '</b>, poi scrivi <b>' + u + '</b> e la tua password e tocca <b>OK</b>.',
'In the Host field paste <b>' + esc(lip) + '</b>, then type <b>' + u + '</b> and your password and tap <b>OK</b>.') + '</p>' +
'<p><b>4.</b> ' + L('Apri la cartella <b>' + esc(n) + '</b>.', 'Open the <b>' + esc(n) + '</b> folder.') + '</p></div>' +
'<div class="card ps" data-o="i"><h3>' + L('Passi Su iPhone e iPad', 'Steps On iPhone and iPad') + '</h3>' +
'<p><b>1.</b> ' + L('Copia l\'indirizzo, poi apri l\'app <b>File</b> e tocca <b>Sfoglia › ··· › Connetti al server</b>.', 'Copy the address, then open the <b>Files</b> app and tap <b>Browse › ··· › Connect to Server</b>.') + '</p>' +
'<p><b>2.</b> ' + L('Incolla l\'indirizzo e tocca <b>Connetti</b>.', 'Paste the address and tap <b>Connect</b>.') + '</p>' +
'<p><b>3.</b> ' + L('Scegli <b>Utente registrato</b>, scrivi <b>' + u + '</b> e la tua password, poi tocca <b>Avanti</b>.',
'Choose <b>Registered User</b>, type <b>' + u + '</b> and your password, then tap <b>Next</b>.') + '</p></div>';
let fmob2 = (n) => pcnote('phone', 'ig', L('Nello stesso server di CX File Explorer apri la cartella <b>' + esc(n) + '</b>.', 'In the same CX File Explorer server open the <b>' + esc(n) + '</b> folder.'), 'a') +
pcnote('phone', 'ig', L('Copia l\'indirizzo e collegalo come il Drive, in <b>Connetti al server</b> dell\'app File.', 'Copy the address and connect it like the Drive, in <b>Connect to Server</b> of the Files app.'), 'i');
let DJ = rjs('/tmp/wf-nas/dfs.json') ?? {}, dfsm = index(type(DJ.users) == 'array' ? DJ.users : [], P.u) >= 0 ? '' + DJ.mode : '';
let dpo = match('' + (N.remote?.port ?? 5005), /^[0-9]{1,5}$/) ? '' + (N.remote?.port ?? 5005) : '5005', dvn = drv?.dav;
let dunc = dvn ? '\\\\' + nb + '@' + dpo + '\\DavWWWRoot\\' + dvn : null, durl = dvn ? 'http://' + lip + ':' + dpo + '/' + urlenc(dvn) + '/' : null;
let nav = (pri) => '<div class="nav"><button class="lk" type="button" data-nav="prev">‹ ' + L('Indietro', 'Back') + '</button><button class="btn' + (pri ? ' pri' : '') +
'" type="button" data-nav="next">' + L('Avanti ›', 'Next ›') + '</button></div>';
let ph = pcnote('pc', 'iw', L('Questa pagina è per il computer: aprila sul PC o sul Mac di casa.', 'This page is for the computer: open it on the home PC or Mac.') +
'<br><a class="btn" href="mailto:?subject=' + urlenc(L('I Miei File Sul Computer', 'My Files on the Computer')) + '&amp;body=' +
urlenc(L('Apri questo indirizzo sul computer di casa: ', 'Open this address on your home computer: ') + 'http://' + lip + '/pc') + '">' +
L('Mandala Per Email', 'Send It By Email') + '</a>', 'i');
let vpnt = L('Le cartelle si aprono solo a casa, o dalla VPN con <b>Samba (SMB)</b> acceso in <b>Accesso Remoto</b>.', 'The folders open only at home, or from the VPN with <b>Samba (SMB)</b> turned on in <b>Remote Access</b>.');
let vpn0 = ZN == 'vpn' && N.remote?.smbvpn !== true ? pcnote('warn', 'iw', vpnt) : '';
let S = {};
S.sys = '<h1>' + L('Che Dispositivo Usi?', 'Which Device Do You Use?') + '</h1><p class="sub">' + L('L\'abbiamo riconosciuto dal browser: cambialo se non è giusto.', 'We detected it from the browser: change it if it is wrong.') + '</p>' +
'<div class="opts">' + join('', map([ [ 'w', 'pc' ], [ 'm', 'laptop' ], [ 'l', 'laptop' ], [ 'a', 'phone' ], [ 'i', 'phone' ] ], (x) => '<button class="card opt" type="button" data-sys="' + x[0] + '">' +
pci(x[1], 30) + '<span>' + OSN[x[0]] + '</span></button>')) + '</div><div class="stack" style="margin-top:14px">' + ph + '</div>' + nav(true);
S.drv = '<h1>' + L('Apri Il Tuo Drive', 'Open Your Drive') + '</h1>' + (drv ? how + '<div class="stack">' + vpn0 + fcard('folder', drv.name, dD, ' pri') + cred + fmob(drv.name) +
(dfsm == 'dfs' ? pcnote('folder', 'ib', L('Dentro trovi anche <b>Cartella Condivisa</b> e <b>Cartella Pubblica</b>.', 'Inside you also find <b>Cartella Condivisa</b> and <b>Cartella Pubblica</b>.'), 'w m l') : '') +
pcnote('star', 'ig', '<b>' + L('Per ritrovarla ogni giorno:', 'To find it every day:') + '</b> <span data-o="w">' +
L('nella finestra che si apre, tasto destro sulla cartella e <b>Aggiungi ad Accesso rapido</b>.', 'in the window that opens, right-click the folder and <b>Pin to Quick access</b>.') + '</span><span data-o="m">' +
L('trascinala nella barra a sinistra del Finder.', 'drag it to the Finder sidebar.') + '</span><span data-o="l">' +
L('aggiungila ai segnalibri del gestore dei file (Ctrl + D).', 'add it to the file manager bookmarks (Ctrl + D).') + '</span>', 'w m l') + '</div>' : '<div class="stack">' + vpn0 + prob + '</div>') + nav(!drv);
if (length(cls)) S.cl = '<h1>' + L('Apri Il Tuo Cloud', 'Open Your Cloud') + '</h1>' + how + '<div class="stack">' +
join('', map(cls, (n) => fcard('cloud', n, dC, length(cls) == 1 ? ' pri' : ''))) + fmob2(cls[0]) + '</div>' + nav(false);
if (shn) S.sh = '<h1>' + L('Apri La Cartella Condivisa', 'Open The Shared Folder') + '</h1><p class="sub">' + L('La vede tutta la casa: mettici quello che serve a tutti.', 'The whole home sees it: put there what everyone needs.') +
'</p><div class="stack">' + fcard('shared', shn, dS, ' pri') + fmob2(shn) + '</div>' + nav(false);
let step = (n, t, pic, p, b) => '<div class="card step"><span class="n">' + n + '</span><h3>' + t + '</h3>' + pic + '<p>' + p + '</p>' + (b ?? '') + '</div>';
let first = pcnote('clock', 'ig', L('La prima copia può durare qualche ora: lascia il computer acceso e a casa.', 'The first copy can take a few hours: leave the computer on and at home.'));
let wsteps = !fhn ? '' : '<div class="g" data-o="w">' +
step(1, L('Collega Il Disco Del Backup', 'Connect The Backup Drive'), wpic,
L('Premi <b>Copia L\'Indirizzo</b>, poi insieme ' + winr + ', incolla e premi ' + pckbd('Invio') + '. Scrivi <b>' + u + '</b> e la tua password, poi spunta <b>Memorizza credenziali</b>.',
'Press <b>Copy The Address</b>, then ' + winr + ' together, paste and press ' + pckbd('Enter') + '. Type <b>' + u + '</b> and your password, then tick <b>Remember my credentials</b>.'),
cpb(unc(fhn), ' pri', cpt, L('Copiato: ora premi Windows + R, incolla e premi Invio', 'Copied: now press Windows + R, paste and press Enter'))) +
step(2, L('Apri Cronologia File', 'Open File History'), pcpic(pcrc(0, 0, 250, 140, 8, 'p0') + pcrc(40, 14, 170, 22, 11, 'p5') + pctx(56, 29, 't1', 10, L('Cronologia file', 'File History')) +
pctx(20, 56, 't3', 9, L('Corrispondenza migliore', 'Best match')) + pcrc(16, 62, 218, 44, 6, 'p4') + pcrc(26, 72, 24, 24, 5, 'p3') +
pctx(60, 82, 't1 tb', 10, L('Cronologia file', 'File History')) + pctx(60, 96, 't2', 9, L('Pannello di controllo', 'Control Panel'))),
L('Premi il tasto ' + pckbd('⊞ Windows') + ', scrivi <b>Cronologia file</b> e apri il primo risultato.', 'Press the ' + pckbd('⊞ Windows') + ' key, type <b>File History</b> and open the first result.')) +
step(3, L('Scegli Il NAS e Attiva', 'Choose The NAS and Turn On'), pcpic(pcrc(0, 0, 250, 140, 8, 'p0') + pctx(14, 22, 't1 tb', 11, L('Seleziona unità', 'Select drive')) +
pcrc(14, 32, 222, 40, 4, 'p4') + pctx(24, 50, 't1', 10, fhn) + pctx(24, 63, 't3', 9, nb) + pctx(14, 90, 't5', 9, L('Seleziona percorso di rete', 'Add network location')) +
pcrc(120, 108, 54, 20, 4, 'p3') + pctx(147, 121, 't4', 9, 'OK', 'middle') + pcrc(180, 108, 56, 20, 4, 'p1') + pctx(208, 121, 't1', 9, L('Annulla', 'Cancel'), 'middle')),
L('Premi <b>Seleziona unità</b>, poi <b>Seleziona percorso di rete</b>: incolla l\'indirizzo nella casella Cartella e premi <b>Seleziona cartella</b>. Poi <b>OK</b> e <b>Attiva</b>.',
'Press <b>Select drive</b>, then <b>Add network location</b>: paste the address in the Folder box and press <b>Select Folder</b>. Then <b>OK</b> and <b>Turn on</b>.')) + '</div>' +
pcnote('help', 'ig', '<b>' + L('L\'indirizzo non si incolla?', 'The address does not paste?') + '</b> ' +
L('Copialo di nuovo e incollalo nella casella Cartella del passo 3.', 'Copy it again and paste it in the Folder box of step 3.') +
'<br>' + cpb(unc(fhn), '', cpt, L('Copiato: incollalo nella casella Cartella', 'Copied: paste it in the Folder box')), 'w');
let msteps = !tmn ? '' : '<div class="g" data-o="m">' +
step(1, L('Collega Il Disco Del Backup', 'Connect The Backup Drive'), mpic,
L('Premi <b>Collega Il Disco</b>, lascia aprire il Finder, scrivi <b>' + u + '</b> e la tua password, poi spunta <b>Ricorda questa password</b>.',
'Press <b>Connect The Drive</b>, let Finder open, type <b>' + u + '</b> and your password, then tick <b>Remember this password</b>.'),
'<a class="btn pri" href="' + esc(smb(tmn)) + '">' + L('Collega Il Disco', 'Connect The Drive') + '</a>') +
step(2, L('Apri Time Machine', 'Open Time Machine'), pcpic(pcrc(0, 0, 250, 140, 10, 'p0') + pcrc(0, 0, 80, 140, 0, 'p1') + pcrc(6, 14, 68, 18, 4, 'p8') +
pctx(12, 26, 't1', 9, L('Generali', 'General')) + pctx(12, 46, 't3', 9, L('Aspetto', 'Appearance')) + pctx(12, 62, 't3', 9, 'Wi-Fi') +
pctx(96, 22, 't1 tb', 11, L('Generali', 'General')) + pcrc(92, 32, 146, 18, 4, 'p1') + pctx(100, 44, 't2', 9, L('Info', 'About')) +
pcrc(92, 52, 146, 18, 4, 'p1') + pctx(100, 64, 't2', 9, L('Aggiornamento Software', 'Software Update')) + pcrc(92, 72, 146, 18, 4, 'p4') +
pctx(100, 84, 't1 tb', 9, 'Time Machine') + pcrc(92, 92, 146, 18, 4, 'p1') + pctx(100, 104, 't2', 9, L('Trasferisci o inizializza', 'Transfer or Reset'))),
L('Apri <b>Impostazioni di Sistema</b> (menu con la mela in alto a sinistra), poi <b>Generali</b> e <b>Time Machine</b>.',
'Open <b>System Settings</b> (Apple menu at the top left), then <b>General</b> and <b>Time Machine</b>.')) +
step(3, L('Scegli Il NAS', 'Choose The NAS'), pcpic(pcrc(0, 0, 250, 140, 10, 'p0') + pctx(14, 22, 't1 tb', 10, L('Seleziona il disco di backup', 'Select a backup disk')) +
pcrc(14, 32, 222, 34, 6, 'p4') + pcrc(22, 40, 18, 18, 4, 'p3') + pctx(48, 48, 't1 tb', 9, tmn) + pctx(48, 60, 't2', 8, lip) +
pcrc(146, 108, 90, 20, 5, 'p3') + pctx(191, 121, 't4', 9, L('Configura disco', 'Set Up Disk'), 'middle')),
L('Premi <b>Aggiungi disco di backup</b>, scegli <b>' + esc(tmn) + '</b>, poi <b>Configura disco</b> e <b>Fine</b>.',
'Press <b>Add Backup Disk</b>, choose <b>' + esc(tmn) + '</b>, then <b>Set Up Disk</b> and <b>Done</b>.')) + '</div>' +
pcnote('help', 'ig', '<b>' + L('Il disco non si collega?', 'The drive does not connect?') + '</b> ' +
L('Nel Finder scegli <b>Vai › Connessione al server</b>, incolla l\'indirizzo e premi <b>Connetti</b>.', 'In Finder choose <b>Go › Connect to Server</b>, paste the address and press <b>Connect</b>.') +
'<br>' + cpb(smb(tmn), '', cpt, tM), 'm');
let stat = '<div class="card done wt" id="st"><span class="sq ck">' + pci('check', 34, 'i1', 2.4) + pci('clock', 30, 'i2') + pci('warn', 30, 'i3') + '</span>' +
'<div class="hx"><h2 id="sh"></h2><p class="m" id="sp"></p></div><span class="chip bl" id="sc"></span></div>';
if (fhn || tmn) S.bk = '<h1>' + L('Backup Di Questo Computer', 'Back Up This Computer') + '</h1><p class="sub"><span data-o="w">' +
L('Tre passi, una volta sola. Poi Windows salva da solo i tuoi documenti sul NAS ogni ora.', 'Three steps, only once. Then Windows saves your documents on the NAS by itself every hour.') + '</span><span data-o="m">' +
L('Tre passi, una volta sola. Poi il Mac salva da solo una copia di tutto sul NAS ogni ora.', 'Three steps, only once. Then the Mac saves a copy of everything on the NAS by itself every hour.') + '</span></p>' +
'<div class="stack">' + wsteps + msteps + first + stat + '</div>' + nav(false);
let chk = (ic, t, p) => '<div class="card"><span class="sq s">' + pci(ic, 22) + '</span><h3>' + t + '</h3><p>' + p + '</p></div>';
S.fin = '<div class="card done"><span class="sq ck">' + pci('check', 34, null, 2.4) + '</span><div class="hx"><h1>' + L('Fatto', 'Done') + '</h1><p class="m">' +
L('Le tue cartelle sono pronte: la prossima volta le trovi subito qui.', 'Your folders are ready: next time you find them right here.') + '</p></div></div>' +
'<div id="fbk"' + (fhn || tmn ? '' : ' hidden') + '><h2 class="h">' + L('Come Controllare Che Funzioni', 'How To Check It Works') + '</h2>' +
'<div class="g chk">' + chk('phone', L('Nell\'App Sul Telefono', 'In The Phone App'), L('Scheda Backup › Backup Del Computer: c\'è l\'ultima copia.', 'Backup tab › Computer Backup: the last copy is there.')) +
chk('pc', L('Sul Computer', 'On The Computer'), '<span data-o="w">' + L('Riapri Cronologia file: dice quando ha copiato i file l\'ultima volta.', 'Open File History again: it says when it last copied the files.') +
'</span><span data-o="m">' + L('In Time Machine guarda l\'ultimo backup.', 'In Time Machine look at the latest backup.') + '</span>') +
chk('undo', L('Prova A Recuperare Un File', 'Try Restoring A File'), '<span data-o="w">' + L('Cronologia file › <b>Ripristina i file personali</b>.', 'File History › <b>Restore personal files</b>.') +
'</span><span data-o="m">' + L('Apri Time Machine dalle Applicazioni.', 'Open Time Machine from Applications.') + '</span> ' +
L('Se vedi i tuoi file con la data, funziona.', 'If you see your files with the date, it works.')) + '</div><div class="stack" style="margin-top:14px">' +
pcnote('warn', 'iw', '<b>' + L('Se per un giorno non arriva nessuna copia', 'If no copy arrives for a day') + '</b>, ' +
L('l\'app sul telefono te lo dice. Basta che il computer sia acceso a casa ogni tanto.', 'the phone app tells you. The computer just needs to be on at home now and then.')) + '</div></div>' +
'<div class="nav"><button class="lk" type="button" data-nav="prev">‹ ' + L('Indietro', 'Back') + '</button><button class="btn pri" type="button" data-go="home">' +
L('Vai Alle Tue Cartelle', 'Go To Your Folders') + '</button></div>';
let tabs = [ [ 'drv', 'Drive', drv ? fcard('folder', drv.name, dD, ' pri') : prob ] ];
if (length(cls)) push(tabs, [ 'cl', 'Cloud', '<div class="stack">' + join('', map(cls, (n) => fcard('cloud', n, dC, ' pri'))) + '</div>' ]);
if (shn) push(tabs, [ 'sh', L('Cartella Condivisa', 'Shared Folder'), fcard('shared', shn, dS, ' pri') ]);
let tbb = '', tbp = '';
for (let i = 0; i < length(tabs); i++) {
let t = tabs[i];
tbb += '<button type="button" role="tab" data-tab="' + t[0] + '"' + (i ? '' : ' class="on"') + ' aria-selected="' + (i ? 'false' : 'true') + '">' + t[1] + '</button>';
tbp += '<div class="tp' + (i ? '' : ' on') + '" id="tp-' + t[0] + '" role="tabpanel">' + t[2] + '</div>';
}
let hn = trim(readfile('/proc/sys/kernel/hostname') ?? ''), crn = join(', ', map(uniq(filter([ hn, nb, lip ], (x) => length(x) > 0)), (x) => '«' + esc(x) + '»'));
let ew = filter([ drv?.name, ...cls, shn, fhn ], (x) => x != null), em = filter([ drv?.name, ...cls, shn, tmn ], (x) => x != null);
let ecode = (A, f) => join(' · ', map(A, (n) => '<code>' + esc(f(n)) + '</code>'));
let exp = '<details class="c"><summary>' + L('Per Esperti', 'For Experts') + '</summary>' + (length(ew) ? '<p>Windows: ' + ecode(ew, unc) + '</p>' : '') +
(length(em) ? '<p>Mac (Finder › ' + L('Vai › Connessione al server', 'Go › Connect to Server') + '): ' + ecode(em, smb) + '</p>' : '') +
'<p>Android (CX File Explorer › SMB): Host <code>' + esc(lip) + '</code></p>' + (dfsm == 'dav' && dunc ? '<p>WebDAV: <code>' + esc(dunc) + '</code> · <code>' + esc(durl) + '</code></p>' : '') +
'<p class="m">' + L('Nome Utente', 'Username') + ': <code>' + u + '</code></p></details>';
let help = '<details class="c"><summary>' + L('Non si apre? Chiede un altro nome?', 'Does Not Open? Asks For Another Name?') + '</summary><div class="stack">' +
pcnote('warn', 'ig', '<b>' + L('Chiede un altro nome o dà errore?', 'Asks for another name or shows an error?') + '</b> ' +
L('Per esempio 1219, accesso negato o cartella vuota: apri <b>Pannello di controllo › Gestione credenziali › Credenziali di Windows</b>, rimuovi le voci ' + crn + ', poi riprova.',
'For example 1219, access denied or an empty folder: open <b>Control Panel › Credential Manager › Windows Credentials</b>, remove the entries ' + crn + ', then try again.') +
'<span class="m2">' + L('Per esperti: ', 'For experts: ') + '<code>net use * /delete</code></span>', 'w') +
(drv ? pcnote('help', 'ig', '<b>' + L('Non si apre niente?', 'Nothing opens?') + '</b> <span data-o="w">' +
L('Apri <b>Esplora File</b>, incolla l\'indirizzo con ' + ctlv + ' nella barra in alto e premi ' + pckbd('Invio') + '.',
'Open <b>File Explorer</b>, paste the address with ' + ctlv + ' in the top bar and press ' + pckbd('Enter') + '.') +
' ' + L('Se il nome del NAS non si trova, usa l\'indirizzo con l\'IP:', 'If the NAS name is not found, use the address with the IP:') + '<br>' +
cpb('\\\\' + lip + '\\' + drv.name, '', cpt, tW) + '</span><span data-o="m">' +
L('Nel Finder scegli <b>Vai › Connessione al server</b>, incolla l\'indirizzo e premi <b>Connetti</b>.', 'In Finder choose <b>Go › Connect to Server</b>, paste the address and press <b>Connect</b>.') +
'<br>' + cpb(smb(drv.name), '', cpt, tM) + '</span><span data-o="l">' +
L('Nel gestore dei file premi ' + pckbd('Ctrl') + ' + ' + pckbd('L') + ', incolla l\'indirizzo e premi ' + pckbd('Invio') + '.', 'In the file manager press ' + pckbd('Ctrl') + ' + ' + pckbd('L') + ', paste the address and press ' + pckbd('Enter') + '.') +
'<br>' + cpb(smb(drv.name), '', cpt, tM) + '</span>', 'w m l') : '') +
(dfsm == 'dav' && dunc ? pcnote('folder', 'ib', '<b>' + L('Vuoi la Cartella Condivisa dentro il Drive?', 'Want the Shared Folder inside the Drive?') + '</b> <span data-o="w">' +
L('In Esplora File scegli <b>Questo PC › Connetti unità di rete</b>, incolla l\'indirizzo nella casella Cartella e premi <b>Fine</b>.',
'In File Explorer choose <b>This PC › Map network drive</b>, paste the address in the Folder box and press <b>Finish</b>.') + '<br>' +
cpb(dunc, '', cpt, L('Copiato: incollalo nella casella Cartella', 'Copied: paste it in the Folder box')) + '</span><span data-o="m">' +
L('Nel Finder scegli <b>Vai › Connessione al server</b>, incolla l\'indirizzo e premi <b>Connetti</b>.', 'In Finder choose <b>Go › Connect to Server</b>, paste the address and press <b>Connect</b>.') +
'<br>' + cpb(durl, '', cpt, tM) + '</span>', 'w m') : '') +
pcnote('info', 'ib', vpnt) + ph + exp + '</div></details>';
S.home = '<h1>' + L('Ciao ', 'Hi ') + esc(vis) + '</h1><p class="sub">' + L('Le tue cartelle sul NAS, a portata di clic.', 'Your NAS folders, one click away.') + '</p>' + vpn0 +
(length(tabs) > 1 ? '<div class="tabs" role="tablist">' + tbb + '</div>' : '') + tbp +
(fhn || tmn ? '<button class="card rowb" type="button" id="hbr" data-go="bk"><span class="sq ok s">' + pci('shield', 22) + '</span><span class="fx"><b>' +
L('Backup Di Questo Computer', 'Back Up This Computer') + '</b><small id="hbk"></small></span><span class="chip" id="hbc"></span><span class="ar">›</span></button>' : '') +
'<div class="acts"><button class="btn" type="button" data-go="sys">' + L('Rifai Il Percorso Guidato', 'Redo The Guided Setup') + '</button></div>' + help;
let body = '<body class="' + os0 + '">' + top(P) + '<main><div class="stp" id="stp" hidden><span class="dots" id="dots"></span><span id="stn"></span></div>';
for (let k in [ 'sys', 'drv', 'cl', 'sh', 'bk', 'fin', 'home' ]) if (S[k]) body += '<section id="' + k + '">' + S[k] + '</section>';
body += foot + '</main>' + toast + '<noscript><p class="sub">JavaScript</p></noscript></body>';
let D = { api: BASE + '/pc/api', napi: BASE + '/n/api', self: self, os: os0, en: EN, u: P.u, vis: vis, pc: pcbk(P.u),
has: { cl: length(cls) > 0, sh: shn != null, fh: fhn != null, tm: tmn != null }, T: { ...T0,
step: L('Passo %1 di %2', 'Step %1 of %2'), none: L('Ancora nessun backup', 'No backup yet'),
wait: L('Aspettiamo Il Computer…', 'Waiting For The Computer…'), waitp: L('Quando il NAS vede il tuo computer, qui compare Fatto. Controlliamo ogni 10 secondi.', 'When the NAS sees your computer, Done appears here. We check every 10 seconds.'),
ok: L('Fatto, Il Backup È Acceso', 'Done, Backup Is On'), first: L('Il NAS ha visto il tuo computer: la prima copia è in corso. Da ora in poi fa tutto da solo.', 'The NAS has seen your computer: the first copy is running. From now on it does everything by itself.'),
last: L('Ultima copia: ', 'Last copy: '), warn: L('L\'ultima copia non è andata bene: l\'app sul telefono ti dice cosa fare.', 'The last copy did not go well: the phone app tells you what to do.'),
cw: L('In Attesa', 'Waiting'), cr: L('In Corso', 'Running'), co: L('Attivo', 'On'), cx: L('Da Controllare', 'Check It') } };
let js = 'var D=' + replace(sprintf('%J', D), '<', '\\u003c') + ',T=D.T,TK=null,cur="",tm=null,K="wfpc-ok-"+D.u;' + jsc +
'function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(x){}return null}' +
'function bkon(){return D.os=="w"&&D.has.fh||D.os=="m"&&D.has.tm}' +
'function steps(){var s=["sys","drv"];if(D.has.cl)s.push("cl");if(D.has.sh)s.push("sh");if(bkon())s.push("bk");s.push("fin");return s}' +
'function first(){return ls(K)?"home":"sys"}' +
'function stp(){var s=steps(),i=s.indexOf(cur),e=gi("stp");e.hidden=i<0;if(i<0)return;gi("stn").textContent=T.step.replace("%1",i+1).replace("%2",s.length);' +
'gi("dots").innerHTML=s.map(function(x,j){return "<i class="+(j<i?"ok":j==i?"on":"no")+"></i>"}).join("")}' +
'function enter(k){stp();clearInterval(tm);if(k=="bk"){poll();tm=setInterval(poll,10000)}else if(k=="home"&&bkon())poll();if(k=="fin")ls(K,"1")}' +
'function setos(o){D.os=o;document.body.className=o;gi("osel").value=o;ls("wfpc-os",o);qa("[data-sys]").forEach(function(b){b.classList.toggle("on",b.dataset.sys==o)});' +
'var r=gi("hbr");if(r)r.hidden=!bkon();gi("fbk").hidden=!bkon();if(cur=="bk"&&!bkon())go("fin",1);else stp()}' +
'function nav(d){var s=steps(),i=s.indexOf(cur);if(d=="next")go(s[i+1]||"home");else go(i>0?s[i-1]:"home")}' +
'function tab(t){qa("[data-tab]").forEach(function(b){b.classList.toggle("on",b.dataset.tab==t);b.setAttribute("aria-selected",b.dataset.tab==t)});qa(".tp").forEach(function(p){p.classList.toggle("on",p.id=="tp-"+t)})}' +
'function z(n){return(n<10?"0":"")+n}function fmt(t){var d=new Date(t*1000),n=new Date();return d.toDateString()==n.toDateString()?z(d.getHours())+":"+z(d.getMinutes()):z(d.getDate())+"/"+z(d.getMonth()+1)+(d.getFullYear()!=n.getFullYear()?"/"+d.getFullYear():"")}' +
'function pst(p){var d=!!p&&p.st!="none"&&p.st!="off",w=d&&(p.st=="warn"||p.st=="bad"),cc=!d?T.cw:w?T.cx:p.st=="run"?T.cr:T.co,ck="chip "+(!d||p.st=="run"?"bl":w?"wr":"ok"),e=gi("st"),h=gi("hbk");' +
'if(e){e.className="card done"+(d?(w?" wr":""):" wt");gi("sh").textContent=d?T.ok:T.wait;gi("sp").textContent=!d?T.waitp:w?T.warn:p.last>0?T.last+fmt(p.last):T.first;gi("sc").textContent=cc;gi("sc").className=ck}' +
'if(h){h.textContent=p&&p.last>0?T.last+fmt(p.last):T.none;gi("hbc").textContent=cc;gi("hbc").className=ck}}' +
'function poll(){fetch(D.api,{cache:"no-store",credentials:"same-origin"}).then(function(r){if(r.status==401){location.replace(D.self);throw 0}return r.json()}).then(function(j){if(j&&j.pc)pst(j.pc)}).catch(function(){})}' +
'gi("osel").addEventListener("change",function(){setos(this.value)});' +
'gi("out").addEventListener("click",function(){var b=this;b.disabled=true;call({act:"logout"}).then(function(j){if(j&&(j.ok||j.code=="who"||j.code=="blocked"))return location.replace(D.self);b.disabled=false;toast(em(j))},function(){b.disabled=false;toast(T.net)})});' +
'var o=ls("wfpc-os");if(!o){o=D.os;if(o=="m"&&1<(navigator.maxTouchPoints||0))o="i"}gi("av").textContent=(Array.from(D.vis)[0]||"?").toUpperCase();setos(o);pst(D.pc);' +
'go(sec((location.hash||"").slice(1))||first(),1)';
pcpage(200, body, js, H);
}

let LK = null;
try { LK = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')()?.LKIND; } catch (e) { LK = null; }
let m = match(uri, /^\/([a-z])\/([A-Za-z0-9_-]+)(\/.*)?$/);
if (m && index(type(LK) == 'array' ? LK : [], m[1]) < 0) m = null;
if (!m || length(m[2]) < 16 || length(m[2]) > 64) fail(404, 'Link non trovato', 'Link not found');
kind = m[1]; tok = m[2];
let rest = m[3] ?? '';
if (!loc && (length(BASE) || !https)) fail(403, 'Solo da casa o dalla VPN', 'Home or VPN only');
if (meth == 'OPTIONS') {
hdr(204, { ...cors(), 'Access-Control-Allow-Methods': 'GET, HEAD, PUT, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Range, Content-Type, X-Mtime', 'Access-Control-Max-Age': '600', Allow: 'GET, HEAD, POST, PUT, OPTIONS' });
exit(0);
}

if (kind == 'p') {
let P = rjs(X + '/probe.json');
if (!P || P.tok != tok || now >= (P.until ?? 0)) fail(404, 'Prova finita', 'Test ended');
let self = ip == lc(replace(getenv('SERVER_ADDR') ?? '', /^::ffff:/, '')) || ip == (rjs(X + '/wan.json')?.ip ?? '');
if (self) { if (!P.ok && P['from'] != 'self') { P['from'] = 'self'; P.self_t = now; wjs(X + '/probe.json', P); } }
else if (!P.ok) { P.ok = true; P.ok_t = now; P['from'] = loc ? 'home' : 'net'; wjs(X + '/probe.json', P); }
html(200, L('Raggiungibile', 'Reachable'), '<div class="c"><p>' + L('Il NAS si raggiunge da qui. Puoi chiudere la pagina.', 'The NAS is reachable from here. You can close this page.') + '</p></div>', null);
}

if (kind == 'c') {
if (!loc) fail(403, 'Solo da casa o dalla VPN', 'Home or VPN only');
if (meth != 'GET' && !head) fail(405, 'Solo lettura', 'Read only', { Allow: 'GET, HEAD' });
let I = rjs('/tmp/wf-nas/invite.json') ?? {}, e = I[tok];
if (type(e) != 'object' || (e.until ?? 0) <= now || (rjs(NJ) ?? {}).users?.[e.user]?.blocked === true)
fail(410, 'Invito scaduto: chiedine uno nuovo', 'Invitation expired: ask for a new one');
let N = rjs(NJ) ?? {}, os = reqos(), lip = pclan(), sh = pcdrv(N, e.user);
let smb = 'smb://' + lip + '/' + urlenc(sh), win = '\\\\' + pcnb(N) + '\\' + sh, wip = '\\\\' + lip + '\\' + sh, st = connsteps();
let orw = '<li><span class="n">' + L('Oppure', 'Or') + '</span><b>' + esc(wip) + '</b></li>';
let rows = '<li><span class="n">' + L('Utente', 'User') + '</span><b>' + esc(e.user ?? '') + '</b></li>' +
'<li><span class="n">' + L('Indirizzo', 'Address') + '</span><b>' + esc(os == 'win' ? win : os == 'android' ? lip : smb) + '</b></li>' +
(os == 'win' ? orw : '') +
(os == 'android' ? '<li><span class="n">' + L('Cartella', 'Folder') + '</span><b>' + esc(sh) + '</b></li>' : '') +
(os == '' ? '<li><span class="n">Windows</span><b>' + esc(win) + '</b></li>' + orw : '');
let steps = length(os) ? '<p>' + esc(st[os]) + '</p>' : join('', map([ 'ios', 'android', 'win', 'mac', 'linux' ], (k) => '<p>' + esc(st[k]) + '</p>'));
html(200, L('Collega Questo Dispositivo', 'Connect This Device'), '<p class="m">' + esc(e.label ?? e.user ?? '') + '</p><div class="c"><ul>' + rows + '</ul></div>' +
'<div class="c">' + steps + '<p class="m">' + L('La password è quella dell\'utente del NAS, scelta dalla persona.', 'The password is the NAS user\'s own, chosen by the person.') + '</p></div>', null);
}

if (kind == 't') {
let SF = X + '/st/' + tok + '.json', e = rjs(SF);
if (!loc && !farok(e?.own, e?.p)) fail(403, 'Solo da casa o dalla VPN', 'Home or VPN only');
if (meth != 'GET' && !head) fail(405, 'Solo lettura', 'Read only', { Allow: 'GET, HEAD' });
if (type(e) == 'object' && exists(e, 'cr')) {
if (!crok(e.cr)) { crgone(SF, e.cr); fail(404, 'File non trovato', 'File not found'); }
if (now - (e.a ?? 0) >= SIDLE || now - (e.t ?? 0) >= SMAX || !(now < (e.x ?? 0)) || ownoff(e.own)) { crgone(SF, e.cr); fail(410, 'Lettura finita: riapri il file', 'Playback ended: open the file again'); }
if (now - (e.a ?? 0) >= 60 && stat(SF)) { e.a = now; wjs(SF, e); }
let cn = replace('' + (e.n ?? ''), /[\/[:cntrl:]]/g, '');
cserve(e.cr, length(cn) && cn != '.' && cn != '..' ? cn : 'file', qp('dl') == '1', cors());
}
let cj = type(e) == 'object' && exists(e, 'cloud') ? e.cloud : null, cf = cj != null;
let cok = cf && type(cj) == 'string' && match(cj, /^j[0-9a-z]{4,24}$/) != null && e.p === CDL + '/' + cj;
let cgone = () => { unlink(SF); if (cok) { unlink(e.p); unlink(e.p + '.tok'); } };
if (cf && !cok) fail(404, 'File non trovato', 'File not found');
if (type(e) != 'object' || now - (e.a ?? 0) >= SIDLE || now - (e.t ?? 0) >= SMAX || (cf && !(now < (e.x ?? 0))) || ownoff(e.own)) {
if (cf) cgone();
fail(410, 'Lettura finita: riapri il file', 'Playback ended: open the file again');
}
let s = lstat(e.p);
if (!s || s.type != 'file') { if (cf) cgone(); fail(404, 'File non trovato', 'File not found'); }
if (!cf && admpriv(e.own, relof(e.p))) fail(404, 'File non trovato', 'File not found');
if (now - (e.a ?? 0) >= 60 && stat(SF)) { e.a = now; wjs(SF, e); }
let nm = cf ? replace('' + (e.n ?? ''), /[\/[:cntrl:]]/g, '') : bname(e.p);
if (cf && (!length(nm) || nm == '.' || nm == '..')) nm = 'file';
serve(e.p, nm, cf || e.dl === true || qp('dl') == '1', null, cors(), cf ? cgone : null);
}

if (kind == 'u') {
let U = rjs(X + '/up.json') ?? {}, u = U[tok];
if (!loc && !farok(u?.own, u?.dir)) jfail(403, 'Solo da casa o dalla VPN', 'Home or VPN only');
if (meth != 'PUT') jfail(405, 'Solo PUT', 'PUT only', null);
if (type(u) != 'object' || now - (u.t ?? 0) >= SMAX || ownoff(u.own)) jfail(410, 'Caricamento finito: riprova', 'Upload ended: try again');
if (stat(u.dir)?.type != 'directory' || lstat(u.dir)?.type == 'link' || admpriv(u.own, relof(u.dir))) jfail(404, 'Cartella non trovata', 'Folder not found');
let off = putchunk(u.part, u.size);
if (off < u.size) jout(200, { off: off });
let fn = freename(u.dir, u.name);
if (!fn || !rename(u.part, u.dir + '/' + fn)) jfail(507, 'File non scritto', 'File not written');
touchm(u.dir + '/' + fn, u.mtime);
U = rjs(X + '/up.json') ?? {}; delete U[tok]; wjs(X + '/up.json', U);
jout(200, { size: u.size, name: fn, path: (u.rel == '/' ? '' : u.rel) + '/' + fn });
}

let Xc = rjs(XJ) ?? {};

const CPH = '/tmp/wf-cloud/ph', CLIN = '.wf-incloud';
function clmb() {
let C = rjs(ETC + '/cloud.json') ?? {}, m = C.lim?.phone_mb, t = trim(readfile('/tmp/wf-cloud/tier') ?? '');
return type(m) == 'int' && m > 0 ? m : (t == 'B' || t == 'C' ? 256 : 32);
}
function memav() { let m = match(readfile('/proc/meminfo') ?? '', /MemAvailable:[ \t]*([0-9]+)/); return m ? +m[1] * 1024 : 1099511627776; }
function phres(job) {
let res = 0;
for (let e in lsdir(CPH) ?? []) {
let m = match(e, /^(.+)\.res$/);
if (!m || m[1] == job) continue;
let ps = lstat(CPH + '/' + m[1] + '.part'), sz = +(trim(readfile(CPH + '/' + e) ?? '0')) || 0;
if (ps && now - ps.mtime <= 600 && sz > ps.size) res += sz - ps.size;
}
return res;
}
function clstage(r, U) {
let mid = (rjs(NJ) ?? {}).main?.id, d = mid != null ? disk('' + mid) : null, rb = U.udir(r.own, 'root');
if (!d || d.ro || mainpause() || ownfull(r.own) || rb == null) return null;
let a = U.umkdir(d.mnt, rb);
if (!a) return null;
let s = a + '/' + CLIN;
if (!lstat(s)) mkdir(s, 448);
return lstat(s)?.type == 'directory' ? { d: d, dir: s, src: '/' + rb + '/' + CLIN } : null;
}
function clreq(r, RS, cap, used) {
let U = ucf();
if (type(U?.udir) != 'function' || type(U?.utype) != 'function' || type(U?.umkdir) != 'function' || type(r.own) != 'string' || r.own == 'admin')
jfail(503, 'Router occupato: riprova', 'Router busy: try again');
let nm = cleanname(urldec(substr(rest, 1))), cr = match(getenv('HTTP_CONTENT_RANGE') ?? '', /\/([0-9]+)$/);
let size = cr ? +cr[1] : (qp('size') != null ? +qp('size') : +(getenv('CONTENT_LENGTH') ?? '0'));
let pub = r.cl.pub === true, tod = '/' + U.udir(r.own, pub ? 'pub' : 'recv', pub ? null : U.utype(nm)), sent = {};
for (let x in split(readfile(RS) ?? '', '\n')) { let e = null; try { e = length(x) ? json(x) : null; } catch (y) { e = null; } if (type(e) == 'object' && e.to == tod) sent[lc(e.name ?? '')] = 1; }
let mm = match(nm, /^(.+)(\.[^.]+)$/), nb = mm ? mm[1] : nm, nx = mm ? mm[2] : '', cn = nm;
for (let i = 2; i < 10000 && sent[lc(cn)]; i++) cn = nb + ' (' + i + ')' + nx;
let refuse = (c, it, en) => { mkdirp(X + '/req'); append(RS, sprintf('%J\n', { refused: 1, t: now })); jfail(c, it, en); };
if (used + size > cap) refuse(413, 'Spazio della richiesta finito', 'Request space used up');
let job = 'jr' + hk(r.tok + '|' + nm + '|' + size), rp = CPH + '/' + job + '.part', S = clstage(r, U);
let pn = '.' + hk(nm + '|' + size) + '.' + size + '.wfpart', dp = S ? S.dir + '/' + pn : null;
let ram = lstat(rp) != null && !(dp && lstat(dp));
if (!ram && !(dp && lstat(dp))) {
let pr = 0;
if (S) for (let f in lsdir(S.dir) ?? []) {
let pm = match(f, /^\.[0-9a-f]{16}\.([0-9]+)\.wfpart$/), x = pm ? lstat(S.dir + '/' + f) : null;
if (x?.type == 'file' && now - x.mtime < 86400) pr += +pm[1] - x.size;
}
ram = !S || size + pr + 16777216 > freeb(S.dir);
if (ram) {
let mb = clmb();
if (size > mb * 1048576) refuse(413, 'Senza disco i file arrivano fino a ' + mb + ' MB', 'Without a drive files can be up to ' + mb + ' MB');
let wt = 0;
for (let e in lsdir(CPH) ?? []) { let wm = match(e, /^(jr[0-9a-f]{16})\.wait$/), ws = wm ? lstat(CPH + '/' + wm[1] + '.part') : null; if (ws) wt += ws.size; }
if (wt + size > mb * 1048576) jout(503, { error: L('Il cloud non risponde: riprova più tardi', 'The cloud is not answering: try again later'), retry: 300 }, { 'Retry-After': '300' });
if (freeb('/tmp') < 2 * size + 8388608 || memav() - phres(job) < size + 33554432) jout(503, { error: L('Memoria del router piena: riprova più tardi', 'Router memory full: try again later'), retry: 60 }, { 'Retry-After': '60' });
if (!stat('/tmp/wf-cloud')) mkdir('/tmp/wf-cloud', 448);
if (!stat(CPH)) mkdir(CPH, 448);
sh('umask 077; : > ' + q(rp));
writefile(CPH + '/' + job + '.res', '' + size);
}
}
let part = ram ? rp : dp, off = putchunk(part, size);
if (off < size) {
if (!ram && index(split(readfile(PARTS) ?? '', '\n'), S.dir) < 0) append(PARTS, S.dir + '\n');
jout(200, { off: off });
}
let CM = null;
try { CM = loadfile(getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc')(); } catch (e) { CM = null; }
let call = (a) => { let x = null; if (type(CM?.cloud?.call) == 'function') { try { x = CM.cloud.call({ args: { ...a, act: 'xfer', id: r.cl.id, as: r.own } }); } catch (e) { x = null; } } return x; };
let res = null, ev0 = { name: cn, size: size, t: now, to: tod };
if (ram) {
writefile(CPH + '/' + job + '.ok', '' + size);
unlink(CPH + '/' + job + '.res');
res = call({ kind: 'phone', job: job, to: tod, name: cn });
if (!res?.job) {
wjs(CPH + '/' + job + '.wait', { tok: r.tok, acc: r.cl.id, own: r.own, to: tod, name: cn, size: size, t: now, n: 1 });
ev0.wait = true;
}
ev0.via = 'ram';
}
else {
let fn = freename(S.dir, cn);
if (!fn || !rename(part, S.dir + '/' + fn)) jfail(507, 'File non scritto', 'File not written');
let mt = +(getenv('HTTP_X_MTIME') ?? qp('mtime') ?? '0');
if (mt > 0 && mt < now + 86400) touchm(S.dir + '/' + fn, mt);
if (fn != cn) { ev0.name = fn; }
res = call({ kind: 'up', disk: S.d.id, src: S.src + '/' + fn, to: tod, move: true });
ev0.via = 'disk';
if (!res?.job) {
let td = U.umkdir(S.d.mnt, U.udir(r.own, 'recv', U.utype(fn))), kn = td ? freename(td, fn) : null;
if (kn && rename(S.dir + '/' + fn, td + '/' + kn)) { ev0 = { name: kn, size: size, t: now, kept: 'disk' }; }
}
}
if (res?.job) ev0.job = res.job;
mkdirp(X + '/req'); append(RS, sprintf('%J\n', ev0));
if (pvis(r.own) == null) ev('nas_req_file', '🗄️ ' + TL('File Arrivati', 'Files Received') + ' ¦ ' + short(r.name) + ' ¦ ' + short(ev0.name));
jout(200, { size: size, name: ev0.name, ...(ev0.kept ? { kept: 'disk' } : ev0.wait ? { wait: true } : { cloud: true }) });
}

if (kind == 'r') {
let r = null;
for (let x in (type(Xc.req) == 'array' ? Xc.req : [])) if (x.tok == tok) r = x;
if (!r || (!loc && r.where != 'net')) fail(404, 'Link non trovato', 'Link not found');
if (Xc.link?.on === false || r.on === false || nasoff() || ownoff(r.own)) fail(403, 'Richiesta non attiva', 'Request not active');
if ((r.exp ?? 0) <= now) fail(410, 'Richiesta scaduta', 'Request expired');
gate(r);
if (type(r.cl) == 'object') {
let RS = X + '/req/' + tok + '.log', cap = (r.gb ?? 1) * 1073741824, used = r.used ?? 0;
for (let x in split(readfile(RS) ?? '', '\n')) { let e = null; try { e = length(x) ? json(x) : null; } catch (y) { e = null; } if (type(e) == 'object' && !e.refused) used += e.size ?? 0; }
if (meth == 'PUT') clreq(r, RS, cap, used);
if (meth != 'GET' && !head) fail(405, 'Metodo non valido', 'Invalid method', { Allow: 'GET, HEAD, PUT' });
if (rest != '/') { hdr(301, { Location: BASE + '/r/' + tok + '/', 'Content-Length': 0 }); exit(0); }
let mid = (rjs(NJ) ?? {}).main?.id, md = mid != null ? disk('' + mid) : null;
let freeq = cap - used < 0 ? 0 : cap - used, mb = clmb(), dk = md != null && !md.ro && !mainpause() && !ownfull(r.own);
html(200, r.name, '<div class="c"><p class="m">' + (r.cl.pub === true ? L('Puoi mettere file nella Cartella Pubblica. ', 'You can add files to the Public Folder. ') : L('Scegli i file da mandare. ', 'Choose the files to send. ')) +
L('Spazio rimasto: ', 'Space left: ') + hs(freeq) + (dk ? '' : L(' · file fino a ', ' · files up to ') + mb + ' MB') + '</p>' +
'<input type="file" id="f" multiple><button class="b" id="go">' + L('Carica', 'Upload') + '</button><ul id="l"></ul></div>',
upjs(''), null);
}
let d = disk(r.disk), dir = d && !d.ro ? nolink(d.mnt, filter(split(r.path ?? '', '/'), length)) : null;
if (!dir || stat(dir)?.type != 'directory') fail(503, 'Cartella non disponibile', 'Folder not available');
let RS = X + '/req/' + tok + '.log', cap = (r.gb ?? 1) * 1073741824, used = r.used ?? 0;
for (let x in split(readfile(RS) ?? '', '\n')) { let e = null; try { e = length(x) ? json(x) : null; } catch (y) { e = null; } if (type(e) == 'object' && !e.refused) used += e.size ?? 0; }
if (meth == 'PUT') {
let nm = cleanname(urldec(substr(rest, 1))), cr = match(getenv('HTTP_CONTENT_RANGE') ?? '', /\/([0-9]+)$/);
let size = cr ? +cr[1] : (qp('size') != null ? +qp('size') : +(getenv('CONTENT_LENGTH') ?? '0'));
let pn = '.' + hk(nm + '|' + size) + '.' + size + '.wfpart', part = dir + '/' + pn;
if (!lstat(part)) {
let po = 0, pr = 0;
for (let f in lsdir(dir) ?? []) {
let pm = match(f, /^\.[0-9a-f]{16}\.([0-9]+)\.wfpart$/), x = pm ? lstat(dir + '/' + f) : null;
if (x?.type == 'file' && now - x.mtime < 86400) { po += +pm[1]; pr += +pm[1] - x.size; }
}
if (used + po + size > cap || size + pr + 16777216 > freeb(dir)) {
mkdirp(X + '/req'); append(RS, sprintf('%J\n', { refused: 1, t: now }));
jfail(413, 'Spazio della richiesta finito', 'Request space used up');
}
}
let off = putchunk(part, size);
if (off < size) {
if (index(split(readfile(PARTS) ?? '', '\n'), dir) < 0) append(PARTS, dir + '\n');
jout(200, { off: off });
}
let td = dir, U = null;
try { U = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')(); } catch (e) { U = null; }
if (type(U?.udir) == 'function' && type(U?.utype) == 'function' && type(U?.umkdir) == 'function') {
let ow = type(r.own) == 'string' && length(r.own) ? r.own : 'admin', rb = U.udir(ow, 'recv'), rp = trim('' + (r.path ?? ''), '/');
let tr = rb != null && (rp == rb || substr(rp, 0, length(rb) + 1) == rb + '/') ? U.udir(ow, 'recv', U.utype(nm)) : null;
let ta = tr != null ? U.umkdir(d.mnt, tr) : null;
if (ta) td = ta;
}
let fn = freename(td, nm);
if (!fn || !rename(part, td + '/' + fn)) jfail(507, 'File non scritto', 'File not written');
let mt = +(getenv('HTTP_X_MTIME') ?? qp('mtime') ?? '0');
if (mt > 0 && mt < now + 86400) touchm(td + '/' + fn, mt);
mkdirp(X + '/req'); append(RS, sprintf('%J\n', { name: fn, size: size, t: now }));
if (pvis(r.own) == null) ev('nas_req_file', '🗄️ ' + TL('File Arrivati', 'Files Received') + ' ¦ ' + short(r.name) + ' ¦ ' + short(fn));
jout(200, { size: size, name: fn });
}
if (meth != 'GET' && !head) fail(405, 'Metodo non valido', 'Invalid method', { Allow: 'GET, HEAD, PUT' });
if (rest != '/') { hdr(301, { Location: BASE + '/r/' + tok + '/', 'Content-Length': 0 }); exit(0); }
let freeq = cap - used < 0 ? 0 : cap - used;
html(200, r.name, '<div class="c"><p class="m">' + L('Scegli i file da mandare. Spazio rimasto: ', 'Choose the files to send. Space left: ') + hs(freeq) + '</p>' +
'<input type="file" id="f" multiple><button class="b" id="go">' + L('Carica', 'Upload') + '</button><ul id="l"></ul></div>',
upjs(''), null);
}

const RCF = ETC + '/cloud-rclone.conf', CLMEM = 50331648, CLLS = 2000;
function rcl(a) { return 'RCLONE_CONFIG=' + q(RCF) + ' RCLONE_CACHE_DIR=/tmp/wf-cloud/rclone-cache exec rclone ' + a + ' --contimeout 15s --timeout 60s --log-level ERROR </dev/null 2>/dev/null'; }
function rmem() { if (memav() < CLMEM) fail(503, 'Router occupato: riprova fra un minuto', 'Router busy: try again in a minute', { 'Retry-After': '60' }); }
function rjoin(b, p) { return substr(b, -1) == ':' ? b + p : b + '/' + p; }
function rjson(a) { rmem(); let o = sh(rcl(a)), v = null; try { v = length(o) ? json(o) : null; } catch (e) { v = null; } return v; }
function isot(s) {
let m = match('' + s, /^([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})[.0-9]*(Z|([+-])([0-9]{2}):([0-9]{2}))?/);
if (!m || type(global.timegm) != 'function') return 0;
let t = global.timegm({ year: +m[1], mon: +m[2], mday: +m[3], hour: +m[4], min: +m[5], sec: +m[6] }) ?? 0;
if (m[8]) t -= (m[8] == '+' ? 1 : -1) * (+m[9] * 3600 + +m[10] * 60);
return t;
}
function clrem(CM, acct, rel) {
let m = CM._rc.cmap(acct, rel);
if (!m || m.st == 'mix') return null;
let a = m.sec + ':' + m.path, b = type(m.alt) == 'object' ? m.alt.sec + ':' + m.alt.path : null;
return m.st == 'back' && b ? [ b, a ] : (b ? [ a, b ] : [ a ]);
}
function clstat(CM, acct, rel) {
for (let r in clrem(CM, acct, rel) ?? []) {
let v = rjson('lsjson --stat --no-mimetype ' + q(r));
if (type(v) == 'object') return { r: r, d: v.IsDir === true, s: v.Size > 0 ? v.Size : 0, m: isot(v.ModTime) };
}
return null;
}
function clls(CM, acct, rel, rec) {
let E = [], seen = {};
for (let r in clrem(CM, acct, rel) ?? []) {
if (rec) {
if (length(E) >= 20001) break;
rmem();
let p = popen(rcl('lsf -R --files-only --max-depth 30 --format stp --separator ' + q(';') + ' ' + q(r)), 'r');
if (!p) continue;
while (length(E) < 20001) {
let ln = p.read('line');
if (ln == null || !length(ln)) break;
let m = match(rtrim(ln, '\r\n'), /^(-?[0-9]+);([^;]*);(.+)$/);
if (!m) continue;
let pp = m[3], hid = false;
for (let y in split(pp, '/')) if (!length(y) || substr(y, 0, 1) == '.') hid = true;
if (hid || seen[pp]) continue;
seen[pp] = 1;
push(E, { n: pp, r: rjoin(r, pp), lr: (length(rel) ? rel + '/' : '') + pp, d: false, s: +m[1] > 0 ? +m[1] : 0, m: isot(m[2]) });
}
p.close();
continue;
}
let v = rjson('lsjson --no-mimetype --max-depth 1 ' + q(r));
if (type(v) != 'array') continue;
for (let x in v) {
let p = '' + (x?.Path ?? ''), hid = false;
for (let y in split(p, '/')) if (!length(y) || substr(y, 0, 1) == '.') hid = true;
if (hid || seen[p]) continue;
seen[p] = 1;
push(E, { n: p, r: rjoin(r, p), lr: (length(rel) ? rel + '/' : '') + p, d: x.IsDir === true, s: x.Size > 0 ? x.Size : 0, m: isot(x.ModTime) });
if (length(E) >= CLLS) break;
}
}
return E;
}
function clink(l) {
let CM = null;
try { CM = loadfile(getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc')(); } catch (e) { CM = null; }
if (type(CM?._rc?.cmap) != 'function' || type(CM._rc.acct) != 'function') fail(503, 'Cloud non disponibile', 'Cloud not available');
let acct = '' + l.cl.id, A = CM._rc.acct(acct);
if (!A) fail(404, 'Link non trovato', 'Link not found');
if (type(CM._rc.paused) == 'function' && CM._rc.paused()) fail(503, 'Cloud in pausa: riprova più tardi', 'Cloud paused: try again later', { 'Retry-After': '600' });
if (meth == 'PUT') jfail(405, 'Solo lettura', 'Read only');
let parts = [];
for (let x in split(urldec(rest), '/')) { if (!length(x)) continue; if (badname(x) || substr(x, 0, 1) == '.') fail(404, 'Non trovato', 'Not found'); push(parts, x); }
let virt = type(l.paths) == 'array', isroot = !length(parts), rel = null, title = l.name;
if (virt) {
if (!isroot) {
let p = null;
for (let x in l.paths) if (bname(x) == parts[0]) p = x;
if (!p) fail(404, 'Non trovato', 'Not found');
rel = join('/', [ ...filter(split(p, '/'), length), ...slice(parts, 1) ]);
}
}
else if (l.dir === true) rel = join('/', [ ...filter(split(l.path ?? '', '/'), length), ...parts ]);
else { rel = join('/', filter(split(l.path ?? '', '/'), length)); isroot = true; }
if (rel != null && admpriv(l.own, rel, true)) fail(404, 'Non trovato', 'Not found');
if (!(virt && isroot) && (!isroot || l.dir === true)) title = parts[length(parts) - 1] ?? l.name;
let st = virt && isroot ? { d: true } : clstat(CM, acct, rel);
if (!st) fail(404, 'Non trovato', 'Not found');
if (st.d) {
if (substr(uri, -1) != '/') { hdr(301, { Location: BASE + uri + '/', 'Content-Length': 0 }); exit(0); }
let E = [];
if (virt && isroot) {
let G = {};
for (let p in l.paths) { let pp = replace(p, /\/[^\/]*$/, ''); G[pp] = G[pp] ?? []; push(G[pp], bname(p)); }
for (let pp, nn in G) {
let L = clls(CM, acct, join('/', filter(split(pp, '/'), length)), false);
for (let e in L) if (index(nn, e.n) >= 0) push(E, e);
}
}
else E = clls(CM, acct, rel, false);
if (qp('zip') == '1') {
nomore(l);
if (!head) count();
let Z = [];
for (let e in E) {
if (e.d) { for (let x in clls(CM, acct, e.lr, true)) push(Z, { r: x.r, n: e.n + '/' + x.n, s: x.s, m: x.m }); }
else push(Z, { r: e.r, n: e.n, s: e.s, m: e.m });
if (length(Z) > 20000) break;
}
rmem();
for (let z in Z) { let r = z.r; z.f = () => memav() < CLMEM ? null : popen(rcl('cat ' + q(r)), 'r'); }
zipsend(Z, title + '.zip', (b) => { mkdirp(X + '/dl'); append(X + '/dl/' + tok, '1'); logacc(l, 'zip', b); });
}
nomore(l);
if (!head) hit(l, 'open', 0);
E = sort(E, (a, b) => a.d != b.d ? (a.d ? -1 : 1) : (lc(a.n) < lc(b.n) ? -1 : (lc(a.n) > lc(b.n) ? 1 : 0)));
let li = isroot ? '' : '<li><a class="n" href="../">‹ ' + L('Indietro', 'Back') + '</a></li>';
for (let e in E) {
let h = urlenc(e.n) + (e.d ? '/' : ''), th = !e.d && match(mimeof(e.n), /^image\/(jpeg|png|gif|webp)/) && e.s <= 3145728;
li += '<li>' + (th ? '<img loading="lazy" alt="" src="' + h + '?view=1&amp;th=1">' : '<span>' + icon(e.n, e.d) + '</span>') + '<a class="n" href="' + h + '">' + esc(e.n) + '</a>' +
(e.d ? '' : '<small>' + hs(e.s) + '</small><a href="' + h + '?dl=1" title="' + L('Scarica', 'Download') + '">⬇</a>') + '</li>';
}
if (!length(E)) li += '<li><small>' + L('Cartella vuota', 'Empty folder') + '</small></li>';
let r = left(l);
html(200, title, '<a class="b" href="?zip=1">' + L('Scarica Tutto · ZIP', 'Download All · ZIP') + '</a>' + (r != null ? '<p class="m">' + L('Accessi rimasti: ', 'Accesses left: ') + (r < 0 ? 0 : r) + '</p>' : '') +
'<div class="c"><ul>' + li + '</ul></div>', null);
}
let nm = bname(rel), dl = qp('dl') == '1', th = qp('th') == '1' && st.s <= 3145728 && match(mimeof(nm), /^image\/(jpeg|png|gif|webp)/) != null && known();
if (l.dir !== true && !virt && meth == 'GET' && !dl && qp('view') == null && getenv('HTTP_RANGE') == null && index(getenv('HTTP_ACCEPT') ?? '', 'text/html') >= 0) {
let r = left(l), mm = mimeof(nm), u = urlenc(nm);
html(200, l.name, '<div class="c"><p>' + icon(nm, false) + ' ' + esc(nm) + ' <small>' + hs(st.s) + '</small></p>' +
(r != null ? '<p class="m">' + L('Download rimasti: ', 'Downloads left: ') + (r < 0 ? 0 : r) + '</p>' : '') + '</div>' +
'<a class="b" href="' + u + '?dl=1">' + L('Scarica', 'Download') + '</a>' +
(match(mm, /^(video|audio|image)\//) || mm == 'application/pdf' || match(mm, /^text\//) ? '<a class="b b2" href="' + u + '?view=1">' + L('Apri', 'Open') + '</a>' : ''), null);
}
if (!th) nomore(l);
if (!th && !head) { let P = prange(st.s); hit(l, 'file', st.s ? P.z - P.a + 1 : 0, P.a == 0); }
rmem();
cserve({ r: st.r, f: RCF, s: st.s }, nm, dl, null);
}

if (kind != 's') fail(404, 'Non trovato', 'Not found');
let l = null;
for (let x in (Xc.link?.list ?? [])) if (x.tok == tok) l = x;
if (!l || (!loc && l.where != 'net')) fail(404, 'Link non trovato', 'Link not found');
for (let p in (type(l.paths) == 'array' ? l.paths : [ l.path ])) if (admpriv(l.own, '' + (p ?? ''), true)) fail(404, 'Link non trovato', 'Link not found');
if (Xc.link?.on === false || nasoff() || ownoff(l.own)) fail(403, 'Link non attivo', 'Link not active');
if ((l.exp ?? 0) <= now) fail(410, 'Link scaduto', 'Link expired');
const PUBRW = l.kind == 'pub' && l.mode == 'rw' && l.dir === true && type(l.paths) != 'array';
if (meth == 'PUT' && !PUBRW) jfail(405, 'Solo lettura', 'Read only');
if (meth != 'GET' && !head && meth != 'POST' && meth != 'PUT') fail(405, 'Solo lettura', 'Read only', { Allow: PUBRW ? 'GET, HEAD, PUT' : 'GET, HEAD' });
gate(l);
if (meth == 'POST') { hdr(303, { Location: BASE + uri, 'Content-Length': 0 }); exit(0); }
if (type(l.cl) == 'object') clink(l);
if (meth == 'PUT') {
let sg = filter(split(rest, '/'), length), sub = [];
if (!length(sg)) jfail(400, 'Nome non valido', 'Invalid name');
for (let x in slice(sg, 0, -1)) { x = urldec(x); if (badname(x) || substr(x, 0, 4) == '.wf-') jfail(404, 'Cartella non trovata', 'Folder not found'); push(sub, x); }
let nm = cleanname(urldec(sg[-1])), d = disk(l.disk);
if (!d || d.ro) jfail(503, 'Disco non disponibile', 'Drive not available');
if (mainpause()) jfail(503, 'Disco Principale staccato: riprova più tardi', 'Main Drive disconnected: try again later');
if (ownfull(l.own)) jout(507, { error: L('Spazio finito: chiedi a chi ti ha invitato', 'Space used up: ask whoever invited you'), code: 'quota_full' });
let base = nolink(d.mnt, filter(split(l.path ?? '', '/'), length)), dir = base ? nolink(base, sub) : null;
if (!dir || stat(dir)?.type != 'directory') jfail(404, 'Cartella non trovata', 'Folder not found');
nomore(l);
let cr = match(getenv('HTTP_CONTENT_RANGE') ?? '', /\/([0-9]+)$/);
let size = cr ? +cr[1] : (qp('size') != null ? +qp('size') : +(getenv('CONTENT_LENGTH') ?? '0'));
let pn = '.' + hk(nm + '|' + size) + '.' + size + '.wfpart', part = dir + '/' + pn;
if (!lstat(part)) {
let pr = 0;
for (let f in lsdir(dir) ?? []) {
let pm = match(f, /^\.[0-9a-f]{16}\.([0-9]+)\.wfpart$/), x = pm ? lstat(dir + '/' + f) : null;
if (x?.type == 'file' && now - x.mtime < 86400) pr += +pm[1] - x.size;
}
if (size + pr + 16777216 > freeb(dir)) jfail(507, 'Disco pieno', 'Drive full');
}
let off = putchunk(part, size);
if (off < size) {
if (index(split(readfile(PARTS) ?? '', '\n'), dir) < 0) append(PARTS, dir + '\n');
jout(200, { off: off });
}
let fn = freename(dir, nm);
if (!fn || !rename(part, dir + '/' + fn)) jfail(507, 'File non scritto', 'File not written');
let mt = +(getenv('HTTP_X_MTIME') ?? qp('mtime') ?? '0');
if (mt > 0 && mt < now + 86400) touchm(dir + '/' + fn, mt);
hit(l, 'up', size);
if (pvis(l.own) == null) ev('nas_req_file', '🗄️ ' + TL('File Arrivati', 'Files Received') + ' ¦ ' + short(l.name) + ' ¦ ' + short(fn));
jout(200, { size: size, name: fn });
}
let parts = [];
for (let x in split(urldec(rest), '/')) { if (!length(x)) continue; if (badname(x) || substr(x, 0, 4) == '.wf-') fail(404, 'Non trovato', 'Not found'); push(parts, x); }
let d = disk(l.disk);
if (!d) fail(503, 'Disco non collegato', 'Drive not connected');
let isroot = !length(parts), virt = type(l.paths) == 'array', target = null, title = l.name;
if (virt) {
if (!isroot) {
let p = null;
for (let x in l.paths) if (bname(x) == parts[0]) p = x;
if (!p) fail(404, 'Non trovato', 'Not found');
target = nolink(d.mnt, [ ...filter(split(p, '/'), length), ...slice(parts, 1) ]);
}
}
else {
let base = nolink(d.mnt, filter(split(l.path ?? '', '/'), length));
if (!base) fail(404, 'File o cartella non trovati', 'File or folder not found');
if (l.dir === true) target = isroot ? base : nolink(base, parts);
else { target = base; isroot = true; }
}
if (!virt || !isroot) {
if (!target) fail(404, 'Non trovato', 'Not found');
if (!isroot || l.dir === true) title = parts[length(parts) - 1] ?? l.name;
}
let st = virt && isroot ? { type: 'directory' } : stat(target);
if (!st) fail(404, 'Non trovato', 'Not found');

if (st.type == 'directory') {
if (substr(uri, -1) != '/') { hdr(301, { Location: BASE + uri + '/', 'Content-Length': 0 }); exit(0); }
let E = [];
if (virt && isroot) { for (let p in l.paths) { let a = nolink(d.mnt, filter(split(p, '/'), length)), x = a ? lstat(a) : null; if (x && (x.type == 'file' || x.type == 'directory')) push(E, { n: bname(p), d: x.type == 'directory', s: x.size, a: a, m: x.mtime }); } }
else for (let n in lsdir(target) ?? []) {
if (badname(n) || substr(n, 0, 4) == '.wf-') continue;
let x = lstat(target + '/' + n);
if (x && (x.type == 'file' || x.type == 'directory')) push(E, { n: n, d: x.type == 'directory', s: x.size, a: target + '/' + n, m: x.mtime });
}
if (qp('zip') == '1') {
nomore(l);
if (!head) count();
let Z = [];
for (let e in E) { if (e.d) walk(e.a, e.n + '/', Z, 1); else push(Z, { a: e.a, n: e.n, s: e.s, m: e.m }); if (length(Z) > 20000) break; }
zipsend(Z, title + '.zip', (b) => { mkdirp(X + '/dl'); append(X + '/dl/' + tok, '1'); logacc(l, 'zip', b); });
}
nomore(l);
if (!head) hit(l, 'open', 0);
E = sort(E, (a, b) => a.d != b.d ? (a.d ? -1 : 1) : (lc(a.n) < lc(b.n) ? -1 : (lc(a.n) > lc(b.n) ? 1 : 0)));
let li = isroot ? '' : '<li><a class="n" href="../">‹ ' + L('Indietro', 'Back') + '</a></li>';
for (let e in E) {
let h = urlenc(e.n) + (e.d ? '/' : ''), th = !e.d && match(mimeof(e.n), /^image\/(jpeg|png|gif|webp)/) && e.s <= 3145728;
li += '<li>' + (th ? '<img loading="lazy" alt="" src="' + h + '?view=1&amp;th=1">' : '<span>' + icon(e.n, e.d) + '</span>') + '<a class="n" href="' + h + '">' + esc(e.n) + '</a>' +
(e.d ? '' : '<small>' + hs(e.s) + '</small><a href="' + h + '?dl=1" title="' + L('Scarica', 'Download') + '">⬇</a>') + '</li>';
}
if (!length(E)) li += '<li><small>' + L('Cartella vuota', 'Empty folder') + '</small></li>';
let r = left(l);
let upc = PUBRW ? '<div class="c"><p class="m">' + L('Puoi anche mettere file in questa cartella.', 'You can also add files to this folder.') + '</p>' +
'<input type="file" id="f" multiple><button class="b" id="go">' + L('Carica', 'Upload') + '</button><ul id="l"></ul></div>' : '';
html(200, title, '<a class="b" href="?zip=1">' + L('Scarica Tutto · ZIP', 'Download All · ZIP') + '</a>' + (r != null ? '<p class="m">' + L('Accessi rimasti: ', 'Accesses left: ') + (r < 0 ? 0 : r) + '</p>' : '') +
upc + '<div class="c"><ul>' + li + '</ul></div>', PUBRW ? upjs('location.reload();') : null);
}
if (st.type != 'file') fail(404, 'Non trovato', 'Not found');
let nm = bname(target), dl = qp('dl') == '1', th = qp('th') == '1' && st.size <= 3145728 && match(mimeof(nm), /^image\/(jpeg|png|gif|webp)/) != null && known();
if (l.dir !== true && !virt && meth == 'GET' && !dl && qp('view') == null && getenv('HTTP_RANGE') == null && index(getenv('HTTP_ACCEPT') ?? '', 'text/html') >= 0) {
let r = left(l), mm = mimeof(nm), u = urlenc(nm);
html(200, l.name, '<div class="c"><p>' + icon(nm, false) + ' ' + esc(nm) + ' <small>' + hs(st.size) + '</small></p>' +
(r != null ? '<p class="m">' + L('Download rimasti: ', 'Downloads left: ') + (r < 0 ? 0 : r) + '</p>' : '') + '</div>' +
'<a class="b" href="' + u + '?dl=1">' + L('Scarica', 'Download') + '</a>' +
(match(mm, /^(video|audio|image)\//) || mm == 'application/pdf' || match(mm, /^text\//) ? '<a class="b b2" href="' + u + '?view=1">' + L('Apri', 'Open') + '</a>' : ''), null);
}
if (!th) nomore(l);
serve(target, nm, dl, th ? null : (n, first) => hit(l, 'file', n, first), null);
