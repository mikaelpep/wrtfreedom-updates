'use strict';
import { popen, readfile, writefile, unlink, stat, lsdir, mkdir, rmdir, rename } from 'fs';

const AT = '/usr/share/wrtfreedom/at.sh', ID = '/tmp/wf-modem.id', CMDLOG = '/tmp/wf-modem.cmd';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function rj(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function cmdlog(c, o) {
let L = split(readfile(CMDLOG) ?? '', '\n'), d = localtime(), t = sprintf('%02d/%02d %02d:%02d:%02d', d.mday, d.mon, d.hour, d.min, d.sec);
push(L, t + ' > ' + c, t + ' < ' + replace(trim('' + o), /\s*\n\s*/g, ' | '));
if (length(L) > 80) L = slice(L, length(L) - 80);
writefile(CMDLOG, join('\n', filter(L, length)) + '\n');
}
function at(c) { let o = sh('sh ' + AT + ' ' + q(c) + ' 2>&1'); cmdlog(c, o); return o; }
function atok(o) { return index(o, 'OK') >= 0 && index(o, 'ERROR') < 0; }
function mmcli(args) { return sh('mmcli -m any ' + args + ' 2>&1'); }
function mmjs(args) { let o = mmcli(args + ' -J'); try { return json(o); } catch (e) { return null; } }
function fields(l) { return map(split(replace(trim(l), /^[+$#!^][A-Za-z0-9_]+: */, ''), ','), (x) => trim(x, ' "')); }
function uniq(a) { let s = {}, r = []; for (let x in a) { x = '' + x; if (length(x) && !s[x]) { s[x] = 1; push(r, x); } } return sort(r, (a, b) => +a - +b); }

const LTEB = [ [0,599,1],[600,1199,2],[1200,1949,3],[1950,2399,4],[2400,2649,5],[2750,3449,7],[3450,3799,8],[3800,4149,9],[4150,4749,10],
[5010,5179,12],[5180,5279,13],[5280,5379,14],[5730,5849,17],[5850,5999,18],[6000,6149,19],[6150,6449,20],[6450,6599,21],[8040,8689,25],
[8690,9039,26],[9040,9209,27],[9210,9659,28],[9660,9769,29],[9770,9869,30],[9870,9919,32],[36000,36199,33],[36200,36349,34],[37750,38249,38],
[38250,38649,39],[38650,39649,40],[39650,41589,41],[41590,43589,42],[43590,45589,43],[46790,54539,46],[55240,56739,48],[65536,66435,65],
[66436,67335,66],[67336,67535,67],[68586,68935,71] ];
const NRB = [ [422000,434000,1],[386000,398000,2],[361000,376000,3],[173800,178800,5],[524000,538000,7],[185000,192000,8],[145800,149200,12],
[158200,164200,20],[151600,160600,28],[386000,399000,25],[514000,524000,38],[376000,384000,39],[460000,480000,40],[499200,537999,41],
[636667,646666,48],[422000,440000,66],[123400,130400,71],[286400,303400,75],[620000,653333,78],[620000,680000,77],[693334,733333,79] ];
function bandof(T, n, prefer) {
n = +n; let found = [];
for (let r in T) if (n >= r[0] && n <= r[1]) push(found, '' + r[2]);
for (let b in found) if (prefer && index(prefer, b) >= 0) return b;
return found[0] ?? '';
}

function vendorOf(s) {
s = lc(s ?? '');
for (let v in [ 'quectel', 'fibocom', 'sierra', 'telit', 'simcom', 'huawei', 'zte' ]) if (index(s, v) >= 0) return v;
if (index(s, 'simtech') >= 0) return 'simcom';
if (match(s, /\bdw58[0-9]{2}/)) return 'sierra';
if (match(s, /\b(rm5\d\d|rm2\d\d|em0[56]|ep06|eg[0-9]{2}|ec2[0-9]|bg9[0-9])/)) return 'quectel';
if (match(s, /\b(fm1[0-9]{2}|fm350|l8[56]0|nl668)/)) return 'fibocom';
if (match(s, /\b(em7[0-9]{3}|em9[0-9]{3}|mc7[0-9]{3})/)) return 'sierra';
if (match(s, /\b(fn9[0-9]{2}|ln9[0-9]{2}|lm9[0-9]{2}|le910)/)) return 'telit';
if (match(s, /\b(sim7[0-9]{3}|sim8[0-9]{3}|a7[0-9]{3})/)) return 'simcom';
return '';
}
function present() {
for (let d in (lsdir('/dev') ?? [])) if (match(d, /^(cdc-wdm|wwan|ttyUSB|ttyACM|mhi_)/)) return true;
return false;
}
function mmidx() { return match(readfile('/tmp/wf-modem.mm') ?? '', /ModemManager1\/Modem\/([0-9]+)/)?.[1] ?? ''; }
function mmver() {
let s = null;
for (let d in split((getenv('PATH') ?? '') + ':/usr/bin:/usr/sbin:/bin:/sbin', ':')) if (length(d) && (s = stat(d + '/mmcli'))) break;
let k = s ? s.inode + ':' + s.mtime + ':' + s.size : '', c = split(trim(readfile('/tmp/wf-modem.mmver') ?? ''), ' ');
if (length(k) && c[0] == k && length(c[1] ?? '')) return c[1];
let v = match(sh('mmcli --version 2>/dev/null'), /([0-9]+\.[0-9]+(\.[0-9]+)?)/);
v = v ? v[1] : '';
if (length(k) && length(v)) writefile('/tmp/wf-modem.mmver', k + ' ' + v + '\n');
return v;
}

function modemgone() { unlink('/tmp/wf-modeminfo.json'); unlink('/tmp/wf-modemcells.json'); unlink('/tmp/wf-modem.bands'); }
function id(fresh) {
let st = stat(ID), c = null;
if (st) c = rj(ID);
if (!fresh && st && time() - st.mtime < 600) {
if (c && (c.mm || c.vendor)) return c;
if (c && time() - st.mtime < 60 && (stat('/tmp/wf-modem.mm')?.mtime ?? 0) < st.mtime && (stat('/tmp/wf-modem.ati')?.mtime ?? 0) < st.mtime &&
(stat('/dev')?.mtime ?? 0) < st.mtime) return c;
}
let mmj = rj('/tmp/wf-modem.mm'), g = mmj?.modem?.generic ?? {};
let r = { mm: !!(mmj && g.model), mfr: g.manufacturer ?? '', model: g.model ?? '', rev: g.revision ?? '', plugin: g.plugin ?? '',
drivers: g.drivers ?? [], mmver: '', vendor: '' };
r.vendor = vendorOf(r.mfr + ' ' + r.model + ' ' + r.plugin);
if (!r.vendor) {
let o = readfile('/tmp/wf-modem.ati') ?? '';
if (atok(o)) {
let L = filter(map(split(o, '\n'), trim), (x) => length(x) && x != 'OK' && x != 'ATI');
r.vendor = vendorOf(join(' ', L));
if (!r.model && length(L) > 1) { r.mfr = L[0]; r.model = L[1]; }
}
}
if (r.mm || fresh) r.mmver = mmver();
r.qmi = length(filter(r.drivers, (d) => match(d, /qmi|mhi/))) > 0;
r.mbim = length(filter(r.drivers, (d) => match(d, /mbim/))) > 0;
r.present = r.mm || present();
if (c && (c.vendor != r.vendor || c.model != r.model || c.mm != r.mm)) modemgone();
let tf = ID + '.' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '' + time(), /[^0-9a-f]/g, ''), 0, 12);
if (writefile(tf, sprintf('%J', r)) == null || !rename(tf, ID)) unlink(tf);
return r;
}
function mmge(ver, want) {
let a = split(ver ?? '', '.'), b = split(want, '.');
for (let i = 0; i < 3; i++) { let x = +(a[i] ?? 0), y = +(b[i] ?? 0); if (x != y) return x > y; }
return true;
}

const DRV = {};
DRV.quectel = {
name: 'Quectel',
read: [ 'AT+QENG="servingcell"', 'AT+QCAINFO' ],
slow: [ 'AT+QTEMP' ],
neigh: [ 'AT+QENG="neighbourcell"' ],
parse: function(o) {
let S = { nb: [] }, seen = {};
for (let l in split(o, '\n')) {
l = trim(l); let f = fields(l);
if (index(l, '+QENG:') == 0 && index(l, 'neighbourcell') < 0) {
let i = index(f, 'LTE');
if (i >= 0 && length(f) > i + 14) S.lte = { pci: f[i + 5], earfcn: f[i + 6], band: f[i + 7], tac: f[i + 10], rsrp: +f[i + 11], rsrq: +f[i + 12], sinr: +f[i + 14], cid: f[i + 4],
bw: ({ '0': 1.4, '1': 3, '2': 5, '3': 10, '4': 15, '5': 20 })[f[i + 9]] };
i = index(f, 'NR5G-NSA');
if (i >= 0 && length(f) > i + 8) S.nr = { pci: f[i + 3], rsrp: +f[i + 4], sinr: +f[i + 5], rsrq: +f[i + 6], arfcn: f[i + 7], band: f[i + 8], scs: f[i + 10] ?? '' };
i = index(f, 'NR5G-SA');
if (i >= 0 && length(f) > i + 12) S.nr = { pci: f[i + 5], tac: f[i + 6], arfcn: f[i + 7], band: f[i + 8], rsrp: +f[i + 10], rsrq: +f[i + 11], sinr: +f[i + 12], sa: true };
}
else if (index(l, '+QENG:') == 0 && f[1] == 'LTE' && length(f) > 5) {
let k = f[2] + ',' + f[3];
if (!seen[k]) { seen[k] = 1; push(S.nb, { earfcn: f[2], pci: f[3], rsrp: +f[5], band: bandof(LTEB, f[2]), t: index(f[0], 'intra') >= 0 ? 'intra' : 'inter' }); }
}
}
return S;
},
lockq: [ 'AT+QNWLOCK="common/4g"', 'AT+QNWLOCK="common/5g"' ],
lockparse: function(o) {
let r = { lte: 'none', nr: 'none' };
for (let l in split(o, '\n')) {
let f = fields(l);
if (index(l, '+QNWLOCK:') < 0) continue;
if (f[0] == 'common/4g') r.lte = (f[1] && f[1] != '0' && length(f) > 3) ? f[2] + ',' + f[3] : 'none';
if (f[0] == 'common/5g') r.nr = (f[1] && f[1] != '0' && length(f) > 4) ? join(',', slice(f, 1, 5)) : 'none';
}
return r;
},
lock: function(L, N) { return [ 'AT+QNWLOCK="common/4g",1,' + L.earfcn + ',' + L.pci, N ? 'AT+QNWLOCK="common/5g",' + join(',', [ N.pci, N.arfcn, N.scs, N.band ]) : 'AT+QNWLOCK="common/5g",0' ]; },
unlock: function() { return [ 'AT+QNWLOCK="common/4g",0', 'AT+QNWLOCK="common/5g",0' ]; },
nrscs: true,
bandsread: function() {
let o = at('AT+QNWPREFCFG="policy_band"'), c = at('AT+QNWPREFCFG="lte_band";+QNWPREFCFG="nsa_nr5g_band";+QNWPREFCFG="mode_pref"');
let g = (s, k) => { let m = match(s, regexp('"' + k + '",([0-9:]+)')); return m ? split(m[1], ':') : null; };
let mp = match(c, /"mode_pref",([A-Z0-9:]+)/i);
if (!g(c, 'lte_band')) return null;
return { sup: { lte: g(o, 'lte_band') ?? [], nr: g(o, 'nsa_nr5g_band') ?? g(o, 'nr5g_band') ?? [] },
cur: { lte: g(c, 'lte_band') ?? [], nr: g(c, 'nsa_nr5g_band') ?? [] },
mode: mp ? (uc(mp[1]) == 'LTE' ? 'lte' : 'nr') : '' };
},
bandsset: function(L, N, mode) {
let c = [ 'AT+QNWPREFCFG="lte_band",' + join(':', L) ];
if (length(N) && mode != 'lte') {
push(c, 'AT+QNWPREFCFG="nsa_nr5g_band",' + join(':', N), 'AT+QNWPREFCFG="nr5g_band",' + join(':', N));
push(c, 'AT+QNWPREFCFG="mode_pref",LTE:NR5G', 'AT+QNWPREFCFG="nr5g_disable_mode",1');
}
else push(c, 'AT+QNWPREFCFG="mode_pref",LTE');
return c;
},
nrbandsset: function(N) { return length(N) ? [ 'AT+QNWPREFCFG="nsa_nr5g_band",' + join(':', N), 'AT+QNWPREFCFG="nr5g_band",' + join(':', N) ] : []; },
ant: 'AT+QRSRP',
antparse: function(o) {
let r = {};
for (let l in split(o, '\n')) {
if (index(l, '+QRSRP:') < 0) continue;
let f = fields(l), k = match(f[4] ?? '', /NR5G/) ? 'nr' : 'lte';
r[k] = map(slice(f, 0, 4), (x) => (+x <= -140 || +x >= 0 || !match(x, /^-?[0-9]+$/)) ? null : +x);
}
return r;
},
after: function(mode) {
if (mode == 'lte') return [];
let nm = trim(sh('uci -q get wrtfreedom.modem.nrmode'));
return [ 'AT+QNWPREFCFG="nr5g_disable_mode",' + (nm == 'sa' || nm == 'auto' ? 0 : 1) ];
},
nrmode: function(m) {
return m == 'sa' ? [ 'AT+QNWPREFCFG="mode_pref",NR5G', 'AT+QNWPREFCFG="nr5g_disable_mode",0' ] :
[ 'AT+QNWPREFCFG="mode_pref",LTE:NR5G', 'AT+QNWPREFCFG="nr5g_disable_mode",' + (m == 'auto' ? 0 : 1) ];
}
};
function fibonr(c) { c = '' + c; return (length(c) >= 3 && substr(c, 0, 2) == '50') ? substr(c, 2) : null; }
DRV.fibocom = {
name: 'Fibocom',
read: [ 'AT+GTCCINFO?' ],
neigh: [],
parse: function(o) {
let S = { nb: [] };
for (let l in split(o, '\n')) {
let f = map(split(trim(l), ','), (x) => trim(x, ' "'));
if (length(f) < 9 || !match(f[0], /^[0-9]$/) || !match(f[1], /^[0-9]+$/)) continue;
let arfcn = '' + hex(f[6]), pci = '' + hex(f[7]), bc = f[8];
if (f[1] == '4') {
let c = { pci: pci, earfcn: arfcn, band: (+bc > 100 && +bc < 300) ? '' + (+bc - 100) : bandof(LTEB, arfcn), tac: f[4], cid: f[5] };
if (f[0] == '1' && !S.lte) S.lte = c; else push(S.nb, { ...c, t: S.lte && S.lte.earfcn == arfcn ? 'intra' : 'inter' });
}
if (f[1] == '9' && f[0] == '1' && !S.nr) S.nr = { pci: pci, arfcn: arfcn, band: fibonr(bc) ?? bandof(NRB, arfcn) };
}
return S;
},
lockq: [ 'AT+GTCELLLOCK?' ],
lockparse: function(o) {
let r = { lte: 'none', nr: 'none' };
for (let l in split(o, '\n')) {
if (index(l, '+GTCELLLOCK:') < 0) continue;
let f = fields(l);
if (f[0] != '1') continue;
if (f[1] == '0' && length(f) > 4) r.lte = f[3] + ',' + f[4];
if (f[1] == '1' && length(f) > 6) r.nr = join(',', [ f[4], f[3], f[5] == '1' ? '30' : '15', fibonr(f[6]) ?? f[6] ]);
}
return r;
},
lock: function(L, N) {
let c = [ 'AT+GTCELLLOCK=0', 'AT+GTCELLLOCK=1,0,0,' + L.earfcn + ',' + L.pci ];
if (N) push(c, 'AT+GTCELLLOCK=2,1,0,' + N.arfcn + ',' + N.pci + ',' + (N.scs == '30' ? '1' : '0') + ',50' + N.band);
return c;
},
unlock: function() { return [ 'AT+GTCELLLOCK=0' ]; },
bandsread: function() {
let o = at('AT+GTACT?'), m = match(o, /\+GTACT: *([0-9,]+)/);
if (!m) return null;
let f = split(m[1], ','), L = [], N = [];
for (let x in slice(f, 3)) { let n = fibonr(x); if (n) push(N, n); else if (+x > 100 && +x < 300) push(L, '' + (+x - 100)); }
return { sup: { lte: uniq(L), nr: uniq(N) }, cur: { lte: uniq(L), nr: uniq(N) }, mode: (f[0] == '2') ? 'lte' : 'nr' };
},
bandsset: function(L, N, mode) {
let lc = join(',', map(L, (x) => '' + (100 + +x))), nc = join(',', map(N, (x) => '50' + x));
return [ (length(N) && mode != 'lte') ? 'AT+GTACT=17,6,,' + lc + ',' + nc : 'AT+GTACT=2,,,' + lc ];
},
nrbandsset: null
};
DRV.simcom = {
name: 'SIMCom',
read: [ 'AT+CPSI?' ],
neigh: [],
parse: function(o) {
let S = { nb: [] };
for (let l in split(o, '\n')) {
if (index(l, '+CPSI:') < 0) continue;
let f = fields(l), bn = (x) => (match(x ?? '', /BAND([0-9]+)/) ?? [])[1] ?? '';
if (f[0] == 'LTE' && length(f) > 7) S.lte = { pci: f[5], earfcn: f[7], band: bn(f[6]), tac: f[3], cid: f[4] };
else if (f[0] == 'NR5G_SA' && length(f) > 7) S.nr = { pci: f[5], arfcn: f[7], band: bn(f[6]), sa: true };
else if (f[0] == 'NR5G_NSA' && length(f) > 3) S.nr = { pci: f[1], arfcn: f[3], band: bn(f[2]) };
}
return S;
},
lockq: [ 'AT+CCELLCFG?', 'AT+C5GCELLCFG?' ],
lockparse: function(o) {
let r = { lte: 'none', nr: 'none' };
for (let l in split(o, '\n')) {
let f = fields(l);
if (index(l, '+CCELLCFG:') >= 0 && f[0] == '1' && length(f) > 2) r.lte = f[2] + ',' + f[1];
if (index(l, '+C5GCELLCFG:') >= 0 && length(f) > 1 && f[0] != '0' && !match(l, /unlock/i)) r.nr = join(',', slice(f, length(f) > 4 ? length(f) - 4 : 0));
}
return r;
},
lock: function(L, N) {
let c = [ 'AT+CCELLCFG=1,' + L.pci + ',' + L.earfcn ];
push(c, N ? 'AT+C5GCELLCFG="pci",' + N.pci + ',' + N.arfcn + ',' + (N.scs == '30' ? '1' : '0') + ',' + N.band : 'AT+C5GCELLCFG="unlock"');
return c;
},
unlock: function() { return [ 'AT+CCELLCFG=0', 'AT+C5GCELLCFG="unlock"' ]; },
bandsread: function() {
let c = at('AT+CSYSSEL="lte_band";+CSYSSEL="nsa_nr5g_band"'), g = (k) => { let m = match(c, regexp('"' + k + '",([0-9:]+)')); return m ? split(m[1], ':') : null; };
if (!g('lte_band')) return null;
return { sup: { lte: g('lte_band'), nr: g('nsa_nr5g_band') ?? [] }, cur: { lte: g('lte_band'), nr: g('nsa_nr5g_band') ?? [] }, mode: '' };
},
bandsset: function(L, N, mode) {
let c = [ 'AT+CSYSSEL="lte_band",' + join(':', L) ];
if (length(N) && mode != 'lte') push(c, 'AT+CSYSSEL="nsa_nr5g_band",' + join(':', N), 'AT+CSYSSEL="nr5g_band",' + join(':', N));
return c;
},
nrbandsset: function(N) { return length(N) ? [ 'AT+CSYSSEL="nsa_nr5g_band",' + join(':', N), 'AT+CSYSSEL="nr5g_band",' + join(':', N) ] : []; }
};

function drv(I) {
if (type(I) == 'string') I = { vendor: I, model: '' };
let D = DRV[I?.vendor ?? ''], m = lc(I?.model ?? '');
if (!D) return null;
if (I.vendor == 'fibocom' && match(m, /fm350|l8[56]0/)) return { ...D, name: D.name + ' ' + I.model, lock: null, unlock: null, lockq: [], read: match(m, /l8[56]0/) ? [] : D.read, bandsread: match(m, /l8[56]0/) ? null : D.bandsread, bandsset: match(m, /l8[56]0/) ? null : D.bandsset };
if (I.vendor == 'simcom' && !match(m, /sim8[0-9]{3}/)) return { ...D, name: D.name + ' ' + I.model, lock: null, unlock: null, lockq: [], bandsread: null, bandsset: null, nrbandsset: null };
return D;
}

function lockobj(L, N) {
let l = null, n = null, f;
if (length(L ?? '')) { f = split(L, ','); l = { earfcn: f[0], pci: f[1], band: f[2] ?? bandof(LTEB, f[0]) }; }
if (length(N ?? '')) { f = split(N, ','); n = { pci: f[0], arfcn: f[1], scs: f[2] ?? '', band: f[3] ?? bandof(NRB, f[1]) }; }
return [ l, n ];
}
function lockcmds(D, L, N) { let o = lockobj(L, N); return o[0] ? D.lock(o[0], o[1]) : D.unlock(); }

function mmbands(list) {
let r = { lte: [], nr: [] };
for (let b in list ?? []) {
let m = match(b, /^eutran-([0-9]+)$/); if (m) push(r.lte, m[1]);
m = match(b, /^ngran-([0-9]+)$/); if (m) push(r.nr, m[1]);
}
r.lte = uniq(r.lte); r.nr = uniq(r.nr);
return r;
}
function mmmode(s) {
let m = match(s ?? '', /allowed: ([^;]+)/);
if (!m) return '';
let a = m[1];
return index(a, '5g') >= 0 ? 'nr' : index(a, '4g') >= 0 ? 'lte' : '';
}
function bandsmm(I) {
let mmj = rj('/tmp/wf-modem.mm'), g = mmj?.modem?.generic ?? {}, r = null;
if (I.mm && length(g['supported-bands'] ?? [])) {
let s = mmbands(g['supported-bands']), c = mmbands(g['current-bands']);
if (length(s.lte)) r = { sup: s, cur: c, mode: mmmode(g['current-modes']), via: 'mm' };
}
return r;
}
function bandsat(D, r) { return D && D.bandsread && (!r || !length(r.sup.nr)); }
const BF = '/tmp/wf-modem.bands';
function bands() {
let I = id(), D = drv(I), r = bandsmm(I);
if (bandsat(D, r)) {
let a = D.bandsread();
if (a) {
if (!r) r = { sup: a.sup, cur: a.cur, mode: a.mode, via: 'at' };
else if (length(a.sup.nr)) { r.sup.nr = a.sup.nr; r.cur.nr = a.cur.nr; r.via = 'mm+at'; }
}
let tf = BF + '.' + substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? '' + time(), /[^0-9a-f]/g, ''), 0, 12);
if (writefile(tf, sprintf('%J', { b: r })) == null || !rename(tf, BF)) unlink(tf);
}
return r;
}
function bandsread(now) {
let L = BF + '.lock', ls = stat(L);
if (ls && (now || time() - ls.mtime > 60)) rmdir(L);
if (mkdir(L)) sh('( ucode /usr/share/wrtfreedom/modemctl.uc bands; rmdir ' + L + ' ) >/dev/null 2>&1 </dev/null &');
}
function bandsbg() {
let I = id(), D = drv(I), r = bandsmm(I);
if (!bandsat(D, r)) return { b: r, age: 0 };
let st = stat(BF), c = st ? rj(BF) : null;
if (!st || time() - st.mtime > 60) bandsread(false);
if (type(c) != 'object' || !('b' in c)) return null;
return { b: c.b, age: time() - st.mtime };
}
const MOBUCI = /^network\.([A-Za-z0-9_]+)\.proto='(modemmanager|qmi|mbim|ncm|3g|wwan|qcm)'$/;
function mobif() {
for (let l in split(sh('uci -q show network'), '\n')) {
let m = match(l, MOBUCI);
if (m) return [ m[1], m[2] ];
}
return null;
}
function bandsset(L, N, mode) {
let I = id(), D = drv(I), B = bands(), errs = [], via = [];
if (!B) return { ok: false, errors: [ 'bande del modem non leggibili' ] };
if (mode == 'lte') N = [];
let mmok = B.via != 'at' && I.mm, mmnr = mmok && B.via == 'mm' && length(B.sup.nr);
if (mmok) {
let list = map(L, (x) => 'eutran-' + x);
if (mmnr) for (let x in N) push(list, 'ngran-' + x);
let c = '--set-current-bands=' + q(join('|', list)), o = mmcli(c);
cmdlog('mmcli ' + c, o);
if (match(o, /error/i)) {
push(errs, 'ModemManager: ' + trim(o));
mmok = false;
} else push(via, 'mm');
let mi = mobif(), m5 = length(B.sup.nr) > 0;
if (mmok) {
let am = (mode == 'lte' || !m5) ? '4g' : '5g|4g', pm = am == '4g' ? '' : '5g';
let o2 = mmcli('--set-allowed-modes=' + q(am) + (length(pm) ? ' --set-preferred-mode=' + pm : ''));
cmdlog('mmcli --set-allowed-modes=' + am, o2);
if (match(o2, /error/i) && !match(o2, /already|unchanged|same/i)) push(errs, 'Gestore Del Modem (modalità): ' + trim(o2));
if (mi && mi[1] == 'modemmanager')
sh('uci set network.' + mi[0] + '.allowedmode=' + q(am) + '; ' + (length(pm) ? 'uci set network.' + mi[0] + '.preferredmode=' + pm + '; ' : 'uci -q delete network.' + mi[0] + '.preferredmode; ') + 'uci commit network');
}
}
if (D) {
let cmds = [];
if (!mmok && D.bandsset) { cmds = D.bandsset(L, N, mode); errs = []; }
else if (mmok && !mmnr && length(N) && D.nrbandsset) cmds = D.nrbandsset(N);
if (mmok && D.after && length(D.after(mode))) {
let bg = '( sleep 15; ';
for (let c in D.after(mode))
bg += 'for i in 1 2 3; do o=$(sh ' + AT + ' ' + q(c) + ' 2>&1); d=$(date +%d/%m\\ %H:%M:%S); printf "%s > %s\\n%s < %s\\n" "$d" ' + q(c) +
' "$d" "$(echo "$o" | tr "\\n" " ")" >> ' + CMDLOG + '; echo "$o" | grep -q OK && break; sleep 10; done; ';
sh(bg + ') >/dev/null 2>&1 </dev/null &');
push(via, 'at');
}
for (let c in cmds) {
let o = at(c);
if (!atok(o)) { sh('sleep 1'); o = at(c); }
if (!atok(o)) push(errs, c + ' → ' + (trim(o) || 'nessuna risposta'));
}
if (length(cmds)) push(via, 'at');
}
else if (!mmok) push(errs, 'questo modem non permette di cambiare le bande da qui');
if (stat('/etc/config/quectel') != null) {
let c = 'uci -q delete quectel.modem.lte_bands; ';
for (let x in L) c += 'uci add_list quectel.modem.lte_bands=' + x + '; ';
if (length(N)) { c += 'uci -q delete quectel.modem.nr5g_bands; '; for (let x in N) c += 'uci add_list quectel.modem.nr5g_bands=' + x + '; '; }
sh(c + 'uci commit quectel');
}
sh('uci set wrtfreedom.modem=modem; uci set wrtfreedom.modem.lte=' + q(join(' ', L)) + '; uci set wrtfreedom.modem.nr=' + q(join(' ', N)) +
'; uci set wrtfreedom.modem.mode=' + q(mode) + '; uci commit wrtfreedom');
unlink('/tmp/wf-modem.ts'); unlink(BF);
if (bandsat(D, bandsmm(I))) bandsread(true);
return { ok: !length(errs), errors: errs, via: join('+', via) };
}

function mmcells(list, curnr) {
let S = { nb: [] };
for (let s in list ?? []) {
let kv = {};
for (let p in split(s, ', ')) { let i = index(p, ': '); if (i > 0) kv[substr(p, 0, i)] = substr(p, i + 2); }
let pci = kv['physical ci'] != null ? '' + hex(kv['physical ci']) : '';
if (kv['cell type'] == 'lte') {
let c = { pci: pci, earfcn: kv.earfcn ?? '', band: bandof(LTEB, kv.earfcn), rsrp: +(kv.rsrp ?? 0), rsrq: +(kv.rsrq ?? 0), tac: kv.tac ?? '', cid: kv.ci ?? '' };
if (kv.serving == 'yes' && (!S.lte || kv['serving cell type'] == '1')) S.lte = c;
else if (kv.serving != 'yes') push(S.nb, { ...c, t: (S.lte && S.lte.earfcn == c.earfcn) ? 'intra' : 'inter' });
}
if (kv['cell type'] == '5gnr' && !S.nr)
S.nr = { pci: pci, arfcn: kv.nrarfcn ?? '', band: kv.nrarfcn ? bandof(NRB, kv.nrarfcn, curnr) : '', rsrp: +(kv.rsrp ?? 0), rsrq: +(kv.rsrq ?? 0), sinr: +(kv.sinr ?? 0) };
}
S.nb = sort(S.nb, (a, b) => b.rsrp - a.rsrp);
return S;
}

function sfbusy() {
let p = trim(readfile('/tmp/wf-sigfast.pid') ?? '');
if (!length(p) || index(readfile('/proc/' + p + '/cmdline') ?? '', 'sigfast') < 0) return false;
return rj('/tmp/wf-sigfast.json')?.via != 'mm';
}
function sigfull(c) { let n = (x) => (type(x) == 'int' || type(x) == 'double') && x == x; return c && n(c.rsrp) && n(c.rsrq) && n(c.sinr); }
function readcmd() {
let I = id(), D = drv(I), A = 'sh ' + AT + ' ', mi = mmidx(), now = time(), busy = sfbusy();
let c = ': > /tmp/wf-modem.' + (busy ? 'tsb' : 'ts') + '; ' + (length(mi) ? 'm=' + mi + '; o=$(mmcli -m $m -J 2>/dev/null); [ -n "$o" ] || { m=any; o=$(mmcli -m any -J 2>/dev/null); }; ' :
'm=any; o=$(mmcli -m any -J 2>/dev/null); ') + '[ -n "$o" ] && echo "$o" > /tmp/wf-modem.mm.$$ && mv -f /tmp/wf-modem.mm.$$ /tmp/wf-modem.mm; ';
if (!busy && !stat('/tmp/wf-modem.ati')) c += A + "'ATI' > /tmp/wf-modem.ati 2>/dev/null; ";
let SL = D?.slow ?? [], due = length(SL) && now - (stat('/tmp/wf-modem.slow')?.mtime ?? 0) >= 50;
let pat = join('|', map(SL, (x) => "*'" + (match(x, /^AT(\+[A-Za-z0-9_]+)/)?.[1] ?? x) + "'*"));
if (!busy && D && length(D.read)) {
let ag = !due && length(SL);
c += (ag ? '{ ' : '') + A; for (let x in [ ...D.read, ...(due ? SL : []) ]) c += q(x) + ' ';
c += ag ? '2>/dev/null; [ -f /tmp/wf-modem.slow ] && while IFS= read -r l; do echo "$l"; done < /tmp/wf-modem.slow; } > /tmp/wf-modem.at.$$; ' : '> /tmp/wf-modem.at.$$ 2>/dev/null; ';
if (due) c += 'while IFS= read -r l; do case "$l" in ' + pat + ') echo "$l" ;; esac; done < /tmp/wf-modem.at.$$ > /tmp/wf-modem.slow.$$; mv -f /tmp/wf-modem.slow.$$ /tmp/wf-modem.slow; ';
}
else if (!busy) c += ': > /tmp/wf-modem.at.$$; ';
if (I.mm) {
let P = D && D.parse ? D.parse(readfile('/tmp/wf-modem.at') ?? '') : null;
let atsig = P && (P.lte || P.nr) && (!P.lte || sigfull(P.lte)) && (!P.nr || sigfull(P.nr));
if (!atsig || now - (stat('/tmp/wf-modem.sig')?.mtime ?? 0) >= 55)
c += 's=$(mmcli -m $m --signal-get -J 2>/dev/null); printf %s "$s" > /tmp/wf-modem.sig.$$ && mv -f /tmp/wf-modem.sig.$$ /tmp/wf-modem.sig; case "$s" in *rsrp*) ;; *) mmcli -m $m --signal-setup=10 >/dev/null 2>&1 ;; esac; ';
if (mmge(I.mmver, '1.20') && (I.qmi || I.mbim)) c += 'mmcli -m $m --get-cell-info -J > /tmp/wf-modem.cell.$$ 2>/dev/null; mv -f /tmp/wf-modem.cell.$$ /tmp/wf-modem.cell; ';
}
return c + (busy ? ':' : 'mv -f /tmp/wf-modem.at.$$ /tmp/wf-modem.at 2>/dev/null || rm -f /tmp/wf-modem.at.$$');
}
function sigv(k, x) {
if (type(x) != 'int' && type(x) != 'double') return null;
if (k == 'nr') return x > -156 && x <= -31 ? x : null;
if (k == 'sinr' || k == 'snr') return x >= -20 && x <= 40 ? x : null;
if (k == 'rsrp') return x >= -145 && x <= -30 ? x : null;
if (k == 'rsrq') return x >= -43 && x <= 20 ? x : null;
if (k == 'rssi') return x >= -125 && x <= -20 ? x : null;
if (k == 'temp') return x > 0 && x < 150 ? x : null;
return x;
}
function sigfix(s) {
let a = (x) => type(x) == 'array' ? x[0] : x;
if (s.nr != null && sigv('nr', a(s.nr)) == null) { s.nr = null; s.nq = null; s.ns = null; if (s.tech == 'nr-nsa') s.tech = 'lte'; }
if (type(s.nr) == 'array') s.nr = [ s.nr[0], sigv('nr', s.nr[1]), s.nr[2] ];
for (let k in [ 'ls', 'ns' ]) {
if (s[k] != null && sigv('sinr', a(s[k])) == null) s[k] = null;
else if (type(s[k]) == 'array') s[k] = [ s[k][0], sigv('sinr', s[k][1]) ];
}
return s;
}
function state(I0) {
let I = I0 ?? id(), D = drv(I), o = readfile('/tmp/wf-modem.at') ?? '', mm = rj('/tmp/wf-modem.mm');
let n = D && D.parse ? D.parse(o) : { nb: [] };
let cl = rj('/tmp/wf-modem.cell')?.modem?.generic?.['cell-info'];
if (cl) {
let c = mmcells(cl, mm?.modem?.generic?.['current-bands']);
if (!n.lte) n.lte = c.lte;
if (!n.nr) n.nr = c.nr;
if (!length(n.nb ?? [])) n.nb = c.nb;
}
let sg = rj('/tmp/wf-modem.sig')?.modem?.signal;
if (sg) {
let num = (x) => (x == null || x == '--') ? null : +x;
if (sg.lte && num(sg.lte.rsrp) != null) { n.lte = n.lte ?? {}; n.lte.rsrp ??= num(sg.lte.rsrp); n.lte.rsrq ??= num(sg.lte.rsrq); n.lte.sinr ??= num(sg.lte.snr); }
if (sg['5g'] && sigv('nr', num(sg['5g'].rsrp)) != null) { n.nr = n.nr ?? {}; n.nr.rsrp ??= num(sg['5g'].rsrp); n.nr.rsrq ??= num(sg['5g'].rsrq); n.nr.sinr ??= num(sg['5g'].snr); }
}
let ca = [];
for (let l in split(o, '\n')) { let m = match(l, /\+QCAINFO:\s*"(PCC|SCC)",(\d+),\d+,"(LTE BAND|NR5G BAND) (\d+)"/); if (m) push(ca, (m[3] == 'LTE BAND' ? 'B' : 'n') + m[4]); }
if (!length(ca)) { if (n.lte?.band) push(ca, 'B' + n.lte.band); if (n.nr?.band) push(ca, 'n' + n.nr.band); }
n.ca = ca;
let t = []; for (let m in match(o, /\+QTEMP: *"[^"]+","([0-9]+)"/g) ?? []) if (sigv('temp', +m[1]) != null) push(t, +m[1]);
if (length(t)) n.temp = t;
if (n.lte) n.lte.sinr = sigv('sinr', n.lte.sinr);
if (n.nr) { let s = sigfix({ nr: n.nr.rsrp, nq: n.nr.rsrq, ns: n.nr.sinr }); n.nr.rsrp = s.nr; n.nr.rsrq = s.nq; n.nr.sinr = s.ns; }
let g = mm?.modem?.generic ?? {}, g3 = mm?.modem?.['3gpp'] ?? {};
n.op = g3['operator-name'] ?? ''; n.at = g['access-technologies'] ?? [];
return { n: n, raw: o, mm: mm, id: I, D: D };
}

function tech(n) {
let a = join(' ', n?.at ?? []), r = n?.nr?.rsrp;
if (n?.nr?.sa || (!n?.lte && index(a, '5gnr') >= 0 && index(a, 'lte') < 0)) return 'nr-sa';
if (n?.lte && (sigv('nr', r) != null || length(filter(n?.ca ?? [], (x) => substr(x, 0, 1) == 'n')) > 0)) return 'nr-nsa';
if (n?.lte || index(a, 'lte') >= 0) return 'lte';
if (match(a, /umts|hsdpa|hsupa|hspa/)) return '3g';
if (match(a, /gsm|gprs|edge/)) return '2g';
return '';
}
function ucs2(s, force) {
s = trim('' + (s ?? ''));
if (!length(s) || length(s) % 4 != 0 || !match(s, /^[0-9A-Fa-f]+$/)) return s;
if (!force && !match(s, /^(00[0-9A-Fa-f]{2}|0[34][0-9A-Fa-f]{2}|20[0-9A-Fa-f]{2})+$/)) return s;
let o = '', u = (c) => c < 0x80 ? chr(c) : c < 0x800 ? chr(0xC0 | (c >> 6), 0x80 | (c & 63)) :
c < 0x10000 ? chr(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63)) : chr(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
for (let i = 0; i < length(s); i += 4) {
let c = hex(substr(s, i, 4));
if (c >= 0xD800 && c < 0xDC00 && i + 8 <= length(s)) { let d = hex(substr(s, i + 4, 4)); if (d >= 0xDC00 && d < 0xE000) { c = 0x10000 + ((c - 0xD800) << 10) + (d - 0xDC00); i += 4; } }
o += u(c);
}
return o;
}

function lineup() {
for (let l in split(readfile('/proc/net/route') ?? '', '\n')) { let f = split(l, '\t'); if (f[1] == '00000000' && f[7] == '00000000') return true; }
return false;
}
function guard() {
if (!lineup()) return;
let B = bands();
if (!B) return;
let g = (k) => trim(sh('uci -q get wrtfreedom.lock.' + k));
writefile('/etc/wrtfreedom/modem.prev', sprintf('%J', { t: time(), lte: B.cur.lte, nr: B.cur.nr, mode: B.mode || 'nr', locklte: g('lte'), locknr: g('nr') }));
sh('( sleep 180; ucode /usr/share/wrtfreedom/modemctl.uc guard ) >/dev/null 2>&1 </dev/null &');
}
function wantmob(keep) {
let M = [];
for (let l in split(sh('uci -q show network'), '\n')) {
let m = match(l, MOBUCI);
if (m) push(M, m[1]);
}
if (!keep) {
mkdir('/tmp/wf-want'); writefile('/tmp/wf-want/_usb', '' + time() + '\n');
for (let i in M) writefile('/tmp/wf-want/' + i, '' + time() + '\n');
return;
}
if (length(M)) sh('( d=0; n=0; while [ $n -lt 9 ]; do sleep 20; n=$((n + 1)); u=1; for i in ' + join(' ', M) +
'; do ifstatus $i 2>/dev/null | grep -q \'"up": true\' || u=0; done; [ $u = 0 ] && d=1; [ $u = 1 ] && [ $d = 1 ] && break; ' +
'for f in _usb ' + join(' ', M) + '; do date +%s > /tmp/wf-want/$f; done; done ) </dev/null >/dev/null 2>&1 &');
}
function restart() {
wantmob(false);
let I = id(), r = '';
if (I.mm) { let o = mmcli('-r'); cmdlog('mmcli -r', o); if (!match(o, /error/i)) r = 'mm'; }
if (!r) { let o = at('AT+CFUN=1,1'); if (atok(o)) r = 'at'; }
if (r) wantmob(true);
return r;
}
function setmode(mode) {
let B = bands();
if (!B) return { ok: false, errors: [ 'bande del modem non leggibili' ] };
let L = length(B.cur.lte) ? B.cur.lte : B.sup.lte, N = mode == 'lte' ? [] : (length(B.cur.nr) ? B.cur.nr : B.sup.nr);
let w = split(trim(sh('uci -q get wrtfreedom.modem.nr')), /\s+/);
if (mode != 'lte' && length(w) && length(w[0])) N = w;
if (mode != 'lte' && !length(B.sup.nr)) return { ok: false, errors: [ 'questo modem non ha bande 5G' ] };
guard();
return bandsset(L, N, mode);
}

function report() {
let I = id(true), B = bands(), D = drv(I), L = [];
let hide = (s) => replace(replace('' + s, /("?(imei|imsi|iccid|msisdn|equipment-identifier|own-numbers|esn|meid)"?[: ]+)"?[^",\n]*"?/gi, '$1***'), /[0-9]{14,20}/g, '***');
push(L, 'WrtFreedom · Rapporto Modem', 'Pacchetto: ' + trim(readfile('/usr/share/wrtfreedom/VERSION') ?? ''),
'OpenWrt: ' + trim(replace(match(readfile('/etc/openwrt_release') ?? '', /DISTRIB_DESCRIPTION='([^']*)'/)?.[1] ?? '', /'/g, '')),
'Modem: ' + I.mfr + ' ' + I.model + ' · firmware ' + I.rev, 'Marca riconosciuta: ' + (I.vendor || 'nessuna') + (D ? ' (modulo ' + D.name + ')' : ' (nessun modulo per il blocco cella)'),
'ModemManager: ' + (I.mm ? 'sì, versione ' + I.mmver + ' · plugin ' + I.plugin + ' · driver ' + join(' ', I.drivers) : (length(I.mmver) ? 'installato, modem non visto' : 'no')),
'Strumento AT: ' + trim(sh('sh ' + AT + ' --tool 2>/dev/null')),
'Bande: ' + (B ? 'via ' + B.via + ' · supportate 4G ' + join(' ', B.sup.lte) + ' · 5G ' + join(' ', B.sup.nr) + ' · in uso 4G ' + join(' ', B.cur.lte) + ' · 5G ' + join(' ', B.cur.nr) + ' · modalità ' + B.mode : 'non leggibili'),
'', '--- Gestore Del Modem ---', hide(trim(mmcli('') || '(nessuna risposta)')), '', '--- ATI ---', hide(trim(at('ATI'))), '', '--- Ultimi comandi ---', hide(trim(readfile(CMDLOG) ?? '')));
return replace(join('\n', L), /\x1b\[[0-9;]*m/g, '');
}

return { id, present, drv, bands, bandsbg, mmidx, modemgone, sfbusy, bandsset, readcmd, state, lineup, guard, restart, setmode, lockcmds, lockobj, mmcells, bandof, LTEB, NRB, at, atok, mmcli, mmjs, fields, report, mobif, mmge, cmdlog, vendorOf, tech, sigv, sigfix, ucs2 };
