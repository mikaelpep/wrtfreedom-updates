LOG() { echo "## $*"; }
arconf() { for d in $(grep -o "/[A-Za-z0-9._/-]*cake-autorate/" /etc/init.d/cake-autorate 2>/dev/null) /root/cake-autorate/ /usr/share/cake-autorate/ /opt/cake-autorate/; do
[ -f "${d}config.primary.sh" ] && { echo "${d}config.primary.sh"; return; }; done; }
D=$(ip -4 route show default table main 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n 1)
J=$(ubus call network.interface dump 2>/dev/null)
P=$(echo "$J" | jsonfilter -e "@.interface[@.l3_device='$D'].proto" 2>/dev/null | head -n 1)
for lb_f in /usr/share/wrtfreedom/lib.sh "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
homenet >/dev/null; H=$HN_DEV
ishome() { [ -n "$H" ] && [ "$1" = "$H" ]; }
case "$P" in modemmanager|qmi|mbim|ncm|3g|wwan|qcm) T=$H ;; *) T=$D ;; esac
Q=$(uci -q show sqm | sed -n "s/^sqm\.\([^.]*\)=queue$/\1/p")
ON=""; for s in $Q; do [ "$(uci -q get sqm.$s.enabled)" = 1 ] && { ON=$(uci -q get sqm.$s.interface); break; }; done
case "$1" in
sqm)
[ -n "$T" ] || { case "$P" in modemmanager|qmi|mbim|ncm|3g|wwan|qcm) LOG "Rete di casa non trovata: interfaccia di SQM da scegliere nell'app" ;;
*) LOG "Linea verso internet non trovata: interfaccia di SQM da scegliere nell'app" ;; esac; exit 0; }
[ -n "$ON" ] && { LOG "SQM ha già una regola accesa ($ON): resta com'è"; exit 0; }
for s in $Q; do [ "$(uci -q get sqm.$s.interface)" = "$T" ] && { LOG "SQM è già su $T"; exit 0; }; done
s=$(echo "$Q" | head -n 1)
if [ -z "$s" ]; then s=$(uci add sqm queue); uci set sqm.$s.enabled=0; uci set sqm.$s.qdisc=cake; uci set sqm.$s.script=piece_of_cake.qos; fi
if ishome "$T" && ! ishome "$(uci -q get sqm.$s.interface)"; then
dl=$(uci -q get sqm.$s.download); ul=$(uci -q get sqm.$s.upload)
[ -n "$dl" ] && uci set sqm.$s.upload="$dl"; [ -n "$ul" ] && uci set sqm.$s.download="$ul"
fi
uci set sqm.$s.interface="$T" && uci commit sqm && LOG "SQM su $T" ;;
ar)
F=$(arconf)
[ -n "$F" ] || exit 0
I=${2:-${ON:-$T}}
echo "$I" | grep -qE '^[A-Za-z0-9._@-]{1,15}$' || { LOG "Interfaccia di cake-autorate da scegliere nell'app"; exit 0; }
B=$(printf 'ifb4%s' "$I" | head -c 15)
U=$I; W=$B; ishome "$I" && { U=$B; W=$I; }
if uci -q show cake-autorate >/dev/null 2>&1; then
for c in $(uci -q show cake-autorate | sed -n "s/^cake-autorate\.\([^.]*\)\.enabled=.*/\1/p"); do uci set cake-autorate.$c.ul_if="$U"; uci set cake-autorate.$c.dl_if="$W"; done
uci commit cake-autorate
fi
for k in ul_if dl_if; do v=$U; [ $k = dl_if ] && v=$W
if grep -q "^$k=" "$F"; then sed -i "s/^$k=[^ #]*/$k=$v/" "$F"; else echo "$k=$v" >> "$F"; fi
done
LOG "cake-autorate: upload $U, download $W" ;;
*) echo "uso: sqmline.sh sqm | ar [interfaccia]"; exit 1 ;;
esac
exit 0
