'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, readlink, open } from 'fs';

const SYS = getenv('WF_SYS') ?? '/sys', MOUNTS = getenv('WF_MOUNTS') ?? '/proc/mounts', PROC = getenv('WF_PROC') ?? '/proc';
const RUN = '/tmp/wf-nas', JOBS = RUN + '/jobs', ETC = getenv('WF_NASETC') ?? '/etc/wrtfreedom', NASJ = ETC + '/nas.json';
const TRASH = '.wf-trash', IDXD = '.wf-index';
const JOB = getenv('WF_NASJOB') ?? '/usr/share/wrtfreedom/nasjob.sh', FSH = getenv('WF_NASFSH') ?? '/usr/share/wrtfreedom/nasf.sh';
const CFGD = getenv('WF_CFGDIR') ?? '/etc/config/', EVSH = getenv('WF_EVENTSH') ?? '/usr/share/wrtfreedom/event.sh';
const FATMAX = 4294967295, RDMAX = 524288, WALKMAX = +(getenv('WF_WALKMAX') ?? 20000) || 20000;
const WALKSEC = match(getenv('WF_WALKSEC') ?? '', /^[0-9]+$/) ? +getenv('WF_WALKSEC') : 3;
const TRDEF = 30, TRMAX = 90;
const TRPERS = 30;
const FAVMAX = 12, IDXMAX = 150000, IDXRAM = 100000;
function idxram() {
let m = match(readfile((getenv('WF_PROC') ?? '/proc') + '/meminfo') ?? '', /MemTotal:[ \t]*([0-9]+)/), mb = m ? +m[1] / 1024 : 0;
return mb > 0 && mb <= 256 ? 20000 : (mb > 0 && mb <= 512 ? 50000 : IDXRAM);
}
let TIPI = {};
try { TIPI = loadfile(getenv('WF_NASTIPIUC') ?? replace(sourcepath() ?? '', /[^\/]*$/, '') + 'nastipi.uc')() ?? {}; } catch (e) { TIPI = {}; }
const TYPES = { img: TIPI.img ?? [], vid: TIPI.vid ?? [], mus: TIPI.mus ?? [], doc: TIPI.doc ?? [] };
const SYSN = [ 'lost+found', '$recycle.bin', 'system volume information', 'recycler', '$windows.~bt', '$windows.~ws' ];

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function bg(c) { sh('( umask 022; ' + c + ' ) >/dev/null 2>&1 </dev/null &'); }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(p) != null; }
function rj(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function uniq(a) { let r = []; for (let x in a) if (index(r, x) < 0) push(r, x); return r; }
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || ('' + time());
function wjr(f, o) { let t = f + '.' + PID + '.t'; writefile(t, sprintf('%J', o)); rename(t, f); }
function mkdirp(p) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c); } }
function bin(n) {
for (let d in [ getenv('WF_NASBIN'), '/usr/sbin', '/usr/bin', '/sbin', '/bin' ]) if (d && has(d + '/' + n)) return d + '/' + n;
return null;
}
function perm(p, m) {
let f = null;
try { f = require('fs').chmod; } catch (e) { f = null; }
if (type(f) == 'function') { f(p, m == '755' ? 493 : 420); return; }
sh('chmod ' + m + ' ' + q(p) + ' 2>/dev/null');
}
function cutn(s, n) { s = '' + s; if (length(s) <= n) return s; while (n > 0 && (ord(s, n) & 192) == 128) n--; return substr(s, 0, n); }
function ferr() { let e = null; try { e = require('fs').error(); } catch (x) { e = null; } return '' + (e ?? ''); }
function hk8(s) { let h = 5381; s = '' + s; for (let i = 0; i < length(s); i++) h = (h * 33 + ord(s, i)) & 0xffffffff; return sprintf('%08x', h); }
function hook(at) { let h = getenv('WF_HOOK'); if (h && getenv('WF_HOOKAT') == at) sh(h); }
function day(t) { let d = localtime(t ?? time()); return sprintf('%04d-%02d-%02d', d.year, d.mon, d.mday); }

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function cfg(n) { return UCFG.parse(readfile(CFGD + n) ?? '', false, UCFG.uvalq); }
function nascfg() { let o = rj(NASJ); return type(o) == 'object' ? o : {}; }
const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function nasput(fn) { return UCFG.njset(nascfg, fn, (o) => { mkdirp(ETC); wjr(NASJ, o); }); }
function nbusy() { return { error: 'Impostazioni occupate: riprova', error_en: 'Settings busy: try again', code: 'busy' }; }
function L(it, en) { return cfg('wrtfreedom').ui?.lang == 'en' ? en : it; }
function err(it, en, x) { let r = { error: it, error_en: en }; for (let k, v in x ?? {}) r[k] = v; return r; }
function gb(b) { let g = b / 1073741824.0; return g >= 10 ? int(g + 0.5) + ' GB' : replace(sprintf('%.1f', g), '.', L(',', '.')) + ' GB'; }
function ev(t, txt) { bg('sh ' + q(EVSH) + ' cron ' + t + ' nas ' + q(txt)); }

function baseof(d) {
let m = match(d, /^(nvme[0-9]+n[0-9]+|mmcblk[0-9]+)p[0-9]+$/);
if (m) return m[1];
m = match(d, /^((s|h|v|xv)d[a-z]+)[0-9]+$/);
return m ? m[1] : d;
}
function virt(d) { return !!match(d, /^(mtdblock|mtd|ubi|loop|zram|ram|dm-|sr|fd|nbd)/); }
function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
function mounts() {
let r = [];
for (let l in split(readfile(MOUNTS) ?? '', '\n')) {
let x = split(l, ' ');
if (length(x) < 4) continue;
push(r, { dev: x[0], mnt: unoct(x[1]), fs: x[2], ro: index(split(x[3], ','), 'ro') >= 0, opts: x[3] });
}
return r;
}
function sysr(p) { return trim(readfile(SYS + p) ?? ''); }
const NBLK = getenv('WF_NASBLK') ?? '/usr/share/wrtfreedom/nasjob.sh';
function blkinfo(M) { return UCFG.blkinfo(M, { sys: SYS, run: RUN, sh: (c) => sh(has(NBLK) ? 'sh ' + q(NBLK) + ' blk 2>/dev/null </dev/null' : c), rj, wjr, bin, mkdirp }); }
const fsname = UCFG.fsname;
function hung(b) {
let f = RUN + '/hung/' + b, h = readfile(f);
if (h == null) return false;
if (trim(h) == (readlink(SYS + '/class/block/' + b) ?? '?')) return true;
unlink(f);
return false;
}
function vfs(p) {
for (let m in mounts()) if (m.mnt == p && substr(m.dev, 0, 5) == '/dev/' && hung(baseof(substr(m.dev, 5)))) return { size: 0, free: 0, used: 0 };
let f = null;
try { f = require('fs').statvfs; } catch (e) { f = null; }
return UCFG.vfs(p, null, f, sh, q);
}
function disks() {
let M = mounts(), BI = blkinfo(M), C = lsdir(SYS + '/class/block') ?? [], sysd = {}, names = nascfg().disks ?? {}, R = [];
for (let m in M) if (index([ '/', '/rom', '/overlay', '/boot', '/boot/efi' ], m.mnt) >= 0 && substr(m.dev, 0, 5) == '/dev/') sysd[baseof(substr(m.dev, 5))] = 1;
let mmc = (b) => substr(b, 0, 6) == 'mmcblk' && sysr('/class/block/' + b + '/device/type') == 'MMC';
let ok = (d) => { let b = baseof(d); return !virt(d) && !sysd[b] && !mmc(b) && !match(d, /^mmcblk[0-9]+(boot|rpmb)/); };
let mnt = {};
for (let m in M) if (substr(m.dev, 0, 5) == '/dev/') { let d = substr(m.dev, 5); if (!mnt[d]) mnt[d] = m; }
let parts = {};
for (let d in C) if (d != baseof(d) || match(d, /^md[0-9]+$/)) parts[baseof(d)] = 1;
let devs = [];
for (let d in C) {
if (!ok(d)) continue;
if (!mnt[d] && +sysr('/class/block/' + d + '/size') == 0) continue;
let I = BI[d] ?? {}, T = I.TYPE ?? (mnt[d]?.fs ?? '');
if (T == 'linux_raid_member' || T == 'swap' || T == 'squashfs' || T == 'ubifs' || T == 'jffs2') continue;
if (d == baseof(d) && !match(d, /^md[0-9]+$/) && parts[d] && !length(T)) continue;
if (d != baseof(d) && !length(T) && !mnt[d]) continue;
push(devs, d);
}
for (let d in sort(devs)) {
let I = BI[d] ?? {}, m = mnt[d], b = baseof(d), u = lc(replace(I.UUID ?? '', /[^A-Za-z0-9-]/g, ''));
let id = length(u) ? u : d, v = m && !hung(b) ? vfs(m.mnt) : { size: +sysr('/class/block/' + d + '/size') * 512, used: null, free: null };
let model = trim(sysr('/class/block/' + b + '/device/vendor') + ' ' + sysr('/class/block/' + b + '/device/model'));
let x = { id: id, name: names[id]?.name ?? (length(I.LABEL) ? I.LABEL : (length(model) ? model : d)), dev: d, base: b,
fs: fsname(m?.fs ?? I.TYPE), mnt: m?.mnt ?? '', mounted: !!m, size: v.size, used: v.used, free: v.free, ro: m ? m.ro : false,
md: !!match(b, /^md[0-9]+$/) };
let st = names[id]?.ro;
x.lock = type(st) == 'bool' ? st : x.fs == 'ntfs';
push(R, x);
}
return R;
}
function diskby(id) {
for (let d in disks()) if (d.id == '' + id) return d;
return null;
}
function asleep(d) {
let c = nascfg().sleep ?? {}, m = type(c.mins) == 'int' && c.mins >= 0 ? c.mins : 15;
if (d.md || m <= 0 || c.keep === true) return false;
let x = split(trim(readfile(SYS + '/class/block/' + d.base + '/stat') ?? ''), /[ \t]+/);
if (length(x) < 7) return false;
let r = +x[2] * 512, w = +x[6] * 512, f = RUN + '/scan/' + d.id + '.io', p = rj(f), now = time();
if (!p || p.r != r || p.w != w) {
let n = (rj(RUN + '/io.json') ?? {})[d.base], chg = !p && n && n.r == r && n.w == w && n.chg ? n.chg : now;
mkdirp(RUN + '/scan');
wjr(f, { r: r, w: w, chg: chg });
return now - chg >= m * 60;
}
return now - (p.chg ?? now) >= m * 60;
}
function waking(D) {
if (!asleep(D)) return false;
let f = RUN + '/scan/' + D.id + '.wake', s = stat(f), v = trim(readfile(f) ?? '');
if (s && v == 'ok' && time() - s.mtime < 60) return false;
if (s && time() - s.mtime < 30 && (v == 'go' || (match(v, /^[0-9]+$/) && has(PROC + '/' + v)))) return true;
mkdirp(RUN + '/scan');
writefile(f, 'go');
let nb = int(+sysr('/class/block/' + D.dev + '/size') / 8), sk = nb > 1 ? (time() * 7919) % nb : 0, dv = q('/dev/' + D.dev), ft = q(f + '.t');
let dd = 'dd if=' + dv + ' of=/dev/null bs=4096 count=1 skip=' + sk;
bg('sh -c ' + q('echo $$ > ' + ft + ' && mv -f ' + ft + ' ' + q(f) + '; ' + dd + ' iflag=direct 2>/dev/null || ' + dd + ' 2>/dev/null; ls -a ' +
q(D.mnt) + ' >/dev/null 2>&1; echo ok > ' + ft + ' && mv -f ' + ft + ' ' + q(f)));
return true;
}
function wakerr() { return { error: 'Sveglio il disco…', error_en: 'Waking up the drive…', code: 'asleep', asleep: true }; }

function badname(n) { return UCFG.badname(n); }
function relp(p) { return UCFG.relp(p); }
function rpath(p) { let f = require('fs').realpath, r = null; if (type(f) != 'function') return null; try { r = f(p); } catch (e) { r = null; } return r; }
function shl(D, P, i) { return type(UCFG.shlnk) == 'function' ? UCFG.shlnk(D.mnt, P, i) : null; }
function absp(D, p) {
let P = relp(p);
if (P == null) return null;
let a = D.mnt;
for (let i = 0; i < length(P); i++) {
a += '/' + P[i];
let s = lstat(a);
if (s && s.type == 'link') { let Q = shl(D, P, i); if (!Q) return null; P = Q; a = D.mnt + '/' + P[0] + '/' + P[1]; i = 1; }
}
let r = length(P) ? rpath(a) : null, m = r ? rpath(D.mnt) : null;
if (r && m && r != m + '/' + join('/', P)) return null;
return { abs: a, rel: '/' + join('/', P), parts: P };
}
function dname(a) { return replace(a, /\/[^\/]*$/, ''); }
function bname(a) { return replace(a, /^.*\//, ''); }
function dsk(id, write) {
let D = diskby(id);
if (!D) return err('Disco non trovato', 'Drive not found');
if (!D.mounted) return err('Disco non collegato', 'Drive not mounted');
if (write && D.lock) return err('Disco in Sola Lettura: niente è cambiato. Per scrivere spegni Sola Lettura', 'Drive is Read Only: nothing changed. Turn off Read Only to write', { ro: true, code: 'ro' });
if (write && D.ro) return err('Disco in sola lettura', 'Drive is read-only', { ro: true, code: 'ro' });
return D;
}
function still(D) {
if (!has(SYS + '/class/block/' + D.dev)) return false;
for (let m in mounts()) if (m.mnt == D.mnt && m.dev == '/dev/' + D.dev) return true;
return false;
}
function gonerr(it, en) { return { error: it, error_en: en, code: 'gone' }; }

function who(req) {
if (type(UCFG.who) != 'function') return { own: 'admin', adm: true };
let O = {}, W = UCFG.who(req, O);
return W ?? (O.why == 'blocked' ? { blocked: true } : null);
}
function werr(W) {
if (W?.blocked) return err('Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator', { code: 'blocked' });
return err('Accesso scaduto: entra di nuovo', 'Access expired: sign in again', { code: 'who' });
}
function errp() { return err('Cartella di un\'altra persona', 'Another person\'s folder', { code: 'private' }); }
function errb() { return err('Cartella di base: non si cancella né si rinomina', 'Base folder: it cannot be deleted or renamed', { code: 'base' }); }
function nomain() { return err('Manca il Disco Principale', 'Main Drive missing', { code: 'nomain' }); }
function upart(o, k, s) { let p = type(UCFG.udir) == 'function' ? UCFG.udir(o, k, s) : null; return p == null ? null : relp(p); }
function under(P, B) {
if (B == null || P == null || length(P) < length(B)) return false;
for (let i = 0; i < length(B); i++) if (lc(P[i]) != lc(B[i])) return false;
return true;
}
function same(P, B) { return P != null && B != null && length(P) == length(B) && under(P, B); }
function ismain(D, NC) {
let m = NC.main;
return type(m) == 'object' && m.id != null && (D.id == '' + m.id || D.dev == '' + m.id || (length(m.uuid ?? '') && D.id == lc('' + m.uuid)));
}
function persons(NC) { let r = []; for (let u, x in (type(NC.users) == 'object' ? NC.users : {})) if (type(x) == 'object' && !x.cam) push(r, u); return r; }
function gones(NC) { return map(filter(type(NC.gone) == 'array' ? NC.gone : [], (g) => type(g) == 'object' && g.user != null), (g) => '' + g.user); }
function ctx(W, D) {
let NC = nascfg(), X = { W: W, NC: NC, D: D, main: ismain(D, NC), mine: [], lock: [], sh: upart('shared', 'root') };
let L2 = W.adm ? (type(UCFG.upriv) == 'function' ? [] : persons(NC)) : uniq([ ...persons(NC), ...gones(NC) ]);
for (let u in L2) if (u != W.own) { let p = upart(u, 'root'); if (p) push(X.lock, p); }
X.gone = [];
if (W.adm) for (let u in gones(NC)) { let p = upart(u, 'root'); if (p) push(X.gone, p); }
if (!W.adm) for (let p in [ upart(W.own, 'root'), X.sh ]) if (p) push(X.mine, p);
return X;
}
function posto(X, C) {
for (let l in X.lock) if (under(C, l)) return length(C) == length(l) ? 'lock' : 'no';
if (X.W.adm) { let v = type(UCFG.upriv) == 'function' ? UCFG.upriv(X.W, C, X.NC) : null; return v == 'lock' ? 'lock' : (v == 'in' ? 'no' : 'ok'); }
if (!X.main) return 'no';
for (let m in X.mine) if (under(C, m)) return 'ok';
for (let m in X.mine) if (under(m, C)) return 'up';
return 'no';
}
function whole(X, P) { return X.W.adm && type(UCFG.upriv) == 'function' && UCFG.upriv(X.W, P, X.NC) == 'up'; }
function basedirs(X) {
if (!X.main) return [];
if (X.base) return X.base;
let L2 = type(UCFG.ubase) == 'function' ? UCFG.ubase(X.NC) : [];
return (X.base = filter(map(L2, (p) => p == null ? null : relp(p)), (P) => P != null && length(P)));
}
function isbase(X, P) { for (let b in basedirs(X)) if (same(P, b)) return true; return false; }
function bkparts(NC) {
let r = [];
for (let u in [ 'admin', ...persons(NC), ...gones(NC) ]) for (let k in [ 'backup', 'tm', 'fh' ]) { let p = upart(u, k); if (p) push(r, p); }
return r;
}
const OWNOLD = ETC + '/nas-own.json', OWNN = '.wf-own.json';
function ownf(D) { return D.mnt + '/' + OWNN; }
function ownold(D) {
let O = rj(OWNOLD), r = {}, p = D.id + ':';
if (type(O) == 'object') for (let k, v in O) if (substr(k, 0, length(p)) == p) r[k] = v;
return r;
}
function owns(D) {
let O = rj(ownf(D));
if (type(O) != 'object') O = {};
for (let k, v in ownold(D)) if (O[k] == null) O[k] = v;
return O;
}
const PASSWD = getenv('WF_PASSWD') ?? '/etc/passwd';
function uidown(uid) {
if (uid == null) return null;
for (let l in split(readfile(PASSWD) ?? '', '\n')) {
let f = split(l, ':');
if (length(f) >= 5 && f[4] == 'wf-nas' && f[2] == '' + uid) return f[0];
}
return null;
}
const OWNFS = { ext2: 1, ext3: 1, ext4: 1, btrfs: 1, f2fs: 1, xfs: 1 };
function ownfix(mnt, L, who) {
mnt = '' + mnt;
let M = filter(mounts(), (m) => m.mnt == mnt), n = 0;
if (!length(M) || !OWNFS[M[length(M) - 1].fs] || type(L) != 'array') return 0;
let N = nascfg(), U = {}, V = {}, sh0 = UCFG.udir('shared', 'root', null, N), ur = UCFG.udir('admin', 'root', null, N);
for (let f in map(split(readfile(PASSWD) ?? '', '\n'), (l) => split(l, ':'))) {
if (length(f) < 5 || f[4] != 'wf-nas' || !match(f[0], /^[A-Za-z0-9._-]+$/) || !match(f[2], /^[1-9][0-9]*$/) || !match(f[3], /^[0-9]+$/)) continue;
U[f[0]] = f[2] + ':' + f[3];
let d = UCFG.udir(f[0], 'root', null, N);
if (type(d) == 'string' && d != sh0 && d != ur) V[d] = f[0];
}
for (let p in L) {
p = '' + p;
if (index(p, mnt + '/') != 0 || index(p, '/../') >= 0 || substr(p, -3) == '/..') continue;
let r = split(substr(p, length(mnt) + 1), '/');
if (length(r) < 3 || r[0] != 'Utenti' || !length(r[1]) || !length(r[2])) continue;
let top = 'Utenti/' + r[1], ug = top == sh0 ? U['' + who] : (V[top] ? U[V[top]] : null);
if (!ug) continue;
let s = lstat(p), b = lstat(mnt + '/' + top);
if (!s || s.type == 'link' || !b || b.type != 'directory') continue;
let rp = rpath(p), rb = rpath(mnt + '/' + top);
if (!rp || !rb || index(rp, rb + '/') != 0) continue;
sh('find ' + q(rp) + ' -xdev -user 0 ! -type l ! -perm -1000 -exec chown ' + ug + ' {} + -exec chmod g+w {} + 2>/dev/null');
n++;
}
return n;
}
function ownfixx() {
let f = getenv('WFO_L'), L = f ? split(readfile(f) ?? '', '\n') : [];
if (f) unlink(f);
return { ok: true, n: ownfix(getenv('WFO_M') ?? '', filter(L, (x) => length(x)), getenv('WFO_W') ?? '') };
}

function ownof(D, P, O) {
O = O ?? owns(D);
let k0 = D.id + ':/' + join('/', P);
if (O[k0] != null) return O[k0];
if (match(D.fs ?? '', /^ext[234]$/)) { let u = uidown(lstat(D.mnt + '/' + join('/', P))?.uid); if (u != null) return u; }
for (let i = length(P) - 1; i > 0; i--) { let k = D.id + ':/' + join('/', slice(P, 0, i)); if (O[k] != null) return O[k]; }
return null;
}
function ownset(X, L2, uid) {
if (X.W.adm || !X.sh) return;
L2 = filter(L2, (P) => under(P, X.sh) && length(P) > length(X.sh));
if (!length(L2)) return;
let D = X.D, ext = uid && match(D.fs ?? '', /^ext[234]$/), mig = length(keys(ownold(D))) > 0, ch = mig;
UCFG.njset(() => owns(D), (o) => {
for (let P in L2) {
let k = D.id + ':/' + join('/', P);
if (o[k] == X.W.own || (ext && o[k] == null && uidown(lstat(D.mnt + '/' + join('/', P))?.uid) == X.W.own)) continue;
o[k] = X.W.own; ch = true;
}
if (ch && length(keys(o)) > 5000) for (let k in keys(o)) if (substr(k, 0, length(D.id) + 1) == D.id + ':' && !lstat(D.mnt + substr(k, length(D.id) + 1))) delete o[k];
}, (o) => {
if (!ch) return;
wjr(ownf(D), o);
if (!mig) return;
let R = rj(ownf(D)), O = rj(OWNOLD), p = D.id + ':';
if (type(R) != 'object' || type(O) != 'object') return;
for (let k, v in ownold(D)) if (R[k] == null && lstat(D.mnt + substr(k, length(p)))) return;
for (let k in keys(O)) if (substr(k, 0, length(p)) == p) delete O[k];
if (length(keys(O))) wjr(OWNOLD, O); else unlink(OWNOLD);
});
}
function mayedit(X, P) {
if (posto(X, P) != 'ok') return false;
return X.W.adm || !under(P, X.sh) || ownof(X.D, P) == X.W.own;
}
function qfull(X) {
if (X.W.adm) return null;
let q = +(X.NC.users?.[X.W.own]?.quota?.disk ?? 0), u = +((rj(RUN + '/quota.json') ?? {})[X.W.own] ?? 0);
let fl = index(split(readfile(RUN + '/full.list') ?? '', '\n'), X.W.own) >= 0;
if (!(q > 0) || (!fl && u < q * 1073741824)) return null;
return err('Spazio finito: libera spazio o chiedi più spazio', 'Space used up: free some space or ask for more space', { code: 'quota_full', pct: int(u * 100 / (q * 1073741824)) });
}
function wdsk(W, id, write) {
if (W.adm) return dsk(id, write);
let m = nascfg().main;
if (type(m) != 'object' || m.id == null) return nomain();
let D = dsk(id ?? m.id, write);
if (D.error) return D;
if (!ismain(D, nascfg())) return errp();
if (write && has(RUN + '/mainpause.json'))
return err('Disco Principale in pausa: niente è cambiato', 'Main Drive paused: nothing changed', { code: 'nomain', pause: true });
return D;
}
function ftype(n) {
let m = match(lc('' + n), /\.([a-z0-9]+)$/);
if (m) for (let k, L2 in TYPES) if (index(L2, m[1]) >= 0) return k;
return 'oth';
}
function hidden(root, n) { return substr(n, 0, 1) == '.' || (root && index(SYSN, lc(n)) >= 0); }
function bkdirs(NC) {
let r = [];
for (let b in (type(NC.backups) == 'array' ? NC.backups : [])) if (b?.dest?.kind != 'nas' && b?.dest?.disk) push(r, b.dest.disk + ':' + (b.dest.path ?? ''));
for (let k in [ 'tm', 'fh' ]) if (NC[k]?.on === true && NC[k].disk) push(r, NC[k].disk + ':' + (NC[k].path ?? ''));
return r;
}

function newid() { return substr(replace(readfile('/proc/sys/kernel/random/uuid') ?? ('' + time()), /-/g, ''), 0, 12); }
function alive(p) { return match('' + p, /^[0-9]+$/) && has(PROC + '/' + p); }
function jobget(id) {
let j = rj(JOBS + '/' + id + '.json');
if (!j) return null;
let kn = JOBS + '/' + id + '.kn', KD = j.own && j.own != 'admin' && has(kn) ? diskby(j.to_disk) : null;
if (KD?.mounted && rename(kn, kn + '.' + PID)) {
let L2 = filter(map(split(readfile(kn + '.' + PID) ?? '', '\n'), (l) => length(l) ? relp(l) : null), (P) => P != null && length(P));
ownset(ctx({ own: j.own, adm: false }, KD), L2);
unlink(kn + '.' + PID);
}
return UCFG.jobchk(JOBS, id, j, alive, wjr);
}
function jobs() { return UCFG.joblist(JOBS, jobget, [ '.kn', '.tro' ]); }
function jobstart(op, disk, todisk, kv, src, total, btotal, runner) {
let id = newid(), Ls = [ 'op=' + op, 'disk=' + disk, 'to_disk=' + (todisk ?? ''), 'total=' + (total ?? 0), 'bytes_total=' + (btotal ?? 0) ];
for (let k, v in kv) push(Ls, k + '=' + v);
for (let s in src ?? []) { push(Ls, 'src=' + s.abs, 'rel=' + s.rel); if (s.nr) push(Ls, 'nr=1'); }
for (let l in Ls) if (index(l, '\n') >= 0 || index(l, '\r') >= 0) return err('Percorso non valido', 'Invalid path');
mkdirp(JOBS);
writefile(JOBS + '/' + id + '.in', join('\n', Ls) + '\n');
let j = { id: id, op: op, disk: disk, to_disk: todisk ?? '', done: 0, total: total ?? 0, bytes: 0, bytes_total: btotal ?? 0, file: '', state: 'run', t0: time(), t1: 0 };
if (kv?.forever) j.forever = true;
j.own = kv?.own ?? 'admin';
wjr(JOBS + '/' + id + '.json', j);
bg('sh ' + q(runner ?? JOB) + ' run ' + id);
return { job: id };
}
function walk(p, A) {
if (A.over) return;
let s = lstat(p);
if (!s) return;
if (++A.n > WALKMAX || ((A.n & 63) == 1 && time() - (A.t0 ?? time()) >= WALKSEC)) { A.over = true; return; }
if (s.type == 'directory') { for (let e in lsdir(p) ?? []) walk(p + '/' + e, A); return; }
A.files++;
if (s.type == 'file') { A.bytes += s.size; if (s.size > FATMAX && length(A.big) < 20) push(A.big, p); }
}
function jobin(id) {
let r = { src: [], rel: [] };
for (let l in split(readfile(JOBS + '/' + id + '.in') ?? '', '\n')) {
let i = index(l, '=');
if (i <= 0) continue;
let k = substr(l, 0, i), v = substr(l, i + 1);
if (k == 'src' || k == 'rel') push(r[k], v); else r[k] = v;
}
return r;
}
function livejobs() { return filter(jobs(), (j) => j.state == 'run' || j.state == 'ask'); }
function reserved(L, tid) {
let n = 0;
for (let j in L) if (j.to_disk == tid && (j.op == 'copy' || j.op == 'backup' || (j.op == 'move' && j.disk != j.to_disk))) {
let r = (+(j.bytes_total ?? 0) || 0) - (+(j.bytes ?? 0) || 0);
if (r > 0) n += r;
}
return n;
}
function samedest(L, T) {
let near = (a, b) => a == b || substr(a, 0, length(b) + 1) == b + '/' || substr(b, 0, length(a) + 1) == a + '/';
for (let j in L) {
let I = jobin(j.id);
if (!length(I.dst ?? '')) continue;
for (let r in I.rel) { let x = I.dst + '/' + bname(r); for (let t in T) if (near(x, t)) return j.id; }
}
return null;
}

function trdir(D, top) {
let T = D.mnt + '/' + TRASH;
for (let p in (top ? [ T ] : [ T, T + '/files', T + '/info' ])) { let s = lstat(p); if (!s || s.type != 'directory') return null; }
return T;
}
function trashinfo(f) {
let o = {};
for (let l in split(readfile(f) ?? '', '\n')) { let i = index(l, '='); if (i > 0) o[substr(l, 0, i)] = substr(l, i + 1); }
return o;
}
function trashdays() { let v = nascfg().trash?.days; return type(v) == 'int' && v >= 1 ? v : TRDEF; }
function trmine(X, o) { let P = relp(o.from ?? ''); return P == null || !length(P) ? X.W.adm : mayedit(X, P); }
const SMBMAX = 5000;
function trhex(s) { let r = ''; for (let i = 0; i < length(s); i++) r += sprintf('%02x', ord(s, i)); return r; }
function trunhex(h) {
if (!length(h) || length(h) % 2 || !match(h, /^[0-9a-f]+$/)) return null;
let r = ''; for (let i = 0; i < length(h); i += 2) r += chr(hex(substr(h, i, 2))); return r;
}
function smbwho(NC, u) { for (let p in persons(NC)) if (lc(p) == lc(u)) return p; return u; }
function smbsees(W, u) { return W.adm || lc(u) == lc(W.own); }
function smbusers(T) {
return filter(lsdir(T) ?? [], (x) => x != 'files' && x != 'info' && substr(x, 0, 1) != '.' && substr(x, 0, 4) != 'via.' && lstat(T + '/' + x)?.type == 'directory');
}
function smbwalk(T, u, fn) {
let n = 0, st = [ '' ];
while (length(st) && n < SMBMAX) {
let r = pop(st), d = T + '/' + u + r;
for (let f in lsdir(d) ?? []) {
let s = lstat(d + '/' + f);
if (!s) continue;
if (s.type == 'directory') push(st, r + '/' + f);
else if (s.type == 'file') { fn(substr(r + '/' + f, 1), s); if (++n >= SMBMAX) break; }
}
}
}
const SMBTPL = getenv('WF_SMBTPL') ?? '/etc/samba/smb.conf.template';
let SMBS = null;
function smbsecs() {
let s = stat(SMBTPL), k = s ? s.mtime + ':' + s.size : '';
if (SMBS?.k == k) return SMBS.S;
let S = {}, n = null;
for (let l in split(readfile(SMBTPL) ?? '', '\n')) {
let m = match(l, /^[ \t]*\[([^\]\/]+)\][ \t]*$/), p = match(l, /^[ \t]*path[ \t]*=[ \t]*(\/.*[^ \t])[ \t]*$/);
if (m) n = m[1];
else if (p && n != null && S[n] == null) S[n] = p[1];
}
SMBS = { k: k, S: S };
return S;
}
function smbdest(D, NC, u, R) {
let w = smbwho(NC, u), B = [], sp = length(R) > 1 ? smbsecs()[R[0]] : null, sb = null;
if (sp != null) {
if (index(sp, '%u') >= 0) sb = upart(w, 'root');
else if (sp == D.mnt) sb = [];
else if (substr(sp, 0, length(D.mnt) + 1) == D.mnt + '/') sb = relp(substr(sp, length(D.mnt) + 1));
}
if (sb != null) { push(B, sb); R = slice(R, 1); }
else for (let p in [ upart(w, 'root'), upart('shared', 'root'), [] ]) if (p != null) push(B, p);
for (let b in B) {
let P = [ ...b, ...R ], par = D.mnt + (length(P) > 1 ? '/' + join('/', slice(P, 0, -1)) : '');
if (stat(par)?.type != 'directory') continue;
let rp = rpath(par);
if (rp == null || rp == D.mnt) return rp == null ? P : [ R[length(R) - 1] ];
if (substr(rp, 0, length(D.mnt) + 1) == D.mnt + '/') return [ ...relp(substr(rp, length(D.mnt) + 1)), R[length(R) - 1] ];
}
return [ ...B[0], ...R ];
}
function smbprune(T, C) { for (let i = length(C) - 1; i >= 1; i--) if (!rmdir(T + '/' + join('/', slice(C, 0, i)))) break; }
function trashget(only, W) {
let It = [], tot = 0;
W = W ?? { own: 'admin', adm: true };
for (let d in disks()) {
if (!d.mounted || (only && d.id != only)) continue;
let T0 = trdir(d, true), NC = T0 ? nascfg() : null;
if (T0) for (let u in smbusers(T0)) {
if (!smbsees(W, u)) continue;
let w = smbwho(NC, u);
smbwalk(T0, u, (r, s) => {
let P = smbdest(d, NC, u, split(r, '/'));
push(It, { item: d.id + '/s.' + trhex(u + '/' + r), disk: d.id, name: bname(r), size: s.size, when: s.mtime, from: '/' + join('/', P), owner: w, smb: true });
tot += s.size;
});
}
let T = trdir(d), X = T ? ctx(W, d) : null;
if (!T) continue;
for (let f in lsdir(T + '/info') ?? []) {
let m = match(f, /^([0-9A-Za-z._-]+)\.info$/);
if (!m || !has(T + '/files/' + m[1])) continue;
let o = trashinfo(T + '/info/' + f), sz = +(o.size ?? 0);
if (!trmine(X, o)) continue;
push(It, { item: d.id + '/' + m[1], disk: d.id, name: bname(o.from ?? m[1]), size: sz, when: +(o.when ?? 0), from: o.from ?? '' });
tot += sz;
}
}
let dd = trashdays();
return { days: W.adm || dd < TRPERS ? dd : TRPERS, items: sort(It, (a, b) => b.when - a.when), size: tot };
}
const TROWN = RUN + '/trash-own.json';
function trashown(tick, nowake) {
let NC = nascfg(), U = persons(NC), R = {}, D = null;
for (let u in U) R[u] = { n: 0, bytes: 0 };
for (let d in disks()) if (d.mounted && ismain(d, NC)) { D = d; break; }
let T = D ? trdir(D, true) : null;
if (T && (tick || nowake) && asleep(D)) return null;
if (T) {
let O = owns(D), sh = upart('shared', 'root'), RT = [], cut = time() - TRPERS * 86400, G = [], XU = {};
for (let u in U) { let p = upart(u, 'root'); if (p) push(RT, [ u, p ]); }
for (let f in (trdir(D) ? lsdir(T + '/info') : null) ?? []) {
let m = match(f, /^([0-9A-Za-z._-]+)\.info$/);
if (!m || !lstat(T + '/files/' + m[1])) continue;
let o = trashinfo(T + '/info/' + f), P = relp(o.from ?? ''), u = null;
if (P == null || !length(P)) continue;
for (let r in RT) if (under(P, r[1])) { u = r[0]; break; }
if (u == null && sh && under(P, sh) && length(P) > length(sh)) { let w = ownof(D, P, O); if (w != null && R[w]) u = w; }
if (u == null) continue;
XU[u] ??= ctx({ own: u, adm: false }, D);
if (posto(XU[u], P) != 'ok') continue;
if (tick && !D.ro && !D.lock && +(o.when ?? 0) > 0 && +o.when < cut) {
let v = T + '/via.' + time() + '.' + m[1];
if (rename(T + '/files/' + m[1], v)) { unlink(T + '/info/' + f); push(G, q(v)); continue; }
}
R[u].n++; R[u].bytes += +(o.size ?? 0);
}
for (let x in smbusers(T)) {
let u = smbwho(NC, x);
if (!R[u]) continue;
smbwalk(T, x, (r, s) => {
if (tick && !D.ro && !D.lock && s.mtime > 0 && s.mtime < cut && unlink(T + '/' + x + '/' + r)) { smbprune(T, [ x, ...split(r, '/') ]); return; }
R[u].n++; R[u].bytes += s.size;
});
}
if (length(G)) bg('rm -rf ' + join(' ', G));
}
mkdirp(RUN);
wjr(TROWN, R);
return R;
}
function trowbg() { bg('sh ' + q(FSH) + ' trown'); }
function freename(dir, n) {
if (!lstat(dir + '/' + n)) return n;
let m = match(n, /^(.+)(\.[^.]+)$/), b = m ? m[1] : n, x = m ? m[2] : '';
for (let i = 2; i < 10000; i++) if (!lstat(dir + '/' + b + ' (' + i + ')' + x)) return b + ' (' + i + ')' + x;
return null;
}
function jobundo(j) {
if (j.state == 'run' || j.state == 'ask' || j.forever || (j.op != 'delete' && j.op != 'move')) return j;
let I = jobin(j.id);
if (j.op == 'delete') {
let D = diskby(j.disk), T = [], TD = D?.mounted ? trdir(D) : null;
if (TD && length(I.rel)) {
for (let f in lsdir(TD + '/info') ?? []) {
let m = match(f, /^([0-9A-Za-z._-]+)\.info$/);
if (!m || !has(TD + '/files/' + m[1])) continue;
let o = trashinfo(TD + '/info/' + f), w = +(o.when ?? 0);
if (index(I.rel, o.from ?? '') >= 0 && w >= (j.t0 ?? 0) - 1 && (!j.t1 || w <= j.t1 + 1)) push(T, D.id + '/' + m[1]);
}
}
j.trash = T;
}
else {
let O = [];
if (length(I.droot ?? '') && length(I.drel ?? '')) for (let r in I.rel) {
let p = I.drel + '/' + bname(r);
if (lstat(I.droot + p)) push(O, p);
}
j.out = O;
}
return j;
}

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function b64e(s) {
if (type(global.b64enc) == 'function') return global.b64enc(s);
let o = [], n = length(s);
for (let i = 0; i < n; i += 3) {
let a = ord(s, i), b = i + 1 < n ? ord(s, i + 1) : 0, c = i + 2 < n ? ord(s, i + 2) : 0, v = (a << 16) | (b << 8) | c;
push(o, substr(B64, (v >> 18) & 63, 1) + substr(B64, (v >> 12) & 63, 1) + (i + 1 < n ? substr(B64, (v >> 6) & 63, 1) : '=') + (i + 2 < n ? substr(B64, v & 63, 1) : '='));
}
return join('', o);
}
const b64d = UCFG.b64d;

function bu16(s, i) { return ((ord(s, i) ?? 0) << 8) | (ord(s, i + 1) ?? 0); }
function bu32(s, i) { return (bu16(s, i) << 16) | bu16(s, i + 2); }
function lu16(s, i) { return (ord(s, i) ?? 0) | ((ord(s, i + 1) ?? 0) << 8); }
function lu32(s, i) { return lu16(s, i) | (lu16(s, i + 2) << 16); }
function u8(c) {
if (c < 128) return chr(c);
if (c < 2048) return chr(192 | (c >> 6), 128 | (c & 63));
if (c < 65536) return chr(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63));
return chr(240 | (c >> 18), 128 | ((c >> 12) & 63), 128 | ((c >> 6) & 63), 128 | (c & 63));
}
function clean(s) {
let i = index(s, chr(0));
if (i >= 0) s = substr(s, 0, i);
return cutn(trim(replace(s, /[\x01-\x1f\x7f]/g, ' ')), 120);
}
function dectxt(enc, s) {
let o = '';
if (enc == 1 || enc == 2) {
let be = enc == 2, i = 0;
if (enc == 1 && length(s) >= 2) { be = ord(s, 0) == 254 && ord(s, 1) == 255; if ((ord(s, 0) == 255 && ord(s, 1) == 254) || be) i = 2; }
for (; i + 1 < length(s); i += 2) {
let c = be ? bu16(s, i) : lu16(s, i);
if (c == 0) break;
if (c >= 0xD800 && c < 0xDC00 && i + 3 < length(s)) { let c2 = be ? bu16(s, i + 2) : lu16(s, i + 2); c = 0x10000 + ((c - 0xD800) << 10) + (c2 - 0xDC00); i += 2; }
o += u8(c);
}
return clean(o);
}
if (enc == 0) { for (let i = 0; i < length(s); i++) { let c = ord(s, i); if (c == 0) break; o += u8(c); } return clean(o); }
return clean(s);
}
function exiftime(s) {
let m = match(s ?? '', /^([0-9]{4}):([0-9]{2}):([0-9]{2}) ([0-9]{2}):([0-9]{2}):([0-9]{2})/);
if (!m || +m[1] < 1971) return null;
let y = +m[1], mo = +m[2], d = +m[3];
if (type(global.timelocal) == 'function') return global.timelocal({ year: y, mon: mo, mday: d, hour: +m[4], min: +m[5], sec: +m[6] });
let a = mo <= 2 ? 1 : 0, y2 = y - a, era = int(y2 / 400), yoe = y2 - era * 400, mp = (mo + 9) % 12;
let doy = int((153 * mp + 2) / 5) + d - 1, doe = yoe * 365 + int(yoe / 4) - int(yoe / 100) + doy;
return (era * 146097 + doe - 719468) * 86400 + +m[4] * 3600 + +m[5] * 60 + +m[6];
}
function exif(t, r) {
let le = substr(t, 0, 2) == 'II', g16 = (i) => le ? lu16(t, i) : bu16(t, i), g32 = (i) => le ? lu32(t, i) : bu32(t, i);
let str = (cnt, vo) => clean(substr(t, cnt <= 4 ? vo : g32(vo), cnt > 64 ? 64 : cnt));
let num = (tp, vo) => tp == 3 ? g16(vo) : g32(vo);
let ifd = (o, cb) => {
if (o <= 0 || o + 2 > length(t)) return;
let n = g16(o);
for (let i = 0; i < n && i < 200; i++) { let e = o + 2 + i * 12; if (e + 12 > length(t)) break; cb(g16(e), g16(e + 2), g32(e + 4), e + 8); }
};
let mk = '', md = '', ex = 0, W = 0, H = 0, dt = null;
ifd(g32(4), (tag, tp, cnt, vo) => {
if (tag == 0x10F) mk = str(cnt, vo);
else if (tag == 0x110) md = str(cnt, vo);
else if (tag == 0x112) r.rot = num(tp, vo);
else if (tag == 0x8769) ex = g32(vo);
});
ifd(ex, (tag, tp, cnt, vo) => {
if (tag == 0x9003) dt = str(cnt, vo);
else if (tag == 0xA002) W = num(tp, vo);
else if (tag == 0xA003) H = num(tp, vo);
});
if (W > 0 && H > 0) { r.w = W; r.h = H; }
let tk = exiftime(dt);
if (tk) r.taken = tk;
let w1 = lc(split(mk, ' ')[0] ?? '');
if (length(md)) r.cam = !length(w1) || w1 == 'apple' || index(lc(md), w1) >= 0 ? md : mk + ' ' + md;
else if (length(mk)) r.cam = mk;
}
function jpgm(f) {
let r = {}, o = 2;
for (let i = 0; i < 80; i++) {
f.seek(o);
let m = f.read(4) ?? '';
if (length(m) < 4 || ord(m, 0) != 255) break;
let k = ord(m, 1), z = bu16(m, 2);
if (k == 255) { o++; continue; }
if (k == 0xD8 || k == 1 || (k >= 0xD0 && k <= 0xD7)) { o += 2; continue; }
if (k == 0xDA || k == 0xD9) break;
if (k == 0xE1 && r.rot == null && z > 8) { let d = f.read(z - 2 > 65536 ? 65536 : z - 2) ?? ''; if (substr(d, 0, 6) == 'Exif' + chr(0, 0)) exif(substr(d, 6), r); }
else if (k >= 0xC0 && k <= 0xCF && k != 0xC4 && k != 0xC8 && k != 0xCC) { let d = f.read(5) ?? ''; r.h = bu16(d, 1); r.w = bu16(d, 3); break; }
o += 2 + z;
}
if (r.rot >= 5 && r.rot <= 8 && r.w) { let x = r.w; r.w = r.h; r.h = x; }
delete r.rot;
return r;
}
function mp4m(f, size, full) {
let r = {}, n = 0;
let boxes = (s, e, cb) => {
let o = s;
while (o + 8 <= e && n++ < 600) {
f.seek(o);
let h = f.read(16) ?? '';
if (length(h) < 8) break;
let z = bu32(h, 0), t = substr(h, 4, 4), hl = 8;
if (z == 1) { if (length(h) < 16) break; z = bu32(h, 8) * 4294967296 + bu32(h, 12); hl = 16; }
else if (z == 0) z = e - o;
if (z < hl) break;
cb(t, o + hl, o + z);
o += z;
}
};
let tags = { [chr(169) + 'nam']: 'title', [chr(169) + 'ART']: 'artist', [chr(169) + 'alb']: 'album' };
boxes(0, size, (t, s, e) => {
if (t != 'moov') return;
boxes(s, e, (t2, s2, e2) => {
if (t2 == 'mvhd') {
f.seek(s2);
let d = f.read(32) ?? '', v = ord(d, 0);
let ts = v == 1 ? bu32(d, 20) : bu32(d, 12), du = v == 1 ? bu32(d, 24) * 4294967296 + bu32(d, 28) : bu32(d, 16);
let ct = v == 1 ? bu32(d, 4) * 4294967296 + bu32(d, 8) : bu32(d, 4);
if (ts > 0) r.dur = int(du / ts);
if (full && ct > 2082844800) r.taken = ct - 2082844800;
}
else if (t2 == 'trak' && !r.w) boxes(s2, e2, (t3, s3, e3) => {
if (t3 != 'tkhd') return;
f.seek(s3);
let d = f.read(96) ?? '', o = ord(d, 0) == 1 ? 88 : 76, w = bu32(d, o) >> 16, h = bu32(d, o + 4) >> 16;
if (w > 0 && h > 0) { r.w = w; r.h = h; }
});
else if (t2 == 'udta') boxes(s2, e2, (t3, s3, e3) => {
if (t3 != 'meta') return;
boxes(s3 + 4, e3, (t4, s4, e4) => {
if (t4 != 'ilst') return;
boxes(s4, e4, (t5, s5, e5) => {
let k = tags[t5];
if (!k || (k == 'album' && !full)) return;
boxes(s5, e5, (t6, s6, e6) => { if (t6 == 'data' && e6 - s6 > 8) { f.seek(s6 + 8); r[k] = clean(f.read(e6 - s6 - 8 > 256 ? 256 : e6 - s6 - 8) ?? ''); } });
});
});
});
});
});
return r;
}
function mp3m(f, size, full) {
f.seek(0);
let h = f.read(10) ?? '', r = {}, start = 0;
if (substr(h, 0, 3) == 'ID3') {
let v = ord(h, 3), fl = ord(h, 5), z = ((ord(h, 6) & 127) << 21) | ((ord(h, 7) & 127) << 14) | ((ord(h, 8) & 127) << 7) | (ord(h, 9) & 127);
start = 10 + z + ((fl & 16) ? 10 : 0);
let d = f.read(z > (full ? 262144 : 65536) ? (full ? 262144 : 65536) : z) ?? '', p = 0;
if (fl & 64) p = v == 4 ? (((ord(d, 0) & 127) << 21) | ((ord(d, 1) & 127) << 14) | ((ord(d, 2) & 127) << 7) | (ord(d, 3) & 127)) : 4 + bu32(d, 0);
let K = v == 2 ? { TT2: 'title', TP1: 'artist', TAL: 'album', TLE: 'len' } : { TIT2: 'title', TPE1: 'artist', TALB: 'album', TLEN: 'len' };
for (let i = 0; i < 300 && p + (v == 2 ? 6 : 10) < length(d); i++) {
let id = substr(d, p, v == 2 ? 3 : 4), fz, hl = v == 2 ? 6 : 10;
if (ord(id, 0) == 0) break;
fz = v == 2 ? (ord(d, p + 3) << 16) | bu16(d, p + 4) : (v == 4 ? (((ord(d, p + 4) & 127) << 21) | ((ord(d, p + 5) & 127) << 14) | ((ord(d, p + 6) & 127) << 7) | (ord(d, p + 7) & 127)) : bu32(d, p + 4));
if (fz <= 0) break;
let k = K[id];
if (k && (k != 'album' || full)) {
let x = substr(d, p + hl, fz), t = dectxt(ord(x, 0), substr(x, 1));
if (k == 'len') { if (match(t, /^[0-9]+$/) && +t > 0) r.dur = int(+t / 1000); }
else if (length(t)) r[k] = t;
}
p += hl + fz;
}
}
if (r.dur) return r;
f.seek(start);
let b = f.read(4096) ?? '';
for (let i = 0; i + 4 < length(b); i++) {
if (ord(b, i) != 255 || (ord(b, i + 1) & 0xE0) != 0xE0) continue;
let b1 = ord(b, i + 1), b2 = ord(b, i + 2), ver = (b1 >> 3) & 3, lay = (b1 >> 1) & 3, bi = b2 >> 4, si = (b2 >> 2) & 3, mono = (ord(b, i + 3) >> 6) == 3;
if (lay != 1 || ver == 1 || bi == 0 || bi == 15 || si == 3) continue;
let br = (ver == 3 ? [ 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320 ] : [ 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160 ])[bi] * 1000;
let sr = [ 44100, 48000, 32000 ][si] / (ver == 3 ? 1 : (ver == 2 ? 2 : 4)), spf = ver == 3 ? 1152 : 576;
let xo = i + 4 + (ver == 3 ? (mono ? 17 : 32) : (mono ? 9 : 17)), tg = substr(b, xo, 4);
if ((tg == 'Xing' || tg == 'Info') && (bu32(b, xo + 4) & 1)) r.dur = int(bu32(b, xo + 8) * spf / sr);
else r.dur = int((size - start - i) * 8 / br);
break;
}
return r;
}
function flacm(f, full) {
let r = {}, o = 4;
for (let i = 0; i < 24; i++) {
f.seek(o);
let h = f.read(4) ?? '';
if (length(h) < 4) break;
let tp = ord(h, 0) & 127, z = (ord(h, 1) << 16) | bu16(h, 2);
if (tp == 0) {
let d = f.read(18) ?? '', sr = (ord(d, 10) << 12) | (ord(d, 11) << 4) | (ord(d, 12) >> 4), tot = (ord(d, 13) & 15) * 4294967296 + bu32(d, 14);
if (sr > 0) r.dur = int(tot / sr);
}
else if (tp == 4) {
let d = f.read(z > 65536 ? 65536 : z) ?? '', p = 4 + lu32(d, 0), n = lu32(d, p);
p += 4;
for (let k = 0; k < n && k < 100 && p + 4 <= length(d); k++) {
let l = lu32(d, p), kv = substr(d, p + 4, l), e = index(kv, '='), key = lc(substr(kv, 0, e));
if (e > 0 && (key == 'title' || key == 'artist' || (key == 'album' && full))) r[key] = clean(substr(kv, e + 1));
p += 4 + l;
}
}
if (ord(h, 0) & 128) break;
o += 4 + z;
}
return r;
}
function riffm(f, size, kind) {
f.seek(0);
let h = f.read(72) ?? '', r = {};
if (kind == 'AVI ') {
let us = lu32(h, 32), fr = lu32(h, 48);
if (substr(h, 24, 4) == 'avih' && lu32(h, 64) > 0) { r.w = lu32(h, 64); r.h = lu32(h, 68); }
if (us > 0 && fr > 0) r.dur = int(us * fr / 1000000);
return r;
}
let o = 12, br = 0;
for (let i = 0; i < 24 && o + 8 <= size; i++) {
f.seek(o);
let c = f.read(20) ?? '', id = substr(c, 0, 4), z = lu32(c, 4);
if (length(c) < 8) break;
if (id == 'fmt ') br = lu32(c, 16);
else if (id == 'data') { if (br > 0) r.dur = int(z / br); break; }
o += 8 + z + (z & 1);
}
return r;
}
function imgm(f, ext) {
f.seek(0);
let h = f.read(32) ?? '', r = {};
if (ext == 'png' && substr(h, 1, 3) == 'PNG') { r.w = bu32(h, 16); r.h = bu32(h, 20); }
else if (ext == 'gif' && substr(h, 0, 3) == 'GIF') { r.w = lu16(h, 6); r.h = lu16(h, 8); }
else if (ext == 'webp' && substr(h, 8, 4) == 'WEBP') {
let c = substr(h, 12, 4);
if (c == 'VP8X') { r.w = 1 + (lu16(h, 24) | (ord(h, 26) << 16)); r.h = 1 + (lu16(h, 27) | (ord(h, 29) << 16)); }
else if (c == 'VP8 ') { r.w = lu16(h, 26) & 0x3fff; r.h = lu16(h, 28) & 0x3fff; }
else if (c == 'VP8L') { r.w = 1 + (((ord(h, 22) & 63) << 8) | ord(h, 21)); r.h = 1 + (((ord(h, 24) & 15) << 10) | (ord(h, 23) << 2) | ((ord(h, 22) & 192) >> 6)); }
}
return r;
}
function metaof(abs, size, full) {
let m = match(lc(abs), /\.([a-z0-9]+)$/), e = m ? m[1] : '';
if (index([ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'mov', 'm4v', 'm4a', '3gp', 'mp3', 'flac', 'wav', 'avi' ], e) < 0) return null;
let f = open(abs, 'r');
if (!f) return null;
let r = null;
try {
if (e == 'jpg' || e == 'jpeg') { let h = f.read(2) ?? ''; r = h == chr(255, 216) ? jpgm(f) : {}; if (!full) delete r.cam; }
else if (e == 'png' || e == 'gif' || e == 'webp') r = imgm(f, e);
else if (e == 'mp3') r = mp3m(f, size, full);
else if (e == 'flac') r = (f.read(4) ?? '') == 'fLaC' ? flacm(f, full) : {};
else if (e == 'wav' || e == 'avi') { let h = f.read(12) ?? ''; r = substr(h, 0, 4) == 'RIFF' ? riffm(f, size, e == 'avi' ? 'AVI ' : 'WAVE') : {}; }
else r = mp4m(f, size, full);
} catch (x) { r = {}; }
f.close();
return r;
}

const SPD = ETC + '/nas-space', SCN = RUN + '/scan';
function spacef(id) { return SPD + '/' + id + '.json'; }
function spclean(keep) {
let K = nascfg().disks ?? {}, C = {}, now = time();
for (let d in disks()) C[d.id] = true;
for (let f in lsdir(SPD) ?? []) {
let m = match(f, /^(.+)\.json$/);
if (!m || m[1] == keep || C[m[1]]) continue;
let st = stat(SPD + '/' + f);
if (type(K[m[1]]) != 'object' || (st && now - st.mtime > 180 * 86400)) unlink(SPD + '/' + f);
}
}
function idxf(D) { return D.ro || D.lock ? RUN + '/idx/' + D.id + '.tsv' : D.mnt + '/' + IDXD + '/names.tsv'; }
function idxany(D) { for (let f in [ D.mnt + '/' + IDXD + '/names.tsv', RUN + '/idx/' + D.id + '.tsv' ]) if (has(f)) return f; return null; }
function scanning(id) { return alive(trim(readfile(SCN + '/' + id + '.run') ?? '')); }
function exdirs(D) {
let NC = nascfg(), r = [];
if (ismain(D, NC)) {
for (let p in [ ...bkparts(NC), upart('admin', 'cams'), upart('admin', 'router') ]) if (p) push(r, '/' + join('/', p));
for (let u in [ 'admin', ...persons(NC), ...gones(NC) ]) { let p = upart(u, 'phones'); if (p) push(r, '/' + join('/', p)); }
}
for (let b in bkdirs(NC)) { let i = index(b, ':'); if (substr(b, 0, i) == D.id) push(r, substr(b, i + 1)); }
for (let x in (type(NC.space?.exclude) == 'array' ? NC.space.exclude : [])) {
let i = index('' + x, ':');
if (i < 0) push(r, '' + x); else if (substr(x, 0, i) == D.id) push(r, substr(x, i + 1));
}
return uniq(filter(map(r, (p) => '/' + join('/', relp(p) ?? [])), (p) => p != '/'));
}
function md5s(L2, part) {
let R = {};
for (let i = 0; i < length(L2); i += 40) {
let B = slice(L2, i, i + 40), c = join('; ', map(B, (p) => part ?
'{ head -c 65536 ' + q(p) + '; tail -c 65536 ' + q(p) + '; } 2>/dev/null | md5sum' : 'md5sum < ' + q(p) + ' 2>/dev/null || echo -'));
let o = split(trim(sh(c)), '\n');
for (let k = 0; k < length(B); k++) R[B[k]] = substr(o[k] ?? '', 0, 32);
}
return R;
}
function topn(A, n) { return slice(sort(A, (a, b) => b.size - a.size), 0, n); }
function scan(id, kind, by) {
let D = diskby(id);
if (!D || !D.mounted) return { error: 'disk' };
let all = kind != 'index', now = time(), mnt = D.mnt, inram = D.ro || D.lock, cap = inram ? idxram() : IDXMAX;
let XD = all ? exdirs(D) : [], old = now - 730 * 86400, dupon = nascfg().space?.dup !== false;
let If = idxf(D), It = If + '.' + PID + '.t';
mkdirp(dname(If));
let fo = open(It, 'w');
if (!fo && !inram) { inram = true; cap = idxram(); If = RUN + '/idx/' + D.id + '.tsv'; It = If + '.' + PID + '.t'; mkdirp(dname(If)); fo = open(It, 'w'); }
if (!fo) return { error: 'index' };
let buf = [], nidx = 0, files = 0, dirs = {}, sysb = 0, other = 0, big = [], olds = [], bysz = {}, nsz = 0, part = false;
let isex = (rel) => { for (let x in XD) if (rel == x || substr(rel, 0, length(x) + 1) == x + '/') return true; return false; };
let PX = {}, parts = null;
if (all && ismain(D, nascfg())) {
parts = { shared: 0, cams: 0, router: 0 };
for (let k, p in { shared: upart('shared', 'root'), cams: upart('admin', 'cams'), router: upart('admin', 'router') })
if (p && length(p)) PX[k] = lc('/' + join('/', p));
}
let inpx = (rel) => { let l = lc(rel); for (let k, x in PX) if (substr(l, 0, length(x) + 1) == x + '/') return k; return null; };
let S = [ { a: mnt, r: '', top: null, hid: false, ex: false } ], nd = 0, bad = false;
let stop = () => { fo.close(); unlink(It); return { error: 'gone' }; };
while (length(S)) {
let c = pop(S), root = c.r == '', L = lsdir(c.a);
if (L == null) {
if (match(ferr(), /Input\/output|No such device|Stale|Transport endpoint/) || !lstat(mnt) || !still(D)) return stop();
continue;
}
if (++nd % 200 == 0 && !still(D)) return stop();
if (nd == 50) hook('scan');
for (let n in L) {
let a = c.a + '/' + n, r = c.r + '/' + n, st = lstat(a);
if (!st || st.type == 'link') continue;
let hid = c.hid || hidden(root, n) || badname(n), top = root ? n : c.top, ex = c.ex || (all && isex(r));
if (st.type == 'directory') { push(S, { a: a, r: r, top: top, hid: hid, ex: ex }); if (root && !hid) dirs[n] = dirs[n] ?? 0; continue; }
if (st.type != 'file') continue;
let z = st.size;
if (hid && !inram && substr(n, 0, 1) == '.' && substr(n, -7) == '.wfpart' && now - st.mtime > 86400 && substr(r, 0, 5) != '/.wf-' && unlink(a)) continue;
if (parts) { let pk = inpx(r); if (pk) parts[pk] += z; }
if (hid) { sysb += z; continue; }
files++;
if (root) other += z; else dirs[top] = (dirs[top] ?? 0) + z;
if (nidx < cap) {
push(buf, r + '\t' + z + '\t' + st.mtime); nidx++;
if (length(buf) >= 500) { if (fo.write(join('\n', buf) + '\n') == null) bad = true; buf = []; }
}
else part = true;
if (!all || ex) continue;
if (z >= 1048576) {
push(big, { path: r, size: z, mtime: st.mtime });
if (length(big) > 400) big = topn(big, 50);
if (st.mtime < old) { push(olds, { path: r, size: z, mtime: st.mtime }); if (length(olds) > 400) olds = topn(olds, 50); }
if (dupon && nsz < 50000) { let k = '' + z; if (!bysz[k]) bysz[k] = []; push(bysz[k], { path: r, size: z, mtime: st.mtime }); nsz++; }
}
else if (st.mtime < old && length(olds) < 400) push(olds, { path: r, size: z, mtime: st.mtime });
}
if (bad) return stop();
}
if (length(buf) && fo.write(join('\n', buf) + '\n') == null) return stop();
if (!still(D)) return stop();
fo.close();
rename(It, If);
for (let f in [ mnt + '/' + IDXD + '/names.tsv', RUN + '/idx/' + D.id + '.tsv' ]) if (f != If && has(f)) unlink(f);
if (!all) return { ok: true, files: nidx, partial: part };
let G = [], dn = 0, db = 0, nfp = 0;
for (let k, A in bysz) {
if (length(A) < 2 || nfp > 5000) continue;
nfp += length(A);
let P = map(A, (x) => mnt + x.path), fp = md5s(P, true), by = {};
for (let x in A) { let h = fp[mnt + x.path]; if (length(h) == 32) { if (!by[h]) by[h] = []; push(by[h], x); } }
for (let h, B in by) {
if (length(B) < 2) continue;
let sets = { [h]: B };
if (+k > 131072) {
sets = {};
let full = md5s(map(B, (x) => mnt + x.path), false);
for (let x in B) { let h2 = full[mnt + x.path]; if (length(h2) == 32) { if (!sets[h2]) sets[h2] = []; push(sets[h2], x); } }
}
for (let h2, C in sets) {
if (length(C) < 2) continue;
sort(C, (a, b) => a.mtime - b.mtime);
let cp = slice(C, 1, 51);
push(G, { keep: C[0], copies: cp });
dn += length(cp); db += length(cp) * C[0].size;
}
}
}
let NC = nascfg(), dld = +(NC.space?.dl_days ?? 30), DL = [], dlb = 0, DC = NC.dl ?? {};
let DP = DC.disk == D.id ? absp(D, DC.path ?? '/Download') : null, DD = DP ? DP.abs + '/.wf-dl/done' : null;
for (let p in (DD ? [ DP.abs + '/.wf-dl', DD ] : [])) { let s = lstat(p); if (!s || s.type != 'directory') { DD = null; break; } }
for (let f in (DD ? lsdir(DD) ?? [] : [])) {
if (!match(f, /^[0-9a-f]{16}\.json$/)) continue;
let x = rj(DD + '/' + f);
if (type(x) != 'object' || (x.disk ?? D.id) != D.id) continue;
let P = absp(D, '' + (x.path ?? '')), t = +(x.t ?? 0);
if (!P || !length(P.parts) || t > now - dld * 86400) continue;
let st = lstat(P.abs);
if (!st || st.type == 'link') continue;
let z = st.type == 'file' ? st.size : +(x.size ?? 0);
push(DL, { path: P.rel, size: z, mtime: st.mtime, done: t });
dlb += z;
}
let O = rj(spacef(id)) ?? {}, hist = filter(type(O.hist) == 'array' ? O.hist : [], (h) => h.d != day(now));
push(hist, { d: day(now), t: now, used: D.used ?? 0, size: D.size ?? 0 });
hist = slice(hist, -14);
let DS = [];
for (let k, v in dirs) push(DS, { path: '/' + k, size: v });
let R = { at: now, id: id, by: by ?? 'night', files: files, dirs: slice(sort(DS, (a, b) => b.size - a.size), 0, 40), sys: sysb, other: other,
big: topn(big, 50), old: topn(olds, 50), dup: { n: dn, groups: length(G), bytes: db, list: slice(sort(G, (a, b) => b.keep.size * length(b.copies) - a.keep.size * length(a.copies)), 0, 100) },
dl: { n: length(DL), bytes: dlb, list: slice(sort(DL, (a, b) => b.size - a.size), 0, 100) }, hist: hist };
if (part) R.partial = true;
if (parts) R.parts = parts;
if (!still(D)) return { error: 'gone' };
mkdirp(SPD);
wjr(spacef(id), R);
spclean(id);
mkdirp(SCN);
writefile(SCN + '/' + id + '.day', day(now));
if (by == 'hand') ev('nas_space_ok', '💾 ' + cutn(D.name, 24) + ' ¦ ' + L('Analisi pronta', 'Analysis ready') + ' ¦ ' +
(dlb + db > 0 ? L('Puoi liberare ', 'You can free ') + gb(dlb + db) : L('Niente da liberare', 'Nothing to free')));
return { ok: true, files: files };
}
function plan() {
let h = nascfg().space?.hour, H = type(h) == 'int' && h >= 0 && h <= 23 ? h : 3, lt = localtime(), R = [];
let off = (lt.hour - H + 24) % 24, win = off < 4, w0 = time() - off * 3600 - lt.min * 60 - lt.sec;
try { trashown(true); } catch (e) { }
for (let d in disks()) {
if (!d.mounted || asleep(d) || scanning(d.id)) continue;
let done = (stat(SCN + '/' + d.id + '.day')?.mtime ?? 0) >= w0 || ((rj(spacef(d.id)) ?? {}).at ?? 0) >= w0;
if (win && !done) push(R, d.id + ' all');
else if (!idxany(d)) push(R, d.id + ' index');
}
return R;
}
function spaceout(D) {
let A = rj(spacef(D.id)), T = trashget(D.id), r = { disk: D.id, size: D.size, used: D.used, free: D.free, ro: D.ro || D.lock, run: scanning(D.id) };
let dd = +(nascfg().space?.dl_days ?? 30);
let tips = [ { k: 'dl', n: A?.dl?.n ?? 0, bytes: A?.dl?.bytes ?? 0, days: dd }, { k: 'dup', n: A?.dup?.n ?? 0, groups: A?.dup?.groups ?? 0, bytes: A?.dup?.bytes ?? 0 },
{ k: 'trash', n: length(T.items), bytes: T.size } ];
r.at = A?.at ?? 0; r.files = A?.files ?? 0; r.tips = tips; r.can = tips[0].bytes + tips[1].bytes + tips[2].bytes;
r.dirs = A?.dirs ?? []; r.sys = A?.sys ?? 0; r.other = A?.other ?? 0;
let H = A?.hist ?? [];
r.grow = map(H, (h) => h.used);
r.full_in = null;
if (length(H) >= 2 && D.size > 0 && D.used != null) {
let a = H[0], b = H[length(H) - 1], dd = (b.t - a.t) / 86400, rate = dd > 0 ? (b.used - a.used) / dd : 0;
if (rate > 0) { let left = D.size * 0.98 - D.used; r.full_in = left <= 0 ? 0 : int(left / rate); }
}
if (A?.partial) r.partial = true;
let NC = nascfg();
if (ismain(D, NC)) {
let Q = rj(RUN + '/quota.json') ?? {}, P = [];
for (let u in persons(NC)) {
let x = NC.users[u], q = +(x.quota?.disk ?? 0), b = +(Q[u] ?? 0);
push(P, { user: u, vis: x.vis ?? u, used: b, quota: q, pct: q > 0 ? int(b * 100 / (q * 1073741824)) : 0 });
}
for (let g in (type(NC.gone) == 'array' ? NC.gone : [])) if (type(g) == 'object' && g.user != null)
push(P, { user: '' + g.user, vis: g.vis ?? g.user, used: +(Q[g.user] ?? g.used ?? 0), quota: 0, pct: 0, gone: true });
r.people = sort(P, (a, b) => b.used - a.used);
let Pa = A?.parts ?? {};
r.parts = { shared: +(Pa.shared ?? 0), cams: +(Pa.cams ?? 0), router: +(Pa.router ?? 0) };
}
return r;
}
function spok(X, p) { let P = relp(p); return P != null && posto(X, P) == 'ok'; }

const LOGT = RUN + '/log', LOGE = ETC + '/nas-log';
function hx(s) { let n = 0; s = uc(s); for (let i = 0; i < length(s); i++) { let c = index('0123456789ABCDEF', substr(s, i, 1)); if (c < 0) return 0; n = n * 16 + c; } return n; }
function bigend() { let f = open('/proc/self/exe', 'r'); if (!f) return false; let h = f.read(6) ?? ''; f.close(); return ord(h, 5) == 2; }
function ipof(h, BE) {
let B = (v) => BE ? [ (v >> 24) & 255, (v >> 16) & 255, (v >> 8) & 255, v & 255 ] : [ v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >> 24) & 255 ];
let w4 = (x) => { let b = B(hx(x)); return sprintf('%d.%d.%d.%d', b[0], b[1], b[2], b[3]); };
if (length(h) == 8) return w4(h);
if (length(h) != 32) return h;
if (substr(h, 0, 16) == '0000000000000000' && substr(h, 16, 8) == (BE ? '0000FFFF' : 'FFFF0000')) return w4(substr(h, 24, 8));
let G = [];
for (let i = 0; i < 4; i++) { let b = B(hx(substr(h, i * 8, 8))); push(G, sprintf('%x', (b[0] << 8) | b[1]), sprintf('%x', (b[2] << 8) | b[3])); }
return replace(join(':', G), /(^|:)0(:0)+(:|$)/, '::');
}
function logports() {
let dp = 8200, NC = nascfg();
for (let s, o in cfg('minidlna')) if (o['.type'] == 'minidlna' && match('' + (o.port ?? ''), /^[0-9]{1,5}$/)) dp = +o.port;
return { '445': 'smb', '139': 'smb', '2049': 'nfs', [dp + '']: 'dlna', [(+(NC.remote?.port ?? 5005) || 5005) + '']: 'webdav' };
}
function logtick() {
let SP = logports(), BE = bigend(), C = {}, now = time(), today = day(now);
for (let f in [ '/net/tcp', '/net/tcp6' ])
for (let l in split(readfile(PROC + f) ?? '', '\n')) {
let x = split(trim(l), /[ \t]+/);
if (length(x) < 4 || x[3] != '01') continue;
let sv = SP['' + hx(split(x[1], ':')[1])];
if (!sv) continue;
let ip = ipof(split(x[2], ':')[0], BE);
if (ip == '127.0.0.1' || ip == '::1') continue;
C[ip + ' ' + sv] = { ip: ip, svc: sv };
}
let MAC = {};
for (let l in split(readfile(PROC + '/net/arp') ?? '', '\n')) { let x = split(trim(l), /[ \t]+/); if (length(x) >= 4 && match(x[3], /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) && x[3] != '00:00:00:00:00:00') MAC[x[0]] = x[3]; }
for (let k, c in C) if (index(c.ip, ':') >= 0) {
for (let l in split(sh('ip -6 neigh 2>/dev/null'), '\n')) { let m = match(l, /^([0-9a-f:]+) .* lladdr ([0-9a-f:]{17})/); if (m) MAC[m[1]] = m[2]; }
break;
}
let ST = rj(RUN + '/logc.json') ?? {}, PC = ST.c ?? {}, NCt = {}, D = {};
let ctf = PROC + '/net/nf_conntrack';
let ctacv = readfile(PROC + '/sys/net/netfilter/nf_conntrack_acct'), ctacct = ctacv == null || trim(ctacv) == '1';
if (ctacct && (length(C) || length(PC)) && has(ctf)) for (let l in split(sh('grep -E ' + q('dport=(' + join('|', keys(SP)) + ') .*bytes=') + ' ' + q(ctf) + ' 2>/dev/null'), '\n')) {
let m = match(l, /src=([^ ]+) dst=[^ ]+ sport=([0-9]+) dport=([0-9]+) packets=[0-9]+ bytes=([0-9]+) .*src=[^ ]+ dst=[^ ]+ sport=[0-9]+ dport=[0-9]+ packets=[0-9]+ bytes=([0-9]+)/);
if (!m) continue;
let sv = SP[m[3]];
if (!sv) continue;
let k = m[1] + ' ' + m[2] + ' ' + m[3], p = PC[k] ?? [ 0, 0 ], w = +m[4], r = +m[5];
NCt[k] = [ w, r ];
let ck = m[1] + ' ' + sv;
if (!D[ck]) D[ck] = { r: 0, w: 0 };
D[ck].w += w >= p[0] ? w - p[0] : w; D[ck].r += r >= p[1] ? r - p[1] : r;
}
mkdirp(LOGT);
if (ST.day && ST.day != today && has(LOGT + '/' + ST.day + '.json')) {
mkdirp(LOGE);
writefile(LOGE + '/' + ST.day + '.json.t', readfile(LOGT + '/' + ST.day + '.json'));
rename(LOGE + '/' + ST.day + '.json.t', LOGE + '/' + ST.day + '.json');
let keep = map([ 0, 1, 2, 3, 4, 5, 6 ], (i) => day(now - i * 86400) + '.json');
for (let d in [ LOGT, LOGE ]) for (let f in lsdir(d) ?? []) if (match(f, /^[0-9-]+\.json$/) && index(keep, f) < 0) unlink(d + '/' + f);
}
let F = LOGT + '/' + today + '.json', Lg = rj(F) ?? {}, act = {}, ch = false;
for (let k, c in C) {
let mac = MAC[c.ip] ?? '', lk = (length(mac) ? mac : c.ip) + ' ' + c.svc, e = Lg[lk] ?? { mac: mac, ip: c.ip, svc: c.svc, r: 0, w: 0, n: 0 };
if (!(ST.act ?? {})[lk]) { e.n++; ch = true; }
let d = D[k];
if (d && (d.r || d.w)) { e.r += d.r; e.w += d.w; ch = true; }
e.ip = c.ip; e.last = now;
Lg[lk] = e; act[lk] = 1;
}
if (ch) wjr(F, Lg);
wjr(RUN + '/logc.json', { day: today, act: act, c: NCt, p: keys(SP) });
return { conn: length(keys(C)) };
}

const SELF = getenv('WF_NASFUC') ?? '/usr/share/wrtfreedom/nasf.uc';
const THN = '.wf-thumb', THQ = RUN + '/thumb.q', THP = RUN + '/thumb.pid', THDMAX = 268435456, THRMAX = 8388608, THBUD = 409600, THLOW = 1073741824;
const THIMG = [ 'png', 'webp', 'gif', 'bmp', 'heic', 'heif', 'tif', 'tiff' ];
const THVID = type(TIPI?.vid) == 'array' ? TIPI.vid : [];
function memkb() { let m = match(readfile(PROC + '/meminfo') ?? '', /MemTotal:[ \t]*([0-9]+)/); return m ? +m[1] : 0; }
function thcaps() {
let ff = bin('ffmpeg'), dj = bin('djpeg') && bin('cjpeg'), ram = memkb() >= 180000, C = { img: true, vid: !!ff && ram };
if (!ff) C.why = 'ffmpeg';
else if (!ram) C.why = 'ram';
if (!dj) C.need = [ 'libjpeg-turbo-utils' ];
C.ff = !!ff && ram; C.dj = !!dj;
return C;
}
function thkind(n, C) {
let m = match(lc(n), /\.([a-z0-9]+)$/), x = m ? m[1] : '';
if (x == 'jpg' || x == 'jpeg') return 'jpg';
if (index(THIMG, x) >= 0) return C.ff ? 'img' : null;
if (index(THVID, x) >= 0) return C.ff ? 'vid' : null;
return null;
}
function thdir(D) {
if (D.ro || D.lock || (vfs(D.mnt).free ?? 0) < THLOW) return RUN + '/thumb/' + D.id;
return D.mnt + '/' + THN;
}
function thkey(D, rel, st, sz) { let a = D.id + '|' + rel + '|' + st.size + '|' + st.mtime + '|' + sz; return hk8(a) + hk8(sz + '#' + a); }
function jpgw(s) {
let o = 2;
for (let i = 0; i < 60 && o + 9 < length(s); i++) {
if (ord(s, o) != 255) return 0;
let k = ord(s, o + 1);
if (k >= 0xC0 && k <= 0xCF && k != 0xC4 && k != 0xC8 && k != 0xCC) return bu16(s, o + 7);
o += 2 + bu16(s, o + 2);
}
return 0;
}
function exthumb(abs, want) {
let f = open(abs, 'r'), r = { rot: 1 }, o = 2;
if (!f) return r;
for (let i = 0; i < 40; i++) {
f.seek(o);
let m = f.read(4) ?? '';
if (length(m) < 4 || ord(m, 0) != 255) break;
let k = ord(m, 1), z = bu16(m, 2);
if (k == 0xDA || k == 0xD9 || (k >= 0xC0 && k <= 0xCF && k != 0xC4 && k != 0xC8 && k != 0xCC)) break;
if (k == 0xE1 && z > 8) {
let d = f.read(z - 2) ?? '';
if (substr(d, 0, 6) == 'Exif' + chr(0, 0)) {
let t = substr(d, 6), le = substr(t, 0, 2) == 'II', g16 = (j) => le ? lu16(t, j) : bu16(t, j), g32 = (j) => le ? lu32(t, j) : bu32(t, j);
let o0 = g32(4), n0 = o0 > 0 && o0 + 2 <= length(t) ? g16(o0) : 0, to = 0, tl = 0;
for (let j = 0; j < n0 && j < 200; j++) { let e = o0 + 2 + j * 12; if (e + 12 > length(t)) break; if (g16(e) == 0x112) r.rot = g16(e + 8); }
let o1 = n0 ? g32(o0 + 2 + n0 * 12) : 0, n1 = o1 > 0 && o1 + 2 <= length(t) ? g16(o1) : 0;
for (let j = 0; j < n1 && j < 50; j++) {
let e = o1 + 2 + j * 12;
if (e + 12 > length(t)) break;
if (g16(e) == 0x201) to = g32(e + 8);
else if (g16(e) == 0x202) tl = g32(e + 8);
}
if (want && to > 0 && tl > 100 && to + tl <= length(t)) {
let x = substr(t, to, tl);
if (ord(x, 0) == 255 && ord(x, 1) == 0xD8) { r.d = x; r.w = jpgw(x); }
}
}
break;
}
o += 2 + z;
}
f.close();
if (r.rot < 1 || r.rot > 8) r.rot = 1;
return r;
}
function thalive() { return alive(trim(readfile(THP) ?? '')); }
function thclean(TD, cap) {
let L = [], tot = 0;
for (let n in lsdir(TD) ?? []) {
if (!match(n, /^[0-9a-f]+\.(jpg|no)$/)) continue;
let s = lstat(TD + '/' + n);
if (!s || s.type != 'file') continue;
push(L, [ s.mtime, n, s.size ]); tot += s.size;
}
if (tot <= cap) return tot;
L = sort(L, (a, b) => a[0] - b[0]);
for (let x in L) { if (tot <= cap * 3 / 4) break; unlink(TD + '/' + x[1]); tot -= x[2]; }
return tot;
}
function thmake(k, sz, kind, src, TD, C) {
let out = TD + '/' + k + '.jpg', tp = TD + '/.' + k + '.' + PID + '.t', ff = bin('ffmpeg'), to = bin('timeout'), nc = bin('nice');
let pre = (nc ? q(nc) + ' -n 19 ' : '') + (to ? q(to) + ' 20 ' : '');
if (C.ff && ff) {
let vf = q('scale=' + sz + ':' + sz + ':force_original_aspect_ratio=decrease');
let one = (ss) => sh(pre + q(ff) + ' -v error -nostdin' + ss + ' -i ' + q(src) + ' -frames:v 1 -vf ' + vf + ' -c:v mjpeg -q:v 6 -f image2 -y ' + q(tp) + ' </dev/null >/dev/null 2>&1');
one(kind == 'vid' ? ' -ss 3' : '');
if (kind == 'vid' && !((lstat(tp)?.size ?? 0) > 0)) one('');
}
if (!((lstat(tp)?.size ?? 0) > 0) && kind == 'jpg' && C.dj) {
let f = open(src, 'r'), w = 0;
if (f) { let h = f.read(65536) ?? ''; f.close(); w = jpgw(h); }
let M = w > 0 ? int((8 * sz + w - 1) / w) : 1;
if (M < 1) M = 1;
if (M > 8) M = 8;
sh(pre + q(bin('djpeg')) + ' -scale ' + M + '/8 -dct fast ' + q(src) + ' 2>/dev/null | ' + q(bin('cjpeg')) + ' -quality 70 > ' + q(tp) + ' 2>/dev/null');
}
if ((lstat(tp)?.size ?? 0) > 0) rename(tp, out);
else { unlink(tp); writefile(TD + '/' + k + '.no', ''); }
unlink(RUN + '/thq/' + k);
}
function thumbrun() {
if (thalive()) return { busy: true };
mkdirp(RUN);
writefile(THP, PID);
let C = thcaps(), T = {}, n = 0;
for (let g = 0; g < 100 && (lstat(THQ)?.size ?? 0) > 0; g++) {
let w = THQ + '.' + PID + '.w';
if (!rename(THQ, w)) break;
for (let l in split(readfile(w) ?? '', '\n')) {
let x = split(l, '\t');
if (length(x) != 5 || !match(x[0], /^[0-9a-f]+$/) || !match(x[1], /^(160|320)$/)) continue;
if (has(x[4] + '/' + x[0] + '.jpg') || !has(x[3])) { unlink(RUN + '/thq/' + x[0]); continue; }
mkdirp(x[4]);
thmake(x[0], +x[1], x[2], x[3], x[4], C);
T[x[4]] = 1; n++;
}
unlink(w);
}
for (let d in keys(T)) thclean(d, substr(d, 0, length(RUN)) == RUN ? THRMAX : THDMAX);
unlink(THP);
return { made: n };
}
function thstart() { if (!thalive()) bg('ucode -e ' + q("loadfile('" + SELF + "')().thumbrun();")); }
function thumbcall(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, D = wdsk(W, a.disk, false);
if (D.error) return D;
let N = type(a.paths) == 'array' ? a.paths : [];
if (!length(N) || length(N) > 50) return err('Da 1 a 50 percorsi', 'From 1 to 50 paths');
let C = thcaps(), cp = { img: C.img, vid: C.vid };
if (C.why) cp.why = C.why;
if (C.need) cp.need = C.need;
if (a.wake === false && asleep(D)) return { asleep: true, thumbs: {}, pending: [], none: [], exp: 0, caps: cp };
if (waking(D)) return wakerr();
let sz = int(+(a.size ?? 256));
if (sz < 64 || sz > 512) sz = 256;
sz = sz <= 160 ? 160 : 320;
let X = ctx(W, D), TD = thdir(D), R = {}, RO = {}, pend = [], none = [], used = 0, qd = '', t0 = time(), mk = false;
for (let p in N) {
p = '' + p;
let P = absp(D, p);
if (!P || !length(P.parts) || length(filter(P.parts, (x) => substr(x, 0, 4) == '.wf-')) || posto(X, P.parts) != 'ok') { push(none, p); continue; }
let st = lstat(P.abs), kind = st && st.type == 'file' ? thkind(P.parts[length(P.parts) - 1], C) : null;
if (!kind) { push(none, p); continue; }
if (used >= THBUD || time() - t0 >= 3) { push(pend, p); continue; }
let k = thkey(D, P.rel, st, sz), c = TD + '/' + k;
if (has(c + '.no')) { push(none, p); continue; }
let x = readfile(c + '.jpg'), e = kind == 'jpg' ? exthumb(P.abs, x == null) : null;
if (x == null && e?.d && (e.w >= sz * 0.9 || (!C.ff && !C.dj))) {
x = e.d;
if (!mk) { mkdirp(TD); mk = true; }
let t = c + '.' + PID + '.t';
if (writefile(t, x) == length(x)) rename(t, c + '.jpg'); else unlink(t);
}
if (x == null) {
if (kind == 'jpg' && !C.ff && !C.dj) { push(none, p); continue; }
push(pend, p);
let qs = lstat(RUN + '/thq/' + k);
if (qs && time() - qs.mtime < 600) continue;
mkdirp(RUN + '/thq'); writefile(RUN + '/thq/' + k, '');
qd += k + '\t' + sz + '\t' + kind + '\t' + P.abs + '\t' + TD + '\n';
continue;
}
used += length(x) * 4 / 3;
R[p] = 'data:image/jpeg;base64,' + b64e(x);
if (e && e.rot != 1) RO[p] = e.rot;
}
if (length(qd)) {
let f = open(THQ, 'a');
if (f) { f.write(qd); f.close(); }
thstart();
}
let r = { thumbs: R, pending: pend, none: none, exp: 0, caps: cp };
if (length(keys(RO))) r.rot = RO;
return r;
}

const VERN = '.wf-vers', VERD = RUN + '/vers', VDAYS = 30, VKEEP = 10, VPCT = 5;
function vint(v, a, b, d) { return type(v) == 'int' && v >= a && v <= b ? v : d; }
function vcfg(NC) { let v = type(NC?.vers) == 'object' ? NC.vers : {}; return { on: v.on !== false, days: vint(v.days, 1, 90, VDAYS), keep: vint(v.keep, 1, 20, VKEEP), pct: vint(v.pct, 1, 20, VPCT) }; }
function gmtn(t) {
let z = int(t / 86400), s = t - z * 86400;
z += 719468;
let era = int(z / 146097), doe = z - era * 146097, yoe = int((doe - int(doe / 1460) + int(doe / 36524) - int(doe / 146096)) / 365);
let doy = doe - (365 * yoe + int(yoe / 4) - int(yoe / 100)), mp = int((5 * doy + 2) / 153), d = doy - int((153 * mp + 2) / 5) + 1;
let m = mp < 10 ? mp + 3 : mp - 9, y = yoe + era * 400 + (m <= 2 ? 1 : 0);
return sprintf('@GMT-%04d.%02d.%02d-%02d.%02d.%02d', y, m, d, int(s / 3600), int(s / 60) % 60, s % 60);
}
function gmtt(n) {
let m = match('' + n, /^@GMT-([0-9]{4})\.([0-9]{2})\.([0-9]{2})-([0-9]{2})\.([0-9]{2})\.([0-9]{2})$/);
if (!m) return null;
let y = +m[1], mo = +m[2], d = +m[3], a = mo <= 2 ? 1 : 0, y2 = y - a, era = int(y2 / 400), yoe = y2 - era * 400, mp = (mo + 9) % 12;
let doy = int((153 * mp + 2) / 5) + d - 1, doe = yoe * 365 + int(yoe / 4) - int(yoe / 100) + doy;
return (era * 146097 + doe - 719468) * 86400 + +m[4] * 3600 + +m[5] * 60 + +m[6];
}
function vsnaps(D) { return sort(filter(lsdir(D.mnt + '/' + VERN) ?? [], (n) => gmtt(n) != null)); }
function vstale(D) { let s = lstat(VERD + '/' + D.id + '.json'); return !s || time() - s.mtime > 21600; }
function vcleanbg(D) {
if (!has(D.mnt + '/' + VERN) || has(VERD + '/' + D.id + '.run')) return;
mkdirp(VERD); writefile(VERD + '/' + D.id + '.run', '' + time());
bg('ucode -e ' + q("loadfile('" + SELF + "')().vclean('" + D.id + "');"));
}
function vsave(D, P, force) {
if (D.ro || D.lock || !P || !length(P.parts)) return false;
let s = lstat(P.abs);
if (!s || s.type != 'file' || (!force && !vcfg(nascfg()).on)) return false;
let now = time(), T = null;
for (let i = 0; i < 10; i++) { let t = D.mnt + '/' + VERN + '/' + gmtn(now + i) + P.rel; if (!lstat(t)) { T = t; break; } }
if (!T) return false;
let c = D.mnt;
for (let x in split(substr(dname(T), length(D.mnt) + 1), '/')) {
c += '/' + x;
let st = lstat(c);
if (st && st.type != 'directory') return false;
if (!st && mkdir(c)) perm(c, '755');
}
if (!rename(P.abs, T)) return false;
if (vstale(D)) vcleanbg(D);
return true;
}
function vsavex(mnt, rel) {
for (let D in disks()) if (D.mounted && D.mnt == '' + mnt) { let P = absp(D, rel); return { ok: vsave(D, P, false) }; }
return { ok: false };
}
function vclean(id) {
let D = diskby(id), V = vcfg(nascfg()), R = { n: 0, bytes: 0, at: time() };
mkdirp(VERD);
if (!D || !D.mounted || D.ro || D.lock) { unlink(VERD + '/' + id + '.run'); return R; }
let mk = memkb(), vmax = mk > 0 && mk <= 163840 ? 20000 : 100000;
let B = D.mnt + '/' + VERN, cut = gmtn(time() - V.days * 86400), S = vsnaps(D), F = {}, all = [], seen = 0;
for (let n in S) if (n < cut) sh('rm -rf ' + q(B + '/' + n));
S = filter(S, (n) => n >= cut);
let walk2 = null;
walk2 = (sn, d, rel) => {
for (let n in lsdir(d) ?? []) {
if (++seen > vmax) return;
let s = lstat(d + '/' + n);
if (!s) continue;
if (s.type == 'directory') walk2(sn, d + '/' + n, rel + '/' + n);
else if (s.type == 'file') { let r = rel + '/' + n; push(F[r] ??= [], [ sn, s.size ]); push(all, [ sn, r, s.size ]); }
}
};
for (let n in S) walk2(n, B + '/' + n, '');
let gone = {};
for (let r, L in F) {
if (length(L) <= V.keep) continue;
L = sort(L, (a, b) => a[0] < b[0] ? 1 : (a[0] > b[0] ? -1 : 0));
for (let i = V.keep; i < length(L); i++) { unlink(B + '/' + L[i][0] + r); gone[L[i][0] + r] = 1; }
}
all = filter(all, (x) => !gone[x[0] + x[1]]);
let tot = 0;
for (let x in all) tot += x[2];
let cap = int((D.size ?? 0) * V.pct / 100);
if (cap > 0 && tot > cap) {
all = sort(all, (a, b) => a[0] < b[0] ? -1 : (a[0] > b[0] ? 1 : 0));
for (let x in all) { if (tot <= cap) break; unlink(B + '/' + x[0] + x[1]); gone[x[0] + x[1]] = 1; tot -= x[2]; }
all = filter(all, (x) => !gone[x[0] + x[1]]);
}
sh('find ' + q(B) + ' -mindepth 1 -depth -type d -exec rmdir {} \\; 2>/dev/null');
R.n = length(all); R.bytes = tot;
wjr(VERD + '/' + id + '.json', R);
unlink(VERD + '/' + id + '.run');
return R;
}
function versget() {
let V = vcfg(nascfg()), L = [];
for (let D in disks()) {
if (!D.mounted) continue;
let o = rj(VERD + '/' + D.id + '.json');
if (!D.ro && !D.lock && vstale(D)) vcleanbg(D);
push(L, { disk: D.id, n: o?.n ?? 0, bytes: o?.bytes ?? 0, at: o?.at ?? 0 });
}
return { ...V, disks: L };
}
function verscall(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, act = '' + (a.act ?? 'get');
if (act == 'get') return versget();
if (act == 'set') {
if (!W.adm) return errp();
let ck = (k, lo, hi) => a[k] == null || (type(a[k]) == 'int' && a[k] >= lo && a[k] <= hi);
if (!ck('days', 1, 90) || !ck('keep', 1, 20) || !ck('pct', 1, 20)) return err('Valore non valido', 'Invalid value');
if (!nasput((o) => {
let v = type(o.vers) == 'object' ? o.vers : {};
if (type(a.on) == 'bool') v.on = a.on;
for (let k in [ 'days', 'keep', 'pct' ]) if (a[k] != null) v[k] = a[k];
o.vers = v;
})) return nbusy();
for (let D in disks()) if (D.mounted && !D.ro && !D.lock) vcleanbg(D);
return { ...versget(), ok: true };
}
if (index([ 'list', 'restore', 'del' ], act) < 0) return err('Azione non valida', 'Invalid action');
let D = wdsk(W, a.disk, act != 'list');
if (D.error) return D;
if (waking(D)) return wakerr();
let P = absp(D, a.path);
if (!P || !length(P.parts) || length(filter(P.parts, (x) => substr(x, 0, 4) == '.wf-'))) return err('Percorso non valido', 'Invalid path');
let X = ctx(W, D);
if (posto(X, P.parts) != 'ok') return errp();
let B = D.mnt + '/' + VERN;
if (act == 'list') {
let It = [];
for (let n in reverse(vsnaps(D))) {
let s = lstat(B + '/' + n + P.rel);
if (s && s.type == 'file') push(It, { ver: n, at: gmtt(n), size: s.size });
}
return { items: It };
}
if (!mayedit(X, P.parts)) return errp();
let ver = '' + (a.ver ?? ''), src = gmtt(ver) != null ? B + '/' + ver + P.rel : null, ss = src ? lstat(src) : null;
if (!ss || ss.type != 'file') return err('Versione non trovata', 'Version not found', { code: 'nover' });
let up = () => { for (let d = dname(src); length(d) >= length(B + '/' + ver); d = dname(d)) if (!rmdir(d)) break; };
if (act == 'del') {
if (!unlink(src)) return err('Versione non tolta', 'Version not removed');
up();
return { ok: true };
}
let dir = dname(P.abs), nm = bname(P.abs), C0 = null;
for (let i = 0, c = D.mnt; i < length(P.parts) - 1; i++) {
c += '/' + P.parts[i];
let s = lstat(c);
if (s && s.type != 'directory') return err('Percorso non valido', 'Invalid path');
if (!s && mkdir(c)) { perm(c, '755'); C0 ??= c; }
}
if (a.copy === true) {
let fn = freename(dir, nm);
if (!fn || !rename(src, dir + '/' + fn)) return err('Non ripristinato', 'Not restored');
up();
ownfix(D.mnt, [ C0 ?? dir + '/' + fn ], W.own);
ownset(X, [ [ ...slice(P.parts, 0, -1), fn ] ]);
return { ok: true, path: '/' + join('/', [ ...slice(P.parts, 0, -1), fn ]) };
}
let cur = lstat(P.abs);
if (cur && (cur.type != 'file' || !vsave(D, P, true))) return err('Non ripristinato', 'Not restored');
if (!rename(src, P.abs)) return err('Non ripristinato', 'Not restored');
up();
ownfix(D.mnt, [ C0 ?? P.abs ], W.own);
return { ok: true, path: P.rel };
}

function trashcall(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, act = '' + (a.act ?? 'get');
if (act == 'days') {
if (!W.adm) return errp();
let d = int(+(a.days ?? 0));
if (d < 1 || d > TRMAX) return err('Giorni non validi: da 1 a ' + TRMAX, 'Invalid days: 1 to ' + TRMAX);
if (!nasput((o) => { o.trash = { ...(type(o.trash) == 'object' ? o.trash : {}), days: d }; })) return nbusy();
let r = trashget(null, W); r.days = d; return r;
}
if (act == 'get') return trashget(null, W);
let it = null;
if (a.item != null) {
let m = match('' + a.item, /^([A-Za-z0-9-]+)\/([0-9A-Za-z._-]+)$/);
if (!m || substr(m[2], 0, 1) == '.') return err('Elemento non trovato', 'Item not found');
let D = wdsk(W, m[1], true);
if (D.error) return D;
let sm = match(m[2], /^s\.([0-9a-f]+)$/), sp = sm ? trunhex(sm[1]) : null;
if (sm) {
let C = sp != null ? split(sp, '/') : [], T0 = trdir(D, true);
if (length(C) < 2 || length(filter(C, (c) => !length(c) || c == '.' || c == '..' || index(c, '\n') >= 0)) || !T0 || !smbsees(W, C[0]) ||
index(smbusers(T0), C[0]) < 0 || lstat(T0 + '/' + sp)?.type != 'file') return err('Elemento non trovato', 'Item not found');
it = { D: D, T: T0, smb: C, f: T0 + '/' + sp };
}
else {
it = { D: D, n: m[2], T: trdir(D) };
if (!it.T || !lstat(it.T + '/files/' + it.n) || !trmine(ctx(W, D), trashinfo(it.T + '/info/' + it.n + '.info'))) return err('Elemento non trovato', 'Item not found');
}
}
if (act == 'empty') {
let t = time(), G = [], via = (T, n) => { rename(T + '/files/' + n, T + '/via.' + t + '.' + n); unlink(T + '/info/' + n + '.info'); push(G, q(T + '/via.' + t + '.' + n)); };
if (it?.smb) { if (it.D.ro || it.D.lock || !unlink(it.f)) return err('Non eliminato', 'Not deleted'); smbprune(it.T, it.smb); }
else if (it) via(it.T, it.n);
else for (let d in disks()) {
let T = d.mounted ? trdir(d, true) : null;
if (!T || d.ro || d.lock) continue;
let X = ctx(W, d), U = map(persons(X.NC), lc);
if (trdir(d)) for (let f in lsdir(T + '/info') ?? []) {
let m = match(f, /^([0-9A-Za-z._-]+)\.info$/);
if (m && lstat(T + '/files/' + m[1]) && trmine(X, trashinfo(T + '/info/' + f))) via(T, m[1]);
}
for (let x in lsdir(T) ?? []) {
if (x == 'files' || x == 'info' || substr(x, 0, 4) == 'via.') continue;
if (W.adm ? index(U, lc(x)) >= 0 : lc(x) != lc(W.own) || lstat(T + '/' + x)?.type != 'directory') continue;
if (rename(T + '/' + x, T + '/via.' + t + '.' + x)) push(G, q(T + '/via.' + t + '.' + x));
}
}
if (length(G)) bg('rm -rf ' + join(' ', G));
return trashget(null, W);
}
if (act == 'restore') {
if (!it) return err('Elemento non trovato', 'Item not found');
let P = null, ow = W.own;
if (it.smb) {
let NC = nascfg();
P = smbdest(it.D, NC, it.smb[0], slice(it.smb, 1));
if (posto(ctx(W, it.D), P) != 'ok') return err('Percorso non valido', 'Invalid path');
if (index(persons(NC), smbwho(NC, it.smb[0])) >= 0) ow = smbwho(NC, it.smb[0]);
}
else {
let o = trashinfo(it.T + '/info/' + it.n + '.info');
P = relp(o.from ?? '');
if (P == null || !length(P)) P = [ it.n ];
}
let dir = it.D.mnt, C0 = null;
for (let i = 0; i < length(P) - 1; i++) {
dir += '/' + P[i];
let s = lstat(dir);
if (s && s.type == 'link') return err('Percorso non valido', 'Invalid path');
if (!s && mkdir(dir)) { perm(dir, '755'); C0 ??= dir; }
}
let fn = freename(dir, P[length(P) - 1]);
if (!fn || !rename(it.smb ? it.f : it.T + '/files/' + it.n, dir + '/' + fn)) return err('Non rimesso al suo posto', 'Not restored');
ownfix(it.D.mnt, [ C0 ?? dir + '/' + fn ], ow);
if (it.smb) smbprune(it.T, it.smb);
else unlink(it.T + '/info/' + it.n + '.info');
let r = trashget(null, W); r.ok = true; r.path = substr(dir, length(it.D.mnt)) + '/' + fn; return r;
}
return err('Azione non valida', 'Invalid action');
}

return {
nas_ls: { args: { disk: 'x', path: 'x', q: 'x', type: 'x', limit: 0, offset: 0, wake: true, as: 'x', ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, D = wdsk(W, a.disk, false);
if (D.error) return D;
if (a.wake === false && asleep(D)) return { asleep: true, items: [], free: D.free, fs: D.fs, ro: D.ro || D.lock };
if (waking(D)) return wakerr();
let P = absp(D, a.path);
if (!P) return err('Percorso non valido', 'Invalid path');
let X = ctx(W, D), sv = posto(X, P.parts);
if (sv != 'ok' && sv != 'up') return errp();
let s = stat(P.abs);
if (!s || s.type != 'directory') return err('Cartella non trovata', 'Folder not found');
let tp = TYPES[a.type] ? a.type : null, lim = int(+(a.limit ?? 0)), ql = lc(trim('' + (a.q ?? '')));
if (lim < 1 || lim > 200) lim = 200;
let bkd = bkdirs(X.NC), bkp = bkparts(X.NC), t0 = time(), SO = null;
let shown = (C) => {
if (!X.main || !X.sh || !under(C, X.sh) || length(C) <= length(X.sh)) return null;
SO ??= owns(D);
return ownof(D, C, SO);
};
let nlb = 2000;
let item = (dir, n) => {
let st = lstat(dir + '/' + n), C = relp(substr(dir, length(D.mnt)) + '/' + n), lk = null;
if (st && st.type == 'link' && C != null && length(C)) { lk = shl(D, C, length(C) - 1); st = lk ? stat(D.mnt + '/' + join('/', lk)) : null; C = lk; if (lk) dir = D.mnt + '/' + join('/', slice(lk, 0, -1)); }
if (!st || st.type == 'link' || (lk && st.type != 'directory')) return null;
let v = C == null ? 'no' : posto(X, C);
if (v == 'no') return null;
let o = { name: n, dir: st.type == 'directory', size: st.type == 'directory' ? 0 : st.size, mtime: st.mtime };
if (lk) o.lk = lk;
if (v == 'lock') { o.lock = true; return o.dir ? o : null; }
if (!o.dir) o.type = ftype(n);
let ow = C == null ? null : shown(C);
if (ow != null) o.own = '' + ow;
if (o.dir && !length(ql)) {
let p = dir + '/' + n, L = lsdir(p) ?? [], V = filter(L, (x) => substr(x, 0, 1) != '.'), isd = (x) => (lstat(p + '/' + x) ?? {}).type == 'directory';
o.count = length(V);
if (st.nlink >= 2 && length(L) - length(V) <= 64) {
o.dirs = st.nlink - 2 - length(filter(L, (x) => substr(x, 0, 1) == '.' && isd(x)));
if (o.dirs < 0 || o.dirs > o.count) delete o.dirs;
}
else if (length(V) <= nlb) { nlb -= length(V); o.dirs = length(filter(V, isd)); }
}
if (o.dir) {
let rp = substr(dir, length(D.mnt)) + '/' + n;
if (index(bkd, D.id + ':' + rp) >= 0 || (X.main && length(filter(bkp, (b) => same(C, b))))) o.backup = true;
if (isbase(X, C)) o.base = true;
if (length(filter(X.gone, (g) => same(C, g)))) o.gone = true;
}
return o;
};
let It = [], part = false;
if (length(ql) || tp) {
let seen = 0, Q = [ P.abs ], lkd = false;
while (length(Q) && length(It) < lim) {
let d = shift(Q);
for (let n in lsdir(d) ?? []) {
if (hidden(d == D.mnt, n)) continue;
if (++seen > 20000 || (seen % 200 == 0 && time() - t0 >= 3)) { part = true; break; }
let o = item(d, n), od = d;
if (!o || o.lock) continue;
if (o.lk) {
if (lkd || under(o.lk, P.parts)) continue;
lkd = true; od = D.mnt + '/' + join('/', slice(o.lk, 0, -1)); delete o.lk;
}
if (o.dir) push(Q, od + '/' + n);
if ((!length(ql) || index(lc(n), ql) >= 0) && (!tp || o.type == tp) && (length(ql) || !o.dir) && !(tp && o.dir)) {
o.path = substr(od, length(D.mnt)) + '/' + n; push(It, o);
if (length(It) >= lim) { part = true; break; }
}
}
if (part) break;
}
}
let pg = null;
if (!length(ql) && !tp) {
let pl = int(+(a.limit ?? 0)), off = int(+(a.offset ?? 0)), K = [], rt = P.abs == D.mnt, n0 = 0;
if (pl < 1) pl = 500;
if (pl > 2000) pl = 2000;
if (off < 0) off = 0;
for (let n in lsdir(P.abs) ?? []) {
if (hidden(rt, n)) continue;
let dr = false;
if (time() - t0 < 6) { let st = lstat(P.abs + '/' + n); dr = !!st && (st.type == 'directory' || (st.type == 'link' && shl(D, [ ...P.parts, n ], length(P.parts)) != null)); }
push(K, [ dr ? 0 : 1, lc(n), n ]);
}
K = sort(K, (x, y) => x[0] != y[0] ? x[0] - y[0] : (x[1] < y[1] ? -1 : (x[1] > y[1] ? 1 : 0)));
let i = off;
for (; i < length(K) && n0 < pl; i++) {
if (i > off && time() - t0 >= 15) break;
n0++;
let o = item(P.abs, K[i][2]);
if (o) { delete o.lk; push(It, o); }
}
pg = { total: length(K), next: i };
}
It = sort(It, (x, y) => x.dir != y.dir ? (x.dir ? -1 : 1) : (lc(x.name) < lc(y.name) ? -1 : (lc(x.name) > lc(y.name) ? 1 : 0)));
let r = { items: It, free: D.free, fs: D.fs, ro: D.ro || D.lock };
if (part) r.partial = true;
if (pg && pg.next < pg.total) { r.more = true; r.next = pg.next; r.total = pg.total; }
return r;
} },
nas_op: { args: { op: 'x', disk: 'x', src: [], to_disk: 'x', to: 'x', name: 'x', conflict: 'x', forever: true, as: 'x', ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, op = '' + (a.op ?? ''), D = wdsk(W, a.disk, op != 'copy' && op != 'backup');
if (D.error) return D;
if (index([ 'copy', 'move', 'delete', 'rename', 'mkdir', 'backup' ], op) < 0) return err('Azione non valida', 'Invalid action');
let X = ctx(W, D), SR = [], wr = op == 'move' || op == 'delete' || op == 'rename';
for (let p in (type(a.src) == 'array' ? a.src : [])) {
let x = absp(D, p);
if (!x || !length(x.parts)) return err('Percorso non valido', 'Invalid path');
if (posto(X, x.parts) != 'ok' || (op != 'mkdir' && whole(X, x.parts))) return errp();
if (!lstat(x.abs)) return err('File non trovato: ' + bname(x.rel), 'File not found: ' + bname(x.rel));
if (wr && isbase(X, x.parts)) return errb();
if (wr && !mayedit(X, x.parts)) return errp();
push(SR, x);
}
if (op == 'mkdir') {
let pp = absp(D, a.to ?? a.src?.[0] ?? '/'), n = '' + (a.name ?? '');
if (!pp || badname(n) || substr(n, 0, 4) == '.wf-') return err('Nome non valido', 'Invalid name');
if (posto(X, pp.parts) != 'ok') return errp();
let qf = qfull(X);
if (qf) return qf;
if (lstat(pp.abs + '/' + n)) return err('Esiste già un file con questo nome', 'A file with this name already exists');
if (!mkdir(pp.abs + '/' + n)) return err('Cartella non creata', 'Folder not created');
perm(pp.abs + '/' + n, '755');
ownfix(D.mnt, [ pp.abs + '/' + n ], W.own);
ownset(X, [ [ ...pp.parts, n ] ]);
return { ok: true };
}
if (!length(SR)) return err('Scegli almeno un file', 'Choose at least one file');
if (op == 'rename') {
let n = '' + (a.name ?? ''), s = SR[0];
if (badname(n) || substr(n, 0, 4) == '.wf-') return err('Nome non valido', 'Invalid name');
let t = dname(s.abs) + '/' + n, te = lstat(t);
let reg = !te || te.inode == lstat(s.abs)?.inode, ok = () => { if (reg) ownset(X, [ [ ...slice(s.parts, 0, -1), n ] ], true); return { ok: true }; };
if (t == s.abs) return ok();
let ts = lstat(t);
if (ts) {
let ss = lstat(s.abs);
if (!ss || lc(n) != lc(bname(s.abs)) || ts.inode != ss.inode) return err('Esiste già un file con questo nome', 'A file with this name already exists');
let mid = dname(s.abs) + '/.' + newid() + '.wfmv';
if (!rename(s.abs, mid)) return err('Nome non cambiato', 'Name not changed');
let tt = lstat(t);
if (tt && tt.inode == ss.inode) { unlink(mid); return ok(); }
if (!rename(mid, t)) { rename(mid, s.abs); return err('Nome non cambiato', 'Name not changed'); }
return ok();
}
if (!rename(s.abs, t)) return err('Nome non cambiato', 'Name not changed');
return ok();
}
if (op == 'delete' && a.forever === true && W.adm) {
let A = { n: 0, files: 0, bytes: 0, big: [], over: false, t0: time() };
for (let s in SR) walk(s.abs, A);
return jobstart('delete', D.id, '', { root: D.mnt, forever: '1', name: cutn(D.name, 24), own: W.own }, SR, length(SR), A.over ? 0 : A.bytes, FSH);
}
if (op == 'delete') return jobstart('delete', D.id, '', { root: D.mnt, own: W.own }, SR, length(SR), 0);
let tdk = a.to_disk;
if (op == 'backup' && tdk == null && W.adm) {
for (let x in disks()) if (x.mounted && !x.ro && !x.lock && x.base != D.base) { tdk = x.id; break; }
}
let T = wdsk(W, tdk ?? D.id, true);
if (T.error) return T;
let TX = T.id == D.id ? X : ctx(W, T), bk = upart(W.own, 'backup');
if (op == 'backup' && a.to == null && !bk) return err('Percorso non valido', 'Invalid path');
let to = '' + (a.to ?? (op == 'backup' ? join('/', bk) : ''));
let tp = absp(T, to);
if (!tp) return err('Percorso non valido', 'Invalid path');
if (posto(TX, tp.parts) != 'ok') return errp();
if (op != 'move') { let qf = qfull(X); if (qf) return qf; }
if (op == 'backup') {
if (!lstat(tp.abs)) { mkdirp(tp.abs); perm(tp.abs, '755'); }
let d = localtime(), n = sprintf('Backup %04d-%02d-%02d %02d.%02d', d.year, d.mon, d.mday, d.hour, d.min);
n = freename(tp.abs, n);
let pp = tp.parts;
push(pp, n);
tp = { abs: tp.abs + '/' + n, rel: tp.rel + '/' + n, parts: pp, make: true };
}
else {
let s = stat(tp.abs);
if (!s || s.type != 'directory') return err('Cartella di arrivo non trovata', 'Destination folder not found');
}
for (let s in SR) {
if (tp.abs == s.abs || substr(tp.abs, 0, length(s.abs) + 1) == s.abs + '/') return err('Non si può copiare una cartella dentro sé stessa', 'A folder cannot be copied into itself');
if (op == 'move' && dname(s.abs) == tp.abs) return err('È già in questa cartella', 'Already in this folder');
}
let LJ = livejobs(), bj = samedest(LJ, map(SR, (s) => tp.abs + '/' + bname(s.abs)));
if (bj) return err('Un altro lavoro sta scrivendo qui gli stessi file: aspetta che finisca', 'Another job is writing the same files here: wait for it to finish', { code: 'busy', job: bj });
let same = T.base == D.base && T.dev == D.dev, A = { n: 0, files: 0, bytes: 0, big: [], over: false, t0: time() };
for (let s in SR) walk(s.abs, A);
if (!A.over) {
if (T.fs == 'fat32' && length(A.big))
return err('FAT32 non tiene file sopra 4 GB', 'FAT32 cannot hold files over 4 GB', { big: map(A.big, (p) => substr(p, length(D.mnt))) });
let need = op == 'move' && same ? 0 : A.bytes, rs = reserved(LJ, T.id), fr = vfs(T.mnt).free - rs;
if (fr < 0) fr = 0;
if (need > 0 && need + 16777216 > fr) return err('Spazio non sufficiente', 'Not enough space', { need: need, free: fr, reserved: rs });
}
if (!W.adm && TX.main && TX.sh) for (let s in SR) {
let A = [ ...tp.parts, bname(s.abs) ];
if (under(A, TX.sh) && !(lstat(tp.abs + '/' + bname(s.abs)) && mayedit(TX, A))) s.nr = true;
}
let NW = map(filter(SR, (s) => tp.make || !lstat(tp.abs + '/' + bname(s.abs)) || !s.nr), (s) => [ ...tp.parts, bname(s.abs) ]);
let J = jobstart(op, D.id, T.id, { dst: tp.abs, droot: T.mnt, drel: tp.rel, conflict: index([ 'replace', 'keep', 'skip' ], a.conflict) >= 0 ? a.conflict : 'ask',
same: same ? '1' : '0', mk: tp.make ? '1' : '0', dfs: T.fs, own: W.own }, SR, A.over ? 0 : A.files, A.over ? 0 : A.bytes);
if (J.job) ownset(TX, NW);
return J;
} },
nas_job: { args: { id: 'x', stop: true, answer: 'x', all: true, as: 'x', ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, id = '' + (a.id ?? ''), mine = (j) => (j.own ?? 'admin') == W.own;
if (!length(id)) return { jobs: filter(jobs(), mine) };
if (!match(id, /^([0-9a-f]+|bak-[0-9A-Za-z-]+)$/)) return err('Lavoro non trovato', 'Job not found');
let j = jobget(id);
if (!j || !mine(j)) return err('Lavoro non trovato', 'Job not found');
if (a.stop && (j.state == 'run' || j.state == 'ask')) writefile(JOBS + '/' + id + '.stop', '' + time());
if (a.answer != null) {
if (index([ 'replace', 'keep', 'skip' ], a.answer) < 0) return err('Risposta non valida', 'Invalid answer');
if (j.state != 'ask') return err('Il lavoro non sta aspettando una risposta', 'The job is not waiting for an answer');
writefile(JOBS + '/' + id + '.ans.t', a.answer + ' ' + (a.all ? '1' : '0') + '\n');
rename(JOBS + '/' + id + '.ans.t', JOBS + '/' + id + '.ans');
}
j = jobundo(j);
if (index([ 'delete', 'copy', 'move' ], j.op) >= 0 && !j.forever && j.state != 'run' && j.state != 'ask' && !lstat(JOBS + '/' + id + '.tro')) {
writefile(JOBS + '/' + id + '.tro', '' + time());
trowbg();
}
return j;
} },
nas_read: { args: { disk: 'x', path: 'x', off: 0, len: 0, ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, D = wdsk(W, a.disk, false);
if (D.error) return D;
if (waking(D)) return wakerr();
let P = absp(D, a.path);
if (!P || !length(P.parts)) return err('Percorso non valido', 'Invalid path');
if (posto(ctx(W, D), P.parts) != 'ok') return errp();
let s = lstat(P.abs);
if (!s || s.type != 'file') return err('File non trovato', 'File not found');
let off = int(+(a.off ?? 0)), len = int(+(a.len ?? RDMAX));
if (off < 0 || len < 1) return err('Pezzo non valido', 'Invalid range');
if (len > RDMAX) len = RDMAX;
if (off >= s.size) return { data: '', size: s.size };
let f = open(P.abs, 'r');
if (!f) return err('File non leggibile', 'File not readable');
f.seek(off);
let d = f.read(len) ?? '';
f.close();
return { data: b64e(d), size: s.size };
} },
nas_write: { args: { disk: 'x', path: 'x', off: 0, data: 'x', last: true, replace: true, ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, D = wdsk(W, a.disk, true);
if (D.error) return D;
let P = absp(D, a.path);
if (!P || !length(P.parts)) return err('Percorso non valido', 'Invalid path');
let X = ctx(W, D);
let fnm = P.parts[length(P.parts) - 1];
let ut = X.main && type(UCFG.uup) == 'function' ? UCFG.uup(W.own, join('/', slice(P.parts, 0, -1)), fnm, X.NC) : null;
if (ut != null && UCFG.umkdir(D.mnt, ut)) P = absp(D, ut + '/' + fnm) ?? P;
let PD = slice(P.parts, 0, -1);
if (posto(X, PD) != 'ok' || posto(X, P.parts) != 'ok') return errp();
let qf = qfull(X);
if (qf) return qf;
let sid = '' + (req.info?.session ?? a.ubus_rpc_session ?? '');
let dir = dname(P.abs), n = bname(P.abs), tmp = dir + '/.' + cutn(n, 200) + '.' + hk8(sid + '|' + n) + '.wfpart', ds = stat(dir);
if (!ds || ds.type != 'directory') return err('Cartella non trovata', 'Folder not found');
let off = int(+(a.off ?? 0)), d = b64d('' + (a.data ?? '')), ts = lstat(tmp);
if (ts && ts.type == 'link') return err('Percorso non valido', 'Invalid path');
if (off > 0 && (!ts || ts.size != off)) return err('Pezzo fuori posto: riprendi da ' + (ts?.size ?? 0), 'Chunk out of place: resume from ' + (ts?.size ?? 0), { size: ts?.size ?? 0 });
if (length(d) > 0 && length(d) + 16777216 > (vfs(D.mnt).free ?? 0)) return err('Spazio non sufficiente', 'Not enough space', { need: length(d), free: vfs(D.mnt).free });
if (D.fs == 'fat32' && off + length(d) > FATMAX) return err('FAT32 non tiene file sopra 4 GB', 'FAT32 cannot hold files over 4 GB');
if (off == 0) for (let x in lsdir(dir) ?? []) {
if (substr(x, 0, 1) != '.' || substr(x, -7) != '.wfpart' || dir + '/' + x == tmp) continue;
let xs = lstat(dir + '/' + x);
if (xs && xs.type == 'file' && time() - xs.mtime > 86400) unlink(dir + '/' + x);
}
let f = open(tmp, off > 0 ? 'r+' : 'w');
if (!f) return still(D) ? err('File non scritto', 'File not written') : gonerr('Disco staccato durante il caricamento: niente salvato', 'Drive removed during the upload: nothing saved');
if (off > 0) f.seek(off);
let w = length(d) ? f.write(d) : 0;
f.close();
hook('write');
if (!still(D)) { unlink(tmp); return gonerr('Disco staccato durante il caricamento: niente salvato', 'Drive removed during the upload: nothing saved'); }
if (w != length(d)) { unlink(tmp); return err('File non scritto: disco pieno o staccato', 'File not written: drive full or removed'); }
if (!a.last) return { ok: true, size: off + length(d) };
let ex = a.replace === true ? lstat(dir + '/' + n) : null;
if (ex && ex.type == 'file' && mayedit(X, P.parts)) {
vsave(D, P, false);
if (!rename(tmp, dir + '/' + n)) return err('File non scritto', 'File not written');
perm(dir + '/' + n, '644');
return { ok: true, size: off + length(d), name: n, path: '/' + join('/', P.parts), replaced: true };
}
let fn = freename(dir, n);
if (!fn || !rename(tmp, dir + '/' + fn)) return err('File non scritto', 'File not written');
perm(dir + '/' + fn, '644');
ownset(X, [ [ ...PD, fn ] ]);
return { ok: true, size: off + length(d), name: fn, path: '/' + join('/', [ ...PD, fn ]) };
} },
nas_usage: { args: { disk: 'x', as: 'x', ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, D = wdsk(W, a.disk, false);
if (D.error) return D;
let NC = nascfg(), X = W.adm ? null : ctx(W, D);
let fd = (L2) => filter(type(L2) == 'array' ? L2 : [], (x) => X ? type(x) == 'object' && spok(X, x.path) : (type(UCFG.upriv) != 'function' || UCFG.upriv(W, '' + (x?.path ?? ''), NC) != 'in'));
let A = rj(spacef(D.id));
if (A?.at) return X ? { dirs: fd(A.dirs), at: A.at } : { dirs: fd(A.dirs), other: A.other ?? 0, sys: A.sys ?? 0, total: D.used ?? 0, at: A.at };
let rf = RUN + '/usage/' + D.id + '.run', f = RUN + '/usage/' + D.id + '.json', c = rj(f), s = stat(f);
let rv = split(trim(readfile(rf) ?? ''), ' '), rp = length(rv) > 1 ? rv[0] : '', rt = +(rv[length(rv) - 1] ?? 0);
let run = has(rf) && ((alive(rp) && index(readfile(PROC + '/' + rp + '/cmdline') ?? '', D.id) >= 0) || (rt > 0 && time() - rt >= 0 && time() - rt < 120));
if (c && s && time() - s.mtime < 600) return X ? { dirs: fd(c.dirs) } : { ...c, dirs: fd(c.dirs) };
if (!run) {
mkdirp(RUN + '/usage'); let t = time();
writefile(rf, '0 ' + t);
bg('sh -c ' + q('echo "$$ ' + t + '" > ' + q(rf) + '; exec sh ' + q(JOB) + ' usage ' + q(D.id) + ' ' + q(D.mnt)));
}
return X ? { dirs: fd(c?.dirs), run: true } : { dirs: fd(c?.dirs), other: c?.other ?? 0, run: true };
} },
nas_trash: { args: { act: 'x', days: 0, item: 'x', as: 'x', ubus_rpc_session: 'x' }, call: function(req) {
let r = trashcall(req), a = req.args?.act;
if (!r?.error && (a == 'empty' || a == 'restore')) trowbg();
return r;
} },
nas_find: { args: { q: 'x', type: 'x', limit: 0, wake: true, as: 'x', ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, ql = lc(trim('' + (a.q ?? ''))), tp = TYPES[a.type] ? a.type : null, lim = int(+(a.limit ?? 0)), t0 = time();
if (!length(ql) && !tp) return err('Scrivi cosa cercare', 'Type what to search');
if (length(ql) > 100 || index(ql, '\t') >= 0 || index(ql, '\n') >= 0) return err('Ricerca non valida', 'Invalid search');
if (lim < 1 || lim > 500) lim = 100;
let It = [], at = 0, part = false, sl = [];
for (let D in disks()) {
if (!D.mounted) continue;
let X = ctx(W, D), ok = (p) => { let P = relp(p); return P != null && posto(X, P) == 'ok'; };
if (!W.adm && !X.main) continue;
if (a.wake === false && asleep(D)) { push(sl, D.id); continue; }
let f = idxany(D);
if (f) {
let st = stat(f), te = tp ? q('\\.(' + join('|', TYPES[tp]) + ')\t') : null, c;
if (!length(ql)) c = 'grep -i -E -m 20000 -- ' + te + ' ' + q(f);
else if (tp) c = 'grep -i -F -- ' + q(ql) + ' ' + q(f) + ' | grep -i -E -m 20000 -- ' + te;
else c = 'grep -i -F -m 20000 -- ' + q(ql) + ' ' + q(f);
for (let l in split(sh(c + ' 2>/dev/null'), '\n')) {
let x = split(l, '\t');
if (length(x) < 3) continue;
let n = bname(x[0]);
if (!ok(x[0])) continue;
if (length(ql) && index(lc(n), ql) < 0) continue;
if (tp && ftype(n) != tp) continue;
push(It, { disk: D.id, path: x[0], name: n, size: +x[1], mtime: +x[2] });
}
if (!at || (st?.mtime ?? 0) < at) at = st?.mtime ?? 0;
continue;
}
let Q = [ D.mnt ], seen = 0;
while (length(Q)) {
let d = shift(Q);
for (let n in lsdir(d) ?? []) {
if (hidden(d == D.mnt, n)) continue;
if (++seen % 200 == 0 && time() - t0 >= 3) { part = true; break; }
let st = lstat(d + '/' + n);
if (!st || st.type == 'link') continue;
let v = posto(X, relp(substr(d, length(D.mnt)) + '/' + n) ?? []);
if (st.type == 'directory') { if (v == 'ok' || v == 'up') push(Q, d + '/' + n); continue; }
if (v != 'ok' || (length(ql) && index(lc(n), ql) < 0) || (tp && ftype(n) != tp)) continue;
push(It, { disk: D.id, path: substr(d, length(D.mnt)) + '/' + n, name: n, size: st.size, mtime: st.mtime });
}
if (part || length(It) > 5000) { part = true; break; }
}
}
if (length(It) > lim) part = true;
let r = { items: slice(sort(It, (x, y) => y.mtime - x.mtime), 0, lim), at: at, partial: part };
if (length(sl)) r.asleep = sl;
return r;
} },
nas_meta: { args: { disk: 'x', dir: 'x', names: [], full: true, ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let a = req.args ?? {}, D = wdsk(W, a.disk, false);
if (D.error) return D;
let P = absp(D, a.dir);
if (!P) return err('Percorso non valido', 'Invalid path');
if (posto(ctx(W, D), P.parts) != 'ok') return errp();
let N = type(a.names) == 'array' ? a.names : [];
if (!length(N) || length(N) > 60) return err('Da 1 a 60 nomi', 'From 1 to 60 names');
let full = a.full === true, cf = RUN + '/meta/' + D.id + '.json', C = rj(cf) ?? {}, ch = false, R = {}, t0 = time(), part = false;
for (let n in N) {
n = '' + n;
if (badname(n)) continue;
if (time() - t0 >= 3) { part = true; break; }
let ab = P.abs + '/' + n, st = lstat(ab);
if (!st || st.type != 'file') continue;
let k = P.rel + '/' + n + '|' + st.size + '|' + st.mtime + (full ? '|f' : '');
if (C[k] == null) { let m = metaof(ab, st.size, full); if (m == null) continue; C[k] = m; ch = true; }
if (length(keys(C[k]))) R[n] = C[k];
}
if (ch) {
if (length(keys(C)) > 3000) { let K = {}; for (let n, v in R) for (let k in keys(C)) if (substr(k, 0, length(P.rel) + length(n) + 2) == P.rel + '/' + n + '|') K[k] = C[k]; C = K; }
mkdirp(RUN + '/meta'); wjr(cf, C);
}
let r = { items: R };
if (part) r.partial = true;
return r;
} },
nas_thumb: { args: { disk: 'x', paths: [], size: 0, wake: true, as: 'x', ubus_rpc_session: 'x' }, call: thumbcall },
nas_vers: { args: { act: 'x', disk: 'x', path: 'x', ver: 'x', copy: true, on: true, days: 0, keep: 0, pct: 0, as: 'x', ubus_rpc_session: 'x' }, call: verscall },
nas_fav: { args: { act: 'x', disk: 'x', path: 'x', ubus_rpc_session: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
let mine = (x) => type(x) == 'object' && length(x.disk ?? '') && (x.own ?? 'admin') == W.own;
let a = req.args ?? {}, act = '' + (a.act ?? 'get'), F = nascfg().fav;
F = filter(type(F) == 'array' ? F : [], mine);
if (act == 'get') return { fav: F };
if (act != 'add' && act != 'del') return err('Azione non valida', 'Invalid action');
let P = relp(a.path), dk = '' + (a.disk ?? '');
if (P == null || !match(dk, /^[A-Za-z0-9-]+$/)) return err('Percorso non valido', 'Invalid path');
let rel = '/' + join('/', P), same = (x) => mine(x) && x.disk == dk && x.path == rel, nw = null, full = false;
if (act == 'add') {
if (length(filter(F, same))) return { ok: true, fav: F };
if (length(F) >= FAVMAX) return err('Al massimo ' + FAVMAX + ' Preferiti', 'At most ' + FAVMAX + ' Favorites', { code: 'max' });
let D = wdsk(W, dk, false);
if (D.error) return D;
let x = absp(D, rel), st = x ? stat(x.abs) : null;
if (!st || st.type != 'directory') return err('Cartella non trovata', 'Folder not found');
if (posto(ctx(W, D), x.parts) != 'ok') return errp();
nw = { disk: dk, path: rel, name: length(P) ? P[length(P) - 1] : D.name };
if (!W.adm) nw.own = W.own;
}
let o = nasput((c) => {
let G = filter(type(c.fav) == 'array' ? c.fav : [], (x) => type(x) == 'object' && length(x.disk ?? ''));
if (!nw) G = filter(G, (x) => !same(x));
else if (!length(filter(G, same))) { if (length(filter(G, mine)) >= FAVMAX) full = true; else push(G, nw); }
c.fav = G;
});
if (!o) return nbusy();
if (full) return err('Al massimo ' + FAVMAX + ' Preferiti', 'At most ' + FAVMAX + ' Favorites', { code: 'max' });
return { ok: true, fav: filter(o.fav, mine) };
} },
nas_space: { args: { act: 'x', disk: 'x', k: 'x' }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
if (!W.adm) return errp();
let a = req.args ?? {}, act = '' + (a.act ?? 'get'), dk = a.disk;
if (dk == null) for (let d in disks()) if (d.mounted) { dk = d.id; break; }
let D = dsk(dk, false);
if (D.error) return D;
if (act == 'get') return spaceout(D);
if (act == 'list') {
let A = rj(spacef(D.id)), k = '' + (a.k ?? ''), X = ctx(W, D), fl = (L2) => filter(type(L2) == 'array' ? L2 : [], (x) => spok(X, x?.path));
if (index([ 'dl', 'dup', 'big', 'old' ], k) < 0) return err('Elenco non valido', 'Invalid list');
if (!A?.at) return { k: k, at: 0, items: [] };
if (k == 'dup') return { k: k, at: A.at, groups: filter(A.dup?.list ?? [], (g) => spok(X, g?.keep?.path) && length(fl(g.copies)) == length(g.copies ?? [])), n: A.dup?.n ?? 0, bytes: A.dup?.bytes ?? 0 };
if (k == 'dl') return { k: k, at: A.at, items: fl(A.dl?.list), bytes: A.dl?.bytes ?? 0 };
return { k: k, at: A.at, items: fl(A[k]) };
}
if (act == 'run') {
if (scanning(D.id)) return { ok: true, run: true };
mkdirp(SCN);
bg('sh ' + q(FSH) + ' scan ' + q(D.id) + ' all hand');
return { ok: true, run: true };
}
return err('Azione non valida', 'Invalid action');
} },
nas_log: { args: { days: 0 }, call: function(req) {
let W = who(req);
if (!W || W.blocked) return werr(W);
if (!W.adm) return errp();
let n = int(+(req.args?.days ?? 7)), now = time(), R = [];
if (n < 1 || n > 7) n = 7;
for (let i = 0; i < n; i++) {
let d = day(now - i * 86400), o = rj(LOGT + '/' + d + '.json') ?? rj(LOGE + '/' + d + '.json');
if (type(o) != 'object') continue;
let Ls = [];
for (let k, e in o) push(Ls, { mac: e.mac ?? '', ip: e.ip ?? '', svc: e.svc ?? '', r: e.r ?? 0, w: e.w ?? 0, n: e.n ?? 0 });
push(R, { d: d, L: sort(Ls, (x, y) => (y.r + y.w) - (x.r + x.w)) });
}
return { days: R };
} },
scan: scan,
plan: plan,
logtick: logtick,
trashown: trashown,
thumbrun: thumbrun,
vclean: vclean,
vsave: vsavex,
ownfix: ownfixx,
};
