#!/bin/sh
export PATH=$PATH:/usr/sbin:/usr/bin:/sbin:/bin
D0=$(cd "$(dirname "$0")" && pwd)
R=; [ -n "$WF_CLOUDROOT" ] && [ ! -e /etc/openwrt_release ] && R=$WF_CLOUDROOT
W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; RC=$ETC/cloud-rclone.conf; FJ=$ETC/cloud-cifra.json
VCK=$ETC/cloud-cifra-ck.json
T=/tmp/wf-cloud; CRD=$T/cr; CS=$D0/cloud.sh
UCF=${WF_UCFGUC:-$D0/ucfg.uc}; [ -f "$UCF" ] || UCF=$W/ucfg.uc
[ -n "$R" ] && export WF_NASETC=$ETC
. "$D0/cloudline.sh" || exit 1
umask 077
TAB=$(printf '\t')
NET='{"mode":"same"}'
EN=0; [ "$(uci -q get wrtfreedom.ui.lang 2>/dev/null)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
alive() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }
now() { date +%s; }
age() { echo $(( $(now) - $(date -r "$1" +%s 2>/dev/null || echo 0) )); }
okid() { echo "$1" | grep -qE '^a[0-9]{1,3}$'; }
lk_get() {
until mkdir "$1" 2>/dev/null; do
p=$(cat "$1/pid" 2>/dev/null)
if { [ -n "$p" ] && ! alive "$p"; } || { [ -z "$p" ] && [ "$(age "$1")" -gt 60 ]; }; then rm -rf "$1"; continue; fi
return 1
done
echo $$ > "$1/pid"
}
lk_wait() { _lw=0; until lk_get "$1"; do _lw=$((_lw + 1)); [ $_lw -ge "$2" ] && return 1; sleep 1; done; }
lk_put() { [ "$(cat "$1/pid" 2>/dev/null)" = $$ ] && rm -rf "$1"; true; }
nid() { [ -n "$R" ] && [ -n "$WF_CRNID" ] && { echo "$WF_CRNID"; return; }; date +%Y%m%d; }
ev() { [ -f $W/event.sh ] && sh $W/event.sh cron "$1" cloud "$2" </dev/null >/dev/null 2>&1; true; }
evme() { [ -f $W/event.sh ] && WF_SOLO=1 sh $W/event.sh cron "$1" cloud "$2" "$3" </dev/null >/dev/null 2>&1; true; }
lg() {
mkdir -p $T/log; _l="$T/log/crmig-$A"
echo "$(now) ${MODE:--} $1 n=${DN:-0} b=${DB:-0} f=${FN:-0}" >> "$_l"
[ "$(wc -l < "$_l")" -gt 200 ] && tail -n 200 "$_l" > "$_l.t" && mv "$_l.t" "$_l"
true
}
rcerr() {
if grep -qi 'invalid_grant\|unauthori[sz]ed\|401\|token.*\(expired\|invalid\|revoked\)\|"result": *\(1000\|2000\)' "$1" 2>/dev/null; then echo relink
elif grep -qi 'quota\|storage.*full\|insufficient' "$1" 2>/dev/null; then echo space
elif grep -qi 'no such host\|dial tcp\|timeout\|network is unreachable' "$1" 2>/dev/null; then echo net
else echo fail; fi
}

fjget() {
A_=$A F=$FJ ucode -e 'let S = {}; try { S = json(require("fs").readfile(getenv("F")) ?? "{}"); } catch (e) {}
		let o = S?.accts?.[getenv("A_")] ?? {};
		print(S?.on === true ? 1 : 0, " ", S?.keyok === true ? 1 : 0, " ", o?.st ?? "-", " ", int(o?.done_b ?? 0), " ", int(o?.done_n ?? 0), " ", o?.pause === true ? 1 : 0, " ", int(o?.tot_b ?? 0), " ", int(o?.tot_n ?? 0), " ", length(o?.err ?? "") ? 1 : 0, " ", o?.nxt_t == null ? "-" : int(o.nxt_t), " ", int(o?.last_t ?? 0), "\n");' </dev/null 2>/dev/null
}
LEFT_UC='let fs = require("fs"), E = getenv, S = {};
try { S = json(fs.readfile(E("F")) ?? "{}"); } catch (e) { S = {}; }
let o = S?.accts?.[E("A_")] ?? {}, f = int(o?.fail_n ?? 0), l = 0;
for (let k, v in (type(o?.long) == "object" ? o.long : {})) l += int(v);
let b = f + l, n = int(o?.tot_n ?? 0) - int(o?.done_n ?? 0) - b, t = E("O") + ".t";
fs.writefile(t, sprintf("{\"n\":%d,\"fail\":%d,\"long\":%d,\"bad\":%d,\"t\":%d}\n", n > 0 ? n : 0, f, l, b, time())); fs.rename(t, E("O"));'
left() { A_=$A F=$FJ O=$CRD/$A.left ucode -e "$LEFT_UC" </dev/null >/dev/null 2>&1; true; }
paused() { set -- $(fjget); [ "${6:-0}" = 1 ]; }
FJ_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, f = E('F'), S = {};
try { S = json(fs.readfile(f) ?? '{}'); } catch (e) { S = {}; }
if (type(S) != 'object') S = {};
if (type(S.accts) != 'object') S.accts = {};
let a = E('A_'), o = type(S.accts[a]) == 'object' ? S.accts[a] : {}, uk = E('UK') ?? '', l0 = int(o.long?.[uk] ?? 0);
let o0 = sprintf('%J', o);
/* 19/11 (analisi del NAS): STIF = stati ammessi («mig|on»): se nel frattempo lo stato è cambiato (Disattiva durante il
   giro, Attiva durante il ritorno) niente si scrive e il quarto numero stampato è 0 */
if (length(E('STIF') ?? '') && index(split(E('STIF'), '|'), o.st ?? '-') < 0) { print(int(o.fn?.[uk] ?? 0), ' ', l0, ' ', l0, ' 0\n'); exit(0); }
function m(k) { if (type(o[k]) != 'object') o[k] = {}; return o[k]; }
function num(k) { let v = E(k); return v != null && match(v, /^[0-9]+$/) ? +v : null; }
if (length(uk)) {
	/* 19/11 sera: UNEW=1 = stato scritto solo se la cartella non ha ancora una voce (anche con altre maiuscole) */
	let had = false;
	if (E('UNEW') == '1') for (let x in keys(m('f'))) if (lc(x) == lc(uk)) had = true;
	if (length(E('UV') ?? '') && !had) m('f')[uk] = E('UV');
	if (E('FNI') == '1') m('fn')[uk] = +(m('fn')[uk] ?? 0) + 1;
	if (E('FNI') == '0') delete m('fn')[uk];
	if (num('LG') != null) { if (num('LG') > 0) m('long')[uk] = num('LG'); else delete m('long')[uk]; }
}
if (length(E('ST') ?? '')) o.st = E('ST');
if (E('ERR') != null) { if (length(E('ERR'))) o.err = E('ERR'); else delete o.err; }
if (E('PAUSE') == '1') o.pause = true;
if (E('PAUSE') == '0') delete o.pause;
for (let k, j in { TOTB: 'tot_b', TOTN: 'tot_n', FAILS: 'fail_n' }) if (num(k) != null) o[j] = num(k);
for (let k, j in { ADDB: 'done_b', ADDN: 'done_n', ADDF: 'fail_n' }) if (num(k) != null) o[j] = int(+(o[j] ?? 0) + num(k));
/* SUBB, SUBN: file spariti dalla partenza (spostati o cancellati dalla persona) tolti dal totale, mai sotto zero */
for (let k, j in { SUBB: 'tot_b', SUBN: 'tot_n' }) if (num(k) != null) { let v = int(+(o[j] ?? 0) - num(k)); o[j] = v > 0 ? v : 0; }
if (num('NXT') != null) o.nxt_t = num('NXT');
if (E('ONLYCH') != '1' || sprintf('%J', o) != o0) {
	o.last_t = time(); S.accts[a] = o;
	let t = f + '.' + E('P_') + '.t';
	fs.writefile(t, sprintf('%.J\n', S)); fs.rename(t, f);
}
print(int(o.fn?.[uk] ?? 0), ' ', int(o.long?.[uk] ?? 0), ' ', l0, ' 1\n');
ucode
)
fjput() {
mkdir -p "$ETC"
lk_wait $T/cr.lock 10 || return 1
FJO=$(env "$@" A_=$A F=$FJ P_=$$ ucode -e "$FJ_UC" </dev/null 2>/dev/null)
lk_put $T/cr.lock
}
PB=0; PN=0; PF=0; FT=0
flush() {
[ "$1" = 1 ] || [ $(( $(now) - FT )) -ge 600 ] || return 0
[ $PB = 0 ] && [ $PN = 0 ] && [ $PF = 0 ] && return 0
fjput ADDB=$PB ADDN=$PN ADDF=$PF && { PB=0; PN=0; PF=0; FT=$(now); }
}

PPL_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, U = loadfile(E('U'))(), N = {};
try { N = json(fs.readfile(E('NJ')) ?? '{}'); } catch (e) { N = {}; }
if (type(N) != 'object') N = {};
let L = [ 'admin', 'shared' ], seen = { admin: true, shared: true }, us = type(N.users) == 'object' ? N.users : {};
for (let u in sort(keys(us))) if (!seen[u]) { seen[u] = true; push(L, u); }
for (let g in (type(N.gone) == 'array' ? N.gone : [])) if (type(g) == 'object' && type(g.user) == 'string' && !seen[g.user]) { seen[g.user] = true; push(L, g.user); }
let pre = U.UDIR.root + '/';
for (let u in L) {
	let p = U.udir(u, 'root', null, N), s = U.crsec(E('A_'), u);
	if (type(p) != 'string' || substr(p, 0, length(pre)) != pre || s == null) continue;
	let v = substr(p, length(pre));
	if (!length(v) || index(v, '/') >= 0 || match(v, /[\t\n]/)) continue;
	print(u, '\t', v, '\t', s, '\n');
}
ucode
)
people() { A_=$A U=$UCF NJ=$ETC/nas.json ucode -e "$PPL_UC" </dev/null 2>/dev/null; }
UNITS_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, U = loadfile(E('U'))(), N = {}, X = {};
try { N = json(fs.readfile(E('NJ')) ?? '{}'); } catch (e) { N = {}; }
try { X = json(fs.readfile(E('XJ')) ?? '{}'); } catch (e) { X = {}; }
let ex = {}, LN = {}, old = 0;
for (let l in split(fs.readfile(E('ENC')) ?? '', '\n')) { l = replace(l, /\/$/, ''); if (length(l)) ex[l] = true; }
/* 19/11 (analisi del NAS): mai una voce con la forma di un nome cifrato (base32 di blocchi da 16 byte, come isenc di
   INS_UC): con st run i nomi cifrati che la chiave di adesso non legge (chiave di prima: router nuovo, reset) si contano
   in OLDF e non si cifrano una seconda volta */
for (let k = 1; k <= 15; k++) LN[int((k * 128 + 4) / 5)] = true;
function isenc(s) { return LN[length(s)] && match(s, /^[0-9a-v]+$/) != null; }
for (let l in split(fs.readfile(E('RAW')) ?? '', '\n')) {
	let i = index(l, '\t');
	if (i < 1) continue;
	let sz = substr(l, 0, i), nm = substr(l, i + 1), d = substr(nm, -1) == '/';
	if (d) nm = replace(nm, /\/$/, '');
	if (!length(nm) || ex[nm] || !match(sz, /^-?[0-9]+$/)) continue;
	if (E('ALL') != '1' && isenc(nm)) { old++; continue; }
	if (E('ALL') != '1') {
		let c = U.cpriv([ U.UDIR.root, E('VIS'), nm ], N, X);
		if (c == null || c.own != E('OWN')) continue;
	}
	print(E('OWN'), '\t', E('VIS'), '\t', E('SEC'), '\t', nm, '\t', d ? 'd' : 'f', '\t', d ? -1 : +sz, '\n');
}
if (old > 0 && length(E('OLDF') ?? '')) { let h = fs.open(E('OLDF'), 'a'); h.write(old + '\n'); h.close(); }
ucode
)
BLK_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, sk = {}, dl = {}, fr = [], du = [], nl = [], b = 0, L = 0, F = 0, G = 0;
let MB = +E('MAXB'), MN = +E('MAXN'), run = E('RUN') == '1', cap = E('CAP') == '1';
for (let l in split(fs.readfile(E('SK')) ?? '', '\n')) { let i = index(l, '\t'); if (i == 1) sk[substr(l, 2)] = substr(l, 0, 1); }
for (let l in split(fs.readfile(E('DL')) ?? '', '\n')) if (length(l)) dl[l] = true;
/* un pezzo oltre 143 byte: cifrato (EME a 16 byte, base32) supera 255 */
function long(p) { for (let s in split(p, '/')) if (length(s) > 143) return true; return false; }
for (let l in split(fs.readfile(E('LS')) ?? '', '\n')) {
	let i = index(l, '\t');
	if (i < 1) continue;
	let sz = +substr(l, 0, i), p = substr(l, i + 1);
	if (!length(p)) continue;
	if (sk[p] == 'L') { L++; continue; }
	if (sk[p] == 'F') { F++; continue; }
	if (run && long(p)) { push(nl, p); sk[p] = 'L'; L++; continue; }
	/* 19/11: con il tetto della SIM un file più grande di quello che resta (MB) non entra mai, nemmeno da primo (G) */
	if (cap && sz > MB) { G++; continue; }
	if (length(fr) + length(du) >= MN || (b >= MB && length(fr) + length(du) > 0)) continue;
	if (dl[p]) push(du, p); else push(fr, p);
	b += sz > 0 ? sz : 0;
}
fs.writefile(E('OF'), length(fr) ? join('\n', fr) + '\n' : '');
fs.writefile(E('OD'), length(du) ? join('\n', du) + '\n' : '');
if (length(nl)) { let h = fs.open(E('SK'), 'a'); for (let p in nl) h.write('L\t' + p + '\n'); h.close(); }
print(length(fr), ' ', length(du), ' ', L, ' ', F, ' ', length(nl), ' ', G, '\n');
ucode
)
BASES_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, U = loadfile(E('U'))(), N = {};
try { N = json(fs.readfile(E('NJ')) ?? '{}'); } catch (e) { N = {}; }
if (type(N) != 'object') N = {};
let pre = U.UDIR.root + '/' + E('VIS') + '/', t = E('TOP');
for (let b in U.ubase(N)) {
	if (type(b) != 'string' || substr(b, 0, length(pre)) != pre) continue;
	let r = substr(b, length(pre));
	if (r == t || substr(r, 0, length(t) + 1) == t + '/') print(r, '\n');
}
ucode
)
bases() { U=$UCF NJ=$ETC/nas.json VIS=$vis TOP=$top ucode -e "$BASES_UC" </dev/null 2>/dev/null; }
CONF_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, have = {}, sx = E('SX');
for (let l in split(fs.readfile(E('LS')) ?? '', '\n')) { let i = index(l, '\t'); if (i > 0) have[substr(l, i + 1)] = true; }
for (let l in split(fs.readfile(E('DL')) ?? '', '\n')) if (length(l)) have[l] = true;
for (let p in split(fs.readfile(E('DIF')) ?? '', '\n')) {
	if (!length(p)) continue;
	let j = rindex(p, '/'), dir = j >= 0 ? substr(p, 0, j + 1) : '', b = j >= 0 ? substr(p, j + 1) : p;
	let k = rindex(b, '.'), st = k > 0 ? substr(b, 0, k) : b, ext = k > 0 ? substr(b, k) : '', n = '';
	for (let i = 1; i < 100; i++) {
		n = dir + st + ' (' + sx + (i > 1 ? ' ' + i : '') + ')' + ext;
		if (!have[n]) break;
	}
	have[n] = true;
	print(p, '\t', n, '\n');
}
ucode
)

rp() { case "$1" in *:) printf '%s%s' "$1" "$2" ;; *) printf '%s/%s' "$1" "$2" ;; esac; }
RCT="--contimeout 15s --timeout 60s"
TMO=; command -v timeout >/dev/null 2>&1 && TMO="timeout 3600"
rcf() {
_o=$1; shift; [ "$_o" = - ] && _o=/dev/null
( cl_in; exec $TMO rclone "$@" $RCT --log-file "$TL" --log-level ERROR ) </dev/null >"$_o" 2>>"$TL" &
_rf=$!; echo $_rf > $CRD/$A.rpid
wait $_rf; _rr=$?
if [ $_rr != 0 ] && [ $_rr != 3 ] && { [ -f $T/jobs/$J.stop ] || paused; }; then STOPW=stop; lg stop; exit 0; fi
return $_rr
}
rcl() {
_rlf=${RLF:-$TL}; [ -n "$RLF" ] && ( umask 077; : > "$RLF" )
( cl_in; exec rclone "$@" $XMEM $XBW $RCT --log-file "$_rlf" --log-level "${RLV:-ERROR}" ) </dev/null >/dev/null 2>>"$_rlf" &
RP=$!; echo $RP > $CRD/$A.rpid; _cltl=$(now); _n=0
while _cl_alive $RP; do
sleep 1; _n=$((_n + 1))
if [ -f $T/jobs/$J.stop ]; then STOPW=stop; cl_kill $RP; wait $RP; return 254; fi
if [ $((_n % 30)) = 0 ] && paused; then STOPW=stop; cl_kill $RP; wait $RP; return 254; fi
cl_tick $RP $J "$NET" || { STOPW=$CL_STOP; wait $RP; return 254; }
done
wait $RP
}
gate() {
{ [ -f $T/jobs/$J.stop ] || paused; } && { STOPW=stop; return 1; }
true
}
cc() {
: > "$COMB"; rm -f $CRD/$A.nh
RLV=DEBUG RLF=$TL.d; rcl cryptcheck "$CLR" "$CRY" --files-from-raw "$1" --one-way --combined "$COMB"; _r=$?; RLV= RLF=
if [ -f "$TL.d" ]; then
sed -n 's/^.*DEBUG : \(.*\): OK - could not check hash$/\1/p' "$TL.d" | sort -u > $CRD/$A.nh
grep -v -e ' DEBUG : ' -e ' INFO  : ' -e 'Creating backend' "$TL.d" >> "$TL"; rm -f "$TL.d"
fi
[ $_r = 254 ] && return 254
return 0
}
pick() { sed -n "s/^$1 //p" "$COMB"; }
bsum() { awk -F'\t' -v L="$1" 'FILENAME == L { k[$0] = 1; next } { p = $0; sub(/^[^\t]*\t/, "", p) } (p in k) { b += $1 } END { print b + 0 }' "$1" $LS; }
used() { [ "$1" -gt 0 ] 2>/dev/null && cl_add "$1" </dev/null >/dev/null 2>&1; true; }
notin() { awk -v L="$1" 'FILENAME != L { k[$0] = 1; next } length($0) && !($0 in k) { print "F\t" $0 }' "$2" ${3:+"$3"} "$1"; }
curset() {
{ printf '%s\n' "$UK"; awk -v p="${udp:+$udp/}" 'length($0) { print p $0 }' "$1"; } > $CRD/$A.cur.t && mv $CRD/$A.cur.t $CRD/$A.cur
RFP=1
}
curoff() { rm -f $CRD/$A.cur; }
rfr() {
[ "$RFP" = 1 ] || return 0
RFP=0
[ -f $W/cloudmnt.sh ] && ( sh $W/cloudmnt.sh refresh "$A" </dev/null >/dev/null 2>&1 & )
true
}
BAD_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, A = {}, B = {}, od = [], oc = [];
function rd(f, M) { let j = null; try { j = json(fs.readfile(f) ?? '[]'); } catch (e) { j = null; } for (let o in (type(j) == 'array' ? j : [])) if (type(o?.Path) == 'string') M[o.Path] = o; }
rd(E('J1'), A); rd(E('J2'), B);
for (let p in split(fs.readfile(E('L')) ?? '', '\n')) {
	if (!length(p) || B[p] == null) continue;
	let s = A[p], d = B[p];
	if (s != null && s.Size == d.Size && substr('' + s.ModTime, 0, 19) == substr('' + d.ModTime, 0, 19)) push(od, p); else push(oc, p);
}
fs.writefile(E('OD'), length(od) ? join('\n', od) + '\n' : '');
fs.writefile(E('OC'), length(oc) ? join('\n', oc) + '\n' : '');
ucode
)
baddel() {
[ -s "$1" ] || return 0
rcf $CRD/$A.js1 lsjson -R --files-only --files-from-raw "$1" "$SR"; _r1=$?
rcf $CRD/$A.js2 lsjson -R --files-only --files-from-raw "$1" "$DR"; _r2=$?
rm -f "$TL"
if [ $_r1 = 0 ] && [ $_r2 = 0 ]; then
J1=$CRD/$A.js1 J2=$CRD/$A.js2 L="$1" OD=$CRD/$A.bd OC=$CRD/$A.bc ucode -e "$BAD_UC" </dev/null >/dev/null 2>&1
[ -s $CRD/$A.bd ] && rcf - delete "$DR" --files-from-raw $CRD/$A.bd
if [ -s $CRD/$A.bc ]; then
_sx=$(t 'prima della cifratura' 'before encryption'); [ "$MODE" = back ] && _sx=$(t 'copia cifrata' 'encrypted copy')
DIF=$CRD/$A.bc LS=$LS DL=$DL SX="$_sx" ucode -e "$CONF_UC" </dev/null > $CO 2>/dev/null
while IFS=$TAB read -r o n; do
[ -n "$n" ] && rcf - moveto "$(rp "$SR" "$o")" "$(rp "$SR" "$n")"
done < $CO
fi
fi
rm -f $CRD/$A.js1 $CRD/$A.js2 $CRD/$A.bd $CRD/$A.bc "$TL"
true
}
nohash() {
[ -s "$OK" ] || return 0
if [ -s $CRD/$A.nh ]; then
awk -v N=$CRD/$A.nh 'FILENAME == N { k[$0] = 1; next } !($0 in k)' $CRD/$A.nh "$OK" > "$OK.t"; mv "$OK.t" "$OK"
fi
rm -f $CRD/$A.nh
}

recover() {
[ -s $CRD/$A.jrn ] && [ -s $CRD/$A.jrnu ] || { rm -f $CRD/$A.jrn $CRD/$A.jrnu; return 0; }
IFS=$TAB read -r jm _ jv js _ jsp jdp < $CRD/$A.jrnu
roots "$jm" "$jv" "$js" "$jsp" "$jdp"
cc $CRD/$A.jrn || return 1
pick '=' > $OK; pick '\*' > $BAD; nohash
[ -s $OK ] && rcf - delete "$SR" --files-from-raw "$OK"
baddel $BAD
rm -f $CRD/$A.jrn $CRD/$A.jrnu "$TL"
}
roots() {
if [ "$1" = run ] && [ -n "$4" ] && [ -n "$5" ]; then SR="$BASE:Utenti/$2/$4"; DR="$3:$5"; CLR=$SR; CRY=$DR
elif [ "$1" = run ]; then SR="$BASE:Utenti/$2"; DR="$3:"; CLR=$SR; CRY=$DR
else SR="$3:"; DR="$BASE:Utenti/$2"; CLR=$DR; CRY=$SR; fi
}

unit() {
own=$1 vis=$2 sec=$3 top=$4 ty=$5 usp=$6 udp=$7 UK="$2/$4"
[ -n "$udp" ] && UK="$2/${udp%%/*}"
roots "$MODE" "$vis" "$sec" "$usp" "$udp"
curoff
if [ "$MODE" = back ]; then fjput UK="$UK" UV=back; elif [ $SW = 0 ]; then fjput UK="$UK" UV=mig; fi
SP=$(rp "$SR" "$top"); DP=$(rp "$DR" "$top")
while :; do
gate || return 3
flush
cl_check "$J" "$NET" >/dev/null || { STOPW=$CL_WHY; return 3; }
MB=$MAXB; [ "${CL_MAX:-0}" -gt 0 ] && [ $((CL_MAX / 3)) -lt "$MB" ] && MB=$((CL_MAX / 3))
rcf $LS.r lsf -R --files-only --format sp --separator "$TAB" "$SP"; r=$?
[ $r = 0 ] || [ $r = 3 ] || { ERRC=$(rcerr "$TL"); return 4; }
rcf $DL.r lsf -R --files-only "$DP"; r=$?
[ $r = 0 ] || [ $r = 3 ] || { ERRC=$(rcerr "$TL"); return 4; }
rm -f "$TL"
if [ "$ty" = d ]; then
awk -F'\t' -v p="$top/" 'NF >= 2 { s = $1; sub(/^[^\t]*\t/, ""); print s "\t" p $0 }' $LS.r > $LS
awk -v p="$top/" 'length($0) { print p $0 }' $DL.r > $DL
else
awk -F'\t' -v p="$top" 'NF >= 2 { print $1 "\t" p; exit }' $LS.r > $LS
[ -s $DL.r ] && printf '%s\n' "$top" > $DL || : > $DL
fi
rm -f $PT
awk -v D="$DL" -v P="$PT" 'FILENAME == D { d[$0] = 1; next }
			{ n++; l[n] = $0; p = $0; sub(/^[^\t]*\t/, "", p); q[n] = p; s[p] = 1 }
			END {
				for (i = 1; i <= n; i++) {
					if (ptl(q[i])) { b = q[i]; sub(/\.[0-9a-f]+\.partial$/, "", b); if (!(b in s) || (b in d)) print q[i] > P; continue }
					print l[i]
				}
			}
			function ptl(x, h) { if (x !~ /\.[0-9a-f]+\.partial$/) return 0; h = x; sub(/\.partial$/, "", h); sub(/.*\./, "", h); return length(h) <= 8 }' $DL $LS > $LS.p
if [ -s $PT ]; then
rcf $PT.a lsf -R --files-only --min-age 1h --include '*.partial' "$SP"; r=$?
rm -f "$TL"
if [ $r = 0 ]; then
if [ "$ty" = d ]; then awk -v p="$top/" 'length($0) { print p $0 }' $PT.a > $PT.b; else awk -v p="$top" 'length($0) { print p }' $PT.a > $PT.b; fi
awk -v B=$PT.b 'FILENAME == B { k[$0] = 1; next } ($0 in k)' $PT.b $PT > $PT.a; mv $PT.a $PT
else : > $PT; fi
rm -f $PT.a $PT.b
fi
if [ -s $PT ]; then
pb=$(bsum $PT)
rcf - delete "$SR" --files-from-raw "$PT" && fjput SUBN="$(grep -c . $PT)" SUBB="$pb"
rm -f "$TL" $PT
fi
mv $LS.p $LS
nrec=0
if [ $SW = 1 ]; then
rcf $LS.r lsf -R --files-only --min-age 10m "$SP"; r=$?
[ $r = 0 ] || [ $r = 3 ] || { ERRC=$(rcerr "$TL"); return 4; }
rm -f "$TL"
if [ "$ty" = d ]; then awk -v p="$top/" 'length($0) { print p $0 }' $LS.r > $LS.y
elif [ -s $LS.r ]; then printf '%s\n' "$top" > $LS.y; else : > $LS.y; fi
: > $LS.p
nrec=$(awk -F'\t' -v Y=$LS.y -v O=$LS.p 'FILENAME == Y { k[$0] = 1; next }
				{ p = $0; sub(/^[^\t]*\t/, "", p); if (p in k) print > O; else n++ } END { print n + 0 }' $LS.y $LS)
mv $LS.p $LS; rm -f $LS.y
fi
set -- $(LS=$LS DL=$DL SK=$SKIP OF=$FR OD=$DU MAXB=$MB MAXN=500 RUN=$([ "$MODE" = run ] && echo 1 || echo 0) \
			CAP=$([ "${CL_MAX:-0}" -gt 0 ] && echo 1 || echo 0) ucode -e "$BLK_UC" </dev/null 2>/dev/null)
nf=${1:-0} nd=${2:-0} nlong=${3:-0} nfail=${4:-0} nnew=${5:-0} nbig=${6:-0}
[ "$nnew" -gt 0 ] && { fjput UK="$UK" LG="$nlong"; longev; }
[ "$nf" = 0 ] && [ "$nd" = 0 ] && [ "$nbig" -gt 0 ] && { STOPW=sim; return 3; }
[ "$nf" = 0 ] && [ "$nd" = 0 ] && break
if [ "$nd" -gt 0 ]; then
curset $DU
cc $DU || { curoff; rfr; return 3; }
used "$(bsum $DU)"
[ -s $COMB ] || { ERRC=$(rcerr "$TL"); curoff; rfr; return 4; }
pick '=' > $OK; pick '\*' > $BAD; nohash
notin $DU $OK $BAD > $CRD/$A.nf
done1 || return 4
if [ -s $BAD ]; then
DIF=$BAD LS=$LS DL=$DL SX="$(t 'prima della cifratura' 'before encryption')" ucode -e "$CONF_UC" </dev/null > $CO 2>/dev/null
while IFS=$TAB read -r o n; do
[ -n "$n" ] || continue
rcf - moveto "$(rp "$CLR" "$o")" "$(rp "$CLR" "$n")" || printf 'F\t%s\n' "$o" >> $CRD/$A.nf
done < $CO
fi
newfail
fi
if [ "$nf" -gt 0 ]; then
gate || return 3
cp $FR $CRD/$A.jrn && printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$MODE" "$own" "$vis" "$sec" "$top" "$usp" "$udp" > $CRD/$A.jrnu
curset $FR
rcl copy "$SR" "$DR" --files-from-raw "$FR" --ignore-existing --no-traverse; r=$?
if [ $r = 254 ]; then
_sw=$STOPW
rcf $CRD/$A.sz size --json --files-from-raw "$FR" "$DR"
set -- $(ucode -e 'let o = {}; try { o = json(require("fs").stdin.read("all")); } catch (e) {} print(int(o?.bytes ?? 0), "\n");' < $CRD/$A.sz 2>/dev/null)
used $(( ${1:-0} * 2 )); STOPW=$_sw
return 3
fi
FB=$(bsum $FR); used $((FB * 2))
cc $FR || return 3
used "$FB"
pick '=' > $OK; pick '\*' > $BAD; nohash
[ -s $COMB ] || { ERRC=$(rcerr "$TL"); return 4; }
notin $FR $OK > $CRD/$A.nf
done1 || return 4
baddel $BAD
rm -f $CRD/$A.jrn $CRD/$A.jrnu
newfail
if [ -s $CRD/$A.ng ]; then
awk -v F=$FR 'FILENAME == F { k[$0] = 1; next } ($0 in k)' $FR $CRD/$A.ng > $CRD/$A.ng.t
[ -s $CRD/$A.ng.t ] && rcf - delete "$DR" --files-from-raw $CRD/$A.ng.t
rm -f $CRD/$A.ng.t
fi
fi
rm -f "$TL" $CRD/$A.ng
curoff; rfr
done
TREC=$((TREC + nrec))
[ "$nfail" -gt 0 ] && return 2
[ "$nlong" -gt 0 ] && return 1
[ "$nrec" -gt 0 ] && return 5
if [ "$ty" = d ]; then
gate || return 3
rcf - copy "$SP" "$DP" --create-empty-src-dirs --ignore-existing
if [ -n "$udp" ]; then : > $BS; else bases > $BS; fi; bok=1
while IFS= read -r b; do [ -n "$b" ] && { rcf - mkdir "$(rp "$DR" "$b")" || bok=0; }; done < $BS
rm -f $BS
[ $bok = 1 ] && rcf - rmdirs "$SP"
rcf $LS.r lsf -R --files-only --min-age 1h --include '*.partial' "$DP"
rm -f $PT
awk -v D="$DL" -v P="$PT" -v p="$top/" 'FILENAME == D { d[$0] = 1; next }
			{ x = p $0; b = x; h = x; sub(/\.partial$/, "", h); sub(/.*\./, "", h)
			  if (h !~ /^[0-9a-f]+$/ || length(h) > 8) next; sub(/\.[0-9a-f]+\.partial$/, "", b); if (!(b in d)) print x > P }' $DL $LS.r
[ -s $PT ] && rcf - delete "$DR" --files-from-raw "$PT"
rm -f $PT
rcf $LS.r lsf -R --files-only "$SP"; r=$?
rm -f "$TL"
[ $r = 3 ] || [ ! -s $LS.r ] || return 2
fi
if [ "$MODE" = back ]; then fjput UK="$UK" UV=clear FNI=0; else fjput UK="$UK" UV=enc FNI=0 ONLYCH=$SW; fi
return 0
}
done1() {
[ -s $OK ] || return 0
rcf - delete "$SR" --files-from-raw "$OK" || { ERRC=$(rcerr "$TL"); return 1; }
set -- $(awk -F'\t' -v O="$OK" 'FILENAME == O { k[$0] = 1; next } { p = $0; sub(/^[^\t]*\t/, "", p) } (p in k) { n++; b += $1 } END { print n + 0, b + 0 }' $OK $LS)
PN=$((PN + $1)); PB=$((PB + $2)); DN=$((DN + $1)); DB=$((DB + $2))
}
newfail() {
[ -s $CRD/$A.nf ] || return 0
gone
[ -s $CRD/$A.nf ] || return 0
k=$(grep -c . $CRD/$A.nf); cat $CRD/$A.nf >> $SKIP; rm -f $CRD/$A.nf
PF=$((PF + k)); FN=$((FN + k))
}
gone() {
rcf $LS.n lsf -R --files-only "$SP"; r=$?
rm -f "$TL"
[ $r = 0 ] || [ $r = 3 ] || { rm -f $LS.n; return 0; }
[ $r = 3 ] && : > $LS.n
: > $CRD/$A.nk
: > $CRD/$A.ng
set -- $(awk -F'\t' -v N=$LS.n -v F=$CRD/$A.nf -v K=$CRD/$A.nk -v G=$CRD/$A.ng -v pre="$([ "$ty" = d ] && printf '%s/' "$top")" '
		FILENAME == N { h[pre $0] = 1; next }
		FILENAME == F { p = $0; sub(/^[^\t]*\t/, "", p); if (p in h) print $0 > K; else { g[p] = 1; n++; print p > G } next }
		{ p = $0; sub(/^[^\t]*\t/, "", p); if (p in g) { b += $1; delete g[p] } }
		END { print n + 0, b + 0 }' $LS.n $CRD/$A.nf $LS)
mv $CRD/$A.nk $CRD/$A.nf; rm -f $LS.n
[ "${1:-0}" -gt 0 ] && fjput SUBN="$1" SUBB="${2:-0}"
true
}
longev() {
_l0=${FJO#* }; _l0=${_l0#* }; _l0=${_l0%% *}
[ "$_l0" = 0 ] || return 0
ev cloud_crypt_err "⚠️ Cloud ¦ $vis: $(t 'cartelle non cifrate' 'folders not encrypted')"
case "$own" in admin|shared) ;; *) evme cloud_crypt_err "⚠️ Cloud ¦ $(t 'Nomi lunghi: in chiaro' 'Long names: unencrypted') ¦ $top" "$own" ;; esac
true
}
failev() {
fjput UK="$UK" FNI=1
[ "${FJO%% *}" = 3 ] || return 0
ev cloud_crypt_err "⚠️ Cloud ¦ $vis: $(t 'cartelle non cifrate' 'folders not encrypted')"
case "$own" in admin|shared) ;; *) evme cloud_crypt_err "⚠️ Cloud ¦ $(t 'Alcuni file non si cifrano' 'Some files not encrypted') ¦ $top" "$own" ;; esac
true
}

build() {
: > $TODO.t; CSD=0; rm -f $CRD/$A.old
people > $CRD/$A.ppl
while IFS=$TAB read -r own vis sec; do
[ -n "$sec" ] || continue
if ! grep -q "^\[$sec\][ 	]*$" $RC 2>/dev/null; then
[ "$MODE" = run ] && [ $CSD = 0 ] && { CSD=1; sh "$CS" cryptset "$A" </dev/null >/dev/null 2>&1; }
if ! grep -q "^\[$sec\][ 	]*$" $RC 2>/dev/null; then
[ "$MODE" = back ] && ! hasenc "$vis" && continue
ERRC=nokey; return 1
fi
fi
if [ "$MODE" = run ]; then
rcf $CRD/$A.raw lsf --format sp --separator "$TAB" "$BASE:Utenti/$vis"; r=$?
[ $r = 3 ] && continue
[ $r = 0 ] || { ERRC=$(rcerr "$TL"); rm -f "$TL"; return 1; }
rcf $CRD/$A.enc lsf --format e "$sec:"; r=$?
[ $r = 0 ] || [ $r = 3 ] || { ERRC=$(rcerr "$TL"); rm -f "$TL"; return 1; }
[ $r = 3 ] && : > $CRD/$A.enc
ALL=0
else
rcf $CRD/$A.raw lsf --format sp --separator "$TAB" "$sec:"; r=$?
[ $r = 3 ] && continue
[ $r = 0 ] || { ERRC=$(rcerr "$TL"); rm -f "$TL"; return 1; }
: > $CRD/$A.enc; ALL=1
fi
rm -f "$TL"
U=$UCF NJ=$ETC/nas.json XJ=$ETC/nasx.json RAW=$CRD/$A.raw ENC=$CRD/$A.enc OWN=$own VIS=$vis SEC=$sec ALL=$ALL OLDF=$CRD/$A.old \
			ucode -e "$UNITS_UC" </dev/null >> $TODO.t 2>/dev/null
[ $SW = 1 ] && [ "$MODE" = run ] && [ -s $CRD/$A.enc ] && { inside || return 1; }
done < $CRD/$A.ppl
rm -f $CRD/$A.raw $CRD/$A.enc $CRD/$A.in $CRD/$A.flt $CRD/$A.ep $CRD/$A.dec
if [ -s $CRD/$A.old ] && [ "$MODE" = run ] && [ $SW = 0 ] && [ "$(fjget | cut -d' ' -f5)" = 0 ]; then
rm -f $CRD/$A.old $TODO.t; ERRC=crold; return 1
fi
rm -f $CRD/$A.old
mv $TODO.t $TODO
}
hasenc() {
A_=$A F=$FJ V="$1/" ucode -e 'let S = {}; try { S = json(require("fs").readfile(getenv("F")) ?? "{}"); } catch (e) {}
		let v = lc(getenv("V")), r = 0;
		for (let k, x in (S?.accts?.[getenv("A_")]?.f ?? {})) if (lc(substr(k, 0, length(v))) == v && x != "clear") r = 1;
		exit(r ? 0 : 1);' </dev/null >/dev/null 2>&1
}
INS_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, dec = {}, seen = {}, LN = {};
/* lunghezze di un nome cifrato: base32 senza «=» di 16, 32, 48… byte (EME), fino a 255 */
for (let k = 1; k <= 15; k++) LN[int((k * 128 + 4) / 5)] = true;
function isenc(s) { return LN[length(s)] && match(s, /^[0-9a-v]+$/) != null; }
let U = null, N = {}, X = {};
if (E('IM') != 'list') {
	U = loadfile(E('U'))();
	try { N = json(fs.readfile(E('NJ')) ?? '{}'); } catch (e) { N = {}; }
	try { X = json(fs.readfile(E('XJ')) ?? '{}'); } catch (e) { X = {}; }
	for (let l in split(fs.readfile(E('DEC')) ?? '', '\n')) {
		let i = index(l, ' \t ');
		if (i < 1) continue;
		let a = substr(l, 0, i), b = substr(l, i + 3);
		if (length(b) && index(b, 'Failed') != 0) dec[a] = b;
	}
}
for (let l in split(fs.readfile(E('IN')) ?? '', '\n')) {
	let i = index(l, '\t');
	if (i < 1) continue;
	let sz = substr(l, 0, i), P = split(substr(l, i + 1), '/'), j = 0;
	while (j < length(P) && isenc(P[j])) j++;
	if (j < 1 || j >= length(P) || !match(sz, /^-?[0-9]+$/)) continue;
	let ep = join('/', slice(P, 0, j)), top = P[j], d = j < length(P) - 1;
	if (E('IM') == 'list') { print(ep, '\n'); continue; }
	let dp = dec[ep];
	if (dp == null || !length(dp) || seen[ep + '\t' + top]) continue;
	seen[ep + '\t' + top] = true;
	let pa = [ U.UDIR.root, E('VIS') ];
	for (let x in split(dp, '/')) push(pa, x);
	push(pa, top);
	let c = U.cpriv(pa, N, X);
	if (c == null || c.own != E('OWN')) continue;
	print(E('OWN'), '\t', E('VIS'), '\t', E('SEC'), '\t', top, '\t', d ? 'd' : 'f', '\t', d ? -1 : +sz, '\t', ep, '\t', dp, '\n');
}
ucode
)
inside() {
awk '{ sub(/\/$/, "") } /^[0-9a-v]+$/ { print "+ /" $0 "/**" } END { print "- **" }' $CRD/$A.enc > $CRD/$A.flt
grep -q '^+ ' $CRD/$A.flt || return 0
rcf $CRD/$A.in lsf -R --files-only --format sp --separator "$TAB" --filter-from $CRD/$A.flt "$BASE:Utenti/$vis"; r=$?
[ $r = 3 ] && return 0
[ $r = 0 ] || { ERRC=$(rcerr "$TL"); rm -f "$TL"; return 1; }
rm -f "$TL"
IM=list IN=$CRD/$A.in ucode -e "$INS_UC" </dev/null 2>/dev/null | sort -u | head -n 200 > $CRD/$A.ep
[ -s $CRD/$A.ep ] || return 0
rcf $CRD/$A.dec cryptdecode "$sec:" $(grep -E '^[0-9a-v/]+$' $CRD/$A.ep); r=$?
rm -f "$TL"
[ $r = 0 ] || return 0
U=$UCF NJ=$ETC/nas.json XJ=$ETC/nasx.json IN=$CRD/$A.in DEC=$CRD/$A.dec OWN=$own VIS=$vis SEC=$sec \
		ucode -e "$INS_UC" </dev/null >> $TODO.t 2>/dev/null
true
}
todosize() {
TB=0; TN=0
while IFS=$TAB read -r own vis sec top ty sz usp udp; do
roots "$MODE" "$vis" "$sec" "$usp" "$udp"
if [ "$ty" = f ]; then TB=$((TB + sz)); TN=$((TN + 1)); continue; fi
rcf $CRD/$A.sz size --json "$(rp "$SR" "$top")"
set -- $(ucode -e 'let o = {}; try { o = json(require("fs").stdin.read("all")); } catch (e) {} print(int(o?.bytes ?? 0), " ", int(o?.count ?? 0), "\n");' < $CRD/$A.sz 2>/dev/null)
TB=$((TB + ${1:-0})); TN=$((TN + ${2:-0}))
done < $TODO
rm -f "$TL"
}

VCK_UC=$(cat <<'ucode'
let fs = require('fs'), E = getenv, f = E('F'), S = {};
try { S = json(fs.readfile(f) ?? '{}'); } catch (e) { S = {}; }
if (type(S) != 'object') S = {};
let a = E('A_'), o = type(S[a]) == 'object' ? S[a] : {}, h = type(o.h) == 'array' ? o.h : [], seen = {};
for (let x in h) seen[x] = true;
for (let l in split(fs.readfile(E('BL')) ?? '', '\n')) {
	let i = index(l, '\t');
	if (i < 1 || seen[substr(l, 0, i)]) continue;
	seen[substr(l, 0, i)] = true; push(h, substr(l, 0, i)); print(substr(l, i + 1), '\n');
}
while (length(h) > 500) shift(h);
o.h = h;
if (E('DONE') == '1') { o.t = time(); o.n = +E('NC'); o.bad = +E('NB'); }
S[a] = o;
let t = f + '.' + E('P_') + '.t';
fs.writefile(t, sprintf('%.J\n', S)); fs.rename(t, f);
ucode
)
vcheck() {
lt=$(A_=$A F=$VCK ucode -e 'let S = {}; try { S = json(require("fs").readfile(getenv("F")) ?? "{}"); } catch (e) {} print(int(S?.[getenv("A_")]?.t ?? 0), "\n");' </dev/null 2>/dev/null)
[ $(( $(now) - ${lt:-0} )) -ge 604800 ] || return 0
gate || return 0
cl_check "$J" "$NET" >/dev/null || return 0
VB=209715200; [ "${CL_MAX:-0}" -gt 0 ] && [ "$CL_MAX" -lt $VB ] && VB=$CL_MAX
VL=$CRD/$A.vl; : > $VL; : > $VL.b
people > $CRD/$A.ppl
vi=0
while IFS=$TAB read -r own vis sec; do
[ -n "$sec" ] && grep -q "^\[$sec\][ 	]*$" $RC 2>/dev/null || continue
vd=; vx=
if [ "$(cl_tier)" = A ]; then
vi=$((vi + 1))
rcf $VL.r lsf --dirs-only "$sec:"; r=$?
rm -f "$TL"
[ $r = 0 ] || [ $r = 3 ] || { rm -f $VL $VL.r $VL.b; return 0; }
vd=$(awk -v s="$$$vi" 'BEGIN { srand(s) } length($0) { n++; d[n] = $0 } END { k = int(rand() * (n + 1)); if (k >= 1 && k <= n) print d[k] }' $VL.r)
vd=${vd%/}; vx="--max-depth 3"; [ -n "$vd" ] || vx="--max-depth 1"
fi
rcf $VL.r lsf -R --files-only $vx --format sp --separator "$TAB" "$sec:$vd"; r=$?
rm -f "$TL"
[ $r = 0 ] || [ $r = 3 ] || { rm -f $VL $VL.r $VL.b; return 0; }
awk -F'\t' -v s="$sec" -v v="$vis" -v p="${vd:+$vd/}" 'NF >= 2 { z = $1; sub(/^[^\t]*\t/, ""); print z "\t" s "\t" v "\t" p $0 }' $VL.r >> $VL
done < $CRD/$A.ppl
awk 'BEGIN { srand() } { print rand() "\t" $0 }' $VL | sort -n | cut -f2- |
awk -F'\t' -v M="$VB" 'n < 20 && $1 >= 0 && b + $1 <= M { print; n++; b += $1 }' > $VL.r
nc=0; nb=0; vok=1
while IFS=$TAB read -r sz sec vis p; do
[ -n "$p" ] || continue
gate || { vok=0; break; }
rcl cat "$sec:$p"; r=$?
[ $r = 254 ] && { vok=0; break; }
used "$sz"
if [ $r = 0 ]; then nc=$((nc + 1))
elif grep -qi 'authenticate\|bad magic\|bad password\|too short\|decrypt\|corrupt' "$TL" 2>/dev/null; then
nc=$((nc + 1)); nb=$((nb + 1))
printf '%s\t%s\n' "$(printf '%s' "$sec:$p" | md5sum | cut -c1-32)" "$vis" >> $VL.b
else vok=0; break; fi
rm -f "$TL"
done < $VL.r
rm -f "$TL"
lk_wait $T/cr.lock 10 || { rm -f $VL $VL.r $VL.b; return 0; }
env A_=$A F=$VCK P_=$$ BL=$VL.b DONE=$vok NC=$nc NB=$nb ucode -e "$VCK_UC" </dev/null 2>/dev/null > $VL.r
lk_put $T/cr.lock
sort $VL.r | uniq -c | while read -r k vis; do
[ -n "$vis" ] && ev cloud_crypt_bad "⚠️ Cloud ¦ $vis: $(t "file cifrati rovinati ($k)" "damaged encrypted files ($k)")"
done
lg "vck c=$nc r=$nb ok=$vok"
rm -f $VL $VL.r $VL.b
}

hashes() {
_h=$CRD/$A.hs
if [ ! -s $_h ] || [ "$(cat $_h)" = '?' ] || [ "$(age $_h)" -ge 86400 ]; then
rcf $_h.j backend features "$BASE:"
rm -f "$TL"
ucode -e 'let o = null; try { o = json(require("fs").stdin.read("all")); } catch (e) {}
			print(type(o?.Hashes) == "array" ? (length(filter(o.Hashes, (x) => type(x) == "string" && length(x))) ? "ok" : "no") : "?", "\n");' < $_h.j > $_h 2>/dev/null
rm -f $_h.j
fi
[ "$(cat $_h 2>/dev/null)" != no ]
}

fin() {
flush 1
rfr
[ "$LEFT" = 1 ] && left
[ -n "$SLOT" ] && sh "$CS" slot put "$J" >/dev/null 2>&1
[ -n "$USZ" ] && ( ucode "${WF_CLOUDUC:-$W/cloud.uc}" usize </dev/null >/dev/null 2>&1 & )
rm -f $CRD/$A.cur $CRD/$A.rpid "$TL" $LS $LS.r $DL $DL.r $FR $DU $OK $BAD $COMB $CO $CRD/$A.sz $CRD/$A.nf $CRD/$A.nk $CRD/$A.ppl $TODO.t $PT $BS $LS.p $LS.n $LS.y $CRD/$A.vl $CRD/$A.vl.r $CRD/$A.vl.b \
		$CRD/$A.in $CRD/$A.flt $CRD/$A.ep $CRD/$A.dec $CRD/$A.raw $CRD/$A.enc "$TL.d" $CRD/$A.ng$CRD/$A.ng.t $CRD/$A.nh $CRD/$A.old $CRD/$A.cur.t $PT.a $PT.b $CRD/$A.js1 $CRD/$A.js2 $CRD/$A.bd $CRD/$A.bc $CRD/$A.lc
rm -rf $CRD/$A.lk
}
mig() {
A=$1; okid "$A" || exit 2
BASE=wfa${A#a}; J=crmig-$A
mkdir -p $CRD $T/jobs; chmod 700 $CRD
TODO=$CRD/$A.todo; SKIP=$CRD/$A.skip; RES=$CRD/$A.res; TL=$CRD/$A.rlog
LS=$CRD/$A.ls; DL=$CRD/$A.dl; FR=$CRD/$A.fr; DU=$CRD/$A.du; OK=$CRD/$A.ok; BAD=$CRD/$A.bad; COMB=$CRD/$A.comb; CO=$CRD/$A.co
PT=$CRD/$A.pt; BS=$CRD/$A.bs
lk_get $CRD/$A.lk || exit 0
SLOT=; LEFT=; USZ=; SW=0; TREC=0; RFP=0; trap 'fin' EXIT
command -v rclone >/dev/null 2>&1 && [ -f $RC ] || exit 0
set -- $(fjget); on=${1:-0} kok=${2:-0} st=${3:--}; DB=0; DN=0; FN=0
case "$MODE" in
run) [ "$on" = 1 ] && [ "$kok" = 1 ] && { [ "$st" = mig ] || [ "$st" = on ]; } || exit 0 ;;
back) [ "$st" = back ] || exit 0 ;;
esac
[ "${6:-0}" = 1 ] && exit 0
LEFT=1
if [ "$st" = on ]; then
SW=1
if [ ! -s $CRD/$A.nxt ]; then
nx=${10:--}; [ "$nx" = - ] && nx=$(( ${11:-0} + 86400 ))
echo "$nx" > $CRD/$A.nxt
fi
[ "$(cat $CRD/$A.nxt 2>/dev/null || echo 0)" -gt "$(now)" ] 2>/dev/null && exit 0
fi
rm -f $T/jobs/$J.stop
NID=$(nid)
NEWN=0
if [ "$(cat $CRD/$A.nid 2>/dev/null)" != "$NID" ]; then rm -f $TODO $SKIP $RES; echo "$NID" > $CRD/$A.nid; NEWN=1; fi
: >> $SKIP; : >> $RES
[ $SW = 0 ] && [ -f $TODO ] && [ ! -s $TODO ] && grep -q "${TAB}fail\$" $RES && [ "$(age $TODO)" -lt 3600 ] && exit 0
cl_check "$J" "$NET" >/dev/null || { lg "$CL_WHY"; exit 0; }
sh "$CS" slot get "$J" "$A" $$ >/dev/null 2>&1 || { lg slot; exit 0; }
SLOT=1
export RCLONE_CONFIG=$RC
SVC=$(A_=$A CJ=$ETC/cloud.json ucode -e 'let C = {}; try { C = json(require("fs").readfile(getenv("CJ")) ?? "{}"); } catch (e) {} for (let a in (C?.accounts ?? [])) if (a?.id == getenv("A_")) print(a.svc ?? "");' </dev/null 2>/dev/null)
cl_env "$SVC"; XMEM=$CL_RMEM
[ -z "$CL_MOK" ] && [ "$(cl_tier)" = A ] && export GOGC=20
TR=2; cl_low && TR=1
[ -n "$CL_MOK" ] && [ "$(cl_tier)" != A ] && case " $XMEM " in *" --transfers 1 "*) TR=1 ;; esac
XMEM=$(printf '%s' "$XMEM" | sed "s/--transfers [0-9]*/--transfers $TR/")
XBW=; case "$CL_BW" in ''|off|off:off) ;; *) XBW="--bwlimit $CL_BW" ;; esac
MAXB=2147483648; [ "$(cl_tier)" = A ] && MAXB=209715200
if [ "$MODE" = run ] && [ $SW = 0 ] && ! hashes; then fjput ERR=nohash; lg nohash; exit 0; fi
recover || { lg stop; exit 0; }
[ $SW = 1 ] && rm -f $TODO
if [ ! -f $TODO ]; then
build || { fjput ERR="$ERRC"; lg "$ERRC"; exit 0; }
[ $SW = 1 ] || NEWN=1
fi
if [ $NEWN = 1 ] || [ $SW = 1 ]; then
set -- $(fjget); B0=${4:-0} N0=${5:-0} T0=${7:-0} M0=${8:-0}
todosize
if [ $NEWN = 1 ]; then fjput TOTB=$((B0 + TB)) TOTN=$((N0 + TN)) FAILS=0 ERR=
elif [ $((B0 + TB)) != "$T0" ] || [ $((N0 + TN)) != "$M0" ] || [ "${9:-0}" = 1 ]; then fjput TOTB=$((B0 + TB)) TOTN=$((N0 + TN)) ERR=; fi
fi
lg start
while :; do
while [ -s $TODO ]; do
IFS=$TAB read -r own vis sec top ty sz usp udp < $TODO
unit "$own" "$vis" "$sec" "$top" "$ty" "$usp" "$udp"; r=$?
case $r in
3) flush 1; lg "${STOPW:-stop}"; exit 0 ;;
4) flush 1; fjput ERR="${ERRC:-fail}"; lg "${ERRC:-fail}"; exit 0 ;;
2) grep -qxF "$vis/$top${TAB}fail" $RES || failev; res=fail ;;
1) res=long ;;
5) res=recent ;;
*) res=ok ;;
esac
printf '%s\t%s\n' "$vis/$top" "$res" >> $RES
tail -n +2 $TODO > $TODO.t && mv $TODO.t $TODO
done
flush 1
[ $SW = 1 ] && break
build || { fjput ERR="$ERRC"; lg "$ERRC"; exit 0; }
[ -s $TODO ] || break
set -- $(fjget); B0=${4:-0} N0=${5:-0}
todosize
fjput TOTB=$((B0 + TB)) TOTN=$((N0 + TN))
awk -F'\t' -v Q="$RES" 'FILENAME == Q { k[$1] = 1; next } !(($2 "/" $4) in k)' $RES $TODO > $TODO.t
if [ -s $TODO.t ]; then mv $TODO.t $TODO; continue; fi
: > $TODO
grep -q "${TAB}fail\$" $RES && { lg day; exit 0; }
break
done
if [ $SW = 1 ]; then
vcheck
nx=86400; { [ "$TREC" -gt 0 ] || [ "$DN" -gt 0 ]; } && nx=900
nx=$(( $(now) + nx )); echo $nx > $CRD/$A.nxt; rm -f $TODO
fjput NXT=$nx
[ "$DN" -gt 0 ] && USZ=1
lg sweep
exit 0
fi
if [ "$MODE" = run ]; then
fjput STIF='mig|on' ST=on ERR= NXT=$(( $(now) + 86400 ))
[ "${FJO##* }" = 1 ] || { lg moved; rm -f $TODO $SKIP $RES; exit 0; }
ev cloud_crypt_done "🗄️ Cloud ¦ $(t 'Cartelle private cifrate' 'Private folders encrypted') ¦ $(t 'cloud comune' 'home cloud')"
else
set -- $(fjget); [ "${3:--}" = back ] || { lg moved; rm -f $TODO $SKIP $RES; exit 0; }
people > $CRD/$A.ppl; left1=0
while IFS=$TAB read -r _ _ s1; do
[ -n "$s1" ] && grep -q "^\[$s1\][ 	]*$" $RC 2>/dev/null || continue
rcf $CRD/$A.lc lsf -R --files-only "$s1:"; r=$?
rm -f "$TL"
[ $r = 0 ] || [ $r = 3 ] || { left1=1; break; }
[ $r = 0 ] && [ -s $CRD/$A.lc ] && { left1=1; break; }
done < $CRD/$A.ppl
rm -f $CRD/$A.lc
[ $left1 = 1 ] && { lg again; rm -f $TODO $RES; exit 0; }
awk -v a="${A#a}" '/^\[wfa[0-9]+[cx][0-9a-z]+\][ \t]*$/ { s = substr($0, 2); sub(/\][ \t]*$/, "", s); if (match(s, "^wfa" a "[cx]")) print s }' $RC |
ucode -e 'let o = {}; for (let s in split(trim(require("fs").stdin.read("all") ?? ""), "\n")) if (length(s)) o[s] = null; print(sprintf("%J", o));' > $CRD/$A.rm 2>/dev/null
if [ "$(cat $CRD/$A.rm)" != '{ }' ] && [ "$(cat $CRD/$A.rm)" != '{}' ]; then
n=0; until ucode "${WF_CLOUDUC:-$W/cloud.uc}" rcput $CRD/$A.rm </dev/null >/dev/null 2>&1; do n=$((n + 1)); [ $n -ge 3 ] && { lg busy; exit 0; }; sleep 1; done
fi
rm -f $CRD/$A.rm
fjput STIF=back ST=off ERR=
ev cloud_crypt_back_done "🗄️ Cloud ¦ $(t 'Cartelle private in chiaro' 'Private folders decrypted') ¦ $(t 'cloud comune' 'home cloud')"
fi
rm -f $TODO $SKIP $RES
USZ=1
lg 'done'
}
stop() {
A=$1; okid "$A" || exit 2; J=crmig-$A
mkdir -p $CRD $T/jobs; chmod 700 $CRD
fjput PAUSE=1; : > $T/jobs/$J.stop
p=$(cat $CRD/$A.rpid 2>/dev/null); alive "$p" && cl_kill "$p"
true
}
halt() {
A=$1; okid "$A" || exit 2; J=crmig-$A
mkdir -p $CRD $T/jobs; chmod 700 $CRD
: > $T/jobs/$J.stop
p=$(cat $CRD/$A.rpid 2>/dev/null); alive "$p" && cl_kill "$p"
true
}
fadd() {
A=$1; okid "$A" || exit 2
case "$3" in enc|mig) ;; *) exit 2 ;; esac
printf '%s' "$2" | grep -qE '^[^/]+/[^/]+$' || exit 2
if [ "$3" = mig ]; then fjput UK="$2" UV=mig UNEW=1 STIF='mig|on' NXT=0 || exit 1; rm -f $CRD/$A.nxt
else fjput UK="$2" UV=enc UNEW=1 STIF='mig|on' || exit 1; fi
true
}
resume() {
A=$1; okid "$A" || exit 2; J=crmig-$A
fjput PAUSE=0 NXT=0 || exit 1
rm -f $T/jobs/$J.stop $CRD/$A.nxt
true
}

c=$1; [ $# -gt 0 ] && shift
case "$c" in
run) MODE=run; mig "$@" ;;
back) MODE=back; mig "$@" ;;
stop) stop "$@" ;;
halt) halt "$@" ;;
resume) resume "$@" ;;
fadd) fadd "$@" ;;
*) echo "uso: cloudcr.sh run|back|stop|halt|resume <acct> · fadd <acct> <vis>/<top> enc|mig"; exit 2 ;;
esac
