#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom
P0=; [ -n "$WF_CRONTEST" ] && [ ! -e /etc/openwrt_release ] && { P0=$WF_CRONTEST; PATH=$P0/bin:$PATH; }
EN=
lang() {
if [ -z "$P0" ] && [ -r /etc/config/wrtfreedom ] && [ ! -e /tmp/.uci/wrtfreedom ]; then
EN=0; ls_=0
while read -r la_ lb_ lc_; do
case "$la_" in
config) lc_=${lc_#[\'\"]}; lc_=${lc_%[\'\"]}; if [ "$lc_" = ui ]; then ls_=1; else ls_=0; fi ;;
option) [ $ls_ = 1 ] || continue; lb_=${lb_#[\'\"]}; lb_=${lb_%[\'\"]}; [ "$lb_" = lang ] || continue
lc_=${lc_#[\'\"]}; lc_=${lc_%[\'\"]}; if [ "$lc_" = en ]; then EN=1; else EN=0; fi ;;
esac
done < /etc/config/wrtfreedom
else EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1; fi
}
t() { [ -n "$EN" ] || lang; if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh "$P0$W/event.sh" cron "$1" "$2" "$3"; }	# tipo categoria testo
wantmark() { mkdir -p "$P0/tmp/wf-want"; date +%s > "$P0/tmp/wf-want/$1"; }
quick() { ubus call wrtfreedom quick "{\"act\":\"$1\"${2:+,\"mac\":\"$2\"}}" >/dev/null 2>&1; }
wgif() { wl_=$(uci -q show network | sed -n "s/^network\.\([A-Za-z0-9_]*\)\.proto='wireguard'$/\1/p" | grep -vxE 'wgo(ut|[0-9]+)'); for i in $wl_; do [ -n "$(uci -q get network.$i.listen_port)" ] && { echo $i; return; }; done; echo "$wl_" | head -n 1; }	# Server VPN: con la porta in ascolto, senza il Client VPN (come wgiface)
isup() { ifstatus "$1" 2>/dev/null | jsonfilter -e '@.up' 2>/dev/null | grep -q true; }
mac() { echo "$1" | tr 'A-F' 'a-f' | grep -qE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'; }
once() { f=$P0/tmp/wf-cron.$1; n=$(date +%s); l=$(cat "$f" 2>/dev/null); [ -n "$l" ] && [ $((n - l)) -lt "$2" ] && return 1; echo "$n" > "$f"; }
unflag() { rm -f "$P0/tmp/wf-cron.$1"; }
raise() { [ -f "$P0/tmp/wf-cron.$1.f" ] && return 1; : > "$P0/tmp/wf-cron.$1.f"; }
clear() { [ -f "$P0/tmp/wf-cron.$1.f" ] || return 1; rm -f "$P0/tmp/wf-cron.$1.f"; }
reg() { ucode "$P0$W/svc.uc" log "wf:$1" "$2" "${3:-c}" >/dev/null 2>&1; }
rlast() { ucode -e 'let s = "wf:" + ARGV[0], h = 5381, fs = require("fs"), r = "";
	for (let i = 0; i < length(s); i++) h = ((h * 33) ^ ord(s, i)) & 0x7fffffff;
	for (let l in split(trim(fs.readfile("/tmp/wf-cronrun.log") ?? fs.readfile("/etc/wrtfreedom/cronrun.log") ?? ""), "\n")) {
		let m = match(l, /^([0-9]{1,12})\|([0-9a-f]{8})\|-?[0-9]{1,5}\|([crn])$/); if (m && m[2] == sprintf("%08x", h) && m[3] == ARGV[1]) r = m[1]; }
	print(r);' "$1" "$2" 2>/dev/null; }
hth() { ubus call wrtfreedom health 2>/dev/null | jsonfilter -e "@.th.$1" 2>/dev/null; }
tgdoc() {
TK=$(uci -q get wrtfreedom.tg.token); CH=$(uci -q get wrtfreedom.tg.chat)
[ -n "$TK" ] && [ -n "$CH" ] && command -v curl >/dev/null || return 1
mkdir -p /tmp/wf-tg.k && chmod 700 /tmp/wf-tg.k || return 1
K=/tmp/wf-tg.k/c-$$
( umask 077; printf 'url = "https://api.telegram.org/bot%s/sendDocument"\n' "$TK" > "$K" )
RN=$(uci -q get wrtfreedom.ui.name); [ -n "$RN" ] || RN=$(cat /proc/sys/kernel/hostname 2>/dev/null); RN=${RN:-OpenWrt}
he_() { printf '%s' "$1" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g'; }
c_=$(he_ "$2"); h_=${c_%%" ¦ "*}; b_=; [ "$h_" = "$c_" ] || b_=$(printf '%s' "${c_#*" ¦ "}" | sed 's/ ¦ /\n/g')
curl -s -m 60 -F chat_id="$CH" -F "document=@$1" --form-string "caption=<b>$h_</b>
${b_:+$b_
}<i>$(he_ "$RN")</i>" --form-string parse_mode=HTML -K "$K" > "${3:-/dev/null}"; r=$?
rm -f "$K"; return $r
}
for lb_f in "$P0$W/lib.sh" "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
adginit() { for s in adguardhome AdGuardHome; do [ -x "$P0/etc/init.d/$s" ] && { echo $s; return; }; done; }
lanbr() { homenet >/dev/null; echo "$HN_DEV"; }
adghook() { [ -f "$P0/usr/lib/acme/notify" ] && grep -q notify "$P0/usr/lib/acme/hook" 2>/dev/null && [ ! -f "$P0/etc/hotplug.d/acme/90-wrtfreedom" ] && grep -qE '^[^#].* # wf:certadg$' "$P0/etc/crontabs/root" 2>/dev/null; }
adgon() { [ -f "$P0/etc/hotplug.d/acme/90-wrtfreedom" ] || grep -qE '^[^#].* # wf:certadg$' "$P0/etc/crontabs/root" 2>/dev/null; }
adgcfg() { Y=$(adgyaml) && [ -n "$Y" ] || return 1
C=$(g certificate_path); K=$(g private_key_path); N=$(g server_name)
D=${Y%/*}/; [ "$D" = "$P0/etc/" ] && D=$P0/etc/adguardhome/; return 0; }
g() { sed -n "s/^ *$1: *['\"]\{0,1\}\([^'\"]*\)['\"]\{0,1\} *$/\1/p" "$Y" | head -n 1; }
adgin() { case "$C$K" in *..*) return 1 ;; esac
case "${D#"$P0"}" in /|/etc/|/usr/|/usr/bin/|/usr/sbin/|/usr/lib/|/usr/share/|/bin/|/sbin/|/lib/|/tmp/|/var/|/root/|/etc/ssl/*|/etc/acme/*|/etc/config/*|/etc/wrtfreedom/*|/etc/init.d/*|/etc/uci-defaults/*|/lib/upgrade/*|/rom/*|/proc/*|/sys/*|/dev/*) return 1 ;; esac
[ -n "$C" ] && [ "${C#"$D"}" != "$C" ] && [ "${K#"$D"}" != "$K" ]; }
adgkeep() { KD=$P0/lib/upgrade/keep.d/wrtfreedom; [ -f "$KD" ] || return 0
a_=0; adgcfg && { [ -n "$1" ] && { C=$1; K=$2; }; adgin && [ -f "$C" ] && [ -f "$K" ] && a_=1; }
{ printf '%s\n' /etc/wrtfreedom/ /etc/config/wrtfreedom /etc/uci-defaults/99-wrtfreedom; [ $a_ = 0 ] || printf '%s\n%s\n' "${C#"$P0"}" "${K#"$P0"}"; } > "$KD.t" || { rm -f "$KD.t"; return 1; }
if cmp -s "$KD.t" "$KD"; then rm -f "$KD.t"; else mv -f "$KD.t" "$KD"; fi; }
cname() { echo "$1" | grep -qE '^[A-Za-z0-9*][A-Za-z0-9.*-]{0,252}$'; }
ckey() { printf '%s' "$1" | tr -c 'A-Za-z0-9.-' '_'; }
cend() { e_=$(openssl x509 -enddate -noout -in "$1" 2>/dev/null | awk '{ sub(/^notAfter=/, ""); m = index("JanFebMarAprMayJunJulAugSepOctNovDec", $1); if (m % 3 == 1 && $2 ~ /^[0-9]+$/ && $3 ~ /^[0-9][0-9]:[0-9][0-9]:[0-9][0-9]$/ && $4 ~ /^[0-9][0-9][0-9][0-9]$/) { gsub(":", "", $3); printf "%s%02d%02d%s", $4, (m + 2) / 3, $2, $3 } }')
m_=$(date -r "$1" +%s 2>/dev/null); echo "${e_:-0} ${m_:-0}"; }
cnew() { b_=; bx_=; for f; do [ -f "$f" ] || continue; x_=$(cend "$f")
[ -n "$b_" ] && ! awk -v a="${x_% *}" -v b="${bx_% *}" -v c="${x_#* }" -v d="${bx_#* }" 'BEGIN { exit !(a + 0 > b + 0 || (a + 0 == b + 0 && c + 0 > d + 0)) }' && continue
b_=$f; bx_=$x_; done; [ -n "$b_" ] && echo "$b_"; }
cfile() { cnew "$P0/etc/ssl/acme/$1.crt" "$P0/etc/ssl/acme/$1.fullchain.crt" "$P0/etc/acme/${1}_ecc/$1.cer" "$P0/etc/acme/$1/$1.cer"; }
cget() { J=$(ubus call wrtfreedom certrenew '{"action":"get"}' 2>/dev/null); [ -n "$J" ]; }
jv() { v_=$(printf '%s' "$J" | jsonfilter -e "$1" 2>/dev/null | head -n 1); case "$v_" in ''|null|None) v_=- ;; esac; printf '%s' "$v_"; }
clist() { n_=$(printf '%s' "$J" | jsonfilter -e '@.certs[*].sec' 2>/dev/null | wc -l); i_=0
while [ $i_ -lt $n_ ]; do echo "$(jv "@.certs[$i_].dom") $(jv "@.certs[$i_].on") $(jv "@.certs[$i_].test") $(jv "@.certs[$i_].na") $(jv "@.certs[$i_].nb") $(jv "@.certs[$i_].due")"; i_=$((i_ + 1)); done; }
CK=$P0/etc/wrtfreedom/certok
certok() {
cname "$1" && [ -d "$P0/tmp" ] || return 1
exec 9>"$P0/tmp/wf-cron.certok.lock"; flock 9 2>/dev/null
cerrw "$1" >/dev/null
f=$(cfile "$1"); d=0; [ -n "$f" ] && d=$(date -r "$f" +%s 2>/dev/null); d=${d:-0}
awk -v n="$1" -v d="$d" '$1 == n && $2 == d { f = 1 } END { exit !f }' "$CK" 2>/dev/null && { exec 9>&-; return 0; }
mkdir -p "${CK%/*}"; { awk -v n="$1" '$1 != n' "$CK" 2>/dev/null; echo "$1 $d"; } > "$CK.t" && mv "$CK.t" "$CK"
exec 9>&-
k=$(ckey "$1"); rm -f "$P0/tmp/wf-cron.certmiss.$k"; clear "certstop.$k"
if [ "$2" = issued ]; then ev cert sys "📜 $1 ¦ $(t "Certificato emesso" "Certificate issued")"
else ev cert sys "📜 $1 ¦ $(t "Certificato rinnovato" "Certificate renewed")"; fi
[ "$2" = check ] || reg certrenew 0
clear "certrenew.$k" && ev cert_ok sys "📜 $1 ¦ $(t "Rinnovo di nuovo a posto" "Renewal working again")"
return 0
}
lday() { z_=$(date +%z 2>/dev/null); o_=0
case "$z_" in [+-][0-9][0-9][0-9][0-9]) h_=${z_#?}; m_=${h_#??}; h_=${h_%??}; o_=$(( (${h_#0} * 60 + ${m_#0}) * 60 )); [ "${z_%????}" = - ] && o_=$((-o_)) ;; esac
echo $(( ($1 + o_) / 86400 )); }
D4N=2; D4F=3
d4() { w_=$3; [ "$w_" -lt 0 ] && w_=0; [ "$1" -ge $D4N ] || [ "$2" -lt $((w_ / D4F)) ]; }
craise() { f_=$P0/tmp/wf-cron.certrenew.$1.f; [ -f "$f_" ] && [ "$(cat "$f_")" != "$2" ] && rm -f "$f_"; raise "certrenew.$1" || return 1; [ -z "$2" ] || echo "$2" > "$f_"; }
CE=$P0/etc/wrtfreedom/certerr.json
cerrw() { mkdir -p "${CE%/*}"; ucode -e 'let fs = require("fs"), f = ARGV[0], n = ARGV[1], c = ARGV[2], o = null;
	try { o = json(fs.readfile(f) ?? "{}"); } catch (e) {}
	if (type(o) != "object") o = {};
	let p = o[n], nw = !!c && (type(p) != "object" || p.c != c);
	if (c) { if (!nw && (p.msg ?? "") == ARGV[4]) exit(0); o[n] = { c: c, t: +ARGV[3], msg: length(ARGV[4]) ? ARGV[4] : null }; }
	else { if (p == null) exit(0); delete o[n]; }
	if (length(o)) { fs.writefile(f + ".t", sprintf("%J", o)); fs.rename(f + ".t", f); } else fs.unlink(f);
	if (nw) print("new");' "$CE" "$@" 2>/dev/null; }
cerrc() { ucode -e 'let o = null; try { o = json(require("fs").readfile(ARGV[0]) ?? "null"); } catch (e) {}
	let p = type(o) == "object" ? o[ARGV[1]] : null; if (type(p) == "object" && type(p.c) == "string") print(p.c + " " + (p.msg ?? ""));' "$CE" "$1" 2>/dev/null; }
cwhy() { case "$1" in
token) t "DuckDNS rifiuta il token: copialo da duckdns.org" "DuckDNS rejects the token: copy it from duckdns.org" ;;
notoken) t "Manca il token di DuckDNS" "The DuckDNS token is missing" ;;
net) t "Internet assente: riprovo stanotte" "No internet: retrying tonight" ;;
limit) t "Troppi tentativi: riprovo più tardi" "Too many attempts: retrying later" ;;
dns) t "Verifica DNS non riuscita" "DNS check failed" ;;
*) if [ -n "$2" ]; then printf '%s' "$2"; else t "Il router riprova stanotte" "The router retries tonight"; fi ;;
esac; }
certerr() {
cname "$1" && [ -d "$P0/tmp" ] || return 1
n_=$(date +%s); s_=$(date -d "@$((n_ - 300))" +%Y%m%d%H%M%S 2>/dev/null)
lr_=logread; [ -n "$P0" ] && [ -x "$P0/bin/logread" ] && lr_=$P0/bin/logread
G_=$("$lr_" 2>/dev/null | awk -v s="$s_" 'BEGIN { split("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec", M, " "); for (i = 1; i <= 12; i++) m[M[i]] = i }
		/ (hook|acme-acmesh)(\[[0-9]+\])?: / { if (s != "" && ($2 in m) && split($4, h, ":") == 3) { k = sprintf("%04d%02d%02d%02d%02d%02d", $5, m[$2], $3, h[1], h[2], h[3]); if (k "" < s "") next } print }' | tail -n 200)
gr_() { printf '%s\n' "$G_" | grep -qiE "$1"; }
c_=other; m_=
if gr_ 'invalid token' || { gr_ 'response=KO' && { gr_ duckdns || uci -q show acme 2>/dev/null | grep -q dns_duckdns; }; }; then c_=token
elif gr_ 'You must export variable'; then c_=notoken
elif gr_ 'Network unreachable|Could not resolve|Couldn.t connect|timed out'; then c_=net
elif gr_ 'rateLimited|too many'; then c_=limit
elif gr_ 'Incorrect TXT|NXDOMAIN|Verify error|Invalid status'; then c_=dns
else
m_=$(printf '%s\n' "$G_" | sed -E 's/^.* (hook|acme-acmesh)(\[[0-9]+\])?: //; s/^\[[^]]*\] *//')
e_=$(printf '%s\n' "$m_" | grep -iE 'err|fail|invalid|unable|cannot|denied|refused' | head -n 1)
[ -n "$e_" ] || e_=$(printf '%s\n' "$m_" | grep -v '^$' | tail -n 1)
m_=$(printf '%s' "$e_" | sed -E 's/[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}/***/g; s/([Tt][Oo][Kk][Ee][Nn]|[Tt][Xx][Tt][A-Za-z_]*)([=:] *)[^ &,;]*/\1\2***/g; s/[A-Za-z0-9_+\/-]{30,}={0,2}/***/g' | tr -d '"\\' | tr '\t' ' ' | tr -cd ' -~' | cut -c1-120 | sed 's/ *$//')
fi
exec 9>"$P0/tmp/wf-cron.certok.lock"; flock 9 2>/dev/null
r_=$(cerrw "$1" "$c_" "$n_" "$m_"); exec 9>&-
[ "$r_" = new ] && ev cert_fail sys "⚠️ $1 ¦ $(t "Rinnovo non riuscito" "Renewal failed") ¦ $(cwhy "$c_" "$m_")"
return 0
}
vpnres() {
case "$1" in
1) raise vpn && ev vpn_fail net "⚠️ $(t "Server VPN ¦ Spento: non si riaccende ¦ Controlla il router" "VPN Server ¦ Off: cannot restart it ¦ Check the router") ¦ $(t "Dal Controllo Automatico" "By Automatic Check")" ;;
0) clear vpn; ev vpn_fix net "🛡️ $(t "Server VPN ¦ Riacceso: era spento" "VPN Server ¦ Restarted: it was off") ¦ $(t "Dal Controllo Automatico" "By Automatic Check")" ;;
ok) clear vpn && ev vpn_ok net "🛡️ $(t "Server VPN ¦ Di nuovo a posto" "VPN Server ¦ Working again") ¦ $(t "Dal Controllo Automatico" "By Automatic Check")" ;;
esac
return 0
}
ddrun() { r_=$(uci -q get ddns.global.ddns_rundir); echo "$P0${r_:-/var/run/ddns}"; }
ddsecs() { uci -q -X show ddns 2>/dev/null | awk -F= -v I="$1" -v D="$([ -n "$1" ] && wf_dddef 2>/dev/null)" -v q="'" '{ n = split($1, a, "."); v = substr($0, length($1) + 2); gsub(q, "", v) }
	n == 2 && v == "service" { s[a[2]] = 1; o[++m] = a[2]; f[a[2]] = D } n == 3 && a[3] == "enabled" { e[a[2]] = v } n == 3 && a[3] == "interface" { f[a[2]] = v }
	END { for (i = 1; i <= m; i++) { k = o[i]; if (e[k] == "1" && (I == "" || f[k] == I)) print k } }'; }
ddwant() { s_=$(uci -q get "ddns.$1.ip_source"); v_=$(uci -q get "ddns.$1.use_ipv6")
case "${s_:-network}" in
network) n_=$(uci -q get "ddns.$1.ip_network"); k_=ipv4; [ "$v_" = 1 ] && k_=ipv6
[ -n "$n_" ] || { k6_=4; [ "$v_" = 1 ] && k6_=6; n_=$(wf_dddef $k6_ 2>/dev/null) || return 0; }
ifstatus "$n_" 2>/dev/null | jsonfilter -e "@[\"$k_-address\"][0].address" 2>/dev/null ;;
interface) d_=$(uci -q get "ddns.$1.ip_interface"); [ -n "$d_" ] || return 0
if [ "$v_" = 1 ]; then ip -6 addr show dev "$d_" scope global 2>/dev/null | sed -n 's/.*inet6 \([0-9a-fA-F:]*\)\/.*/\1/p' | head -n 1
else ip -4 addr show dev "$d_" 2>/dev/null | sed -n 's/.*inet \([0-9.]*\)\/.*/\1/p' | head -n 1; fi ;;
esac; }
ddnm() { n_=$(uci -q get "ddns.$1.lookup_host"); [ -n "$n_" ] || n_=$(uci -q get "ddns.$1.domain"); printf '%s' "${n_:-$1}"; }
DDUPD=$P0/usr/lib/ddns/dynamic_dns_updater.sh
ddup() { if [ -x "$DDUPD" ]; then ( "$DDUPD" -S "$1" -- start ) >/dev/null 2>&1 </dev/null & else "$P0/etc/init.d/ddns" restart >/dev/null 2>&1; fi; }
DDW=30; [ -n "$P0" ] && [ -n "$WF_DDWAIT" ] && DDW=$WF_DDWAIT
dddone() { u_=$(cat "$RD/$1.update" 2>/dev/null); [ -n "$u_" ] && [ "$u_" != "$2" ] && return 0; [ -n "$3" ] && [ "$(cat "$RD/$1.ip" 2>/dev/null)" = "$3" ]; }
ddwait() { i_=0
while :; do
m_=0; for x_ in $1; do s_=${x_%%|*}; r_=${x_#*|}; dddone "$s_" "${r_%%|*}" "${r_#*|}" || m_=1; done
[ $m_ = 0 ] && return 0; [ $i_ -ge $DDW ] && return 1; sleep 2; i_=$((i_ + 1))
done; }
ddforce() { RD=$(ddrun); rm -f "$RD/$1.update"; ddup "$1"; ddwait "$1||"; }
ddhow() { [ "$(ucode "$P0$W/wgx.uc" how ddns 2>/dev/null)" = svc ]; }
DDIF=180
ddresoon() { f_=$P0/tmp/wf-cron.ddnsre; w_=$(( $(date +%s) + DDIF )); d_=$(cat "$f_" 2>/dev/null)
case "$d_" in ''|*[!0-9]*) ;; *) [ "$d_" -le "$w_" ] && return 0 ;; esac
echo "$w_" > "$f_"; }
ddhear() { grep -qE '^[^#]*ifupdate[^#]*\)' "$P0/etc/hotplug.d/iface/95-ddns" 2>/dev/null; }
DDRE=600
ddchk() {
LK=$P0/tmp/wf-cron.ddnschk.lock
if ! mkdir "$LK" 2>/dev/null; then
n=$(date +%s); m=$(date -r "$LK" +%s 2>/dev/null || echo "$n")
[ $((n - m)) -lt 300 ] && return 0
rm -rf "$LK"; mkdir "$LK" 2>/dev/null || return 0
fi
ddchk1; rmdir "$LK" 2>/dev/null
return 0
}
ddchk1() {
AS=" $(ddsecs | tr '\n' ' ') "
for f in "$P0"/tmp/wf-cron.ddns.*.f "$P0"/tmp/wf-cron.ddnsold.*; do
[ -f "$f" ] || continue
b=${f##*/}; case "$b" in wf-cron.ddnsold.*) s=${b#wf-cron.ddnsold.} ;; *) s=${b#wf-cron.ddns.}; s=${s%.f} ;; esac
case "$AS" in *" $s "*) ;; *) rm -f "$f" ;; esac
done
F=$P0/tmp/wf-ddnsname.json; t0=$(date +%s)
ucode "$P0$W/svc.uc" name >/dev/null 2>&1
i=0; while [ $i -lt 30 ]; do [ "$(jsonfilter -i "$F" -e '@.t' 2>/dev/null)" -ge "$t0" ] 2>/dev/null && break; sleep 2; i=$((i + 1)); done
ddo=$(ucode -e 'let j = json(require("fs").readfile(ARGV[0]) ?? "null"); if (type(j) == "object") { print(int(+(j.t ?? 0)), j.cgnat ? " 1\n" : " 0\n");
		for (let x in j.list ?? []) { let s = "" + (x.id ?? x.sec); if (match(s, /^[A-Za-z0-9_]{1,64}$/) && match("" + x.why, /^[a-z]{1,8}$/)) print(s, " ", x.why, "\n"); } }' "$F" 2>/dev/null)
set -- $ddo
[ $# -ge 2 ] && [ "$1" -ge "$t0" ] 2>/dev/null || return 0
TF=$P0/tmp/wf-cron.ddnst; [ "$1" = "$(cat "$TF" 2>/dev/null)" ] && return 0; echo "$1" > "$TF"
RE=$P0/tmp/wf-cron.ddnsre; re=0
[ "$2" = 1 ] && { rm -f "$RE"; return 0; }
shift 2
while [ $# -ge 2 ]; do
s=$1; y=$2; shift 2
OF=$P0/tmp/wf-cron.ddnsold.$s; n=0; f=0; [ -f "$OF" ] && read -r n f < "$OF"
case "$n$f" in *[!0-9]*|'') n=0; f=0 ;; esac
case "$y" in
ok) rm -f "$OF"; clear "ddns.$s" && ev ddns_ok net "🛡️ $(ddnm "$s") ¦ $(t "Nome di casa a posto" "Home name working again") ¦ $(t "Dal Controllo Automatico" "By Automatic Check")" ;;
old) n=$((n + 1))
if [ $n -ge 3 ] && [ "$f" != 1 ]; then
f=1; echo "$n $f" > "$OF"; ddforce "$s"; r=$?; reg ddnscheck $r
if [ $r = 0 ]; then n=0
else raise "ddns.$s" && ev ddns_fail net "⚠️ $(ddnm "$s") ¦ $(t "Nome di casa non aggiornato" "Home name not updating") ¦ $(t "Dal Controllo Automatico" "By Automatic Check")"; fi
elif [ $n -ge 3 ]; then raise "ddns.$s" && ev ddns_fail net "⚠️ $(ddnm "$s") ¦ $(t "Nome di casa non aggiornato" "Home name not updating") ¦ $(t "Dal Controllo Automatico" "By Automatic Check")"
fi
echo "$n $f" > "$OF"
[ -f "$P0/tmp/wf-cron.ddns.$s.f" ] || re=1 ;;
*) echo "0 $f" > "$OF" ;;
esac
done
if [ $re = 1 ]; then echo $(( $(date +%s) + DDRE )) > "$RE"; else rm -f "$RE"; fi
return 0
}

B5=5g-led-bars; B5G=$P0/tmp/wf-leds.5gbars
b5on() { [ -x "$P0/etc/init.d/$B5" ] && ubus call service list "{\"name\":\"$B5\"}" 2>/dev/null | jsonfilter -e '@[*].instances[*].running' 2>/dev/null | grep -q true; }
b5fix() { uci -q show system 2>/dev/null | sed -n "s/^system\.wf_led_[A-Za-z0-9_]*\.sysfs='\([^']*5g:led[^']*\)'$/\1/p"; }
b5stop() { b5on || return 1; "$P0/etc/init.d/$B5" stop >/dev/null 2>&1; : > "$B5G"; }
b5start() {
[ -f "$B5G" ] && [ ! -f "$P0/tmp/wf-leds.save" ] && [ -z "$(b5fix)" ] || return 1
[ -x "$P0/etc/init.d/$B5" ] && "$P0/etc/init.d/$B5" start >/dev/null 2>&1
rm -f "$B5G"
}

A="$1"; X="$2"
case "$A" in
ledoff)	# salva lo stato di ogni spia (una volta) e le spegne; valore = spie da lasciare come sono, con la virgola (Spie Di Notte)
S=$P0/tmp/wf-leds.save
for l in $P0/sys/class/leds/*5g:led*; do
[ -d "$l" ] || continue
case ",$X," in *",${l##*/},"*) continue ;; esac
b5stop; break
done
for l in $P0/sys/class/leds/*; do
[ -d "$l" ] || continue
case ",$X," in *",${l##*/},"*) continue ;; esac
[ -f $S ] || echo "${l##*/}|$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$l/trigger")|$(cat "$l/brightness")" >> $S.t
echo none > "$l/trigger" 2>/dev/null; echo 0 > "$l/brightness" 2>/dev/null
done
[ -f $S.t ] && mv $S.t $S ;;
ledon)	# rimette lo stato salvato e le impostazioni LED del router (anche le spie spente per sempre); 5g-led-bars riparte
S=$P0/tmp/wf-leds.save
if [ -f $S ]; then
while IFS='|' read -r n tr b; do
[ -d "$P0/sys/class/leds/$n" ] || continue
echo "${tr:-none}" > "$P0/sys/class/leds/$n/trigger" 2>/dev/null
[ "${tr:-none}" = none ] && echo "${b:-0}" > "$P0/sys/class/leds/$n/brightness" 2>/dev/null
done < $S
rm -f $S
fi
[ -x $P0/etc/init.d/led ] && $P0/etc/init.d/led restart >/dev/null 2>&1
b5start ;;
ledbars) # barre spente per sempre (2.82), da ledset e all'accensione (health.uc boot, valore boot):
if [ "$X" = free ]; then
[ -f "$B5G" ] && [ -x "$P0/etc/init.d/$B5" ] && "$P0/etc/init.d/$B5" start >/dev/null 2>&1
rm -f "$B5G"; exit 0
fi
F=$(b5fix)
[ -n "$F" ] || { b5start; exit 0; }
if [ "$X" = boot ] && [ -x "$P0/etc/init.d/$B5" ]; then
n=12; [ -n "$P0" ] && n=1
while [ $n -gt 0 ] && ! b5on; do n=$((n - 1)); [ $n -gt 0 ] && sleep 10; done
fi
b5stop
for l in $F; do
[ -d "$P0/sys/class/leds/$l" ] || continue
echo none > "$P0/sys/class/leds/$l/trigger" 2>/dev/null; echo 0 > "$P0/sys/class/leds/$l/brightness" 2>/dev/null
done ;;
memfree) # rimedio «riserva» del Custode (custode.uc memcache). Caccia-memoria: niente sync (con rclone o aria2 che scrivono
MF=$P0/tmp/wf-memfree; MI=$P0/proc/meminfo; DC=$P0/proc/sys/vm/drop_caches
a0=$(awk '/^MemAvailable:/ { print $2; exit }' "$MI" 2>/dev/null)
( echo 3 > "$DC"; a1=$(awk '/^MemAvailable:/ { print $2; exit }' "$MI" 2>/dev/null)
echo "$(date +%s) $(( ${a1:-0} - ${a0:-0} ))" > "$MF" ) </dev/null >/dev/null 2>&1 & ;;
ntpsync) # client NTP del router: sysntpd (BusyBox), altrimenti chrony o ntpd
for s in sysntpd chronyd ntpd; do [ -x /etc/init.d/$s ] && /etc/init.d/$s enabled 2>/dev/null && { /etc/init.d/$s restart >/dev/null 2>&1; exit 0; }; done ;;
svc)	# riavvia un servizio di /etc/init.d
echo "$X" | grep -qE '^[A-Za-z0-9_.-]{1,40}$' && [ -x "/etc/init.d/$X" ] || { echo "servizio non valido"; exit 1; }
/etc/init.d/$X restart >/dev/null 2>&1 ;;
ifrestart) # riavvia un'interfaccia di rete
echo "$X" | grep -qE '^[A-Za-z0-9_]{1,32}$' && [ "$(uci -q get network.$X)" = interface ] || { echo "interfaccia non valida"; exit 1; }
wantmark "$X"; ifup "$X" ;;
wanup)	# 3.48 (19/11): servizi accesi legati alla linea, fermi perché all'avvio la linea non c'era («no wan devices» di banIP,
echo "$X" | grep -qE '^[A-Za-z0-9_.-]{1,32}$' || exit 1
ifstatus "$X" 2>/dev/null | jsonfilter -e '@.route[@.target="0.0.0.0"].mask' -e '@.route[@.target="::"].mask' 2>/dev/null | grep -qx 0 || exit 0
L=$P0/tmp/wf-wanup.lock
if ! mkdir "$L" 2>/dev/null; then [ -n "$(find "$L" -maxdepth 0 -mmin +2 2>/dev/null)" ] || exit 0; fi
trap 'rmdir "$L" 2>/dev/null' EXIT
for s in banip; do
b=$P0/etc/init.d/$s; [ -x "$b" ] && "$b" enabled 2>/dev/null || continue
case $s in
banip) uci -q show banip 2>/dev/null | grep -q "\.ban_enabled='1'$" || continue
st=$("$b" status 2>/dev/null | sed -n 's/^[[:space:]+]*status[[:space:]]*:[[:space:]]*\([A-Za-z]*\).*/\1/p' | head -n 1)
case "$st" in active|processing|running|paused) continue ;; esac ;;
esac
once wanup.$s 600 || continue
"$b" restart >/dev/null 2>&1 </dev/null
done ;;

signalcheck) # avvisa se il segnale del modem è sotto la soglia (RSRP, di serie −110 dBm)
r=$(ucode -e 'let M=loadfile("/usr/share/wrtfreedom/modem.uc")(),s=M.state().n;print(s.lte?.rsrp ?? s.nr?.rsrp ?? "")' 2>/dev/null)
[ -n "$r" ] || exit 0; lim=${X:--110}
r=${r%.*}
if [ "$r" -lt "$lim" ]; then once signal 7200 && ev signal net "🌐 $(t "Linea ¦ Segnale scarso" "Line ¦ Weak signal") ¦ $r dBm"; else unflag signal; fi ;;
modemreport) # Rapporto Modem come file al bot
mkdir -p /tmp/wf-tgfile && chmod 700 /tmp/wf-tgfile
f=/tmp/wf-tgfile/$(t Rapporto-Modem Modem-Report).txt
ucode $W/modemctl.uc report > "$f" 2>/dev/null
tgdoc "$f" "🌐 $(t "Rapporto Modem ¦ Lo stato del modem nel file" "Modem Report ¦ Modem status in the file")"; rm -f "$f" ;;
backup)	# Copia Automatica (Backup Al Bot): backup e invio sincroni, così il Registro scrive l'esito vero. Copia per Telegram
H=$(tr -c 'A-Za-z0-9_\n-' '-' < /proc/sys/kernel/hostname 2>/dev/null | head -n 1); H=${H:-router}
f=$P0/tmp/backup-$H-$(date +%Y%m%d)-$$.tar.gz; o=$P0/tmp/wf-tgdoc.json; T_=$o.$$; rm -f "$T_"
if [ -f "$P0$W/backup.sh" ]; then sh "$P0$W/backup.sh" create "$f" tg >/dev/null 2>&1; else ( umask 077; sysupgrade -b "$f" ) >/dev/null 2>&1; fi
c_="💾 Backup ¦ $(t "Copia di oggi pronta" "Today's copy ready") ¦ $(t "Password e chiavi leggibili" "Passwords and keys readable") ¦ $(t "Imposta la password nell'app" "Set a password in the app")"
[ -s "${f%.tar.gz}.wfbak" ] && { rm -f "$f"; f=${f%.tar.gz}.wfbak; c_="💾 Backup ¦ $(t "Copia cifrata di oggi pronta" "Today's encrypted copy ready")"; }
if [ ! -s "$f" ]; then echo '{"ok":false,"description":"backup non creato"}' > "$T_"
elif ! tgdoc "$f" "$c_" "$T_" && [ ! -s "$T_" ]; then echo '{"ok":false,"description":"bot non collegato o Telegram non raggiungibile"}' > "$T_"
fi
rm -f "$f"; [ -s "$T_" ] || echo '{"ok":false}' > "$T_"; mv -f "$T_" "$o"
if grep -q '"ok":true' "$o"; then clear backup; exit 0; fi
if [ "$X" != retry ]; then
RT=3600; [ -n "$P0" ] && [ -n "$WF_BAKRETRY" ] && RT=$WF_BAKRETRY
( sleep $RT; sh "$P0$W/cron.sh" backup retry ) </dev/null >/dev/null 2>&1 &
exit 1
fi
d=$(jsonfilter -i "$o" -e '@.description' 2>/dev/null | cut -c1-120)
raise backup && ev backup_fail sys "⚠️ Backup ¦ $(t "Copia automatica non riuscita" "Automatic copy failed")${d:+ ¦ $d}"
exit 1 ;;

vpncheck) # riattiva la VPN se è giù (non se è spenta apposta); 2.67: avvisi con il segno senza scadenza (vpnres), come il
i=$(wgif); [ -n "$i" ] || exit 0
[ "$(uci -q get network.$i.disabled)" = 1 ] && exit 0
[ "$(ifstatus "$i" 2>/dev/null | jsonfilter -e '@.autostart' 2>/dev/null)" = false ] && exit 0
ok() { isup "$i" || return 1; command -v wg >/dev/null || return 0; wg show "$i" >/dev/null 2>&1; }
ok && { vpnres ok; exit 0; }
logger -t wrtfreedom-cron "VPN $i giù, la riattivo"
wantmark "$i"; ifup "$i"; sleep 15
if ok; then vpnres 0; else vpnres 1; fi ;;
vpnwd)	# Controllo Del Server VPN (2.67, dal giro di wgx.uc tick): up <interfaccia> = ifup in un processo a parte con il
case "$X" in
up)	i=$3; echo "$i" | grep -qE '^[A-Za-z0-9_]{1,32}$' || exit 1
echo "$i" | grep -qE '^wgo(ut|[0-9]+)$' && exit 1
LK=$P0/tmp/wf-vpnwd.lock
if ! mkdir "$LK" 2>/dev/null; then
n=$(date +%s); m=$(date -r "$LK" +%s 2>/dev/null || echo "$n")
[ $((n - m)) -lt 120 ] && exit 0
rm -rf "$LK"; mkdir "$LK" 2>/dev/null || exit 0
fi
if [ "$(uci -q get network.$i.disabled)" = 1 ] || [ "$(ifstatus "$i" 2>/dev/null | jsonfilter -e '@.autostart' 2>/dev/null)" = false ]; then
rmdir "$LK"; exit 0
fi
logger -t wrtfreedom-cron "VPN $i giù, la riattivo"
wantmark "$i"; ifup "$i"; r=$?; rmdir "$LK"; exit $r ;;
fix) reg vpncheck 0; vpnres 0 ;;
fail) reg vpncheck 1; vpnres 1 ;;
ok) vpnres ok ;;
clr) clear vpn ;;
now) # Controlla Ora (2.68, vpnwd run in sottofondo): come vpncheck (spenta apposta = niente), con il blocco dell'ifup del
RF=$P0/tmp/wf-vpnwdrun.json
rs() { printf '{"t":%s,"state":"%s","fix":%s,"msg":"%s"}\n' "$(date +%s)" "$1" "$2" "$3" > "$RF.t" && mv "$RF.t" "$RF"; exit 0; }
i=$(wgif); [ -n "$i" ] || rs err false "$(t "Server VPN non configurato" "VPN Server not set up")"
if [ "$(uci -q get network.$i.disabled)" = 1 ] || [ "$(ifstatus "$i" 2>/dev/null | jsonfilter -e '@.autostart' 2>/dev/null)" = false ]; then
rs ok false "$(t "VPN spenta apposta: non la riaccendo" "VPN turned off on purpose: not restarting it")"
fi
vok() { isup "$i" || return 1; command -v wg >/dev/null || return 0; wg show "$i" >/dev/null 2>&1; }
vok && { vpnres ok; rs ok false "$(t "VPN a posto" "VPN working")"; }
LK=$P0/tmp/wf-vpnwd.lock; n=0
until mkdir "$LK" 2>/dev/null; do
m=$(date -r "$LK" +%s 2>/dev/null || echo 0)
if [ $(( $(date +%s) - m )) -ge 120 ]; then rm -rf "$LK"
elif [ $n -ge 10 ]; then rs err false "$(t "Il router la sta già riaccendendo" "The router is already restarting it")"
else sleep 2; n=$((n + 1)); fi
done
vok && { rmdir "$LK"; rs ok false "$(t "VPN a posto" "VPN working")"; }
logger -t wrtfreedom-cron "VPN $i giù, la riattivo (Controlla Ora)"
w=15; [ -n "$P0" ] && [ -n "$WF_VPNWAIT" ] && w=$WF_VPNWAIT
wantmark "$i"; ifup "$i"; rmdir "$LK"; sleep "$w"
if vok; then rm -f /tmp/wf-vpnwd.json; reg vpncheck 0 n; vpnres 0; rs ok true "$(t "VPN riaccesa" "VPN back on")"
else reg vpncheck 1 n; vpnres 1; rs err false "$(t "La VPN non si riaccende" "The VPN does not come back on")"; fi ;;
*) exit 1 ;;
esac ;;
ddnscheck) # IP della linea cambiato: i servizi DDNS si aggiornano subito. 2.68 (docs/v2/controllo-nome.md): ddnscheck
[ -x "$P0/etc/init.d/ddns" ] || exit 0
[ -z "$X" ] || echo "$X" | grep -qE '^[A-Za-z0-9_.-]{1,32}$' || exit 1
RD=$(ddrun); U=; IP=; LN=
for s in $(ddsecs "$X"); do
w=$(ddwant "$s")
if [ -n "$w" ]; then
[ "$(cat "$RD/$s.ip" 2>/dev/null)" = "$w" ] || [ "$(cat "$P0/tmp/wf-cron.ddnsw.$s" 2>/dev/null)" = "$w" ] && continue
IP=${IP:-$w}
elif [ -z "$X" ]; then
[ -n "$LN" ] || { dev=$(ip -4 route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n 1)
LN=$(ip -4 addr show dev "$dev" 2>/dev/null | sed -n 's/.*inet \([0-9.]*\).*/\1/p' | head -n 1); LN=${LN:--}; }
[ "$LN" != - ] && [ "$(cat "$P0/tmp/wf-cron.ddnsip" 2>/dev/null)" != "$LN" ] || continue
IP=${IP:-$LN}
fi
U="$U $s|$(cat "$RD/$s.update" 2>/dev/null)|$w"
ddup "$s"
done
[ -n "$LN" ] && [ "$LN" != - ] && echo "$LN" > "$P0/tmp/wf-cron.ddnsip"
[ -n "$U" ] || exit 0
[ "$3" = q ] || ( ucode "$P0$W/svc.uc" ip ) >/dev/null 2>&1 </dev/null &	# storico dei cambi di IP (2.53)
ddwait "$U"; r=$?
for x in $U; do s=${x%%|*}; y=${x#*|}; w=${y#*|}; [ -n "$w" ] && dddone "$s" "${y%%|*}" "" && echo "$w" > "$P0/tmp/wf-cron.ddnsw.$s"; done
[ $r = 0 ] || exit 1
[ "$3" = q ] || ev ddns net "🌐 $(t "Nome Di Casa ¦ Nomi aggiornati ¦ Nuovo IP" "Home Name ¦ Names updated ¦ New IP")${IP:+ $IP}" ;;
ddnsforce) # aggiornamento forzato di tutti i servizi DDNS accesi (2.68, docs/v2/controllo-nome.md: per un comando del bot
[ -x "$P0/etc/init.d/ddns" ] || { echo "⚠️ $(t "DDNS non installato" "DDNS not installed")"; exit 1; }
RD=$(ddrun); U=; SS=$(ddsecs)
[ -n "$SS" ] || { echo "⚠️ $(t "Nessun nome DDNS acceso" "No DDNS name turned on")"; exit 1; }
l=$(rlast ddnscheck n); n=$(date +%s)
if [ -n "$l" ] && [ $((n - l)) -lt 300 ] && [ $((n - l)) -ge 0 ]; then
m=$(( (300 - (n - l) + 59) / 60 )); w=$(t minuti minutes); [ $m = 1 ] && w=$(t minuto minute)
echo "⚠️ $(t "Aggiornato da poco: riprova tra" "Updated recently: try again in") $m $w"; exit 1
fi
for s in $SS; do U="$U $s||"; rm -f "$RD/$s.update"; ddup "$s"; done
[ -n "$P0" ] && [ -n "$WF_DDWAIT" ] || DDW=20
ddwait "$U"; rc=0
for x in $U; do
s=${x%%|*}
if dddone "$s" "" ""; then
ip=$(cat "$RD/$s.ip" 2>/dev/null); [ -n "$ip" ] || ip=$(ddwant "$s")
echo "✅ $(ddnm "$s") → ${ip:-?}"
else
rc=1; m=$(t "nessuna conferma in 40 s" "no confirmation in 40 s")
case "$(uci -q get "ddns.$s.ip_source")" in ''|network|interface) [ -n "$(ddwant "$s")" ] || m=$(t "la linea non ha un IP" "the line has no IP") ;; esac
echo "⚠️ $(ddnm "$s"): $(t "non aggiornato" "not updated") ($m)"
fi
done
reg ddnscheck $rc n
exit $rc ;;
ddnswd) # Controllo Del Nome Di Casa (2.68, docs/v2/controllo-nome.md): il nome lo aggiorna ddns-scripts; il pacchetto
case "$X" in
if) # dal gancio iface/90-wrtfreedom (event.sh) con ifupdate e IFUPDATE_ADDRESSES: sull'interfaccia di un servizio DDNS
i=$3; echo "$i" | grep -qE '^[A-Za-z0-9_.-]{1,32}$' || exit 1
[ -x "$P0/etc/init.d/ddns" ] && [ -n "$(ddsecs "$i")" ] || exit 0
( ucode "$P0$W/svc.uc" ip ) >/dev/null 2>&1 </dev/null &
ddhow || exit 0
ddresoon
[ "$4" = up ] && exit 0
ddhear && exit 0
exec sh "$0" ddnscheck "$i" q ;;
chg) # dal giro di notify.sh: <sez>.ip (IP registrato da ddns-scripts) cambiato, chiunque abbia aggiornato: «Nome
s=$3; echo "$s" | grep -qE '^[A-Za-z0-9_]{1,64}$' || exit 1
ddhow || exit 0
ip=$(cat "$(ddrun)/$s.ip" 2>/dev/null)
[ -n "$ip" ] && ev ddns net "🌐 $(ddnm "$s") ¦ $(t "Nome di casa aggiornato" "Home name updated") ¦ $(t "Nuovo IP" "New IP") $ip"
ddchk ;;
day) # controllo del giorno (dal giro di notify.sh; una volta al giorno anche se il giro riparte; force = di nuovo oggi)
F=$P0/tmp/wf-cron.ddnsday; d=$(date +%Y%m%d)
[ "$3" != force ] && [ "$(cat "$F" 2>/dev/null)" = "$d" ] && exit 0
echo "$d" > "$F"
ddhow || exit 0
ddchk ;;
re) # ricontrollo dopo un old (dal giro di notify.sh): passata l'ora scritta da ddchk1 in /tmp/wf-cron.ddnsre, una volta
F=$P0/tmp/wf-cron.ddnsre; [ -f "$F" ] || exit 0
read -r d < "$F"
case "$d" in ''|*[!0-9]*) rm -f "$F"; exit 0 ;; esac
[ "$(date +%s)" -ge "$d" ] || exit 0
rm -f "$F"
ddhow || exit 0
ddchk ;;
d5) # impostazione assente (D5, dal giro di notify.sh): ddnswd align; rpcd che non risponde = di nuovo al giro dopo
ubus -t 10 call wrtfreedom ddnswd '{"action":"align"}' >/dev/null 2>&1 || rm -f "$P0/tmp/wf-ddnswd.d5" ;;
clr) # controllo spento (dal giro di notify.sh): segni e conti tolti senza avviso
rm -f "$P0"/tmp/wf-cron.ddns.*.f "$P0"/tmp/wf-cron.ddnsold.* "$P0/tmp/wf-cron.ddnst" "$P0/tmp/wf-cron.ddnsre" ;;
*) exit 1 ;;
esac ;;
certrenew) # Rinnovo Dei Certificati adesso (attività pronta; 2.66: n = Rinnova Ora di certrenew run, esito in
R=$P0/tmp/wf-certrun.json
st() { [ "$X" = n ] || return 0; printf '{"t":%s,"state":"%s","msg":"%s"}\n' "$(date +%s)" "$1" "$2" > "$R.t" && mv "$R.t" "$R"; }
fin() { if [ "$1" = 0 ]; then st ok "$2"; else st err "$2"; fi; [ "$X" = n ] && reg certrenew "$1" n; echo "$2"; exit "$1"; }
[ -x "$P0/etc/init.d/acme" ] || fin 1 "$(t "Certificati non installati" "Certificates not installed")"
st run ""
cget; c=start; [ "$(jv @.renew)" = true ] && c=renew
now=$(date +%s); B=; E=; set -f; L=$(clist); OI=$IFS; IFS='
'
for l in $L; do
IFS=$OI; set -- $l
[ "$2" = true ] && cname "$1" || continue
f=$(cfile "$1"); m=0; [ -n "$f" ] && m=$(date -r "$f" +%s 2>/dev/null)
B="$B $1|${m:-0}"
case "$6" in *[!0-9]*) [ -z "$f" ] && E="$E $1" ;; *) { [ -z "$f" ] || [ "$now" -ge "$6" ]; } && E="$E $1" ;; esac
done
IFS=$OI
"$P0/etc/init.d/acme" $c >/dev/null 2>&1; rc=$?
i=0; while [ $i -lt 450 ]; do
case "$(ubus call service list '{"name":"acme"}' 2>/dev/null | jsonfilter -e '@.acme.instances[*].running' 2>/dev/null)" in *true*) sleep 2; i=$((i + 1)) ;; *) break ;; esac
done
nd=0; er=0
for e in $rc $(ubus call service list '{"name":"acme"}' 2>/dev/null | jsonfilter -e '@.acme.instances[*].exit_code' 2>/dev/null); do
case "$e" in 0|''|*[!0-9]*) ;; 2) nd=1 ;; *) [ "$er" = 0 ] && er=$e ;; esac
done
rc=$er
ok=; bad=
for b in $B; do
D=${b%|*}; f=$(cfile "$D"); m=0; [ -n "$f" ] && m=$(date -r "$f" +%s 2>/dev/null)
if [ "${m:-0}" -gt "${b##*|}" ]; then ok="$ok $D"; else case " $E " in *" $D "*) bad="$bad $D" ;; esac; fi
done
set +f
[ -n "$bad" ] && [ $nd = 0 ] && fin 1 "$(t "Rinnovo non riuscito" "Renewal failed"):$bad"
[ "$rc" = 0 ] || fin "$rc" "$(t "Rinnovo non riuscito" "Renewal failed") ($(t errore error) $rc)"
[ -n "$ok" ] && fin 0 "$(t "Certificati rinnovati" "Certificates renewed"):$ok"
fin 0 "$(t "Nessun certificato da rinnovare" "No certificate to renew")" ;;
certok) # rinnovo riuscito (2.66, gancio /etc/hotplug.d/acme/91-wrtfreedom con il nome del certificato e ACTION)
certok "$X" "$([ "$3" = issued ] && echo issued)" || exit 1 ;;
certerr) # rinnovo non riuscito (3.22, gancio 91 con ACTION <op>-failed): causa vera in certerr.json e nell'avviso
certerr "$X" || exit 1 ;;
certcheck) # Rinnovo Dei Certificati (2.66): una volta al giorno dalle 01:30 (giro di notify.sh, niente riga nel crontab;
[ -x "$P0/etc/init.d/acme" ] || exit 0
now=$(date +%s); dn=$(lday "$now"); F=$P0/tmp/wf-cron.certday
[ "$X" != force ] && [ "$(cat "$F" 2>/dev/null)" = "$dn" ] && exit 0
echo "$dn" > "$F"
cget || exit 0
how=$(jv @.how)
rc=0; any=0; ON=' '; set -f; L=$(clist); OI=$IFS; IFS='
'
for l in $L; do
IFS=$OI; set -- $l; D=$1; NA=$4; NB=$5; DU=$6
[ "$2" = true ] && cname "$D" || continue
ON="$ON$(ckey "$D") "
f=$(cfile "$D") || continue
m=$(date -r "$f" +%s 2>/dev/null) || continue
any=1; k=$(ckey "$D"); r=$(awk -v n="$D" '$1 == n { print $2 }' "$CK" 2>/dev/null)
if [ -z "$r" ]; then
mkdir -p "${CK%/*}"; echo "$D $m" >> "$CK"
elif [ "$m" -gt "$r" ]; then
certok "$D" check
[ -f "$P0/etc/hotplug.d/acme/90-wrtfreedom" ] && sh "$0" certadg "$D" >/dev/null 2>&1 </dev/null
continue
fi
[ "$3" = true ] && continue
case "$NA$NB$DU" in *[!0-9]*) continue ;; esac
MF=$P0/tmp/wf-cron.certmiss.$k
[ "$now" -gt $((DU + 86400)) ] || { rm -f "$MF"; clear "certstop.$k"; continue; }
pd=; pn=0; [ -f "$MF" ] && read -r pd pn < "$MF"
case "$pn" in ''|*[!0-9]*) pn=0 ;; esac
if [ "$pd" = "$dn" ]; then n=$pn; else n=$((pn + 1)); echo "$dn $n" > "$MF"; fi
[ "$how" = - ] || clear "certstop.$k"
left=$((NA - now))
if [ $left -gt 0 ]; then w="$(t "Scade tra" "Expires in") $(((left + 86399) / 86400)) $(t giorni days)"; else w=$(t "Certificato scaduto" "Certificate expired"); fi
cw=; e=$(cerrc "$D"); [ -n "$e" ] && cw=$(cwhy "${e%% *}" "${e#* }")
if d4 "$n" "$left" $((NA - DU)); then
rc=1
if [ "$how" = - ]; then craise "$k" stop && ev cert_fail sys "⚠️ $D ¦ $(t "Rinnovo automatico fermo" "Automatic renewal stopped") ¦ $w"
else craise "$k" "" && ev cert_fail sys "⚠️ $D ¦ $(t "Rinnovo non riuscito" "Renewal failed") ¦ ${cw:-$w}"; fi
elif [ "$how" = - ]; then
raise "certstop.$k" && ev cert_stop sys "📜 $D ¦ $(t "Rinnovo automatico fermo" "Automatic renewal stopped") ¦ $w"
elif [ "$pd" != "$dn" ]; then
ev cert_wait sys "📜 $D ¦ $(t "Rinnovo rimandato" "Renewal postponed") ¦ ${cw:-$(t "Il router riprova stanotte" "The router retries tonight")}"
fi
done
IFS=$OI; set +f
sh "$0" adgfix >/dev/null 2>&1 </dev/null
for f in "$P0"/tmp/wf-cron.certrenew.*.f "$P0"/tmp/wf-cron.certstop.*.f "$P0"/tmp/wf-cron.certmiss.*; do
[ -f "$f" ] || continue
b=${f##*/}; case "$b" in wf-cron.certmiss.*) k=${b#wf-cron.certmiss.} ;; *) k=${b#wf-cron.cert*.}; k=${k%.f} ;; esac
case "$ON" in *" $k "*) ;; *) rm -f "$f" ;; esac
done
[ $any = 1 ] && reg certrenew $rc
exit $rc ;;
align) # riallineamento (2.66: fine di install.sh, svc.uc boot dopo l'orologio, certrenew on con «started»): riga di acme
if [ -x "$P0/etc/init.d/acme" ]; then
s=$(ubus call wrtfreedom certrenew '{"action":"align"}' 2>/dev/null | jsonfilter -e '@.start' 2>/dev/null)
if [ "$s" = true ]; then
[ "$X" = started ] || "$P0/etc/init.d/acme" start >/dev/null 2>&1
ubus call wrtfreedom certrenew '{"action":"align","write":true}' >/dev/null 2>&1
fi
fi
ubus call wrtfreedom vpnwd '{"action":"align"}' >/dev/null 2>&1
ubus call wrtfreedom ddnswd '{"action":"align"}' >/dev/null 2>&1
adghook && ubus call wrtfreedom certadg '{"action":"on"}' >/dev/null 2>&1
sh "$0" adgfix >/dev/null 2>&1 </dev/null
CF=$P0/etc/crontabs/root
if [ ! -f "${WF_BAKDIR:-$P0/etc/wrtfreedom/bak}/cron/id" ] && grep -qE '\{ ubus call wrtfreedom tgdoc; \} .* #wrtfreedom .*"a": *"backup"' "$CF" 2>/dev/null; then
sed -i -E '/ #wrtfreedom .*"a": *"backup"/ s#\{ ubus call wrtfreedom tgdoc; \}#{ sh /usr/share/wrtfreedom/cron.sh backup; }#' "$CF"
[ -n "$P0" ] || /etc/init.d/cron restart >/dev/null 2>&1
fi ;;
certadg) # certificato del nome di AdGuard Home (acme) nei percorsi di AdGuard, solo se è cambiato (2.65,
if [ -z "$X" ] && adghook && once certadghook 86400; then
ubus call wrtfreedom certadg '{"action":"on"}' >/dev/null 2>&1
[ -f "$P0/etc/hotplug.d/acme/90-wrtfreedom" ] && exit 0
fi
F=0; [ "$3" = primo ] && F=1
adgcfg || { [ $F = 1 ] && echo "err=file di AdGuard Home non trovato"; exit $F; }
[ $F = 1 ] && { N=$X; adgin || { C=${D}tls/fullchain.crt; K=${D}tls/privkey.key; }; }
[ -n "$N" ] && [ "${C#/}" != "$C" ] && [ "${K#/}" != "$K" ] || exit 0
[ -z "$X" ] || [ "$X" = "$N" ] || exit 0
set --; for d in "$P0/etc/ssl/acme" "$P0/etc/acme/$N" "$P0/etc/acme/${N}_ecc"; do
for f in "$d/$N.fullchain.crt" "$d/fullchain.cer"; do [ -f "$f" ] && [ -f "$d/$N.key" ] && set -- "$@" "$f"; done
done
SC=; [ $# -gt 0 ] && SC=$(cnew "$@"); SK=${SC%/*}/$N.key
[ -n "$SC" ] && [ -f "$SK" ] || { [ $F = 1 ] && echo "err=certificato di $N non trovato"; exit $F; }
exec 8>"$P0/tmp/wf-cron.certadg.lock"; flock 8 2>/dev/null
MS=0; [ $F = 0 ] && { [ -f "$C" ] && [ -f "$K" ] || MS=1; }
[ $MS = 1 ] && ! adgin && exit 0
O=$(ls -ldn "${Y%/*}" 2>/dev/null | awk '{ print $3 ":" $4 }')
own() { [ -z "$O" ] || [ "$O" = : ] || chown -h "$O" "$1"; }
if cmp -s "$SC" "$C" && cmp -s "$SK" "$K"; then
[ $F = 1 ] && { [ -L "$K" ] || [ -L "$C" ] || { own "$K" && chmod 600 "$K" && own "$C" && chmod 644 "$C"; } || { echo "err=permessi del certificato non sistemati"; exit 1; }; echo "cert=$C"; echo "key=$K"; ( adgkeep "$C" "$K" ); }
unflag certadg; exit 0
fi
adgin || { [ $F = 1 ] && echo "err=cartella di AdGuard Home non adatta"; exit $F; }
prep() { pd=${2%/*}; [ ! -L "$pd" ] && { [ -d "$pd" ] || { ( umask 022; mkdir -p "$pd" ) && own "$pd"; }; } && ( umask 077; cp -L "$1" "$2" ) && chmod "$3" "$2" && own "$2"; }
TK=${K%/*}/.${K##*/}.wf$$; TC=${C%/*}/.${C##*/}.wf$$; nw=1
{ [ -e "$TK" ] || [ -L "$TK" ] || [ -e "$TC" ] || [ -L "$TC" ]; } && nw=0
if ! { [ $nw = 1 ] && prep "$SK" "$TK" 600 && prep "$SC" "$TC" 644 && mv -f "$TK" "$K" && mv -f "$TC" "$C"; }; then
[ $nw = 1 ] && rm -f "$TK" "$TC"
[ $F = 1 ] && { echo "err=copia del certificato non riuscita"; exit 1; }
once certadg 604800 && ev cert_fail sys "⚠️ $N ¦ $(t "Non copiato in AdGuard Home" "Not copied to AdGuard Home") ¦ $(t "Usa ancora quello di prima" "Still uses the previous one")"
reg certadg 1
exit 1
fi
unflag certadg
( adgkeep "$C" "$K" )
[ $F = 1 ] && { ev cert sys "📜 $N ¦ $(t "Aggiornato in AdGuard Home" "Updated in AdGuard Home")" >/dev/null 2>&1; echo "cert=$C"; echo "key=$K"; exit 0; }
reg certadg 0
s=$(adginit); J=; [ -n "$s" ] && J=$(ubus call service list "{\"name\":\"$s\"}" 2>/dev/null)
B=$(echo "$J" | jsonfilter -e '@[*].instances[*].command[0]' 2>/dev/null | head -n 1)
P=$(echo "$J" | jsonfilter -e '@[*].instances[*].pid' 2>/dev/null | head -n 1)
[ -n "$P" ] || { J=; P=$(pidof AdGuardHome 2>/dev/null | cut -d ' ' -f 1); [ -n "$P" ] && B=$(readlink "/proc/$P/exe"); }
v=; case "${B##*/}" in [Aa]d[Gg]uard[Hh]ome) v=$("$B" --version 2>/dev/null | sed -n 's/.*version v\{0,1\}\([0-9]\{1,9\}\)\.\([0-9]\{1,9\}\).*/\1 \2/p' | head -n 1) ;; esac
set -- $v
if [ -z "$P" ]; then :
elif [ $MS = 1 ] && [ -n "$s" ]; then "$P0/etc/init.d/$s" restart >/dev/null 2>&1
elif [ -n "$2" ] && { [ "$1" -gt 0 ] || [ "$2" -ge 102 ]; } && { { [ -n "$J" ] && ubus call service signal "{\"name\":\"$s\",\"signal\":1}" >/dev/null 2>&1; } || kill -HUP "$P" 2>/dev/null; }; then :
elif [ -n "$s" ]; then "$P0/etc/init.d/$s" restart >/dev/null 2>&1
fi
if [ $MS = 1 ]; then ev cert sys "📜 $N ¦ $(t "Rimesso in AdGuard Home" "Restored in AdGuard Home") ¦ $(t "Il file mancava" "The file was missing")"
else ev cert sys "📜 $N ¦ $(t "Aggiornato in AdGuard Home" "Updated in AdGuard Home")"; fi ;;
adgfix) # riparazione del certificato di AdGuard (cron.sh certcheck di notte e align all'avvio): con il certificato acceso
( adgkeep )
adgon && adgcfg && adgin && [ -n "$N" ] && [ "${C#/}" != "$C" ] && [ "${K#/}" != "$K" ] || exit 0
[ -f "$C" ] && [ -f "$K" ] && exit 0
exec sh "$0" certadg "$N" ;;
adgkeep) adgkeep ;;	# install.sh: percorsi di AdGuard nel keep.d del pacchetto
adgrestart) s=$(adginit); [ -n "$s" ] && /etc/init.d/$s restart >/dev/null 2>&1 ;;
adgpause) quick adg_off ;;
adgon) quick adg_on ;;
cloudoff) ubus call wrtfreedom cloud '{"act":"pause","until":0,"kind":"sched"}' >/dev/null 2>&1 ;;
cloudon) ubus call wrtfreedom cloud '{"act":"pause","do":"resume","kind":"sched"}' >/dev/null 2>&1 ;;
vpnoff) sh $W/event.sh act vpn_off ;;
vpnon) sh $W/event.sh act vpn_on ;;
vpnsvcon) ubus call wrtfreedom vpnout '{"action":"onoff","on":true}' >/dev/null 2>&1 ;;
vpnsvcoff) ubus call wrtfreedom vpnout '{"action":"onoff","on":false}' >/dev/null 2>&1 ;;
vpnsvcnext) ucode $W/vpnctl.uc rotate ;;
vpnsvcresume) # fine della Pausa Del Client VPN (2.52, da notify.sh): tornano accesi i collegamenti accesi prima
ubus call wrtfreedom vpnout '{"action":"resume"}' >/dev/null 2>&1 ;;
wgexp) ucode $W/wgx.uc exp >/dev/null 2>&1 ;;
wgpeeron|wgpeeroff)
echo "$X" | grep -qE '^[A-Za-z0-9_]{1,40}$' || { echo "dispositivo non valido"; exit 1; }
a=resume; [ "$A" = wgpeeroff ] && a=pause
ubus call wrtfreedom wgpeer "{\"action\":\"$a\",\"id\":\"$X\"}" >/dev/null 2>&1 ;;
guestoff) quick guest_off ;;
gueston) quick guest_on ;;
guestpwd) # password nuova della rete ospiti (subito se è spenta, altrimenti quando si spegne)
ubus call wrtfreedom wifiguest '{"action":"rot"}' >/dev/null 2>&1
mkdir -p /tmp/wf-batt; date +%s > /tmp/wf-batt/guestpwd ;;	# battito: l'attività è partita (prova di fumo, Custode)
guestend) # ospiti a tempo scaduti (da notify.sh)
ubus call wrtfreedom wifiguest '{"action":"end"}' >/dev/null 2>&1 ;;
wifichan) # Canale Automatico di notte per le radio scelte nell'app (mai canali DFS)
ucode $W/wifi.uc night >/dev/null 2>&1
mkdir -p /tmp/wf-batt; date +%s > /tmp/wf-batt/wifichan ;;	# battito: l'attività è partita (prova di fumo, Custode)
txlow|txnorm) # Potenza Di Notte: subito con iw (niente riavvio, niente scritture); txnorm senza valore = quella della configurazione
command -v iw >/dev/null || exit 0
if [ -n "$X" ] || [ "$A" = txlow ]; then
echo "$X" | grep -qE '^[0-9]{1,2}$' && [ "$X" -ge 1 ] && [ "$X" -le 30 ] || { echo "potenza non valida (1…30 dBm)"; exit 1; }
fi
if [ "$A" = txlow ]; then echo "$X" > /tmp/wf-txlow.$$ && mv /tmp/wf-txlow.$$ /tmp/wf-txlow; else rm -f /tmp/wf-txlow; fi
S=$(ubus call network.wireless status 2>/dev/null)
for r in $(uci -q show wireless | sed -n "s/^wireless\.\([A-Za-z0-9_]*\)=wifi-device$/\1/p"); do
i=$(echo "$S" | jsonfilter -e "@.$r.interfaces[0].ifname" 2>/dev/null); [ -n "$i" ] && [ -d "/sys/class/net/$i" ] || continue
if [ "$A" = txlow ] || [ -n "$X" ]; then v="fixed ${X}00"
else p=$(uci -q get wireless.$r.txpower); case "$p" in ''|*[!0-9]*) v=auto ;; *) v="fixed ${p}00" ;; esac; fi
iw dev "$i" set txpower $v 2>/dev/null
done ;;
txradio) # 2.64 una radio sola (wifinet, Assistente IA): la potenza della configurazione subito con iw, senza riavvio; radio
command -v iw >/dev/null && echo "$X" | grep -qE '^[A-Za-z0-9_]{1,32}$' || { wifi reload; exit 0; }
i=$(ubus call network.wireless status 2>/dev/null | jsonfilter -e "@.$X.interfaces[0].ifname" 2>/dev/null); [ -n "$i" ] && [ -d "/sys/class/net/$i" ] || { wifi reload; exit 0; }
p=$(uci -q get wireless.$X.txpower); case "$p" in ''|*[!0-9]*) v=auto ;; *) v="fixed ${p}00" ;; esac
iw dev "$i" set txpower $v 2>/dev/null ;;
dnsflush) # DNS del router: dnsmasq, altrimenti unbound o smartdns
for s in dnsmasq unbound smartdns; do [ -x /etc/init.d/$s ] && /etc/init.d/$s enabled 2>/dev/null && /etc/init.d/$s restart >/dev/null 2>&1; done ;;

block|unblock) mac "$X" || { echo "dispositivo non valido"; exit 1; }; quick "$A" "$(echo "$X" | tr 'A-F' 'a-f')" ;;
wol)	# accende un dispositivo con Wake-on-LAN
mac "$X" || { echo "dispositivo non valido"; exit 1; }
I=$(lanbr); [ -n "$I" ] || { echo "rete di casa non trovata"; exit 1; }
if command -v etherwake >/dev/null; then etherwake -i "$I" "$X"
elif command -v ether-wake >/dev/null; then ether-wake -i "$I" "$X"
else echo "manca etherwake"; exit 1; fi ;;

spacecheck) # memoria del router quasi piena (di serie la soglia «Quasi Pieno» di Salute Del Router)
[ "$(uci -q get wrtfreedom.health.al_disk)" = 0 ] || exit 0	# Avvisi Di Salute accesi: l'avviso lo manda già health.uc
m=/overlay; grep -q " /overlay " /proc/mounts || m=/	# x86 o router con disco: niente overlay
p=$(df "$m" 2>/dev/null | awk 'NR==2{gsub("%","",$5);print $5}'); [ -n "$p" ] || exit 0; lim=${X:-$(hth disk)}; [ -n "$lim" ] || exit 0
if [ "$p" -ge "$lim" ]; then once space 43200 && ev space sys "🩺 Router ¦ $(t "Spazio quasi pieno" "Storage almost full") ¦ $((100 - p))% $(t libero free)"; else unflag space; fi ;;
tempcheck) # temperatura più alta dei sensori del router (di serie la soglia «Molto Alta» di Salute Del Router)
[ "$(uci -q get wrtfreedom.health.al_temp)" = 0 ] || exit 0	# Avvisi Di Salute accesi: l'avviso lo manda già health.uc

m=0; for z in /sys/class/thermal/thermal_zone*/temp; do [ -f "$z" ] || continue; v=$(cat "$z" 2>/dev/null); case "$v" in ''|*[!0-9]*) continue ;; esac; v=$((v / 1000)); [ $v -gt $m ] && m=$v; done
[ $m -gt 0 ] || exit 0; lim=${X:-$(hth tempbad)}; [ -n "$lim" ] || exit 0
if [ $m -ge "$lim" ]; then once temp 7200 && ev temp sys "🩺 Router ¦ $(t "Molto caldo" "Very hot") ¦ $m °C"; else unflag temp; fi ;;

updcheck) sh $W/upd.sh notify >/dev/null 2>&1 ;;
pkgupd) sh $W/upd.sh safe tg >/dev/null 2>&1 ;;	# con copia e ritorno, come l'app
pkglist) if command -v apk >/dev/null; then apk update >/dev/null 2>&1; else opkg update >/dev/null 2>&1; fi ;;
trafficsave) command -v nlbw >/dev/null && nlbw -c commit >/dev/null 2>&1 ;;

sqmon) sh $W/sqmctl.sh on >/dev/null ;;
sqmoff) sh $W/sqmctl.sh off >/dev/null ;;
sqmp)	# profilo per orario (righe # wf:sqmp_<id>, metodo sqmsched)
echo "$X" | grep -qE '^[a-z0-9]{1,12}$' || { echo "profilo non valido"; exit 1; }
[ "$(uci -q get wrtfreedom.sqmp_$X)" = sqmp ] || exit 0
[ "$(uci -q get wrtfreedom.sqmp_$X.enabled)" = 0 ] && exit 0
sh $W/sqmctl.sh prof "$X" >/dev/null ;;
hb)	# richiesta all'indirizzo scelto (riga # wf:hb): l'indirizzo resta in uci, a curl arriva da stdin (mai nei processi)
U=$(uci -q get wrtfreedom.hb.url); [ -n "$U" ] || exit 0
echo "$U" | grep -qE "^https?://[^ '\"\]+$" || exit 1
command -v curl >/dev/null || exit 1
c=$(printf 'url = "%s"\n' "$U" | curl -s -o /dev/null -m 15 --retry 2 -w '%{http_code}' -K - 2>/dev/null)
c=$(echo "$c" | tr -cd 0-9 | head -c 3 | sed 's/^0*//'); [ -n "$c" ] || c=0
ok=false; case "$c" in 2??|3??) ok=true;; esac
printf '{"t":%s,"ok":%s,"code":%s}\n' "$(date +%s)" "$ok" "$c" > /tmp/wf-hb.json.t && mv /tmp/wf-hb.json.t /tmp/wf-hb.json ;;

bot)	# un Comando Pronto del bot, risultato su Telegram
echo "$X" | grep -qE '^[a-z0-9_]{1,40}$' || { echo "comando non valido"; exit 1; }
ucode $W/tgbot.uc run "$X" >/dev/null 2>&1 ;;
weekly) # Riepilogo Settimanale (2.50): consumo, bloccati da AdGuard, dispositivi nuovi, cadute della linea; 2.66: esito nel
ucode $W/netx.uc weekly >/dev/null 2>&1; r=$?; reg weekly $r "$X"; exit $r ;;
monthly) # Consumo Del Mese (2.59, riga # wf:monthly): i primi dispositivi del mese (valore = quanti, 1…10)
echo "${X:-5}" | grep -qE '^([1-9]|10)$' || { echo "numero non valido (1…10)"; exit 1; }
ucode $W/dev.uc monthly "${X:-5}" >/dev/null 2>&1 ;;

*)	echo "uso: cron.sh <azione> [valore]"; exit 1 ;;
esac
exit 0
