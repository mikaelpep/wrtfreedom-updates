'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, error as ferr } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', NJ = ETC + '/nas.json', TMP = '/tmp/wf-nas', ST = TMP + '/dl.json', PROBE = TMP + '/dl-probe';
const W = R + '/usr/share/wrtfreedom', SH = getenv('WF_NASDLSH') ?? '/usr/share/wrtfreedom/nasdl.sh';
const SECRET = ETC + '/nas-aria2.secret', DLPORT = 6800, CA = '/etc/ssl/certs/ca-certificates.crt';
const GID = /^[0-9a-f]{16}$/, HMRX = /^([01][0-9]|2[0-3]):([0-5][0-9])$/;
const BUSYON = 262144, BUSYOFF = 131072;

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(R + p) != null; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
function wput(f, s) { let t = f + '.' + PID + '.t'; if (writefile(t, s) === length(s) && rename(t, f)) return true; unlink(t); return false; }
function wjs(f, o) { return wput(f, sprintf('%J', o)); }
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
function uniq(a) { let s = {}, r = []; for (let x in a) { x = '' + x; if (length(x) && !s[x]) { s[x] = 1; push(r, x); } } return r; }
function uuid() { return replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''); }
function rid() { return substr(uuid(), 0, 10) || ('' + time()); }
function newgid() { let g = lc(substr(uuid(), 0, 16)); return match(g, GID) && g != '0000000000000000' ? g : sprintf('%016x', time()); }
function mkdirp(p) { let c = '', n = []; for (let s in split(p, '/')) { if (!length(s)) continue; c += '/' + s; if (!lstat(c) && mkdir(c)) push(n, c); } return n; }
function wif(f, s) { if (readfile(f) == s) return false; return wput(f, s); }
function lo(a, b) { return !a ? b : (!b ? a : (a < b ? a : b)); }
function bname(p) { return replace('' + p, /^.*\//, ''); }
function dirof(p) { let d = replace('' + p, /\/[^\/]*$/, ''); return length(d) ? d : '/'; }
function dname(p) { return p == '/' || !length(p ?? '') ? '/' : bname(p); }
function short(s) {
s = '' + s;
if (length(s) <= 24) return s;
let n = 21;
while (n > 0 && (ord(s, n) & 0xC0) == 0x80) n--;
return substr(s, 0, n) + '…';
}
function cutp(s) { s = '' + (s ?? ''); return match(s, /^[^[:cntrl:]]{0,64}$/) ? s : ''; }

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function cfg(name) { return UCFG.read((getenv('WF_CFGDIR') ?? '/etc/config/') + name, false); }

let LG = 'it', WC = null;
let NREG = [];
function L(it, en) { return LG == 'en' ? en : it; }
function err(code, it, en) { return { error: it, error_en: en, code: code }; }
function begin() { WC = cfg('wrtfreedom'); LG = WC?.ui?.lang == 'en' ? 'en' : 'it'; mkdir(TMP); mkdir(ETC); NREG = []; }
function ev(t, x, bg, own, solo) {
if (!has('/usr/share/wrtfreedom/event.sh')) return;
let c = (solo && own && own != 'admin' ? 'WF_SOLO=1 ' : '') + 'sh ' + q(W + '/event.sh') + ' cron ' + q(t) + ' nas ' + q(x) + (own && own != 'admin' ? ' ' + q(own) : '');
if (bg) detach(c); else sh(c + ' >/dev/null 2>&1 </dev/null');
}

function wpriv(f, s) {
let t = f + '.' + PID + '.t', p = popen('umask 077; cat > ' + q(t), 'w');
if (!p) return false;
p.write(s); p.close();
return rename(t, f);
}
function wifp(f, s) { if (readfile(f) == s) return false; wpriv(f, s); return true; }

const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function nget() {
let N = UCFG.njget(NJ, NREG);
if (type(N.dl) != 'object') N.dl = {};
return N;
}
function nput(N) { return UCFG.njput(N, NREG, NJ, (s) => { let t = NJ + '.' + PID + '.t'; writefile(t, s); rename(t, NJ); }); }
function busyerr() { return err('busy', 'Impostazioni occupate: riprova', 'Settings busy: try again'); }
function NOMAIN() { return err('nomain', 'Manca il Disco Principale', 'The Main Drive is missing'); }
function ADM() { return err('admin', 'Solo l\'Amministratore', 'Administrator only'); }
function whoof(req) {
if (type(UCFG.who) != 'function') return { own: 'admin', adm: true };
let O = {}, w = UCFG.who(req, O);
if (w) return w;
return O.why == 'blocked' ? err('blocked', 'Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator') :
err('who', 'Accesso scaduto: entra di nuovo', 'Access expired: sign in again');
}
function oursset(N, s, on) { let o = type(N.ours) == 'array' ? N.ours : []; N.ours = on ? uniq([ ...o, s ]) : filter(o, (x) => x != s); }

const SYSMNT = /^\/(|overlay|rom|boot|tmp|proc|sys|dev)$/, SYS = getenv('WF_SYS') ?? '/sys';
function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
function blkinfo(ML) { return UCFG.blkinfo(ML, { sys: SYS, run: TMP, sh, rj: rjs, wjr: wjs, mkdirp: mkdir }); }
function mounted(m, ro) { return UCFG.mounted(m, ro); }
function disks() {
let M = {}, ML = [], D = [], NS = rjs(NJ)?.disks;
if (type(NS) != 'object') NS = {};
for (let l in split(readfile(R + '/proc/mounts') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) < 4) continue;
push(ML, { dev: p[0], mnt: unoct(p[1]) });
if (substr(p[0], 0, 5) == '/dev/' && !M[p[0]])
M[p[0]] = { mnt: unoct(p[1]), fs: p[2], ro: match(p[3], /^ro(,|$)/) != null };
}
let B = blkinfo(ML);
for (let dv in sort(keys(B))) {
let a = B[dv], k = '/dev/' + dv;
if (type(a) != 'object' || !M[k] || match(M[k].mnt, SYSMNT)) continue;
if (match(a.TYPE ?? '', /^(squashfs|ubifs|jffs2|swap)$/)) continue;
let dev = replace(dv, /^.*\//, ''), id = lc(a.UUID ?? '') || dev, fs = M[k].fs;
let st = NS[id]?.ro, lock = type(st) == 'bool' ? st : match(fs, /^(ntfs|ntfs3|ntfs-3g|fuseblk)$/) != null;
if (!mounted(M[k], M[k].ro || lock)) continue;
push(D, { id: id, dev: dev, name: a.LABEL || dev, mnt: M[k].mnt, fs: fs, ro: M[k].ro, lock: lock });
}
return D;
}
function rod(d) { return d.ro || d.lock === true; }
function diskof(D, id) { for (let d in D) if (d.id == id) return d; return null; }
function relok(p) {
p = '' + (p ?? '');
if (!length(p)) p = '/';
if (substr(p, 0, 1) != '/' || length(p) > 1024 || match(p, /[[:cntrl:]\\]/)) return null;
p = replace(p, /\/+/g, '/');
for (let s in split(p, '/')) if (s == '..' || s == '.') return null;
if (length(p) > 1 && substr(p, -1) == '/') p = substr(p, 0, length(p) - 1);
return p;
}
function absof(D, id, rel) {
let d = diskof(D, id), r = relok(rel);
if (!d || r == null) return null;
let p = d.mnt;
for (let s in split(r, '/')) {
if (!length(s)) continue;
p += '/' + s;
let st = lstat(p);
if (st && st.type == 'link') return null;
}
return p;
}
function freeb(p) {
let f = null;
try { f = require('fs').statvfs; } catch (e) { f = null; }
if (f) { let s = null; try { s = f(p); } catch (e) {} if (s) return s.bavail * s.frsize; }
let l = split(trim(sh('df -kP ' + q(p) + ' 2>/dev/null')), '\n'), x = split(l[length(l) - 1] ?? '', /[ \t]+/);
return length(x) >= 4 && match(x[3] ?? '', /^[0-9]+$/) ? +x[3] * 1024 : 0;
}
function freename(dir, n) {
if (!lstat(dir + '/' + n)) return n;
let m = match(n, /^(.+)(\.[^.]+)$/), b = m ? m[1] : n, x = m ? m[2] : '';
for (let i = 2; i < 10000; i++) if (!lstat(dir + '/' + b + ' (' + i + ')' + x)) return b + ' (' + i + ')' + x;
return null;
}

const PK = [ [ 'aria2', '/usr/bin/aria2c' ], [ 'ca-bundle', CA ] ];
function need() { return map(filter(PK, (p) => !has(p[1])), (p) => p[0]); }
function pkgerr(P) { return { ...err('pkg', 'Serve installare: ' + join(', ', P), 'Needs to be installed: ' + join(', ', P)), need: P }; }

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function b64e(s) {
if (type(global.b64enc) == 'function') return global.b64enc(s);
let o = [], n = length(s);
for (let i = 0; i < n; i += 3) {
let a = ord(s, i), b = i + 1 < n ? ord(s, i + 1) : 0, c = i + 2 < n ? ord(s, i + 2) : 0, v = (a << 16) | (b << 8) | c;
push(o, substr(B64, (v >> 18) & 63, 1) + substr(B64, (v >> 12) & 63, 1) + (i + 1 < n ? substr(B64, (v >> 6) & 63, 1) : '=') + (i + 2 < n ? substr(B64, v & 63, 1) : '='));
}
return join('', o);
}

const ADV = { bytype: true, conc: 2, retry: true, keep_days: 30, up_kbs: 50, peers: 30, seed: false, exe_warn: true, media: true };
const DLDIR = '/', RUNMAIN = TMP + '/mainpause.json', FULLS = TMP + '/full.list', DLOWN = TMP + '/dl-own.json';
function ownof(m) { let o = m?.own; return type(o) == 'string' && length(o) ? o : 'admin'; }
let TIPI = {};
try { TIPI = loadfile(getenv('WF_NASTIPIUC') ?? replace(sourcepath() ?? '', /[^\/]*$/, '') + 'nastipi.uc')() ?? {}; } catch (e) { TIPI = {}; }
const EXT = { video: TIPI.vid ?? [], music: TIPI.mus ?? [], photo: TIPI.img ?? [], doc: TIPI.doc ?? [], archive: TIPI.arc ?? [], app: TIPI.app ?? [] };
const VIA = [ 'app', 'paste', 'share', 'shortcut', 'bot', 'ai', 'tile' ];
function dcfg(d, N) {
let a = type(d.adv) == 'object' ? d.adv : {}, A = {};
for (let k, v in ADV) A[k] = type(a[k]) == type(v) ? a[k] : v;
let sc = type(d.sched) == 'object' ? d.sched : { mode: d.night === true ? 'night' : 'always' }, mi = N?.main?.id;
return { on: d.on === true, disk: type(mi) == 'string' || type(mi) == 'int' ? '' + mi : '', path: DLDIR, max_kbs: d.max_kbs ?? 0,
ppause: filter(type(d.ppause) == 'array' ? d.ppause : [], (u) => type(u) == 'string' && match(u, /^[A-Za-z0-9._-]+$/) && u != 'admin'),
sched: { mode: index([ 'always', 'night', 'bands' ], sc.mode) >= 0 ? sc.mode : 'always', bands: type(sc.bands) == 'array' ? sc.bands : [] },
sim_at: d.sim_at ?? 80, sim_backup: d.sim_backup !== false, busy: d.busy !== false, busy_kbs: d.busy_kbs ?? 500,
adv: A, notify: d.notify !== false, phones: type(d.phones) == 'array' ? d.phones : [], user: d.user === true, simok: d.simok ?? '' };
}
function ftype(n) {
let m = match(lc('' + n), /\.([a-z0-9]+)$/);
if (!m) return 'other';
for (let k, l in EXT) if (index(l, m[1]) >= 0) return k;
return 'other';
}
function tdir(c, own, n) {
let u = c.adv.bytype ? UCFG.udir(own, 'dl', ftype(n)) : UCFG.udir(own, 'dl');
return u != null ? '/' + u : null;
}
function udest(dk, own, p, N) {
let x = dk ? UCFG.absp(dk, '' + (p ?? '')) : null;
if (!x || lstat(x.abs)?.type != 'directory') return { e: 'path' };
let P = map(x.parts, lc), sotto = (b) => {
let B = b != null ? map(filter(split(b, '/'), (s) => length(s) > 0), lc) : null;
if (!B || length(P) < length(B)) return false;
for (let i = 0; i < length(B); i++) if (P[i] != B[i]) return false;
return true;
};
if (own == 'admin') { let v = UCFG.upriv({ adm: true }, x.parts, N); return v == 'lock' || v == 'in' ? { e: 'private' } : { x: x }; }
return sotto(UCFG.udir(own, 'root', null, N)) || sotto(UCFG.udir('shared', 'root', null, N)) ? { x: x } : { e: 'private' };
}
function desterr(e) {
return e == 'private' ? err('private', 'Qui non puoi salvare: scegli la tua cartella o la Cartella Condivisa', 'You cannot save here: pick your folder or the Shared Folder') :
err('path', 'Cartella non valida', 'Invalid folder');
}
function odir(root, own) {
let u = root ? UCFG.udir(own, 'dl') : null;
if (u == null) return null;
let p = root;
for (let s in split(u, '/')) { p += '/' + s; let st = lstat(p); if (st && st.type == 'link') return null; }
let C = mkdirp(p);
if (length(C)) sh('chmod 755 ' + join(' ', map(C, (x) => q(x))) + ' 2>/dev/null');
return stat(p)?.type == 'directory' ? p : null;
}
function lanhost(h) {
h = lc(h);
if (h == 'localhost' || match(h, /\.localhost$/) || match(h, /\.(lan|local|home|internal|home\.arpa)$/) || index(h, '.') < 0 && index(h, ':') < 0) return true;
if (match(h, /^[0-9.]+$/) && (!match(h, /^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/) || match(h, /(^|\.)0[0-9]/))) return true;
if (match(h, /^[0-9a-fx.]+$/) && match(h, /(^|\.)0x/)) return true;
if (match(h, /^(127|10|0)\.|^192\.168\.|^169\.254\.|^172\.(1[6-9]|2[0-9]|3[01])\./)) return true;
if (index(h, ':') >= 0 && (h == '::' || h == '::1' || match(h, /^(fc|fd|fe[89ab])[0-9a-f]*:|^::ffff:/))) return true;
return false;
}
function urlok(u) {
if (length(u) > 4000 || match(u, /[[:cntrl:] ]/)) return false;
if (match(u, /^magnet:\?/)) return true;
let m = match(u, /^(https?|ftp|sftp):\/\/([^\/?#]+)/);
if (!m) return false;
let h = replace(m[2], /^.*@/, ''), b = match(h, /^\[([^]]*)\]/);
h = b ? b[1] : replace(h, /:[0-9]*$/, '');
return length(h) > 0 && !lanhost(h);
}
function uname(u) {
u = '' + u;
if (substr(u, 0, 7) == 'magnet:') { let m = match(u, /[?&]dn=([^&]*)/); return m ? replace(replace(m[1], /\+/g, ' '), /%([0-9A-Fa-f][0-9A-Fa-f])/g, (a, h) => chr(hex(h))) : 'magnet'; }
return bname(replace(u, /[?#].*$/, '')) || u;
}

const CLOUDUC = getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc', CJOBS = getenv('WF_CLOUDJOBS') ?? '/tmp/wf-cloud/jobs';
const JOBID = /^j[0-9a-z]{4,24}$/, ACCT = /^a[0-9]{1,3}$/;
let MC = {};
function cmod() { return stat(CLOUDUC) ? UCFG.modof(MC, CLOUDUC) : null; }
function CNO() { return err('cloud', 'Cloud non pronto: riprova più tardi', 'Cloud not ready: try again later'); }
function ccall(own, a) {
let m = cmod()?.cloud, r = null;
if (!m) return CNO();
try { r = m.call({ args: { ...a, ...(own == 'admin' ? {} : { as: own }) } }); } catch (e) { r = null; }
return type(r) == 'object' ? r : CNO();
}
function curl(u) { return match(u, /^https?:\/\/[^ ]+$/) != null && length(u) <= 2048 && !match(lc(replace(u, /[?#].*$/, '')), /\.torrent$/); }
function cacct(id, own) {
if (type(id) != 'string' || !match(id, ACCT)) return { e: err('cloud', 'Account del cloud non trovato', 'Cloud account not found') };
let rc = cmod()?._rc, A = null;
if (!rc) return { e: CNO() };
try { A = rc.acct(id); } catch (e) { A = null; }
if (type(A) != 'object') return { e: err('cloud', 'Account del cloud non trovato', 'Cloud account not found') };
if (A.user != 'admin' && A.user != own) return { e: err('private', 'Cloud personale di un\'altra persona', 'Another person\'s personal cloud') };
return { a: A };
}
function cnames() {
let C = rjs(ETC + '/cloud.json'), r = {};
for (let a in (type(C?.accounts) == 'array' ? C.accounts : [])) if (type(a) == 'object' && type(a.id) == 'string') r[a.id] = '' + (a.name ?? a.id);
return r;
}
function cjob(j) { let o = type(j) == 'string' && match(j, JOBID) ? rjs(CJOBS + '/' + j + '.json') : null; return type(o) == 'object' ? o : null; }
function cst(s) { return { run: 'run', wait: 'queue', pause: 'pause', err: 'err', stop: 'err', ok: 'done' }[s] ?? 'queue'; }
function cpart(acct, job, o, CN, x) {
let s = o ? (o.state ?? 'wait') : (x?.state ?? (length(job ?? '') ? 'ok' : 'err'));
return { acct: acct, name: CN[acct] ?? acct, job: job ?? '', state: s, pct: +(o?.pct ?? (s == 'ok' ? 100 : 0)),
why: o ? (s == 'err' ? o.err ?? '' : o.why ?? '') : x?.why ?? '', why_en: o ? (s == 'err' ? o.err_en ?? '' : o.why_en ?? '') : x?.why_en ?? '' };
}
function crows(own, CN) {
let r = [];
for (let f in (lsdir(CJOBS) ?? [])) {
let m = match(f, /^(j[0-9a-z]{4,24})\.json$/), o = m ? rjs(CJOBS + '/' + f) : null;
if (type(o) != 'object' || o.kind != 'url' || ownof(o) != own) continue;
let s = cst(o.state), dn = +(o.bytes ?? 0), tt = +(o.size ?? 0), v = +(o.speed ?? 0), nm = '' + (o.name ?? 'Link'), to = '' + (o.to ?? '');
push(r, { id: m[1], src: 'cloud', name: nm, state: s, why: s == 'err' ? L(o.err ?? '', o.err_en ?? '') : '', done: dn, total: tt, speed: s == 'run' ? v : 0,
eta: s == 'run' && v > 0 && tt > dn ? int((tt - dn) / v) : 0, dir: dname(to), from: '', via: 'cloud', tor: false, up: 0, seeders: 0, url: o.url ?? '',
when: 'now', added: +(o.t ?? 0), t: s == 'done' ? +(o.t ?? 0) : 0, disk: '', path: s == 'done' ? (to == '/' ? '' : to) + '/' + nm : '', own: own,
cloud: cpart(o.id ?? '', m[1], o, CN) });
}
return r;
}

function secret() { return trim(readfile(SECRET) ?? ''); }
function bin(n) { for (let d in [ '/usr/bin/', '/bin/', '/usr/sbin/', '/sbin/' ]) if (stat(R + d + n)?.type == 'file') return R + d + n; return null; }
let SOCK = false;
function sockmod() { if (SOCK === false) { try { SOCK = require('socket'); } catch (e) { SOCK = null; } } return SOCK; }
function hbody(r) { let i = index(r ?? '', '\r\n\r\n'); return match(r ?? '', /^HTTP\/1\.[01] [0-9][0-9][0-9]/) && i >= 0 ? substr(r, i + 4) : null; }
function hdone(r) {
let i = index(r, '\r\n\r\n'), m = i >= 0 ? match(substr(r, 0, i), /\r\n[Cc][Oo][Nn][Tt][Ee][Nn][Tt]-[Ll][Ee][Nn][Gg][Tt][Hh]: *([0-9]+)/) : null;
return m != null && length(r) >= i + 4 + +m[1];
}
function spost(S, req) {
let c = null, r = '', end = time() + 3;
try { c = S.connect('127.0.0.1', '' + DLPORT, null, 2000); } catch (e) { c = null; }
if (!c) return null;
try {
for (let o = 0, n = length(req); o < n && time() <= end; ) {
let k = c.send(o ? substr(req, o) : req);
if (type(k) != 'int' || k <= 0) { S.poll(500, [ c, S.POLLOUT ]); continue; }
o += k;
}
while (time() <= end && !hdone(r)) {
let p = S.poll(1000, [ c, S.POLLIN ]);
if (!length(p ?? [])) continue;
let d = c.recv(65536);
if (d == null || !length(d)) break;
r += d;
}
} catch (e) {}
try { c.close(); } catch (e) {}
return hbody(r);
}
function post(body) {
let b = sprintf('%J', body), S = sockmod(), o = null;
let req = 'POST /jsonrpc HTTP/1.1\r\nHost: 127.0.0.1:' + DLPORT + '\r\nContent-Type: application/json\r\nContent-Length: ' + length(b) +
'\r\nConnection: close\r\n\r\n' + b;
if (S) o = spost(S, req);
else {
let cu = bin('curl'), nc = cu ? null : bin('nc'), to = bin('timeout');
if (!cu && !nc) return null;
let dd = TMP + '/.sec', f = dd + '/rpc' + rid();
mkdir(dd, 448);
writefile(f, cu ? b : req);
if (cu) o = sh(q(cu) + ' -s -m 3 -H ' + q('Content-Type: application/json') + ' -H Expect: --data-binary @' + q(f) + ' http://127.0.0.1:' + DLPORT + '/jsonrpc 2>/dev/null');
else o = hbody(sh((to ? q(to) + ' 4 ' : '') + q(nc) + ' 127.0.0.1 ' + DLPORT + ' <' + q(f) + ' 2>/dev/null'));
unlink(f);
}
let j = null; try { j = json(o ?? ''); } catch (e) {}
return type(j) == 'object' ? j : null;
}
function listening() {
let p = sprintf(':%04X', DLPORT);
for (let f in [ '/proc/net/tcp', '/proc/net/tcp6' ])
for (let l in split(readfile(R + f) ?? '', '\n')) { let x = split(trim(l), /[ \t]+/); if (length(x) > 3 && substr(x[1], -5) == p && x[3] == '0A') return true; }
return false;
}
function rpc(method, params) {
let s = secret();
if (!length(s)) return null;
return post({ jsonrpc: '2.0', id: 'wf', method: method, params: [ 'token:' + s, ...params ] })?.result ?? null;
}
function rpcm(calls) {
let s = secret();
if (!length(s) || !length(calls)) return [];
let r = post({ jsonrpc: '2.0', id: 'wf', method: 'system.multicall', params: [ map(calls, (c) => ({ methodName: c[0], params: [ 'token:' + s, ...(c[1] ?? []) ] })) ] })?.result;
return type(r) == 'array' ? map(r, (x) => type(x) == 'array' ? x[0] : null) : [];
}
const KEYS = [ 'gid', 'status', 'totalLength', 'completedLength', 'downloadSpeed', 'uploadSpeed', 'files', 'bittorrent', 'errorCode', 'dir', 'numSeeders', 'followedBy', 'infoHash' ];
function alist() {
let r = rpcm([ [ 'aria2.tellActive', [ KEYS ] ], [ 'aria2.tellWaiting', [ 0, 1000, KEYS ] ], [ 'aria2.tellStopped', [ 0, 1000, KEYS ] ] ]);
if (!length(r)) return null;
let o = [];
for (let p in r) for (let x in (type(p) == 'array' ? p : [])) if (type(x) == 'object' && x.status != 'removed') push(o, x);
return o;
}
function aname(x, m) {
let n = x?.bittorrent?.info?.name ?? bname(x?.files?.[0]?.path ?? '');
if (!length(n)) n = m?.name ?? uname(x?.files?.[0]?.uris?.[0]?.uri ?? m?.url ?? '');
return n || x?.gid || '';
}
function whyx(code) {
if (code == 'fat4g') return [ 'Il disco è FAT32: un file al massimo 4 GB', 'The drive is FAT32: 4 GB per file at most' ];
let c = +(code ?? 0);
if (c == 3 || c == 4 || c == 22 || c == 24) return [ 'Link scaduto', 'Link expired' ];
if (c == 9) return [ 'Disco pieno', 'Disk full' ];
if (c == 2 || c == 5 || c == 6 || c == 19 || c == 21 || c == 23 || c == 29) return [ 'Sito irraggiungibile', 'Site unreachable' ];
if (c >= 14 && c <= 18) return [ 'Errore del disco', 'Disk error' ];
if (c >= 25 && c <= 27) return [ 'Torrent non valido', 'Invalid torrent' ];
return [ 'Non riuscito', 'Failed' ];
}
function whyt(code, tries) {
let w = whyx(code), t = L(w[0], w[1]);
return tries >= 2 ? t + ' · ' + sprintf(L('provato %d volte', 'tried %d times'), tries) : t;
}

function droot(c, D) { return c.disk != '' ? absof(D, c.disk, c.path) : null; }
function jget(root, g) { return root ? rjs(root + '/.wf-dl/job/' + g + '.json') : null; }
function jput(root, g, o) { if (!root) return; mkdirp(root + '/.wf-dl/job'); wjs(root + '/.wf-dl/job/' + g + '.json', o); }
function jdel(root, g) { if (root) unlink(root + '/.wf-dl/job/' + g + '.json'); }
function jall(root) {
let r = {};
if (!root) return r;
for (let f in (lsdir(root + '/.wf-dl/job') ?? [])) {
let m = match(f, /^([0-9a-f]{16})\.json$/), o = m ? rjs(root + '/.wf-dl/job/' + f) : null;
if (type(o) == 'object') r[m[1]] = o;
}
return r;
}
function dones(root) {
let r = [];
if (!root) return r;
for (let f in (lsdir(root + '/.wf-dl/done') ?? [])) {
if (!match(f, /^[0-9a-f]{16}\.json$/)) continue;
let o = rjs(root + '/.wf-dl/done/' + f);
if (type(o) == 'object' && match('' + o.id, GID)) push(r, o);
}
return sort(r, (a, b) => (b.t ?? 0) - (a.t ?? 0));
}
function probes() {
let r = {};
for (let f in (lsdir(PROBE) ?? [])) { let m = match(f, /^([0-9a-f]{16})\.json$/); if (m) r[m[1]] = rjs(PROBE + '/' + f) ?? {}; }
return r;
}
function pdel(g) { unlink(PROBE + '/' + g + '.json'); }

function siminfo(c) {
let U = rjs('/tmp/wf-usage.json'), qb = +(WC?.usage?.quota ?? 0) * 1e9;
if (type(U) != 'object' || U.mobile !== true || qb <= 0) return null;
let used = +(U.rx ?? 0) + +(U.tx ?? 0), at = c.sim_at, lim = at > 0 ? qb * at / 100 : qb;
let Ln = rjs('/tmp/wf-line.json'), on = !length(Ln?.dev ?? '') || Ln.dev == U.dev, Si = rjs('/tmp/wf-sim.json');
return { slot: +(Si?.active ?? 1), pct: int(used * 100 / qb), left: used < lim ? int(lim - used) : 0, renew: U.next ?? '', pause_at: at,
backup: c.sim_backup, line: on, reserve: on && Ln?.active == 'backup' };
}
function simpause(c, s) {
if (!s || !s.line || (length(c.simok) && c.simok == s.renew)) return false;
return (c.sim_at > 0 && s.pct >= c.sim_at) || (c.sim_backup && s.reserve);
}

function hm(s) { let m = match('' + s, HMRX); return m ? +m[1] * 60 + +m[2] : null; }
function inband(b, lt) {
let c = lt.hour * 60 + lt.min, f = hm(b.from), t = hm(b.to);
if (f == null || t == null) return false;
let inn = f == t || (f < t ? c >= f && c < t : c >= f || c < t);
if (!inn || type(b.days) != 'array' || !length(b.days)) return inn;
let wd = f > t && c < t ? (lt.wday + 6) % 7 : lt.wday;
return index(b.days, wd) >= 0;
}
function win(c, lt) {
let s = c.sched, cur = lt.hour * 60 + lt.min;
if (s.mode == 'night') return { ok: cur >= 60 && cur < 420, kbs: 0 };
if (s.mode == 'bands' && length(s.bands)) {
for (let b in s.bands) if (inband(b, lt)) return { ok: true, kbs: +(b.kbs ?? 0) };
return { ok: false, kbs: 0 };
}
return { ok: true, kbs: 0 };
}

function today(lt) { return sprintf('%04d-%02d-%02d', lt.year, lt.mon, lt.mday); }
function ejectwait() {
for (let f in lsdir(TMP + '/eject') ?? []) {
if (!match(f, /\.json$/)) continue;
let e = rjs(TMP + '/eject/' + f);
if (type(e?.stopped) == 'array' && index(e.stopped, 'dl') >= 0) return true;
}
return false;
}
function dlwhere(c, D) {
if (!c.on || !length(c.disk) || D == null) return '';
if (!diskof(D, c.disk)) return 'disk';
let p = droot(c, D);
return p && stat(p)?.type == 'directory' && stat(p + '/.wf-dl')?.type == 'directory' ? '' : 'folder';
}
function decide(c, st, lt, D) {
let w = win(c, lt), s = siminfo(c), sp = simpause(c, s);
let r = c.user ? 'pause' : (!w.ok ? 'night' : (sp ? 'sim' : 'run'));
let cu = stat(TMP + '/dl.custode') != null, ej = ejectwait(), nd = dlwhere(c, D);
let mp = !length(c.disk) || stat(RUNMAIN) != null, pp = {}, fu = {};
for (let u in c.ppause) pp[u] = true;
for (let u in split(readfile(FULLS) ?? '', '\n')) { u = trim(u); if (length(u) && u != 'admin') { fu[u] = true; pp[u] = true; } }
return { reason: r, custode: cu, eject: ej, nodisk: nd, mainp: mp, pp: pp, full: fu, hold: cu || ej || mp || nd != '',
kbs: lo(lo(c.max_kbs, w.kbs), c.busy && st.busy ? c.busy_kbs : 0),
sim: s, simp: sp, night: lt.hour >= 1 && lt.hour < 7, day: today(lt), busy: c.busy && st.busy ? true : false };
}
function want(m, G) {
if (m?.paused === true || G.reason != 'run' || G.pp[ownof(m)]) return false;
if (m?.when == 'night' && !G.night) return false;
if (m?.when == 'renew' && length(m.until ?? '') && G.day < m.until) return false;
return true;
}
const FAT4G = 4294967295;
function cutu(s, n) {
s = '' + (s ?? '');
if (length(s) <= n) return s;
s = substr(s, 0, n);
while (length(s) && (ord(s, length(s) - 1) & 0xC0) == 0x80) s = substr(s, 0, length(s) - 1);
if (length(s) && ord(s, length(s) - 1) >= 0xC0) s = substr(s, 0, length(s) - 1);
return s;
}
function isfat(d) { return !!d && match(d.fs ?? '', /^(vfat|msdos|fat|fat32)$/) != null; }
function fatbig(x) {
for (let f in (type(x?.files) == 'array' ? x.files : [])) if (f?.selected != 'false' && +(f?.length ?? 0) > FAT4G) return true;
return +(x?.totalLength ?? 0) > FAT4G && length(x?.files ?? []) <= 1;
}
function jstate(x, m, G) {
let s = x.status;
if (m?.fat4g === true) return 'err';
if (s == 'active') return 'run';
if (s == 'waiting') return 'queue';
if (s == 'error') return 'err';
if (s == 'complete') return 'done';
if (m?.paused === true || G.hold || G.reason == 'pause' || G.pp[ownof(m)]) return 'pause';
if (G.reason == 'sim' || (m?.when == 'renew' && length(m.until ?? '') && G.day < m.until)) return 'sim';
if (G.reason == 'night' || (m?.when == 'night' && !G.night)) return 'night';
return 'queue';
}
function pstate(c, L1, G, W) {
if (!c.on) return [ 'off', '' ];
let open = filter(L1, (j) => j.state != 'done');
if (!length(open)) return [ 'empty', '' ];
if (G.mainp) return [ 'pause', 'main' ];
if (G.nodisk) return [ 'pause', G.nodisk ];
if (!W.adm && G.full[W.own]) return [ 'pause', 'quota' ];
if (!W.adm && G.pp[W.own]) return [ 'pause', 'user' ];
if (G.custode) return [ 'pause', 'custode' ];
if (G.eject) return [ 'pause', 'eject' ];
if (G.reason == 'pause') return [ 'pause', 'user' ];
if (G.reason == 'sim') return [ 'sim', G.sim?.reserve && c.sim_backup && !(c.sim_at > 0 && G.sim.pct >= c.sim_at) ? 'reserve' : 'sim' ];
if (G.reason == 'night') return [ 'night', 'sched' ];
let live = filter(open, (j) => j.state == 'run' || j.state == 'queue');
if (!length(live)) {
for (let k in [ 'sim', 'night' ]) if (length(filter(open, (j) => j.state == k)) == length(filter(open, (j) => j.state != 'err'))) return [ k, k == 'sim' ? 'sim' : 'sched' ];
if (length(filter(open, (j) => j.state == 'pause'))) return [ 'pause', 'user' ];
}
return [ 'run', G.busy ? 'busy' : '' ];
}
function spd(b) {
let s = b >= 1048576 ? sprintf('%.1f MB/s', b / 1048576.0) : sprintf('%d KB/s', int(b / 1024));
return LG == 'en' ? s : replace(s, '.', ',');
}

function doneold(c, r, now) { let k = c.adv.keep_days; return k > 0 && now - +(r.t ?? 0) > k * 86400; }
function ownw(R, G) {
let O = {}, one = (u) => { if (!O[u]) O[u] = { n: 0, run: 0, paused: false, kbs: 0 }; return O[u]; };
for (let j in R) { if (j.state == 'done') continue; let o = one(j.own); o.n++; if (j.state == 'run') { o.run++; o.kbs += +(j.v ?? 0); } }
for (let u in keys(G?.pp ?? {})) one(u);
for (let u, o in O) { o.paused = G != null && (!!G.pp[u] || G.reason == 'pause' || G.hold); o.kbs = int(o.kbs / 1024); }
mkdir(TMP);
wif(DLOWN, sprintf('%J', O));
}
function visof(N, u) {
let x = type(N?.users) == 'object' ? N.users[u] : null;
if (type(x) == 'object' && type(x.vis) == 'string' && length(x.vis)) return x.vis;
for (let g in (type(N?.gone) == 'array' ? N.gone : [])) if (type(g) == 'object' && g.user == u && type(g.vis) == 'string' && length(g.vis)) return g.vis;
return u;
}
function peopleof(N, c, G, A) {
let O = {}, R = [];
for (let j in A) {
if (j.own == 'admin' || j.state == 'done') continue;
let o = O[j.own] ?? (O[j.own] = { n: 0, err: 0, run: 0, v: 0 });
o.n++;
if (j.state == 'err') o.err++;
if (j.state == 'run') { o.run++; o.v += j.v; }
}
for (let u in sort(keys(O))) {
let o = O[u], pz = G.pp[u] || G.reason == 'pause' || G.hold;
let s = o.err ? [ 'warn', 'Non Riesce', 'Failing' ] : (o.run ? [ 'run', 'In Corso', 'Downloading' ] : (pz ? [ 'ok', 'In Pausa', 'Paused' ] : [ 'ok', 'In Coda', 'Queued' ]));
push(R, { own: u, own_name: visof(N, u), n: o.n, st: s[0], st_t: s[1], st_t_en: s[2], speed: o.v, paused: index(c.ppause, u) >= 0 });
}
return R;
}
function view(N, D, W) {
W = W ?? { own: 'admin', adm: true };
let c = dcfg(N.dl, N), now = time(), lt = localtime(now), st = rjs(ST) ?? {}, G = decide(c, st, lt, D);
let root = c.on ? droot(c, D) : null, M = jall(root), P = probes(), X = c.on ? alist() : null;
let L1 = [], LA = [], ALL = [], sp = 0, nrun = 0, rem = 0, qd = 0, CN = cnames();
for (let x in (X ?? [])) {
if (P[x.gid] || x.status == 'complete') continue;
let m = M[x.gid] ?? {}, s = jstate(x, m, G), dn = +(x.completedLength ?? 0), tt = +(x.totalLength ?? 0), v = +(x.downloadSpeed ?? 0), ow = ownof(m);
push(ALL, { own: ow, state: s, v: v });
if (!W.adm && ow != W.own) continue;
push(LA, { state: s });
if (s == 'run') { sp += v; nrun++; }
if (s != 'err') { qd++; if (tt > dn) rem += tt - dn; }
if (ow != W.own) continue;
let od = UCFG.udir(ow, 'dl'), nm = aname(x, m);
push(L1, { id: x.gid, name: nm, state: s, why: s == 'err' ? whyt(m.fat4g === true ? 'fat4g' : (x.errorCode ?? m.code), +(m.tries ?? 0)) : '', done: dn, total: tt, speed: v,
eta: s == 'run' && v > 0 && tt > dn ? int((tt - dn) / v) : 0, dir: dname(length(m.dir ?? '') ? m.dir : (tdir(c, ow, nm) ?? '')), from: m.from ?? '', via: m.via ?? '',
tor: x.bittorrent != null, up: +(x.uploadSpeed ?? 0), seeders: +(x.numSeeders ?? 0), url: m.url ?? x.files?.[0]?.uris?.[0]?.uri ?? '',
when: m.when ?? 'now', added: m.t ?? 0, t: 0, disk: c.disk, path: od != null ? '/' + od + '/' + nm : '', own: ow,
cloud: length(m.cloud ?? '') ? cpart(m.cloud, '', null, CN, { state: 'wait', why: 'Dopo il download', why_en: 'After the download' }) : '' });
}
if (c.on) ownw(ALL, G);
let mid = now - (lt.hour * 3600 + lt.min * 60 + lt.sec), dt = 0;
for (let r in dones(root)) {
if (doneold(c, r, now) || ownof(r) != W.own) continue;
if ((r.t ?? 0) >= mid) dt++;
let rc = type(r.cloud) == 'object' && length(r.cloud.acct ?? '') ? r.cloud : null, o = rc ? cjob(rc.job) : null, cp = rc ? cpart(rc.acct, rc.job, o, CN, rc) : '';
let s = rc ? (o ? cst(o.state) : (cp.state == 'err' ? 'err' : 'done')) : 'done', inc = rc && s == 'done' && length(rc.to ?? '');
push(L1, { id: r.id, name: r.name ?? '', state: s, why: s == 'err' ? L(cp.why, cp.why_en) : '', done: r.size ?? 0, total: r.size ?? 0, speed: s == 'run' ? +(o?.speed ?? 0) : 0, eta: 0,
dir: inc ? dname(rc.to) : dname(dirof(r.path ?? '/')),
path: inc ? (rc.to == '/' ? '' : rc.to) + '/' + (r.name ?? '') : r.path ?? '', disk: inc ? '' : r.disk ?? '', from: r.from ?? '', via: r.via ?? '', tor: r.tor === true, up: 0, seeders: 0,
url: r.url ?? '', when: 'now', added: r.added ?? 0, t: r.t ?? 0, own: ownof(r), cloud: cp });
if (s != 'done') push(LA, { state: 'done' });
}
for (let j in crows(W.own, CN)) { push(L1, j); if (j.state != 'done') push(LA, { state: 'done' }); }
for (let j in L1) if (j.state == 'done') push(LA, { state: 'done' });
let ps = pstate(c, LA, G, W), s = W.adm ? G.sim : null, line = '', ud = W.adm ? null : UCFG.udir(W.own, 'dl');
if (ps[0] == 'run' && nrun) line = nrun + (LG == 'en' && nrun > 1 ? ' files · ' : ' file · ') + spd(sp);
else if (qd) line = qd + L(' in coda', ' queued');
return { state: ps[0], why: ps[1], run: X != null, line: line,
speed: sp, end: sp > 0 && rem > 0 ? now + int(rem / sp) : 0, queued: qd, done_today: dt, free: !W.adm ? null : (root ? freeb(root) : 0),
sim: s ? { slot: s.slot, pct: s.pct, left: s.left, renew: s.renew, pause_at: s.pause_at, backup: s.backup, reserve: s.reserve } : null,
list: L1, hist: W.adm && type(st.hist) == 'array' ? st.hist : [],
on: c.on, disk: c.disk, path: W.adm ? c.path : (ud != null ? '/' + ud : ''), max_kbs: c.max_kbs, kbs: G.kbs, sched: c.sched, sim_at: c.sim_at, sim_backup: c.sim_backup,
busy: { on: c.busy, kbs: c.busy_kbs, now: G.busy, who: W.adm ? st.bwho ?? '' : '', log: !W.adm ? [] : map(type(st.blog) == 'array' ? st.blog : [], (x) => ({ t: x.t, end: x.end ?? 0,
name: x.who ?? '', person: x.person ?? '', mac: x.mac ?? '', mins: int(((x.end || now) - x.t) / 60), now: !x.end && G.busy })) },
adv: c.adv, notify: c.notify, phones: map(filter(c.phones, (p) => ownof(p) == W.own), (p) => ({ ...p, ready: true })), need: need(),
people: W.adm ? peopleof(N, c, G, ALL) : [],
own: W.own, adm: W.adm === true, paused_me: !W.adm && G.pp[W.own] === true, full: !W.adm && G.full[W.own] === true,
shortcut: '' };
}

const DLINIT = '#!/bin/sh /etc/rc.common\n# WrtFreedom: Download del NAS (aria2, RPC solo locale), scritto da nasdl.uc e tolto da nasvc.sh uninstall\nSTART=99\nUSE_PROCD=1\n' +
'start_service() {\n\tsh /usr/share/wrtfreedom/nasdl.sh dlprep || return 0\n\tprocd_open_instance\n' +
'\tprocd_set_param command /usr/bin/aria2c --conf-path=/etc/wrtfreedom/nas-aria2.conf\n\tprocd_set_param respawn\n\tprocd_close_instance\n}\n';
const MEMJ = R + '/tmp/wf-mem.json';
function amem() {
let J = rjs(MEMJ), now = time(), s = type(J) == 'object' ? J.serv?.aria2 : null;
if (type(s) != 'object' || type(J.t) != 'int' || now - J.t > 180 || J.t - now > 60 || type(s.tetto) != 'int' || type(s.sol) != 'int') return null;
return { sol: int(s.sol / 1024), tetto: int(s.tetto / 1024), low: type(J.avail) == 'int' && type(J.ris) == 'int' && J.avail < J.ris };
}
function dcache(M, o) {
if (!M) return type(o) == 'string' && match(o, /^[0-9]{1,4}[KM]?$/) ? o : '4M';
return M.sol >= 48 ? '4M' : (M.sol >= 24 ? '2M' : '1M');
}
function dlmem(c, M) {
let p = c.adv.peers, r = 1000;
if (M) {
if (M.low) { if (p > 20) p = 20; r = 100; }
else if (M.tetto < 64) { let x = M.tetto > 20 ? M.tetto : 20; if (p > x) p = x; r = 200; }
}
return { 'bt-max-peers': '' + p, 'max-download-result': '' + r };
}
function confkv(k, t) { return match(t ?? readfile(ETC + '/nas-aria2.conf') ?? '', regexp('(^|\n)' + k + '=([^\n]*)'))?.[2]; }
function confdir(t) { return confkv('dir', t) ?? ''; }
function dlwrite(c, D) {
let p = droot(c, D);
if (!p) return false;
let C = mkdirp(p + '/.wf-dl'), X = [], ot = readfile(ETC + '/nas-aria2.conf') ?? '', od = confdir(ot), odc = confkv('disk-cache', ot);
if (!length(secret())) wpriv(SECRET, rid() + rid() + rid() + '\n');
let s = p + '/.wf-aria2.session', A = c.adv;
wifp(ETC + '/nas-aria2.conf', 'dir=' + p + '\nenable-rpc=true\nrpc-listen-all=false\nrpc-listen-port=' + DLPORT + '\nrpc-secret=' + secret() +
'\nrpc-allow-origin-all=false\nrpc-max-request-size=2M\ninput-file=' + s + '\nsave-session=' + s + '\nsave-session-interval=60\n' +
'max-concurrent-downloads=' + A.conc + '\ncontinue=true\nfile-allocation=none\ndisk-cache=' + dcache(amem(), odc) + '\n' +
(A.seed ? 'seed-ratio=1.0\n' : 'seed-time=0\n') + 'max-overall-download-limit=' + c.max_kbs + 'K\nmax-overall-upload-limit=' + A.up_kbs + 'K\n' +
'bt-max-peers=' + A.peers + '\nfollow-torrent=mem\nauto-save-interval=60\n' + (has(CA) ? 'ca-certificate=' + CA + '\n' : '') +
'on-download-complete=' + ETC + '/nas-dl-ok.sh\non-download-error=' + ETC + '/nas-dl-err.sh\n');
if (wif(ETC + '/nas-dl-ok.sh', '#!/bin/sh\nexec sh ' + SH + ' dldone ok "$@"\n')) push(X, ETC + '/nas-dl-ok.sh');
if (wif(ETC + '/nas-dl-err.sh', '#!/bin/sh\nexec sh ' + SH + ' dldone err "$@"\n')) push(X, ETC + '/nas-dl-err.sh');
if (wif(R + '/etc/init.d/wf-nasdl', DLINIT)) push(X, R + '/etc/init.d/wf-nasdl');
let Y = [ ...C, ...X ], P6 = filter([ SECRET, ETC + '/nas-aria2.conf' ], (f) => (stat(f)?.mode ?? 0) & 63);
if (length(Y)) sh('chmod 755 ' + join(' ', map(Y, (x) => q(x))) + ' 2>/dev/null');
if (length(P6)) sh('chmod 600 ' + join(' ', map(P6, (x) => q(x))) + ' 2>/dev/null');
return od != p;
}
function dlopts(c) {
let A = c.adv;
return { 'max-concurrent-downloads': '' + A.conc, 'max-overall-upload-limit': A.up_kbs + 'K', ...dlmem(c, amem()),
...(A.seed ? { 'seed-ratio': '1.0' } : { 'seed-time': '0' }) };
}

function retry(c, root, x, m, G) {
let od = odir(root, ownof(m));
if (!od) return null;
let ng = newgid(), opt = { gid: ng, pause: want(m, G) && !G.hold ? 'false' : 'true', dir: od }, r = null;
if (length(m.files ?? [])) opt['select-file'] = join(',', m.files);
if (x.bittorrent) {
let h = x.infoHash ?? '', f = match(h, /^[0-9a-f]{40}$/) && x.dir ? x.dir + '/' + h + '.torrent' : null, b = f ? readfile(f) : null;
if (length(b)) r = rpc('aria2.addTorrent', [ b64e(b), [], opt ]);
}
else {
let u = m.url ?? x.files?.[0]?.uris?.[0]?.uri;
if (u && urlok(u)) r = rpc('aria2.addUri', [ [ u ], opt ]);
}
if (r == null) return null;
rpc('aria2.removeDownloadResult', [ x.gid ]);
m.tt = time();
jdel(root, x.gid);
jput(root, ng, m);
return ng;
}

function hist(st, now, sp) {
let b = now - now % 300, H = type(st.hist) == 'array' ? st.hist : [];
if (st.hb != b) {
if (st.hb != null && st.hn) {
push(H, int(st.hs / st.hn));
for (let i = st.hb + 300; i < b && length(H) < 48; i += 300) push(H, 0);
}
st.hb = b; st.hs = 0; st.hn = 0;
}
st.hs = (st.hs ?? 0) + sp; st.hn = (st.hn ?? 0) + 1;
st.hist = slice(H, length(H) > 24 ? length(H) - 24 : 0);
}
function topdev() {
let Rt = rjs('/tmp/wf-dev.json')?.rate, best = null, bv = 0;
for (let mac, v in (type(Rt) == 'object' ? Rt : {})) { let s = type(v) == 'array' ? +(v[0] ?? 0) + +(v[1] ?? 0) : 0; if (s > bv) { bv = s; best = mac; } }
if (!best) return { mac: '', name: '' };
let D = cfg('dhcp'), nm = '', lf = '/tmp/dhcp.leases';
for (let k in D) if (D[k]['.type'] == 'dnsmasq' && length(D[k].leasefile ?? '')) { lf = D[k].leasefile; break; }
for (let l in split(readfile(lf) ?? '', '\n')) { let p = split(l, ' '); if (length(p) >= 4 && lc(p[1]) == best && p[3] != '*') nm = p[3]; }
for (let k in D) if (D[k]['.type'] == 'host' && index(split(lc(join(' ', type(D[k].mac) == 'array' ? D[k].mac : [ D[k].mac ?? '' ])), /[ \t]+/), best) >= 0) {
let n = D[k].x3000_label || D[k].name || '';
if (length(n)) nm = n;
}
return { mac: best, name: nm || best };
}
function rdev() {
for (let l in split(readfile('/proc/net/route') ?? '', '\n')) { let f = split(l, '\t'); if (f[1] == '00000000' && f[7] == '00000000') return f[0]; }
return '';
}
function busy(c, st, now, sp) {
let dev = rjs('/tmp/wf-line.json')?.dev || rdev();
if (!length(dev)) return;
let rx = +trim(readfile((getenv('WF_SYSNET') ?? '/sys/class/net') + '/' + dev + '/statistics/rx_bytes') ?? '0'), dt = now - +(st.bt ?? 0);
let ok = st.bdev == dev && st.brx != null && rx >= st.brx && dt > 0 && dt <= 120, oth = ok ? (rx - st.brx) / dt - sp : 0;
st.bdev = dev; st.brx = rx; st.bt = now;
let lg = type(st.blog) == 'array' ? st.blog : [];
if (!c.busy || !ok) { if (!c.busy && st.busy) { if (length(lg)) lg[0].end = now; st.busy = 0; st.bwho = ''; } st.blog = lg; return; }
if (oth >= BUSYON) {
st.bfree = 0;
if (!st.busy) {
let w = topdev();
st.busy = now; st.bwho = w.name;
unshift(lg, { t: now, end: 0, who: w.name, mac: w.mac });
}
}
else if (st.busy && oth < BUSYOFF) {
st.bfree = (st.bfree ?? 0) + 1;
if (st.bfree >= 2) { if (length(lg)) lg[0].end = now; st.busy = 0; st.bwho = ''; st.bfree = 0; }
}
st.blog = slice(lg, 0, 10);
}
function control(c, G, st, now, root, X, D) {
let M = jall(root), P = probes(), calls = [], ch = {};
if (isfat(diskof(D ?? [], c.disk))) for (let x in X) {
let m = M[x.gid];
if (P[x.gid] || !m || m.fat4g === true || index([ 'active', 'waiting', 'paused' ], x.status) < 0 || !fatbig(x)) continue;
if (x.status != 'paused') rpc('aria2.forcePause', [ x.gid ]);
m.fat4g = true; m.paused = true; jput(root, x.gid, m); x.status = 'paused';
ev('nas_dl_fat', '⚠️ Download ¦ ' + cutu(aname(x, m), 60) + ' ¦ ' + L('Il disco è FAT32: un file al massimo 4 GB', 'The drive is FAT32: 4 GB per file at most'), true);
}
if (!G.hold) for (let x in X) {
if (P[x.gid]) continue;
let m = M[x.gid], w = want(m, G);
if (x.status == 'paused' && w) {
push(calls, [ 'aria2.unpause', [ x.gid ] ]);
if (m && m.when && m.when != 'now') { m.when = 'now'; delete m.until; ch[x.gid] = m; }
}
else if ((x.status == 'active' || x.status == 'waiting') && !w) push(calls, [ 'aria2.pause', [ x.gid ] ]);
}
if (length(calls)) rpcm(calls);
for (let g, m in ch) jput(root, g, m);
if (c.adv.retry && !G.hold) for (let x in X) {
if (x.status != 'error' || P[x.gid]) continue;
let m = M[x.gid] ?? {};
if (+(m.tries ?? 0) < 3 && now - +(m.tt ?? 0) >= 300) retry(c, root, x, m, G);
}
if (st.lim !== G.kbs || now - +(st.limt ?? 0) >= 600) {
if (rpc('aria2.changeGlobalOption', [ { 'max-overall-download-limit': G.kbs + 'K' } ]) != null) { st.lim = G.kbs; st.limt = now; }
}
let mo = dlmem(c, amem()), mk = mo['bt-max-peers'] + '/' + mo['max-download-result'];
if (st.memk !== mk || now - +(st.memt ?? 0) >= 600) {
if (rpc('aria2.changeGlobalOption', [ mo ]) != null) { st.memk = mk; st.memt = now; }
}
if (G.reason == 'sim' && st.reason != 'sim' && st.simev != (G.sim?.renew ?? '')) {
st.simev = G.sim?.renew ?? '';
let rn = match(st.simev, /^[0-9]{4}-([0-9]{2})-([0-9]{2})$/);
ev('nas_dl_sim', '⚠️ Download ¦ ' + L('Fermi per la SIM', 'Stopped for the SIM') + ' ¦ SIM ' + (G.sim?.slot ?? 1) + ' ' + L('al', 'at') + ' ' + (G.sim?.pct ?? 0) + '%' +
(rn ? L(' · rinnovo ', ' · renews ') + rn[2] + '/' + rn[1] : ''), true);
}
st.reason = G.reason;
}
function probeclean(now) {
let calls = [];
for (let g, p in probes()) if (now - +(p.t ?? 0) >= 120) { push(calls, [ 'aria2.remove', [ g ] ], [ 'aria2.removeDownloadResult', [ g ] ]); pdel(g); }
if (length(calls)) rpcm(calls);
}
function doneclean(c, root, now, D) {
if (!root || !c.adv.keep_days) return;
for (let r in dones(root)) {
if (!doneold(c, r, now)) continue;
let p = length(r.path ?? '') ? absof(D, r.disk ?? c.disk, r.path) : null;
if (diskof(D, r.disk ?? c.disk) && (!p || !lstat(p))) unlink(root + '/.wf-dl/done/' + r.id + '.json');
}
}
function follow(c, st, down, force) {
if (!c.on || !length(c.disk)) return false;
let mj = rjs(TMP + '/mnt.json'), mp = type(mj) == 'object' ? mj[c.disk] : null, cd = confdir(), now = time();
if (type(mp) == 'string') { if (cd == mp + (c.path == '/' ? '' : c.path) || (!force && now - +(st.fwt ?? 0) < 60)) return false; }
else if (!down || (!force && now - +(st.fwt ?? 0) < 300)) return false;
st.fwt = now;
let D = disks(), root = droot(c, D);
if (!root || root == cd) return false;
dlwrite(c, D);
detach('sh ' + q(SH) + ' svc on');
return true;
}
function tick() {
begin();
let N = nget(), d = N.dl;
if (d.on !== true) { ownw([], null); return { on: false }; }
if (d.night != null) { if (type(d.sched) != 'object') d.sched = { mode: d.night === true ? 'night' : 'always', bands: [] }; delete d.night; nput(N); }
let c = dcfg(d, N), now = time(), lt = localtime(now), st = rjs(ST) ?? {};
let g = rpc('aria2.getGlobalStat', []), f0 = st.fwt;
if (follow(c, st, g == null, false)) { wjs(ST, st); return { on: true, run: false, follow: true }; }
if (g == null) { if (st.fwt != f0) wjs(ST, st); return { on: true, run: false }; }
let n = +(g.numActive ?? 0) + +(g.numWaiting ?? 0) + +(g.numStopped ?? 0), sp = +(g.downloadSpeed ?? 0);
hist(st, now, sp);
let root = null, D = null;
if (n > 0) {
busy(c, st, now, sp);
D = disks();
let G = decide(c, st, lt, D), X = alist();
root = droot(c, D);
if (G.nodisk || G.mainp) { if (length(filter(X ?? [], (x) => x.status == 'active' || x.status == 'waiting'))) rpc('aria2.pauseAll', []); }
else if (root && confdir() != root) { dlwrite(c, D); detach('sh ' + q(SH) + ' svc on'); }
else if (X != null) control(c, G, st, now, root, X, D);
if (X != null) {
let M = jall(root), P = probes();
ownw(map(filter(X, (x) => !P[x.gid] && x.status != 'complete'), (x) => ({ own: ownof(M[x.gid]),
state: x.status == 'active' && (G.hold || !want(M[x.gid], G)) ? 'pause' : jstate(x, M[x.gid], G), v: +(x.downloadSpeed ?? 0) })), G);
}
}
else { st.brx = null; if (st.busy) { st.busy = 0; st.bwho = ''; } st.reason = ''; ownw([], decide(c, st, lt, null)); }
if (length(lsdir(PROBE) ?? [])) probeclean(now);
if (now - +(st.clean ?? 0) >= 3600) { if (!D) { D = disks(); root = droot(c, D); } doneclean(c, root, now, D); st.clean = now; }
wjs(ST, st);
return { on: true, run: true, n: n };
}

function dldone(kind, gid, file) {
begin();
gid = '' + gid;
if (!match(gid, GID)) return null;
if (stat(PROBE + '/' + gid + '.json')) return { probe: true };
let N = nget(), D = disks(), c = dcfg(N.dl, N), root = droot(c, D), m = jget(root, gid) ?? {}, own = ownof(m);
let x = rpc('aria2.tellStatus', [ gid, KEYS ]) ?? {};
if (type(x.followedBy) == 'array' && length(x.followedBy)) {
for (let g in x.followedBy) if (match('' + g, GID)) jput(root, g, m);
jdel(root, gid);
rpc('aria2.removeDownloadResult', [ gid ]);
return { follow: x.followedBy };
}
let name = aname(x, m);
if (kind != 'ok') {
m.tries = +(m.tries ?? 0) + 1; m.tt = time(); m.code = +(x.errorCode ?? 0);
jput(root, gid, m);
let last = !c.adv.retry || m.tries >= 3, w = whyx(m.code);
let pn = own != 'admin' ? sprintf(L('%s: un download non riesce', '%s: a download is failing'), visof(N, own)) : null;
let evd = (id, why) => {
if (!pn) return ev(id, '⚠️ Download ¦ ' + why + ' ¦ ' + short(name), false, own);
ev(id, '⚠️ Download ¦ ' + pn + ' ¦ ' + why, false, null);
ev(id, '⚠️ Download ¦ ' + why + ' ¦ ' + short(name), false, own, true);
};
if (m.code == 9) { let f = TMP + '/dl-space'; if (time() - +trim(readfile(f) ?? '0') >= 86400) { writefile(f, '' + time());
evd('nas_dl_space', L('Disco pieno', 'Disk full')); } }
else if (last) evd('nas_dl_err', L(w[0], w[1]));
return { err: m.code, last: last };
}
let multi = x.bittorrent?.info?.name && length(x.files ?? []) > 1, src = multi ? x.dir + '/' + x.bittorrent.info.name : (length(file ?? '') ? file : x.files?.[0]?.path);
let dk = diskof(D, c.disk), big = name;
if (multi) { let bs = -1; for (let f in x.files) if (+(f.length ?? 0) > bs && f.selected != 'false') { bs = +(f.length ?? 0); big = f.path; } }
let ud = length(m.dir ?? '') ? udest(dk, own, m.dir, N).x : null;
let ty = ftype(big), dst = src, td = ud ? ud.rel : tdir(c, own, big), to = dk && td ? absof(D, dk.id, td) : null, C = [];
if (src && to && lstat(src) && dirof(src) != to && index(src, dk.mnt + '/') == 0) {
C = mkdirp(to);
let nm = freename(to, bname(src));
if (nm && rename(src, to + '/' + nm)) dst = to + '/' + nm;
}
if (dk && dst && index(dst, dk.mnt + '/') == 0 && lstat(dst)) push(C, dst);
if (length(C)) sh('chmod -R a+rX ' + join(' ', map(C, (x) => q(x))) + ' 2>/dev/null');
if (dk && dst && index(dst, dk.mnt + '/') == 0 && lstat(dst)) {
let lf = TMP + '/dl-own.' + PID;
if (writefile(lf, dst + '\n') != null)
sh('WFO_F=' + q(getenv('WF_NASFUC') ?? '/usr/share/wrtfreedom/nasf.uc') + ' WFO_M=' + q(dk.mnt) + ' WFO_W=' + q(own ?? '') + ' WFO_L=' + q(lf) +
' ucode -e "loadfile(getenv(\'WFO_F\'))().ownfix();" </dev/null >/dev/null 2>&1; rm -f ' + q(lf));
}
if (match(x.infoHash ?? '', /^[0-9a-f]{40}$/) && x.dir) unlink(x.dir + '/' + x.infoHash + '.torrent');
let rel = dk && dst && index(dst, dk.mnt + '/') == 0 ? substr(dst, length(dk.mnt)) : '/' + bname(dst ?? name);
let rec = { id: gid, name: bname(dst ?? name), disk: dk?.id ?? c.disk, path: rel, size: +(x.totalLength ?? 0), type: ty, t: time(), added: m.t ?? 0, url: m.url ?? '',
from: m.from ?? '', via: m.via ?? '', tor: x.bittorrent != null, own: own };
let cerr = null;
if (length(m.cloud ?? '')) {
if (x.bittorrent != null && x.status != 'complete' && x.status != 'removed') rpcm([ [ 'aria2.forceRemove', [ gid ] ] ]);
let cd = UCFG.udir(own, 'dl'), on = dk && dst && index(dst, dk.mnt + '/') == 0 && lstat(dst);
let r = on && cd != null ? ccall(own, { act: 'xfer', kind: 'up', id: m.cloud, disk: dk.id, src: rel, to: '/' + cd, move: true }) :
err('path', 'File non trovato sul disco', 'File not found on the disk');
if (type(r?.job) == 'string' && match(r.job, JOBID)) rec.cloud = { acct: m.cloud, job: r.job, to: '/' + cd };
else { cerr = r; rec.cloud = { acct: m.cloud, job: '', state: 'err', why: r?.error ?? '', why_en: r?.error_en ?? '', code: r?.code ?? 'cloud' }; }
}
if (root) { mkdirp(root + '/.wf-dl/done'); wjs(root + '/.wf-dl/done/' + gid + '.json', rec); }
jdel(root, gid);
rpc('aria2.removeDownloadResult', [ gid ]);
wjs(TMP + '/dl-last.json', rec);
if (c.notify) ev('nas_dl_ok', '💾 Download ¦ ' + (rec.cloud && !cerr ? L('Completato, va nel cloud', 'Completed, going to the cloud') : L('Completato', 'Completed')) + ' ¦ ' + short(rec.name), false, own);
if (cerr) {
let w = L('Non mandato nel cloud', 'Not sent to the cloud') + (length(cerr.error ?? '') ? ': ' + L(cerr.error, cerr.error_en ?? cerr.error) : '');
if (own == 'admin') ev('nas_dl_err', '⚠️ Download ¦ ' + w + ' ¦ ' + short(rec.name), false, own);
else { ev('nas_dl_err', '⚠️ Download ¦ ' + sprintf(L('%s: un download non riesce', '%s: a download is failing'), visof(N, own)) + ' ¦ ' + L('Non mandato nel cloud', 'Not sent to the cloud'), false, null);
ev('nas_dl_err', '⚠️ Download ¦ ' + w + ' ¦ ' + short(rec.name), false, own, true); }
}
if (c.adv.media && !(rec.cloud && !cerr) && index([ 'video', 'music', 'photo' ], ty) >= 0) {
let f = TMP + '/dl-scan';
if (time() - +trim(readfile(f) ?? '0') >= 60) { writefile(f, '' + time()); detach('ubus call wrtfreedom nas_media ' + q('{"act":"scan"}')); }
}
return rec;
}

function isint(v, a, b) { return type(v) == 'int' && v >= a && v <= b; }
function setopts(d, A) {
if (A.max_kbs != null) { if (!isint(A.max_kbs, 0, 10000000)) return err('max', 'Velocità non valida', 'Invalid speed'); d.max_kbs = A.max_kbs; }
if (type(A.night) == 'bool' && A.sched == null) { d.sched = { mode: A.night ? 'night' : 'always', bands: dcfg(d).sched.bands }; delete d.night; }
if (A.sched != null) {
let s = A.sched, B = s?.bands ?? dcfg(d).sched.bands, o = [];
if (type(s) != 'object' || index([ 'always', 'night', 'bands' ], s.mode) < 0 || type(B) != 'array' || length(B) > 8) return err('sched', 'Pianificazione non valida', 'Invalid schedule');
for (let b in B) {
if (type(b) != 'object' || hm(b.from) == null || hm(b.to) == null || !isint(b.kbs ?? 0, 0, 10000000)) return err('sched', 'Fascia non valida', 'Invalid time band');
let dy = b.days;
if (dy != null && (type(dy) != 'array' || length(filter(dy, (x) => !isint(x, 0, 6))))) return err('sched', 'Giorni non validi', 'Invalid days');
push(o, { from: b.from, to: b.to, kbs: b.kbs ?? 0, ...(dy != null && length(dy) ? { days: map(uniq(dy), (x) => +x) } : {}) });
}
if (s.mode == 'bands' && !length(o)) return err('sched', 'Aggiungi almeno una fascia', 'Add at least one time band');
d.sched = { mode: s.mode, bands: o };
delete d.night;
}
if (A.sim_at != null) { if (index([ 0, 70, 80, 90 ], A.sim_at) < 0) return err('sim', 'Soglia non valida', 'Invalid threshold'); d.sim_at = A.sim_at; }
if (A.busy_kbs != null) { if (!isint(A.busy_kbs, 50, 100000)) return err('busy_kbs', 'Velocità non valida', 'Invalid speed'); d.busy_kbs = A.busy_kbs; }
for (let k in [ 'sim_backup', 'busy', 'notify' ]) if (A[k] != null) { if (type(A[k]) != 'bool') return err(k, 'Valore non valido', 'Invalid value'); d[k] = A[k]; }
if (A.adv != null) {
let a = A.adv, X = dcfg(d).adv;
if (type(a) != 'object') return err('adv', 'Valore non valido', 'Invalid value');
for (let k, v in ADV) if (type(v) == 'bool' && a[k] != null) { if (type(a[k]) != 'bool') return err(k, 'Valore non valido', 'Invalid value'); X[k] = a[k]; }
let R4 = { conc: [ 1, 5 ], keep_days: [ 0, 365 ], up_kbs: [ 0, 100000 ], peers: [ 5, 200 ] };
for (let k, r in R4) if (a[k] != null) { if (!isint(a[k], r[0], r[1])) return err(k, 'Valore non valido', 'Invalid value'); X[k] = a[k]; }
d.adv = X;
}
return null;
}
function turnon(d, D, c) {
let pk = need(); if (length(pk)) return pkgerr(pk);
if (!length(c.disk) || stat(RUNMAIN) != null) return NOMAIN();
let dk = diskof(D, c.disk);
if (!dk) return NOMAIN();
if (rod(dk)) return err('ro', 'Il disco è in sola lettura', 'The disk is read-only');
if (!absof(D, dk.id, DLDIR)) return err('path', 'Cartella non valida', 'Invalid folder');
delete d.disk; delete d.path; d.on = true;
return null;
}

const M = {
nas_dl: {
args: { act: 'x', url: 'x', id: 'x', gid: 'x', b64: 'x', when: 'x', files: [], via: 'x', from: 'x', dir: 'x', on: true, max_kbs: 0, own: 'x',
night: true, sched: {}, sim_at: 0, sim_backup: true, busy: true, busy_kbs: 0, adv: {}, notify: true, cloud: 'x', as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let W = whoof(req);
if (W.error) return W;
let A = req.args ?? {}, a = A.act ?? 'get', N = nget(), d = N.dl, D = disks(), now = time();
let res = (x) => ({ ...view(N, D, W), ...(x ?? {}) });
if (a == 'get') return res();
let c = dcfg(d, N), root = droot(c, D), st = rjs(ST) ?? {}, G = decide(c, st, localtime(now), D);
let up = () => d.on === true && length(secret()) && rpc('aria2.getVersion', []) != null;
let mine = (m) => ownof(m) == W.own, nf = () => err('id', 'Download non trovato', 'Download not found');
let oth = () => W.adm ? err('private', 'Download di una persona: usa la sua riga', 'A person\'s download: use their row') : nf();
if ((a == 'set' || a == 'test' || a == 'pause_own' || a == 'resume_own') && !W.adm) return ADM();
if (a == 'pause_own' || a == 'resume_own') {
let u = A.own, x = type(u) == 'string' && type(N.users) == 'object' ? N.users[u] : null;
if (type(x) != 'object' || x.cam || !match(u, /^[A-Za-z0-9._-]+$/) || u == 'admin') return err('own', 'Persona non trovata', 'Person not found');
d.ppause = a == 'pause_own' ? uniq([ ...c.ppause, u ]) : filter(c.ppause, (y) => y != u);
if (!nput(N)) return busyerr();
c = dcfg(d, N);
if (up()) { let X = alist(); if (X != null) { control(c, decide(c, st, localtime(now), D), st, now, root, X); wjs(ST, st); } }
return res();
}
if (a == 'test') { ev('nas_dl_ok', '💾 Download ¦ ' + L('Avviso di prova', 'Test notice') + ' ¦ ' + L('Completato', 'Completed'), true); return res({ sent: true }); }
if (index([ 'pause', 'resume', 'del', 'retry', 'top', 'rm' ], a) >= 0) {
let g = '' + (A.id ?? '');
if (match(g, JOBID)) return err('cloudrow', 'Si comanda dalla pagina del Cloud', 'Manage it from the Cloud page');
if (!match(g, GID)) return nf();
if (a == 'rm') {
let f = root ? root + '/.wf-dl/done/' + g + '.json' : null;
if (!mine(f ? rjs(f) : null)) return oth();
if (f) unlink(f);
rpc('aria2.removeDownloadResult', [ g ]);
return res();
}
let m = jget(root, g) ?? {};
if (!mine(m)) return oth();
if (!up()) return err('rpc', 'Download non raggiungibile', 'Downloads not reachable');
if (a == 'pause') { m.paused = true; jput(root, g, m); rpc('aria2.pause', [ g ]); return res(); }
if (a == 'resume') {
m.paused = false; m.when = 'now'; delete m.until; jput(root, g, m);
if (want(m, G) && !G.hold) rpc('aria2.unpause', [ g ]);
return res();
}
if (a == 'top') { if (rpc('aria2.changePosition', [ g, 0, 'POS_SET' ]) == null) return err('id', 'Download non trovato', 'Download not found'); return res(); }
if (a == 'del') {
rpcm([ [ 'aria2.remove', [ g ] ], [ 'aria2.removeDownloadResult', [ g ] ] ]);
jdel(root, g);
return res();
}
let x = rpc('aria2.tellStatus', [ g, KEYS ]);
if (x?.status != 'error') return err('id', 'Download non trovato', 'Download not found');
m.tries = 0;
let ng = retry(c, root, x, m, G);
if (!ng) return err('retry', 'Link non più disponibile', 'Link no longer available');
return res({ id: ng });
}
if (a == 'pauseall' || a == 'resumeall') {
if (W.adm) {
d.user = a == 'pauseall';
if (a == 'resumeall' && G.simp && G.sim) d.simok = G.sim.renew;
}
else d.ppause = a == 'pauseall' ? uniq([ ...c.ppause, W.own ]) : filter(c.ppause, (u) => u != W.own);
if (!nput(N)) return busyerr();
c = dcfg(d, N);
if (up()) {
if (a == 'pauseall' && W.adm) rpc('aria2.pauseAll', []);
else { let X = alist(); if (X != null) { control(c, decide(c, st, localtime(now), D), st, now, root, X); wjs(ST, st); } }
}
return res();
}
if (a == 'probe' || a == 'torrent') {
if (G.mainp) return NOMAIN();
let s = G.sim, free = root ? freeb(root) : 0, run = up(), id = '' + (A.gid ?? A.id ?? ''), P = null, x = null, u = '';
if (length(id)) {
P = match(id, GID) ? rjs(PROBE + '/' + id + '.json') : null;
if (!P) return nf();
if (!mine(P)) return oth();
u = P.url ?? ''; x = run ? rpc('aria2.tellStatus', [ id, KEYS ]) : null;
}
else if (a == 'torrent') {
let b = '' + (A.b64 ?? '');
if (!length(b) || length(b) > 1398104 || !match(b, /^[A-Za-z0-9+\/=]+$/)) return err('torrent', 'Torrent non valido (al massimo 1 MB)', 'Invalid torrent (1 MB at most)');
if (!run) return err('off', 'Accendi prima i download', 'Turn on downloads first');
id = newgid();
if (rpc('aria2.addTorrent', [ b, [], { gid: id, pause: 'true' } ]) == null) return err('torrent', 'Torrent non valido', 'Invalid torrent');
mkdir(PROBE); P = { tor: true, t: now, own: W.own }; wjs(PROBE + '/' + id + '.json', P);
x = rpc('aria2.tellStatus', [ id, KEYS ]);
}
else {
u = '' + (A.url ?? '');
if (!urlok(u)) return err('url', 'Link non valido', 'Invalid link');
if (run && substr(u, 0, 7) != 'magnet:') {
id = newgid();
if (rpc('aria2.addUri', [ [ u ], { gid: id, 'dry-run': 'true' } ]) != null) {
mkdir(PROBE); P = { url: u, t: now, own: W.own }; wjs(PROBE + '/' + id + '.json', P);
rpc('aria2.changePosition', [ id, 0, 'POS_SET' ]);
x = rpc('aria2.tellStatus', [ id, KEYS ]);
}
else id = '';
}
}
if (x?.status == 'error') { let w = whyx(x.errorCode); rpcm([ [ 'aria2.removeDownloadResult', [ id ] ] ]); pdel(id); return err('url', w[0], w[1]); }
let size = +(x?.totalLength ?? 0), name = x ? aname(x, { url: u }) : uname(u), tor = P?.tor === true, fl = [];
if (tor) for (let i = 0; i < length(x?.files ?? []) && i < 500; i++) { let f = x.files[i]; push(fl, { n: +(f.index ?? (i + 1)), name: bname(f.path ?? ''), size: +(f.length ?? 0) }); }
let ty = ftype(name), when = s && simpause(c, s) ? 'renew' : (s && size > 0 && size > s.left && c.sim_at > 0 && s.line ? 'renew' : (G.reason == 'night' ? 'night' : 'now'));
return { gid: id, name: name, size: size, type: ty, dir: dname(tdir(c, W.own, name) ?? ''), fits_disk: size == 0 || size + 52428800 < free, free: free,
sim_left: s ? s.left : null, renew: s?.renew ?? '', when: when, ready: tor || size > 0 || x == null || x.status == 'complete', tor: tor, files: fl, on: c.on,
fat4g: isfat(diskof(D, c.disk)) && fatbig(x) };
}
let CL = null;
if (a == 'add' && A.cloud != null && A.cloud !== '') {
if (A.dir != null && A.dir !== '') return err('dir', 'Scegli una cartella del disco o il cloud', 'Pick a disk folder or the cloud');
let pid = '' + (A.gid ?? A.id ?? ''), P = null, u = '';
if (length(pid)) { P = match(pid, GID) ? rjs(PROBE + '/' + pid + '.json') : null; if (!P) return nf(); if (!mine(P)) return oth(); u = P.url ?? ''; }
else { u = '' + (A.url ?? ''); if (!urlok(u)) return err('url', 'Link non valido', 'Invalid link'); }
let ca = cacct(A.cloud, W.own);
if (ca.e) return ca.e;
if (P?.tor !== true && curl(u)) {
let r = ccall(W.own, { act: 'xfer', kind: 'url', id: A.cloud, url: u });
if (type(r?.job) != 'string') return r;
if (P) { rpcm([ [ 'aria2.remove', [ pid ] ], [ 'aria2.removeDownloadResult', [ pid ] ] ]); pdel(pid); }
return res({ id: r.job, added: true, cloud_job: r.job, night_wait: false });
}
if (G.mainp || !length(c.disk) || !diskof(D, c.disk))
return err('nodisk_cloud', 'Per un torrent nel cloud serve il Disco Principale: il router lo scarica lì e poi lo sposta nel cloud',
'A torrent to the cloud needs the Main Drive: the router downloads it there, then moves it to the cloud');
CL = A.cloud;
}
if (a == 'set' || a == 'add') {
if (a == 'add' && !W.adm && d.on !== true) return err('off', 'Download spenti: chiedi all\'Amministratore', 'Downloads are off: ask the Administrator');
if (a == 'add' && !W.adm && G.full[W.own]) return { ...err('quota_full', 'Spazio finito: libera spazio o chiedi più spazio', 'No space left: free up space or ask for more'), pct: 100 };
if (a == 'add' || A.on === true) { let e = turnon(d, D, c); if (e) return e; }
if (A.on === false) d.on = false;
if (a == 'set') { let e = setopts(d, A); if (e) return e; }
oursset(N, 'wf-nasdl', d.on === true);
c = dcfg(d, N); root = droot(c, D);
let pid = '' + (A.gid ?? A.id ?? ''), P = null, u = '', via = index(VIA, A.via) >= 0 ? A.via : 'app', when = index([ 'now', 'night', 'renew' ], A.when) >= 0 ? A.when : 'now', od = null, fl = [], dd = null;
if (a == 'add') {
if (length(pid)) { P = match(pid, GID) ? rjs(PROBE + '/' + pid + '.json') : null; if (!P) return nf(); if (!mine(P)) return oth(); u = P.url ?? ''; }
else { u = '' + (A.url ?? ''); if (!urlok(u)) return err('url', 'Link non valido', 'Invalid link'); }
od = odir(root, W.own);
if (!od) return err('path', 'Cartella non valida', 'Invalid folder');
if (A.dir != null && A.dir !== '') { let y = udest(diskof(D, c.disk), W.own, A.dir, N); if (!y.x) return desterr(y.e); dd = y.x.rel; }
for (let n in (type(A.files) == 'array' ? A.files : [])) { if (!isint(n, 1, 100000)) return err('files', 'File non validi', 'Invalid files'); push(fl, n); }
if ((via == 'bot' || via == 'ai') && length(filter(values(jall(root)), (m) => m.via == 'bot' || m.via == 'ai')) >= 20)
return err('max', 'Al massimo 20 download in coda dal bot e dall\'IA', 'At most 20 queued downloads from the bot and the AI');
}
if (!nput(N)) return busyerr();
let nd = d.on ? dlwrite(c, D) : false;
let ans = up(), run = ans;
if (run && d.on && nd) run = false;
if (run && a == 'set') rpc('aria2.changeGlobalOption', [ { ...dlopts(c), 'max-overall-download-limit': decide(c, st, localtime(now), D).kbs + 'K' } ]);
if (!d.on) { detach('sh ' + q(SH) + ' svc off'); return res({ drop: [ 'aria2' ] }); }
if (a == 'set') { if (!run) detach('sh ' + q(SH) + ' svc on'); return res(); }
if (!ans && listening()) return err('rpc', 'Download non raggiungibile', 'Downloads not reachable');
let restart = !run;
let m = { url: P?.tor ? '' : u, name: P?.tor ? '' : uname(u), from: cutp(A.from), via: via, when: when, t: now, tries: 0, own: W.own };
if (length(fl)) m.files = fl;
if (dd != null) m.dir = dd;
if (CL) m.cloud = CL;
if (when == 'renew') { if (G.sim?.renew) m.until = G.sim.renew; else m.when = 'now'; }
G = decide(c, st, localtime(now), D);
let w = want(m, G) && !G.hold, gid = null, opt = { pause: w ? 'false' : 'true', dir: od };
if (length(fl)) opt['select-file'] = join(',', fl);
if (P?.tor) {
gid = pid;
if (!ans || rpc('aria2.tellStatus', [ gid, [ 'gid' ] ]) == null) return err('rpc', 'Download non raggiungibile', 'Downloads not reachable');
let co = { dir: od };
if (length(fl)) co['select-file'] = opt['select-file'];
rpcm(filter([ [ 'aria2.changeOption', [ gid, co ] ], w ? [ 'aria2.unpause', [ gid ] ] : null ], (x) => x != null));
pdel(pid);
}
else {
if (P) { rpcm([ [ 'aria2.remove', [ pid ] ], [ 'aria2.removeDownloadResult', [ pid ] ] ]); pdel(pid); }
gid = newgid(); opt.gid = gid;
if (run && rpc('aria2.addUri', [ [ u ], opt ]) != gid) return err('rpc', 'Download non raggiungibile', 'Downloads not reachable');
if (!run) {
if (!root) return err('disk', 'Disco non collegato', 'Disk not connected');
let f = root + '/.wf-aria2.session.add';
if ((stat(f)?.size ?? 0) > 262144) return err('max', 'Troppi download in coda: aspetta che partano', 'Too many queued downloads: wait for them to start');
let ln = u + '\n gid=' + gid + '\n dir=' + od + '\n' + (opt.pause == 'true' ? ' pause=true\n' : '') + (length(fl) ? ' select-file=' + opt['select-file'] + '\n' : '');
let t = f + '.' + PID + '.t';
writefile(t, (readfile(f) ?? '') + ln);
rename(t, f);
restart = true;
}
}
jput(root, gid, m);
if (restart) detach('sh ' + q(SH) + ' svc on');
if ((via == 'share' || via == 'shortcut') && length(m.from)) {
d.phones = slice([ { name: m.from, via: via, t: now, own: W.own }, ...filter(c.phones, (p) => p.name != m.from || ownof(p) != W.own) ], 0, 10);
nput(N);
}
return res({ id: gid, added: true, night_wait: !w });
}
return err('act', 'Azione sconosciuta', 'Unknown action');
}
},
tick: tick,
dldone: dldone,
follow: function() {
begin();
let N = nget(), c = dcfg(N.dl, N), st = rjs(ST) ?? {}, r = follow(c, st, rpc('aria2.getVersion', []) == null, true);
if (st.fwt) wjs(ST, st);
return { did: r ? [ 'dl' ] : [] };
},
rpc: rpc
};

return M;
