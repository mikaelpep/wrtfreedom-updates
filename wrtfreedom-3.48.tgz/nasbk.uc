'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, open } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', NJ = ETC + '/nas.json', XJ = ETC + '/nasx.json', BKD = ETC + '/nas-bak';
const RCONF = ETC + '/cloud-rclone.conf', OLDRC = ETC + '/nasx-rclone.conf', CDIR = ETC + '/nasx-cloud';
const CLOUDUC = getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc', CTMP = '/tmp/wf-cloud';
const TMP = '/tmp/wf-nas', X = TMP + '/x', JOBS = TMP + '/jobs';
const SH = getenv('WF_NASBKSH') ?? '/usr/share/wrtfreedom/nasbk.sh';
const XSH = getenv('WF_NASXSH') ?? '/usr/share/wrtfreedom/nasx.sh';
const VUC = getenv('WF_NASVCUC') ?? '/usr/share/wrtfreedom/nasvc.uc';
const BMAX = 20, CMAX = 10, PMAX = 20, PCHUNK = 4194304, DAY = 86400;
const ADV = { warn_phone: 7, warn_pc: 10, warn_task: 2, full: 'prune', cap: 80, verify: true };

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(R + p) != null; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
function rid() { return substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10) || ('' + time()); }
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
function wput(f, s) { let t = f + '.' + PID + '.t'; if (writefile(t, s) === length(s) && rename(t, f)) return true; unlink(t); return false; }
function wjs(f, o) { return wput(f, sprintf('%J', o)); }
function wif(f, s) { if (readfile(f) == s) return false; return wput(f, s); }
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
function mkdirp(p) { let c = ''; for (let x in split(p, '/')) { if (!length(x)) continue; c += '/' + x; if (!stat(c)) mkdir(c); } }
function uniq(a) { let s = {}, r = []; for (let x in a) { x = '' + x; if (length(x) && !s[x]) { s[x] = 1; push(r, x); } } return r; }
function alive(p) { return match('' + p, /^[0-9]+$/) != null && stat('/proc/' + p) != null; }
function absn(x) { return x < 0 ? -x : x; }
function num(s) { let m = match('' + (s ?? ''), /^[0-9]+/); return m ? +m[0] : 0; }
function macok(x) { return match('' + x, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) != null; }
function macs(a) { return slice(filter(uniq(map(type(a) == 'array' ? a : split('' + (a ?? ''), /[ \t]+/), (x) => lc('' + x))), macok), 0, 64); }
const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
const hk = UCFG.hk, b64d = UCFG.b64d;
function ud(own, k, sub, N) { let p = UCFG.udir(own ?? 'admin', k, sub, N ?? (rjs(NJ) ?? {})); return p == null ? null : '/' + p; }
function ownof(x) { return type(x?.own) == 'string' && length(x.own) ? x.own : 'admin'; }

function cfg(name) { return UCFG.read((getenv('WF_CFGDIR') ?? '/etc/config/') + name, false); }

let LG = 'it';
let DRV = null;
let PHDD = false;
function L(it, en) { return LG == 'en' ? en : it; }
function err(code, it, en, x) { let r = { error: it, error_en: en, code: code }; for (let k, v in x ?? {}) r[k] = v; return r; }
function begin() { LG = cfg('wrtfreedom')?.ui?.lang == 'en' ? 'en' : 'it'; PHDD = false; mkdirp(X); mkdir(ETC); }
function ev(t, txt, tg) { detach((tg ? 'WF_TG=1 ' : '') + 'sh ' + q(R + '/usr/share/wrtfreedom/event.sh') + ' cron ' + t + ' nas ' + q(txt)); }

function nget() {
let N = rjs(NJ) ?? {};
if (type(N.backups) != 'array') N.backups = [];
if (type(N.bk) != 'object') N.bk = {};
return N;
}
const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function nsave(fn) {
mkdirp(TMP);
if (!njlock()) return null;
let N = null;
try { N = nget(); fn(N); mkdirp(ETC); wjs(NJ, N); } catch (e) { N = null; }
njunlock();
return N;
}
function busy() { return err('busy', 'Impostazioni occupate: riprova', 'Settings busy: try again'); }
const XLK = TMP + '/cmig.lock';
let XHELD = false, XSN = [];
function xsnap(o) {
let s = json(sprintf('%J', o));
for (let e in XSN) if (e[0] === o) { e[1] = s; return; }
push(XSN, [ o, s ]);
while (length(XSN) > 16) shift(XSN);
}
function xmrg(D, o, S) {
for (let k, v in o) {
let s = S[k];
if (type(v) == 'object' && type(s) == 'object' && type(D[k]) == 'object') xmrg(D[k], v, s);
else if (s == null || sprintf('%J', v) != sprintf('%J', s)) D[k] = v;
}
let K = keys(o);
for (let k in keys(S)) if (index(K, k) < 0) delete D[k];
}
function xget() {
let o = rjs(XJ) ?? {};
if (type(o.cloud) != 'array') o.cloud = [];
if (type(o.photo) != 'object') o.photo = {};
if (type(o.photo.phones) != 'object') o.photo.phones = {};
xsnap(o);
return o;
}
function nason() { return (rjs(NJ) ?? {}).on !== false; }
function advof(N) {
let A = type(N.bk?.adv) == 'object' ? N.bk.adv : {}, r = {};
for (let k, v in ADV) r[k] = A[k] ?? v;
return r;
}

const SYS = getenv('WF_SYS') ?? '/sys';
function blkinfo(ML) { return UCFG.blkinfo(ML, { sys: SYS, run: TMP, sh, rj: rjs, wjr: wjs, mkdirp }); }
function disks() {
let D = UCFG.nasdisks(R, rjs(NJ) ?? {}, blkinfo);
let s = sprintf('%J', { fp: hk(sprintf('%J', D)), list: D });
wif(X + '/disks.json', s);
return D;
}
function diskof(D, id) { for (let d in D) if (d.id == id) return d; return null; }
function relok(p) {
p = '' + (p ?? '');
if (!length(p)) p = '/';
if (substr(p, 0, 1) != '/' || length(p) > 1024 || match(p, /[[:cntrl:]\\]/)) return null;
p = replace(p, /\/+/g, '/');
for (let s in split(p, '/')) if (s == '..' || s == '.') return null;
if (length(p) > 1 && substr(p, -1) == '/') p = substr(p, 0, length(p) - 1);
return p;
}
function rpath(p) { let f = require('fs').realpath, r = null; if (type(f) != 'function') return null; try { r = f(p); } catch (e) { r = null; } return r; }
function inside(root, p) {
if (type(require('fs').realpath) != 'function') return true;
let x = p;
while (length(x) > length(root) && !lstat(x)) x = replace(x, /\/[^\/]*$/, '');
let rp = rpath(x), rr = rpath(root) ?? root;
return rp != null && (rp == rr || index(rp, rr + '/') == 0);
}
function dirof(p) { return replace(p, /\/[^\/]*$/, '') || '/'; }
function absof(D, id, rel) {
let d = diskof(D, id), r = relok(rel);
if (!d || r == null) return null;
let p = d.mnt + (r == '/' ? '' : r);
return inside(d.mnt, p) ? p : null;
}
function badname(n) { return UCFG.badname(n); }
function relp(p) { return UCFG.relp(p, true); }
function absp(d, p) { return UCFG.absp(d, p); }
function bname(a) { return UCFG.bname(a); }
function ovis(own) { if (own == 'admin') return ''; let p = ud(own, 'root'); return p ? bname(p) : own; }
function vfs(p) {
let f = null; try { f = require('fs').statvfs; } catch (e) { f = null; }
if (f) { let s = null; try { s = f(p); } catch (e) {} if (s) { let b = s.frsize ?? s.bsize ?? 4096; return { free: (s.bavail ?? 0) * b, total: (s.blocks ?? 0) * b }; } }
let l = split(trim(sh('df -kP ' + q(p) + ' 2>/dev/null')), '\n'), x = split(l[length(l) - 1] ?? '', /[ \t]+/);
return { free: match(x[3] ?? '', /^[0-9]+$/) ? +x[3] * 1024 : 0, total: match(x[1] ?? '', /^[0-9]+$/) ? +x[1] * 1024 : 0 };
}
function dsk(D, id, write) {
let d = diskof(D, '' + (id ?? ''));
if (!d) return err('disk', 'Disco non collegato', 'Drive not connected');
if (write && d.ro) return err('ro', 'Disco in sola lettura: qui si può solo leggere', 'Drive is read-only: only reading is possible here', { ro: true });
return d;
}

function mainof(D, N) {
let m = (N ?? rjs(NJ) ?? {}).main;
if (type(m) != 'object' || m.id == null) return null;
for (let d in D) if (d.id == '' + m.id || d.dev == '' + m.id || (length(m.uuid ?? '') && d.id == lc('' + m.uuid))) return d;
return null;
}
function people(N) { let r = []; for (let u, x in (type(N?.users) == 'object' ? N.users : {})) if (type(x) == 'object' && !x.cam) push(r, u); return sort(r); }
function whoami(req) {
if (type(req?.wfown) == 'string' && match(req.wfown, /^[a-z][a-z0-9]{0,19}$/) && req.wfown != 'admin' && req.wfown != 'shared') return { own: req.wfown, adm: false, sys: true };
if (type(UCFG.who) != 'function') return { own: 'admin', adm: true };
let O = { nj: rjs(NJ) ?? {} }, W = UCFG.who(req, O);
return W ?? (O.why == 'blocked' ? { blocked: true } : null);
}
function werr(W) {
if (W?.blocked) return err('blocked', 'Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator');
return err('who', 'Accesso scaduto: entra di nuovo', 'Access expired: sign in again');
}
function errp() { return err('private', 'Cartella di un\'altra persona', 'Another person\'s folder'); }
function eadm() { return err('admin', 'Lo può fare solo l\'Amministratore', 'Only the Administrator can do this'); }
function nomain() { return err('nomain', 'Manca il Disco Principale', 'Main Drive missing'); }
function under(p, b) { if (b == null || p == null) return false; p = lc(p); b = lc(b); return p == b || index(p, b + '/') == 0; }
const PASSWD = getenv('WF_PASSWD') ?? '/etc/passwd';
function shown(d, rel) {
let O = rjs(d.mnt + '/.wf-own.json'), O2 = rjs(ETC + '/nas-own.json'), P = relp(rel) ?? [];
let at = (k) => (type(O) == 'object' ? O[k] : null) ?? (type(O2) == 'object' ? O2[k] : null);
let k0 = d.id + ':/' + join('/', P);
if (at(k0) != null) return at(k0);
if (match(d.fs ?? '', /^ext[234]$/)) {
let uid = lstat(d.mnt + '/' + join('/', P))?.uid;
if (uid != null) for (let l in split(readfile(PASSWD) ?? '', '\n')) { let f = split(l, ':'); if (length(f) >= 5 && f[4] == 'wf-nas' && f[2] == '' + uid) return f[0]; }
}
for (let i = length(P) - 1; i > 0; i--) { let v = at(d.id + ':/' + join('/', slice(P, 0, i))); if (v != null) return v; }
return null;
}
function shmine(d, N, rel, own) {
let sr = ud('shared', 'root', null, N);
return sr != null && under(rel, sr) && lc(rel) != lc(sr) && shown(d, rel) == own;
}
function srcok(W, D, N, disk, p, all) {
let m = mainof(D, N), main = m != null && disk == m.id;
if (W.adm) {
if (type(UCFG.upriv) == 'function') { let v = UCFG.upriv(W, p, N); return v == null || (v == 'up' && !main && !all) ? null : errp(); }
for (let u in people(N)) { let b = ud(u, 'root', null, N); if (b && (under(p, b) || ((main || all) && (p == '/' || under(b, p))))) return errp(); }
return null;
}
if (!main) return m == null ? nomain() : errp();
if (under(p, ud(W.own, 'root', null, N)) || shmine(m, N, p, W.own)) return null;
return under(p, '/' + UCFG.UDIR.root) ? errp() : err('path', 'Cartella non valida', 'Invalid folder');
}
function mpause() { return stat(TMP + '/mainpause.json') != null; }
function qfull(own) { return own != 'admin' && index(map(split(readfile(TMP + '/full.list') ?? '', '\n'), (x) => trim(x)), own) >= 0; }
function pstop(own, N) {
if (own == 'admin') return null;
let U = (N ?? nget()).users;
if (type(U) == 'object' && U[own]?.blocked === true) return err('blocked', 'Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator');
if (mpause()) return nomain();
return qfull(own) ? err('quota_full', 'Spazio finito: libera spazio o chiedi più spazio', 'Space used up: free some space or ask for more space', { pct: 100 }) : null;
}
function csrcok(W, D, N, d, rel) {
if (W.adm) {
if (type(UCFG.upriv) == 'function') return UCFG.upriv(W, rel, N) == null ? null : errp();
for (let u in people(N)) { let b = ud(u, 'root', null, N); if (b && (under(rel, b) || rel == '/' || under(b, rel))) return errp(); }
return null;
}
let m = mainof(D, N);
if (m == null) return nomain();
if (d.id != m.id) return errp();
if (under(rel, ud(W.own, 'root', null, N)) || shmine(d, N, rel, W.own)) return null;
return under(rel, '/' + UCFG.UDIR.root) || rel == '/' ? errp() : err('path', 'Cartella non valida', 'Invalid folder');
}

const PK = {
rsync: [ [ 'rsync', '/usr/bin/rsync' ] ],
rclone: [ [ 'rclone', '/usr/bin/rclone' ], [ 'ca-bundle', '/etc/ssl/certs/ca-certificates.crt' ] ],
inotify: [ [ 'inotifywait', '/usr/bin/inotifywait' ] ]
};
function need(part) {
let r = [];
for (let p in PK[part]) { let ok = false; for (let i = 1; i < length(p); i++) if (has(p[i])) ok = true; if (!ok) push(r, p[0]); }
return r;
}
function pkgerr(P) { return err('pkg', 'Serve installare: ' + join(', ', P), 'Needs to be installed: ' + join(', ', P), { need: P }); }
function sambaOk() { return UCFG.smbmem(R); }

function persons() {
let W = cfg('wrtfreedom'), P = [];
for (let k, s in W) if (s['.type'] == 'person') push(P, { id: k, name: s.name ?? k, macs: macs(s.mac) });
return P;
}
function personof(P, mac) { for (let p in P) if (index(p.macs, mac) >= 0) return p; return null; }
function leasefile() { for (let k, s in cfg('dhcp')) if (s['.type'] == 'dnsmasq') return length(s.leasefile ?? '') ? s.leasefile : '/tmp/dhcp.leases'; return '/tmp/dhcp.leases'; }
function neigh() {
let ip = {}, nm = {};
for (let l in split(readfile(leasefile()) ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) >= 4 && macok(lc(p[1]))) { ip[p[2]] = lc(p[1]); if (p[3] != '*') nm[lc(p[1])] = p[3]; }
}
for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) { let p = split(l, /[ \t]+/); if (length(p) >= 4 && macok(lc(p[3])) && !ip[p[0]]) ip[p[0]] = lc(p[3]); }
return { ip: ip, name: nm };
}
function nkey(s) { return replace(lc('' + s), /[^a-z0-9]/g, ''); }

function bakstate(id) {
let m = match(readfile(BKD + '/' + id + '.last') ?? '', /^([0-9]+) ([01]) ([0-9]+)/), r = m ? { last: +m[1], ok: m[2] == '1', size: +m[3] } : { last: 0, ok: null, size: 0 };
let x = split(trim(readfile(BKD + '/' + id + '.last') ?? ''), ' ');
r.xfer = num(x[3]); r.secs = num(x[4]);
r.okt = num(trim(readfile(BKD + '/' + id + '.ok') ?? '')) || (r.ok ? r.last : 0);
r.versions = num(trim(readfile(BKD + '/' + id + '.nv') ?? ''));
let c = match(trim(readfile(BKD + '/' + id + '.chk') ?? ''), /^([0-9]+) (miss|skip) ([0-9]+)$/);
r.chk = c && r.ok ? { why: c[2], n: +c[3] } : null;
if (r.chk?.why == 'skip') r.chk.files = filter(split(trim(readfile(BKD + '/' + id + '.skip') ?? ''), '\n'), length);
return r;
}
function modeof(b) { let m = b.when?.mode; return match('' + m, /^(night|plug|man)$/) ? m : (length(b.when?.at ?? '') ? 'night' : 'man'); }
function daysof(d) {
if (type(d) != 'array') return null;
let D = [];
for (let x in d) if (type(x) == 'int' && x >= 0 && x <= 6 && index(D, x) < 0) push(D, x);
return length(D) > 0 && length(D) < 7 ? sort(D, (a, b) => a - b) : null;
}
function dayon(d, ts) { let D = daysof(d); return !D || index(D, localtime(ts).wday % 7) >= 0; }
function daygap(d) {
let D = daysof(d), g = 0;
if (!D) return 0;
for (let i = 0; i < length(D); i++) { let x = (i + 1 < length(D) ? D[i + 1] : D[0] + 7) - D[i]; if (x > g) g = x; }
return g - 1;
}
function lastocc(at, d) {
let t = localtime(), now = time(), n = now - (t.hour * 3600 + t.min * 60 + t.sec) + +substr(at, 0, 2) * 3600 + +substr(at, 3, 2) * 60;
if (n > now) n -= DAY;
for (let k = 0; k < 7 && !dayon(d, n); k++) n -= DAY;
return n;
}
function nextocc(at, d) {
let t = localtime(), now = time(), n = now - (t.hour * 3600 + t.min * 60 + t.sec) + +substr(at, 0, 2) * 3600 + +substr(at, 3, 2) * 60;
if (n <= now) n += DAY;
for (let k = 0; k < 7 && !dayon(d, n); k++) n += DAY;
return n;
}
function baknext(b) { return modeof(b) == 'night' && b.on !== false && length(b.when?.at ?? '') ? nextocc(b.when.at, b.when.days) : 0; }
function late(b, s, A) {
if (modeof(b) != 'night' || b.on === false) return false;
let ref = s.okt || b.t || 0;
return ref > 0 && time() - ref > (A.warn_task + daygap(b.when?.days)) * DAY;
}
function safeof(name) { return replace('' + name, /[^A-Za-z0-9._-]/g, '_'); }
function bsafe(b) { return b.own != null && b.dest?.kind != 'nas' ? '' + b.name : safeof(b.name); }
function bknameok(N, own, id, nm) {
for (let x in N.backups) if (x.id != id && ownof(x) == own && lc('' + x.name) == lc(nm)) return err('name', 'Nome già usato da un altro backup', 'Name already used by another backup');
for (let k in [ 'tm', 'fh' ]) if (lc(nm) == lc('' + (UCFG.UDIR?.[k] ?? ''))) return err('name', 'Nome riservato a Backup Del Mac e Backup Del PC', 'Name reserved for Mac Backup and PC Backup');
return null;
}
function cutb(t, n) {
if (length(t) <= n) return t;
t = substr(t, 0, n);
let j = length(t) - 1;
while (j > 0 && (ord(t, j) & 0xC0) == 0x80) j--;
let l = ord(t, j), need = l >= 0xF0 ? 4 : l >= 0xE0 ? 3 : l >= 0xC0 ? 2 : 1;
return trim(length(t) - j < need ? substr(t, 0, j) : t);
}
function bkname(N, own, base) {
let s = replace(trim(replace('' + (base ?? ''), /[[:cntrl:]\/\\]/g, '_')), /^\.+/, '');
if (!length(s)) s = 'Backup';
for (let n = 1; n <= 99; n++) {
let x = n > 1 ? ' ' + n : '', c = cutb(s, 40 - length(x)) + x;
if (!bknameok(N, own, '', c)) return c;
}
return 'Backup ' + rid();
}
function bakdst(D, b) {
if (b.dest?.kind == 'nas') return null;
let d = diskof(D, b.dest?.disk);
if (!d) return null;
let p = (b.dest.path == '/' ? '' : b.dest.path) + '/' + bsafe(b), a = absof(D, d.id, p);
return a ? { d: d, abs: a, rel: p } : null;
}
const STAMP = /^([0-9]{4})([0-9]{2})([0-9]{2})-([0-9]{2})([0-9]{2})$/;
function stampt(s) { let m = match(s, STAMP); return m ? timelocal({ year: +m[1], mon: +m[2], mday: +m[3], hour: +m[4], min: +m[5], sec: 0 }) : 0; }
function versions(dir) { return sort(filter(lsdir(dir) ?? [], (v) => match(v, STAMP) != null && stat(dir + '/' + v)?.type == 'directory')); }

let TIPI = {};
try { TIPI = loadfile(getenv('WF_NASTIPIUC') ?? replace(sourcepath() ?? '', /[^\/]*$/, '') + 'nastipi.uc')() ?? {}; } catch (e) { TIPI = {}; }
const SKIP = { video: TIPI.vid ?? [], music: TIPI.mus ?? [], photo: TIPI.img ?? [], doc: TIPI.doc ?? [], archive: TIPI.arc ?? [] };
function bakwrite(b, N) {
mkdirp(BKD);
let w = b.what ?? {}, de = b.dest ?? {}, ds = type(w.dirs) == 'array' ? w.dirs : [];
let ex = [ '/.wf-*', '.wf-trash/', '.wf-minidlna/', '.wf-dav-tmp/', 'lost+found/' ];
for (let s in w.skip) for (let e in SKIP[s]) push(ex, '*.' + e, '*.' + uc(e));
N = N ?? nget();
if (ownof(b) == 'admin') for (let u in people(N)) { let p = ud(u, 'root', null, N); if (p) push(ex, p + '/'); }
wif(BKD + '/' + b.id + '.excl', join('\n', ex) + '\n');
wif(BKD + '/' + b.id + '.dirs', join('\n', ds) + (length(ds) ? '\n' : ''));
wif(BKD + '/' + b.id + '.sh', 'NAME=' + q(b.name) + '\nSRC=' + q(w.disk ?? '') + '\nALL=' + (w.all ? 1 : 0) + '\nROUTER=' + (w.router ? 1 : 0) +
'\nKIND=' + q(de.kind ?? '') + '\nDDISK=' + q(de.disk ?? '') + '\nDPATH=' + q(de.path ?? '') + '\nHOST=' + q(de.host ?? '') + "\nAT=''\nTIME=" + q(b.when?.at ?? '') +
'\nMODE=' + q(modeof(b)) + '\nON=' + (b.on === false ? 0 : 1) + '\nWARN=' + (b.warn === false ? 0 : 1) + '\nSAFE=' + q(bsafe(b)) + '\nKEEP=' + (b.keep_days ?? 0) +
'\nOWN=' + q(ownof(b)) + '\n');
}
function bakrun(b) {
let l = TMP + '/bak-' + b.id + '.lock', s = stat(l);
if (!s) return false;
let p = trim(readfile(l + '/pid') ?? '');
return length(p) ? alive(p) : time() - s.mtime < 60;
}
function pcscan(N, D) {
let du = rjs(TMP + '/bk-du.json') ?? {}, r = [], mn = mainof(D, N), B = [];
if (mn) for (let k in [ 'tm', 'fh' ]) if (N[k]?.on === true) for (let own in [ 'admin', ...people(N) ]) {
let rel = ud(own, k, null, N), base = rel ? absof(D, mn.id, rel) : null;
if (base) push(B, { k: k, own: own, base: base });
}
for (let x in B) {
let k = x.k, own = x.own, base = x.base;
for (let e in lsdir(base) ?? []) {
let p = base + '/' + e;
if (k == 'tm') {
let m = match(e, /^(.+)\.(sparsebundle|backupbundle)$/);
if (!m || stat(p)?.type != 'directory') continue;
let t = 0;
for (let f in [ '', '/bands', '/Info.plist', '/com.apple.TimeMachine.SnapshotHistory.plist', '/com.apple.TimeMachine.MachineID.plist' ]) { let s = stat(p + f); if (s && s.mtime > t) t = s.mtime; }
push(r, { kind: 'tm', name: m[1], last: t, bytes: du[p] ?? 0, path: p, own: own });
}
else if (substr(e, 0, 1) != '.' && stat(p)?.type == 'directory') for (let pc in lsdir(p) ?? []) {
let pp = p + '/' + pc, t = 0;
if (substr(pc, 0, 1) == '.' || stat(pp)?.type != 'directory') continue;
for (let f in [ '', '/Data', '/Configuration' ]) { let s = stat(pp + f); if (s && s.mtime > t) t = s.mtime; }
push(r, { kind: 'fh', name: pc, user: e, last: t, bytes: du[pp] ?? 0, path: pp, own: own });
}
}
}
mkdirp(TMP);
wjs(TMP + '/bk-pc.json', { t: time(), list: r });
return r;
}
function pclist(N, D) { let c = rjs(TMP + '/bk-pc.json'); return type(c?.list) == 'array' ? c.list : pcscan(N, D); }

function dupof(dir, n, size, mt, fat) {
let m = match(n, /^(.+)(\.[^.]+)$/), b = m ? m[1] : n, x = m ? m[2] : '';
for (let i = 1; i < 1000; i++) {
let f = dir + '/' + (i == 1 ? n : b + ' (' + i + ')' + x), s = lstat(f);
if (!s) return null;
if (s.type != 'file' || s.size != size) continue;
let d = absn(s.mtime - mt);
if (mt <= 0 || d <= 2 || (fat && d <= 50400 && (d % 900 <= 2 || 900 - d % 900 <= 2))) return f;
}
return null;
}
function freename(dir, n) {
if (!lstat(dir + '/' + n)) return n;
let m = match(n, /^(.+)(\.[^.]+)$/), b = m ? m[1] : n, x = m ? m[2] : '';
for (let i = 2; i < 10000; i++) if (!lstat(dir + '/' + b + ' (' + i + ')' + x)) return b + ' (' + i + ')' + x;
return null;
}
function ymdir(mt) {
let t = localtime(mt > 0 ? mt : time());
if (t.year < 1990 || t.year > 2100) t = localtime(time());
return sprintf('/%04d/%02d', t.year, t.mon);
}
const MESI = {
it: [ '01 Gennaio', '02 Febbraio', '03 Marzo', '04 Aprile', '05 Maggio', '06 Giugno', '07 Luglio', '08 Agosto', '09 Settembre', '10 Ottobre', '11 Novembre', '12 Dicembre' ],
en: [ '01 January', '02 February', '03 March', '04 April', '05 May', '06 June', '07 July', '08 August', '09 September', '10 October', '11 November', '12 December' ]
};
const MESIV = {
it: [ 'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre' ],
en: [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ]
};
function phmn(m, lg) { let l = lg == 'en' ? 'en' : 'it'; return index(MESI[l], m) >= 0 || index(MESIV[l], m) >= 0; }
function phmnew(m) { for (let l in [ 'it', 'en' ]) { let i = index(MESIV[l], m); if (i >= 0) return MESI[l][i]; } return null; }
function ymok(y, m) { return y >= 1990 && y <= 2100 && m >= 1 && m <= 12 ? { y: y, m: m } : null; }
function ymof(t) { if (type(t) != 'int' || t <= 0) return null; let l = localtime(t); return ymok(l.year, l.mon); }
function phkind(n, lg) { let m = match(lc('' + n), /\.([a-z0-9]+)$/), v = m && index(TIPI.vid ?? [], m[1]) >= 0; return lg == 'en' ? (v ? 'Videos' : 'Photos') : (v ? 'Video' : 'Foto'); }
function phsub(ym, n, lg) { return sprintf('/%04d/%s/%s', ym.y, MESI[lg == 'en' ? 'en' : 'it'][ym.m - 1], phkind(n, lg)); }
function phymk(ym) { return sprintf('%04d/%02d', ym.y, ym.m); }
function phlang(Xc, own) { let o = Xc?.photo?.lang; return type(o) == 'object' && match('' + o[own], /^(it|en)$/) ? o[own] : null; }
function u16(b, o, le) { let x = ord(b, o), y = ord(b, o + 1); return x == null || y == null ? null : (le ? x | y << 8 : x << 8 | y); }
function u32(b, o, le) { let x = u16(b, o, le), y = u16(b, o + 2, le); return x == null || y == null ? null : (le ? x | y << 16 : x << 16 | y); }
function exifym(b, t) {
let bo = substr(b, t, 2), le = bo == 'II';
if (!le && bo != 'MM') return null;
let ifd = (o) => {
let r = {}, n = o == null ? null : u16(b, t + o, le);
if (n == null || n > 500) return r;
for (let i = 0; i < n; i++) {
let e = t + o + 2 + i * 12, tg = u16(b, e, le), ty = u16(b, e + 2, le), c = u32(b, e + 4, le);
if (tg == null || c == null) break;
r[tg] = ty == 2 ? substr(b, c > 4 ? t + u32(b, e + 8, le) : e + 8, c) : u32(b, e + 8, le);
}
return r;
};
let I0 = ifd(u32(b, t + 4, le)), IE = type(I0[0x8769]) == 'int' ? ifd(I0[0x8769]) : {};
for (let s in [ IE[0x9003], IE[0x9004], I0[0x0132] ]) {
let m = type(s) == 'string' ? match(s, /^([0-9]{4}):([0-9]{2}):/) : null, r = m ? ymok(+m[1], +m[2]) : null;
if (r) return r;
}
return null;
}
function tiffat(b) {
for (let i = 0; i < 64 && i + 4 <= length(b); i++) {
let s = substr(b, i, 2);
if ((s == 'MM' && ord(b, i + 2) == 0 && ord(b, i + 3) == 42) || (s == 'II' && ord(b, i + 2) == 42 && ord(b, i + 3) == 0)) return i;
}
return null;
}
function boxes(h, a, z) {
let r = [];
while (a + 8 <= z && length(r) < 64) {
h.seek(a);
let b = h.read(16), s = u32(b, 0, false), hl = 8;
if (s == null || length(b) < 8) break;
if (s == 1) { let x = u32(b, 8, false), y = u32(b, 12, false); if (y == null) break; s = x * 4294967296 + y; hl = 16; }
else if (s == 0) s = z - a;
if (s < hl) break;
push(r, [ substr(b, 4, 4), a + hl, a + s > z ? z : a + s ]);
a += s;
}
return r;
}
function boxof(L, t) { for (let x in L) if (x[0] == t) return x; return null; }
function heicym(h, z) {
let M = boxof(boxes(h, 0, z), 'meta');
if (!M || M[2] - M[1] > 1048576) return null;
let C = boxes(h, M[1] + 4, M[2]), II = boxof(C, 'iinf'), IL = boxof(C, 'iloc');
if (!II || !IL) return null;
h.seek(II[1]);
let b = h.read(II[2] - II[1]), v = ord(b, 0), o = v == 0 ? 6 : 8, ex = null;
while (o + 8 <= length(b) && ex == null) {
let s = u32(b, o, false), iv = ord(b, o + 8), p = o + 12;
if (s == null || s < 8) break;
if (substr(b, o + 4, 4) == 'infe' && iv >= 2) { let id = iv == 2 ? u16(b, p, false) : u32(b, p, false); p += (iv == 2 ? 2 : 4) + 2; if (substr(b, p, 4) == 'Exif') ex = id; }
o += s;
}
if (ex == null) return null;
h.seek(IL[1]);
b = h.read(IL[2] - IL[1]);
v = ord(b, 0);
let os = ord(b, 4) >> 4, ls = ord(b, 4) & 15, bs = ord(b, 5) >> 4, xs = v >= 1 ? ord(b, 5) & 15 : 0;
let rd = (n) => { let x = 0; for (let i = 0; i < n; i++) x = x * 256 + (ord(b, o + i) ?? 0); o += n; return x; };
o = 6;
let n = rd(v < 2 ? 2 : 4);
for (let i = 0; i < n && o < length(b); i++) {
let id = rd(v < 2 ? 2 : 4), cm = v >= 1 ? rd(2) & 15 : 0;
rd(2);
let base = rd(bs), ec = rd(2);
for (let j = 0; j < ec; j++) {
rd(xs);
let eo = rd(os), el = rd(ls);
if (id == ex && j == 0 && cm == 0) {
h.seek(base + eo);
let d = h.read(el > 0 && el < 65536 ? el : 65536), t = d ? tiffat(d) : null;
return t == null ? null : exifym(d, t);
}
}
}
return null;
}
function mp4ym(h, z) {
let M = boxof(boxes(h, 0, z), 'moov'), V = M ? boxof(boxes(h, M[1], M[2]), 'mvhd') : null;
if (!V) return null;
h.seek(V[1]);
let b = h.read(12), t = ord(b, 0) == 1 ? (u32(b, 4, false) ?? 0) * 4294967296 + (u32(b, 8, false) ?? 0) : u32(b, 4, false) ?? 0;
return t > 2082844800 ? ymof(t - 2082844800) : null;
}
function phnym(n) {
let m = match(lc('' + n), /^(img|vid|pxl|mvimg|pano|burst|photo|video|signal|screenshot|screen_recording|screenrecording)[-_ ]*((19|20)[0-9][0-9])-?(0[1-9]|1[0-2])-?(0[1-9]|[12][0-9]|3[01])([^0-9]|$)/);
return m ? ymok(+m[2], +m[4]) : null;
}
function phdate(f, nm) {
let n = type(nm) == 'string' && length(nm) ? nm : f;
n = substr(n, rindex(n, '/') + 1);
let s = lstat(f), h = s?.type == 'file' && s.size >= 12 ? open(f, 'r') : null;
if (!h) return phnym(n);
let r = null;
try {
let b = h.read(12);
if (ord(b, 0) == 0xFF && ord(b, 1) == 0xD8) {
h.seek(0);
b = h.read(262144);
let p = 2;
while (p + 4 <= length(b) && ord(b, p) == 0xFF) {
let k = ord(b, p + 1);
if (k == 0xD8 || (k >= 0xD0 && k <= 0xD7) || k == 0x01) { p += 2; continue; }
if (k == 0xDA || k == 0xD9) break;
let sl = u16(b, p + 2, false);
if (sl == null || sl < 2) break;
if (k == 0xE1 && substr(b, p + 4, 4) == 'Exif') { r = exifym(b, p + 10); break; }
p += 2 + sl;
}
}
else if (substr(b, 4, 4) == 'ftyp' && match(substr(b, 8, 4), /^(heic|heix|heim|heis|hevc|hevx|mif1|msf1|avif)$/)) r = heicym(h, s.size);
else if (match(substr(b, 4, 4), /^(ftyp|moov|wide|mdat|free|skip|pnot)$/)) r = mp4ym(h, s.size);
else if (substr(b, 0, 4) == 'II*' + chr(0) || substr(b, 0, 4) == 'MM' + chr(0) + '*') { h.seek(0); r = exifym(h.read(262144), 0); }
} catch (e) { r = null; }
h.close();
return r ?? phnym(n);
}
function samef(a, b) {
let x = open(a, 'r'), y = open(b, 'r'), ok = x != null && y != null;
while (ok) { let p = x.read(1048576), s = y.read(1048576); if (p != s) ok = false; else if (!length(p)) break; }
if (x) x.close();
if (y) y.close();
return ok;
}
function phslot(dir, e, f, sz) {
let m = match(e, /^(.+)(\.[^.]+)$/), b = m ? m[1] : e, x = m ? m[2] : '';
for (let i = 1; i < 10000; i++) {
let n = i == 1 ? e : b + ' (' + i + ')' + x, s = lstat(dir + '/' + n);
if (!s) return { name: n };
if (s.type == 'file' && s.size == sz && samef(f, dir + '/' + n)) return { dup: n };
}
return null;
}
function phsubv(sub) {
let m = match(sub, /^(\/[0-9]{4}\/)([^\/]+)(\/.*)$/);
if (m) for (let l in [ 'it', 'en' ]) { let i = index(MESI[l], m[2]); if (i >= 0) return m[1] + MESIV[l][i] + m[3]; }
return null;
}
function phdup(base, sub, n, size, mt, fat) { let o = phsubv(sub); return dupof(base + sub, n, size, mt, fat) ?? (o ? dupof(base + o, n, size, mt, fat) : null) ?? dupof(base + ymdir(mt), n, size, mt, fat); }
function phfold(f) { let o = rjs(f); return type(o) != 'object' || o.last != null ? {} : o; }
function phonestat(ph, d) {
let s = rjs(X + '/photo-' + ph + '.json');
if (!s && d) { let a = absp(d, d.p ?? ''); s = a ? phfold(a.abs + '/.wf-photo.json')[ph] : null; if (type(s) == 'object') wjs(X + '/photo-' + ph + '.json', s); else s = null; }
return s ?? { last: 0, files: 0, bytes: 0 };
}
function phoneadd(ph, dirabs, size) {
let F = phfold(dirabs + '/.wf-photo.json');
let s = rjs(X + '/photo-' + ph + '.json') ?? (type(F[ph]) == 'object' ? F[ph] : null) ?? { last: 0, files: 0, bytes: 0 };
s.last = time(); s.files = (s.files ?? 0) + 1; s.bytes = (s.bytes ?? 0) + size;
wjs(X + '/photo-' + ph + '.json', s);
F[ph] = s;
let t = dirabs + '/.wf-photo.json.t'; writefile(t, sprintf('%J', F)); rename(t, dirabs + '/.wf-photo.json');
}
function phmac(id, p) {
if (macok(p.mac)) return p.mac;
let m = match(id, /^m([0-9a-f]{12})$/);
return m ? join(':', map(match(m[1], /[0-9a-f]{2}/g), (x) => x[0])) : '';
}
function reminds() { let r = rjs(X + '/remind.json'); return type(r) == 'object' ? r : {}; }
function phloc(D, N, p) { let d = mainof(D, N); return { d: d, disk: d?.id ?? '', path: ud(ownof(p), 'phones', null, N) ?? '' }; }
function phonedir(D, p) {
if (!length(p.disk)) return nomain();
let d = dsk(D, p.disk, true);
if (d.error) return d;
let a = absp(d, p.path);
if (!a || !length(a.parts)) return err('path', 'Cartella non valida', 'Invalid folder');
mkdirp(a.abs);
if (stat(a.abs)?.type != 'directory') return err('path', 'Cartella non creata', 'Folder not created');
return { d: d, a: a };
}
function phbusy(abs) {
let now = time();
for (let e in lsdir(abs) ?? []) if (match(e, /^\..*\.wfpart$/)) { let s = lstat(abs + '/' + e); if (s && now - s.mtime < 1800) return true; }
return false;
}
function phold(abs) {
let r = [];
for (let y in sort(lsdir(abs) ?? [])) {
if (!match(y, /^[0-9]{4}$/) || lstat(abs + '/' + y)?.type != 'directory') continue;
for (let m in sort(lsdir(abs + '/' + y) ?? [])) if (match(m, /^(0[1-9]|1[0-2])$/) && lstat(abs + '/' + y + '/' + m)?.type == 'directory') push(r, [ +y, +m, abs + '/' + y + '/' + m, y + '/' + m ]);
}
return r;
}
function phrmdir(d) {
let E = lsdir(d);
if (E == null) return false;
for (let e in E) {
if (e != '.DS_Store' && (substr(e, 0, 2) != '._' || index(E, substr(e, 2)) >= 0)) continue;
if (lstat(d + '/' + e)?.type == 'file') unlink(d + '/' + e);
}
return rmdir(d);
}
function phmv1(abs, O, lg, J) {
let now = time(), k = 0;
if (phbusy(abs)) return 'busy';
for (let o in O) {
for (let e in sort(lsdir(o[2]) ?? [])) {
let f = o[2] + '/' + e, s = lstat(f);
if (s?.type != 'file') continue;
if (substr(e, 0, 1) == '.') { if (match(e, /\.wfpart$/) && now - s.mtime > 2 * DAY) unlink(f); continue; }
if (++k % 20 == 0 && phbusy(abs)) return 'busy';
let sub = phsub(phdate(f) ?? ymok(o[0], o[1]), e, lg), dir = abs + sub, dst = dir + '/' + e, fn = e;
mkdirp(dir);
let ds = lstat(dst);
if (ds && ds.type == 'file' && ds.size == s.size && samef(f, dst)) { unlink(f); push(J, [ o[3] + '/' + e, substr(sub, 1) + '/' + e, 1 ]); continue; }
if (ds) { fn = freename(dir, e); if (!fn) return 'name'; dst = dir + '/' + fn; }
if (lstat(dst) || !rename(f, dst)) return 'move';
push(J, [ o[3] + '/' + e, substr(sub, 1) + '/' + fn, 0 ]);
}
phrmdir(o[2]);
}
return 'done';
}
const PROV = { drive: 'Google Drive', onedrive: 'OneDrive', dropbox: 'Dropbox', pcloud: 'pCloud', box: 'Box', kdrive: 'kDrive', koofr: 'Koofr',
jottacloud: 'Jottacloud', mega: 'MEGA', icloud: 'iCloud Drive', b2: 'Backblaze B2', s3: 'S3', hetzner: 'Hetzner Storage Box', webdav: 'WebDAV', sftp: 'SFTP' };
function lkstale(K) {
let s = stat(K), p = trim(readfile(K + '/pid') ?? '');
if (s == null) return false;
return p == PID || (match(p, /^[0-9]+$/) != null && stat('/proc/' + p) == null) || time() - s.mtime > 30 || s.mtime > time() + 60;
}
function lkget(K) {
mkdirp(TMP);
let b = K + '.brk';
if (mkdir(K)) { writefile(K + '/pid', PID); return true; }
if (lkstale(K)) {
let bs = stat(b);
if (bs && (time() - bs.mtime > 30 || bs.mtime > time() + 60)) rmdir(b);
if (mkdir(b)) {
if (lkstale(K)) { unlink(K + '/pid'); rmdir(K); }
rmdir(b);
if (mkdir(K)) { writefile(K + '/pid', PID); return true; }
}
}
return false;
}
function lkput(K) { if (trim(readfile(K + '/pid') ?? '') == PID) { unlink(K + '/pid'); rmdir(K); } }
function xlock() {
if (XHELD) return 'in';
for (let i = 0; i <= 20; i++) { if (lkget(XLK)) { XHELD = true; return true; } if (i < 20) sleep(100); }
return false;
}
function xunlock(t) { if (t === true) { XHELD = false; lkput(XLK); } }
function xput(o) {
let t = xlock();
if (!t) return false;
let S = null, ok = true;
for (let e in XSN) if (e[0] === o) S = e[1];
try {
let D = o;
if (S) { D = rjs(XJ); if (type(D) != 'object') D = {}; xmrg(D, o, S); }
o.saved = D.saved = time(); mkdirp(ETC); wjs(XJ, D);
xsnap(o);
} catch (e) { ok = false; }
xunlock(t);
return ok;
}
let CMOD = null;
function cmod() { if (CMOD == null) { CMOD = false; try { CMOD = loadfile(CLOUDUC)() ?? false; } catch (e) { CMOD = false; } } return CMOD || null; }
function rcx() { return cmod()?._rc ?? null; }
function rcq(f) { let r = rcx(); return r ? r[f]() : null; }
function rcset(W) { let r = rcx(); return r != null && r.rcset(W) === true; }
function rcf() { return stat(RCONF) || !stat(OLDRC) ? RCONF : OLDRC; }
function rcset1(sec, kv) { let W = {}; W[sec] = kv; return rcset(W); }
function rcbusy(sec) {
let p = trim(readfile(X + '/rc-' + sec + '.lock/pid') ?? '');
return match(p, /^[0-9]+$/) != null && stat('/proc/' + p) != null;
}
function rcsec(sec) {
let cur = null, r = null;
for (let l in split(readfile(rcf()) ?? '', '\n')) {
let m = match(l, /^\[(.*)\][ \t]*$/);
if (m) { cur = m[1]; if (cur == sec) r = {}; continue; }
let kv = match(l, /^([A-Za-z0-9_]+)[ \t]*=[ \t]*(.*)$/);
if (cur == sec && kv) r[kv[1]] = kv[2];
}
return r;
}
function rcname(c) { return c.kind == 'backup' ? 'wf' + c.id : 'wfc' + c.id; }
function rclinked(sec) { return match(rcsec(sec)?.token ?? '', /^\{/) != null; }
function acctok(id) { return type(id) == 'string' && match(id, /^a[0-9]{1,3}$/) != null; }
function asec(c) { return acctok(c.acct) ? 'wf' + c.acct : rcname(c); }
function amap() { let r = rcx(), M = {}; if (r) for (let x in (r.accts() ?? [])) if (type(x) == 'object') M[x.id] = x; return M; }
function clinked(c, AM) { return acctok(c.acct) ? match(AM[c.acct]?.state ?? '', /^(ok|err|busy)$/) != null : rclinked(rcname(c)); }
function cbusy(c) { return !acctok(c.acct) && rcbusy(rcname(c)); }
function migrating() {
let K = CTMP + '/mig.lock', s = stat(K);
if (!s) return false;
let p = trim(readfile(K + '/pid') ?? '');
return length(p) ? alive(p) : time() - s.mtime < 600;
}
function wasabi(A) { if (A?.svc != 's3') return false; let s = rcsec('wf' + A.id) ?? {}; return match('' + (s.provider ?? s.vendor ?? ''), /wasabi/i) != null; }
function hhmm(s) { return type(s) == 'string' && match(s, /^([01][0-9]|2[0-3]):[0-5][0-9]$/) != null; }
function netok(n) {
if (type(n) != 'object' || !match('' + n.mode, /^(same|own|fixed)$/)) return null;
if (n.mode != 'own') return { mode: n.mode };
let gb = n.gb, all = n.all === true;
if (!(type(gb) == 'int' || type(gb) == 'double') || !(gb == 0 || (gb >= 0.5 && gb <= 500))) return null;
if (!all && !(hhmm(n.from) && hhmm(n.to))) return null;
return { mode: 'own', gb: gb, all: all, from: all ? '' : n.from, to: all ? '' : n.to };
}
const KEYA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newkey() {
let f = open('/dev/urandom', 'r'), b = f ? f.read(24) : null, k = '';
if (f) f.close();
if (type(b) != 'string' || length(b) < 24) return null;
for (let i = 0; i < 24; i++) k += substr(KEYA, ord(b, i) & 31, 1) + (i % 4 == 3 && i < 23 ? '-' : '');
return k;
}
const FS = require('fs');
function put600(f, s) {
let t = f + '.' + PID + '.t';
unlink(t);
let h = open(t, 'w');
if (!h) return false;
if (type(FS.chmod) == 'function') FS.chmod(t, 0600);
if (((stat(t)?.mode ?? 511) & 63) != 0) { h.close(); unlink(t); return false; }
h.write(s); h.close();
if (!rename(t, f)) { unlink(t); return false; }
return true;
}
function pwput(id, pw) { mkdirp(X); return put600(X + '/.pw-' + id, pw); }
const PHIDX = CTMP + '/phidx', PHETC = ETC + '/cloud-photo', PHB = CTMP + '/ph';
function phkey(ym, n, s) { return ym + '/' + n + '|' + s; }
function phym(mt) { return substr(ymdir(mt), 1); }
function phjob(id, ym, n, s) { return 'jp' + substr(hk(id), 0, 6) + substr(hk(phkey(ym, n, s)), 0, 12); }
function phdirs() { for (let d in [ CTMP, PHB, PHIDX ]) if (!stat(d)) mkdir(d, 0700); return stat(PHB)?.type == 'directory'; }
function phidxd() {
if (PHDD !== false) return PHDD;
let N = nget(), d = mainof(disks(), N);
PHDD = d && !d.ro && length(d.mnt ?? '') && stat(d.mnt)?.type == 'directory' ? d.mnt + '/.wf-cloud-photo' : null;
return PHDD;
}
function phidxraw(id) {
let t = readfile(PHIDX + '/' + id + '.idx');
if (t != null) return t;
let dd = phidxd(), gz = PHETC + '/' + id + '.idx.gz';
let z = stat(gz) ? sh('gzip -dc ' + q(gz) + ' 2>/dev/null') : null;
t = (dd ? readfile(dd + '/' + id + '.idx') : null) ?? (length(z) ? z : null) ?? readfile(PHETC + '/' + id + '.idx');
if (length(t) && phdirs()) wput(PHIDX + '/' + id + '.idx', t);
return t ?? '';
}
function phidx(id) {
let I = { last: 0, k: {}, f: {}, n: 0, b: 0, old: 0 };
for (let l in split(phidxraw(id), '\n')) {
if (substr(l, 0, 1) == '#') { I.last = num(substr(l, 1)); continue; }
let p = split(l, '\t');
if ((length(p) != 4 && length(p) != 5) || !match(p[0], /^[0-9]+$/)) continue;
I.k[phkey(p[1], p[2], p[0])] = p[3]; I.n++; I.b += +p[0];
if (length(p) == 5) I.f[p[1] + '/' + p[3]] = +p[0]; else I.old++;
}
return I;
}
function phcopy(src, dst, every, now) {
let t = stat(src), es = stat(dst);
return t && !(es && es.mtime >= t.mtime && es.mtime <= now + 60) && !(es && now - es.mtime < every && es.mtime <= now + 60);
}
function phsync(id) {
let src = PHIDX + '/' + id + '.idx', now = time();
if (!stat(src)) return;
let dd = phidxd();
if (dd && phcopy(src, dd + '/' + id + '.idx', 3600, now)) { mkdirp(dd); if (!wif(dd + '/' + id + '.idx', readfile(src) ?? '')) sh('touch ' + q(dd + '/' + id + '.idx') + ' 2>/dev/null'); }
let gz = PHETC + '/' + id + '.idx.gz';
if (!phcopy(src, gz, 6 * 3600, now)) return;
let sz = stat(src).size, fr = vfs(ETC).free;
if (fr < 2 * sz) return;
mkdirp(PHETC);
let t = gz + '.' + PID + '.t';
sh('gzip -c ' + q(src) + ' > ' + q(t) + ' 2>/dev/null && mv ' + q(t) + ' ' + q(gz) + ' || rm -f ' + q(t));
if (stat(gz)) unlink(PHETC + '/' + id + '.idx');
}
function phq(id) { let Q = rjs(X + '/phq-' + id + '.json'); return type(Q) == 'object' ? Q : {}; }
function phqput(id, Q) { if (length(Q)) wjs(X + '/phq-' + id + '.json', Q); else unlink(X + '/phq-' + id + '.json'); }
function phmerge(id) {
if (!length(phq(id))) return;
let K = X + '/phq-' + id + '.lock';
if (!lkget(K)) return;
try {
let Q = phq(id), add = [], by = 0, now = time(), ch = false;
for (let j, e in Q) {
let st = rjs(CTMP + '/jobs/' + j + '.json')?.state;
if (st == 'ok') { push(add, sprintf('%d\t%s\t%s\t%s%s\n', e.s, e.ym, e.n, e.f, e.nl ? '\tn' : '')); by += e.s; delete Q[j]; ch = true; }
else if (st == 'err' || st == 'stop' || (st == null && now - (e.t ?? 0) > 120)) { delete Q[j]; ch = true; }
}
if (length(add) && phdirs()) {
let f = PHIDX + '/' + id + '.idx', s = replace(phidxraw(id), /^#[^\n]*\n/, '');
wif(f, '#' + now + '\n' + s + join('', add));
let S = rjs(X + '/photo-' + id + '.json');
if (type(S) == 'object') { S.last = now; S.files = (S.files ?? 0) + length(add); S.bytes = (S.bytes ?? 0) + by; wjs(X + '/photo-' + id + '.json', S); }
}
if (ch) phqput(id, Q);
} catch (e) {}
lkput(K);
}
function phcstat(id) {
phmerge(id);
phsync(id);
let S = rjs(X + '/photo-' + id + '.json');
if (type(S) != 'object') { let I = phidx(id); S = { last: I.last, files: I.n, bytes: I.b }; mkdirp(X); wjs(X + '/photo-' + id + '.json', S); }
S.queue = length(phq(id));
return S;
}
function phcdrop(id) {
let dd = phidxd();
for (let f in [ PHIDX + '/' + id + '.idx', PHETC + '/' + id + '.idx', PHETC + '/' + id + '.idx.gz', dd ? dd + '/' + id + '.idx' : null, X + '/phq-' + id + '.json', X + '/photo-' + id + '.json' ]) if (f) unlink(f);
}
function phlim() {
let m = rjs(ETC + '/cloud.json')?.lim?.phone_mb;
return (type(m) == 'int' && m > 0 && m <= 100000 ? m : (rcq('tier') == 'A' ? 32 : 256)) * 1048576;
}
function phccheck(a, id) {
let F = type(a.items) == 'array' ? a.items : (type(a.files) == 'array' ? a.files : []);
if (length(F) > 500) return err('max', 'Al massimo 500 file per volta', 'At most 500 files at a time');
phmerge(id);
let I = phidx(id), QK = {}, dup = [];
for (let j, e in phq(id)) QK[phkey(e.ym, e.n, e.s)] = 1;
for (let k = 0; k < length(F); k++) {
let f = F[k], n = '' + (f?.name ?? ''), sz = f?.size, mt = f?.mt ?? f?.mtime ?? 0;
if (badname(n) || type(sz) != 'int' || type(mt) != 'int') continue;
let key = phkey(phymk(ymof(f?.taken) ?? ymof(mt) ?? ymof(time())), n, sz), ko = phkey(phym(mt), n, sz);
if (I.k[key] != null || QK[key] || I.k[ko] != null || QK[ko]) push(dup, k);
}
return { dup: dup, ro: false };
}
function memavail() { let m = match(readfile('/proc/meminfo') ?? '', /MemAvailable:[ \t]*([0-9]+)/); return m ? +m[1] * 1024 : 1099511627776; }
function phres(job) {
let r = { res: 0, big: false }, now = time();
for (let e in lsdir(PHB) ?? []) {
let m = match(e, /^(.+)\.res$/);
if (!m || m[1] == job) continue;
let ps = lstat(PHB + '/' + m[1] + '.part'), sz = num(trim(readfile(PHB + '/' + e) ?? ''));
if (!ps || now - ps.mtime > 600) { unlink(PHB + '/' + e); continue; }
if (sz > ps.size) r.res += sz - ps.size;
if (sz > 33554432) r.big = true;
}
return r;
}
function phcput(a, id, ph, lg) {
let n = '' + (a.file ?? ''), sz = a.size, mt = a.mtime ?? 0, off = a.off ?? 0;
if (badname(n) || substr(n, 0, 1) == '.') return err('name', 'Nome del file non valido', 'Invalid file name');
if (type(sz) != 'int' || sz < 0 || type(mt) != 'int' || type(off) != 'int' || off < 0) return err('val', 'Dati del file non validi', 'Invalid file data');
let lim = phlim();
if (sz > lim) return err('big', 'Video Troppo Grande Per Questo Router', 'Video Too Large For This Router', { max: lim });
let gy = ymof(a.taken) ?? ymof(mt) ?? ymof(time()), ym = phymk(gy), yo = phym(mt), job = phjob(id, ym, n, sz), pf = PHB + '/' + job + '.part', ok = PHB + '/' + job + '.ok';
if (off == 0) {
phmerge(id);
let I0 = phidx(id), f = I0.k[phkey(ym, n, sz)] ?? I0.k[phkey(yo, n, sz)], Q = phq(id);
if (f == null && Q[job]) f = Q[job].f;
if (f != null) return { ok: true, dup: true, name: f };
if (vfs('/tmp').free < 2 * sz + 8388608) return err('space', 'Memoria del router piena: riprova più tardi', 'Router memory full: try again later', { need: sz });
let R0 = phres(job);
if (sz > 33554432 && R0.big) return err('busy', 'Un altro video in arrivo: riprova fra poco', 'Another video is arriving: try again shortly', { need: sz });
if (memavail() - R0.res < sz + 33554432) return err('space', 'Memoria del router piena: riprova più tardi', 'Router memory full: try again later', { need: sz });
unlink(ok);
if (!phdirs() || !put600(pf, '')) return err('write', 'File non scritto', 'File not written');
writefile(PHB + '/' + job + '.res', '' + sz);
}
let data = b64d('' + (a.data ?? ''));
if (length(data) > PCHUNK) return err('big', 'Pezzo troppo grande', 'Chunk too large');
let ts = lstat(pf);
if (!ts || ts.type != 'file' || ts.size != off) return err('off', 'Pezzo fuori posto: riprendi da ' + (ts?.size ?? 0), 'Chunk out of place: resume from ' + (ts?.size ?? 0), { size: ts?.size ?? 0 });
if (off + length(data) > sz) return err('size', 'Il file è più grande del previsto', 'The file is larger than expected');
if (length(data)) {
let h = open(pf, 'r+');
if (!h) return err('write', 'File non scritto', 'File not written');
h.seek(off);
let wr = h.write(data);
h.close();
if (wr != length(data)) { unlink(pf); return err('write', 'File non scritto: memoria del router piena', 'File not written: router memory full'); }
}
if (!a.last) return { ok: true, size: off + length(data) };
if (off + length(data) != sz) return err('size', 'File incompleto: riprendi da ' + (off + length(data)), 'Incomplete file: resume from ' + (off + length(data)), { size: off + length(data) });
let K = X + '/phq-' + id + '.lock';
if (!lkget(K)) return busy();
let r = null;
try {
let ry = phdate(pf, n) ?? gy;
ym = phymk(ry);
let I = phidx(id), Q = phq(id), used = {}, m = match(n, /^(.+)(\.[^.]+)$/), b = m ? m[1] : n, x = m ? m[2] : '', fn = n;
let df = I.k[phkey(ym, n, sz)];
for (let j, e in Q) if (j != job && e.ym == ym && e.n == n && e.s == sz) df = e.f;
if (df != null) { unlink(pf); lkput(K); return { ok: true, dup: true, name: df }; }
for (let j, e in Q) if (j != job && e.nl) used[e.ym + '/' + e.f] = 1;
for (let i = 2; i < 10000 && (I.f[ym + '/' + fn] != null || used[ym + '/' + fn]); i++) fn = b + ' (' + i + ')' + x;
writefile(ok, '' + sz);
let to = '/' + ph.remote + phsub(ry, n, lg), c = cmod()?.cloud;
r = c ? c.call({ args: { act: 'xfer', kind: 'phone', id: ph.acct, job: job, to: to, name: fn } }) : null;
if (r?.job) { Q[job] = { n: n, s: sz, ym: ym, f: fn, t: time(), nl: 1 }; phqput(id, Q); r = { ok: true, size: sz, name: fn, path: to + '/' + fn, job: r.job }; }
else { unlink(pf); unlink(ok); r = r?.error ? r : err('cloud', 'Cloud non pronto: riprova più tardi', 'Cloud not ready: try again later'); }
} catch (e) { unlink(pf); unlink(ok); r = busy(); }
lkput(K);
return r;
}
function cfacts(id) {
let o = rjs(CDIR + '/' + id + '.st'), n1 = (f) => match(readfile(CDIR + '/' + id + f) ?? '', /^[0-9]+/);
o = type(o) == 'object' ? o : {};
if (stat(CDIR + '/' + id + '.resync')) o.resync = true;
let c = n1('.conflicts'), b = n1('.oldb');
if (c) o.conflicts = +c[0];
if (b) o.old_bytes = +b[0];
return o;
}
function nint(v) { return type(v) == 'int' && v >= 0 ? v : 0; }
const CST = { run: [ 'In Corso', 'Running' ], wait: [ 'In Attesa', 'Waiting' ], gone: [ 'Disco Staccato', 'Disk Disconnected' ],
relink: [ 'Da Ricollegare', 'Reconnect' ], err: [ 'Non Riuscito', 'Failed' ], pause: [ 'In Pausa', 'Paused' ], ok: [ 'Riuscito', 'Succeeded' ],
never: [ 'Mai Fatto', 'Never Run' ], setup: [ 'Da Completare', 'To Complete' ], resync: [ 'Da Riallineare', 'Needs Realign' ],
keybad: [ 'Chiave Da Controllare', 'Check The Key' ] };
function ccloud(c) { return c.kind != 'backup' && acctok(c.sacct); }
function clink2(c, AM) { return clinked(c, AM) && (!ccloud(c) || clinked({ acct: c.sacct }, AM)); }
function cst(c, d, AM, s, pr, e, F, pz) {
let k = c.setup === true ? 'setup' : d == null && !ccloud(c) ? 'gone' : !clink2(c, AM) ? 'relink' : pr ? 'run' : F.resync === true ? 'resync' :
F.keybad === true ? 'keybad' : pz && c.on ? 'pause' : e?.state == 'wait' && c.on ? 'wait' : s.ok === false ? 'err' : !s.last ? 'never' : 'ok';
let r = { st: k, st_t: CST[k][0], st_t_en: CST[k][1] };
let wt = e?.why_t ?? e?.why ?? '';
if (k == 'wait' && length(wt)) { r.why = wt; r.why_en = e.why_en ?? wt; }
return r;
}
function bkdir(Xc, disk, path, self, own) {
let p = lc(path), hit = (x) => { x = lc('' + x); return p == x || x == '/' || p == '/' || index(p, x + '/') == 0 || index(x, p + '/') == 0; };
for (let c in Xc.cloud) if (c.id != self && c.kind == 'backup' && c.disk == disk && (own == null || ownof(c) == own) && hit(c.path)) return c.name;
for (let b in nget().backups) {
if (type(b?.what) != 'object' || b.kind == 'router' || b.what.disk != disk || (own != null && ownof(b) != own)) continue;
if (b.what.all === true) return b.name;
for (let x in (type(b.what.dirs) == 'array' ? b.what.dirs : [])) if (hit(x)) return b.name;
}
return null;
}
const BKROOT = ud('admin', 'backup'), SYROOT = ud('admin', 'sync'), REMV = 2;
function croot(own, bk) { return own == 'admin' ? (bk ? BKROOT : SYROOT) : ud(own, bk ? 'backup' : 'sync'); }
const BKOLD = '/WrtFreedom Backup';
function cmapx(acct, p) {
let r = rcx(), m = null;
if (!acctok(acct) || r == null || type(r.cmap) != 'function') return null;
try { m = r.cmap(acct, replace('' + (p ?? ''), /^\/+/, '')); } catch (e) { m = null; }
if (type(m) != 'object' || type(m.sec) != 'string' || !match(m.sec, /^wfa[0-9]{1,3}[a-z0-9]*$/) || type(m.path) != 'string') return null;
return { sec: m.sec, path: replace(m.path, /^\/+/, ''), st: m.st, wait: m.st == 'mig' || m.st == 'back' };
}
function cdat(c) {
let m = c.kind != 'backup' ? cmapx(c.acct, c.remote) : null;
return m ? { sec: m.sec, rem: '/' + m.path } : { sec: asec(c), rem: c.remote };
}
function cmore(c, m) {
let n = type(c.net) == 'object' ? c.net : { mode: 'same' };
return '\nACCT=' + q(acctok(c.acct) ? c.acct : '') + '\nRSEC=' + q(m.sec) + '\nKEY2=' + (c.key2 ? 1 : 0) + '\nKEEP=' + (c.keep_days ?? 30) +
'\nNET=' + q(n.mode) + '\nNETGB=' + q(n.gb ?? '') + '\nNETALL=' + (n.all ? 1 : 0) + '\nNETFROM=' + q(n.from ?? '') + '\nNETTO=' + q(n.to ?? '') +
'\nMIRROR=' + (c.kind != 'backup' && c.mirror !== false ? 1 : 0) + '\nOF=' + q(c.of ?? '') + '\nCHECKM=' + (c.check_m ? 1 : 0) + '\nADOPT=' + (c.adopt ? 1 : 0) + '\nWARN=' + (c.warn === false ? 0 : 1);
}
function csrc(c) {
if (!acctok(c.sacct)) return '';
let m = cmapx(c.sacct, c.spath);
return '\nSACCT=' + q(c.sacct) + '\nSREM=' + q(m ? '/' + m.path : (c.spath ?? '/')) + '\nSRSEC=' + q(m?.sec ?? '');
}
function cwrite(c) {
mkdirp(CDIR);
let on = c.on && c.setup !== true && !pstop(ownof(c)), m = cdat(c);
wif(CDIR + '/' + c.id + '.sh', 'NAME=' + q(c.name) + '\nPROV=' + q(c.provider) + '\nDISK=' + q(c.disk) + '\nLPATH=' + q(c.path) + '\nREM=' + q(m.rem) +
'\nDIR=' + q(c.dir) + '\nAT=' + q(c.at) + '\nEVERY=' + (c.every ?? 0) + '\nON=' + (on ? 1 : 0) + '\nKIND=' + q(c.kind ?? 'sync') + '\nCRYPT=' + (c.crypt ? 1 : 0) +
'\nREMV=' + REMV + cmore(c, m) + '\nOWN=' + q(ownof(c)) + csrc(c) + '\n');
}
function cdrive(c, did) {
if (c.provider != 'onedrive') return '';
if (did != null) return '' + did;
return '' + ((DRV ? DRV[c.id] : rcsec(rcname(c))?.drive_id) ?? '');
}
function drvload(L) {
let S = {}, cur = null;
DRV = {};
for (let c in L) if (c.provider == 'onedrive') S[rcname(c)] = c.id;
for (let l in split(readfile(rcf()) ?? '', '\n')) {
let m = match(l, /^\[(.*)\][ \t]*$/);
if (m) { cur = S[m[1]]; continue; }
let kv = match(l, /^drive_id[ \t]*=[ \t]*(.*)$/);
if (cur && kv) DRV[cur] = kv[1];
}
}
function sameacct(a, b, did) {
if (acctok(a.acct) && acctok(b.acct)) return a.acct == b.acct;
if (a.provider != b.provider) return false;
let x = cdrive(a, did), y = cdrive(b);
return !length(x) || !length(y) || x == y;
}
function cin(p, q, qbk) {
if (!(q == '/' ? p != '/' : index(p, q + '/') == 0)) return false;
if (!qbk || q != lc(BKOLD)) return true;
let f = split(substr(p, length(q) + 1), '/')[0];
return f == 'current' || f == 'old';
}
function cover(a, b, did) {
if (a.id == b.id || (a.kind != 'backup' && b.kind != 'backup') || !sameacct(a, b, did)) return false;
let p = lc(a.remote), r = lc(b.remote);
return p == r || cin(p, r, b.kind == 'backup') || cin(r, p, a.kind == 'backup');
}
function cclash(L, c, did) { for (let o in L) if (cover(c, o, did)) return o; return null; }
function cfree(L, c, did, root) {
root ??= BKROOT;
let s = replace(replace(c.name, /["*:<>?|]/g, '_'), /[. ]+$/, '');
if (!length(s) || substr(s, 0, 1) == '.') s = c.id;
for (let n = 1; n <= 30; n++) {
let r = root + '/' + s + (n > 1 ? ' ' + n : '');
if (!cclash(L, { ...c, remote: r }, did)) return r;
}
return root + '/' + c.id;
}
function cryptrem(c) {
let s = rcsec(rcname(c) + 'x');
if (!s || s.remote == asec(c) + ':' + substr(c.remote, 1)) return null;
s.remote = asec(c) + ':' + substr(c.remote, 1);
return s;
}
const CMLK = XLK;
function cmig1() {
let Xc = xget();
if (Xc.cmig === REMV) return Xc;
let B = sort(filter(Xc.cloud, (c) => c.kind == 'backup'), (x, y) => ((x.t ?? 0) - (y.t ?? 0)) || (x.id < y.id ? -1 : x.id > y.id ? 1 : 0));
if (!length(B)) return Xc;
let done = [], off = [];
drvload(Xc.cloud);
mkdirp(CDIR);
for (let c in Xc.cloud) if (c.kind != 'backup' && c.on && cclash(B, c)) { c.on = false; push(off, c); }
for (let c in B) {
let hit = filter(done, (k) => cover(c, k));
if (length(hit)) {
for (let k in hit) if (!stat(CDIR + '/' + k.id + '.keepnext')) writefile(CDIR + '/' + k.id + '.keepnext', '');
detach('sh ' + q(SH) + ' cloudstop ' + q(c.id));
if (c.prev_remote == null) c.prev_remote = c.remote;
c.remote = cfree(filter(Xc.cloud, (o) => o.id != c.id && (o.kind == 'backup' || o.on)), c, null, croot(ownof(c), true) ?? BKROOT);
let cs = c.crypt ? cryptrem(c) : null;
if (cs && !rcset1(rcname(c) + 'x', cs)) die('rcconf');
unlink(CDIR + '/' + c.id + '.vers'); unlink(CDIR + '/' + c.id + '.full'); unlink(X + '/cloud-' + c.id + '.full');
}
push(done, c);
}
for (let c in B) cwrite(c);
for (let c in off) { cwrite(c); detach('sh ' + q(XSH) + ' cloudstop ' + q(c.id)); }
Xc.cmig = REMV; if (!xput(Xc)) die('busy');
for (let c in off) ev('nas_cloud_err', ownof(c) != 'admin' ? L('⚠️ Sincronizzazione Cloud ¦ ' + ovis(ownof(c)) + ': sincronizzazione spenta', '⚠️ Cloud Sync ¦ ' + ovis(ownof(c)) + ': sync turned off') :
L('⚠️ Sincronizzazione Cloud ¦ Spenta: sopra i Backup Cloud ¦ ', '⚠️ Cloud Sync ¦ Off: over Cloud Backups ¦ ') + c.name);
return Xc;
}
function cmig(Xc) {
if (Xc.cmig === REMV || !length(filter(Xc.cloud, (c) => c.kind == 'backup'))) return Xc;
if (!lkget(CMLK)) return null;
let r = null;
XHELD = true;
try { r = cmig1(); } catch (e) { r = null; }
DRV = null; XHELD = false; lkput(CMLK);
return r;
}
function clast(id) {
let m = match(readfile(X + '/cloud-' + id + '.last') ?? readfile(CDIR + '/' + id + '.last') ?? '', /^([0-9]+) ([01]) ([0-9]+) ([0-9]+)/);
return m ? { last: +m[1], ok: m[2] == '1', bytes: +m[3], files: +m[4] } : { last: 0, ok: null, bytes: 0, files: 0 };
}
function adoptfin(Xc) {
let ch = false;
for (let c in Xc.cloud) {
if (c.adopt !== true) continue;
let o = rjs(X + '/cloud-' + c.id + '.adopt.json');
if (o?.state != 'ok') continue;
c.key2 = o.key2 === true; delete c.adopt; cwrite(c); ch = true;
}
if (ch && !xput(Xc)) return null;
return Xc;
}
function acctfix(Xc) {
let AM = null, N = null;
let fx = filter(Xc.cloud, (c) => type(c) == 'object' && length(c.provider ?? '') && (acctok(c.acct) ? (AM ??= amap())[c.acct] == null && length(AM) : !rclinked(rcname(c))));
if (!length(fx) || migrating()) return Xc;
AM ??= amap();
let A = values(AM), ch = [], usr = (a) => type(a?.user) == 'string' && length(a.user) ? a.user : 'admin';
if (!length(A)) return Xc;
fx = filter(fx, (c) => {
if (!acctok(c.acct)) return true;
let r = ud(ownof(c), 'root', null, N ??= nget());
return r != null && index(lc('' + (c.remote ?? '')) + '/', lc(r) + '/') == 0;
});
for (let c in fx) {
let com = filter(A, (a) => a.svc == c.provider && usr(a) == 'admin');
let mine = ownof(c) != 'admin' ? filter(A, (a) => a.svc == c.provider && usr(a) == ownof(c)) : [];
if (length(com) != 1 || length(mine)) continue;
let was = c.acct;
c.acct = com[0].id;
if (cclash(filter(Xc.cloud, (o) => o.id != c.id && acctok(o.acct)), c)) { if (was == null) delete c.acct; else c.acct = was; continue; }
push(ch, c);
}
if (!length(ch)) return Xc;
if (!xput(Xc)) return null;
for (let c in ch) {
let cs = c.crypt ? cryptrem(c) : null;
if (cs) rcset1(rcname(c) + 'x', cs);
cwrite(c);
}
return Xc;
}
function cnext(c, last) {
if (!c.on || length(c.of ?? '')) return 0;
let now = time();
if (length(c.at ?? '')) return nextocc(c.at, c.days);
if (c.every > 0) { let n = (last || now) + c.every * 60; return n > now ? n : now; }
return 0;
}
function cprog(id, disk) {
let p = rjs(X + '/cloud-' + id + '.json');
if (!p || p.state != 'run' || !alive(p.pid)) return null;
let s = stat(TMP + '/speed-' + disk + '.json'), sp = s && time() - s.mtime <= 10 ? rjs(TMP + '/speed-' + disk + '.json') : null;
return { bytes: p.bytes ?? 0, total: p.total ?? 0, files: p.files ?? 0, files_total: p.files_total ?? 0, speed: p.speed ?? 0,
pct: (p.total ?? 0) > 0 ? int((p.bytes ?? 0) * 100 / p.total) : null, t0: p.t0 ?? 0, disk_speed: sp };
}
function cabout(id) {
let a = rjs(X + '/cloud-' + id + '.about') ?? rjs(CDIR + '/' + id + '.about');
if (type(a) != 'object' || type(a.free) != 'int') return null;
let r = { free: a.free, free_t: a.t ?? 0 };
for (let k in [ 'total', 'used' ]) if (type(a[k]) == 'int') r[k] = a[k];
return r;
}
function bkgrp(V, none) {
let n = length(V), last = 0, st = none ?? 'none';
for (let x in V) if (x.ok_t > last) last = x.ok_t;
if (n) {
let has = (k) => length(filter(V, (x) => x.st == k)) > 0;
st = has('bad') ? 'bad' : has('run') ? 'run' : has('warn') ? 'warn' : has('ok') ? 'ok' : 'off';
}
return { n: n, last: last, st: st };
}
function bkst(b, D, A, con, ps) {
let s = bakstate(b.id), m = modeof(b);
let st = b.on === false || !con ? 'off' : bakrun(b) ? 'run' : ps || s.ok === false ? 'bad' :
(b.what?.router !== true && !diskof(D, b.what?.disk)) || (b.dest?.kind != 'nas' && !diskof(D, b.dest?.disk)) ? 'bad' :
late(b, s, A) || (!s.okt && m == 'man') || s.chk ? 'warn' : 'ok';
return { st: st, ok_t: s.okt };
}
function phst(id, p, Xc, N, mn, A, ps, now) {
let cl = p.dest == 'cloud', d = cl ? null : mn, s = cl ? phcstat(id) : phonestat(id, d ? { ...d, p: ud(ownof(p), 'phones', null, N) ?? '' } : null), lt = s.last ?? 0;
let st = Xc.photo.on === false ? 'off' : ps || (!cl && !d) ? 'bad' : lt > 0 && now - lt < 120 ? 'run' : !lt || now - lt >= A.warn_phone * DAY ? 'warn' : 'ok';
return { st: st, ok_t: lt };
}
function ccst(c, s, D, A, AM, ps, now) {
let F = cfacts(c.id), ref = s.last || c.t || 0;
let lt = (c.kind == 'backup' || length(c.at ?? '') || (c.every ?? 0) > 0) && ref > 0 && now - ref > (A.warn_task + daygap(c.days)) * DAY;
let st = c.on !== true ? 'off' : cprog(c.id, c.disk) ? 'run' : ps || !clink2(c, AM) || F.keybad === true || s.ok === false || (!ccloud(c) && !diskof(D, c.disk)) ? 'bad' :
c.setup === true || F.resync === true || lt ? 'warn' : 'ok';
return { st: st, ok_t: s.ok === true ? s.last : 0 };
}
const PST = { ok: [ 'Tutto A Posto', 'All Good' ], warn: [ 'Da Controllare', 'To Check' ], bad: [ 'Non Riuscito', 'Failed' ],
run: [ 'In Corso', 'Running' ], none: [ 'Spento', 'Off' ] };
function prow(own, V, x) {
let g = bkgrp(V), st = PST[g.st] ? g.st : 'none', nv = g.st == 'ok' && !g.last, t = nv ? [ 'Mai Fatto', 'Never Run' ] : PST[st];
if (nv) st = 'none';
return { own: own, own_name: ovis(own), n: g.n, st: st, st_t: t[0], st_t_en: t[1], last: g.last, ...(x ?? {}) };
}
function ppl(L, f, x) {
let G = {}, r = [];
for (let o in L) { let w = ownof(o); if (w == 'admin') continue; if (!G[w]) G[w] = []; push(G[w], f(o)); }
for (let w in sort(keys(G))) push(r, prow(w, G[w], x));
return r;
}
function pstopc(N) { let C = {}; return (own) => { if (!exists(C, own)) C[own] = pstop(own, N); return C[own]; }; }
function bkppl(N, D, A) { let ps = pstopc(N), con = N.bk?.on !== false; return ppl(N.backups, (b) => bkst(b, D, A, con, ps(ownof(b)))); }
function auser(A) { return type(A?.user) == 'string' && length(A.user) ? A.user : 'admin'; }
const PLMAX = 10;
function plist(Xc) { return filter(type(Xc.cpull) == 'array' ? Xc.cpull : [], (c) => type(c) == 'object' && match('' + c.id, /^p[0-9a-z]{1,16}$/) != null); }
function paok(W, A) { return A != null && (W.adm ? auser(A) == 'admin' : auser(A) == W.own); }
function pin(p, b) { return b == '/' || under(p, b); }
function rglob(s) { return replace(s, /[][\\*?{}]/g, (x) => '\\' + x); }
function pskip(own, N) {
let pv = [], bk = [ BKROOT, SYROOT, BKOLD, '/WrtFreedom/Backup' ];
for (let u in people(N)) { if (own == 'admin') push(pv, ud(u, 'root', null, N)); push(bk, croot(u, true), croot(u, false)); }
return { pv: filter(pv, (x) => x != null), bk: filter(bk, (x) => x != null) };
}
function pexcl(c, N) {
let S = pskip(ownof(c), N), r = [], rm = c.remote == '/' ? '' : c.remote;
for (let p in [ ...S.pv, ...S.bk ]) if (lc(p) != lc(c.remote) && pin(p, c.remote)) push(r, '/' + rglob(substr(p, length(rm) + 1)) + '/**');
return uniq(r);
}
function pwrite(c, N) {
mkdirp(CDIR);
N ??= nget();
let on = c.on !== false && !pstop(ownof(c), N), m = cmapx(c.acct, c.remote), n = type(c.net) == 'object' ? c.net : { mode: 'same' };
wif(CDIR + '/' + c.id + '.excl', join('\n', pexcl(c, N)) + '\n');
wif(CDIR + '/' + c.id + '.sh', 'NAME=' + q(c.name) + '\nACCT=' + q(c.acct) + '\nRSEC=' + q(m?.sec ?? 'wf' + c.acct) + '\nREM=' + q(m ? '/' + m.path : c.remote) +
'\nDISK=' + q(c.disk) + '\nLPATH=' + q(c.path) + '\nKEEP=' + (c.keep_days ?? 30) + '\nON=' + (on ? 1 : 0) + '\nWARN=' + (c.warn === false ? 0 : 1) +
'\nNETJ=' + q(sprintf('%J', n)) + '\nOWN=' + q(ownof(c)) + '\n');
}
function pdir(D, c) { return absof(D, c.disk, c.path); }
function pvers(dir) { return dir ? versions(dir + '/old') : []; }
function prow1(c, W, D, AM, pz) {
let s = clast(c.id), d = diskof(D, c.disk), pr = cprog(c.id, c.disk), e = rjs(X + '/cloud-' + c.id + '.json'), A = AM[c.acct], F = cfacts(c.id);
let o = { ...c, on: c.on !== false };
return { id: c.id, name: c.name, kind: 'pull', acct: c.acct, acct_name: A?.name ?? '', svc: c.svc, provider_name: PROV[c.svc] ?? A?.svc_name ?? c.svc,
remote: c.remote, disk: c.disk, path: c.path, at: c.at ?? '', days: daysof(c.days) ?? [], every: c.every ?? 0, on: o.on, keep_days: c.keep_days ?? 30,
net: type(c.net) == 'object' ? c.net : { mode: 'same' }, warn: c.warn !== false, last: s.last, last_ok: s.ok, bytes: s.bytes, files: s.files,
...(s.ok === false && e?.state == 'err' ? { last_err: e.err ?? '', last_err_en: e.err_en ?? '' } : {}),
next: cnext(o, s.last), run: pr != null, prog: pr, missing: d == null, ro: d?.ro === true, ...cst(o, d, AM, s, pr, e, F, pz),
vers_n: d ? length(pvers(pdir(D, c))) : 0, own: ownof(c), own_name: ovis(ownof(c)), personal: A != null && auser(A) != 'admin' };
}
function cloudout(Xc, W) {
W ??= { own: 'admin', adm: true };
let D = disks(), AM = amap(), pz = rcq('paused') === true;
let vis = (A) => W.adm ? true : (auser(A) == W.own || auser(A) == 'admin');
let PP = [];
if (W.adm) {
let N = nget(), A = advof(N), now = time(), ps = pstopc(N);
for (let k in [ 'backup', 'sync' ]) PP = [ ...PP, ...ppl(filter(Xc.cloud, (c) => (c.kind == 'backup') == (k == 'backup')), (c) => ccst(c, clast(c.id), D, A, AM, ps(ownof(c)), now), { kind: k }) ];
PP = [ ...PP, ...ppl(plist(Xc), (c) => ccst({ ...c, on: c.on !== false }, clast(c.id), D, A, AM, ps(ownof(c)), now), { kind: 'pull' }) ];
}
return { list: map(filter(Xc.cloud, (c) => ownof(c) == W.own), (c) => { let s = clast(c.id), d = diskof(D, c.disk), pr = cprog(c.id, c.disk), e = rjs(X + '/cloud-' + c.id + '.json'), bk = c.kind == 'backup';
let A = acctok(c.acct) ? AM[c.acct] : null, F = cfacts(c.id), ab = A ? { free: A.free ?? 0, free_t: A.t_about ?? 0, total: A.total ?? 0, used: A.used ?? 0 } : cabout(c.id);
return { id: c.id, name: c.name, kind: bk ? 'backup' : 'sync', provider: c.provider, provider_name: PROV[c.provider] ?? A?.svc_name ?? c.provider, disk: c.disk, path: c.path, remote: c.remote, dir: c.dir,
at: c.at ?? '', days: daysof(c.days) ?? [], every: c.every ?? 0, on: c.on === true, linked: clinked(c, AM), last: s.last, last_ok: s.ok, bytes: s.bytes, files: s.files,
...(bk ? { crypt: c.crypt === true, pass_saved: c.crypt === true && rcsec(rcname(c) + 'x')?.password != null, keep_days: c.keep_days ?? 30 } : {}),
...(bk && c.prev_remote ? { prev_remote: c.prev_remote } : {}),
...(s.ok === false && e?.state == 'err' ? { last_err: e.err ?? '', last_err_en: e.err_en ?? '' } : {}), ...(ab ?? {}),
next: cnext(c, s.last), run: pr != null, prog: pr, missing: d == null && !ccloud(c), ro: d?.ro === true,
...(ccloud(c) ? { src_acct: c.sacct, src_path: c.spath ?? '/', src_name: AM[c.sacct]?.name ?? '' } : {}),
...(A ? { account: auser(A) == W.own ? A.mail ?? '' : '' } : {}), acct: acctok(c.acct) ? c.acct : '', acct_name: A?.name ?? '', svc: c.provider,
...cst(c, d, AM, s, pr, e, F, pz), net: type(c.net) == 'object' ? c.net : { mode: 'same' }, of: c.of ?? '', also: c.also ?? '',
key2: c.key2 === true, key_t: nint(F.key_t), check_m: c.check_m === true, warn: c.warn !== false, conflicts: nint(F.conflicts),
mirror: !bk && c.mirror !== false, old_bytes: nint(F.old_bytes),
own: ownof(c), own_name: ovis(ownof(c)), personal: A != null && auser(A) != 'admin' }; }),
pull: map(filter(plist(Xc), (c) => ownof(c) == W.own), (c) => prow1(c, W, D, AM, pz)),
rclone: !length(need('rclone')), providers: keys(PROV), acct_n: length(filter(values(AM), vis)), ...(W.adm ? { people: PP } : {}) };
}
function pullcall(W, a, act, Xc, AM) {
let id = '' + (a.id ?? ''), L = plist(Xc), N = nget(), D = disks(), i = -1;
for (let k = 0; k < length(L); k++) if (L[k].id == id && (W.adm || ownof(L[k]) == W.own)) i = k;
if (i >= 0 && W.adm && ownof(L[i]) != 'admin') return err('private', 'Lavoro di un\'altra persona', 'Another person\'s job');
let c = i >= 0 ? L[i] : null, out = (x) => ({ ...cloudout(Xc, W), ...(x ?? {}) });
let save = () => { Xc.cpull = L; return xput(Xc); };
let eacct = () => err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
let eacp = () => err('private', 'Cloud di un\'altra persona', 'Another person\'s cloud');
let ready = (c) => {
let P = need('rclone'); if (length(P)) return pkgerr(P);
let pe = pstop(W.own, N); if (pe) return pe;
let A = AM[c.acct];
if (!A) return eacct();
if (!paok(W, A)) return eacp();
if (!clinked(c, AM)) return err('link', 'Collega di nuovo l\'account', 'Connect the account again');
if (cmapx(c.acct, c.remote)?.wait) return err('wait', 'Cartella in cifratura: riprova fra poco', 'Folder being encrypted: try again shortly');
return null;
};
if (act == 'set') {
let isnew = c == null;
if (!isnew && a.kind != null && a.kind != 'pull') return err('kind', 'Il tipo non si cambia: crea un nuovo backup', 'The type cannot change: create a new backup');
if (isnew && length(id)) return err('none', 'Backup non trovato', 'Backup not found');
if (isnew && length(filter(L, (o) => ownof(o) == W.own)) >= PLMAX) return err('max', 'Al massimo ' + PLMAX + ' backup del cloud', 'At most ' + PLMAX + ' cloud backups');
if (!W.adm && a.net != null && netok(a.net)?.mode != 'same') return eadm();
let A = AM['' + (a.acct ?? c?.acct ?? '')];
if (!A) return eacct();
if (!paok(W, A)) return eacp();
if (c && a.acct != null && '' + a.acct != c.acct) return err('acct', 'L\'account non si cambia: crea un nuovo backup', 'The account cannot change: create a new backup');
let rp = relp('' + (a.remote ?? c?.remote ?? '/'));
if (rp == null || length('' + (a.remote ?? '')) > 512) return err('remote', 'Cartella del cloud non valida', 'Invalid cloud folder');
let rm = '/' + join('/', rp);
if (c && lc(rm) != lc(c.remote)) return err('remote', 'La cartella del cloud non si cambia: crea un nuovo backup', 'The cloud folder cannot change: create a new backup');
let S = pskip(W.own, N);
for (let p in S.pv) if (under(rm, p)) return errp();
for (let p in S.bk) if (under(rm, p)) return err('remote', 'Cartella dei backup del disco: non si sceglie', 'Drive backup folder: it cannot be chosen');
if (cmapx(A.id, rm)?.wait) return err('wait', 'Cartella in cifratura: riprova fra poco', 'Folder being encrypted: try again shortly');
for (let o in L) if (o.id != id && o.acct == A.id && (pin(rm, o.remote) || pin(o.remote, rm))) return err('remote', 'Cartella del cloud già salvata da «' + o.name + '»', 'Cloud folder already saved by «' + o.name + '»');
let mn = mainof(D, N), dk = c?.disk;
if (isnew) {
if (a.disk != null && !W.adm && '' + a.disk != mn?.id) return eadm();
dk = '' + (a.disk ?? mn?.id ?? '');
if (!length(dk)) return nomain();
let d = dsk(D, dk, true);
if (d.error) return d;
}
let lq = filter(rp, (x) => length(x)), nm = trim('' + (a.name ?? c?.name ?? cutb(replace((A.name ?? PROV[A.svc] ?? A.svc) + (length(lq) ? ' ' + lq[length(lq) - 1] : ''), /[[:cntrl:]\/\\]/g, '_'), 40)));
if (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/) || substr(nm, 0, 1) == '.') return err('name', 'Nome non valido', 'Invalid name');
for (let o in L) if (o.id != id && ownof(o) == W.own && lc(o.name) == lc(nm)) return err('name', 'Nome già usato da un altro backup', 'Name already used by another backup');
let pth = c?.path;
if (isnew) {
let ne = bknameok(N, W.own, '', nm); if (ne) return ne;
pth = ud(W.own, 'backup', nm, N);
if (pth == null) return errp();
let ab = absof(D, dk, pth);
if (!ab) return err('path', 'Cartella non valida', 'Invalid folder');
if (length(lsdir(ab) ?? [])) return err('name', 'Cartella già usata sul disco: scegli un altro nome', 'Folder already used on the drive: choose another name');
}
let at = '' + (a.at ?? c?.at ?? (isnew && a.every == null ? '03:40' : '')), every = a.every ?? c?.every ?? 0;
if (length(at) && !hhmm(at)) return err('at', 'Orario non valido', 'Invalid time');
if (type(every) != 'int' || every < 0 || every > 1440 || (every > 0 && (every < 15 || every % 5))) return err('every', 'Ogni quanti minuti: da 15 a 1440, a passi di 5', 'Every how many minutes: 15 to 1440, in steps of 5');
if (length(at) && every > 0) return err('when', 'Scegli un orario oppure ogni quanti minuti', 'Choose a time or every how many minutes');
if (a.days != null && type(a.days) != 'array') return err('days', 'Giorni non validi', 'Invalid days');
let dys = length(at) ? daysof(a.days ?? c?.days) : null, kd = a.keep_days ?? c?.keep_days ?? 30;
if (index([ 7, 30, 90, 365 ], kd) < 0) return err('keep', 'Tieni Per: 7, 30, 90 o 365 giorni', 'Keep For: 7, 30, 90 or 365 days');
let net = type(c?.net) == 'object' ? c.net : { mode: 'same' };
if (a.net != null) { net = netok(a.net); if (!net) return err('net', 'Rete Da Usare non valida', 'Invalid Network To Use'); }
let on = type(a.on) == 'bool' ? a.on : c?.on !== false;
if (on) { let P = need('rclone'); if (length(P)) return pkgerr(P); }
let o = { id: c?.id ?? 'p' + rid(), name: nm, acct: A.id, svc: A.svc, remote: rm, disk: dk, path: pth, at: at, ...(dys ? { days: dys } : {}), every: every, on: on,
keep_days: kd, net: net, warn: type(a.warn) == 'bool' ? a.warn : c?.warn !== false, t: c?.t ?? time(), ...(W.adm ? {} : { own: W.own }) };
if (isnew) push(L, o); else L[i] = o;
if (!save()) return busy();
pwrite(o, N);
return out({ id: o.id });
}
if (!c) return err('none', 'Backup non trovato', 'Backup not found');
if (act == 'del') {
detach('sh ' + q(SH) + ' cloudstop ' + q(id));
L = filter(L, (o) => o.id != id);
if (!save()) return busy();
for (let e in [ '.sh', '.excl', '.last', '.st' ]) unlink(CDIR + '/' + id + e);
for (let e in [ '.json', '.last', '.log', '.day' ]) unlink(X + '/cloud-' + id + e);
return out();
}
if (act == 'stop') { detach('sh ' + q(SH) + ' cloudstop ' + q(id)); return out(); }
if (act == 'run') {
if (!nason()) return err('off', 'Il NAS è spento', 'The NAS is off');
let e = ready(c); if (e) return e;
let d = dsk(D, c.disk, true);
if (d.error) return d;
if (cprog(id, c.disk)) return err('run', 'Questo backup è già in corso', 'This backup is already running');
pwrite(c, N);
detach('sh ' + q(SH) + ' cpull ' + q(id));
return { job: id };
}
if (!match(act, /^(versions|browse|restore|free)$/)) return err('act', 'Azione sconosciuta', 'Unknown action');
let d = dsk(D, c.disk, act == 'free'), dir = d.error ? null : pdir(D, c);
if (d.error) return d;
if (!dir) return err('path', 'Cartella non valida', 'Invalid folder');
let V = pvers(dir), cur = stat(dir + '/current')?.type == 'directory', s = clast(id);
if (act == 'versions')
return { list: [ ...(cur ? [ { stamp: 'current', t: s.ok === true ? s.last : (stat(dir + '/current').mtime ?? 0), kind: 'mirror' } ] : []),
...map(reverse(V), (v) => ({ stamp: v, t: stampt(v), kind: 'day' })) ], disk: c.disk, path: c.path };
if (act == 'free') {
let kd = a.keep_days;
if (type(kd) != 'int' || kd < 1 || kd > 3650) return err('keep', 'Giorni non validi', 'Invalid days');
if (cprog(id, c.disk)) return err('run', 'Questo backup è in corso: riprova alla fine', 'This backup is running: try again when it ends');
let j = 'bak-f' + rid();
mkdirp(JOBS);
wjs(JOBS + '/' + j + '.json', { id: j, op: 'free', name: c.name, done: 0, total: 0, bytes: 0, bytes_total: 0, file: '', state: 'run', t: time() });
detach('sh ' + q(SH) + ' cpullfree ' + q(id) + ' ' + kd + ' ' + q(j));
return { job: j };
}
let sp = '' + (a.stamp ?? 'current');
if (!((sp == 'current' && cur) || index(V, sp) >= 0)) return err('stamp', 'Versione non trovata', 'Version not found');
let vd = dir + '/' + (sp == 'current' ? 'current' : 'old/' + sp);
if (act == 'browse') {
let bp = relok(a.path ?? '/'), b = bp == null ? null : vd + (bp == '/' ? '' : bp);
if (b == null || !inside(vd, b) || stat(b)?.type != 'directory') return err('path', 'Percorso non valido', 'Invalid path');
let r = [];
for (let n in sort(lsdir(b) ?? [])) {
if (substr(n, 0, 4) == '.wf-' || length(r) >= 2000) continue;
let st = lstat(b + '/' + n);
if (st && (st.type == 'directory' || st.type == 'file')) push(r, { name: n, dir: st.type == 'directory', size: st.type == 'file' ? st.size : 0, mtime: st.mtime });
}
return { items: r, path: bp, stamp: sp };
}
let PS = type(a.paths) == 'array' && length(a.paths) ? a.paths : [ '/' ], to = '' + (a.to ?? 'cloud'), lines = [], tb = null;
if (length(PS) > 500) return err('max', 'Al massimo 500 file per volta', 'At most 500 files at a time');
if (to == 'cloud') { let e = ready(c); if (e) return e; }
else {
let r2 = relok(to);
if (r2 == null || d.ro) return err('to', 'Cartella di arrivo non valida', 'Invalid destination folder');
let te = csrcok(W, D, N, d, r2); if (te) return te;
tb = absof(D, d.id, r2);
if (!tb || under(tb, dir)) return err('to', 'Cartella di arrivo non valida', 'Invalid destination folder');
}
for (let p in PS) {
p = relok(p);
let src = p == null ? null : vd + (p == '/' ? '' : p);
if (src == null || !inside(vd, src) || !lstat(src)) return err('path', 'Percorso non valido', 'Invalid path');
push(lines, src + '\t' + (tb == null ? (p == '/' ? '' : p) : tb + (p == '/' ? '' : p)));
}
if (cprog(id, c.disk)) return err('run', 'Questo backup è in corso: riprova alla fine', 'This backup is running: try again when it ends');
let j = 'bak-r' + rid();
mkdirp(JOBS);
writefile(JOBS + '/' + j + '.list', join('\n', lines) + '\n');
wjs(JOBS + '/' + j + '.json', { id: j, op: 'restore', name: c.name, done: 0, total: 0, bytes: 0, bytes_total: 0, file: '', state: 'run', t: time(), root: rpath(d.mnt) ?? d.mnt });
detach('sh ' + q(SH) + (tb == null ? ' cpullput ' + q(j) + ' ' + q(id) : ' restore ' + q(j)));
return { job: j };
}
function tokof(s) {
s = '' + s;
if (length(s) > 16384 || match(s, /[[:cntrl:]]/)) return null;
let o = null; try { o = json(s); } catch (e) { o = null; }
return type(o) == 'object' && type(o.access_token) == 'string' && length(o.access_token) ? sprintf('%J', o) : null;
}
function rclink(c, a, tk) {
let kv = { type: c.provider, token: tk };
if (c.provider == 'drive') kv.scope = 'drive';
if (c.provider == 'onedrive') { kv.drive_id = '' + a.drive_id; kv.drive_type = '' + (a.drive_type ?? 'personal'); }
if (a.client_id != null) kv.client_id = '' + a.client_id;
if (a.client_secret != null) kv.client_secret = '' + a.client_secret;
return kv;
}
function linkchk(a, pv, tk) {
for (let k in [ 'client_id', 'client_secret', 'drive_id' ]) if (a[k] != null && !match('' + a[k], /^[A-Za-z0-9!._~-]{1,200}$/)) return err(k, 'Dati del collegamento non validi', 'Invalid connection data');
if (a.drive_type != null && !match('' + a.drive_type, /^(personal|business|documentLibrary)$/)) return err('drive_type', 'Dati del collegamento non validi', 'Invalid connection data');
if (pv == 'onedrive' && tk && a.drive_id == null) return err('drive_id', 'OneDrive: manca l\'unità', 'OneDrive: drive missing');
return null;
}
const TOKMAX = 600;
function tokf(pv) { return X + '/.tok-' + pv; }
function tokput(pv, o) {
mkdirp(X);
let f = tokf(pv), t = f + '.' + PID + '.t';
sh('umask 077; : > ' + q(t));
let h = open(t, 'w');
if (!h) return false;
h.write(sprintf('%J', o)); h.close();
return rename(t, f);
}
function tokget(pv) {
let o = rjs(tokf(pv));
if (o && type(o.token) == 'string' && time() - (o.t ?? 0) <= TOKMAX) return o;
if (o) unlink(tokf(pv));
return null;
}

function hist() {
let H = {};
for (let l in split(readfile(BKD + '/hist') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) < 3 || !match(p[0], /^[0-9]{8}$/)) continue;
let h = H[p[0]] ?? { b: 0, ok: 0, err: 0 };
h.b += num(p[2]); if (p[1] == '1') h.ok++; else h.err++;
H[p[0]] = h;
}
return H;
}
function protect() {
let N = nget(), Xc = xget(), D = disks(), A = advof(N), P = persons(), nb = neigh(), now = time(), MC = rjs(BKD + '/macs.json') ?? {};
let devs = [];
let dev = (kind, mac, name, last, bytes, extra) => {
let w = kind == 'phone' ? A.warn_phone : A.warn_pc, days = last > 0 ? int((now - last) / DAY) : -1;
push(devs, { mac: mac ?? '', name: name, kind: kind, last: last, bytes: bytes ?? 0, days: days, ok: last > 0 && now - last < w * DAY, ...(extra ?? {}) });
};
if (Xc.photo.on !== false) for (let id, p in Xc.photo.phones) {
let L = phloc(D, N, p), d = p.dest == 'cloud' ? null : L.d, s = p.dest == 'cloud' ? phcstat(id) : phonestat(id, d ? { ...d, p: L.path } : null);
dev('phone', phmac(id, p), p.name, s.last ?? 0, s.bytes ?? 0, { id: id, own: ownof(p) });
}
for (let c in pclist(N, D)) {
let mac = MC[c.kind]?.[c.name] ?? '';
if (!mac) for (let m, n in nb.name) if (nkey(n) == nkey(c.name)) mac = m;
dev(c.kind, mac, c.name, c.last, c.bytes, { own: ownof(c) });
}
let people = [], other = [];
for (let p in P) {
let ds = filter(devs, (d) => length(d.mac) && index(p.macs, d.mac) >= 0);
if (length(ds)) push(people, { id: p.id, name: p.name, ok: length(filter(ds, (d) => d.ok)), all: length(ds), devs: ds });
}
for (let d in devs) if (!length(d.mac) || !personof(P, d.mac)) push(other, d);
let tasks = [], tlast = 0, disk = 0;
for (let b in N.backups) {
let s = bakstate(b.id), lt = late(b, s, A);
if (s.okt > tlast) tlast = s.okt;
disk += s.size;
push(tasks, { id: b.id, name: b.name, mode: modeof(b), on: b.on !== false, last: s.okt, ok: s.ok, late: lt, run: bakrun(b), own: ownof(b) });
}
let nasok = length(tasks) > 0 && !length(filter(tasks, (t) => t.late || (t.on && t.mode == 'night' && t.ok === false)));
let CB = filter(Xc.cloud, (c) => c.kind == 'backup'), AM = length(CB) ? amap() : {}, clok = true, cll = 0;
for (let c in CB) {
let s = clast(c.id);
if (s.last > cll) cll = s.last;
if (c.on !== true) continue;
if (c.setup === true || !clinked(c, AM) || !s.last || s.ok === false || cfacts(c.id).keybad === true || now - s.last > (A.warn_task + (length(c.at ?? '') ? daygap(c.days) : 0)) * DAY) clok = false;
}
let ncl = length(CB) ? 1 : 0;
let all = length(devs) + (length(tasks) ? 1 : 0) + ncl, ok = length(filter(devs, (d) => d.ok)) + (length(tasks) && nasok ? 1 : 0) + (ncl && clok ? 1 : 0), miss = all - ok, last = tlast > cll ? tlast : cll;
for (let d in devs) { disk += d.bytes; if (d.last > last) last = d.last; }
let H = hist(), night = [], skip = [];
for (let i = 13; i >= 0; i--) {
let t = localtime(now - i * DAY), k = sprintf('%04d%02d%02d', t.year, t.mon, t.mday), h = H[k];
push(night, h ? int(h.b / 107374182.4) / 10 : 0);
if (h && h.err > 0) push(skip, 13 - i);
}
let cl = null;
for (let c in Xc.cloud) if (c.kind == 'backup') { let s = clast(c.id); if (!cl || s.last > cl.last) cl = { id: c.id, name: c.name, provider_name: PROV[c.provider], last: s.last, ok: s.ok, bytes: s.bytes, on: c.on === true, own: ownof(c) }; }
let k = N.bk.on === false ? 'off' : (!all ? 'none' : (miss ? 'warn' : 'ok'));
let T = { off: [ 'Spento', 'Off' ], none: [ 'Da Configurare', 'To Set Up' ], warn: [ 'Da Controllare', 'To Check' ], ok: [ 'Protetto', 'Protected' ] };
let line = all ? ok + ' di ' + all + ' protetti' + (miss ? ' · ' + miss + ' senza copia' : '') : 'Nessun backup';
let line_en = all ? ok + ' of ' + all + ' protected' + (miss ? ' · ' + miss + ' without a copy' : '') : 'No backups';
let ro = [], phd = {};
for (let pid, p in Xc.photo.phones) phd[p.disk] = 1;
for (let d in D) if (d.ro && (N.tm?.disk == d.id || N.fh?.disk == d.id || phd[d.id] || length(filter(N.backups, (b) => b.dest?.disk == d.id)))) push(ro, d.name);
return { sum: { ok: ok, all: all, miss: miss, k: k, t: T[k][0], t_en: T[k][1], line: line, line_en: line_en, last: last, disk: disk, nas: length(tasks) ? nasok : null,
cloud: { n: length(CB), last: cll, ok: ncl ? clok : null },
...(length(ro) ? { ro: ro, ro_t: 'Disco in sola lettura: Time Machine, foto e backup su ' + join(', ', ro) + ' non scrivono',
ro_t_en: 'Read-only drive: Time Machine, photos and backups on ' + join(', ', ro) + ' cannot write' } : {}) },
people: people, other: other, tasks: tasks, night: night, night_skip: skip, cloud: cl, adv: A, on: N.bk.on !== false };
}

function alldevs(P) { let r = [ ...P.other ]; for (let p in P.people) for (let d in p.devs) push(r, d); return r; }
function protadm(P) {
let mine = (d) => (d.own ?? 'admin') == 'admin', V = [];
for (let d in alldevs(P)) if (!mine(d)) push(V, d);
let H = [];
for (let p in P.people) {
let ds = filter(p.devs, mine);
if (length(ds)) push(H, { ...p, ok: length(filter(ds, (d) => d.ok)), all: length(ds), devs: ds });
}
let cl = null;
for (let c in xget().cloud) if (c.kind == 'backup' && ownof(c) == 'admin') { let s = clast(c.id); if (!cl || s.last > cl.last) cl = { id: c.id, name: c.name, provider_name: PROV[c.provider], last: s.last, ok: s.ok, bytes: s.bytes, on: c.on === true, own: 'admin' }; }
return { ...P, people: [ ...H, ...ppl(V, (d) => ({ st: d.ok ? 'ok' : 'warn', ok_t: d.last ?? 0 })) ], other: filter(P.other, mine), tasks: filter(P.tasks, mine), cloud: cl };
}

const BKOWN = TMP + '/bk-own.json';
function bkownbg() { detach('sh ' + q(SH) + ' bkown'); }
function bkown() {
let N = nget(), D = disks(), Xc = xget(), A = advof(N), now = time(), mn = mainof(D, N), AM = null, O = {};
let PC = pclist(N, D), con = N.bk?.on !== false;
for (let own in [ 'admin', ...people(N) ]) {
let ps = pstop(own, N), nx = [];
let B = map(filter(N.backups, (b) => ownof(b) == own), (b) => {
let bn = baknext(b);
if (bn > 0) push(nx, bn);
return bkst(b, D, A, con, ps);
});
let P = [];
for (let id, p in Xc.photo.phones) if (ownof(p) == own) push(P, phst(id, p, Xc, N, mn, A, ps, now));
let C = [];
for (let c in Xc.cloud) {
if (ownof(c) != own) continue;
AM ??= amap();
let s = clast(c.id), cn = cnext(c, s.last);
if (cn > 0) push(nx, cn);
push(C, ccst(c, s, D, A, AM, ps, now));
}
let pcon = N.tm?.on === true || N.fh?.on === true, PL = [];
for (let c in PC) {
if (ownof(c) != own) continue;
let st = !pcon ? 'off' : !c.last ? 'warn' : now - c.last < 900 ? 'run' : now - c.last >= A.warn_pc * DAY ? 'warn' : 'ok';
push(PL, { name: c.name, kind: c.kind == 'tm' ? 'mac' : 'pc', last: c.last ?? 0, st: st, ok_t: c.last ?? 0 });
}
let g = { phone: bkgrp(P), dirs: bkgrp(B), cloud: bkgrp(C), pc: { ...bkgrp(PL, pcon ? 'none' : 'off'), list: map(PL, (x) => ({ name: x.name, kind: x.kind, last: x.last, st: x.st })) } };
let all = [ ...P, ...B, ...C, ...PL ], T = bkgrp(all), nb = length(filter(all, (x) => x.st == 'bad'));
let nxt = 0; for (let t in nx) if (!nxt || t < nxt) nxt = t;
O[own] = { last: T.last, ok: T.n > 0 && !nb && !length(filter(all, (x) => x.st == 'warn')), n: T.n, next: nxt, err: nb, st: T.st, ...g };
}
wif(BKOWN, sprintf('%J', O));
return O;
}

function warned(W, key, on, t, txt, okt, oktxt) {
if (on && !W[key]) { W[key] = time(); ev(t, txt); return true; }
if (!on && W[key]) { delete W[key]; if (okt) ev(okt, oktxt); return true; }
return false;
}
function bkmacs(N, PC) {
if (!has('/usr/bin/smbstatus') && !has('/usr/sbin/smbstatus')) return;
let now = time(), BZ = { tm: filter(PC, (c) => c.kind == 'tm' && now - c.last < 900), fh: filter(PC, (c) => c.kind == 'fh' && now - c.last < 900) };
if (length(BZ.tm) != 1 && length(BZ.fh) != 1) return;
let MC = rjs(BKD + '/macs.json') ?? {}, nb = neigh(), ch = false;
let SN = { tm: [ (UCFG.UDIR?.tm ?? 'Backup Del Mac') + ' (', 'Time Machine ' ], fh: [ (UCFG.UDIR?.fh ?? 'Backup Del PC') + ' (', 'Cronologia File ' ] };
let o = sh('smbstatus -S 2>/dev/null');
for (let k in [ 'tm', 'fh' ]) {
let ips = [], busy = BZ[k];
if (length(busy) != 1) continue;
for (let l in split(o, '\n')) for (let p in SN[k]) {
if (substr(l, 0, length(p)) != p) continue;
let r = substr(l, length(p)), e = index(r, ') ');
if (substr(p, -1) == '(') { if (e < 0) continue; r = substr(r, e + 1); }
let f = split(trim(r), /[ \t]+/);
if (match(f[1] ?? '', /^[0-9a-fA-F.:]+$/)) push(ips, f[1]);
}
ips = uniq(ips);
if (length(ips) == 1 && nb.ip[ips[0]]) {
if (type(MC[k]) != 'object') MC[k] = {};
if (MC[k][busy[0].name] != nb.ip[ips[0]]) { MC[k][busy[0].name] = nb.ip[ips[0]]; ch = true; }
}
}
if (ch) { mkdirp(BKD); wjs(BKD + '/macs.json', MC); }
}
function dused(ds) { let s = vfs(ds.d.mnt); return s.total > 0 ? int((s.total - s.free) * 100 / s.total) : 0; }
function pruneone(ds, p, cap) {
if (dused(ds) < cap) return 0;
let f0 = vfs(ds.d.mnt).free;
sh('rm -rf ' + q(p));
return vfs(ds.d.mnt).free - f0 >= 1048576 ? 1 : 2;
}
function prunewarn(b, n, full) {
let nm = ownof(b) != 'admin' ? ovis(ownof(b)) : b.name;
if (n > 0) ev('nas_backup_err', L('⚠️ Backup ¦ Disco quasi pieno ¦ Versioni vecchie tolte: ' + n + ' ¦ ' + nm,
'⚠️ Backup ¦ Drive almost full ¦ Old versions removed: ' + n + ' ¦ ' + nm));
let f = TMP + '/bk-' + b.id + '.full';
if (full && time() - (num(trim(readfile(f) ?? '')) ?? 0) >= DAY) {
writefile(f, '' + time());
ev('nas_backup_err', L('⚠️ Backup ¦ Disco pieno di altri file ¦ Le versioni restano ¦ ' + nm, '⚠️ Backup ¦ Drive full of other files ¦ Versions kept ¦ ' + nm));
}
}
function bkprune(id) {
begin();
let N = nget(), D = disks(), A = advof(N), b = null;
for (let x in N.backups) if (x.id == id) b = x;
if (!b) return { ok: false };
let ds = bakdst(D, b);
if (!ds || ds.d.ro) return { ok: false };
let V = versions(ds.abs), now = time(), keep = {}, day = {}, week = {}, gone = [];
for (let i = length(V) - 1; i >= 0; i--) {
let v = V[i], t = stampt(v), age = now - t;
if (i == length(V) - 1 || age < DAY) { keep[v] = 1; continue; }
if ((b.keep_days ?? 0) > 0 && age > b.keep_days * DAY) continue;
if (age < 31 * DAY) { let k = substr(v, 0, 8); if (!day[k]) { day[k] = 1; keep[v] = 1; } continue; }
let k = '' + int((t + 3 * DAY) / (7 * DAY));
if (!week[k]) { week[k] = 1; keep[v] = 1; }
}
for (let v in V) if (!keep[v]) push(gone, v);
if (stat(ds.abs + '/current')?.type == 'directory') {
let ob = ds.abs + '/old', OV = versions(ob);
for (let v in OV) if ((b.keep_days ?? 0) > 0 && now - stampt(v) > b.keep_days * DAY) sh('rm -rf ' + q(ob + '/' + v));
OV = versions(ob);
if (A.full == 'prune') {
let n = 0, r = 1;
while (r == 1 && length(OV) && (r = pruneone(ds, ob + '/' + OV[0], A.cap))) { OV = slice(OV, 1); n++; }
prunewarn(b, n, length(OV) > 0 && dused(ds) >= A.cap);
}
if (!length(V)) { wif(BKD + '/' + id + '.nv', '' + (1 + length(OV))); return { ok: true, versions: 1 + length(OV) }; }
}
if (A.full == 'prune') {
let K = filter(V, (v) => keep[v]);
for (let v in gone) sh('rm -rf ' + q(ds.abs + '/' + v));
gone = [];
let n = 0, r = 1;
while (r == 1 && length(K) > 1 && (r = pruneone(ds, ds.abs + '/' + K[0], A.cap))) { K = slice(K, 1); n++; }
prunewarn(b, n, length(K) > 1 && dused(ds) >= A.cap);
wif(BKD + '/' + id + '.nv', '' + length(K));
return { ok: true, versions: length(K) };
}
for (let v in gone) sh('rm -rf ' + q(ds.abs + '/' + v));
wif(BKD + '/' + id + '.nv', '' + length(versions(ds.abs)));
return { ok: true, versions: length(V) - length(gone) };
}
const PHORD = ETC + '/photo-order.json', PHORDD = ETC + '/photo-order';
const PHREN = ETC + '/photo-rename.json';
function phsec(acct) { return match('' + acct, /^a[0-9]{1,3}$/) ? 'wfa' + substr(acct, 1) : null; }
function rcenv() { return 'RCLONE_CONFIG=' + q(RCONF) + ' RCLONE_CACHE_DIR=' + q(X + '/rclone-cache') + ' rclone '; }
function rcrun(a) { return +trim(sh(rcenv() + a + ' </dev/null >/dev/null 2>&1; echo $?')); }
function rcls(p) {
let o = sh(rcenv() + 'lsf --files-only ' + q(p) + ' </dev/null 2>/dev/null; echo "#$?"'), m = match(o, /#([0-9]+)[ \t\n]*$/), rc = m ? +m[1] : 1;
if (rc == 3) return [];
if (rc != 0) return null;
return filter(split(replace(o, /#[0-9]+[ \t\n]*$/, ''), '\n'), (x) => length(x) && substr(x, -1) != '/');
}
function phjmv(B, J, o) {
let H = {}, G = {}, one = [], dd = {}, sp = (p) => { let m = match(p, /^(.*)\/([^\/]+)$/); return m ? m : [ p, '', p ]; }, pa = (d) => length(d) ? B + '/' + d : B;
for (let e in J) {
let a = sp(e[0]), b = sp(e[1]);
if (!exists(H, a[1])) { let l = rcls(pa(a[1])); if (l == null) return false; H[a[1]] = {}; for (let x in l) H[a[1]][x] = 1; }
if (length(a[1])) dd[a[1]] = 1;
if (!H[a[1]][a[2]]) continue;
if (a[2] == b[2] && length(a[1])) { let k = a[1] + '\n' + b[1]; G[k] = G[k] ?? []; push(G[k], a[2]); }
else push(one, e);
}
let lf = X + '/phmove.list';
for (let k, l in G) {
let p = split(k, '\n');
writefile(lf, join('\n', l) + '\n');
let rc = rcrun('move ' + q(pa(p[0])) + ' ' + q(pa(p[1])) + ' --files-from-raw ' + q(lf) + o);
unlink(lf);
if (rc != 0) return false;
}
for (let e in one) if (rcrun('moveto ' + q(B + '/' + e[0]) + ' ' + q(B + '/' + e[1]) + o) != 0) return false;
for (let d in keys(dd)) rcrun('rmdir ' + q(B + '/' + d));
return true;
}
function phlk(K) {
if (mkdir(K)) { writefile(K + '/pid', PID); return true; }
if (alive(trim(readfile(K + '/pid') ?? ''))) return false;
sh('rm -rf ' + q(K));
if (mkdir(K)) { writefile(K + '/pid', PID); return true; }
return false;
}
function phunlk(K) { if (trim(readfile(K + '/pid') ?? '') == PID) sh('rm -rf ' + q(K)); }
function phatgt(Xc, own) {
let id = type(Xc.photo.also) == 'object' ? Xc.photo.also[own] : null;
for (let c in Xc.cloud) if (id != null && c.id == id) {
let s = phsec(c.acct), m = s ? cmapx(c.acct, c.remote) : null;
if (m) return { id: id, sec: m.sec, base: m.sec + ':' + m.path, wait: m.wait };
return s ? { id: id, sec: s, base: s + ':' + replace('' + (c.remote ?? ''), /^\/+/, '') } : null;
}
return null;
}
function phcmv(id, ph, lg) {
let sec = phsec(ph.acct), J = [], M = {}, used = {}, cm = sec ? cmapx(ph.acct, ph.remote) : null, base = sec + ':' + ph.remote;
if (!sec || cm?.wait) return 'cloud';
if (cm) base = cm.sec + ':' + cm.path;
let L = filter(map(split(phidxraw(id), '\n'), (l) => split(l, '\t')), (p) => (length(p) == 4 || length(p) == 5) && match(p[0], /^[0-9]+$/));
for (let p in L) if (length(p) == 5) { let y = match(p[1], /^([0-9]{4})\/([0-9]{2})$/), ym = y ? ymok(+y[1], +y[2]) : null; if (ym) used[phsub(ym, p[3], lg) + '/' + p[3]] = 1; }
for (let p in L) {
if (length(p) != 4) continue;
let y = match(p[1], /^([0-9]{4})\/([0-9]{2})$/), ym = y ? ymok(+y[1], +y[2]) : null;
if (!ym) continue;
let sub = phsub(ym, p[3], lg), m = match(p[3], /^(.+)(\.[^.]+)$/), b = m ? m[1] : p[3], x = m ? m[2] : '', fn = p[3];
for (let i = 2; i < 10000 && used[sub + '/' + fn]; i++) fn = b + ' (' + i + ')' + x;
used[sub + '/' + fn] = 1;
push(J, [ p[1] + '/' + p[3], substr(sub, 1) + '/' + fn, 0 ]);
M[p[1] + '/' + p[3]] = fn;
}
if (!length(J)) return 'done';
if (!phjmv(base, J, ' --ignore-existing')) return 'cloud';
let K = X + '/phq-' + id + '.lock';
if (!lkget(K)) return 'cloud';
try {
let out = [];
for (let l in split(phidxraw(id), '\n')) {
let p = split(l, '\t'), f = length(p) == 4 ? M[p[1] + '/' + p[3]] : null;
if (f != null) l = join('\t', [ p[0], p[1], p[2], f, 'n' ]);
if (length(l)) push(out, l);
}
let s = join('\n', out) + '\n';
if (phdirs()) wif(PHIDX + '/' + id + '.idx', s);
} catch (e) {}
lkput(K);
phsync(id);
return 'done';
}
function phmvp(D, N, Xc, own, lg, stamp) {
let L = phloc(D, N, { own: own }), a = null, O = [], JF = PHORDD + '/' + own + '.json', J = rjs(JF), PO = [];
if (type(J) != 'array' || !length(J)) J = null;
if (type(N.main) == 'object' && !L.d) return 'disk';
if (L.d) {
if (!length(L.path)) return 'path';
a = absp(L.d, L.path);
if (!a) return 'path';
if (stat(a.abs)?.type == 'directory') O = phold(a.abs);
if (length(O) && L.d.ro) return 'ro';
}
for (let id, p in Xc.photo.phones) if (p.dest == 'cloud' && ownof(p) == own && phidx(id).old > 0) push(PO, [ id, p ]);
if (!length(O) && !J && !length(PO)) return 'done';
if (!lg) return 'lang';
for (let x in PO) if (phcmv(x[0], x[1], lg) != 'done') return 'cloud';
if (!length(O) && !J) return 'done';
let C = phatgt(Xc, own);
if (C?.wait) return 'cloud';
if (!C && J) { unlink(JF); J = null; }
let K = C ? X + '/cloud-' + C.id + '.lock' : null, bd = C ? ' --backup-dir ' + q(C.sec + ':.wf-cloud-old/' + C.id + '/' + stamp) : '', r = 'done';
if (K && !phlk(K)) return 'busy';
try {
if (C && J) { if (phjmv(C.base, J, bd)) { unlink(JF); J = null; } else r = 'cloud'; }
if (r == 'done' && length(O) && C && rcls(C.base) == null) r = 'cloud';
if (r == 'done' && length(O)) {
let NJ2 = [];
r = phmv1(a.abs, O, lg, NJ2);
if (C && length(NJ2)) {
mkdirp(PHORDD);
wjs(JF, NJ2);
if (phjmv(C.base, NJ2, bd)) unlink(JF); else if (r == 'done') r = 'cloud';
}
}
} catch (e) { r = 'cloud'; }
if (K) phunlk(K);
return r;
}
function phskip(e) { return substr(e, 0, 1) == '.' || match(lc(e), /(\.tmp|\.part|\.partial|\.crdownload|\.download|~)$/) != null; }
function phwalk(abs, rel, F, Dd, sg, lv, mx) {
if (lv > (mx ?? 8)) return;
push(Dd, rel);
sg[rel] = lstat(abs)?.mtime ?? 0;
for (let e in sort(lsdir(abs) ?? [])) {
if (phskip(e)) continue;
let s = lstat(abs + '/' + e);
if (s?.type == 'file') push(F, [ rel + '/' + e, abs + '/' + e ]);
else if (s?.type == 'directory') phwalk(abs + '/' + e, rel + '/' + e, F, Dd, sg, lv + 1, mx);
}
}
function phscan(abs, lg, old, full, mx) {
let sg = { '': lstat(abs)?.mtime ?? 0 }, F = [], Dd = [], K = [ phkind('a.jpg', lg), phkind('a.mp4', lg) ];
let loose = (p, r) => { let s = lstat(p); if (s?.type == 'file') push(F, [ r, p ]); else if (s?.type == 'directory') phwalk(p, r, F, Dd, sg, 1, mx); };
for (let y in sort(lsdir(abs) ?? [])) {
if (phskip(y)) continue;
let yp = abs + '/' + y;
if (!match(y, /^[0-9]{4}$/) || lstat(yp)?.type != 'directory') { loose(yp, y); continue; }
sg[y] = lstat(yp).mtime;
for (let m in sort(lsdir(yp) ?? [])) {
if (phskip(m)) continue;
let mp = yp + '/' + m, mr = y + '/' + m, ms = lstat(mp);
if (ms?.type == 'directory' && phmn(m, lg)) {
sg[mr] = ms.mtime;
for (let k in sort(lsdir(mp) ?? [])) {
if (phskip(k)) continue;
let kp = mp + '/' + k, ks = lstat(kp);
if (ks?.type == 'directory' && index(K, k) >= 0) {
sg[mr + '/' + k] = ks.mtime;
if (full) for (let x in sort(lsdir(kp) ?? [])) if (!phskip(x) && lstat(kp + '/' + x)?.type == 'directory') phwalk(kp + '/' + x, mr + '/' + k + '/' + x, F, Dd, sg, 2, mx);
}
else loose(kp, mr + '/' + k);
}
}
else if (ms?.type == 'directory' && match(m, /^(0[1-9]|1[0-2])$/) && old) continue;
else loose(mp, mr);
}
}
return { sg: sg, F: F, Dd: Dd };
}
function phmvl(abs, go, Dd, Xc, own, lg, stamp, nc) {
let C = phatgt(Xc, own), K = C ? X + '/cloud-' + C.id + '.lock' : null, JF = PHORDD + '/' + own + '.json', now = time(), r = 'moved', J = [];
let bd = C ? ' --backup-dir ' + q(C.sec + ':.wf-cloud-old/' + C.id + '/' + stamp) : '';
if (C?.wait) return 'wait';
if (K && !phlk(K)) return 'busy';
if (C && !nc) {
let J0 = rjs(JF);
if (type(J0) == 'array' && length(J0) && phjmv(C.base, J0, bd)) unlink(JF);
if (rcls(C.base) == null) { phunlk(K); return 'wait'; }
}
for (let f in go) {
let s = lstat(f[1]);
if (s?.type != 'file') continue;
let e = match(f[0], /([^\/]+)$/)[1], sub = phsub(phdate(f[1]) ?? ymof(s.mtime) ?? ymof(now), e, lg), dir = abs + sub;
mkdirp(dir);
let P = phslot(dir, e, f[1], s.size);
if (!P) continue;
if (P.dup) { unlink(f[1]); push(J, [ f[0], substr(sub, 1) + '/' + P.dup, 1 ]); continue; }
let fn = P.name, dst = dir + '/' + fn;
if (lstat(dst) || !rename(f[1], dst)) continue;
push(J, [ f[0], substr(sub, 1) + '/' + fn, 0 ]);
}
for (let d in sort(Dd, (x, y) => length(y) - length(x))) phrmdir(abs + '/' + d);
if (C && !nc && length(J)) {
let J0 = rjs(JF);
J0 = type(J0) == 'array' ? J0 : [];
for (let x in J) push(J0, x);
mkdirp(PHORDD);
wjs(JF, J0);
if (phjmv(C.base, J0, bd)) unlink(JF); else r = 'cloud';
}
if (K) phunlk(K);
return r;
}
function phtop(D, N, own) {
let L = phloc(D, N, { own: own }), t = ud(own, 'media', 'photo', N);
if (!L.d || L.d.ro || !length(L.path) || !length(t ?? '') || !rjs(PHREN)?.[own]?.done) return null;
let a = absp(L.d, t), b = absp(L.d, L.path);
return a && b && stat(a.abs)?.type == 'directory' ? { abs: a.abs, pabs: b.abs } : null;
}
function phmedia(e) { let m = match(lc('' + e), /\.([a-z0-9]+)$/); return m != null && !phskip(e) && (index(TIPI.img ?? [], m[1]) >= 0 || index(TIPI.vid ?? [], m[1]) >= 0); }
function phtopf(abs) { let F = []; for (let e in sort(lsdir(abs) ?? [])) if (phmedia(e) && lstat(abs + '/' + e)?.type == 'file') push(F, [ e, abs + '/' + e ]); return F; }
function phtidy1(D, N, Xc, own, lg, S, stamp) {
let L = phloc(D, N, { own: own });
if (!L.d || L.d.ro || !length(L.path)) return 'disk';
let a = absp(L.d, L.path), TP = phtop(D, N, own);
if (!a) return 'none';
if (stat(a.abs)?.type != 'directory') { if (!TP || !length(phtopf(TP.abs))) return 'none'; mkdirp(a.abs); }
let TF = X + '/phtidy-' + own + '.json', T = rjs(TF), now = time();
if (type(T) != 'object') T = { sg: {}, f: {} };
let old = !S[own]?.done, sc = phscan(a.abs, lg, old, false);
if (TP) sc.sg['/top'] = lstat(TP.abs)?.mtime ?? 0;
if (sprintf('%J', sc.sg) == sprintf('%J', T.sg) && !length(T.f ?? {}) && !length(T.t ?? {})) return 'same';
sc = phscan(a.abs, lg, old, true);
let NF = {}, go = [];
for (let f in sc.F) {
let s = lstat(f[1]), k = s ? s.size + ':' + s.mtime : null;
if (!k) continue;
if (T.f?.[f[0]] == k && now - s.mtime >= 120) push(go, f); else NF[f[0]] = k;
}
let r = length(go) ? 'moved' : (length(NF) ? 'wait' : 'same');
if (length(go)) {
let x = phbusy(a.abs) ? 'busy' : phmvl(a.abs, go, sc.Dd, Xc, own, lg, stamp);
if (x == 'busy' || x == 'wait') { for (let f in go) NF[f[0]] = T.f[f[0]]; r = x == 'busy' ? 'busy' : 'cloud'; }
else r = x;
}
let TN = {}, tg = [];
if (TP) for (let f in phtopf(TP.abs)) {
let s = lstat(f[1]), k = s ? s.size + ':' + s.mtime : null;
if (!k) continue;
if (T.t?.[f[0]] == k && now - s.mtime >= 120) push(tg, f); else TN[f[0]] = k;
}
if (length(tg)) {
let x = phbusy(a.abs) ? 'busy' : phmvl(a.abs, tg, [], Xc, own, lg, stamp, true);
if (x == 'busy' || x == 'wait') { for (let f in tg) TN[f[0]] = T.t[f[0]]; if (r != 'busy') r = x == 'busy' ? 'busy' : 'cloud'; }
else if (r == 'same' || r == 'wait') r = 'moved';
}
else if (length(TN) && r == 'same') r = 'wait';
let sg = phscan(a.abs, lg, old, false).sg;
if (TP) sg['/top'] = lstat(TP.abs)?.mtime ?? 0;
for (let k, v in sg) if (v >= time() - 1) { sg = {}; break; }
wjs(TF, { sg: sg, f: NF, t: TN });
return r;
}
const PHCATLV = 64;
function phcatd(D, N, own) {
let T = phtop(D, N, own), t = ud(own, 'tocat', null, N), L = phloc(D, N, { own: own });
if (!T || !length(t ?? '')) return null;
let a = absp(L.d, t);
if (!a) return null;
if (!lstat(a.abs)) mkdirp(a.abs);
return lstat(a.abs)?.type == 'directory' ? a.abs : null;
}
function phcatl(C) { let r = []; for (let e in sort(lsdir(C) ?? [])) if (!phskip(e) && lstat(C + '/' + e)?.type == 'directory') push(r, e); return r; }
function phcat1(D, N, Xc, own, lg, stamp) {
let C = phcatd(D, N, own);
if (!C) return 'none';
let TF = X + '/phcat-' + own + '.json', T = rjs(TF), now = time();
if (type(T) != 'object') T = { sg: {}, f: {} };
let sig = () => {
let g = { '': lstat(C)?.mtime ?? 0 };
for (let e in phcatl(C)) for (let k, v in phscan(C + '/' + e, lg, false, false, PHCATLV).sg) g[e + '/' + k] = v;
return g;
};
if (sprintf('%J', sig()) == sprintf('%J', T.sg) && !length(T.f ?? {})) return 'same';
let NF = {}, r = 'same';
for (let e in phcatl(C)) {
let A = C + '/' + e, sc = phscan(A, lg, false, true, PHCATLV), go = [];
for (let f in sc.F) {
if (!phmedia(match(f[0], /([^\/]+)$/)[1])) continue;
let s = lstat(f[1]), k = s ? s.size + ':' + s.mtime : null, id = e + '/' + f[0];
if (!k) continue;
if (T.f?.[id] == k && now - s.mtime >= 120) push(go, f); else NF[id] = k;
}
if (!length(go)) continue;
let x = phmvl(A, go, sc.Dd, Xc, own, lg, stamp, true);
if (x == 'busy' || x == 'wait') { for (let f in go) NF[e + '/' + f[0]] = T.f[e + '/' + f[0]]; if (r != 'busy') r = x; }
else if (r == 'same') r = 'moved';
}
if (r == 'wait') r = 'cloud';
if (r == 'same' && length(NF)) r = 'wait';
let sg = sig();
for (let k, v in sg) if (v >= time() - 1) { sg = {}; break; }
wjs(TF, { sg: sg, f: NF });
return r;
}
function phwdirs() {
begin();
let N = nget();
if (N.on !== true) return '';
let D = disks(), r = [];
for (let own in [ 'admin', ...people(N) ]) {
let L = phloc(D, N, { own: own }), a = L.d && !L.d.ro && length(L.path) ? absp(L.d, L.path) : null;
if (a) { mkdirp(a.abs); if (stat(a.abs)?.type == 'directory') push(r, a.abs); }
let C = phcatd(D, N, own);
if (C) push(r, C);
}
return join('\n', r);
}
function phwtops() {
begin();
let N = nget();
if (N.on !== true) return '';
let D = disks(), r = [];
for (let own in [ 'admin', ...people(N) ]) { let T = phtop(D, N, own); if (T) push(r, T.abs); }
return join('\n', r);
}
function phisloose(rel, lg, old) {
let s = split(rel, '/'), K = [ phkind('a.jpg', lg), phkind('a.mp4', lg) ];
for (let x in s) if (!length(x) || phskip(x)) return null;
if (length(s) == 4 && match(s[0], /^[0-9]{4}$/) && phmn(s[1], lg) && index(K, s[2]) >= 0) return null;
if (old && length(s) == 3 && match(s[0], /^[0-9]{4}$/) && match(s[1], /^(0[1-9]|1[0-2])$/)) return null;
let Dd = [];
for (let i = 1; i < length(s); i++) {
let p = join('/', slice(s, 0, i)), ok = (i == 1 && match(s[0], /^[0-9]{4}$/)) || (i == 2 && match(s[0], /^[0-9]{4}$/) && phmn(s[1], lg)) ||
(i == 3 && match(s[0], /^[0-9]{4}$/) && phmn(s[1], lg) && index(K, s[2]) >= 0);
if (!ok) push(Dd, p);
}
return Dd;
}
function phfileq(f) {
begin();
let N = nget(), r = { moved: 0, wait: 0 };
if (N.on !== true) return r;
let D = disks(), Xc = xget(), S = rjs(PHORD), t = localtime(), B = [], PK = X + '/phord.lock', G = {};
let stamp = sprintf('%04d%02d%02d-%02d%02d', t.year, t.mon, t.mday, t.hour, t.min);
if (type(S) != 'object') S = {};
let TB = [], CB = [], WQ = [], now = time();
for (let own in [ 'admin', ...people(N) ]) {
let L = phloc(D, N, { own: own }), a = L.d && !L.d.ro && length(L.path) ? absp(L.d, L.path) : null, T = phtop(D, N, own);
if (a) push(B, [ own, a.abs ]);
if (T) push(TB, [ own, T.abs, T.pabs ]);
let C = T ? phcatd(D, N, own) : null;
if (C) push(CB, [ own, C ]);
}
for (let p in uniq(split(readfile(f) ?? '', '\n'))) {
let hit = false;
for (let b in CB) {
if (index(p, b[1] + '/') != 0) continue;
hit = true;
let e = substr(p, length(b[1]) + 1), i = index(e, '/');
if (i <= 0) break;
let top = substr(e, 0, i), rel = substr(e, i + 1), lg = phlang(Xc, b[0]) ?? LG, Dd = phskip(top) || !phmedia(match(rel, /([^\/]+)$/)?.[1] ?? '') ? null : phisloose(rel, lg, false);
let s = lstat(p);
if (Dd == null || s?.type != 'file') break;
let busy = now - s.mtime < 120;
for (let d in Dd) if (now - (lstat(b[1] + '/' + top + '/' + d)?.mtime ?? 0) < 120) busy = true;
if (busy) { push(WQ, p); break; }
let k = b[0] + '#' + top;
G[k] = G[k] ?? { own: b[0], abs: b[1] + '/' + top, lg: lg, go: [], Dd: [], nc: true };
push(G[k].go, [ rel, p ]);
for (let d in Dd) push(G[k].Dd, d);
break;
}
if (hit) continue;
for (let b in B) {
if (index(p, b[1] + '/') != 0) continue;
hit = true;
let lg = phlang(Xc, b[0]) ?? LG, rel = substr(p, length(b[1]) + 1), Dd = phisloose(rel, lg, !S[b[0]]?.done), s = lstat(p);
if (Dd == null || s?.type != 'file') break;
let busy = now - s.mtime < 120;
for (let d in Dd) if (now - (lstat(b[1] + '/' + d)?.mtime ?? 0) < 120) busy = true;
if (busy) { push(WQ, p); break; }
G[b[0]] = G[b[0]] ?? { own: b[0], abs: b[1], lg: lg, go: [], Dd: [] };
push(G[b[0]].go, [ rel, p ]);
for (let d in Dd) push(G[b[0]].Dd, d);
break;
}
if (hit) continue;
for (let b in TB) {
if (index(p, b[1] + '/') != 0) continue;
let e = substr(p, length(b[1]) + 1), k = b[0] + '/';
if (index(e, '/') >= 0 || !phmedia(e) || lstat(p)?.type != 'file') break;
G[k] = G[k] ?? { own: b[0], abs: b[2], lg: phlang(Xc, b[0]) ?? LG, go: [], Dd: [], nc: true };
push(G[k].go, [ e, p ]);
break;
}
}
let back = (g) => { r.wait += length(g.go); if ((stat(X + '/phwatch.q')?.size ?? 0) > 262144) { writefile(X + '/phwatch.full', ''); return; } let o = open(X + '/phwatch.q', 'a'); if (o) { for (let x in g.go) o.write(x[1] + '\n'); o.close(); } };
if (length(WQ)) back({ go: map(WQ, (p) => [ null, p ]) });
if (!length(G)) return r;
if (!phlk(PK)) { for (let own, g in G) back(g); return r; }
try {
for (let k, g in G) {
let own = g.own;
mkdirp(g.abs);
let x = phbusy(g.abs) ? 'busy' : phmvl(g.abs, g.go, uniq(g.Dd), Xc, own, g.lg, stamp, g.nc);
if (x == 'busy' || x == 'wait') { back(g); continue; }
r.moved += length(g.go);
if (!phlang(Xc, own)) { Xc = xget(); if (type(Xc.photo.lang) != 'object') Xc.photo.lang = {}; Xc.photo.lang[own] = g.lg; xput(Xc); }
}
} catch (e) {}
phunlk(PK);
return r;
}
function phdavbase(own) {
let N = nget(), L = phloc(disks(), N, { own: own }), a = L.d && length(L.path) ? absp(L.d, L.path) : null;
return a ? { abs: a.abs, d: L.d, N: N } : null;
}
function phdav(own, tmp, n, mt) {
begin();
let B = phdavbase(own), s = lstat(tmp);
if (!B) { unlink(tmp); return nomain(); }
if (index(tmp, B.abs + '/.') != 0 || !match(tmp, /\.wfpart$/) || s?.type != 'file' || badname(n) || substr(n, 0, 1) == '.') { unlink(tmp); return err('name', 'Nome del file non valido', 'Invalid file name'); }
let ps = pstop(own, B.N);
if (ps) { unlink(tmp); return ps; }
if (B.d.ro) { unlink(tmp); return err('ro', 'Disco in sola lettura', 'Drive is read-only', { ro: true }); }
let Xc = xget(), lg = phlang(Xc, own);
if (!lg) { lg = LG; if (type(Xc.photo.lang) != 'object') Xc.photo.lang = {}; Xc.photo.lang[own] = lg; xput(Xc); }
let sub = phsub(phdate(tmp, n) ?? ymof(mt) ?? ymof(time()), n, lg), dir = B.abs + sub, dst = dir + '/' + n;
mkdirp(dir);
let ds = lstat(dst);
if (ds?.type == 'file' && ds.size == s.size && samef(tmp, dst)) { unlink(tmp); return { ok: true, dup: true, name: n, path: substr(sub, 1) + '/' + n }; }
let fn = freename(dir, n);
if (!fn || !rename(tmp, dir + '/' + fn)) { unlink(tmp); return err('write', 'File non scritto', 'File not written'); }
if (type(mt) == 'int' && mt > 0) { let t = localtime(mt); sh('touch -c -t ' + sprintf('%04d%02d%02d%02d%02d.%02d', t.year, t.mon, t.mday, t.hour, t.min, t.sec) + ' ' + q(dir + '/' + fn) + ' 2>/dev/null'); }
return { ok: true, dup: false, name: fn, path: substr(sub, 1) + '/' + fn };
}
const PHDH = 262144, CLSH = R + '/usr/share/wrtfreedom/cloudline.sh';
function phdavcp(Xc, own) {
let P = [], H = type(Xc?.photo?.phones) == 'object' ? Xc.photo.phones : {};
for (let k in sort(keys(H))) { let p = H[k]; if (p?.dest == 'cloud' && ownof(p) == own && phsec(p.acct)) push(P, [ k, p ]); }
return sort(P, (a, b) => (a[1].t ?? 0) - (b[1].t ?? 0));
}
function phdavline() {
if (!stat(CLSH)) return { ok: true, bw: 'off', max: 0 };
let p = split(trim(sh('. ' + q(CLSH) + ' >/dev/null 2>&1; cl_check phdav 2>/dev/null </dev/null')), ' ');
if (p[0] == 'ok') return { ok: true, bw: match(p[1] ?? '', /^[0-9a-z:]+$/) ? p[1] : 'off', max: num(p[2]) };
return { ok: false, why: p[1] ?? 'net' };
}
function phdavwait(w) {
if (w == 'pause') return err('wait', 'Pausa Cloud: riprova più tardi', 'Cloud paused: try again later', { retry: 600, why: w });
if (w == 'net') return err('wait', 'Internet non raggiungibile: riprova più tardi', 'Internet unreachable: try again later', { retry: 60, why: w });
return err('wait', 'Il cloud aspetta la linea fissa: riprova più tardi', 'The cloud waits for the fixed line: try again later', { retry: 600, why: w });
}
function phdavconf(f, sec) {
let S = {}, cur = null, o = '';
for (let l in split(readfile(rcf()) ?? '', '\n')) {
let m = match(l, /^\[(.+)\][ \t]*$/);
if (m) { cur = m[1]; S[cur] = S[cur] ?? []; continue; }
if (cur != null && length(trim(l))) push(S[cur], l);
}
if (!S[sec]) return false;
let add = (s) => {
o += '[' + s + ']\n';
for (let l in S[s]) {
if (match(l, /^token[ \t]*=/)) l = replace(replace(l, /"refresh_token"[ \t]*:[ \t]*"[^"]*"[ \t]*,?[ \t]*/g, ''), /,[ \t]*}/g, '}');
o += l + '\n';
}
};
add(sec);
for (let l in S[sec]) { let m = match(l, /^remote[ \t]*=[ \t]*([^:]+):/); if (m && m[1] != sec && S[m[1]]) add(m[1]); }
return put600(f, o);
}
function phdavcl(own, n, sz, mt, rd) {
begin();
let N = nget(), B = phdavbase(own);
if (B) return B.d.ro ? err('ro', 'Disco in sola lettura', 'Drive is read-only', { ro: true }) : nomain();
if (badname(n) || substr(n, 0, 1) == '.') return err('name', 'Nome del file non valido', 'Invalid file name');
let Xc = xget(), P = phdavcp(Xc, own);
if (!length(P)) return nomain();
if (Xc.photo.on === false) return err('off', 'Backup Del Telefono spento', 'Phone Backup is off');
let ps = pstop(own, N);
if (ps) return ps;
let id = P[0][0], ph = P[0][1], cm = cmapx(ph.acct, ph.remote);
if (cm?.wait) return err('wait', 'Cartella del cloud in migrazione: riprova più tardi', 'Cloud folder being migrated: try again later', { retry: 600, why: 'mig' });
let base = cm ? cm.sec + ':' + cm.path : phsec(ph.acct) + ':' + replace('' + (ph.remote ?? ''), /^\/+/, '');
let li = phdavline();
if (!li.ok) return phdavwait(li.why);
if (li.max > 0 && sz > li.max) return phdavwait('cap');
let K = X + '/phdav-' + own + '.lock';
if (!phlk(K)) return err('busy', 'Un altro file in arrivo: riprova fra poco', 'Another file is arriving: try again shortly', { retry: 30 });
let cf = X + '/.phdav-' + own + '.conf', hf = X + '/.phdav-' + own + '.head', rf = X + '/.phdav-' + own + '.rc', r = null;
try {
let hl = sz >= 0 && sz < PHDH ? sz : PHDH, h = '';
while (length(h) < hl) { let c = rd(hl - length(h)); if (c == null || !length(c)) break; h += c; }
if (sz >= 0 && length(h) < hl) r = err('size', 'File incompleto', 'Incomplete file');
else {
let lg = phlang(Xc, own);
if (!lg) { lg = LG; if (type(Xc.photo.lang) != 'object') Xc.photo.lang = {}; Xc.photo.lang[own] = lg; xput(Xc); }
put600(hf, h);
let ry = phdate(hf, n) ?? ymof(mt) ?? ymof(time()), ym = phymk(ry), yo = mt > 0 ? phym(mt) : null, df = null, used = {};
unlink(hf);
for (let e in P) {
phmerge(e[0]);
let I = phidx(e[0]);
if (sz >= 0 && df == null) df = I.k[phkey(ym, n, sz)] ?? (yo ? I.k[phkey(yo, n, sz)] : null);
for (let k, v in I.f) used[k] = 1;
for (let j, q in phq(e[0])) { if (sz >= 0 && q.ym == ym && q.n == n && q.s == sz) df = df ?? q.f; if (q.nl) used[q.ym + '/' + q.f] = 1; }
}
if (df != null) r = { ok: true, dup: true, name: df };
else {
let m = match(n, /^(.+)(\.[^.]+)$/), b = m ? m[1] : n, x = m ? m[2] : '', fn = n, sub = phsub(ry, n, lg);
for (let i = 2; i < 10000 && used[ym + '/' + fn]; i++) fn = b + ' (' + i + ')' + x;
if (!phdavconf(cf, split(base, ':')[0])) r = err('cloud', 'Cloud non pronto: riprova più tardi', 'Cloud not ready: try again later', { retry: 60 });
else {
let ra = rcx(), sv = type(ra?.acct) == 'function' ? '' + (ra.acct(ph.acct)?.svc ?? '') : '';
if (!match(sv, /^[a-z0-9]{1,20}$/)) sv = '';
unlink(rf);
let cmd = '{ [ -f ' + q(CLSH) + ' ] && . ' + q(CLSH) + '; command -v cl_env >/dev/null && cl_env ' + q(sv) + '; ' +
'( command -v cl_in >/dev/null && cl_in; RCLONE_CONFIG=' + q(cf) + ' RCLONE_CACHE_DIR=' + q(X + '/rclone-cache') + ' exec rclone rcat' +
(sz >= 0 ? ' --size ' + sz : '') + (li.bw != 'off' ? ' --bwlimit ' + q(li.bw) : '') + ' $CL_RMEM ' + q(base + sub + '/' + fn) + ' ); r=$?; ' +
'[ $r = 0 ] && [ ' + sz + ' -gt 0 ] && command -v cl_add >/dev/null && cl_add ' + sz + '; cat >/dev/null; echo $r > ' + q(rf) + '; } >/dev/null 2>&1';
let p = popen(cmd, 'w'), got = 0, wok = p != null;
if (wok && length(h)) { wok = p.write(h) == length(h); got = length(h); }
while (wok && (sz < 0 || got < sz)) {
let c = rd(sz < 0 || sz - got > 65536 ? 65536 : sz - got);
if (c == null || !length(c)) break;
if (p.write(c) != length(c)) { wok = false; break; }
got += length(c);
}
if (p) p.close();
let rc = trim(readfile(rf) ?? '');
unlink(rf);
if (sz >= 0 && got != sz) r = err('size', 'File incompleto', 'Incomplete file');
else if (rc != '0' || !wok) r = err('cloud', 'Cloud non raggiungibile: riprova più tardi', 'Cloud unreachable: try again later', { retry: 60 });
else {
let KI = X + '/phq-' + id + '.lock';
for (let i = 0; i < 20 && !lkget(KI); i++) sleep(100);
if (trim(readfile(KI + '/pid') ?? '') == PID && phdirs()) {
let f = PHIDX + '/' + id + '.idx', s = replace(phidxraw(id), /^#[^\n]*\n/, ''), now = time();
wif(f, '#' + now + '\n' + s + sprintf('%d\t%s\t%s\t%s\tn\n', got, ym, n, fn));
let S = rjs(X + '/photo-' + id + '.json');
if (type(S) == 'object') { S.last = now; S.files = (S.files ?? 0) + 1; S.bytes = (S.bytes ?? 0) + got; wjs(X + '/photo-' + id + '.json', S); }
}
lkput(KI);
phsync(id);
r = { ok: true, dup: false, name: fn, path: substr(sub, 1) + '/' + fn };
}
}
}
}
} catch (e) { r = err('cloud', 'Cloud non raggiungibile: riprova più tardi', 'Cloud unreachable: try again later', { retry: 60 }); }
unlink(cf); unlink(hf); unlink(rf); phunlk(K);
return r;
}
function phdavls(own) {
begin();
let B = phdavbase(own), F = {}, S = [];
if (!B) {
for (let e in phdavcp(xget(), own)) {
phmerge(e[0]);
let t = 0;
for (let l in split(phidxraw(e[0]), '\n')) {
if (substr(l, 0, 1) == '#') { t = num(substr(l, 1)); continue; }
let p = split(l, '\t');
if ((length(p) == 4 || length(p) == 5) && match(p[0], /^[0-9]+$/) && !exists(F, p[3])) F[p[3]] = [ null, +p[0], t ];
}
for (let j, q in phq(e[0])) if (type(q?.f) == 'string' && !exists(F, q.f)) F[q.f] = [ null, q.s, q.t ?? 0 ];
}
return { base: null, files: F, cloud: true };
}
push(S, [ B.abs, 0 ]);
while (length(S)) {
let x = pop(S);
for (let e in lsdir(x[0]) ?? []) {
if (substr(e, 0, 1) == '.') continue;
let p = x[0] + '/' + e, s = lstat(p);
if (s?.type == 'directory' && x[1] < 6) push(S, [ p, x[1] + 1 ]);
else if (s?.type == 'file' && !exists(F, e)) F[e] = [ p, s.size, s.mtime ];
}
}
return { base: B.abs, files: F };
}
function phtidy() {
begin();
let N = nget();
if (N.on !== true) return { off: true };
let K = X + '/phord.lock';
if (!phlk(K)) return { busy: true };
let D = disks(), Xc = xget(), S = rjs(PHORD), r = {}, t = localtime();
let stamp = sprintf('%04d%02d%02d-%02d%02d', t.year, t.mon, t.mday, t.hour, t.min);
if (type(S) != 'object') S = {};
try {
for (let own in [ 'admin', ...people(N) ]) {
let lg = phlang(Xc, own);
let x = phtidy1(D, N, Xc, own, lg ?? LG, S, stamp);
let c = phcat1(D, N, Xc, own, lg ?? LG, stamp);
if (c == 'moved' && index([ 'same', 'wait', 'none', 'disk' ], x) >= 0) x = 'moved';
else if ((c == 'busy' || c == 'cloud') && x != 'busy') x = c;
else if (c == 'wait' && (x == 'same' || x == 'none')) x = 'wait';
if (x == 'moved' && !lg) { Xc = xget(); if (type(Xc.photo.lang) != 'object') Xc.photo.lang = {}; Xc.photo.lang[own] = LG; xput(Xc); }
r[own] = x;
}
} catch (e) { r.error = '' + e; }
phunlk(K);
return r;
}
function phmove() {
begin();
let N = nget(), D = disks(), Xc = xget(), S = rjs(PHORD), now = time(), ch = false, r = {}, t = localtime();
let stamp = sprintf('%04d%02d%02d-%02d%02d', t.year, t.mon, t.mday, t.hour, t.min);
if (type(S) != 'object') S = {};
let PK = X + '/phord.lock';
if (!phlk(PK)) return { busy: true };
for (let own in [ 'admin', ...people(N) ]) {
if (S[own]?.done) continue;
let lg = phlang(Xc, own);
if (!lg && type(S[own]?.wait) == 'int' && now - S[own].wait >= 7 * DAY) {
Xc = xget();
if (type(Xc.photo.lang) != 'object') Xc.photo.lang = {};
Xc.photo.lang[own] = lg = LG;
if (!xput(Xc)) lg = null;
}
let x = phmvp(D, N, Xc, own, lg, stamp);
r[own] = x;
if (x == 'done') { S[own] = { done: now }; ch = true; }
else if (x == 'lang' && type(S[own]?.wait) != 'int') { S[own] = { wait: now }; ch = true; }
}
if (ch) { mkdirp(ETC); wjs(PHORD, S); }
phunlk(PK);
return r;
}
function dname(p) { return replace(p, /\/[^\/]*$/, ''); }
function phrdisk(a, b, lv) {
let sa = lstat(a);
if (!sa) return true;
if (sa.type != 'directory') return false;
let sb = lstat(b);
if (!sb) { mkdirp(dname(b)); return rename(a, b); }
if (sb.type != 'directory') { let fn = freename(dname(b), replace(b, /^.*\//, '')); return fn != null && rename(a, dname(b) + '/' + fn); }
if (lv > 32) return false;
let ok = true;
for (let e in lsdir(a) ?? []) {
let pa = a + '/' + e, pb = b + '/' + e, s = lstat(pa), t = lstat(pb);
if (!t) { if (!rename(pa, pb)) ok = false; continue; }
if (s?.type == 'directory' && t.type == 'directory') { if (!phrdisk(pa, pb, lv + 1)) ok = false; continue; }
let fn = freename(b, e);
if (fn == null || !rename(pa, b + '/' + fn)) ok = false;
}
if (ok) rmdir(a);
return ok && !lstat(a);
}
function rclsr(p) {
let o = sh(rcenv() + 'lsf -R --files-only ' + q(p) + ' </dev/null 2>/dev/null; echo "#$?"'), m = match(o, /#([0-9]+)[ \t\n]*$/), rc = m ? +m[1] : 1;
if (rc == 3) return null;
if (rc != 0) return false;
return filter(split(replace(o, /#[0-9]+[ \t\n]*$/, ''), '\n'), (x) => length(x) && substr(x, -1) != '/');
}
function phrcloud(s, d, ex) {
let A = rclsr(s), out = (f) => length(filter(ex ?? [], (x) => f == x || substr(f, 0, length(x) + 1) == x + '/')) > 0;
if (A === false) return false;
if (A != null) A = filter(A, (f) => !out(f));
if (A == null || !length(A)) { if (A != null) rcrun('rmdirs ' + q(s)); return true; }
let B = rclsr(d);
if (B === false) return false;
if (B == null && !length(ex ?? [])) return rcrun('moveto ' + q(s) + ' ' + q(d)) == 0;
let H = {}, go = [], cf = [];
B = B ?? [];
for (let x in B) H[x] = 1;
for (let f in A) {
if (!H[f]) { push(go, f); H[f] = 1; continue; }
let m = match(f, /^(.*\/)?([^\/]*)$/), pre = m[1] ?? '', e = match(m[2], /^(.+)(\.[^.]+)$/), b = e ? e[1] : m[2], x = e ? e[2] : '', fn = null;
for (let i = 2; i < 10000; i++) if (!H[pre + b + ' (' + i + ')' + x]) { fn = pre + b + ' (' + i + ')' + x; break; }
if (fn == null) return false;
H[fn] = 1; push(cf, [ f, fn ]);
}
if (length(go)) {
let lf = X + '/phren.list';
writefile(lf, join('\n', go) + '\n');
let rc = rcrun('move ' + q(s) + ' ' + q(d) + ' --files-from-raw ' + q(lf));
unlink(lf);
if (rc != 0) return false;
}
for (let e in cf) if (rcrun('moveto ' + q(s + '/' + e[0]) + ' ' + q(d + '/' + e[1])) != 0) return false;
rcrun('rmdirs ' + q(s));
return true;
}
function phrspec(acct, p) {
let s = phsec(acct), m = s ? cmapx(acct, p) : null;
if (!s || m?.wait) return null;
return m ? m.sec + ':' + m.path : s + ':' + p;
}
function phrnew(x, P) {
if (type(x) != 'string') return x;
let sl = match(x, /^\/+/) ? '/' : '', r = replace(x, /^\/+/, '');
for (let p in P) if (r == p[0] || substr(r, 0, length(p[0]) + 1) == p[0] + '/') r = p[1] + substr(r, length(p[0]));
return sl + r;
}
function phrex(Xc, acct, p) {
let ex = [];
for (let c in Xc.cloud ?? []) if (c.kind == 'backup' && c.acct == acct) {
let rr = replace('' + (c.remote ?? ''), /^\/+/, '');
if (substr(rr, 0, length(p) + 1) == p + '/') push(ex, substr(rr, length(p) + 1));
else if (rr == p || substr(p, 0, length(rr) + 1) == rr + '/') return null;
}
return ex;
}
function phrsave(own, P, mn, AC) {
if (!length(P)) return 'done';
let X2 = xget(), ch = [], r = 'done';
for (let c in X2.cloud ?? []) if (ownof(c) == own) {
let o = sprintf('%J', [ c.path, c.remote ]);
if (mn && c.disk == mn.id) c.path = phrnew(c.path, P);
if (AC[c.acct] && c.kind != 'backup') c.remote = phrnew(c.remote, P);
if (sprintf('%J', [ c.path, c.remote ]) != o) push(ch, c);
}
let pc = false;
for (let id, p in X2.photo?.phones ?? {}) if (ownof(p) == own && p.dest == 'cloud' && AC[p.acct]) { let n = phrnew(p.remote, P); if (n != p.remote) { p.remote = n; pc = true; } }
if (length(ch) || pc) { if (xput(X2)) { for (let c in ch) cwrite(c); } else r = 'busy'; }
if (r == 'done' && mn) {
let BC = [], nm = (x) => replace(x, /^.*\//, '');
let N2 = nsave((F) => {
for (let b in (type(F.backups) == 'array' ? F.backups : [])) {
if (type(b) != 'object' || ownof(b) != own) continue;
let o = sprintf('%J', [ b.what, b.dest ]);
if (type(b.what) == 'object' && b.what.disk == mn.id && type(b.what.dirs) == 'array') b.what.dirs = map(b.what.dirs, (x) => phrnew(x, P));
if (type(b.dest) == 'object' && b.dest.kind == 'disk' && b.dest.disk == mn.id) b.dest.path = phrnew(b.dest.path, P);
if (sprintf('%J', [ b.what, b.dest ]) != o) push(BC, b.id);
}
for (let f in (type(F.fav) == 'array' ? F.fav : [])) {
if (type(f) != 'object' || f.disk != mn.id || type(f.path) != 'string') continue;
let n = phrnew(f.path, P);
if (n != f.path) { if (f.name == nm(f.path)) f.name = nm(n); f.path = n; }
}
});
if (!N2) r = 'busy';
else for (let b in N2.backups ?? []) if (index(BC, b.id) >= 0) bakwrite(b, N2);
}
return r;
}
function phrctx(D, N, own, B) {
let Xc = xget(), mn = mainof(D, N), aid = type(Xc.photo.also) == 'object' ? Xc.photo.also[own] : null, C = null;
for (let c in Xc.cloud ?? []) if (aid != null && c.id == aid && ownof(c) == own) C = c;
let K = C ? X + '/cloud-' + C.id + '.lock' : null, AC = {};
if (type(N.main) == 'object' && !mn) return 'disk';
if (mn) for (let p in B) { let a = absp(mn, '/' + p); if (a && stat(a.abs)?.type == 'directory' && phbusy(a.abs)) return 'busy'; }
for (let id, p in Xc.photo.phones) if (ownof(p) == own && p.dest == 'cloud') { if (length(phq(id))) return 'busy'; AC[p.acct] = 1; }
if (C) AC[C.acct] = 1;
if (K && !phlk(K)) return 'busy';
return { Xc: Xc, mn: mn, AC: AC, K: K };
}
function phren1(D, N, own) {
let P = [ [ UCFG.udir(own, 'pold', null, N), UCFG.udir(own, 'media', 'photo', N) ], [ UCFG.udir(own, 'phold', null, N), UCFG.udir(own, 'phones', null, N) ] ];
for (let p in P) if (p[0] == null || p[1] == null) return 'done';
let G = phrctx(D, N, own, [ P[1][0], P[1][1], P[0][0] + '/' + replace(P[1][0], /^.*\//, '') ]);
if (type(G) != 'object') return G;
let Xc = G.Xc, mn = G.mn, AC = G.AC, K = G.K, r = 'done';
try {
for (let acct in keys(AC)) {
for (let p in P) {
let s = phrspec(acct, p[0]), d = phrspec(acct, p[1]), ex = phrex(Xc, acct, p[0]);
if (ex == null) continue;
if (!s || !d || !phrcloud(s, d, ex)) { r = 'cloud'; break; }
}
if (r != 'done') break;
}
if (r == 'done' && mn) {
if (mn.ro) r = 'disk';
else for (let p in P) {
let a = absp(mn, '/' + p[0]), b = absp(mn, '/' + p[1]);
if (!a || !b) { r = 'path'; break; }
if (!phrdisk(a.abs, b.abs, 0)) { r = 'disk'; break; }
}
}
if (r == 'done') r = phrsave(own, P, mn, AC);
} catch (e) { r = 'cloud'; }
if (K) phunlk(K);
return r;
}
function rclsm(p) {
let o = sh(rcenv() + 'lsf -R --dirs-only --max-depth 2 ' + q(p) + ' </dev/null 2>/dev/null; echo "#$?"'), m = match(o, /#([0-9]+)[ \t\n]*$/), rc = m ? +m[1] : 1, r = [];
if (rc == 3) return null;
if (rc != 0) return false;
for (let l in split(replace(o, /#[0-9]+[ \t\n]*$/, ''), '\n')) { let x = match(l, /^([0-9]{4})\/([^\/]+)\/$/); if (x && phmnew(x[2])) push(r, [ x[1], x[2] ]); }
return r;
}
function phmes1(D, N, own) {
let ph = UCFG.udir(own, 'phones', null, N);
if (ph == null) return 'done';
let G = phrctx(D, N, own, [ ph ]);
if (type(G) != 'object') return G;
let Xc = G.Xc, mn = G.mn, AC = G.AC, K = G.K, r = 'done', P = [];
try {
for (let acct in keys(AC)) {
let b = phrspec(acct, ph), L = b ? rclsm(b) : false;
if (L === false) { r = 'cloud'; break; }
for (let m in L ?? []) {
let p = ph + '/' + m[0] + '/' + m[1], ex = phrex(Xc, acct, p);
if (ex == null) continue;
if (!phrcloud(b + '/' + m[0] + '/' + m[1], b + '/' + m[0] + '/' + phmnew(m[1]), ex)) { r = 'cloud'; break; }
push(P, [ p, ph + '/' + m[0] + '/' + phmnew(m[1]) ]);
}
if (r != 'done') break;
}
if (r == 'done' && mn) {
let a = absp(mn, '/' + ph);
if (mn.ro) r = 'disk';
else if (!a) r = 'path';
else for (let y in sort(lsdir(a.abs) ?? [])) {
if (!match(y, /^[0-9]{4}$/) || lstat(a.abs + '/' + y)?.type != 'directory') continue;
for (let m in sort(lsdir(a.abs + '/' + y) ?? [])) {
let n = phmnew(m), yp = a.abs + '/' + y;
if (!n || lstat(yp + '/' + m)?.type != 'directory') continue;
if (!phrdisk(yp + '/' + m, yp + '/' + n, 0)) { r = 'disk'; break; }
push(P, [ ph + '/' + y + '/' + m, ph + '/' + y + '/' + n ]);
}
if (r != 'done') break;
}
}
if (r == 'done') r = phrsave(own, P, mn, AC);
} catch (e) { r = 'cloud'; }
if (K) phunlk(K);
return r;
}
function phren() {
begin();
let N = nget();
if (N.on !== true) return { off: true };
let PK = X + '/phord.lock';
if (!phlk(PK)) return { busy: true };
let D = disks(), S = rjs(PHREN), r = {}, ch = false, all = true;
if (type(S) != 'object') S = {};
try {
for (let own in [ 'admin', ...people(N) ]) {
if (!S[own]?.done) {
let x = phren1(D, N, own);
r[own] = x;
if (x == 'done') { S[own] = { done: time() }; ch = true; } else { all = false; continue; }
}
if (S[own].mesi) continue;
let x = phmes1(D, N, own);
r.mesi = r.mesi ?? {};
r.mesi[own] = x;
if (x == 'done') { S[own].mesi = time(); ch = true; } else all = false;
}
} catch (e) { r.error = '' + e; all = false; }
if (ch) { mkdirp(ETC); wjs(PHREN, S); }
if (all) writefile(X + '/phren2.ok', '');
phunlk(PK);
r.all = all;
return r;
}
function pcakid(Xc, own, k) {
for (let c in Xc.cloud) if (type(c) == 'object' && c.pc == k && ownof(c) == own) return c;
return null;
}
function pcqf(own, acct) {
if (own == 'admin' || !length(own ?? '')) return false;
let A = amap()['' + (acct ?? '')];
if (A && auser(A) != 'admin') return false;
let q = +(nget().users?.[own]?.quota?.cloud ?? 0), u = rjs(CTMP + '/home.json')?.users?.[own]?.used;
return q > 0 && type(u) == 'int' && u >= q * 1073741824;
}
function pcatick(Xc, N, PC, now) {
let r = [];
for (let c in Xc.cloud) {
if (type(c) != 'object' || (c.pc != 'tm' && c.pc != 'fh') || c.on !== true || N[c.pc]?.on !== true) continue;
let own = ownof(c);
if (pstop(own, N) || cprog(c.id, c.disk) || pcqf(own, c.acct)) continue;
let L = filter(PC, (x) => x.kind == c.pc && ownof(x) == own && x.last > 0), t = 0, busy = false;
for (let x in L) { if (now - x.last < 900) busy = true; if (x.last > t) t = x.last; }
if (busy || !t) continue;
let s = clast(c.id);
if (s.ok === false ? now - s.last >= 1800 : t > s.last) push(r, c.id);
}
return r;
}
function pcaout(Xc, own, k) {
let c = pcakid(Xc, own, k);
if (!c) return null;
let AM = amap(), A = AM[c.acct], s = clast(c.id), pr = cprog(c.id, c.disk), e = rjs(X + '/cloud-' + c.id + '.json'), m = cmapx(c.acct, c.remote);
return { id: c.id, acct: c.acct ?? '', acct_name: A?.name ?? '', crypt: m != null && m.sec != asec(c), last: s.last, last_ok: s.ok,
cquota: pcqf(own, c.acct), ...cst(c, diskof(disks(), c.disk), AM, s, pr, e, cfacts(c.id), rcq('paused') === true) };
}
function bktick() {
begin();
let N = nget();
if (N.on !== true) return { ok: true, off: true };
let D = disks(), A = advof(N), now = time(), t = localtime(), run = [];
let PF = BKD + '/present.json', was = rjs(PF) ?? rjs(TMP + '/bk-present.json'), cur = sort(map(D, (d) => d.id)), fresh = [];
if (type(was) == 'array') for (let id in cur) if (index(was, id) < 0) push(fresh, id);
if (type(was) != 'array' || length(fresh) || length(was) != length(cur)) { mkdirp(BKD); wjs(PF, cur); unlink(TMP + '/bk-present.json'); }
for (let b in N.backups) if (type(b) == 'object' && match('' + b.id, /^b[0-9a-z]{1,16}$/)) bakwrite(b, N);
if (N.bk.on !== false) for (let b in N.backups) {
if (b.on === false || bakrun(b) || pstop(ownof(b), N)) continue;
let s = bakstate(b.id), m = modeof(b), tf = TMP + '/bk-' + b.id + '.try', tr = num(trim(readfile(tf) ?? ''));
let here = diskof(D, b.what?.disk) != null || b.what?.router === true, there = b.dest?.kind == 'nas' || diskof(D, b.dest?.disk) != null;
if (m == 'night' && length(b.when?.at ?? '')) {
let T = lastocc(b.when.at, b.when.days);
if (s.okt >= T || (b.t ?? 0) > T) continue;
if (tr < T || (here && there && now - tr >= 1800)) { push(run, b.id); writefile(tf, '' + now); }
}
else if (m == 'plug' && length(fresh) && (index(fresh, b.dest?.disk) >= 0 || index(fresh, b.what?.disk) >= 0) && here && there && now - tr >= 3600) {
push(run, b.id); writefile(tf, '' + now);
}
}
if (length(run)) detach('for i in ' + join(' ', map(run, q)) + '; do sh ' + q(SH) + ' run "$i"; done');
let Xc = xget(), cr = [];
Xc = cmig(Xc) ?? Xc; Xc = adoptfin(Xc) ?? Xc; Xc = acctfix(Xc) ?? Xc;
for (let c in Xc.cloud) {
if (ownof(c) != 'admin') { cwrite(c); if (pstop(ownof(c), N)) continue; }
else if (c.kind != 'backup' && cmapx(c.acct, c.remote)) cwrite(c);
if (c.kind != 'backup' || !c.on || length(c.of ?? '') || cprog(c.id, c.disk)) continue;
if (length(c.at ?? '')) {
let T = lastocc(c.at, c.days), df = X + '/cloud-' + c.id + '.day';
if (clast(c.id).last < T && (c.t ?? 0) <= T && trim(readfile(df) ?? '') != '' + T) { writefile(df, '' + T); push(cr, c.id); }
}
else if (c.every > 0 && now - clast(c.id).last + 60 >= c.every * 60) push(cr, c.id);
}
if (length(cr)) detach('for i in ' + join(' ', map(cr, q)) + '; do sh ' + q(SH) + ' cloud "$i"; done');
let pr = [];
for (let c in plist(Xc)) {
pwrite(c, N);
if (c.on === false || pstop(ownof(c), N) || cprog(c.id, c.disk)) continue;
if (length(c.at ?? '')) {
let T = lastocc(c.at, c.days), df = X + '/cloud-' + c.id + '.day';
if (clast(c.id).last < T && (c.t ?? 0) <= T && trim(readfile(df) ?? '') != '' + T) { writefile(df, '' + T); push(pr, c.id); }
}
else if (c.every > 0 && now - clast(c.id).last + 60 >= c.every * 60) push(pr, c.id);
}
if (length(pr)) detach('for i in ' + join(' ', map(pr, q)) + '; do sh ' + q(SH) + ' cpull "$i"; done');
let pc = rjs(TMP + '/bk-pc.json'), PC = (type(pc?.list) == 'array' && now - pc.t < 3600) ? pc.list : pcscan(N, D);
bkmacs(N, PC);
let pa = pcatick(Xc, N, PC, now);
if (length(pa)) detach('for i in ' + join(' ', map(pa, q)) + '; do sh ' + q(SH) + ' pccloud "$i"; done');
let at4 = t.hour == 4 && t.min < 5;
if (length(PC) && (at4 || !stat(TMP + '/bk-du.json'))) detach('sh ' + q(SH) + ' du');
bkown();
if (!at4) return { ok: true, run: run, cloud: cr, pccloud: pa, pull: pr };
let W = rjs(BKD + '/warned.json') ?? {}, ch = false, P = protect();
for (let d in alldevs(P)) {
let key = d.kind + ':' + (d.mac || d.name), lo = d.last > 0 && !d.ok, nm = d.name, po = (d.own ?? 'admin') != 'admin' ? ovis(d.own) : null;
let txt = po != null ? (d.kind == 'phone' ? L('⚠️ Backup ¦ ' + po + ': un telefono senza copia', '⚠️ Backup ¦ ' + po + ': a phone without a copy') :
L('⚠️ Backup ¦ ' + po + ': un computer senza copia', '⚠️ Backup ¦ ' + po + ': a computer without a copy')) :
L('⚠️ Backup ¦ ' + nm + ' senza copia ¦ Ultima ' + d.days + (d.days == 1 ? ' giorno fa' : ' giorni fa'), '⚠️ Backup ¦ ' + nm + ' without a copy ¦ Last ' + d.days + (d.days == 1 ? ' day ago' : ' days ago'));
if (warned(W, key, lo, 'nas_nocopy', txt,
d.kind == 'phone' && po == null ? 'nas_photo_ok' : null, L('📱 Backup ¦ ' + nm + ' di nuovo salvato', '📱 Backup ¦ ' + nm + ' saved again'))) ch = true;
}
for (let x in P.tasks) {
let po = (x.own ?? 'admin') != 'admin' ? ovis(x.own) : null;
if (warned(W, 'task:' + x.id, x.late, 'nas_backup_late', po != null ? L('⚠️ Backup ¦ ' + po + ': un backup in ritardo', '⚠️ Backup ¦ ' + po + ': a backup is late') :
L('⚠️ Backup ¦ In ritardo ¦ ' + x.name, '⚠️ Backup ¦ Late ¦ ' + x.name))) ch = true;
}
if (ch) { mkdirp(BKD); wjs(BKD + '/warned.json', W); }
let VB = map(filter(N.backups, (b) => b.dest?.kind != 'nas' && b.on !== false), (b) => q(b.id));
if (A.verify && t.mday == 1 && length(VB)) detach('for i in ' + join(' ', VB) + '; do sh ' + q(SH) + ' verify "$i"; done');
for (let b in N.backups) if (b.dest?.kind != 'nas') bkprune(b.id);
if (length(filter(Xc.cloud, (c) => c.kind == 'backup'))) detach('sh ' + q(SH) + ' cloudold');
return { ok: true, run: run, cloud: cr, pccloud: pa, pull: pr, checked: true };
}

const MODC = {};
function modof(f) { return UCFG.modof(MODC, f); }
function vcall(args) {
let V = modof(VUC);
let fn = V?._backup ?? V?.nas_backup;
if (type(fn?.call) != 'function') return err('svc', 'Servizi del NAS non caricati', 'NAS services not loaded');
return fn.call({ args: args });
}
function smbenc(s) { return replace('' + s, /[^A-Za-z0-9._~-]/g, (c) => join('', map(split(c, ''), (b) => sprintf('%%%02X', ord(b))))); }
function pcinfo(N, D, k, W, ST) {
let x = N[k] ?? {}, d = mainof(D, N), s = type(ST?.[k]) == 'object' ? ST[k] : {}, PK = filter(pclist(N, D), (c) => c.kind == k), PC = filter(PK, (c) => ownof(c) == W.own), used = 0, MC = rjs(BKD + '/macs.json') ?? {};
for (let c in (W.adm ? PK : PC)) used += c.bytes;
let nb = '' + (ST?.nb || 'NAS'), mh = '' + (ST?.lanip || nb), url = (n) => k == 'tm' ? 'smb://' + mh + '/' + smbenc(n) : '\\\\' + nb + '\\' + n;
let SH = map(filter(type(s.shares) == 'array' ? s.shares : [], (h) => type(h) == 'object' && (h.user ?? 'admin') == W.own),
(h) => ({ user: h.user ?? 'admin', name: h.name, path: h.path, ro: h.ro === true, missing: h.missing === true, url: url(h.name) }));
let me = null; for (let h in SH) if ((h.user ?? 'admin') == W.own) me = h;
return { on: x.on === true, state: s.state ?? (x.on === true ? (d ? 'on' : 'nomain') : 'off'), need: type(s.need) == 'array' ? s.need : [],
disk: d?.id ?? '', path: me?.path ?? (W.adm ? null : ud(W.own, k, null, N)) ?? '', quota_gb: s.quota_gb ?? x.quota_gb ?? 0, used: used,
missing: x.on === true && (!d || me?.missing === true), ro: d?.ro === true || me?.ro === true, name: me?.name ?? '', url: me ? me.url : '',
also: pcaout(xget(), W.own, k),
shares: SH, pcs: map(PC, (c) => ({ name: c.name, own: ownof(c), last: c.last, bytes: c.bytes, mac: MC[k]?.[c.name] ?? '' })) };
}

let ME = null;
function ccall(own, args, x) { return ME.nas_cloud.call({ ...(x ?? {}), ...(own != 'admin' ? { wfown: own } : {}), args: args }); }
function also1(w) { return type(w) == 'object' && w.router !== true && (w.all === true || (type(w.dirs) == 'array' && length(w.dirs) == 1)); }
function kidof(Xc, b) { if (length(b?.also ?? '')) for (let c in Xc.cloud) if (c.id == b.also && c.of == b.id) return c; return null; }
function alsosrc(c, b) { c.disk = b.what.disk; c.path = b.what.all ? '/' : b.what.dirs[0]; c.name = b.name; c.on = b.on !== false; c.warn = b.warn !== false; c.at = ''; c.every = 0; }
function alsofollow(b) {
let Xc = xget(), c = kidof(Xc, b);
if (!c || !also1(b.what)) return;
let o = sprintf('%J', c);
alsosrc(c, b);
if (sprintf('%J', c) != o && xput(Xc)) cwrite(c);
}
function alsoset(b, al) {
let Xc = xget(), cur = kidof(Xc, b);
if (al && !also1(b.what)) return err('also', 'Copia Anche Su vale per una cartella o un disco', 'Also Copy To works for one folder or one disk');
if (al && cur && cur.acct == '' + al.acct && (al.remote == null || lc('/' + join('/', relp('' + al.remote) ?? [])) == lc(cur.remote))) { alsofollow(b); return {}; }
if (cur) { let r = ccall(ownof(b), { act: 'del', id: cur.id }); if (r?.error) return r; }
if (!al) {
if (length(b.also ?? '') && !nsave((F) => { for (let x in F.backups) if (x.id == b.id) delete x.also; })) return busy();
return {};
}
let src = b.what.all ? '/' : b.what.dirs[0];
let r = ccall(ownof(b), { act: 'set', kind: 'backup', acct: '' + al.acct, disk: b.what.disk, path: src, name: b.name, at: '', every: 0, on: b.on !== false, warn: b.warn !== false,
...(al.remote != null ? { remote: '' + al.remote } : {}) });
if (r?.error) return r;
Xc = xget();
let c = null;
for (let x in Xc.cloud) if (x.id == r.id) c = x;
if (!c) return busy();
c.of = b.id; if (!xput(Xc)) return busy(); cwrite(c);
if (!nsave((F) => { for (let x in F.backups) if (x.id == b.id) x.also = c.id; })) return busy();
return r.key ? { key: r.key } : {};
}

function phakid(Xc, own) {
let id = type(Xc.photo.also) == 'object' ? Xc.photo.also[own] : null;
if (type(id) == 'string') for (let c in Xc.cloud) if (c.id == id && ownof(c) == own) return c;
return null;
}
function phaout(Xc, own) {
let c = phakid(Xc, own);
if (!c) return null;
let AM = amap(), A = AM[c.acct], s = clast(c.id), pr = cprog(c.id, c.disk), e = rjs(X + '/cloud-' + c.id + '.json');
return { id: c.id, acct: c.acct ?? '', acct_name: A?.name ?? '', last: s.last, last_ok: s.ok,
...cst(c, diskof(disks(), c.disk), AM, s, pr, e, cfacts(c.id), rcq('paused') === true) };
}
function photoout(Xc, W) {
let D = disks(), N = nget(), r = [], P = persons(), RM = reminds();
for (let id, p in Xc.photo.phones) {
if (ownof(p) != W.own) continue;
let cl = p.dest == 'cloud', L = phloc(D, N, p), d = cl ? null : L.d, s = cl ? phcstat(id) : phonestat(id, d ? { ...d, p: L.path } : null), mac = phmac(id, p), pe = mac ? personof(P, mac) : null;
push(r, { id: id, name: p.name, own: ownof(p), disk: cl ? '' : L.disk, path: cl ? '' : L.path, t: p.t ?? 0, last: s.last ?? 0, files: s.files ?? 0, bytes: s.bytes ?? 0, missing: !cl && d == null,
dest: cl ? 'cloud' : 'disk', acct: cl ? p.acct ?? '' : '', remote: cl ? p.remote ?? '' : '', queue: cl ? s.queue : 0, ro: d?.ro === true,
mac: mac, auto: p.auto === true, charge: p.charge === true, what: p.what ?? 'all', person: pe?.name ?? '', wait: p.wait ?? 0, wait_t: p.wait_t ?? 0,
remind: mac && RM[mac] && time() - RM[mac].t < 3 * DAY ? RM[mac].t : 0 });
}
let pp = null;
if (W.adm) {
let A = advof(N), mn = mainof(D, N), now = time(), ps = pstopc(N), V = [];
for (let id, p in Xc.photo.phones) push(V, { id: id, p: p, own: ownof(p) });
pp = ppl(V,(x) => phst(x.id, x.p, Xc, N, mn, A, ps(x.own), now));
}
return { on: Xc.photo.on !== false, phones: sort(r, (a, b) => a.t - b.t), also: phaout(Xc, W.own), ...(pp ? { people: pp } : {}), need: need('inotify'),
dav_port: type(Xc.link?.port) == 'int' ? Xc.link.port : 5006 };
}
function phalso(W, al) {
let own = W.own, Xc = xget(), cur = phakid(Xc, own), acct = type(al) == 'object' ? '' + (al.acct ?? '') : '';
let link = (id) => {
let X2 = xget();
if (type(X2.photo.also) != 'object') X2.photo.also = {};
if (id) X2.photo.also[own] = id; else delete X2.photo.also[own];
if (!length(X2.photo.also)) delete X2.photo.also;
return xput(X2) ? {} : busy();
};
if (!length(acct)) {
if (cur) { let r = ccall(own, { act: 'del', id: cur.id, old: 'keep' }); if (r?.error) return r; }
return type(Xc.photo.also?.[own]) == 'string' ? link(null) : {};
}
let A = amap()[acct];
if (!A) return err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
if (auser(A) != 'admin' && auser(A) != own) return err('private', 'Cloud personale di un\'altra persona', 'Another person\'s personal cloud');
if (cur && cur.acct == A.id) return {};
let D = disks(), N = nget(), Q = phloc(D, N, { own: own });
if (!Q.d || !length(Q.path)) return nomain();
let pd = phonedir(D, Q);
if (pd.error) return pd;
if (cur) { let r = ccall(own, { act: 'del', id: cur.id, old: 'keep' }); if (r?.error) return r; }
let r = ccall(own, { act: 'set', kind: 'sync', acct: A.id, disk: Q.disk, path: Q.path, dir: 'up', mirror: false, at: '', every: 60, on: true,
name: L('Foto Del Telefono', 'Phone Photos') }, { wfph: Q.path });
if (r?.error) return r;
return link(r.id);
}
function pcalso(W, k, al) {
let own = W.own, Xc = xget(), cur = pcakid(Xc, own, k), acct = type(al) == 'object' ? '' + (al.acct ?? '') : '';
if (!length(acct)) {
if (cur) { let r = ccall(own, { act: 'del', id: cur.id, old: 'keep' }); if (r?.error) return r; }
return {};
}
let A = amap()[acct];
if (!A) return err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
if (auser(A) != 'admin' && auser(A) != own) return err('private', 'Cloud personale di un\'altra persona', 'Another person\'s personal cloud');
if (cur && cur.acct == A.id) return {};
let N = nget(), D = disks(), mn = mainof(D, N), rel = ud(own, k, null, N);
if (N[k]?.on !== true) return err('off', k == 'tm' ? 'Backup Del Mac spento' : 'Backup Del PC spento', k == 'tm' ? 'Mac Backup is off' : 'PC Backup is off');
if (!mn) return nomain();
if (!rel) return errp();
let abs = absof(D, mn.id, rel);
if (!abs || stat(abs)?.type != 'directory') return err('path', 'La cartella non esiste', 'The folder does not exist');
if (cur) { let r = ccall(own, { act: 'del', id: cur.id, old: 'keep' }); if (r?.error) return r; }
let r = ccall(own, { act: 'set', kind: 'sync', acct: A.id, disk: mn.id, path: rel, dir: 'up', mirror: false, at: '', every: 0, on: true,
name: k == 'tm' ? L('Backup Del Mac', 'Mac Backup') : L('Backup Del PC', 'PC Backup') }, { wfph: rel });
if (r?.error) return r;
Xc = xget();
let c = null;
for (let x in Xc.cloud) if (x.id == r.id) c = x;
if (!c) return busy();
c.pc = k;
if (!xput(Xc)) return busy();
cwrite(c);
return {};
}
const M = {
nas_backup: {
args: { act: 'x', id: 'x', name: 'x', what: {}, dest: {}, when: {}, keep_days: 0, dirs: [], on: true, warn: true, quota_gb: 0,
stamp: 'x', paths: [], to: 'x', warn_phone: 0, warn_pc: 0, warn_task: 0, full: 'x', cap: 0, verify: true, also: {}, as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let W = whoami(req);
if (!W?.own) return werr(W);
let a = req.args ?? {}, act = a.act ?? 'get', N = nget(), D = disks(), id = '' + (a.id ?? ''), A = advof(N);
let pcboth = () => { let ST = vcall({ act: 'get' }); if (ST?.error) ST = null; return { tm_info: pcinfo(N, D, 'tm', W, ST), fh_info: pcinfo(N, D, 'fh', W, ST) }; };
let out = () => { let XB = xget(); return { list: map(filter(N.backups, (b) => ownof(b) == W.own), (b) => { let s = bakstate(b.id), rn = bakrun(b), kd = kidof(XB, b);
let k = rn ? 'run' : (b.what?.router !== true && !diskof(D, b.what?.disk)) || (b.dest?.kind != 'nas' && !diskof(D, b.dest?.disk)) ? 'gone' :
s.ok === false ? 'err' : !s.last ? 'never' : 'ok';
return { id: b.id, name: b.name, own: ownof(b), last: s.last, last_ok: s.ok, ok_t: s.okt, size: s.size, xfer: s.xfer, secs: s.secs, versions: s.versions,
next: baknext(b), dest: b.dest, at: b.when?.at ?? '', mode: modeof(b), on: b.on !== false, warn: b.warn !== false, late: late(b, s, A), days: daysof(b.when?.days) ?? [],
what: b.what, disk: b.what?.disk ?? '', keep_days: b.keep_days ?? 0, run: rn,
missing: !diskof(D, b.what?.disk) || (b.dest?.kind != 'nas' && !diskof(D, b.dest?.disk)),
also: kd ? kd.id : '', st: k, st_t: CST[k][0], st_t_en: CST[k][1],
chk: s.chk ? s.chk.why : '', chk_n: s.chk?.n ?? 0, chk_files: s.chk?.files ?? [],
chk_t: !s.chk ? '' : s.chk.why == 'miss' ? 'Cartelle Da Copiare Non Trovate: ' + s.chk.n : 'File Non Copiati: ' + s.chk.n,
chk_t_en: !s.chk ? '' : s.chk.why == 'miss' ? 'Folders To Copy Not Found: ' + s.chk.n : 'Files Not Copied: ' + s.chk.n }; }),
tm: N.tm?.on === true, fh: N.fh?.on === true, tm_ok: sambaOk(), rsync: !length(need('rsync')), on: N.bk.on !== false, adv: A,
...pcboth(), main: mainof(D, N)?.id ?? '',
...(W.adm ? { people: bkppl(N, D, A) } : {}) }; };
if (act == 'get') return out();
if (act == 'pcalso') {
if (id != 'tm' && id != 'fh') return err('id', 'Scegli Backup Del Mac o Backup Del PC', 'Choose Mac Backup or PC Backup');
let P = need('rclone'); if (type(a.also) == 'object' && length(a.also.acct ?? '') && length(P)) return pkgerr(P);
let r = pcalso(W, id, type(a.also) == 'object' ? a.also : null);
if (r?.error) return r;
N = nget(); D = disks();
return out();
}
if (!W.adm && (act == 'adv' || (act == 'set' && (id == 'tm' || id == 'fh')))) return eadm();
if (act == 'adv') {
let X2 = type(N.bk.adv) == 'object' ? N.bk.adv : {};
for (let k in [ 'warn_phone', 'warn_pc', 'warn_task' ]) if (a[k] != null) {
if (type(a[k]) != 'int' || a[k] < 1 || a[k] > 90) return err(k, 'Giorni da 1 a 90', 'Days from 1 to 90');
X2[k] = a[k];
}
if (a.full != null) { if (!match('' + a.full, /^(prune|stop)$/)) return err('full', 'Scelta non valida', 'Invalid choice'); X2.full = a.full; }
if (a.cap != null) { if (type(a.cap) != 'int' || a.cap < 50 || a.cap > 95) return err('cap', 'Quota da 50 a 95%', 'Quota from 50 to 95%'); X2.cap = a.cap; }
if (type(a.verify) == 'bool') X2.verify = a.verify;
let N2 = nsave((F) => {
let Y = type(F.bk.adv) == 'object' ? F.bk.adv : {};
for (let k in [ 'warn_phone', 'warn_pc', 'warn_task', 'full', 'cap', 'verify' ]) if (X2[k] != null) Y[k] = X2[k];
F.bk.adv = Y;
if (type(a.on) == 'bool') F.bk.on = a.on;
});
if (!N2) return busy();
N = N2; A = advof(N);
return out();
}
if (act == 'set' && (id == 'tm' || id == 'fh')) {
let x = N[id] ?? {}, qg = a.quota_gb;
if (qg != null && (type(qg) != 'int' || qg < 0 || qg > 100000)) return err('quota', 'Quota non valida', 'Invalid quota');
let r = null;
if (type(a.on) == 'bool') {
r = vcall({ act: 'set', id: id, on: a.on, ...(type(a.dest) == 'object' ? { dest: a.dest } : {}) });
if (r?.error) return r;
}
if (qg != null) {
N = nsave((F) => { let y = type(F[id]) == 'object' ? F[id] : {}; y.quota_gb = qg; F[id] = y; });
if (!N) return busy();
x = N[id];
if (x.on === true && r == null) { r = vcall({ act: 'set', id: id, on: true }); if (r?.error) return r; }
}
N = nget(); D = disks();
return { ...out(), ...(r?.drop ? { drop: r.drop } : {}) };
}
let i = -1; for (let k = 0; k < length(N.backups); k++) if (N.backups[k].id == id && ownof(N.backups[k]) == W.own) i = k;
if (i < 0 && W.adm && length(id)) for (let b in N.backups) if (b.id == id && ownof(b) != 'admin') return err('private', 'Backup di un\'altra persona', 'Another person\'s backup');
if (act == 'del') {
if (i < 0) return err('none', 'Backup non trovato', 'Backup not found');
let kd = kidof(xget(), N.backups[i]);
if (kd) { let r = ccall(ownof(N.backups[i]), { act: 'del', id: kd.id }); if (r?.error) return r; }
let N2 = nsave((F) => { F.backups = filter(F.backups, (b) => b.id != id); });
if (!N2) return busy();
N = N2;
for (let e in [ '.sh', '.excl', '.dirs', '.nv', '.chk', '.skip' ]) unlink(BKD + '/' + id + e);
return out();	/* le copie già fatte restano sul disco */
}
if (act == 'run' || act == 'dry') {
if (i < 0) return err('none', 'Backup non trovato', 'Backup not found');
let pk = need('rsync'); if (length(pk)) return pkgerr(pk);
let b = N.backups[i], ps = pstop(ownof(b));
if (ps) return ps;
if (act == 'dry') {
let f = TMP + '/bk-dry-' + id + '.json', r = rjs(f), st = stat(BKD + '/' + id + '.sh');
if (r && r.state != 'run' && time() - (r.t ?? 0) < 600 && (r.cfg ?? 0) >= (st?.mtime ?? 0)) return r;
if (r?.state == 'run' && alive(r.pid)) return r;
wjs(f, { state: 'run', t: time() });
detach('sh ' + q(SH) + ' dry ' + q(id));
return { state: 'run', t: time() };
}
if (bakrun(b)) return err('run', 'Questo backup è già in corso', 'This backup is already running');
let j = 'bak-' + rid(), df = '';
if (type(a.dirs) == 'array' && length(a.dirs)) {
let L2 = [];
for (let p in a.dirs) {
p = relok(p);
if (p == null || p == '/') return err('path', 'Cartella non valida', 'Invalid folder');
let e = srcok(W, D, N, b.what?.disk, p); if (e) return e;
push(L2, p);
}
df = TMP + '/' + j + '.dirs'; writefile(df, join('\n', uniq(L2)) + '\n');
}
mkdirp(JOBS);
wjs(JOBS + '/' + j + '.json', { id: j, own: W.own, op: 'backup', name: b.name, done: 0, total: 0, bytes: 0, bytes_total: 0, file: '', state: 'run', t: time() });
detach('sh ' + q(SH) + ' run ' + q(id) + ' ' + q(j) + ' ' + q(df));
return { job: j };
}
if (act == 'versions' || act == 'restore') {
if (i < 0) return err('none', 'Backup non trovato', 'Backup not found');
let b = N.backups[i];
if (b.dest?.kind == 'nas') return err('remote', 'Copie su un altro NAS: ripristina dal NAS', 'Copies on another NAS: restore from that NAS');
let ds = bakdst(D, b);
if (!ds) return err('disk', 'Disco delle copie non collegato', 'Backup drive not connected');
let V = versions(ds.abs), mir = stat(ds.abs + '/current')?.type == 'directory', OV = mir ? versions(ds.abs + '/old') : [], now = time();
if (act == 'versions') {
let r = map(reverse(V), (v) => { let t = stampt(v); return { stamp: v, t: t, kind: now - t < 31 * DAY ? 'day' : 'week' }; });
if (mir) {
r = map(reverse(OV), (v) => ({ stamp: v, t: stampt(v), kind: 'day' }));
unshift(r, { stamp: 'current', t: stat(ds.abs + '/current').mtime, kind: 'mirror', ...(lstat(ds.abs + '/.wf-incompleta') ? { partial: true } : {}) });
}
return { list: r, disk: ds.d.id, path: ds.rel };
}
let sp = '' + (a.stamp ?? ''), old = mir && index(OV, sp) >= 0;
if (!((sp == 'current' && mir) || old || index(V, sp) >= 0)) return err('stamp', 'Versione non trovata', 'Version not found');
let sd = diskof(D, b.what?.disk);
if (!sd) return err('disk', 'Disco di partenza non collegato', 'Source disk not connected');
if (sd.ro) return err('ro', 'Il disco è in sola lettura', 'The disk is read-only');
let to = '' + (a.to ?? 'orig'), tb = sd.mnt, tr = '';
if (to != 'orig') { let r2 = relok(to); if (r2 == null || !absof(D, sd.id, r2)) return err('to', 'Cartella di arrivo non valida', 'Invalid destination folder'); tb = absof(D, sd.id, r2); tr = r2 == '/' ? '' : r2; }
let PS = type(a.paths) == 'array' && length(a.paths) ? a.paths : [ '/' ], lines = [], vd = ds.abs + (old ? '/old/' : '/') + sp;
if (length(PS) > 500) return err('max', 'Al massimo 500 file per volta', 'At most 500 files at a time');
for (let p in PS) {
p = relok(p);
if (p == null) return err('path', 'Percorso non valido', 'Invalid path');
let ek = srcok(W, D, N, sd.id, (tr + (p == '/' ? '' : p)) || '/', true); if (ek) return ek;
let src = vd + (p == '/' ? '' : p), dst = tb + (p == '/' ? '' : p);
if (!lstat(src) && old) continue;
if (!lstat(src)) return err('path', 'File non trovato nella versione', 'File not found in the version');
if (!inside(vd, src)) return err('path', 'Percorso non valido', 'Invalid path');
if (!inside(sd.mnt, p == '/' ? dst : dirof(dst))) return err('to', 'Cartella di arrivo non valida', 'Invalid destination folder');
push(lines, src + '\t' + dst);
}
if (!length(lines)) return err('path', 'In questa copia niente di queste cartelle è cambiato', 'Nothing in these folders changed in this copy');
let j = 'bak-r' + rid();
mkdirp(JOBS);
writefile(JOBS + '/' + j + '.list', join('\n', lines) + '\n');
wjs(JOBS + '/' + j + '.json', { id: j, own: W.own, op: 'restore', name: b.name, done: 0, total: 0, bytes: 0, bytes_total: 0, file: '', state: 'run', t: time(), root: rpath(sd.mnt) ?? sd.mnt });
detach('sh ' + q(SH) + ' restore ' + q(j));
return { job: j };
}
if (act != 'set') return err('act', 'Azione sconosciuta', 'Unknown action');
if (exists(a, 'also')) {
let al = type(a.also) == 'object' && length('' + (a.also.acct ?? '')) ? a.also : null, rest = { ...a };
delete rest.also;
let more = length(filter(keys(rest), (k) => k != 'act' && k != 'id' && k != 'as' && k != 'ubus_rpc_session')) > 0;
if (i < 0 && !more) return err('none', 'Backup non trovato', 'Backup not found');
if (al) {
let AA = amap()['' + al.acct];
if (!AA) return err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
if (auser(AA) != 'admin' && auser(AA) != W.own) return err('private', 'Cloud personale di un\'altra persona', 'Another person\'s personal cloud');
let w = a.what ?? N.backups[i]?.what;
if (!also1(w)) return err('also', 'Copia Anche Su vale per una cartella o un disco', 'Also Copy To works for one folder or one disk');
if (migrating()) return busy();
}
let rq = (x) => ({ args: x, info: req?.info, ...(req?.wfown != null ? { wfown: req.wfown } : {}) });
let r = more ? ME.nas_backup.call(rq(rest)) : null;
if (r?.error) return r;
N = nget(); D = disks();
let bid = r?.id ?? id, b = null;
for (let x in N.backups) if (x.id == bid) b = x;
if (!b) return err('none', 'Backup non trovato', 'Backup not found');
let k = alsoset(b, al);
if (k?.error) {
if (i < 0) { let dx = { act: 'del', id: b.id }; for (let x in [ 'ubus_rpc_session', 'as' ]) if (exists(a, x)) dx[x] = a[x]; ME.nas_backup.call(rq(dx)); }
return k;
}
N = nget();
return { ...out(), id: b.id, ok: true, ...(k.key ? { key: k.key } : {}) };
}
if (i >= 0 && (type(a.on) == 'bool' || type(a.warn) == 'bool') && a.what == null && a.dest == null && a.when == null && a.name == null && a.keep_days == null) {
let bw = null, N2 = nsave((F) => { for (let b in F.backups) if (b.id == id) { for (let k in [ 'on', 'warn' ]) if (type(a[k]) == 'bool') b[k] = a[k]; bw = b; } });
if (!N2) return busy();
N = N2;
if (!bw) return err('none', 'Backup non trovato', 'Backup not found');
bakwrite(bw, N); alsofollow(bw);
return { ...out(), id: id };
}
let pk = need('rsync'); if (length(pk)) return pkgerr(pk);
let old = i >= 0 ? N.backups[i] : {}, w = a.what ?? old.what ?? {}, de = a.dest ?? old.dest ?? {}, wh = a.when ?? old.when ?? {};
let nm = trim('' + (a.name ?? old.name ?? ''));
let auto = i < 0 && a.name == null;
if (!auto && (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/) || substr(nm, 0, 1) == '.')) return err('name', 'Nome del backup non valido', 'Invalid backup name');
if (!W.adm && (w.router === true || de.kind == 'nas')) return eadm();
if (!auto) { let ne = bknameok(N, W.own, id, nm); if (ne) return ne; }
let sd = '' + (w.disk ?? ''), mn = mainof(D, N);
if (!diskof(D, sd) && !(w.router === true)) return err('disk', 'Disco di partenza non collegato', 'Source disk not connected');
if (w.all === true && w.router !== true) { if (mn && sd == mn.id) return errp(); let e = srcok(W, D, N, sd, '/'); if (e) return e; }
let dirs = [];
if (w.all !== true) for (let p in (w.dirs ?? [])) {
p = relok(p);
if (p == null || !absof(D, sd, p)) return err('path', 'Cartella non valida', 'Invalid folder');
let e = srcok(W, D, N, sd, p); if (e) return e;
push(dirs, p);
}
if (w.all !== true && !length(dirs) && w.router !== true) return err('dirs', 'Scegli tutto il disco o almeno una cartella', 'Choose the whole disk or at least one folder');
if (auto) nm = bkname(N, W.own, w.router === true ? 'Router' : w.all === true || dirs[0] == '/' ? diskof(D, sd)?.name ?? '' : bname(dirs[0]));
let skip = filter(uniq(w.skip ?? []), (s) => type(s) == 'string' && SKIP[s] != null);
let kind = '' + (de.kind ?? ''), host = '' + (de.host ?? ''), keep = i >= 0 && old.own == null;
let dp = relok(keep ? old.dest?.path ?? ud('admin', 'backup', null, N) : ud(W.own, 'backup', null, N)), dk = '' + (de.disk ?? mn?.id ?? '');
if (!match(kind, /^(disk|dir|nas)$/) || dp == null) return err('dest', 'Destinazione non valida', 'Invalid destination');
if (kind == 'nas' && !match(host, /^[A-Za-z0-9][A-Za-z0-9.:-]{0,252}$/)) return err('host', 'Indirizzo del NAS non valido', 'Invalid NAS address');
if (kind != 'nas') {
if (!W.adm && !mn) return nomain();
if (!W.adm && dk != mn.id) return errp();
let dd = diskof(D, dk);
if (!dd) return err('dest', 'Disco di arrivo non collegato', 'Destination disk not connected');
if (dd.ro) return err('ro', 'Il disco di arrivo è in sola lettura', 'The destination disk is read-only');
if (!absof(D, dd.id, dp)) return err('dest', 'Cartella di arrivo non valida', 'Invalid destination folder');
if (dd.id == sd && (w.all === true || dp == '/' || length(filter(dirs, (x) => index(dp + '/', x + '/') == 0)))) return err('loop', 'La copia non può stare dentro le cartelle da copiare', 'The copy cannot be inside the folders to copy');
}
let mode = '' + (wh.mode ?? (length(wh.at ?? '') ? 'night' : (a.when == null && i >= 0 ? modeof(old) : 'man')));
if (!match(mode, /^(night|plug|man)$/)) return err('when', 'Quando non valido', 'Invalid schedule');
if (mode == 'plug' && kind == 'nas') return err('when', 'Quando Colleghi Il Disco vale solo per un disco', 'When You Connect The Drive only works with a drive');
let at = mode == 'night' ? '' + (wh.at || '03:00') : '';
if (wh.days != null && type(wh.days) != 'array') return err('days', 'Giorni non validi', 'Invalid days');
let dys = mode == 'night' ? daysof(wh.days ?? old.when?.days) : null;
if (length(at) && !match(at, /^([01][0-9]|2[0-3]):[0-5][0-9]$/)) return err('at', 'Orario non valido', 'Invalid time');
let kd = a.keep_days ?? old.keep_days ?? 30;
if (type(kd) != 'int' || kd < 0 || kd > 3650) return err('keep', 'Giorni da tenere non validi', 'Invalid days to keep');
if (i < 0 && length(N.backups) >= BMAX) return err('max', 'Al massimo ' + BMAX + ' backup', 'At most ' + BMAX + ' backups');
let b = { ...old, ...(i < 0 ? { own: W.own } : {}), id: i >= 0 ? id : 'b' + rid(), name: nm, what: { all: w.all === true, dirs: dirs, disk: sd, skip: skip, router: w.router === true },
dest: { kind: kind, disk: kind == 'nas' ? '' : dk, path: dp, host: kind == 'nas' ? host : '' }, when: { mode: mode, at: at, ...(dys ? { days: dys } : {}) }, keep_days: kd,
on: type(a.on) == 'bool' ? a.on : old.on !== false, warn: type(a.warn) == 'bool' ? a.warn : old.warn !== false, t: old.t ?? time() };
if (kidof(xget(), b) && !also1(b.what)) return err('also', 'Copia Anche Su vale per una cartella o un disco: togli prima la copia nel cloud', 'Also Copy To works for one folder or one disk: remove the cloud copy first');
let N2 = nsave((F) => {
let k = -1; for (let j = 0; j < length(F.backups); j++) if (F.backups[j].id == b.id) k = j;
if (k >= 0) F.backups[k] = b; else push(F.backups, b);
});
if (!N2) return busy();
N = N2;
bakwrite(b, N); alsofollow(b);
return { ...out(), id: b.id };
}
},
nas_photo: {
args: { act: 'x', id: 'x', name: 'x', disk: 'x', path: 'x', files: [], file: 'x', size: 0, mtime: 0, off: 0, data: 'x', last: true,
mac: 'x', auto: true, charge: true, what: 'x', on: true, dest: 'x', acct: 'x', remote: 'x', items: [], also: {}, as: 'x', lang: 'x', taken: 0, wait: 0, ubus_rpc_session: 'x' },
call: function(req) {
begin();
let W = whoami(req);
if (!W?.own) return werr(W);
let a = req.args ?? {}, act = a.act ?? 'get', Xc = xget(), id = '' + (a.id ?? ''), mac = lc('' + (a.mac ?? ''));
Xc = acctfix(Xc) ?? Xc;
if (act == 'get') return photoout(Xc, W);
if (act == 'set' && exists(a, 'also')) {
let r = phalso(W, a.also);
if (r?.error) return r;
Xc = xget();
if (a.id == null && a.mac == null) return photoout(Xc, W);
}
if (act == 'set' && a.id == null && a.mac == null) {
if (!W.adm) return eadm();
if (type(a.on) != 'bool') return err('id', 'Telefono non valido', 'Invalid phone');
Xc.photo.on = a.on; if (!xput(Xc)) return busy();
return photoout(Xc, W);
}
if (a.mac != null && !macok(mac)) return err('mac', 'Indirizzo MAC non valido', 'Invalid MAC address');
if (macok(mac)) {
let f = null;
for (let k, p in Xc.photo.phones) if (phmac(k, p) == mac) f = k;
if (f) id = f; else if (!match(id, /^[A-Za-z0-9_-]{8,64}$/)) id = 'm' + replace(mac, /:/g, '');
}
if (!match(id, /^[A-Za-z0-9_-]{8,64}$/)) return err('id', 'Telefono non valido', 'Invalid phone');
let ph = Xc.photo.phones[id];
if (ph && ownof(ph) != W.own) return err('private', 'Telefono di un\'altra persona', 'Another person\'s phone');
if (act == 'del') {
if (!ph) return err('none', 'Telefono non trovato', 'Phone not found');
delete Xc.photo.phones[id]; if (!xput(Xc)) return busy(); unlink(X + '/photo-' + id + '.json');
if (ph.dest == 'cloud') phcdrop(id);
return photoout(Xc, W);	/* le foto restano sul disco o nel cloud */
}
let D = disks(), N = nget();
if (act == 'set') {
if (!ph && length(keys(Xc.photo.phones)) >= PMAX) return err('max', 'Al massimo ' + PMAX + ' telefoni', 'At most ' + PMAX + ' phones');
let nm = trim('' + (a.name ?? ph?.name ?? ''));
if (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/) || substr(nm, 0, 1) == '.') return err('name', 'Nome del telefono non valido', 'Invalid phone name');
let wt = '' + (a.what ?? ph?.what ?? 'all');
if (!match(wt, /^(all|photo|video)$/)) return err('what', 'Cosa salvare non valido', 'Invalid choice of what to save');
if (a.wait != null && (type(a.wait) != 'int' || a.wait < 0)) return err('wait', 'Numero delle foto non valido', 'Invalid number of photos');
let L = phloc(D, N, { own: W.own }), wok = L.d != null && !L.d.ro, wc = ph?.dest == 'cloud', dst = '' + (a.dest ?? (wc ? 'cloud' : (wok ? 'disk' : 'cloud')));
if (!match(dst, /^(disk|cloud)$/)) return err('dest', 'Destinazione non valida', 'Invalid destination');
if (dst == 'cloud') {
if (wok && !wc) return err('dest', 'Con il disco le foto vanno sul NAS', 'With the disk the photos go to the NAS');
let A = amap()['' + (a.acct ?? ph?.acct ?? '')];
if (!A) return err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
let rp = relp(L.path);
if (rp == null || !length(rp) || length(join('/', rp)) > 512) return err('remote', 'Cartella del cloud non valida', 'Invalid cloud folder');
let p = { ...(ph ?? {}), own: W.own, name: nm, disk: '', path: '', dest: 'cloud', acct: A.id, remote: join('/', rp), t: ph?.t ?? time(), what: wt };
if (macok(mac)) p.mac = mac;
for (let k in [ 'auto', 'charge' ]) if (type(a[k]) == 'bool') p[k] = a[k];
if (type(a.wait) == 'int') { p.wait = a.wait; p.wait_t = time(); }
if (!wc) unlink(X + '/photo-' + id + '.json');
Xc.photo.phones[id] = p; if (!xput(Xc)) return busy();
return { ...photoout(Xc, W), id: id };
}
let p = { ...(ph ?? {}), own: W.own, name: nm, disk: L.disk, path: L.path, t: ph?.t ?? time(), what: wt };
for (let k in [ 'dest', 'acct', 'remote' ]) delete p[k];
if (wc) unlink(X + '/photo-' + id + '.json');
if (macok(mac)) p.mac = mac;
for (let k in [ 'auto', 'charge' ]) if (type(a[k]) == 'bool') p[k] = a[k];
if (type(a.wait) == 'int') { p.wait = a.wait; p.wait_t = time(); }
let r = phonedir(D, p);
if (r.error) return r;
p.path = r.a.rel;
Xc.photo.phones[id] = p; if (!xput(Xc)) return busy();
return { ...photoout(Xc, W), id: id };
}
if (!ph) return err('none', 'Telefono non trovato: collegalo di nuovo', 'Phone not found: connect it again');
if (Xc.photo.on === false && (act == 'check' || act == 'put')) return err('off', 'Backup Del Telefono spento', 'Phone Backup is off');
let po = ownof(ph), lg = phlang(Xc, po) ?? (match('' + a.lang, /^(it|en)$/) ? a.lang : LG);
if (act == 'put' && a.last && phlang(Xc, po) == null) {
if (type(Xc.photo.lang) != 'object') Xc.photo.lang = {};
Xc.photo.lang[po] = lg;
xput(Xc);
}
let gs = (f) => ymof(f?.taken) ?? ymof(f?.mtime ?? f?.mt) ?? ymof(time());
if (ph.dest == 'cloud') return act == 'check' ? phccheck(a, id) : act == 'put' ? phcput(a, id, ph, lg) : err('act', 'Azione sconosciuta', 'Unknown action');
let fat =(d) => match(d.fs, /^(vfat|msdos|exfat)$/) != null, L = phloc(D, N, ph);
if (act == 'check') {
if (!L.d) return nomain();
let d = dsk(D, L.disk, false);
if (d.error) return d;
let base = absp(d, L.path);
if (!base) return err('path', 'Cartella non valida', 'Invalid folder');
let F = type(a.files) == 'array' ? a.files : [];
if (length(F) > 500) return err('max', 'Al massimo 500 file per volta', 'At most 500 files at a time');
let dup = [];
for (let k = 0; k < length(F); k++) {
let f = F[k], n = '' + (f?.name ?? ''), sz = f?.size, mt = f?.mtime ?? 0;
if (badname(n) || type(sz) != 'int' || type(mt) != 'int') continue;
if (phdup(base.abs, phsub(gs(f), n, lg), n, sz, mt, fat(d))) push(dup, k);
}
return { dup: dup, ro: d.ro === true };
}
if (act != 'put') return err('act', 'Azione sconosciuta', 'Unknown action');
let ps = pstop(ownof(ph));
if (ps) return ps;
let r = phonedir(D, L);
if (r.error) return r;
let n = '' + (a.file ?? ''), sz = a.size, mt = a.mtime ?? 0, off = a.off ?? 0;
if (badname(n) || substr(n, 0, 1) == '.') return err('name', 'Nome del file non valido', 'Invalid file name');
if (type(sz) != 'int' || sz < 0 || type(mt) != 'int' || type(off) != 'int' || off < 0) return err('val', 'Dati del file non validi', 'Invalid file data');
let tmp = r.a.abs + '/.' + n + '.' + substr(id, 0, 12) + '.wfpart';
if (off == 0) { let f = phdup(r.a.abs, phsub(gs(a), n, lg), n, sz, mt, fat(r.d)); if (f) return { ok: true, dup: true, name: bname(f) }; }
let data = b64d('' + (a.data ?? ''));
if (length(data) > PCHUNK) return err('big', 'Pezzo troppo grande', 'Chunk too large');
let ts = lstat(tmp);
if (ts && ts.type != 'file') return err('path', 'Percorso non valido', 'Invalid path');
if (off > 0 && (!ts || ts.size != off)) return err('off', 'Pezzo fuori posto: riprendi da ' + (ts?.size ?? 0), 'Chunk out of place: resume from ' + (ts?.size ?? 0), { size: ts?.size ?? 0 });
if (off + length(data) > sz) return err('size', 'Il file è più grande del previsto', 'The file is larger than expected');
let fr = vfs(r.d.mnt).free;
if (length(data) && length(data) + 16777216 > fr) return err('space', 'Spazio non sufficiente', 'Not enough space', { need: sz - off, free: fr });
let f = open(tmp, off > 0 ? 'r+' : 'w');
if (!f) return err('write', 'File non scritto', 'File not written');
if (off > 0) f.seek(off);
let wr = length(data) ? f.write(data) : 0;
f.close();
if (wr != length(data)) { unlink(tmp); return err('write', 'File non scritto: disco pieno o staccato', 'File not written: drive full or removed'); }
if (!a.last) return { ok: true, size: off + length(data) };
if (off + length(data) != sz) return err('size', 'File incompleto: riprendi da ' + (off + length(data)), 'Incomplete file: resume from ' + (off + length(data)), { size: off + length(data) });
let sub = phsub(phdate(tmp, n) ?? gs(a), n, lg), dir = r.a.abs + sub;
mkdirp(dir);
let dp = phdup(r.a.abs, sub, n, sz, mt, fat(r.d));
if (dp) { unlink(tmp); return { ok: true, dup: true, name: bname(dp) }; }
let fn = freename(dir, n);
if (!fn || !rename(tmp, dir + '/' + fn)) { unlink(tmp); return err('write', 'File non scritto', 'File not written'); }
if (mt > 0) { let t = localtime(mt); sh('touch -c -t ' + sprintf('%04d%02d%02d%02d%02d.%02d', t.year, t.mon, t.mday, t.hour, t.min, t.sec) + ' ' + q(dir + '/' + fn) + ' 2>/dev/null'); }
phoneadd(id, r.a.abs, sz);
return { ok: true, size: sz, name: fn, path: r.a.rel + sub + '/' + fn };
}
},
nas_cloud: {
args: { act: 'x', id: 'x', name: 'x', provider: 'x', token: 'x', client_id: 'x', client_secret: 'x', drive_id: 'x', drive_type: 'x',
disk: 'x', path: 'x', remote: 'x', dir: 'x', at: 'x', every: 0, on: true, kind: 'x', crypt: true, pass: 'x', stamp: 'x', paths: [], to: 'x',
acct: 'x', net: {}, keep_days: 0, also: {}, mirror: true, old: 'x', key: 'x', adopt: {}, dry: true, check: true, ok: true, do: 'x', warn: true, days: [],
src_acct: 'x', src_path: 'x', as: 'x', ubus_rpc_session: 'x' },
call: function(req) {
begin();
let W = whoami(req);
if (!W?.own) return werr(W);
let a = req.args ?? {}, act = a.act ?? 'get', Xc = xget(), id = '' + (a.id ?? '');
let Xm = cmig(Xc);
if (Xm) Xc = Xm; else if (act != 'get') return busy();
Xc = adoptfin(Xc); if (!Xc) return busy();
Xc = acctfix(Xc) ?? Xc;
if (act == 'get') return cloudout(Xc, W);
if (act != 'versions' && migrating()) return busy();
let AM = amap(), eacct = () => err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
let aok = (A) => A == null || auser(A) == 'admin' || auser(A) == W.own;
let eacp = () => err('private', 'Cloud personale di un\'altra persona', 'Another person\'s personal cloud');
if ((act == 'set' && (a.kind == 'pull' || match(id, /^p[0-9a-z]{1,16}$/))) || (act != 'set' && act != 'find' && match(id, /^p[0-9a-z]{1,16}$/))) return pullcall(W, a, act, Xc, AM);
if (act == 'find') {
let A = AM['' + (a.acct ?? '')], m = cmod();
if (!A || !m) return eacct();
if (!aok(A)) return eacp();
return m.cloud.call({ args: { act: 'find', id: A.id, ...(W.adm ? {} : { as: W.own }) } });
}
let i = -1; for (let k = 0; k < length(Xc.cloud); k++) if (Xc.cloud[k].id == id && (W.adm || ownof(Xc.cloud[k]) == W.own)) i = k;
if (i >= 0 && W.adm && ownof(Xc.cloud[i]) != 'admin') return err('private', 'Lavoro di un\'altra persona', 'Another person\'s job');
let ps = () => pstop(W.own);
let cmax = () => length(filter(Xc.cloud, (o) => ownof(o) == W.own)) >= CMAX ? err('max', 'Al massimo ' + CMAX + ' copie nel cloud', 'At most ' + CMAX + ' cloud copies') : null;
let shof = (c) => c?.kind == 'backup' ? SH : XSH, nf = () => err('none', 'Sincronizzazione non trovata', 'Sync not found');
let kids = (pid) => filter(Xc.cloud, (o) => length(pid) && o.of == pid);
let ejob = (j, op, c, x) => { mkdirp(JOBS); wjs(JOBS + '/' + j + '.json', { id: j, op: op, name: c.name, done: 0, total: 0, bytes: 0, bytes_total: 0, file: '', state: 'run', t: time(), ...(x ?? {}) }); };
let eready = (c) => {
let P = need('rclone'); if (length(P)) return pkgerr(P);
let pe = ps(); if (pe) return pe;
if (!clinked(c, AM)) return err('link', 'Collega di nuovo l\'account', 'Connect the account again');
if (c.setup === true) return err('setup', 'Prima conferma di aver salvato la Chiave Di Recupero', 'First confirm you saved the Recovery Key');
if (cprog(c.id, c.disk)) return err('run', 'Questa copia è in corso: riprova alla fine', 'This copy is running: try again when it ends');
return null;
};
let cdrop = (c) => {
detach('sh ' + q(shof(c)) + ' cloudstop ' + q(c.id));
for (let e in [ '.sh', '.last', '.bisync', '.vers', '.full', '.about', '.keep', '.keepnext', '.st', '.resync', '.conflicts', '.oldb' ]) unlink(CDIR + '/' + c.id + e);
for (let e in [ '.json', '.last', '.log', '.about', '.full' ]) unlink(X + '/cloud-' + c.id + e);
unlink(X + '/.pw-' + c.id);
};
let csecs = (W, c) => { if (!acctok(c.acct)) W[rcname(c)] = null; if (c.kind == 'backup') W[rcname(c) + 'x'] = null; };
if (act == 'del') {
if (i < 0) return nf();
let c = Xc.cloud[i], K = kids(c.id);
if (c.kind != 'backup' && a.old != 'keep' && a.old != 'del') return err('old', 'Scegli se tenere o cancellare i file tolti nel cloud', 'Choose whether to keep or delete the removed files in the cloud');
for (let o in [ c, ...K ]) if (cbusy(o)) return busy();
let RW = {};
for (let o in [ c, ...K ]) csecs(RW, o);
if (!rcset(RW)) return busy();
for (let o in [ c, ...K ]) cdrop(o);
if (c.kind != 'backup' && a.old == 'del' && acctok(c.acct)) detach('sh ' + q(XSH) + ' oldrm ' + q(c.id) + ' ' + q(c.acct));
for (let o in Xc.cloud) if (length(c.of ?? '') && o.id == c.of) { delete o.also; cwrite(o); }
Xc.cloud = filter(Xc.cloud, (o) => o.id != c.id && o.of != c.id);
let drop = !length(Xc.cloud) && Xc.rclone_mine === true;
if (drop) delete Xc.rclone_mine;
if (!xput(Xc)) return busy();
return { ...cloudout(Xc, W), ...(drop ? { drop: [ 'rclone' ] } : {}) };
}
if (act == 'run' || act == 'stop') {
if (i < 0) return nf();
let c = Xc.cloud[i];
if (act == 'stop') { detach('sh ' + q(shof(c)) + ' cloudstop ' + q(id)); return cloudout(Xc, W); }
let P = need('rclone'); if (length(P)) return pkgerr(P);
if (!nason()) return err('off', 'Il NAS è spento', 'The NAS is off');
let pe = ps(); if (pe) return pe;
if (!clink2(c, AM)) return err('link', 'Collega di nuovo l\'account', 'Connect the account again');
if (c.setup === true) return err('setup', 'Prima conferma di aver salvato la Chiave Di Recupero', 'First confirm you saved the Recovery Key');
if (c.kind == 'backup' && c.crypt && rcsec(rcname(c) + 'x')?.password == null) return err('pass', 'Password Di Crittografia non ancora salvata: riprova fra poco', 'Encryption Password not saved yet: try again shortly');
let d = ccloud(c) ? {} : dsk(disks(), c.disk, c.dir != 'up');
if (d.error) return d;
if (cprog(id, c.disk)) return err('run', 'Questa copia è già in corso', 'This copy is already running');
detach('sh ' + q(c.pc ? SH : shof(c)) + (c.pc ? ' pccloud ' : ' cloud ') + q(id));
return { job: id };
}
if (act == 'keyok') {
if (i < 0) return nf();
for (let o in [ Xc.cloud[i], ...kids(id) ]) if (o.setup === true) { delete o.setup; cwrite(o); }
if (!xput(Xc)) return busy();
return { ...cloudout(Xc, W), ok: true };
}
if (act == 'rekey') {
if (i < 0) return nf();
let c = Xc.cloud[i];
if (c.kind != 'backup' || !c.crypt || c.key2 !== true) return err('rekey', 'Questo backup non ha una Chiave Di Recupero', 'This backup has no Recovery Key');
let K = [ c, ...kids(id) ];
for (let o in K) if (clast(o.id).last > 0 || length(trim(readfile(CDIR + '/' + o.id + '.vers') ?? ''))) return err('rekey', 'Il backup ha già copiato: la chiave non si cambia', 'The backup has already copied: the key cannot change');
let k = newkey();
if (!k) return busy();
for (let o in K) { if (!pwput(o.id, k)) return busy(); o.setup = true; cwrite(o); }
if (!xput(Xc)) return busy();
for (let o in K) detach('sh ' + q(SH) + ' cryptset ' + q(o.id));
return { ...cloudout(Xc, W), ok: true, key: k };
}
if (act == 'dry') {
if (i < 0) return nf();
let c = Xc.cloud[i], f = TMP + '/cloud-dry-' + id + '.json', r = rjs(f), cs = stat(CDIR + '/' + id + '.sh'), now = time();
if (r?.state == 'ok' && now - (r.t ?? 0) < 600 && (r.t ?? 0) >= (cs?.mtime ?? 0)) {
let Ln = rcq('line') ?? {}, n = type(c.net) == 'object' ? c.net : { mode: 'same' }, by = nint(r.bytes);
let gb = n.mode == 'fixed' ? -1 : n.mode == 'own' ? n.gb : Ln.sim?.gb, up = nint(Ln.bw_up) * 1024;
let bf = up > 0 && up < 4000000 ? up : 4000000, bs = up > 0 && up < 1500000 ? up : 1500000, h = (b, v) => int(b * 10.0 / (v * 3600.0) + 0.5) / 10.0;
return { state: 'ok', files: nint(r.files), bytes: by, sim_bytes: gb == null || gb < 0 ? 0 : gb == 0 ? by : (by < gb * 1e9 ? by : int(gb * 1e9)),
hours_fixed: h(by, bf), hours_sim: gb != null && gb < 0 ? 0 : h(by, bs), t: r.t };
}
if (r?.state == 'err' && now - (r.t ?? 0) < 60) return err(r.code ?? 'dry', r.error ?? 'Prova non riuscita', r.error_en ?? 'Test failed');
if (r?.state == 'run' && (alive(r.pid) || (r.pid == null && now - (r.t ?? 0) < 30))) return { state: 'run', t: r.t };
let P = need('rclone'); if (length(P)) return pkgerr(P);
if (c.dir != 'up' && !clinked(c, AM)) return err('link', 'Collega di nuovo l\'account', 'Connect the account again');
let pe = ps(); if (pe) return pe;
let d = dsk(disks(), c.disk, false);
if (d.error) return d;
wjs(f, { state: 'run', t: now });
detach('sh ' + q(shof(c)) + ' clouddry ' + q(id));
return { state: 'run', t: now };
}
if (act == 'check') {
if (i < 0) return nf();
let c = Xc.cloud[i], dw = '' + (a.do ?? '');
if (!match(dw, /^(key|full)$/)) return err('act', 'Azione sconosciuta', 'Unknown action');
if (c.kind != 'backup' || !c.crypt) return err('check', 'Solo per i backup crittografati', 'Only for encrypted backups');
let e = eready(c); if (e) return e;
let j = 'bak-c' + rid();
ejob(j, 'check', c, { do: dw });
detach('sh ' + q(SH) + ' verify ' + q(id) + ' ' + dw + ' ' + q(j));
return { job: j };
}
if (act == 'resync') {
if (i < 0) return nf();
let c = Xc.cloud[i];
if (c.dir != 'both') return err('dir', 'Solo per Nei Due Sensi', 'Only for Both Ways');
let e = eready(c); if (e) return e;
let d = dsk(disks(), c.disk, true);
if (d.error) return d;
let f = X + '/cloud-' + id + '.dry.json', r = rjs(f), now = time();
if (a.ok === true) {
unlink(f);
detach('sh ' + q(XSH) + ' resync ' + q(id) + ' ok');
return { job: id };
}
if (r?.state == 'ok' && now - (r.t ?? 0) < 600) return { state: 'ok', dry: true, files: nint(r.files), bytes: nint(r.bytes), conflicts: nint(r.conflicts), t: r.t };
if (match(r?.state ?? '', /^(run|wait)$/) && (alive(r.pid) || (!alive(r.pid) && now - (r.t ?? 0) < 30))) return { state: r.state, t: r.t, ...(length(r.why_t ?? '') ? { why: r.why_t, why_en: r.why_en ?? r.why_t } : {}) };
if (r?.state == 'err' && now - (r.t ?? 0) < 60) return err('resync', length(r.err ?? '') ? r.err : 'Prova non riuscita', length(r.err_en ?? '') ? r.err_en : 'Test failed');
wjs(f, { state: 'run', t: now });
detach('sh ' + q(XSH) + ' resync ' + q(id) + ' dry');
return { state: 'run', t: now };
}
if (act == 'free') {
if (i < 0) return nf();
let c = Xc.cloud[i], kd = a.keep_days;
if (c.kind != 'backup') return err('remote', 'Sincronizzazione Cloud: niente versioni', 'Cloud Sync: no versions');
if (type(kd) != 'int' || kd < 1 || kd > 3650) return err('keep', 'Giorni non validi', 'Invalid days');
let e = eready(c); if (e) return e;
let j = 'bak-f' + rid();
ejob(j, 'free', c, { keep_days: kd });
detach('sh ' + q(SH) + ' cloudfree ' + q(id) + ' ' + kd + ' ' + q(j));
return { job: j };
}
if (act == 'versions' || act == 'restore' || act == 'browse') {
if (i < 0) return err('none', 'Backup non trovato', 'Backup not found');
let c = Xc.cloud[i];
if (c.kind != 'backup') return err('remote', 'Sincronizzazione Cloud: niente copie da ripristinare', 'Cloud Sync: no copies to restore');
let s = clast(id), V = sort(filter(split(readfile(CDIR + '/' + id + '.vers') ?? '', '\n'), (v) => match(v, STAMP) != null));
let cur = s.ok === true || length(V) > 0, FU = {};
for (let v in split(readfile(X + '/cloud-' + id + '.full') ?? readfile(CDIR + '/' + id + '.full') ?? '', '\n')) if (match(v, STAMP)) FU[v] = true;
if (act == 'versions') {
let r = map(reverse(V), (v) => ({ stamp: v, t: stampt(v), kind: 'day', full: FU[v] === true }));
if (cur) unshift(r, { stamp: 'current', t: s.ok === true ? s.last : 0, kind: 'mirror' });
return { list: r, disk: '', path: '' };
}
let P = need('rclone'); if (length(P)) return pkgerr(P);
if (!clinked(c, AM)) return err('link', 'Collega di nuovo l\'account', 'Connect the account again');
if (c.crypt && rcsec(rcname(c) + 'x')?.password == null) return err('pass', 'Password Di Crittografia non ancora salvata: riprova fra poco', 'Encryption Password not saved yet: try again shortly');
let sp = '' + (a.stamp ?? 'current');
if (!((sp == 'current' && cur) || index(V, sp) >= 0)) return err('stamp', 'Versione non trovata', 'Version not found');
if (act == 'browse') {
let bp = relok(a.path ?? '/');
if (bp == null) return err('path', 'Percorso non valido', 'Invalid path');
let rq = 'b' + substr(hk(id + '|' + sp + '|' + bp), 0, 14), rf = X + '/browse-' + rq + '.json', qf = X + '/browse-' + rq + '.req', rs = stat(rf), now = time();
if (rs && now - rs.mtime <= 60 && rs.mtime <= now + 60) {
let o = rjs(rf);
if (type(o?.error) == 'string') return err(o.code ?? 'browse', o.error, o.error_en ?? o.error);
if (type(o) == 'object') return { items: map(filter(type(o.items) == 'array' ? o.items : [], (x) => type(x) == 'object' && type(x.name) == 'string'),
(x) => ({ name: x.name, dir: x.dir === true, size: nint(x.size), mtime: nint(x.mtime) })), path: bp, stamp: sp };
}
let qs = stat(qf);
if (!qs || now - qs.mtime > 120 || qs.mtime > now + 60) {
unlink(rf);
wjs(qf, { id: id, stamp: sp, path: bp, t: now });
detach('sh ' + q(SH) + ' browse ' + q(rq));
}
return { pending: rq };
}
let pe = ps(); if (pe) return pe;
let D = disks(), sd = dsk(D, c.disk, true);
if (sd.error) return sd;
let to = '' + (a.to ?? 'orig'), tb = sd.mnt;
if (to != 'orig') { let r2 = relok(to); if (r2 == null || !absof(D, sd.id, r2)) return err('to', 'Cartella di arrivo non valida', 'Invalid destination folder'); tb = absof(D, sd.id, r2); }
if (!W.adm) { let te = csrcok(W, D, nget(), sd, to == 'orig' ? relok(c.path) ?? '/' : relok(to)); if (te) return te; }
let base = relok(c.path) ?? '/', PS = type(a.paths) == 'array' && length(a.paths) ? a.paths : [ base ], lines = [];
if (length(PS) > 500) return err('max', 'Al massimo 500 file per volta', 'At most 500 files at a time');
for (let p in PS) {
p = relok(p);
if (p == null || (base != '/' && p != base && index(p, base + '/') != 0)) return err('path', 'Percorso non valido', 'Invalid path');
let rel = base == '/' ? p : substr(p, length(base));
if (rel == '/' || rel == '') rel = '';
if (relp(rel) == null) return err('path', 'Percorso non valido', 'Invalid path');
let dst = tb + (p == '/' ? '' : p);
if (!inside(sd.mnt, p == '/' ? dst : dirof(dst))) return err('to', 'Cartella di arrivo non valida', 'Invalid destination folder');
push(lines, (sp == 'current' ? 'current' : (FU[sp] ? 'day/' : 'old/') + sp) + rel + '\t' + dst);
}
if (cprog(id, c.disk)) return err('run', 'Questa copia è in corso: riprova alla fine', 'This copy is running: try again when it ends');
let j = 'bak-r' + rid();
mkdirp(JOBS);
writefile(JOBS + '/' + j + '.list', join('\n', lines) + '\n');
wjs(JOBS + '/' + j + '.json', { id: j, op: 'restore', name: c.name, done: 0, total: 0, bytes: 0, bytes_total: 0, file: '', state: 'run', t: time(), root: rpath(sd.mnt) ?? sd.mnt });
detach('sh ' + q(SH) + ' cloudrestore ' + q(j) + ' ' + q(id));
return { job: j };
}
if (act == 'adopt') {
let ad = type(a.adopt) == 'object' ? a.adopt : {}, A = AM['' + (ad.acct ?? '')];
if (!A) return eacct();
if (!aok(A)) return eacp();
if (cmax()) return cmax();
let rp = relp('' + (ad.remote ?? '')), rin = (P) => P != null && length(rp) > length(P) && join('/', slice(rp, 0, length(P))) == join('/', P);
let rok = W.adm ? rp != null && (rin(relp(BKOLD)) || rin([ 'WrtFreedom', 'Backup' ]) || rin(relp(BKROOT))) : rp != null && croot(W.own, true) != null && rin(relp(croot(W.own, true)));
if (!rok || length('' + ad.remote) > 512) return err('remote', 'Backup non trovato nel cloud', 'Backup not found in the cloud');
let ky = '' + (ad.key ?? '');
if (length(ky) < 8 || length(ky) > 128 || match(ky, /[[:cntrl:]]/)) return err('key', 'La chiave non apre questo backup', 'The key does not open this backup');
let rm = '/' + join('/', rp);
for (let o in Xc.cloud) if (o.acct == A.id && lc(o.remote) == lc(rm)) return err('adopt', 'Questo backup è già sul router: «' + o.name + '»', 'This backup is already on the router: «' + o.name + '»');
let D = disks(), d = dsk(D, '' + (a.disk ?? ''), false);
if (d.error) return d;
let lp = absp(d, a.path ?? '/');
if (!lp) return err('path', 'Cartella non valida', 'Invalid folder');
let se = csrcok(W, D, nget(), d, lp.rel); if (se) return se;
if (stat(lp.abs)?.type != 'directory') return err('path', 'La cartella non esiste', 'The folder does not exist');
let nm = trim('' + (a.name ?? rp[length(rp) - 1]));
if (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/)) return err('name', 'Nome non valido', 'Invalid name');
let P = need('rclone'); if (length(P)) return pkgerr(P);
let c = { id: 'k' + rid(), name: nm, provider: A.svc, disk: d.id, path: lp.rel, remote: rm, dir: 'up', at: '04:10', every: 0, on: true, t: time(),
kind: 'backup', crypt: true, acct: A.id, net: { mode: 'same' }, keep_days: wasabi(A) ? 90 : 30, key2: true, adopt: true, ...(W.adm ? {} : { own: W.own }) };
let o = cclash(Xc.cloud, c);
if (o) return err('remote', 'Cartella del cloud già usata da «' + o.name + '»: scegline un\'altra', 'Cloud folder already used by «' + o.name + '»: choose another one');
if (!pwput(c.id, ky)) return busy();
push(Xc.cloud, c); if (!xput(Xc)) return busy(); cwrite(c);
detach('sh ' + q(SH) + ' adopt ' + q(c.id));
return { ...cloudout(Xc, W), id: c.id, ok: true };
}
if (act == 'auth') {
if (!W.adm) return eadm();
if (i < 0 && length(id)) return nf();
if (i >= 0 && acctok(Xc.cloud[i].acct)) return err('acct', 'Ricollega l\'account nella sezione Cloud', 'Reconnect the account in the Cloud section');
let tk = tokof(a.token ?? '');
if (!tk) return err('token', 'Collegamento non valido: riprova', 'Invalid connection: try again');
if (i < 0) {
let pv = '' + (a.provider ?? '');
if (!PROV[pv]) return err('provider', 'Servizio cloud non valido', 'Invalid cloud service');
let e = linkchk(a, pv, null); if (e) return e;
let o = { t: time(), token: tk };
for (let k in [ 'drive_id', 'drive_type', 'client_id', 'client_secret' ]) if (a[k] != null) o[k] = '' + a[k];
if (!tokput(pv, o)) return err('write', 'Collegamento non salvato: riprova', 'Connection not saved: try again');
return { ...cloudout(Xc, W), pending: pv };
}
let c = Xc.cloud[i];
let e = linkchk(a, c.provider, tk); if (e) return e;
let o = rcsec(rcname(c)) ?? {};
if (rcbusy(rcname(c))) return busy();
if (!rcset1(rcname(c), rclink(c, { drive_id: a.drive_id ?? o.drive_id, drive_type: a.drive_type ?? o.drive_type, client_id: a.client_id ?? o.client_id, client_secret: a.client_secret ?? o.client_secret }, tk))) return busy();
unlink(CDIR + '/' + c.id + '.bisync');
return cloudout(Xc, W);
}
if (act != 'set') return err('act', 'Azione sconosciuta', 'Unknown action');
if (!W.adm) {
if (a.token != null || a.acct == null && i < 0) return eacct();
if (exists(a, 'also') && a.also != null) return eadm();
if (a.net != null && netok(a.net)?.mode != 'same') return eadm();
}
let old = i >= 0 ? Xc.cloud[i] : null, isnew = old == null;
let kind = '' + (a.kind ?? old?.kind ?? 'sync');
if (!match(kind, /^(sync|backup)$/)) return err('kind', 'Tipo non valido', 'Invalid type');
if (old && kind != (old.kind ?? 'sync')) return err('kind', 'Il tipo non si cambia: crea un nuovo backup', 'The type cannot change: create a new backup');
let bk = kind == 'backup';
if (old?.of) return err('also', 'Si cambia dal backup principale', 'Change it from the main backup');
if (isnew && cmax()) return cmax();
let A = null;
if (a.acct != null) {
A = AM['' + a.acct];
if (!A) return eacct();
if (old && old.provider != A.svc) return err('acct', 'L\'account si cambia solo con uno dello stesso servizio', 'The account can only change to one of the same service');
}
else if (old && acctok(old.acct) && a.token == null && (a.provider == null || '' + a.provider == old.provider)) A = AM[old.acct] ?? { id: old.acct, svc: old.provider };
else if (isnew && a.provider == null && a.token == null) return eacct();
if (!aok(A)) return eacp();
if (!W.adm && !A) return eacct();
let pv = A ? A.svc : '' + (a.provider ?? old?.provider ?? '');
if (!A && !PROV[pv]) return err('provider', 'Servizio cloud non valido', 'Invalid cloud service');
let tk = null, ta = a, tok = null;
if (A) ta = {};
else if (a.token != null) { tk = tokof(a.token); if (!tk) return err('token', 'Collegamento non valido: riprova', 'Invalid connection: try again'); }
else if (isnew || pv != old.provider || acctok(old.acct)) {
tok = tokget(pv);
if (!tok) return err('token', isnew ? 'Collega prima l\'account' : 'Collega l\'account del nuovo servizio', isnew ? 'Connect the account first' : 'Connect the account of the new service');
tk = tok.token; ta = { ...a };
for (let k in [ 'drive_id', 'drive_type', 'client_id', 'client_secret' ]) if (ta[k] == null && tok[k] != null) ta[k] = tok[k];
}
if (!A) { let le = linkchk(ta, pv, tk); if (le) return le; }
let D = disks(), dk = '' + (a.disk ?? old?.disk ?? ''), dir = bk ? 'up' : '' + (a.dir ?? old?.dir ?? 'up');
if (!match(dir, /^(up|down|both)$/)) return err('dir', 'Verso non valido', 'Invalid direction');
let SA = null, sp = null, sau = bk ? '' : exists(a, 'src_acct') ? '' + (a.src_acct ?? '') : '' + (old?.sacct ?? '');
if (old && !bk && (length(sau) > 0) != acctok(old.sacct))
return err('kind', 'La partenza non si cambia: crea una nuova sincronizzazione', 'The source cannot change: create a new sync');
if (length(sau)) {
SA = AM[sau];
if (!SA || !A || SA.id == A.id) return err('acct', 'Scegli un altro account di partenza', 'Choose another source account');
if (!aok(SA)) return eacp();
if (dir != 'up') return err('dir', 'Fra due cloud solo da uno all\'altro', 'Between two clouds only one way');
let sv = '' + (exists(a, 'src_path') ? (a.src_path ?? '/') : (old?.spath ?? '/')), sr = relp(sv);
if (sr == null || length(sv) > 512) return err('path', 'Cartella di partenza non valida', 'Invalid source folder');
sp = '/' + join('/', sr);
if (auser(SA) == 'admin') {
let ur = ud(W.adm ? 'admin' : W.own, 'root'), uu = replace(ur ?? '', /\/[^\/]*$/, '');
if (!W.adm && !under(sp, ur) && !under(sp, ud('shared', 'root'))) return errp();
if (W.adm && length(uu) && (pin(uu, sp) || under(sp, uu)) && !under(sp, ur)) return errp();
}
if (cmapx(SA.id, sp)?.wait) return err('wait', 'Cartella in cifratura: riprova fra poco', 'Folder being encrypted: try again shortly');
}
let d = SA ? { id: '', name: SA.name } : dsk(D, dk, dir != 'up');
if (d.error) return d;
let lp = SA ? { rel: '', abs: '' } : absp(d, a.path ?? old?.path ?? '/');
if (!lp) return err('path', 'Cartella non valida', 'Invalid folder');
if (!SA) {
let se = csrcok(W, D, nget(), d, lp.rel); if (se) return se;
if (stat(lp.abs)?.type != 'directory') return err('path', 'La cartella non esiste', 'The folder does not exist');
}
let ph = isnew && !bk && !SA && dir == 'up' && type(req.wfph) == 'string' && lc(req.wfph) == lc('/' + join('/', relp(lp.rel) ?? [])) ? req.wfph : null;
if (A && !bk && !SA && ph == null && (isnew || old.disk != d.id || old.path != lp.rel)) {
let by = bkdir(Xc, d.id, lp.rel, old?.id, W.adm ? null : W.own);
if (by) return err('bkdir', 'Usata da un backup: non si sceglie', 'Used by a backup: it cannot be chosen', { by: by });
}
let root = croot(W.own, bk);
if (root == null) return errp();
let rm = '' + (old?.remote ?? root);
let rp = relp(rm);
if (rp == null || length(rm) > 512) return err('remote', 'Cartella del cloud non valida', 'Invalid cloud folder');
let at = '' + (a.at ?? old?.at ?? (bk && isnew && a.every == null ? '04:10' : '')), every = a.every ?? old?.every ?? 0;
if (length(at) && !match(at, /^([01][0-9]|2[0-3]):[0-5][0-9]$/)) return err('at', 'Orario non valido', 'Invalid time');
if (type(every) != 'int' || every < 0 || every > 1440 || (every > 0 && (every < 15 || every % 5))) return err('every', 'Ogni quanti minuti: da 15 a 1440, a passi di 5', 'Every how many minutes: 15 to 1440, in steps of 5');
if (length(at) && every > 0) return err('when', 'Scegli un orario oppure ogni quanti minuti', 'Choose a time or every how many minutes');
if (a.days != null && type(a.days) != 'array') return err('days', 'Giorni non validi', 'Invalid days');
let dys = length(at) ? daysof(a.days ?? old?.days) : null;
let crypt = bk ? (type(a.crypt) == 'bool' ? a.crypt : (old?.crypt ?? true)) : false, pw = null, gen = false;
if (bk && old && crypt != (old.crypt === true)) return err('crypt', 'La crittografia non si cambia: crea un nuovo backup', 'Encryption cannot change: create a new backup');
if (crypt && a.pass != null) {
if (old?.crypt) return err('pass', 'La Password Di Crittografia non si cambia', 'The Encryption Password cannot change');
pw = '' + a.pass;
if (length(pw) < 8 || length(pw) > 128 || match(pw, /[[:cntrl:]]/)) return err('pass', 'Password da 8 a 128 caratteri', 'Password from 8 to 128 characters');
}
else if (crypt && isnew && A) { pw = newkey(); gen = true; if (!pw) return busy(); }
else if (crypt && isnew) return err('pass', 'Scegli la Password Di Crittografia', 'Choose the Encryption Password');
let kd = bk ? (old?.keep_days ?? (A && wasabi(A) ? 90 : 30)) : null;
if (bk && a.keep_days != null) {
if (index([ 7, 30, 90, 365 ], a.keep_days) < 0) return err('keep', 'Tieni Per: 7, 30, 90 o 365 giorni', 'Keep For: 7, 30, 90 or 365 days');
if (A && wasabi(A) && a.keep_days < 90) return err('keep', 'Wasabi tiene i file almeno 90 giorni', 'Wasabi keeps files at least 90 days');
kd = a.keep_days;
}
let net = type(old?.net) == 'object' ? old.net : { mode: 'same' };
if (a.net != null) { net = netok(a.net); if (!net) return err('net', 'Rete Da Usare non valida', 'Invalid Network To Use'); }
let on = type(a.on) == 'bool' ? a.on : (old?.on ?? true);
let wn = type(a.warn) == 'bool' ? a.warn : old?.warn !== false;
if (on) { let P = need('rclone'); if (length(P)) { if (Xc.rclone_req !== true) { Xc.rclone_req = true; if (!xput(Xc)) return busy(); } return pkgerr(P); } }
let sname = PROV[pv] ?? A?.svc_name ?? pv;
let lq = filter(split(SA ? sp : lp.rel, '/'), (x) => length(x)), lf = length(lq) ? lq[length(lq) - 1] : d.name ?? 'Disco';
let nm = trim('' + (a.name ?? old?.name ?? (bk ? cutb(replace(lf, /[[:cntrl:]\\]/g, '_'), 40) : sname + ' ' + lf)));
if (!match(nm, /^[^[:cntrl:]\/\\]{1,40}$/)) return err('name', 'Nome non valido', 'Invalid name');
let c = { id: old?.id ?? ((bk ? 'k' : 'c') + rid()), name: nm, provider: pv, disk: d.id, path: lp.rel, remote: '/' + join('/', rp), dir: dir, at: at, ...(dys ? { days: dys } : {}), every: every, on: on,
t: old?.t ?? time(), ...(bk ? { kind: 'backup', crypt: crypt, keep_days: kd, check_m: type(a.check) == 'bool' ? a.check : old?.check_m === true } :
{ mirror: type(a.mirror) == 'bool' ? a.mirror : (old ? old.mirror !== false : !A) }),
...(old?.prev_remote ? { prev_remote: old.prev_remote } : {}), net: net, warn: wn, ...(W.adm ? {} : { own: W.own }),
...(SA ? { sacct: SA.id, spath: sp } : {}) };
for (let k in [ 'also', 'key2', 'setup', 'adopt', 'pc' ]) if (old?.[k] != null) c[k] = old[k];
if (A) c.acct = A.id;
if (crypt && A && pw != null) { c.key2 = true; c.setup = true; }
drvload(Xc.cloud);
let did = !A && pv == 'onedrive' ? (ta.drive_id ?? (old && old.provider == pv ? cdrive(old) : null)) : null;
if (isnew) c.remote = ph ?? cfree(Xc.cloud, c, did, root);
let o = isnew || pv != old.provider || c.acct != old.acct || lc(c.remote) != lc(old.remote) || (on && old.on !== true) ? cclash(Xc.cloud, c, did) : null;
DRV = null;
if (o) return err('remote', 'Cartella del cloud già usata da «' + o.name + '»: scegline un\'altra', 'Cloud folder already used by «' + o.name + '»: choose another one');
let OK = kids(c.id), ch = null, chW = {}, alu = exists(a, 'also');
if (alu && type(a.also) == 'object' && length('' + (a.also.acct ?? ''))) {
let A2 = AM['' + a.also.acct];
if (!bk || !A2 || A2.id == c.acct) return err('also', 'Scegli un altro account per Copia Anche Su', 'Choose another account for Also Copy To');
let need2 = clast(c.id).bytes;
if ((A2.total ?? 0) > 0 && (A2.free ?? 0) < need2) return err('also', 'Spazio non sufficiente su ' + A2.name, 'Not enough space on ' + A2.name);
ch = { id: OK[0]?.acct == A2.id ? OK[0].id : 'k' + rid(), name: nm, provider: A2.svc, disk: c.disk, path: c.path, remote: '', dir: 'up', at: at, ...(dys ? { days: dys } : {}), every: every, on: on, t: OK[0]?.acct == A2.id ? OK[0].t : time(),
kind: 'backup', crypt: crypt, acct: A2.id, net: net, keep_days: A2 && wasabi(A2) && kd < 90 ? 90 : kd, key2: c.key2 === true, of: c.id, check_m: c.check_m, warn: wn };
let rest = filter(Xc.cloud, (x) => x.id != c.id && x.id != ch.id);
if (a.also.remote != null) {
let r2 = relp('' + a.also.remote);
if (r2 == null || length('' + a.also.remote) > 512) return err('remote', 'Cartella del cloud non valida', 'Invalid cloud folder');
ch.remote = '/' + join('/', r2);
}
else if (OK[0]?.acct == A2.id) ch.remote = OK[0].remote;
else ch.remote = cfree(rest, ch);
let o2 = cclash(rest, ch);
if (o2) return err('remote', 'Cartella del cloud già usata da «' + o2.name + '»: scegline un\'altra', 'Cloud folder already used by «' + o2.name + '»: choose another one');
if (crypt && pw == null && (OK[0]?.acct != A2.id || OK[0]?.remote != ch.remote)) {
let ps = rcsec(rcname(c) + 'x');
if (ps?.password == null) return err('pass', 'Password Di Crittografia non ancora salvata: riprova fra poco', 'Encryption Password not saved yet: try again shortly');
chW[rcname(ch) + 'x'] = { ...ps, remote: asec(ch) + ':' + substr(ch.remote, 1) };
}
if (c.setup === true) ch.setup = true;
}
let drop = !alu ? [] : ch == null ? OK : filter(OK, (x) => x.id != ch.id);
let RW = { ...chW }, cs = crypt && old && (old.remote != c.remote || old.acct != c.acct) ? cryptrem(c) : null;
if (tk) RW[rcname(c)] = rclink(c, ta, tk);
if (cs) RW[rcname(c) + 'x'] = cs;
for (let x in drop) { if (cbusy(x)) return busy(); csecs(RW, x); }
if (tk && old && rcbusy(rcname(c))) return busy();
if (length(RW) && !rcset(RW)) return busy();
if (tk || (old && (old.dir != dir || old.path != c.path || old.remote != c.remote || old.disk != c.disk || old.acct != c.acct))) unlink(CDIR + '/' + c.id + '.bisync');
if (tok) unlink(tokf(pv));
if (Xc.rclone_req === true && !length(need('rclone'))) { Xc.rclone_mine = true; delete Xc.rclone_req; }
for (let x in drop) cdrop(x);
Xc.cloud = filter(Xc.cloud, (x) => index(map(drop, (y) => y.id), x.id) < 0);
if (ch) c.also = ch.id; else if (alu) delete c.also;
let ci = -1; for (let k = 0; k < length(Xc.cloud); k++) if (Xc.cloud[k].id == c.id) ci = k;
if (ci >= 0) Xc.cloud[ci] = c; else push(Xc.cloud, c);
if (ch) { let hi = -1; for (let k = 0; k < length(Xc.cloud); k++) if (Xc.cloud[k].id == ch.id) hi = k; if (hi >= 0) Xc.cloud[hi] = ch; else push(Xc.cloud, ch); }
for (let x in Xc.cloud) if (x.of == c.id && x.id != ch?.id) { x.disk = c.disk; x.path = c.path; x.at = at; if (dys) x.days = dys; else delete x.days; x.every = every; x.on = on; x.net = net; x.name = nm; x.keep_days = kd; x.warn = wn; cwrite(x); }
if (!xput(Xc)) return busy(); cwrite(c); if (ch) cwrite(ch);
if (pw != null) {
for (let x in [ c, ...(ch ? [ ch ] : []) ]) if (pwput(x.id, pw)) detach('sh ' + q(SH) + ' cryptset ' + q(x.id));
}
return { ...cloudout(Xc, W), id: c.id, ...(gen ? { key: pw } : {}) };
}
},
nas_protect: {
args: {},
call: function(req) {
begin();
let W = whoami(req);
if (!W?.own) return werr(W);
if (!W.adm) return eadm();
return protadm(protect());
}
},
nas_remind: {
args: { mac: 'x' },
call: function(req) {
begin();
let mac = lc('' + (req.args?.mac ?? ''));
if (!macok(mac)) return err('mac', 'Indirizzo MAC non valido', 'Invalid MAC address');
let P = persons(), pe = personof(P, mac), Xc = xget(), RM = reminds(), now = time();
if (RM[mac] && now - RM[mac].t < 600) return err('wait', 'Avviso già mandato da poco', 'Reminder already sent a moment ago');
let pr = protect(), dv = null;
for (let d in alldevs(pr)) if (d.mac == mac) dv = d;
if (dv && (dv.own ?? 'admin') != 'admin') return err('private', 'Dispositivo di un\'altra persona', 'Another person\'s device');
let who = pe?.name ?? dv?.name ?? mac;
let app = false;
for (let id, p in Xc.photo.phones) { let m = phmac(id, p); if (p.auto === true && (m == mac || (pe && index(pe.macs, m) >= 0))) app = true; }
let dd = dv && dv.days >= 0 ? dv.days : -1;
let lc_ = dd < 0 ? L('Nessuna copia', 'No copy') : L('Ultima copia ' + dd + (dd == 1 ? ' giorno fa' : ' giorni fa'), 'Last copy ' + dd + (dd == 1 ? ' day ago' : ' days ago'));
let txt = L('📱 Backup ¦ Ricorda a ' + who + ' ¦ ', '📱 Backup ¦ Reminder for ' + who + ' ¦ ') + lc_;
RM[mac] = { t: now, to: app ? 'app' : 'tg' };
for (let k, v in RM) if (now - v.t > 3 * DAY) delete RM[k];
wjs(X + '/remind.json', RM);
ev('nas_remind', txt, !app);
return { ok: true, to: app ? 'app' : 'tg', name: who };
}
},
bktick: bktick,
phmove: phmove,
phren: phren,
phdate: function(f, nm) { let r = type(f) == 'string' ? phdate(f, nm) : null; return r ? r.y + ' ' + r.m : ''; },
phtidy: phtidy,
phwdirs: phwdirs,
phwtops: phwtops,
phfileq: phfileq,
phdav: phdav,
phdavls: phdavls,
phdavcl: phdavcl,
phdavdir: function(own) { begin(); let B = phdavbase(own); if (!B || B.d.ro) return null; mkdirp(B.abs); return stat(B.abs)?.type == 'directory' ? B.abs : null; },
bkprune: function(id) { let r = bkprune(id); bkown(); return r; },
bkown: function() { begin(); return bkown(); },
rcset: rcset,
pstop: pstop,
pcqf: pcqf,
bkudel: function(u) {
if (type(u) != 'string' || !match(u, /^[a-z][a-z0-9]{0,19}$/) || u == 'admin' || u == 'shared') return err('user', 'Persona non valida', 'Invalid person');
let n = 0, done = {};
for (let k = 0; k < 80; k++) {
let c = null, X1 = xget();
for (let o in [ ...(X1.cloud ?? []), ...plist(X1) ]) if (ownof(o) == u && !done[o.id]) { c = o; break; }
if (!c) break;
done[c.id] = true;
let r = ME.nas_cloud.call({ wfown: u, args: { act: 'del', id: c.id, old: 'keep' } });
if (r?.error) return { ...r, n: n };
n++;
}
if (n) bkownbg();
return { n: n };
}
};
ME = M;
const BKCHG = { set: 1, del: 1, adv: 1, run: 1, stop: 1, keyok: 1, rekey: 1, adopt: 1, restore: 1, pcalso: 1 };
for (let k in [ 'nas_backup', 'nas_photo', 'nas_cloud' ]) {
let f = M[k].call;
M[k].call = function(req) {
let r = f(req), a = req?.args ?? {}, act = '' + (a.act ?? 'get');
if (type(r) != 'object' || r.error != null || req?.wfown != null || req?.wfph != null) return r;
if (BKCHG[act] || (k == 'nas_photo' && act == 'put' && a.last === true && time() - (stat(BKOWN)?.mtime ?? 0) >= 60)) bkownbg();
return r;
};
}

return M;
