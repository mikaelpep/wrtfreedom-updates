'use strict';
import { open, popen, readfile, unlink, rename } from 'fs';

const M = 0xffffffff, MAG = 'WFBAK1 ', HL = 140, MO = 75, CNT = 16777216, CMIN = 65536, CMAX = 67108864, CH = 65536;
const TD = getenv('WF_BAKTMP') ?? '/tmp';
let ST = null;
if (getenv('WF_BAKNOST') != '1') try { ST = require('struct'); } catch (e) { ST = null; }
let ZB = '', ZH = '';
for (let i = 0; i < 64; i++) { ZB += chr(0); ZH += '00'; }

function le(h, i) { i *= 2; return hex(substr(h, i + 6, 2) + substr(h, i + 4, 2) + substr(h, i + 2, 2) + substr(h, i, 2)); }
function sw(w) { return ((w & 0xff) << 24) | ((w & 0xff00) << 8) | ((w >> 8) & 0xff00) | (w >> 24); }
function blk(k, c, n, d, i, o) {
let x0 = 0x61707865, x1 = 0x3320646e, x2 = 0x79622d32, x3 = 0x6b206574, x4 = k[0], x5 = k[1], x6 = k[2], x7 = k[3],
x8 = k[4], x9 = k[5], x10 = k[6], x11 = k[7], x12 = c, x13 = n[0], x14 = n[1], x15 = n[2];
for (let r = 0; r < 10; r++) {
x0 = (x0 + x4) & M; x12 ^= x0; x12 = ((x12 << 16) | (x12 >> 16)) & M; x8 = (x8 + x12) & M; x4 ^= x8; x4 = ((x4 << 12) | (x4 >> 20)) & M;
x0 = (x0 + x4) & M; x12 ^= x0; x12 = ((x12 << 8) | (x12 >> 24)) & M; x8 = (x8 + x12) & M; x4 ^= x8; x4 = ((x4 << 7) | (x4 >> 25)) & M;
x1 = (x1 + x5) & M; x13 ^= x1; x13 = ((x13 << 16) | (x13 >> 16)) & M; x9 = (x9 + x13) & M; x5 ^= x9; x5 = ((x5 << 12) | (x5 >> 20)) & M;
x1 = (x1 + x5) & M; x13 ^= x1; x13 = ((x13 << 8) | (x13 >> 24)) & M; x9 = (x9 + x13) & M; x5 ^= x9; x5 = ((x5 << 7) | (x5 >> 25)) & M;
x2 = (x2 + x6) & M; x14 ^= x2; x14 = ((x14 << 16) | (x14 >> 16)) & M; x10 = (x10 + x14) & M; x6 ^= x10; x6 = ((x6 << 12) | (x6 >> 20)) & M;
x2 = (x2 + x6) & M; x14 ^= x2; x14 = ((x14 << 8) | (x14 >> 24)) & M; x10 = (x10 + x14) & M; x6 ^= x10; x6 = ((x6 << 7) | (x6 >> 25)) & M;
x3 = (x3 + x7) & M; x15 ^= x3; x15 = ((x15 << 16) | (x15 >> 16)) & M; x11 = (x11 + x15) & M; x7 ^= x11; x7 = ((x7 << 12) | (x7 >> 20)) & M;
x3 = (x3 + x7) & M; x15 ^= x3; x15 = ((x15 << 8) | (x15 >> 24)) & M; x11 = (x11 + x15) & M; x7 ^= x11; x7 = ((x7 << 7) | (x7 >> 25)) & M;
x0 = (x0 + x5) & M; x15 ^= x0; x15 = ((x15 << 16) | (x15 >> 16)) & M; x10 = (x10 + x15) & M; x5 ^= x10; x5 = ((x5 << 12) | (x5 >> 20)) & M;
x0 = (x0 + x5) & M; x15 ^= x0; x15 = ((x15 << 8) | (x15 >> 24)) & M; x10 = (x10 + x15) & M; x5 ^= x10; x5 = ((x5 << 7) | (x5 >> 25)) & M;
x1 = (x1 + x6) & M; x12 ^= x1; x12 = ((x12 << 16) | (x12 >> 16)) & M; x11 = (x11 + x12) & M; x6 ^= x11; x6 = ((x6 << 12) | (x6 >> 20)) & M;
x1 = (x1 + x6) & M; x12 ^= x1; x12 = ((x12 << 8) | (x12 >> 24)) & M; x11 = (x11 + x12) & M; x6 ^= x11; x6 = ((x6 << 7) | (x6 >> 25)) & M;
x2 = (x2 + x7) & M; x13 ^= x2; x13 = ((x13 << 16) | (x13 >> 16)) & M; x8 = (x8 + x13) & M; x7 ^= x8; x7 = ((x7 << 12) | (x7 >> 20)) & M;
x2 = (x2 + x7) & M; x13 ^= x2; x13 = ((x13 << 8) | (x13 >> 24)) & M; x8 = (x8 + x13) & M; x7 ^= x8; x7 = ((x7 << 7) | (x7 >> 25)) & M;
x3 = (x3 + x4) & M; x14 ^= x3; x14 = ((x14 << 16) | (x14 >> 16)) & M; x9 = (x9 + x14) & M; x4 ^= x9; x4 = ((x4 << 12) | (x4 >> 20)) & M;
x3 = (x3 + x4) & M; x14 ^= x3; x14 = ((x14 << 8) | (x14 >> 24)) & M; x9 = (x9 + x14) & M; x4 ^= x9; x4 = ((x4 << 7) | (x4 >> 25)) & M;
}
push(o, ((x0 + 0x61707865) & M) ^ d[i], ((x1 + 0x3320646e) & M) ^ d[i + 1], ((x2 + 0x79622d32) & M) ^ d[i + 2],
((x3 + 0x6b206574) & M) ^ d[i + 3], ((x4 + k[0]) & M) ^ d[i + 4], ((x5 + k[1]) & M) ^ d[i + 5], ((x6 + k[2]) & M) ^ d[i + 6],
((x7 + k[3]) & M) ^ d[i + 7], ((x8 + k[4]) & M) ^ d[i + 8], ((x9 + k[5]) & M) ^ d[i + 9], ((x10 + k[6]) & M) ^ d[i + 10],
((x11 + k[7]) & M) ^ d[i + 11], ((x12 + c) & M) ^ d[i + 12], ((x13 + n[0]) & M) ^ d[i + 13], ((x14 + n[1]) & M) ^ d[i + 14],
((x15 + n[2]) & M) ^ d[i + 15]);
}
function xorc(k, n, c, s) {
let L = length(s), Z = (64 - L % 64) % 64, W = (L + Z) >> 2, d = [], o = [];
if (ST) d = ST.unpack('<' + W + 'I', Z ? s + substr(ZB, 0, Z) : s);
else {
let h = hexenc(s) + substr(ZH, 0, Z * 2);
for (let p = 0; p < W * 8; p += 8) push(d, sw(hex(substr(h, p, 8))));
}
for (let i = 0; i < W; i += 16) { blk(k, c, n, d, i, o); c = (c + 1) & M; }
let r;
if (ST) r = ST.pack('<' + W + 'I', ...o);
else { let h = []; for (let i = 0; i < W; i += 16) push(h, sprintf('%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x',
sw(o[i]), sw(o[i + 1]), sw(o[i + 2]), sw(o[i + 3]), sw(o[i + 4]), sw(o[i + 5]), sw(o[i + 6]), sw(o[i + 7]), sw(o[i + 8]),
sw(o[i + 9]), sw(o[i + 10]), sw(o[i + 11]), sw(o[i + 12]), sw(o[i + 13]), sw(o[i + 14]), sw(o[i + 15]))); r = hexdec(join('', h)); }
return [ Z ? substr(r, 0, L) : r, c ];
}
function words(h, n) { let w = []; for (let i = 0; i < n; i++) push(w, le(h, i * 4)); return w; }
function sha(feed) {
let f = TD + '/.wfbe-' + hexenc(readfile('/dev/urandom', 8) ?? '' + time()), p = popen('sha256sum > ' + f, 'w'), bad = false, d;
if (!p) return null;
feed((s) => { if (p.write(s) != length(s)) bad = true; });
if (p.close() !== 0) bad = true;
d = readfile(f); unlink(f);
d = match(d ?? '', /^[0-9a-f]{64}/);
return d && !bad ? d[0] : null;
}
function same(a, b) {
if (length(a) != length(b)) return false;
let x = 0;
for (let i = 0; i < length(a); i++) x |= ord(a, i) ^ ord(b, i);
return x == 0;
}
function keys(pw, salt, c) {
let u = hexdec(salt) + pw, ch = '';
while (length(ch) < CH) ch += u;
let k0 = sha((w) => {
let left = c < length(u) ? length(u) : c;
while (left >= length(ch)) { w(ch); left -= length(ch); }
if (left > 0) w(substr(ch, 0, left));
});
if (!k0) return null;
let ke = sha((w) => w(hexdec(k0) + 'enc')), km = sha((w) => w(hexdec(k0) + 'mac'));
return ke && km ? [ ke, km ] : null;
}
function pad(km, b) { let a = []; for (let i = 0; i < 64; i++) push(a, (i < 32 ? hex(substr(km, i * 2, 2)) : 0) ^ b); return chr(...a); }
function rdpw(f) {
let p = readfile(f);
return p != null && length(p) >= 1 && length(p) <= 256 ? p : null;
}
function rnd(n) { let r = readfile('/dev/urandom', n); return r != null && length(r) == n ? hexenc(r) : null; }

function enc(fi, fo, pw) {
let salt = rnd(16), non = rnd(12);
if (!salt || !non) return 3;
let K = keys(pw, salt, CNT);
if (!K) return 3;
let k = words(K[0], 8), n = words(non, 3), c = 1, hd = sprintf('%s%09d %s %s ', MAG, CNT, salt, non);
let I = open(fi, 'r'), O = open(fo + '.t', 'w'), ok = I != null && O != null;
if (!ok) { if (I) I.close(); if (O) O.close(); unlink(fo + '.t'); return 3; }
O.write(hd + substr('0000000000000000000000000000000000000000000000000000000000000000', 0, 64) + '\n');
let ih = sha((w) => {
w(pad(K[1], 0x36)); w(hd);
for (let s = I.read(CH); s != null && length(s); s = I.read(CH)) {
let x = xorc(k, n, c, s);
c = x[1];
if (O.write(x[0]) != length(x[0])) ok = false;
w(x[0]);
}
});
let mac = ih ? sha((w) => w(pad(K[1], 0x5c) + hexdec(ih))) : null;
if (mac) { O.seek(MO); if (O.write(mac) != 64) ok = false; } else ok = false;
I.close(); O.close();
if (!ok || !rename(fo + '.t', fo)) { unlink(fo + '.t'); return 3; }
return 0;
}
function head(f) {
let I = open(f, 'r'), h = I ? I.read(HL) : null;
if (I) I.close();
let m = match(h ?? '', /^WFBAK1 ([0-9]{9}) ([0-9a-f]{32}) ([0-9a-f]{24}) ([0-9a-f]{64})\n$/);
return m ? [ +m[1], m[2], m[3], m[4] ] : null;
}
function chk(I, H, pw, K) {
let k = keys(pw, H[1], H[0]);
if (!k) return 3;
let hd = sprintf('%s%09d %s %s ', MAG, H[0], H[1], H[2]);
let ih = sha((w) => {
w(pad(k[1], 0x36)); w(hd);
I.seek(HL);
for (let s = I.read(CH); s != null && length(s); s = I.read(CH)) w(s);
});
let mac = ih ? sha((w) => w(pad(k[1], 0x5c) + hexdec(ih))) : null;
if (!mac) return 3;
if (!same(mac, H[3])) return 4;
push(K, ...k);
return 0;
}
function ver(fi, pw) {
let H = head(fi);
if (!H || H[0] < CMIN || H[0] > CMAX) return 5;
let I = open(fi, 'r');
if (!I) return 3;
let r = chk(I, H, pw, []);
I.close();
return r;
}
function dec(fi, fo, pw) {
let H = head(fi), K = [];
if (!H || H[0] < CMIN || H[0] > CMAX) return 5;
let I = open(fi, 'r');
if (!I) return 3;
let r = chk(I, H, pw, K);
if (r) { I.close(); return r; }
let O = open(fo + '.t', 'w'), k = words(K[0], 8), n = words(H[2], 3), c = 1, ok = O != null;
if (ok) {
I.seek(HL);
for (let s = I.read(CH); s != null && length(s); s = I.read(CH)) {
let x = xorc(k, n, c, s);
c = x[1];
if (O.write(x[0]) != length(x[0])) { ok = false; break; }
}
O.close();
}
I.close();
if (!ok || !rename(fo + '.t', fo)) { unlink(fo + '.t'); return 3; }
return 0;
}

let A = '' + (ARGV[0] ?? ''), r = 2;
if (A == 'is') r = head('' + (ARGV[1] ?? '')) ? 0 : 5;
else if (A == 'kat' && match('' + ARGV[1], /^[0-9a-f]{64}$/) && match('' + ARGV[2], /^[0-9a-f]{24}$/) && match('' + ARGV[4], /^([0-9a-f][0-9a-f])+$/)) {
print(hexenc(xorc(words(ARGV[1], 8), words(ARGV[2], 3), +ARGV[3], hexdec(ARGV[4]))[0]), '\n');
r = 0;
}
else if ((A == 'enc' || A == 'dec') && length(ARGV) == 4) {
let pw = rdpw('' + ARGV[3]);
if (pw != null) r = A == 'enc' ? enc('' + ARGV[1], '' + ARGV[2], pw) : dec('' + ARGV[1], '' + ARGV[2], pw);
}
else if (A == 'ver' && length(ARGV) == 3) {
let pw = rdpw('' + ARGV[2]);
if (pw != null) r = ver('' + ARGV[1], pw);
}
exit(r);
