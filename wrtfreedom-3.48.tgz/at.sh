#!/bin/sh
C="$1"
read -r U _ < /proc/uptime; U=${U%%.*}
mm() { mmcli -L 2>/dev/null | grep -o '/Modem/[0-9]*' | head -n 1 | cut -d/ -f3; }
mmf() {
if [ -f /tmp/wf-modem.mm ]; then
while IFS= read -r l; do
case "$l" in *ModemManager1/Modem/[0-9]*) l=${l#*ModemManager1/Modem/}; echo "${l%%[!0-9]*}"; return ;; esac
done < /tmp/wf-modem.mm
fi
mm
}
AC=/tmp/wf-atport
mmport() {
if [ -f "$AC" ]; then
read -r p < "$AC"; u=; [ -f "$AC.u" ] && read -r u < "$AC.u"
case "$u" in ''|*[!0-9]*) a=999999 ;; *) a=$((U - u)) ;; esac
[ $a -ge 0 ] || a=999999
if [ "$p" = - ]; then [ $a -lt 60 ] && { echo -; return; }; elif [ -n "$p" ] && [ $a -lt 600 ]; then echo "$p"; return; fi
fi
p=-
if command -v mmcli >/dev/null 2>&1; then
n=$(mm)
[ -n "$n" ] && for x in $(mmcli -m "$n" -J 2>/dev/null | grep -o '"[A-Za-z0-9_]\{1,30\} (at)"' | cut -d '"' -f 2 | cut -d ' ' -f 1); do
[ -c "/dev/$x" ] && { p=/dev/$x; break; }
done
fi
echo "$p" > "$AC.$$" && mv "$AC.$$" "$AC"
echo "$U" > "$AC.u"
echo "$p"
}
UC=/tmp/wf-atuci
uport() {
F=/etc/config/wrtfreedom
if [ -f "$F" ] && [ -f "$UC" ] && [ "$UC" -nt "$F" ] && { [ ! -f /tmp/.uci/wrtfreedom ] || [ "$UC" -nt /tmp/.uci/wrtfreedom ]; }; then
P=; read -r P < "$UC"; return
fi
P=$(uci -q get wrtfreedom.modem.atport)
[ -f "$F" ] && echo "$P" > "$UC.$$" && mv "$UC.$$" "$UC"
}
port() {
uport
[ -n "$P" ] && [ -c "$P" ] && { echo "$P"; return; }
P=$(mmport); [ "$P" != - ] && [ -c "$P" ] && { echo "$P"; return; }
for P in /dev/ttyUSB2 /dev/ttyUSB3 /dev/wwan0at0 /dev/wwan0at1 /dev/ttyACM0 /dev/ttyUSB1; do
[ -c "$P" ] && { echo "$P"; return; }
done
}
[ "$C" = "--port" ] && { port; exit 0; }
tool() {
T=none; PORT=; MMI=
command -v quectel-at >/dev/null 2>&1 && { T=quectel-at; return; }
command -v sms_tool >/dev/null 2>&1 && { PORT=$(port); [ -n "$PORT" ]; } && { T=sms_tool; return; }
command -v gl_modem >/dev/null 2>&1 && { T=gl_modem; return; }
command -v atinout >/dev/null 2>&1 && { [ -n "$PORT" ] || PORT=$(port); [ -n "$PORT" ]; } && { T=atinout; return; }
command -v mmcli >/dev/null 2>&1 && { MMI=$(mmf); [ -n "$MMI" ]; } && { T=mmcli; return; }
}
[ "$C" = "--tool" ] && { tool; echo "$T"; exit 0; }
[ -n "$C" ] || { echo "uso: at.sh 'AT...'"; exit 1; }
if command -v flock >/dev/null 2>&1; then exec 9>/var/lock/wf-at.lock; i=0; until flock -n 9; do [ $? = 1 ] && [ $i -lt 15 ] || break; i=$((i+1)); sleep 1; done; fi
tool
rc=0
for C in "$@"; do
[ -n "$C" ] || continue
case "$T" in
quectel-at) quectel-at "$C" ;;
sms_tool) sms_tool -d "$PORT" at "$C" ;;
gl_modem) gl_modem AT "$C" ;;
atinout) echo "$C" | atinout - "$PORT" - ;;
mmcli) o=$(mmcli -m "$MMI" --command="$C" 2>&1)
case "$o" in *"find modem"*) n=$(mm); [ -n "$n" ] && [ "$n" != "$MMI" ] && { MMI=$n; o=$(mmcli -m "$MMI" --command="$C" 2>&1); } ;; esac
printf '%s\n' "$o" | sed "s/^response: '//;s/'\$//" ;;
*) echo "ERROR: nessuno strumento per i comandi AT (installa sms-tool)"; false ;;
esac
rc=$?
[ -n "$T" ] && [ "$T" != none ] || rc=2
done
exit $rc
