#!/bin/sh
if [ "$1" = dfree ]; then
MR=/tmp/wf-cloudmnt
dft() {
_o=/tmp/.wf-dfree.$$; rm -f $_o $_o.t
( df -kP "$1" 2>/dev/null | awk 'NR == 2 { print $2, $4 }' > $_o.t; mv -f $_o.t $_o ) </dev/null >/dev/null 2>&1 &
_p=$! _i=0
while kill -0 $_p 2>/dev/null && [ $_i -lt 50 ]; do if sleep 0.1 2>/dev/null; then _i=$((_i + 1)); else sleep 1; _i=$((_i + 10)); fi; done
if kill -0 $_p 2>/dev/null; then kill -KILL $_p 2>/dev/null; rm -f $_o $_o.t; return 1; fi
read -r _a _b < $_o 2>/dev/null; rm -f $_o $_o.t
case "$_a$_b" in ''|*[!0-9]*) return 1 ;; esac
echo "$_a $_b"
}
d=$(cd "${2:-.}" 2>/dev/null && pwd -P); [ -n "$d" ] || d=$(pwd -P 2>/dev/null)
case "$d/" in
"$MR"/a*/*)
i=${d#"$MR"/}; i=${i%%/*}; i=${i%.p}; i=${i%.u}; v=
case "$i" in a[0-9]|a[0-9][0-9]) ;; *) i= ;; esac
[ -n "$i" ] && read -r t f x 2>/dev/null < $MR/.$i.df && case "$t$f" in ''|*[!0-9]*) false ;; esac &&
v="$((t / 1024)) $((f / 1024))"
[ -n "$v" ] || v=$(dft "$d") || exit 1
t=${v% *} f=${v#* }
echo "$t $f" ;;
*) dft "${2:-.}" || exit 1 ;;
esac
exit 0
fi
export PATH=$PATH:/usr/sbin:/usr/bin:/sbin:/bin
D0=$(cd "$(dirname "$0")" && pwd)
. "$D0/cloudline.sh" || exit 1
R=$CL_R; W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; CJ=$ETC/cloud.json; RC=$ETC/cloud-rclone.conf
T=/tmp/wf-cloud; MD=$T/mnt; MR=/tmp/wf-cloudmnt; MNTJ=/tmp/wf-nas/mnt.json; STJ=$T/state.json; NASJ=$ETC/nas.json
CLOUDUC=${WF_CLOUDUC:-$W/cloud.uc}; MOUNTS=$CL_PROC/mounts
umask 022
[ -d $T ] || mkdir -p $T 2>/dev/null; chmod 700 $T 2>/dev/null

idok() { case "$1" in a[0-9]|a[0-9][0-9]) return 0 ;; esac; return 1; }
log() { logger -t wrtfreedom "Cartella Cloud: $*" 2>/dev/null; true; }
why() {
case "$1" in
warn) echo 'Questo router ha poca memoria: la Cartella Cloud può rallentarlo|This router has little memory: the Cloud Folder may slow it down' ;;
many) echo 'Una sola Cartella Cloud su questo router|Only one Cloud Folder on this router' ;;
pmany) echo 'Troppi cloud personali in rete per questo router|Too many personal clouds on the network for this router' ;;
puser) echo 'La persona di questo cloud non è nel NAS|The owner of this cloud is not in the NAS' ;;
space) echo 'Poco spazio nella memoria interna del router|Not enough space in the router internal storage' ;;
fuse) echo 'Manca FUSE: reinstalla Cloud in Software|FUSE missing: reinstall Cloud in Software' ;;
pkg) echo 'Serve installare Cloud in Software|Install Cloud in Software first' ;;
acct) echo 'Account da ricollegare|Account needs reconnecting' ;;
disk) echo 'Collega il disco del NAS|Connect the NAS disk' ;;
ro) echo 'Disco in sola lettura|Disk is read-only' ;;
full) echo 'Disco del NAS quasi pieno|NAS disk almost full' ;;
smb) echo 'Installa Cartelle Condivise nel NAS|Install Shared Folders in the NAS' ;;
users) echo 'Crea prima un utente del NAS|Create a NAS user first' ;;
mem_low) echo 'Memoria del router bassa: modo leggero|Router memory low: light mode' ;;
pmem) echo 'Memoria del router bassa: cartelle private non accese|Router memory low: private folders not started' ;;
cache) echo 'In scrittura serve la cache: scegli il disco del NAS o la memoria interna|Writing needs a cache: choose the NAS disk or the internal storage' ;;
name) echo 'Nome già usato da un'"'"'altra cartella condivisa|Name already used by another shared folder' ;;
overlap) echo 'Dentro una cartella condivisa in scrittura o del Server Multimediale|Inside a writable shared folder or the Media Server' ;;
path) echo 'Cartella non valida|Invalid folder' ;;
fail) echo 'Non riuscito|Failed' ;;
start) echo 'Avvio: rilettura della cache|Starting: reading the cache' ;;
off) echo 'Spenta|Off' ;;
*) cl_why "$1" ;;
esac
}
put() {
[ -d $MD ] || mkdir -p $MD
set -- "$1" "$2" "$3" "$4"; [ "$2" = on ] && [ -z "$3" ] && [ -f $MD/$1.pmem ] && set -- "$1" "$2" pmem "$4"
_w=; [ -n "$3" ] && _w=$(why "$3")
[ -n "$4" ] && case "$4" in *'|'*) _w="${_w%%|*}: ${4%%|*}|${_w#*|}: ${4#*|}" ;; *) _w="${_w%%|*}: $4|${_w#*|}: $4" ;; esac
_sp=; _cu=0; _cm=0; _cc=
if [ "$2" = on ]; then
_sp=$SPD; _cm=${CMAX:-0}; _cc=$CCAP; _c=$(cdir "$1")
if [ -n "$_c" ]; then if [ -n "$CUK" ] && [ "$_c" = "$CUD" ]; then _cu=$CUK; else _cu=$(cdu "$1" "$_c"); fi; fi
fi
ID=$1 ST=$2 WC=$3 WI=${_w%%|*} WE=${_w#*|} F=$MD/$1.json NM=$NAME CP=$CPATH DK=$DISK MO=$MODE EN=$ENG SP=$_sp CU=$(( ${_cu:-0} * 1024 )) CX=$_cm CC=$_cc ucode -e '
		let E = getenv, fs = require("fs"), o = { st: E("ST"), why: E("WI") ?? "", why_en: E("WE") ?? "", why_code: E("WC") ?? "",
			name: E("NM") ?? "", path: E("CP") ?? "", disk: E("DK") ?? "", mode: E("MO") ?? "", speed_now: E("SP") ?? "",
			cache_used: +(E("CU") ?? 0), cache_max: +(E("CX") ?? 0), cache_capped: E("CC") == "1", eng: E("EN") ?? "", t: time() };
		let t = E("F") + "." + (fs.readlink("/proc/self") ?? "0"), s = sprintf("%J\n", o);
		/* 19/11: rename solo con la scrittura completa (disco /tmp pieno: il file di prima resta) */
		if (fs.writefile(t, s) == length(s)) fs.rename(t, E("F")); else fs.unlink(t);' </dev/null 2>/dev/null
}
cdu() {
_dn=$(date +%s)
if [ "$RW" != 1 ] && read -r _dt _dk _dd < $MD/$1.du 2>/dev/null && [ "$_dd" = "$2" ] &&
case "$_dt$_dk" in ''|*[!0-9]*) false ;; esac && [ "$_dn" -ge "$_dt" ] && [ $((_dn - _dt)) -lt 1800 ]; then
echo "$_dk"; return 0
fi
_dk=; _ds=$(rcst $MD/$1.port); _ds=${_ds##* }
if [ -n "$_ds" ]; then _dq=$(rcst $MD/$1.pport); _dq=${_dq##* }; _dk=$(( (_ds + ${_dq:-0}) / 1024 ))
else tl 120 $MD/.du-$1.$$ du -sk "$2"; _dk=$(cut -f1 $MD/.du-$1.$$ 2>/dev/null); rm -f $MD/.du-$1.$$; fi
case "$_dk" in ''|*[!0-9]*) _dk=0 ;; esac
[ -d $MD ] && echo "$_dn $_dk $2" > $MD/$1.du
echo "$_dk"
}
stof() { ucode -e 'try { print(json(require("fs").readfile(ARGV[0]) ?? "{}").st ?? ""); } catch (e) { }' "$MD/$1.json" 2>/dev/null; }

cfg() {
ON=0 CPATH='' NAME='' DISK='' GB=5 AOK=0 DMP='' USERS='' WUSERS='' NASN='' PBAD=0 CACHE=disk WOK=0 RW=0 SPEED=auto SPD='' CMAX=0 CCAP='' ADMU='' CON=0 CF=1 CRON=0 PU='' SVN='' PSV=0 PUOK=0
eval "$(ID=$1 CJ=$CJ MJ=$MNTJ NJ=$NASJ SJ=$STJ CRJ=$CRJ UC=${WF_UCFGUC:-$W/ucfg.uc} ucode -e '
		let E = getenv, fs = require("fs"), UC = null;
		try { UC = loadfile(E("UC"))(); } catch (e) { UC = null; }
		function rj(p) { try { return json(fs.readfile(p) ?? "null"); } catch (e) { return null; } }
		function q(s) { return "\x27" + replace("" + s, "\x27", "\x27\\\x27\x27") + "\x27"; }
		let id = E("ID"), C = rj(E("CJ")) ?? {}, S = (type(C.share) == "object" ? C.share : {})[id], M = rj(E("MJ")) ?? {}, N = rj(E("NJ")) ?? {};
		let St = rj(E("SJ")) ?? {}, a = filter(type(C.accounts) == "array" ? C.accounts : [], (x) => x?.id == id)[0];
		if (type(S) != "object") exit(0);
		let p = trim(replace(replace("" + (S.path ?? ""), /\/+/g, "/"), /^\/|\/$/g, "")), bad = 0;
		for (let x in split(p, "/")) if (x == "." || x == "..") bad = 1;
		if (match(p, /[[:cntrl:]]/) || match(p, /^WrtFreedom (Backup|Router)(\/|$)/)) bad = 1;
		let n = "" + (S.name ?? "");
		if (!length(n) || length(n) > 40 || match(n, /[]["\/\\:;|=,+*?<>[:cntrl:]]/) || match(n, /^[ .]|[ .]$/)) bad = 2;
		let d = "" + (S.disk ?? ""), dm = match(d, /^[A-Za-z0-9_.:-]+$/) ? M[d] : null, st = St.accts?.[id]?.st;
		/* voce senza «cache» (prima della scelta): come shcache di cloud.uc */
		let c = match("" + (S.cache ?? ""), /^(disk|int|none)$/) ? S.cache : (length(d) || (type(M) == "object" && length(keys(M))) ? "disk" : "none");
		/* cache_gb 0 (o assente) = tetto automatico */
		let gb = type(S.cache_gb) == "int" && S.cache_gb >= 0 && S.cache_gb <= 500 ? S.cache_gb : 0;
		/* chi scrive (solo in lettura e scrittura): gli utenti fissi del NAS, come il modello «rw» di nasvc.uc (non gli
		   Accessi Temporanei «until», non le telecamere «cam») */
		let U = type(N.users) == "object" ? N.users : {}, ok = (u) => match(u, /^[A-Za-z0-9_.-]+$/) != null;
		/* 19/11 (funzione nuova 11): cloud personale = account con user di una persona (auser di cloud.uc); i nomi in rete
		   e i conti del Cloud Di Casa (CON, CF) solo sugli account comuni. AC = account della voce share accesa */
		let AA = type(C.accounts) == "array" ? C.accounts : [], au = (x) => type(x?.user) == "string" && length(x.user) ? x.user : "admin";
		let ac = (k) => C.share[k]?.on === true ? filter(AA, (x) => x?.id == k)[0] : null, com = (k) => ac(k) && au(ac(k)) == "admin";
		let pu = a && au(a) != "admin" ? a.user : "", sv = "" + (a?.svc ?? "");
		const SN = { pcloud: "pCloud", drive: "Google Drive", onedrive: "OneDrive", dropbox: "Dropbox", box: "Box", kdrive: "kDrive",
			koofr: "Koofr", jottacloud: "Jottacloud", mega: "MEGA", icloud: "iCloud", b2: "B2", s3: "S3", hetzner: "Hetzner", webdav: "WebDAV", sftp: "SFTP" };
		print("PU=", q(ok(pu) ? pu : (length(pu) ? "-" : "")), " SVN=", q(SN[sv] ?? "Personale"),
			" PUOK=", ok(pu) && type(U[pu]) == "object" && !U[pu].cam ? 1 : 0,
			/* altri cloud personali accesi dello stesso servizio (nome «Cloud <Servizio> <vis>» con samba4) */
			" PSV=", length(pu) ? length(filter(keys(C.share ?? {}), (k) => k != id && ac(k) && au(ac(k)) != "admin" && ("" + (ac(k).svc ?? "")) == sv)) : 0, " ");
		print("ON=", S.on === true ? 1 : 0, " RW=", S.rw === true ? 1 : 0, " SPEED=", match("" + S.speed, /^(light|fast)$/) ? S.speed : "auto", " CACHE=", c, " WOK=", S.warn_ok === true ? 1 : 0, " CPATH=", q(p), " NAME=", q(n), " DISK=", q(d), " GB=", gb, " PBAD=", bad,
			" AOK=", a && st != "relink" && st != "new" ? 1 : 0, " DMP=", q(type(dm) == "string" ? dm : ""),
			" USERS=", q(join(" ", filter(keys(U), ok))), " WUSERS=", q(join(" ", filter(sort(keys(U)), (u) => ok(u) && !U[u]?.until && !U[u]?.cam))),
			" NASN=", q(join("|", map(type(N.shares) == "array" ? N.shares : [], (s) => lc("" + s?.name)))),
			/* 18/11 sera (scelta dell’utente; apostrofo tipografico: siamo dentro gli apici della shell): Cartelle Cloud
			   accese in cloud.json (con il loro account), per i nomi di smbl */
			" CON=", length(filter(keys(C.share ?? {}), com)),
			/* 19/11 mattina (scelta dell’utente): CF 1 = prima Cartella Cloud accesa (numero dell’id più basso): nomi SMB senza
			   il nome della cartella («Cloud», «Admin Cloud»); le altre «Cloud <Nome>» */
			" CF=", (sort(filter(keys(C.share ?? {}), com), (x, y) => +substr(x, 1) - +substr(y, 1))[0] ?? id) == id ? 1 : 0,
			" ADMU=", q(type(UC?.smbadm) == "function" ? UC.smbadm(N) : ""),
			/* 19/11 notte: cifratura accesa sull’account (mig, on o back) e Cartella sulla radice o su Utenti: le cartelle
			   private si vedono solo dalla vista decifrata (pers), mai dal montaggio in chiaro (smbl) */
			" CRON=", !length(pu) && (p == "" || p == "Utenti") && rj(E("CRJ"))?.on === true && match("" + (rj(E("CRJ"))?.accts?.[id]?.st ?? ""), /^(mig|on|back)$/) ? 1 : 0, "\n");' </dev/null 2>/dev/null)"
}
ids() {
CJ=$CJ ucode -e 'try { let S = json(require("fs").readfile(getenv("CJ")) ?? "{}").share; if (type(S) == "object") print(join(" ", keys(S)), "\n"); } catch (e) { }' </dev/null 2>/dev/null
for f in $MD/a*.*; do [ -e "$f" ] && { f=${f##*/}; echo "${f%%.*}"; }; done
}
acids() {
CJ=$CJ ucode -e 'try { let C = json(require("fs").readfile(getenv("CJ"))); if (type(C?.accounts) == "array")
		print("ok ", join(" ", map(filter(C.accounts, (a) => type(a?.id) == "string"), (a) => a.id)), "\n"); } catch (e) { }' </dev/null 2>/dev/null
}
gone_() { [ "${ACS%% *}" = ok ] || return 1; case " $ACS " in *" $1 "*) return 1 ;; esac; return 0; }
jv() { ucode -e 'try { print(json(require("fs").readfile(ARGV[0]) ?? "{}")[ARGV[1]] ?? ""); } catch (e) { }' "$MD/$1.json" "$2" 2>/dev/null; }
nmof() { [ -n "$NAME" ] || NAME=$(jv "$1" name); [ -n "$NAME" ] || NAME=$1; }

eng() {
for e in samba4 ksmbd; do [ -x $R/etc/init.d/$e ] && ls $R/etc/rc.d/S*$e >/dev/null 2>&1 && { echo $e; return 0; }; done
for e in ksmbd samba4; do [ -x $R/etc/init.d/$e ] && { echo $e; return 0; }; done
return 1
}
shares() {
uci -q show "$1" 2>/dev/null | awk -F= '
		function un(v) { gsub(/^\x27|\x27$/, "", v); return v }
		{ k = $1; v = substr($0, length($1) + 2); n = split(k, P, ".") }
		n == 2 { T[P[2]] = un(v); next }
		n == 3 { V[P[2] "." P[3]] = un(v) }
		END { for (s in T) if (T[s] == "share" || T[s] == "sambashare") print T[s] "|" s "|" V[s ".name"] "|" V[s ".path"] "|" V[s ".read_only"] }'
}
under() { [ -n "$1" ] && case "$2/" in "${1%/}/"*) return 0 ;; esac; return 1; }
clash() {
_n=$(printf '%s' "$NAME" | tr 'A-Z' 'a-z'); _m=$MR/$1
case "|$NASN|" in *"|$_n|"*) echo name; return 0 ;; esac
for e in ksmbd samba4; do
shares $e | while IFS='|' read -r _t _s _sn _sp _ro; do
case "$_s" in "wfcloud_$1"|"wfcloud_$1"_*) continue ;; esac
[ "$(printf '%s' "$_sn" | tr 'A-Z' 'a-z')" = "$_n" ] && { echo name; break; }
case "$_ro" in yes|1|true) ;; *) under "$_sp" "$_m" && { echo overlap; break; } ;; esac
done
done | sed -n 1p | grep . && return 0
{ uci -q show minidlna 2>/dev/null | awk '
		!s && $0 ~ /^minidlna\.[^.=]+=minidlna$/ { s = substr($0, 10, index($0, "=") - 10); next }
		{ k = substr($0, 1, index($0, "=") - 1); L[k] = substr($0, index($0, "=") + 1) }
		END { v = L["minidlna." s ".media_dir"]; if (s == "" || v == "") exit
			n = split(v, A, /\x27 \x27/); for (i = 1; i <= n; i++) { gsub(/^\x27|\x27$/, "", A[i]); print A[i] } }'
awk '/^[ \t]*media_dir[ \t]*=/ { sub(/^[ \t]*media_dir[ \t]*=[ \t]*/, ""); sub(/[ \t\r]+$/, ""); print }' \
		$R/etc/minidlna.conf 2>/dev/null; } | sed 's/^[AVP]*,//' | while IFS= read -r _d; do
under "$_d" "$_m" && { echo overlap; break; }
done | grep . && return 0
return 1
}
smbreload() { [ -x $R/etc/init.d/$1 ] && { $R/etc/init.d/$1 reload || $R/etc/init.d/$1 restart; } </dev/null >/dev/null 2>&1; true; }
ppl() {
_po=$(NJ=$NASJ ucode -e '
		let N = null; try { N = json(require("fs").readfile(getenv("NJ")) ?? "null"); } catch (e) { }
		let U = type(N?.users) == "object" ? N.users : {};
		print("admin\nshared\n"); for (let u in sort(keys(U))) if (type(U[u]) == "object" && !U[u].cam) print(u, "\n");' </dev/null 2>/dev/null)
[ -n "$_po" ] || return 0
( WF_NASETC=$ETC; export WF_NASETC; . "$D0/lib.sh" || exit 0
printf '%s\n' "$_po" | while IFS= read -r _u; do
_d=$(wf_udir "$_u" root) && [ -n "$_d" ] || continue
_v=${_d#Utenti/}; case "$_v" in */*|*[\"=\|\	]*) continue ;; esac
printf '%s\t%s\n' "$_u" "$_v"
done )
}
smbnm() {
_x=$1
case "|$NASN|" in *"|$(printf '%s' "$_x" | tr 'A-Z' 'a-z')|"*) _x="$_x ($NAME)" ;; esac
printf '%s' "$_x"
}
smbl() {
if [ -n "$PU" ]; then
[ "$PUOK" = 1 ] || return 0
_w=; case " $WUSERS " in *" $PU "*) _w=$PU ;; esac
if [ -n "$CPATH" ]; then _nm=$NAME
else
_nm="Cloud $SVN"
if [ "$2" = ksmbd ] || [ "${PSV:-0}" -gt 0 ]; then
_v=$(ppl | awk -F'\t' -v u="$PU" '$1 == u { print $2; exit }'); [ -n "$_v" ] && _nm="$_nm $_v"
fi
_nm=$(smbnm "$_nm")
fi
printf 'wfcloud_%s|%s|%s|%s|%s||\n' "$1" "$_nm" "$MR/$1" "$PU" "$_w"; return 0
fi
[ -n "$ADMU" ] || return 0
_pl=$(ppl); _al=$ADMU; _aw=$ADMU
while IFS='	' read -r _o _v; do
case "$_o" in ''|admin|shared|"$ADMU") continue ;; esac
_al="$_al $_o"; case " $WUSERS " in *" $_o "*) _aw="$_aw $_o" ;; esac
done <<X
$_pl
X
_rl=; _n=0
_sx=; [ "${CON:-0}" -gt 1 ] && _sx=" ($NAME)"
_cx=; [ "${CON:-0}" -gt 1 ] && [ "$CF" != 1 ] && _cx=" $NAME"
case "$CPATH" in
'') printf 'wfcloud_%s|%s|%s|%s|%s|/Utenti/|\n' "$1" "$(smbnm "Admin Cloud$_cx")" "$MR/$1" $ADMU $ADMU; _n=1; _rl=Utenti/ ;;
Utenti) ;;
*)
_u=$ADMU _w=$ADMU
while IFS='	' read -r _o _v; do
case "$_o" in ''|admin) continue ;; esac
under "Utenti/$_v" "$CPATH" || continue
if [ "$_o" = shared ]; then _u=$_al _w=$_aw; else _u=$_o _w=; case " $WUSERS " in *" $_o "*) _w=$_o ;; esac; fi
done <<X
$_pl
X
printf 'wfcloud_%s|%s|%s|%s|%s||\n' "$1" "$NAME" "$MR/$1" "$_u" "$_w"; return 0 ;;
esac
_pv=; mntd "$MR/$1.p" && _pv=1
_cr=; [ "$CRON" = 1 ] && { _cr=$(cat $MD/$1.crs 2>/dev/null) || _cr='*'; }; _mh=
if [ -n "$_cr" ] && [ -n "$PL" ] && [ -z "$SMBNEW" ] && [ -s $MD/$1.smb ] && [ ! -f $MD/$1.pmem ]; then
[ -n "$_pv" ] && { dok "$MR/$1.p"; [ $? = 2 ] && _pv=; }
[ -z "$_pv" ] && pvivo $1 && { cat $MD/$1.smb; return 0; }
fi
_lu=; _lw=; _lk=
while IFS='	' read -r _o _v; do
[ -n "$_o" ] || continue
_pd=1; [ -n "$_pv" ] && { dok "$MR/$1.p/$_v"; _pd=$?; [ $_pd = 2 ] && _pv=; }
if [ $_pd = 0 ]; then _pp=$MR/$1.p/$_v
else
[ -n "$_cr" ] && continue
[ -z "$_mh" ] || continue
dok "$MR/$1/$_rl$_v"; case $? in 0) _pp=$MR/$1/$_rl$_v ;; 2) _mh=1; continue ;; *) continue ;; esac
fi
_h=; _nm=
case "$_o" in
admin) _u=$ADMU _w=$ADMU ;;
shared) _u=$_al _w=$_aw _h=1; _nm="$_v · Cloud$_sx"; [ -z "$_sx" ] && _nm=$(smbnm "$_nm") ;;
*) _u=$_o _w=; case " $WUSERS " in *" $_o "*) _w=$_o ;; esac ;;
esac
if [ -z "$_nm" ] && [ "$2" = samba4 ]; then
_lu="$_lu $_u"; [ -n "$_w" ] && _lw="$_lw $_w"; _lk="${_lk}lnk|$_u|$_pp
"; continue
fi
[ -n "$_nm" ] || _nm=$(smbnm "Cloud $_v$_cx")
_s=wfcloud_$1; [ $_n -gt 0 ] && _s=wfcloud_$1_$_n; _n=$((_n + 1))
printf '%s|%s|%s|%s|%s||%s\n' "$_s" "$_nm" "$_pp" "$_u" "$_w" "$_h"
done <<X
$_pl
X
[ -n "$_lu" ] || return 0
_s=wfcloud_$1; [ $_n -gt 0 ] && _s=wfcloud_$1_$_n
printf '%s|%s|%s|%s|%s||\n%s' "$_s" "$(smbnm "Cloud$_cx")" "$MR/$1.u/%u" "${_lu# }" "${_lw# }" "$_lk"
}
smblk() {
_ul=$MR/$1.u; _lk=$(printf '%s\n' "$2" | sed -n 's/^lnk|//p')
for _f in "$_ul"/*; do
[ -L "$_f" ] || continue
printf '%s\n' "$_lk" | awk -F'|' -v u="${_f##*/}" '$1 == u { f = 1 } END { exit !f }' || rm -f "$_f"
done
[ -n "$_lk" ] || { rmdir "$_ul" 2>/dev/null; return 0; }
[ -d "$_ul" ] || mkdir -p "$_ul"
printf '%s\n' "$_lk" | while IFS='|' read -r _u _t; do
[ -n "$_u" ] && [ -n "$_t" ] || continue
[ "$(readlink "$_ul/$_u" 2>/dev/null)" = "$_t" ] && continue
[ -L "$_ul/$_u" ] && rm -f "$_ul/$_u"
[ -e "$_ul/$_u" ] || ln -s "$_t" "$_ul/$_u"
done
}
smbsec() { shares $1 | awk -F'|' -v p="wfcloud_$2" '$2 == p || index($2, p "_") == 1 { print $2 }'; }
smbon() {
_t=share; [ "$2" = samba4 ] && _t=sambashare; _ls=$(smbl $1 $2)
_b4=$(uci -q show "$2" 2>/dev/null | grep "^$2\.wfcloud_$1[._=]"); _sr=
printf '%s\n' "$_ls" > $MD/$1.smb; echo "$2" > $MD/$1.se; smbtpl && [ "$2" = samba4 ] && _sr=1
for _oe in ksmbd samba4; do
_ss=$(smbsec $_oe $1); [ -n "$_ss" ] || continue
for _s in $_ss; do uci -q delete "$_oe.$_s"; done
[ "$_oe" = "$2" ] && continue
uci -q commit $_oe; ls $R/etc/rc.d/S*$_oe >/dev/null 2>&1 && smbreload $_oe
done
printf '%s\n' "$_ls" | while IFS='|' read -r _s _n _p _u _w _v _h; do
case "$_s" in wfcloud_*) ;; *) continue ;; esac
_b=yes; [ "$_h" = 1 ] && _b=no
uci -q set "$2.$_s=$_t"; uci -q set "$2.$_s.name=$_n"; uci -q set "$2.$_s.path=$_p"
uci -q set "$2.$_s.read_only=yes"; uci -q set "$2.$_s.browseable=$_b"
case "$_p" in *%u*) ;; *) [ "$2" = ksmbd ] || uci -q set "$2.$_s.force_root=1" ;; esac
_v="${_v:-/}._*/.DS_Store/.wf-trash/"
uci -q set "$2.$_s.hide_dot_files=yes"; uci -q set "$2.$_s.veto_files=$_v"
uci -q set "$2.$_s.guest_ok=no"; uci -q set "$2.$_s.users=$_u"
[ "$RW" = 1 ] && [ -n "$_w" ] && uci -q set "$2.$_s.write_list=$_w"
done
smblk $1 "$_ls"
[ "$(uci -q show "$2" 2>/dev/null | grep "^$2\.wfcloud_$1[._=]")" = "$_b4" ] || _sr=1
uci -q commit "$2"; [ -n "$_sr" ] && smbreload "$2"
davw $1 "$_ls"
}
davw() {
if [ -n "$2" ]; then
( umask 077; printf '%s\n' "$2" | awk -F'|' -v rw="$RW" '
			function has(l, u) { return index(" " l " ", " " u " ") > 0 }
			$1 == "lnk" { L[++m] = $2; P[m] = $3; next }
			$1 ~ /^wfcloud_/ { w = rw == 1 ? $5 : ""
				if (index($3, "%u")) { U = $2; W = w; next }
				print $2 "|" $3 "|" $4 "|" w "|" $6 }
			END { if (U == "") exit
				for (i = 1; i <= m; i++) { v = P[i]; sub(/.*\//, "", v); if (v == "") continue
					print U " " v "|" P[i] "|" L[i] "|" (has(W, L[i]) ? L[i] : "") "|" } }' > $MD/$1.dav )
else rm -f $MD/$1.dav; fi
_dl=$T/dav.list
( umask 077; for _f in $MD/a*.dav; do [ -f "$_f" ] && cat "$_f"; done > $_dl.t )
if [ -s $_dl.t ]; then cmp -s $_dl.t $_dl && rm -f $_dl.t || mv -f $_dl.t $_dl
else rm -f $_dl.t $_dl; fi
}
smbtpl() {
_tp=$R/etc/samba/smb.conf.template; [ -f "$_tp" ] || return 1
_tn=$( { for _f in $MD/a*.smb; do [ -f "$_f" ] && [ "$(cat "${_f%.smb}.se" 2>/dev/null)" = samba4 ] && cat "$_f"; done; } | awk -F'|' '
		$1 ~ /^wfcloud_/ && $2 != "" {
			v = $6; if (v == "") v = "/"; v = v "._*/.DS_Store/.wf-trash/"
			# 19/11 sera (router vero): senza «path» smbd segna la sezione non disponibile prima di leggere quella di uci
			printf "[%s]\n\tpath = %s\n\tveto files = %s\n\tdelete veto files = yes\n\thide dot files = yes\n\tcase sensitive = yes\n\tstore dos attributes = no\n\tea support = no\n", $2, $3, v
			if (index($3, "%u")) printf "\twide links = yes\n"; n++ }
		END { if (n) print "[global]" }')
[ -n "$_tn" ] || grep -qx '# wf-cloud' "$_tp" 2>/dev/null || grep -q '^\[\(Admin Cloud\|Cloud\)[] ]\|^\[.* · Cloud' "$_tp" 2>/dev/null || return 1
_nm=$(for _f in $MD/a*.smb; do [ -f "$_f" ] && cut -d'|' -f2 "$_f"; done | awk 'NF { printf "%s[%s]", (n++ ? "|" : ""), $0 }')
_sk=/tmp/wf-smbtpl.lock; _si=0
until mkdir $_sk 2>/dev/null; do
_st=$(cat $_sk/t 2>/dev/null); [ -n "$_st" ] && [ $(( $(date +%s) - _st )) -gt 30 ] && { rm -rf $_sk; continue; }
_si=$((_si + 1)); [ $_si -ge 10 ] && break; sleep 1
done
date +%s > $_sk/t 2>/dev/null
awk -v M='# wf-cloud' -v NM="$_nm" 'BEGIN { c = split(NM, A, "|"); for (i = 1; i <= c; i++) S[A[i]] = 1 }
		function ours(x) { return x == "Admin Cloud" || index(x, "Admin Cloud ") == 1 || x == "Cloud" || index(x, "Cloud ") == 1 || index(x, " · Cloud") > 0 }
		k { k = 0; next } $0 == M { k = 1; next } ($0 in S) { next } { L[++n] = $0 }
		END { for (i = 1; i <= n; i++) {
				if (L[i] !~ /^\[.*\]$/ || !ours(substr(L[i], 2, length(L[i]) - 2))) continue
				e = 1; w = 0
				for (j = i + 1; j <= n && L[j] !~ /^[ \t]*\[/; j++) {
					if (w) { w = 0; continue }
					if (L[j] ~ /^# wf-/) { w = 1; continue }
					if (L[j] !~ /^[ \t]*([#;].*)?$/) { e = 0; break } }
				if (e) D[i] = 1 }
			while (n > 0 && (L[n] == "" || D[n])) n--; for (i = 1; i <= n; i++) if (!D[i]) print L[i] }' "$_tp" > "$_tp.wfc" 2>/dev/null || { rm -f "$_tp.wfc"; rm -rf $_sk; return 1; }
[ -n "$_tn" ] && printf '%s\n' "$_tn" | awk '{ print "# wf-cloud"; print }' >> "$_tp.wfc"
if cmp -s "$_tp.wfc" "$_tp"; then rm -f "$_tp.wfc"; rm -rf $_sk; return 1; fi
mv -f "$_tp.wfc" "$_tp"; rm -rf $_sk
}
smboff() {
_ht=; [ -f $MD/$1.smb ] && _ht=1; rm -f $MD/$1.smb $MD/$1.se; _sr=; [ -n "$_ht" ] && smbtpl && _sr=1
for e in ksmbd samba4; do
_ss=$(smbsec $e $1); [ -n "$_ss" ] || { [ $e = samba4 ] && [ -n "$_sr" ] && ls $R/etc/rc.d/S*samba4 >/dev/null 2>&1 && smbreload $e; continue; }
for _s in $_ss; do uci -q delete "$e.$_s"; done; uci -q commit $e; smbreload $e
done
smblk $1 ''
davw $1 ''
}
mounted() { awk -v m="$MR/$1" '$2 == m { f = 1 } END { exit !f }' $MOUNTS 2>/dev/null; }
dfs() { [ -n "$1" ] && awk -v m="$1" '$2 == m { print $3; exit }' $MOUNTS 2>/dev/null; }
sec() { awk -v s="[$2]" '/^\[/ { on = ($0 == s); next } on && NF' "$1" 2>/dev/null; }
tok() { sec "$1" "$2" | grep '^token[ =]' | md5sum | cut -c1-32; }

lock() {
[ -d $MD ] || mkdir -p $MD; _l=$MD/$1.lock
mkdir $_l 2>/dev/null && { echo $$ > $_l/pid; return 0; }
_p=$(cat $_l/pid 2>/dev/null)
if { [ -n "$_p" ] && { [ ! -d /proc/$_p ] || ! tr '\0' ' ' < /proc/$_p/cmdline 2>/dev/null | grep -q 'cloudmnt\.sh'; }; } ||
{ [ -z "$_p" ] && [ -n "$(find $_l -maxdepth 0 -mmin +2 2>/dev/null)" ]; }; then
rm -rf $_l; mkdir $_l 2>/dev/null && { echo $$ > $_l/pid; return 0; }
fi
if [ -n "$(find $_l -maxdepth 0 -mmin +30 2>/dev/null)" ]; then
log "lucchetto di $1 tenuto da oltre 30 minuti (pid ${_p:-?}): tolto"
rm -rf $_l; mkdir $_l 2>/dev/null && { echo $$ > $_l/pid; return 0; }
fi
return 1
}
unlock() { [ "$(cat $MD/$1.lock/pid 2>/dev/null)" = "$$" ] && rm -rf $MD/$1.lock; true; }

texp() {
sec "$1" "$2" | awk '!d && /^token[ \t]*=/ { sub(/^token[ \t]*=[ \t]*/, ""); print; d = 1 }' | ucode -e '
		function dn(s) { let v = 0; for (let i = 0; i < length(s); i++) v = v * 10 + ord(s, i) - 48; return v; }
		let t = null; try { t = json(require("fs").stdin.read("all")); } catch (e) {}
		/* 19/11 (analisi del NAS): senza refresh_token o con la scadenza prima del 1971 (pCloud: 0001-01-01) il token non
		   scade: niente scadenza */
		if (!length(t?.refresh_token ?? "") || dn(substr("" + (t?.expiry ?? ""), 0, 4)) < 1971) exit(0);
		let m = match(t?.expiry ?? "",/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})[.0-9]*(Z|([-+])([0-9]{2}):([0-9]{2}))$/);
		if (m) { let o = m[8] ? (dn(m[9]) * 3600 + dn(m[10]) * 60) * (m[8] == "-" ? -1 : 1) : 0;
			print(timegm({ year: dn(m[1]), mon: dn(m[2]), mday: dn(m[3]), hour: dn(m[4]), min: dn(m[5]), sec: dn(m[6]) }) - o - time(), "\n"); }' 2>/dev/null
}
ccopy() {
( umask 077; { echo "[wf$1]"; sec $RC wf$1 | awk '/^token[ \t]*=/ { gsub(/"refresh_token"[ \t]*:[ \t]*"[^"]*"[ \t]*,?[ \t]*/, ""); gsub(/,[ \t]*}/, "}") } { print }'
if [ -f "${2%.conf}.x" ]; then cat "${2%.conf}.x"; fi; } > "$2.t" ) &&
mv -f "$2.t" "$2"
tok $RC wf$1 > "${2%.conf}.tk"
}
tfresh() {
[ -f "$2" ] || return 0
[ "$(tok $RC wf$1)" = "$(cat "${2%.conf}.tk" 2>/dev/null)" ] && ! grep -q '"refresh_token"' "$2" || ccopy "$1" "$2"
}
renew() {
_e=$(texp $RC wf$1)
case "$_e" in ''|*[!0-9-]*) return 0 ;; esac
[ "$_e" -lt 1200 ] || return 0
_l=$T/acct-$1.lock
if ! mkdir $_l 2>/dev/null; then
_p=$(cat $_l/pid 2>/dev/null)
[ -n "$_p" ] && ! kill -0 "$_p" 2>/dev/null || return 0
rm -rf $_l; mkdir $_l 2>/dev/null || return 0
fi
echo $$ > $_l/pid; echo "mnt-tok" > $_l/job
_k0=$(tok $RC wf$1); _f=$T/.mnt-$1.$$
( umask 077; { echo "[wf$1]"; sec $RC wf$1 | awk '/^token[ \t]*=/ { gsub(/"expiry"[ \t]*:[ \t]*"[^"]*"/, "\"expiry\":\"2000-01-01T00:00:00Z\"") } { print }'; } > $_f )
_kf=$(tok $_f wf$1); _to=; command -v timeout >/dev/null 2>&1 && _to="timeout 60"
$_to rclone lsf "wf$1:" --config $_f --max-depth 1 --dirs-only --retries 1 --low-level-retries 2 </dev/null >/dev/null 2>&1
if [ "$(tok $_f wf$1)" != "$_kf" ] && [ "$(tok $RC wf$1)" = "$_k0" ]; then
ucode "$CLOUDUC" rcput "$_f" </dev/null >/dev/null 2>&1 || log "token rinnovato non salvato (riprova al giro dopo)"
fi
rm -f $_f
[ "$(cat $_l/pid 2>/dev/null)" = $$ ] && rm -rf $_l
true
}

cdir() {
case $CACHE in
disk) [ -n "$DMP" ] && echo "$DMP/.wf-cloud-cache/$1" ;;
int) if ouse "$1"; then echo "$OLDC/$1"; else _i=$(cat $MD/intdir 2>/dev/null); [ -n "$_i" ] && echo "$_i/$1"; fi ;;
esac
}
kept() {
cat $R/etc/sysupgrade.conf $R/lib/upgrade/keep.d/* 2>/dev/null | sed 's/#.*//' | {
while read -r _k _x; do
[ -n "$_k" ] || continue; _k=${_k%/}; [ -n "$_k" ] || exit 0
case $1 in $_k|$_k/*) exit 0 ;; esac
done
exit 1
}
}
idir() {
_ov=$(awk '$2 == "/overlay" { o = ($3 == "tmpfs" || $3 == "ramfs") ? "ram" : ($4 ~ /^rw/ ? "y" : "ro") }
		$2 == "/" && $3 ~ /^(ext[234]|btrfs|f2fs|xfs)$/ && $4 ~ /^rw/ { d = 1 }
		END { print (o != "" ? o : (d ? "disk" : "ram")) }' $MOUNTS 2>/dev/null)
[ -d $MD ] || mkdir -p $MD
case $_ov in ram|'') rm -f $MD/intdir; return 1 ;; esac
[ "$_ov" = y ] && [ -d $R/overlay/upper ] || _ov=
for _c in ${_ov:+/overlay} /srv /opt /usr/share; do
_c=$_c/wf-cloud-cache; kept "$_c" && continue
[ "$(cat $MD/intdir 2>/dev/null)" = "$R$_c" ] || echo "$R$_c" > $MD/intdir
echo "$R$_c"; return 0
done
rm -f $MD/intdir; return 1
}
OLDC=$R/root/.wf-cloud-cache
ouse() {
_up=$(cat $MD/$1.pid 2>/dev/null)
[ -n "$_up" ] && [ -d /proc/$_up ] && case "$(cat $MD/$1.key 2>/dev/null)" in *"|$OLDC/$1") true ;; *) false ;; esac
}
omig() {
[ -d $OLDC/$1 ] && ! ouse "$1" || return 0
_od=$(idir) && ( umask 077; mkdir -p "$_od" ) 2>/dev/null && chmod 700 "$_od" 2>/dev/null || _od=
CD=${_od:+$_od/$1}; imig "$1"
}
imig() {
[ -d $OLDC ] || return 0
if [ -n "$1" ]; then
[ -d $OLDC/$1 ] || return 0
hasd $OLDC/$1/vfsMeta; _hv=$?; [ $_hv = 2 ] && { log "cache vecchia di $1 non letta: resta"; return 0; }
if [ $_hv = 0 ]; then
{ [ -n "$CD" ] && { hasd "$CD/vfsMeta"; [ $? = 1 ]; }; } || { log "cache vecchia di $1 non spostata"; return 0; }
rm -rf "$CD"; mkdir -p "${CD%/*}" && mv $OLDC/$1 "$CD" 2>/dev/null ||
{ [ -d $OLDC/$1 ] && rm -rf "$CD"; log "cache vecchia di $1 non spostata"; return 0; }
fi
rm -rf "${OLDC:?}/$1"
else
hasd $OLDC/*/vfsMeta; [ $? = 1 ] || return 0
for _q in $CL_PROC/[0-9]*/cmdline; do
[ -f "$_q" ] && tr '\0' ' ' < "$_q" 2>/dev/null | grep -q "$OLDC" && return 0
done
rm -rf $OLDC
fi
true
}
pfree() {
for _pp in $((${2:-35700} + ${1#a})) $(seq ${3:-35800} ${4:-35849}); do
_fh=$(printf ':%04X ' "$_pp")
cat /proc/net/tcp /proc/net/tcp6 2>/dev/null | awk -v h="$_fh" '$4 == "0A" && index($2 " ", h) { f = 1 } END { exit !f }' || { echo "$_pp"; return 0; }
done
return 1
}
rcpw() {
[ -s $MD/$1.rck ] || { [ -d $MD ] || mkdir -p $MD; ( umask 077; cat /proc/sys/kernel/random/uuid > $MD/$1.rck.t && mv -f $MD/$1.rck.t $MD/$1.rck ) 2>/dev/null; }
cat $MD/$1.rck 2>/dev/null
}
rcp() {
_rp=$(cat "$1" 2>/dev/null); [ -n "$_rp" ] || return 1
_ri=${1##*/}; _ri=${_ri%%.*}; _rw=$(cat $MD/$_ri.rck 2>/dev/null); _rc=$2; _ru=http://127.0.0.1:$_rp/; shift 2
_rj=$(ucode -e 'let o = {}; for (let i = 0; i + 1 < length(ARGV); i += 2) o[ARGV[i]] = ARGV[i + 1]; print(sprintf("%J", o), "\n");' "$@" </dev/null 2>/dev/null)
if command -v "${WF_CURL:-curl}" >/dev/null 2>&1; then
{ [ -n "$_rw" ] && printf 'user = "wf:%s"\n' "$_rw"; } | "${WF_CURL:-curl}" -s -m 3 -K - -X POST -H 'Content-Type: application/json' -d "$_rj" "$_ru$_rc"
else
_rt=; command -v timeout >/dev/null 2>&1 && _rt="timeout 3"
if [ -n "$_rw" ]; then
RCLONE_USER=wf RCLONE_PASS="$_rw" $_rt rclone rc --contimeout 3s --timeout 3s --url "$_ru" --json "$_rj" "$_rc" </dev/null
else
$_rt rclone rc --contimeout 3s --timeout 3s --url "$_ru" --json "$_rj" "$_rc" </dev/null
fi
fi 2>/dev/null
}
rcst() {
rcp "$1" vfs/stats | ucode -e '
		try { let j = json(require("fs").stdin.read("all") || "null"), d = j?.diskCache, a = d?.uploadsInProgress, b = d?.uploadsQueued;
			if (type(a) == "int" && type(b) == "int") print(a + b, " ", type(j?.inUse) == "int" ? j.inUse : 0, " ", type(d?.bytesUsed) == "int" ? d.bytesUsed : 0, "\n"); } catch (e) { }' 2>/dev/null
}
rcn() { _rs=$(rcst $MD/$1.port); [ -n "$_rs" ] && echo "${_rs%% *}"; true; }
rbw() {
[ "$(cat $MD/$1.bwl 2>/dev/null)" = "$2" ] && return 0
for _bp in $MD/$1.port $MD/$1.pport; do [ -f $_bp ] && rcp $_bp core/bwlimit rate "$2" >/dev/null; done
echo "$2" > $MD/$1.bwl
}
dcw() {
_dw=; [ -n "$CD" ] && _dw="$_mg $CD"
[ "$(cat $MR/.$1.dc 2>/dev/null)" = "$_dw" ] && return 0
[ -n "$_dw" ] || { rm -f $MR/.$1.dc; return 0; }
mkdir -p $MR && chmod 711 $MR && printf '%s\n' "$_dw" > $MR/.$1.dc.t && chmod 644 $MR/.$1.dc.t && mv -f $MR/.$1.dc.t $MR/.$1.dc
true
}
dirtyn() {
_fn=0
for _fx in "$1/vfsMeta" "$1/p/vfsMeta"; do
[ -n "$1" ] && [ -d "$_fx" ] || continue
_fy=$(grep -rlE '"Dirty": *true' "$_fx" 2>/dev/null; echo "x$?")
_fz=$(printf '%s\n' "$_fy" | sed '$d' | grep -c .); [ "${_fy##*x}" -ge 2 ] && [ "$_fz" = 0 ] && _fz=1
_fn=$((_fn + _fz))
done
echo $_fn
}
hasd() {
_hr=1
for _hx; do
[ -d "$_hx" ] || continue
grep -rqsE '"Dirty": *true' "$_hx"; case $? in 0) return 0 ;; 1) ;; *) _hr=2 ;; esac
done
return $_hr
}
flush1() {
_fe=$(( $(date +%s) + $2 )); _fc=$(cdir "$1"); _fo=
if [ "$CACHE" = int ]; then
if [ "$_fc" = "$OLDC/$1" ]; then _fo=$(cat $MD/intdir 2>/dev/null); _fo=${_fo:+$_fo/$1}; else _fo=$OLDC/$1; fi
fi
while :; do
_fa=$(rcn "$1"); _fa=${_fa:-0}; _fb=$(( $(dirtyn "$_fc") + $(dirtyn "$_fo") )); [ "$_fb" -gt "$_fa" ] && _fa=$_fb
[ "$_fa" = 0 ] && { echo 0; return 0; }
_fq=$(cat $MD/$1.pid 2>/dev/null)
{ [ -n "$_fq" ] && [ -d /proc/$_fq ] && [ "$(date +%s)" -lt $_fe ]; } || { echo "$_fa"; return 0; }
sleep 2
done
}

down() {
smboff "$1"
pdown "$1"
if mounted "$1"; then
fusermount3 -u -z $MR/$1 2>/dev/null || fusermount -u -z $MR/$1 2>/dev/null || umount -l $MR/$1 2>/dev/null
fi
_p=$(cat $MD/$1.pid 2>/dev/null)
if pvl "$_p" "$MR/$1"; then
kill -TERM "$_p" 2>/dev/null; _i=0
while [ -d /proc/$_p ] && [ $_i -lt 10 ]; do sleep 1; _i=$((_i + 1)); done
pvl "$_p" "$MR/$1" && kill -KILL "$_p" 2>/dev/null
fi
rm -f $MD/$1.pid $MD/$1.conf $MD/$1.tk $MD/$1.port $MD/$1.speed $MD/$1.boot $MD/$1.bw $MD/$1.du $MD/$1.nf $MD/$1.bwl; rmdir $MR/$1 2>/dev/null; true
}

boot_() {
_bp=$(cut -d' ' -f1 $MD/$1.boot 2>/dev/null)
[ -n "$_bp" ] && [ "$_bp" = "$(cat $MD/$1.pid 2>/dev/null)" ] && pvl "$_bp" "$MR/$1"
}
bwok() { _bq=$(cat $MD/$1.bw 2>/dev/null); [ -n "$_bq" ] && [ -d /proc/$_bq ]; }
bspawn() {
if command -v setsid >/dev/null 2>&1; then setsid sh "$D0/cloudmnt.sh" boot "$1" </dev/null >/dev/null 2>&1 &
else sh "$D0/cloudmnt.sh" boot "$1" </dev/null >/dev/null 2>&1 & fi
}
rsig() {
{ awk '$1 == "rchar:" || $1 == "wchar:" { printf "%s ", $2 }' /proc/$1/io 2>/dev/null
sed 's/.*) //' /proc/$1/stat 2>/dev/null | cut -d' ' -f12,13; wc -c < "$2" 2>/dev/null; } | tr '\n' ' '
}
lwhy() {
_lt=$(tail -c +$(( ${2:-0} + 1 )) "$1" 2>/dev/null); _e=fail
printf '%s' "$_lt" | grep -qiE 'invalid_grant|unauthori[sz]ed|401|token' && _e=acct
printf '%s' "$_lt" | grep -qiE 'fuse|fusermount' && _e=fuse
printf '%s' "$_lt" | grep -qiE 'no such host|network is unreachable|i/o timeout|connection refused' && _e=net
_ed=$(printf '%s\n' "$_lt" | grep -E 'ERROR|CRITICAL|Fatal|panic' | tail -n 1)
[ -n "$_ed" ] || _ed=$(printf '%s\n' "$_lt" | grep . | tail -n 1)
_ed=$(printf '%s' "$_ed" | sed -E 's/^[0-9]{4}\/[0-9]{2}\/[0-9]{2} [0-9:.]+ *//; s/^(ERROR|CRITICAL|NOTICE) *: *//; s/[[:cntrl:]]//g' | tr '|' '/' | cut -c1-160)
}
bend() {
cfg $1; nmof $1; MODE=$(cat $MD/$1.mode 2>/dev/null); SPD=$(cat $MD/$1.speed 2>/dev/null)
_bz=$(cat $MD/$1.csz 2>/dev/null); CMAX=$(( ${_bz:-0} * 1048576 )); CCAP=; [ "$4" = 1 ] && CCAP=1
_lw=; [ -f $MD/$1.low ] && _lw=mem_low
rm -f $MD/$1.boot $MD/$1.bw
[ "$ON" = 1 ] || { down $1; put $1 off; return 0; }
if mounted $1; then
ENG=$(eng) || { down $1; put $1 err smb; return 0; }
PL=$(cat $MD/$1.pl 2>/dev/null); smbon $1 $ENG; pbind $1; log "$NAME: accesa dopo $(( $(date +%s) - $2 )) s di avvio ($MODE, $SPD)"; put $1 on $_lw
return 0
fi
_bx=$(cut -d' ' -f1 $MD/$1.pid 2>/dev/null); _bl=
[ -n "$_bx" ] && [ -d /proc/$_bx ] && _bl=1
lwhy $T/log/mnt-$1 "$3"; down $1
if [ $_e = net ]; then put $1 wait net; return 0; fi
[ -n "$_bl" ] && [ -z "$_ed" ] && _ed="nessun montaggio dopo $(( ($(date +%s) - $2) / 60 )) min|not mounted after $(( ($(date +%s) - $2) / 60 )) min"
[ $_e = fail ] || _ed=
put $1 err $_e "$_ed"; log "$NAME: non montata ($_e${_ed:+: ${_ed%%|*}})"
}

cbusy() {
for _q in $CL_PROC/[0-9]*/cmdline; do [ -f "$_q" ] && tr '\0' ' ' < "$_q" 2>/dev/null | grep -qF -- "$1" && return 0; done
return 1
}
fdi() {
if command -v stat >/dev/null 2>&1; then stat -c "%d${2:+:%i}" "$1" 2>/dev/null; return; fi
_fp=$(cd -P -- "$1" 2>/dev/null && pwd) || return 1
_fd=$(awk -v p="$_fp" '{ m = $5; gsub(/\\040/, " ", m)
		if ((m == "/" || p == m || index(p, m "/") == 1) && length(m) >= l) { l = length(m); d = $3 } }
		END { if (d != "") print d }' /proc/self/mountinfo 2>/dev/null); [ -n "$_fd" ] || return 1
if [ -n "$2" ]; then echo "$_fd:$(ls -di "$1" 2>/dev/null | awk '{ print $1 }')"; else echo "$_fd"; fi
}
cold() {
_ci=; [ -n "$CD" ] && _ci=$(fdi "$CD" i)
cdirs "$1" | while IFS= read -r _d; do
{ [ "$_d" = "$CD" ] || [ "$_d" = "$OLDC/$1" ]; } && continue
[ -n "$_ci" ] && [ "$(fdi "$_d" i)" = "$_ci" ] && continue
cbusy "$_d" || echo "$_d"
done
}
fsid() { if [ -n "$CL_R" ] && [ -f "${1%/*}/.fsid" ]; then cat "${1%/*}/.fsid"; else fdi "$1"; fi; }
cdel() {
_dn="$1.del-$(date +%s)-$$"; mv "$1" "$_dn" 2>/dev/null || _dn=$1
( rm -rf "$_dn" ) </dev/null >/dev/null 2>&1 &
log "$NAME: cache di prima tolta ($1)"
}
cdelold() {
for _cb in $(cdirs "$1" | sed 's#/[^/]*$##' | sort -u) $(mnts | sed 's#$#/.wf-cloud-cache#'); do
for _cx in "$_cb/$1".del-*; do [ -d "$_cx" ] && { ( rm -rf "$_cx" ) </dev/null >/dev/null 2>&1 & }; done
done
true
}
ccopies() {
grep -rLE '"Dirty": *true' "$1/vfsMeta" 2>/dev/null | while IFS= read -r _cm; do
rm -f "$_cm" "$1/vfs/${_cm#"$1/vfsMeta/"}"
done
}
cmv() {
[ -d "$1/vfsMeta" ] || { echo 0; return 0; }
grep -rlE '"Dirty": *true' "$1/vfsMeta" 2>/dev/null | { _n=0
while IFS= read -r _mm; do
_mr=${_mm#"$1/vfsMeta/"}; _mt=$2/vfsMeta/$_mr; _mdt=$2/vfs/$_mr
[ -f "$1/vfs/$_mr" ] && ! grep -qsE '"Dirty": *true' "$_mt" || continue
mkdir -p "${_mt%/*}" "${_mdt%/*}" && mv -f "$1/vfs/$_mr" "$_mdt" && mv -f "$_mm" "$_mt" && _n=$((_n + 1))
done; echo $_n; }
}
cfast() {
cold "$1" > $MD/.co-$1.$$; _cf=; [ -n "$CD" ] && _cf=$(fsid "$CD")
while IFS= read -r _so; do
[ -n "$_so" ] || continue
[ "$(dirtyn "$_so")" = 0 ] && { cdel "$_so"; continue; }
[ -n "$_cf" ] && [ "$(fsid "$_so")" = "$_cf" ] || continue
_sn=$(( $(cmv "$_so" "$CD") + $(cmv "$_so/p" "$CD/p") ))
[ "${_sn:-0}" -gt 0 ] && log "$NAME: $_sn file non ancora nel cloud spostati da $_so nella cache in uso"
[ "$(dirtyn "$_so")" = 0 ] && cdel "$_so"
done < $MD/.co-$1.$$
rm -f $MD/.co-$1.$$
}
cneed() {
cold "$1" > $MD/.co-$1.$$; _cn=1
while IFS= read -r _so; do
[ -n "$_so" ] || continue
if [ "$(dirtyn "$_so")" = 0 ]; then cdel "$_so"; else _cn=0; fi
done < $MD/.co-$1.$$
rm -f $MD/.co-$1.$$; return $_cn
}
pspawn() {
_pq=$(cat $MD/$1.push 2>/dev/null); [ -n "$_pq" ] && [ -d /proc/$_pq ] && return 0
if command -v setsid >/dev/null 2>&1; then setsid sh "$D0/cloudmnt.sh" push "$1" </dev/null >/dev/null 2>&1 &
else sh "$D0/cloudmnt.sh" push "$1" </dev/null >/dev/null 2>&1 & fi
}
cfull() {
grep -rlE '"Dirty": *true' "$1/vfsMeta" 2>/dev/null | ucode -e '
		let fs = require("fs"), o = ARGV[0], p = o + "/vfsMeta/", pre = ARGV[1] + "/";
		for (let l in split(fs.stdin.read("all") ?? "", "\n")) {
			if (!length(l) || substr(l, 0, length(p)) != p) continue;
			let r = substr(l, length(p)), m = null;
			try { m = json(fs.readfile(l) ?? "null"); } catch (e) { }
			if (m?.Dirty !== true || substr(r, 0, length(pre)) != pre || length(r) <= length(pre)) continue;
			let z = m.Size, st = fs.stat(o + "/vfs/" + r);
			if (type(z) != "int" || st?.type != "file" || st.size != z) continue;
			let R = sort(filter(type(m.Rs) == "array" ? m.Rs : [], (x) => type(x?.Pos) == "int" && type(x?.Size) == "int"), (a, b) => a.Pos - b.Pos), e = 0;
			for (let x in R) { if (x.Pos > e) break; if (x.Pos + x.Size > e) e = x.Pos + x.Size; }
			if (e >= z) print(r, "\n");
		}' "$1" "$2" 2>/dev/null
}
pino() { ls -lnid "$1" 2>/dev/null | awk '$2 ~ /^-/ { print $1 ":" $6 }'; }
pok() {
ucode -e '
		let fs = require("fs"), m = null, st = fs.stat(ARGV[0] + "/vfs/" + ARGV[1]);
		try { m = json(fs.readfile(ARGV[0] + "/vfsMeta/" + ARGV[1]) ?? "null"); } catch (e) { }
		if (m?.Dirty !== true) exit(1);
		if (st == null) exit(2);
		let z = m.Size;
		if (st.type != "file" || type(z) != "int" || st.size != z) exit(1);
		let R = sort(filter(type(m.Rs) == "array" ? m.Rs : [], (x) => type(x?.Pos) == "int" && type(x?.Size) == "int"), (a, b) => a.Pos - b.Pos), e = 0;
		for (let x in R) { if (x.Pos > e) break; if (x.Pos + x.Size > e) e = x.Pos + x.Size; }
		exit(e >= z ? 0 : 1);' "$1" "$2" 2>/dev/null
}
corph() {
grep -rlE '"Dirty": *true' "$1/vfsMeta" 2>/dev/null | { _on=0
while IFS= read -r _om; do
[ -e "$1/vfs/${_om#"$1/vfsMeta/"}" ] || ! grep -qsE '"Size": *[0-9]' "$_om" || { rm -f "$_om"; _on=$((_on + 1)); }
done; echo $_on; }
}
pgone() {
[ "${1:-0}" -gt 0 ] || return 0
log "${NAME:+$NAME: }$1 file tolti dalla cache prima di arrivare nel cloud (tolti dalla coda)"
if _cl_en; then _cl_ev cloud_xfer_gone 86400 "⚠️ Cloud Folder ¦ $1 files removed before reaching the cloud ¦ Not uploaded"
else _cl_ev cloud_xfer_gone 86400 "⚠️ Cartella Cloud ¦ $1 file tolti prima di arrivare nel cloud ¦ Non caricati"; fi
}
ptoget() { F=$2 awk '{ o = $1; n = $2; sub(/^[^ ]* [^ ]* /, ""); if ($0 == ENVIRON["F"]) print o, n }' $MD/$1.pto 2>/dev/null | tail -n 1; }
ptoset() {
F=$2 awk '{ l = $0; sub(/^[^ ]* [^ ]* /, "", l); if (l != ENVIRON["F"]) print }' $MD/$1.pto > $MD/$1.pto.$$ 2>/dev/null
[ -n "$3" ] && echo "$3 $4 $2" >> $MD/$1.pto.$$
if [ -s $MD/$1.pto.$$ ]; then mv -f $MD/$1.pto.$$ $MD/$1.pto; else rm -f $MD/$1.pto.$$ $MD/$1.pto; fi
}
memcap() {
MGO=; MCG=; _mjt=; _mk=
_mjo=$(jsonfilter -i /tmp/wf-mem.json -e '@.t' -e "@.serv.$1.go" -e "@.serv.$1.cg" 2>/dev/null)
{ read -r _mjt; read -r _mk; read -r MCG; } <<X
$_mjo
X
case "$_mjt" in ''|*[!0-9]*) MCG=; return 1 ;; esac
case "$_mk" in ''|*[!0-9]*) MCG=; return 1 ;; esac
_mjn=$(date +%s); [ $((_mjn - _mjt)) -le 180 ] && [ $((_mjt - _mjn)) -le 180 ] || { MCG=; return 1; }
MGO=$((_mk / 1024))
case "$MCG" in "$R/sys/fs/cgroup/wrtfreedom/"[a-z]*) case "$MCG" in *..*) MCG= ;; esac ;; *) MCG= ;; esac
[ -n "$MCG" ] && [ ! -w "$MCG/cgroup.procs" ] && MCG=
return 0
}
pgl() {
_ga=$(awk '/^MemAvailable:/ { print $2; exit }' $CL_PROC/meminfo 2>/dev/null)
_gm=$(( (${_ga:-0} / 1024 - 80) / 2 )); [ $_gm -ge 30 ] || _gm=30; [ $_gm -le 100 ] || _gm=100; PGL=${_gm}MiB
}
pcopy() {
_crn=${6:-wf$3}; _cdst=${7:-$_crn:}
_cf=$1/vfs/$2; _co=$(ptoget $3 "$_cf"); _cn=0; [ -n "$_co" ] && _cn=${_co#* }
[ -n "$_co" ] && [ $(( $(date +%s) - ${_co%% *} )) -lt 3600 ] && return 2
pok "$1" "$2"; case $? in 0) ;; 2) rm -f "$1/vfsMeta/$2"; return 3 ;; *) return 2 ;; esac
_ci=$(pino "$_cf"); [ -n "$_ci" ] || { rm -f "$1/vfsMeta/$2"; return 3; }
_cz=${_ci#*:}; _cv=$(cat $MD/$3.pv 2>/dev/null); case "$_cv" in ''|0|*[!0-9]*) _cv=262144 ;; esac
_ck=$_cn; [ $_ck -le 3 ] || _ck=3
_cx=$(( (${WF_PUSHT0:-300} + _cz / _cv * 2) * (_ck + 1) )); _ct=$(date +%s); _cw=$MD/.pw-$3.$$; rm -f "$_cw"
( _cs=$(awk -v S="[${_cdst%%:*}]" '$0 == S { f = 1; next } /^\[/ { f = 0 }
		f && /^type *= */ { sub(/^type *= */, ""); t = $0 } f && /^provider *= */ { p = 1 }
		END { if (t == "alias" && p) t = "s3"; print t }' "$4" 2>/dev/null)
cl_env "$_cs"
if [ -n "$CL_MOK" ]; then
case "$CL_CG" in "$R/sys/fs/cgroup/wrtfreedom/"[a-z]*) case "$CL_CG" in *..*) CL_CG= ;; esac ;; *) CL_CG= ;; esac
else CL_CG=; pgl; export GOMEMLIMIT="$PGL"; fi
export GOGC=20; cl_in
exec rclone copyto "$_cf" "$_cdst${2#"$_crn"/}" --config "$4" --bwlimit "$CL_BW" $CL_RMEM \
		--retries 3 --low-level-retries 5 --log-level ERROR --log-file "$5" ) </dev/null >/dev/null 2>&1 &
_PP=$!
( while sleep "${WF_PUSHPOLL:-5}"; do
[ -d /proc/$_PP ] || exit 0
_gw=; _gi=$(pino "$_cf")
if [ -z "$_gi" ]; then _gw=3; elif [ "$_gi" != "$_ci" ]; then _gw=4; elif [ $(( $(date +%s) - _ct )) -ge $_cx ]; then _gw=5; fi
[ -n "$_gw" ] || continue
echo $_gw > "$_cw"; kill -TERM $_PP 2>/dev/null; sleep 5; [ -d /proc/$_PP ] && kill -KILL $_PP 2>/dev/null; exit 0
done ) </dev/null >/dev/null 2>&1 &
_cg=$!
wait $_PP; _cr=$?; _PP=
kill $_cg 2>/dev/null; _cs=$(cat "$_cw" 2>/dev/null); rm -f "$_cw"
case "$_cs" in
3) [ -e "$_cf" ] || rm -f "$1/vfsMeta/$2"; [ -n "$_co" ] && ptoset $3 "$_cf"; log "$NAME: caricamento fermato, file tolto dalla cache (${2#"$_crn"/})"; return 3 ;;
4) log "$NAME: caricamento fermato, file cambiato nella cache (${2#"$_crn"/})"; return 4 ;;
5) ptoset $3 "$_cf" "$(date +%s)" $((_cn + 1)); log "$NAME: caricamento fermato dopo $_cx s, riprova fra un'ora (${2#"$_crn"/})"; return 5 ;;
esac
[ $_cr = 0 ] || return 1
rm -f "$1/vfsMeta/$2" "$_cf"; [ -n "$_co" ] && ptoset $3 "$_cf"
_cd=$(( $(date +%s) - _ct )); [ $_cz -ge 1048576 ] && [ $_cd -gt 0 ] && echo $((_cz / _cd)) > $MD/$3.pv
return 0
}
mnts() { [ -f $MNTJ ] && ucode -e 'try { for (let k, v in json(require("fs").readfile(ARGV[0]))) if (type(v) == "string") print(v, "\n"); } catch (e) { }' $MNTJ 2>/dev/null; }
cdirs() {
{ _k=$(cat $MD/$1.key 2>/dev/null); [ -n "$_k" ] && echo "${_k##*|}"
mnts | while IFS= read -r _m; do echo "$_m/.wf-cloud-cache/$1"; done
for _c in /overlay /srv /opt /usr/share; do echo "$R$_c/wf-cloud-cache/$1"; done
echo "$OLDC/$1"; } | awk 'NF && !s[$0]++' | while IFS= read -r _d; do
case "$_d" in /*/"$1") [ -d "$_d" ] && echo "$_d" ;; esac
done
}
pendn() { cdirs "$1" | { _pn=0; while IFS= read -r _pd; do _pn=$((_pn + $(dirtyn "$_pd"))); done; echo $_pn; }; }
gflush() {
_fe=$(( $(date +%s) + $2 ))
while :; do
_fa=$(rcn "$1"); _fa=${_fa:-0}; _fb=$(pendn "$1"); [ "$_fb" -gt "$_fa" ] && _fa=$_fb
[ "$_fa" = 0 ] && { echo 0; return 0; }
_fq=$(cat $MD/$1.pid 2>/dev/null)
{ [ -n "$_fq" ] && [ -d /proc/$_fq ] && [ "$(date +%s)" -lt $_fe ]; } || { echo "$_fa"; return 0; }
sleep 2
done
}
cgone() {
_ck=$(dirtyn "$1")
if [ "$_ck" -gt 0 ] && [ "$2" != lose ]; then
_to="$1.tolto-$(date +%s)"
mv "$1" "$_to" 2>/dev/null || _to=$1
[ "$_to" != "$1" ] && [ -f "$MD/${1##*/}.gconf" ] && { mkdir -p $MD/tolto; cp -p "$MD/${1##*/}.gconf" "$MD/tolto/${_to##*/}.conf"; }
log "$NAME: $_ck file non ancora nel cloud, account tolto: cache tenuta in $_to"
else
rm -rf "$1"
[ "$_ck" -gt 0 ] && log "$NAME: account tolto, $_ck file non ancora nel cloud tolti (confermato)"
fi
true
}
gsave() { [ -f $MD/$1.conf ] && ( umask 077; cp $MD/$1.conf $MD/$1.gconf ) 2>/dev/null; true; }
drop() {
cdirs "$1" > $MD/.cd-$1.$$
while IFS= read -r _dd; do [ -n "$_dd" ] && cgone "$_dd" "$2"; done < $MD/.cd-$1.$$
rm -f $MD/.cd-$1.$$
for _df in $MD/$1.*; do [ "$_df" = $MD/$1.lock ] || rm -rf "$_df"; done
rm -f $T/log/mnt-$1 $T/log/mnt-$1.p $MR/.$1.dc $MR/.$1.df; rmdir $MR/$1 2>/dev/null; true
}
cbases() { mnts | while IFS= read -r _m; do echo "$_m/.wf-cloud-cache"; done
for _c in /overlay /srv /opt /usr/share; do echo "$R$_c/wf-cloud-cache"; done; echo "$OLDC"; }
osweep() {
cbases | while IFS= read -r _b; do
for _d in "$_b"/a*; do
_i=${_d##*/}; [ -d "$_d" ] && idok "$_i" && gone_ "$_i" || continue
[ -e $MD/$_i.pid ] && continue
NAME=; nmof "$_i"; cgone "$_d" keep
done
done
}
TOLTO_DAYS=7
tdirs() {
cbases | awk 'NF && !s[$0]++' | while IFS= read -r _b; do
for _d in "$_b"/a*.tolto-*; do
[ -d "$_d" ] || continue
_tb=${_d##*/}; idok "${_tb%%.tolto-*}" || continue
case "${_tb#*.tolto-}" in ''|*[!0-9]*) continue ;; esac
echo "$_d"
done
done
}

CRJ=$ETC/cloud-cifra.json
pers() {
case "$CPATH" in ''|Utenti) ;; *) return 0 ;; esac
[ -z "$PU" ] || return 0
[ -f "$CRJ" ] && [ -f "$RC" ] || return 0
_po=$(ID=$1 CRJ=$CRJ NJ=$NASJ ucode -e '
		let fs = require("fs"); function rj(p) { try { return json(fs.readfile(p) ?? "null"); } catch (e) { return null; } }
		let C = rj(getenv("CRJ")) ?? {}, a = C.accts?.[getenv("ID")], N = rj(getenv("NJ")) ?? {}, U = type(N.users) == "object" ? N.users : {};
		/* 19/11 (revisione R2): Disattiva mette on falso con st back: la vista resta (ramo «#back» di pxtra) */
		if (!match("" + (a?.st ?? ""), /^(mig|on|back)$/) || (C.on !== true && a.st != "back")) exit(0);
		/* 19/11 (G3): Disattiva in corso (back) = prima riga «#back» */
		if (a.st == "back") print("#back\n");
		print("admin\t\nshared\tS\n"); for (let u in sort(keys(U))) if (type(U[u]) == "object" && !U[u].cam) print(u, "\t", U[u].blocked === true ? "" : "1", "\n");' </dev/null 2>/dev/null)
[ -n "$_po" ] || return 0
_bk=; case "$_po" in '#back'*) _bk=b; _po=${_po#*"
"} ;; esac
_ul=; _nr=
if ! mounted "$1"; then
_pc=$MD/.pl-$1.conf; ccopy "$1" "$_pc"
_ul=$(rls "$_pc" "wf$1:Utenti") || _nr=1
rm -f "$_pc" "${_pc%.conf}.tk"
[ -z "$_nr" ] || return 3
fi
( WF_NASETC=$ETC WF_UCFGUC=${WF_UCFGUC:-$W/ucfg.uc}; export WF_NASETC WF_UCFGUC; . "$D0/lib.sh" || exit 0
_cs=; _nr=; _rb=Utenti/; [ "$CPATH" = Utenti ] && _rb=
while IFS='	' read -r _u _k; do
[ -n "$_u" ] || continue
_d=$(wf_udir "$_u" root) && _s=$(wf_crsec "$1" "$_u") || continue
_v=${_d#Utenti/}; case "$_v" in *[\"=\	]*) continue ;; esac
grep -qxF "[$_s]" "$RC" || continue
_cs="$_cs$_v
"
if mounted "$1"; then
[ -z "$_nr" ] || continue
dok "$MR/$1/$_rb$_v"; case $? in 0) ;; 2) _nr=1; continue ;; *) continue ;; esac
else
printf '%s\n' "$_ul" | grep -qxF -- "$_v" || continue
fi
printf '%s\t%s\t%s%s\n' "$_v" "$_s" "${_k:--}" "${_bk:+	$_bk}"
done <<X
$_po
X
printf '%s' "$_cs" > $MD/$1.crs.t && mv -f $MD/$1.crs.t $MD/$1.crs
[ -z "$_nr" ] || exit 3 )
}
tl() {
_tlS=$1 _tlO=$2; shift 2; _tlF=$MD/.tl$TLX.$$; rm -f $_tlF.p $_tlF.e
( "$@" > "$_tlO" 2>/dev/null </dev/null & echo $! > $_tlF.p; wait $!; echo $? > $_tlF.e ) >/dev/null 2>&1 &
_tlP=$! _tlI=0
while [ ! -s $_tlF.e ] && [ $_tlI -lt $((_tlS * 20)) ]; do
if sleep 0.05 2>/dev/null; then _tlI=$((_tlI + 1)); else sleep 1; _tlI=$((_tlI + 20)); fi
done
if [ ! -s $_tlF.e ]; then kill -KILL $(cat $_tlF.p 2>/dev/null) $_tlP 2>/dev/null; rm -f $_tlF.p $_tlF.e; return 124; fi
wait $_tlP 2>/dev/null; _tlR=$(cat $_tlF.e); rm -f $_tlF.p $_tlF.e; return ${_tlR:-1}
}
dokx() { ls -d "$1/." 2>&1; }
dok() {
_dkf=$MD/.dk$TLX.$$; tl 10 $_dkf dokx "$1"; _dkr=$?
case $_dkr in 0) rm -f $_dkf; return 0 ;; 124) rm -f $_dkf; return 2 ;; esac
grep -qiE 'no such file|not a directory' $_dkf 2>/dev/null; _dkr=$?; rm -f $_dkf
[ $_dkr = 0 ] && return 1; return 2
}
rls() {
tl "${WF_RLST:-40}" $MD/.rls.$$ rclone lsf --dirs-only --max-depth 1 --config "$1" --contimeout 10s --timeout 20s --retries 1 \
		--low-level-retries 1 "$2"
case $? in 0) sed 's#/$##' $MD/.rls.$$ ;; 3) ;; *) rm -f $MD/.rls.$$; return 1 ;; esac
rm -f $MD/.rls.$$; return 0
}
pshv() { printf '%s\n' "$PL" | awk -F'\t' '$3 == "S" { print $1; exit }'; }
pxtra() {
[ -n "$PL" ] || { rm -f $MD/$1.x; return 0; }
( umask 077; _n=0 _cu= _cs=
{ while IFS='	' read -r _v _s _k _bk; do
[ -n "$_v" ] && [ -n "$_s" ] && grep -qxF "[$_s]" "$RC" || continue
_n=$((_n + 1)); _cu="$_cu \"$_v=wf$1u$_n:\""
printf '\n[%s]\n' "$_s"; sec $RC "$_s"
_x=; [ "$_k" = 1 ] && [ -n "$_cs" ] && _x=' wf'$1's::ro'
if [ "$_bk" = b ]; then
printf '\n[wf%su%s]\ntype = union\nupstreams = "wf%s:Utenti/%s" %s:%s\ncreate_policy = ff\n' "$1" $_n "$1" "$_v" "$_s" "$_x"
else
printf '\n[wf%su%s]\ntype = union\nupstreams = %s: "wf%s:Utenti/%s:nc"%s\ncreate_policy = ff\n' "$1" $_n "$_s" "$1" "$_v" "$_x"
fi
[ "$_k" = S ] && { _cs=1; printf '\n[wf%ss]\ntype = combine\nupstreams = "%s=wf%su%s:"\n' "$1" "$_v" "$1" $_n; }
done <<X
$PL
X
printf '\n[wf%sp]\ntype = combine\nupstreams =%s\n' "$1" "$_cu"; } > $MD/$1.x )
}
mntd() { _me=$(printf '%s' "$1" | sed 's/ /\\040/g'); ME=$_me awk '$2 == ENVIRON["ME"] { f = 1 } END { exit !f }' $MOUNTS 2>/dev/null; }
PMG=$R/tmp/wf-mem.margine
pmgon() {
_pmm=0
[ -n "$_mcg" ] && [ -w "$_mcg/memory.high" ] || return 0
_pmh=$(cat "$_mcg/memory.high" 2>/dev/null); case "$_pmh" in ''|*[!0-9]*) return 0 ;; esac
_pma=$(awk '/^MemAvailable:/ { print int($2 / 1024); exit }' $CL_PROC/meminfo 2>/dev/null)
case "$_pma" in ''|*[!0-9]*) return 0 ;; esac
_pmn=$(date +%s); _pme=; read -r _pmx _pme _pmx 2>/dev/null < $PMG
case "$_pme" in ''|*[!0-9]*) ;; *) [ "$_pme" -gt "$_pmn" ] && return 0 ;; esac
_pmm=$((_pma - 60)); [ $_pmm -le "${WF_PMARG:-160}" ] || _pmm=${WF_PMARG:-160}
[ $_pmm -ge 32 ] || { _pmm=0; return 1; }
echo "$_pmm $((_pmn + ${WF_PMT:-600} + 60)) $_mcg" > $PMG.$$ && mv -f $PMG.$$ $PMG || { _pmm=0; return 0; }
echo $((_pmh + _pmm * 1048576)) > "$_mcg/memory.high" 2>/dev/null || { rm -f $PMG; _pmm=0; return 0; }
log "$NAME: vista: partenza con margine di $_pmm MB"
}
pmgoff() {
_pmx=; _pmy=; read -r _pmx _pmy _pmz 2>/dev/null < $PMG
[ "$_pmx" = "$1" ] && [ "$_pmz" = "$2" ] || return 0
_pmh=$(cat "$2/memory.high" 2>/dev/null)
case "$_pmh" in ''|*[!0-9]*) ;; *) [ "$_pmh" -gt $(($1 * 1048576)) ] && echo $((_pmh - $1 * 1048576)) > "$2/memory.high" 2>/dev/null ;; esac
rm -f $PMG
}
pmgwait() {
trap 'pmgoff "$4" "$5"; exit 0' INT TERM HUP
_pwi=0; _pwr=
while [ $_pwi -lt "${WF_PMT:-600}" ]; do
if [ $_pwi -lt 5 ]; then [ -d /proc/$2 ] || break; else pvl "$2" "$MR/$1.p" || break; fi
if mntd "$MR/$1.p" && { dok "$MR/$1.p"; [ $? != 2 ]; }; then _pwr=1; break; fi
sleep 1; _pwi=$((_pwi + 1))
done
pmgoff "$4" "$5"
if [ -n "$_pwr" ]; then log "$NAME: vista montata in $(( $(date +%s) - $3 )) s"
else log "$NAME: vista non montata, margine di $4 MB tolto"; fi
}
pup() {
rm -f $MD/$1.pmem; _pmm=0
[ -n "$PL" ] || return 0
_pi=$1
case "$_pgl" in *MiB) [ "${_pgl%MiB}" -ge 32 ] || { log "$NAME: vista delle cartelle private non accesa (memoria)"; : > $MD/$_pi.pmem; return 0; } ;; esac
[ -f $W/mem.uc ] && { ucode $W/mem.uc check rclone </dev/null >/dev/null 2>&1; [ $? = 1 ] && { log "$NAME: vista delle cartelle private non accesa (memoria del recinto)"; : > $MD/$_pi.pmem; return 0; }; }
pmgon || { log "$NAME: vista delle cartelle private non accesa (memoria disponibile per la partenza)"; : > $MD/$_pi.pmem; return 0; }
set -- --vfs-cache-mode $MODE
if [ -n "$CD" ]; then
mkdir -p "$CD/p"; pfix "$CD/p"
[ "${_pz:-0}" -gt 0 ] 2>/dev/null || _pz=256
set -- "$@" --cache-dir "$CD/p" --vfs-cache-max-size ${_pz}M --vfs-cache-max-age 24h --vfs-cache-poll-interval 5m \
			--vfs-cache-min-free-space ${_mgg:-2G}
fi
[ -n "$_ra" ] && set -- "$@" --vfs-read-ahead $_ra
[ -n "$_ck" ] && set -- "$@" --vfs-read-chunk-size $_ck
_pb=$_b _ptf=$_tf; [ "$_tr" = A ] && _pb=0 _ptf=1
[ -n "$_ptf" ] && set -- "$@" --transfers $_ptf
if [ "$RW" = 1 ]; then set -- "$@" --vfs-write-back 60s; else set -- --read-only "$@"; fi
_pdt=; read -r _pdt _pdf _pdx 2>/dev/null < $MR/.$_pi.df; case "$_pdt" in ''|*[!0-9]*) ;; *) set -- "$@" --vfs-disk-space-total-size ${_pdt}B ;; esac
_sv=$(pshv); [ -n "$_sv" ] && set -- "$@" --exclude "/*/$_sv/{{$CRX}}" --exclude "/*/$_sv/{{$CRX}}/**"
_pdp=$_dp _pfp=$_fp; [ "$RW" = 1 ] && _pdp=0777 _pfp=0666
set -- "$@" --disable ChangeNotify
_pdc=10m; [ "$_tr" = A ] && _pdc=1m
rm -f $MD/$_pi.pport; _ppt=$(pfree $_pi 35900 35850 35899) && { set -- "$@" --rc --rc-addr "127.0.0.1:$_ppt"; echo "$_ppt" > $MD/$_pi.pport; }
_rk=$(rcpw $_pi)
mkdir -p $MR/$_pi.p && chmod 711 $MR/$_pi.p
_plg=$T/log/mnt-$_pi.p; [ -f $_plg ] && [ "$(wc -c < $_plg)" -gt 65536 ] && : > $_plg
( [ -n "$_gc" ] && export GOGC=$_gc; [ -n "$_mcg" ] && echo 0 > "$_mcg/cgroup.procs" 2>/dev/null
[ -n "$_ppt" ] && [ -n "$_rk" ] && export RCLONE_RC_USER=wf RCLONE_RC_PASS="$_rk"
exec env GOMEMLIMIT=${_pgl:-$_gl} rclone mount "wf${_pi}p:" $MR/$_pi.p --config $MD/$_pi.conf --allow-other \
		"$@" --buffer-size $_pb --dir-cache-time $_pdc --poll-interval 0 --attr-timeout 10s --dir-perms $_pdp --file-perms $_pfp --umask 000 --use-mmap \
		--exclude "/*/{{$CRX}}" --exclude "/*/{{$CRX}}/**" \
		--bwlimit "$CL_BW" --log-level ERROR --log-file $_plg ) </dev/null >/dev/null 2>&1 &
_ppd=$!; echo $_ppd > $MD/$_pi.ppid; date +%s > $MD/$_pi.pt
[ "$_pmm" -gt 0 ] && { ( pmgwait $_pi $_ppd "$(cat $MD/$_pi.pt)" $_pmm "$_mcg" ) </dev/null >/dev/null 2>&1 & }
return 0
}
pfix() {
[ -d "$1/vfsMeta" ] || return 0
ucode -e '
		let fs = require("fs"), B = ARGV[0], n = 0;
		function walk(r, k) {
			if (k > 64) return;
			for (let e in fs.lsdir(B + "/vfsMeta" + r) ?? []) {
				let p = r + "/" + e, s = fs.lstat(B + "/vfsMeta" + p);
				if (s?.type == "directory") { walk(p, k + 1); continue; }
				if (s?.type != "file") continue;
				let t = fs.readfile(B + "/vfsMeta" + p), m = null; try { m = json(t ?? ""); } catch (x) { m = null; }
				if (t == null || match(t, /"Dirty": *true/) || (type(m) == "object" && m.Dirty === true)) continue;
				let d = fs.stat(B + "/vfs" + p);
				if (type(m) != "object" || (d?.type == "file" && type(m.Size) == "int" && d.size > m.Size)) {
					fs.unlink(B + "/vfsMeta" + p); if (d?.type == "file") fs.unlink(B + "/vfs" + p); n++;
				}
			}
		}
		walk("", 0); if (n) print(n, "\n");' "$1" </dev/null 2>/dev/null | { read -r _fn && log "$NAME: $_fn voci rovinate tolte dalla cache della vista"; true; }
}
CRX='(?:[0-9a-v]{26}|[0-9a-v]{52}|[0-9a-v]{77}|[0-9a-v]{103}|[0-9a-v]{128}|[0-9a-v]{154}|[0-9a-v]{180}|[0-9a-v]{205}|[0-9a-v]{231}|[0-9a-v]{256})'
pvivo() { [ -z "$PL" ] && return 0; pvl "$(cat $MD/$1.ppid 2>/dev/null)" "$MR/$1.p"; }
pvok() {
[ -z "$PL" ] && return 0
if ! mntd "$MR/$1.p"; then
pvivo $1 || return 0
_pt=$(cat $MD/$1.pt 2>/dev/null); case "$_pt" in ''|*[!0-9]*) return 0 ;; esac
[ $(( $(date +%s) - _pt )) -le 60 ]; return
fi
[ -f $MD/$1.pport ] && [ -z "$(rcst $MD/$1.pport)" ] && return 1
dok "$MR/$1.p"; [ $? != 2 ]
}
pvl() {
[ -n "$1" ] && [ -d /proc/$1 ] || return 1
case " $(tr '\0' ' ' < /proc/$1/cmdline 2>/dev/null) " in *rclone*" $2 "*) return 0 ;; esac
return 1
}
dk() { dok "$1"; case $? in 0) return 0 ;; 2) DKH=1 ;; esac; return 1; }
pclr() { ( WF_NASETC=$ETC; export WF_NASETC; . "$D0/lib.sh" || exit 0
for _k in pub lnk inbox; do _d=$(wf_udir admin $_k) && echo "${_d##*/}"; done; wf_udir admin wf ); }
pbind() {
[ -n "$PL" ] && mounted "$1" && mntd "$MR/$1.p" || return 0
_pr=Utenti/; [ "$CPATH" = Utenti ] && _pr=; _sv=$(pshv); _pn=$(pclr); DKH=
_pw=$(printf '%s\n' "$_pn" | grep /); _pn=$(printf '%s\n' "$_pn" | grep -v /)
while IFS='	' read -r _v _s _k _bk; do
[ -n "$_v" ] || continue
_pc="$MR/$1.p/$_v/$_sv"
[ "$_k" = 1 ] && [ -n "$_sv" ] && ! mntd "$_pc" && dk "$MR/$1.p/$_sv" && dk "$_pc" &&
{ tl 10 /dev/null mount -o bind "$MR/$1.p/$_sv" "$_pc" 2>/dev/null || log "$NAME: $_sv di $_v non montata"; }
[ -z "$DKH" ] || return 0
_pt="$MR/$1/$_pr$_v"
if [ "$_k" != S ]; then
_pm=$_pn; [ "Utenti/$_v" = "${_pw%/*}" ] && _pm="$_pm
${_pw##*/}"
_pz=
while IFS= read -r _n; do
[ -n "$_n" ] && ! mntd "$MR/$1.p/$_v/$_n" && dk "$MR/$1.p/$_v/$_n" && _pz="$_pz$_n
"
[ -z "$DKH" ] || return 0
done <<X
$_pm
X
if [ -n "$_pz" ]; then
mntd "$_pt" && tl 10 /dev/null umount -l "$_pt"
while IFS= read -r _n; do
[ -n "$_n" ] || continue
dk "$_pt/$_n" && { tl 10 /dev/null mount -o bind "$_pt/$_n" "$MR/$1.p/$_v/$_n" 2>/dev/null || log "$NAME: $_n di $_v non montata"; }
[ -z "$DKH" ] || return 0
done <<X
$_pz
X
fi
fi
dk "$MR/$1.p/$_v" && dk "$_pt" && { mntd "$_pt" || tl 10 /dev/null mount -o bind "$MR/$1.p/$_v" "$_pt" 2>/dev/null || log "$NAME: cartella di $_v non montata"; }
[ -z "$DKH" ] || return 0
done <<X
$PL
X
}
pdown() {
_pq=$(cat $MD/$1.ppid 2>/dev/null)
if [ -f $MD/$1.pport ] && pvl "$_pq" "$MR/$1.p"; then
_pe=$(( $(date +%s) + ${WF_PFLUSH:-60} ))
while _ps=$(rcst $MD/$1.pport) && [ -n "$_ps" ]; do
set -- "$1" $_ps; [ "$2" = 0 ] && [ "$3" = 0 ] && break
[ "$(date +%s)" -lt $_pe ] || { log "${NAME:-$1}: vista fermata con $2 file non ancora nel cloud"; break; }
sleep 2; set -- "$1"
done
set -- "$1"
fi
awk -v m="$MR/$1/" -v n="$MR/$1.p/" 'index($2, m) == 1 || index($2, n) == 1 { print $2 }' $MOUNTS 2>/dev/null | sort -r | sed 's/\\040/ /g' | while IFS= read -r _m; do
tl 10 /dev/null umount -l "$_m"
done
mntd "$MR/$1.p" && { fusermount3 -u -z $MR/$1.p 2>/dev/null || fusermount -u -z $MR/$1.p 2>/dev/null || umount -l $MR/$1.p 2>/dev/null; }
if pvl "$_pq" "$MR/$1.p"; then
kill -TERM "$_pq" 2>/dev/null; _i=0
while [ -d /proc/$_pq ] && [ $_i -lt 30 ]; do sleep 1; _i=$((_i + 1)); done
pvl "$_pq" "$MR/$1.p" && kill -KILL "$_pq" 2>/dev/null
fi
rm -f $MD/$1.ppid $MD/$1.pport $MD/$1.pt; rmdir $MR/$1.p 2>/dev/null; true
}
mopts() {
_gc=; [ "$_tr" = A ] && _gc=20
_mcg=
if memcap rclone; then _gn=$MGO _mcg=$MCG
else _gn=$(( ${_ma:-0} / 1024 - 80 )); [ $_gn -ge 60 ] || _gn=60; [ $_gn -le 200 ] || _gn=200; fi
_gl=${_gn}MiB _pgl=
{ [ "$CRON" = 1 ] || [ -n "$PL" ]; } && _gl=$((_gn * 6 / 10))MiB _pgl=$((_gn * 4 / 10))MiB
if [ -n "$_pgl" ] && [ "${_pgl%MiB}" -lt 32 ]; then _pgl=32MiB; _gl=$((_gn - 32)); [ $_gl -ge 40 ] || _gl=40; _gl=${_gl}MiB; fi
_tf='' _ck=''
if [ $SPD = fast ]; then
_b=16M _ra=64M _tf=4 _ck=16M
[ "$_tr" = A ] && _b=0 _tf=2
case $CACHE in
none) MODE=off _ra=32M _ck='' _tf='' ;;
int) MODE=full ;;
*) case "$_fs" in ext[234]|btrfs|xfs|f2fs) MODE=full ;; *) MODE=minimal ;; esac ;;
esac
case $_tr in A) _dc=1m ;; *) _dc=10m ;; esac
else
_b=0 _ra='' _dc=1m _tf=1
MODE=minimal; [ "$CACHE" = none ] && MODE=off
fi
[ "$RW" = 1 ] && [ $MODE != full ] && MODE=writes
_dp=0555 _fp=0444; [ "$RW" = 1 ] && _dp=0777 _fp=0666
true
}
prem() {
mopts; rm -f $MD/.$1.xo; [ -f $MD/$1.x ] && cp -p $MD/$1.x $MD/.$1.xo; pxtra $1
if [ -n "$PL" ] && pvivo $1 && pvok $1; then
if [ -f $MD/.$1.xo ] && cmp -s $MD/$1.x $MD/.$1.xo; then rm -f $MD/.$1.xo; printf '%s' "$PL" > $MD/$1.pl; return 0; fi
if [ -f $W/mem.uc ]; then
ucode $W/mem.uc check rclone </dev/null >/dev/null 2>&1
[ $? = 1 ] && { [ -f $MD/.$1.xo ] && mv -f $MD/.$1.xo $MD/$1.x; log "$NAME: vista delle cartelle private tenuta com'è (memoria del recinto)"; : > $MD/$1.pmem; return 0; }
fi
fi
rm -f $MD/.$1.xo
pdown $1; ccopy $1 $MD/$1.conf; pup $1
_i=0; while [ -n "$PL" ] && ! mntd "$MR/$1.p" && [ $_i -lt 5 ] && pvivo $1; do sleep 1; _i=$((_i + 1)); done
printf '%s' "$PL" > $MD/$1.pl
rm -f $MD/$1.pbad
if [ -n "$PL" ] && mntd "$MR/$1.p" && { dok "$MR/$1.p"; [ $? != 2 ]; }; then
SMBNEW=1; mounted $1 && smbon $1 ${ENG:-$(eng)}; pbind $1; SMBNEW=
log "$NAME: vista delle cartelle private pronta, sezioni rifatte"
elif [ -n "$PL" ] && pvivo $1; then pwspawn $1; fi
log "$NAME: vista delle cartelle private rifatta"
}
pwok() {
_wq=$(cat $MD/$1.pw 2>/dev/null); [ -n "$_wq" ] && [ -d /proc/$_wq ] || return 1
case "$(tr '\0' ' ' < /proc/$_wq/cmdline 2>/dev/null)" in *cloudmnt.sh*pwait*) return 0 ;; esac
return 1
}
pwspawn() {
pwok $1 && return 0
if command -v setsid >/dev/null 2>&1; then setsid sh "$D0/cloudmnt.sh" pwait "$1" </dev/null >/dev/null 2>&1 &
else sh "$D0/cloudmnt.sh" pwait "$1" </dev/null >/dev/null 2>&1 & fi
echo $! > $MD/$1.pw
}
pabout() {
[ -f $MD/$1.conf ] || return 0
_an=$(date +%s); _at=; read -r _a1 _a2 _at 2>/dev/null < $MR/.$1.df
case "$_at" in ''|*[!0-9]*) ;; *) [ $((_an - _at)) -lt 21600 ] && [ $((_at - _an)) -lt 60 ] && return 0 ;; esac
_ak=$(cat $MD/$1.abt 2>/dev/null); case "$_ak" in ''|*[!0-9]*) ;; *) [ $((_an - _ak)) -lt 600 ] && return 0 ;; esac
echo "$_an" > $MD/$1.abt
( TLX=ab; tl 60 $MD/.ab-$1 rclone about "wf$1:" --json --config $MD/$1.conf --contimeout 10s --timeout 30s --retries 1 --low-level-retries 1 &&
ucode -e 'let a = null; try { a = json(require("fs").readfile(ARGV[0]) ?? "null"); } catch (e) { }
			if (type(a?.total) == "int" && type(a?.free) == "int" && a.total > 0 && a.free >= 0) print(a.total, " ", a.free, " ", time(), "\n");' \
			$MD/.ab-$1 > $MR/.$1.df.t 2>/dev/null && [ -s $MR/.$1.df.t ] && chmod 644 $MR/.$1.df.t && mv -f $MR/.$1.df.t $MR/.$1.df
rm -f $MD/.ab-$1 $MR/.$1.df.t ) </dev/null >/dev/null 2>&1 &
}
ckx() {
_xn=$(cat $T/log/mnt-$1 $T/log/mnt-$1.p 2>/dev/null | grep -ci 'failed to upload'); _xn=${_xn:-0}
_xo=$(cat $MD/$1.fu 2>/dev/null); case "$_xo" in ''|*[!0-9]*) _xo=0 ;; esac; [ "$_xn" -lt "$_xo" ] && _xo=0
if [ "$_xn" -gt "$_xo" ]; then
log "$NAME: $((_xn - _xo)) caricamenti non riusciti (rclone riprova)"
if _cl_en; then _cl_ev cloud_up_fail 86400 "⚠️ Cloud Folder ¦ $((_xn - _xo)) uploads failed ¦ Retrying"
else _cl_ev cloud_up_fail 86400 "⚠️ Cartella Cloud ¦ $((_xn - _xo)) caricamenti non riusciti ¦ Riprova da sola"; fi
fi
[ -d $MD ] && echo "$_xn" > $MD/$1.fu
[ -f $MD/$1.conf ] && mounted $1 || return 0
_xt=$(date +%s); _xa=$(cat $MD/$1.pa 2>/dev/null); case "$_xa" in ''|*[!0-9]*) _xa=0 ;; esac
[ $((_xt - _xa)) -ge 21600 ] || return 0
[ "$(rcn $1)" = 0 ] || return 0
[ -f $MD/$1.pport ] && { _xq=$(rcst $MD/$1.pport); [ "${_xq%% *}" = 0 ] || return 0; }
echo "$_xt" > $MD/$1.pa
( TLX=pa; tl 300 /dev/null rclone delete "wf$1:$CPATH" --include '*{{\.[0-9a-f]{1,8}\.partial}}' --min-age 1h --config $MD/$1.conf \
		--contimeout 10s --timeout 30s --retries 1 --low-level-retries 1 ) </dev/null >/dev/null 2>&1 &
}

up() {
id=$1; MODE=; ENG=; CUK=''; CUD=''
[ "$CFGD" = "$id" ] || cfg $id; CFGD=
[ "$ON" = 1 ] || { down $id; put $id off; return 0; }
[ "$PBAD" = 0 ] || { down $id; put $id err "$([ "$PBAD" = 2 ] && echo name || echo path)"; return 3; }
PL=
[ -z "$PU" ] || [ "$PUOK" = 1 ] || { down $id; put $id err puser; return 3; }
_tr=$(cl_tier)
if [ "$_tr" = A ]; then
[ "$WOK" = 1 ] || { down $id; put $id err warn; return 3; }
for _f in $MD/a*.pid; do
_o=${_f##*/}; _o=${_o%.pid}; [ -f "$_f" ] && [ "$_o" != "$id" ] || continue
_q=$(cat "$_f" 2>/dev/null); [ -n "$_q" ] && [ -d /proc/$_q ] && { down $id; put $id err many; return 3; }
done
fi
command -v rclone >/dev/null 2>&1 || { down $id; put $id err pkg; return 3; }
command -v fusermount3 >/dev/null 2>&1 || command -v fusermount >/dev/null 2>&1 || { down $id; put $id err fuse; return 3; }
[ -e $R/dev/fuse ] || modprobe fuse 2>/dev/null || insmod fuse 2>/dev/null
[ -e $R/dev/fuse ] || { down $id; put $id err fuse; return 3; }
[ "$AOK" = 1 ] && [ -n "$(sec $RC wf$id)" ] || { down $id; put $id err acct; return 3; }
ENG=$(eng) || { down $id; put $id err smb; return 3; }
[ -n "$USERS" ] || { down $id; put $id err users; return 3; }
_cx=$(clash $id) && { down $id; put $id err "$_cx"; return 3; }
[ "$RW" = 1 ] && [ "$CACHE" = none ] && { down $id; put $id err cache; return 3; }
CD=; _fs=; _csz=0; _fk=0; CCAP=; _mg=0 _mgg=
case $CACHE in
disk)
_fs=$(dfs "$DMP")
[ -n "$_fs" ] || { down $id; put $id wait disk; return 4; }
CD=$DMP/.wf-cloud-cache/$id; _mg=2097152 _mgg=2G
mkdir -p "$CD" 2>/dev/null && tl 10 /dev/null touch "$CD/.wf" || { down $id; put $id wait ro; return 4; }
_a=$(df -kP "$DMP" 2>/dev/null | awk 'NR == 2 { print $4 }'); _u=$(cdu $id "$CD"); CUK=$_u CUD=$CD
_fr=$(( ${_a:-0} / 1048576 )); _fk=$(( ${_a:-0} + ${_u:-0} ))
[ "$_fr" -ge 1 ] || { down $id; put $id wait full; return 4; }
if [ "$GB" -gt 0 ]; then
_g=$GB; [ $((_fk / 1048576 - 2)) -lt "$_g" ] && _g=$((_fk / 1048576 - 2)); [ "$_g" -ge 1 ] || _g=1
[ "$_g" -lt "$GB" ] && CCAP=1; _csz=$((_g * 1024))
fi ;;
int)
_id=$(idir); CD=${_id:+$_id/$id}; _mg=1048576 _mgg=1G
if [ -d $OLDC/$id ]; then
if { hasd $OLDC/$id/vfsMeta; [ $? != 1 ]; } && ouse $id; then CD=$OLDC/$id
else down $id; imig $id; [ -d $OLDC/$id ] && CD=$OLDC/$id; fi
fi
[ -n "$CD" ] || { down $id; put $id err space; return 3; }
( umask 077; mkdir -p ${_id:+"$_id"} "$CD" ) 2>/dev/null && chmod 700 ${_id:+"$_id"} "$CD" 2>/dev/null &&
tl 10 /dev/null touch "$CD/.wf" || { down $id; put $id err space; return 3; }
_a=$(df -kP "${CD%/*/*}" 2>/dev/null | awk 'NR == 2 { print $4 }'); _u=$(cdu $id "$CD"); CUK=$_u CUD=$CD
_fk=$(( ${_a:-0} + ${_u:-0} )); _fr=$(( _fk / 1048576 ))
if [ "$GB" -gt 0 ]; then
_g=$GB; [ $((_fr - 1)) -lt "$_g" ] && _g=$((_fr - 1))
[ "$_g" -ge 1 ] || { down $id; put $id err space; return 3; }
_csz=$((_g * 1024))
else
[ "$_fr" -ge 1 ] || { down $id; put $id err space; return 3; }
fi ;;
esac
if [ -n "$CD" ] && [ "$GB" = 0 ]; then
_csz=$((_fk / 4096)); [ "$_csz" -ge 256 ] || _csz=256
_o=$(cat $MD/$id.csz 2>/dev/null)
case "$_o" in ''|*[!0-9]*) ;; *) _d=$((_csz - _o)); [ $_d -lt 0 ] && _d=$((-_d)); [ "$_o" -gt 0 ] && [ $((_d * 5)) -le "$_o" ] && _csz=$_o ;; esac
fi
_pz=0
if [ "$CRON" = 1 ] && [ -n "$CD" ]; then
_pz=$((_csz / 2)); [ $_pz -ge 256 ] || _pz=256
_lm=$(( (_fk - _mg) / 1024 ))
if [ $((_csz + _pz)) -gt $_lm ]; then
_pz=$((_lm / 3)); [ $_pz -ge 256 ] || _pz=256; _csz=$((_lm - _pz)); [ $_csz -ge 256 ] || _csz=256
[ "$GB" -gt 0 ] && CCAP=1
fi
fi
CMAX=$((_csz * 1048576))
dcw $id
_ma=$(awk '/^MemAvailable:/ { print $2; exit }' $CL_PROC/meminfo 2>/dev/null)
_p=$(cat $MD/$id.pid 2>/dev/null); _run='' _bt=''
if pvl "$_p" "$MR/$id"; then if mounted $id; then _run=1; elif boot_ $id; then _run=1 _bt=1; fi; fi
if ! cl_check "mnt-$id" '{"mode":"same"}' >/dev/null; then
_w=$CL_WHY
if [ -n "$_run" ] && [ -z "$_bt" ]; then
_nf=$(cat $MD/$id.nf 2>/dev/null); case "$_nf" in ''|*[!0-9]*) _nf=0 ;; esac; _nf=$((_nf + 1))
if [ $_nf -lt 3 ]; then
echo $_nf > $MD/$id.nf
case "$_w" in net) ;; *) rbw $id 1K ;; esac
MODE=$(cat $MD/$id.mode 2>/dev/null); SPD=$(cat $MD/$id.speed 2>/dev/null); put $id on "$_w"; return 0
fi
log "$NAME: ${_w:-linea} da 3 giri di fila, fermata"
fi
down $id; put $id wait "$_w"; return 4
fi
rm -f $MD/$id.nf
if [ -n "$_run" ]; then
if [ "${_ma:-0}" -lt 40960 ]; then
down $id; log "fermata: memoria del router quasi finita"
if [ "$_tr" = A ]; then put $id err mem; return 3; fi
put $id wait mem; return 4
fi
else
[ "${_ma:-0}" -ge 153600 ] || { down $id; put $id wait mem; return 4; }
if [ -n "$PU" ] && [ "$_tr" != A ]; then
_pm=2; [ "$_tr" = C ] && _pm=4; _pn=0
for _f in $MD/a*.pu; do
_o=${_f##*/}; _o=${_o%.pu}; [ -f "$_f" ] && [ "$_o" != "$id" ] || continue
pvl "$(cat $MD/$_o.pid 2>/dev/null)" "$MR/$_o" && _pn=$((_pn + 1))
done
[ $_pn -lt $_pm ] || { down $id; put $id err pmany; return 3; }
fi
if [ -n "$PU" ] && [ -f $W/mem.uc ]; then
ucode $W/mem.uc check rclone </dev/null >/dev/null 2>&1; [ $? = 1 ] && { down $id; put $id wait mem; return 4; }
fi
fi
_low=
if [ "$SPEED" = auto ] && [ -n "$_run" ]; then
SPD=$(cat $MD/$id.speed 2>/dev/null); [ -f $MD/$id.low ] && _low=1
if [ "$SPD" = fast ]; then
rm -f $MD/$id.up
[ "${_ma:-0}" -lt 61440 ] && { SPD=light; _low=1; touch $MD/$id.low; log "$NAME: memoria bassa, riparte in modo leggero"; }
elif [ -n "$_low" ] && [ "${_ma:-0}" -gt 184320 ]; then
_n=$(( $(cat $MD/$id.up 2>/dev/null || echo 0) + 1 ))
if [ $_n -ge 2 ]; then SPD=fast; _low=; rm -f $MD/$id.low $MD/$id.up; else echo $_n > $MD/$id.up; fi
else
rm -f $MD/$id.up
fi
elif [ "$SPEED" = auto ]; then
SPD=light; [ "${_ma:-0}" -ge 204800 ] && [ "$CACHE" != none ] && SPD=fast; rm -f $MD/$id.low $MD/$id.up
else
SPD=$SPEED; rm -f $MD/$id.low $MD/$id.up
fi
_lw=; [ -n "$_low" ] && _lw=mem_low
renew $id
PL=$(pers $id) || PL=$(cat $MD/$id.pl 2>/dev/null)
_key="$CACHE|$CPATH|$DISK|$DMP|$GB|$RW|$SPD|$_csz|$CRON|$CD"
if [ -n "$_bt" ] && [ "$(cat $MD/$id.key 2>/dev/null)" = "$_key" ]; then
bwok $id || bspawn $id
MODE=$(cat $MD/$id.mode 2>/dev/null); put $id wait start; return 4
fi
if [ -n "$_run" ] && [ -z "$_bt" ] && [ "$(cat $MD/$id.key 2>/dev/null)" = "$_key" ]; then
if [ "$PL" = "$(cat $MD/$id.pl 2>/dev/null)" ] && pvivo $id; then
if pwok $id || pvok $id; then rm -f $MD/$id.pbad
elif ! mntd "$MR/$id.p"; then log "$NAME: vista delle cartelle private mai montata"; prem $id
elif [ -f $MD/$id.pbad ]; then rm -f $MD/$id.pbad; log "$NAME: vista delle cartelle private che non risponde"; prem $id
else : > $MD/$id.pbad; fi
else prem $id; fi
pabout $id
if ! pwok $id; then
{ shares $ENG | grep "^[a-z]*|wfcloud_$id|" >/dev/null && [ "$(smbl $id $ENG)" = "$(cat $MD/$id.smb 2>/dev/null)" ]; } || smbon $id $ENG
smblk $id "$(cat $MD/$id.smb 2>/dev/null)"
pbind $id
fi
rbw $id "$CL_BW"
tfresh $id $MD/$id.conf
cneed $id && pspawn $id
MODE=$(cat $MD/$id.mode 2>/dev/null); put $id on $_lw; return 0
fi
if [ -n "$_run" ] && [ -z "$_bt" ] && [ -f $MD/$id.port ]; then
_k=$(flush1 $id 90); [ "$_k" -gt 0 ] && log "$NAME: $_k file non ancora nel cloud prima del cambio"
fi
down $id
cfast $id; cdelold $id
CUK=
mopts
set -- --vfs-cache-mode $MODE
[ -n "$CD" ] && set -- "$@" --cache-dir "$CD" --vfs-cache-max-size ${_csz}M --vfs-cache-max-age 24h
[ -n "$CD" ] && set -- "$@" --vfs-cache-min-free-space $_mgg
[ -n "$CD" ] && set -- "$@" --vfs-cache-poll-interval 5m
[ -n "$_ra" ] && set -- "$@" --vfs-read-ahead $_ra
[ -n "$_ck" ] && set -- "$@" --vfs-read-chunk-size $_ck
[ -n "$_tf" ] && set -- "$@" --transfers $_tf
if [ "$RW" = 1 ]; then
set -- "$@" --vfs-write-back 60s
_pt=$(pfree $id) && { set -- "$@" --rc --rc-addr "127.0.0.1:$_pt"; echo "$_pt" > $MD/$id.port; }
else
set -- --read-only "$@"
fi
pxtra $id; ccopy $id $MD/$id.conf
mkdir -p $MR/$id $T/log && chmod 711 $MR && chmod 755 $MR/$id
_rk=; [ -f $MD/$id.port ] && _rk=$(rcpw $id)
_lg=$T/log/mnt-$id; [ -f $_lg ] && [ "$(wc -c < $_lg)" -gt 65536 ] && : > $_lg
_lo=$(wc -c < $_lg 2>/dev/null); _lo=$((${_lo:-0} + 0)); _t0=$(date +%s)
( [ -n "$_gc" ] && export GOGC=$_gc; [ -n "$_mcg" ] && echo 0 > "$_mcg/cgroup.procs" 2>/dev/null
[ -n "$_rk" ] && export RCLONE_RC_USER=wf RCLONE_RC_PASS="$_rk"
exec env GOMEMLIMIT=$_gl rclone mount "wf$id:$CPATH" $MR/$id --config $MD/$id.conf --allow-other \
		"$@" --buffer-size $_b --dir-cache-time $_dc --poll-interval 0 --attr-timeout 10s --dir-perms $_dp --file-perms $_fp --umask 000 --use-mmap \
		--bwlimit "$CL_BW" --log-level ERROR --log-file $_lg ) </dev/null >/dev/null 2>&1 &
_rp=$!
pup $id
echo $_rp > $MD/$id.pid; echo "$CL_BW" > $MD/$id.bwl; echo $MODE > $MD/$id.mode; echo $SPD > $MD/$id.speed; echo $_csz > $MD/$id.csz; echo "$_key" > $MD/$id.key
printf '%s' "$PL" > $MD/$id.pl
if [ -n "$PU" ]; then echo "$PU" > $MD/$id.pu; else rm -f $MD/$id.pu; fi
_i=0; while ! mounted $id && [ $_i -lt ${WF_MNTWAIT:-15} ] && [ -d /proc/$_rp ]; do sleep 1; _i=$((_i + 1)); done
if ! mounted $id && [ -d /proc/$_rp ]; then
echo "$_rp $_t0 $_lo ${CCAP:-0}" > $MD/$id.boot; bspawn $id; cneed $id && pspawn $id
put $id wait start; log "$NAME: avvio lungo, rclone rilegge la cache"; return 4
fi
if ! mounted $id; then
lwhy $_lg $_lo; down $id
if [ $_e = net ]; then put $id wait net; return 4; fi
put $id err $_e "$([ $_e = fail ] && echo "$_ed")"; log "non montata ($_e${_ed:+: $_ed})"; return 3
fi
_i=0; while [ -n "$PL" ] && ! mntd "$MR/$id.p" && [ $_i -lt 5 ] && pvivo $id; do sleep 1; _i=$((_i + 1)); done
smbon $id $ENG; pbind $id; pabout $id; cneed $id && pspawn $id
[ -n "$PL" ] && ! mntd "$MR/$id.p" && pvivo $id && pwspawn $id
put $id on $_lw; log "accesa ($NAME, $MODE, $SPD, cache $CACHE ${_csz} MiB$([ "$RW" = 1 ] && echo ', in scrittura'))"
return 0
}

dlcfg() {
DL_AC='' DL_NET='' DL_WHY=''
eval "$(NJ=$NASJ ucode -e '
		function q(s) { return "\x27" + replace("" + s, "\x27", "\x27\\\x27\x27") + "\x27"; }
		let N = null; try { N = json(require("fs").readfile(getenv("NJ")) ?? "null"); } catch (e) { }
		let C = N?.media?.cloud;
		if (type(C) == "object" && (C.on === true || C.on == 1) && C.mode == "live" && match("" + C.acct, /^a[0-9]{1,3}$/))
			print("DL_AC=", q(C.acct), " DL_NET=", q(sprintf("%J", type(C.net) == "object" ? C.net : { mode: "same" })), "\n");' </dev/null 2>/dev/null)"
[ -n "$DL_AC" ] && [ -f $RC ] && grep -qxF "[wf$DL_AC]" $RC && command -v rclone >/dev/null 2>&1 || DL_AC=
[ -n "$ACS" ] || ACS=$(acids)
[ -n "$DL_AC" ] && gone_ "$DL_AC" && DL_AC=
true
}
dlorph() {
for _q in $CL_PROC/[0-9]*/cmdline; do
[ -f "$_q" ] || continue
_c=$(tr '\0' ' ' < "$_q" 2>/dev/null)
case "$_c" in *"rclone serve dlna wf"*"--config $MD/dlna.conf"*) ;; *) continue ;; esac
[ "$(cat "${_q%cmdline}comm" 2>/dev/null)" = rclone ] || continue
_s='serve dlna wf'; _a=${_c#*"$_s"}; _a=${_a%%:*}; _a=${_a%m}
[ "$_a" = "$DL_AC" ] && continue
_p=${_q%/cmdline}; echo "${_p##*/}"
done
}
dlcs() { ( WF_NASETC=$ETC WF_UCFGUC=${WF_UCFGUC:-$W/ucfg.uc}; export WF_NASETC WF_UCFGUC; . "$D0/lib.sh" || exit 1; _cs=$(wf_crsec "$1" shared) && [ -n "$_cs" ] && grep -qxF "[$_cs]" $RC && echo "$_cs" ); }
dlx() {
_cs=$(dlcs "$1")
( WF_NASETC=$ETC; export WF_NASETC; . "$D0/lib.sh" || exit 1; umask 077; _u=
_sr=$(wf_udir shared root) && [ -n "$_sr" ] || exit 1
_lc=; _le=; WF_RLST=${WF_RLST:-15}
if [ -n "$_cs" ]; then
{ printf '\n[%s]\n' "$_cs"; sec $RC "$_cs"; } > $MD/.dlq.x && ccopy "$1" $MD/.dlq.conf &&
_lc=$(rls $MD/.dlq.conf "wf$1:$_sr") && _le=$(rls $MD/.dlq.conf "$_cs:") || { rm -f $MD/.dlq.*; exit 1; }
rm -f $MD/.dlq.*
fi
{ [ -n "$_cs" ] && { printf '\n[%s]\n' "$_cs"; sec $RC "$_cs"; }
for _k in video music photo; do
_d=$(wf_udir shared media $_k) && [ -n "$_d" ] || exit 1
if [ -n "$_cs" ]; then
_n=${_d#"$_sr"/}; _a=; _b=
printf '%s\n' "$_le" | grep -qxF -- "$_n" && _a="\"$_cs:$_n\""
printf '%s\n' "$_lc" | grep -qxF -- "$_n" && _b="\"wf$1:$_d\""
if [ -n "$_a" ] && [ -n "$_b" ]; then
printf '\n[wf%sm%s]\ntype = union\nupstreams = %s %s\n' "$1" $_k "$_a" "$_b"
_u="$_u \"${_d##*/}=wf$1m$_k:\""
elif [ -n "$_a$_b" ]; then _a=${_a:-$_b}; _a=${_a#\"}; _u="$_u \"${_d##*/}=${_a%\"}\""; fi
else _u="$_u \"${_d##*/}=wf$1:$_d\""; fi
done
[ -n "$_u" ] || exit 1
printf '\n[wf%sm]\ntype = combine\nupstreams =%s\n' "$1" "$_u"; } > $MD/dlna.x.t && mv -f $MD/dlna.x.t $MD/dlna.x ) || { rm -f $MD/dlna.x.t; return 1; }
}
dlup() {
for _q in $CL_PROC/[0-9]*/cmdline; do
[ -f "$_q" ] || continue
case "$(tr '\0' ' ' < "$_q" 2>/dev/null)" in *"rclone serve dlna wf${DL_AC}m: "*"--config $MD/dlna.conf"*) ;; *) continue ;; esac
[ "$(cat "${_q%cmdline}comm" 2>/dev/null)" = rclone ] || continue
_p=${_q%/cmdline}; kill -0 "${_p##*/}" 2>/dev/null && return 0
done
return 1
}
anyup() { for _p; do kill -0 "$_p" 2>/dev/null && return 0; done; return 1; }
dlok() {
cl_check dlna "$DL_NET" >/dev/null || { DL_WHY=$CL_WHY; return 1; }
if [ "$1" != on ] && [ "$(cl_tier)" = A ]; then
_ma=$(awk '/^MemAvailable:/ { print $2; exit }' $CL_PROC/meminfo 2>/dev/null)
[ "${_ma:-0}" -ge 153600 ] || { DL_WHY=mem; return 1; }
fi
return 0
}
dlcheck() {
lock dlna || return 0
dlcfg; _s=$(cut -d' ' -f1 $MD/dlna.st 2>/dev/null); _rl=
_op=$(dlorph)
if [ -z "$DL_AC" ]; then
[ "$_s" = on ] && _rl=1
rm -f $MD/dlna.conf $MD/dlna.tk; [ -f $MD/dlna.st ] && echo off > $MD/dlna.st
elif dlok "$_s"; then
renew $DL_AC
_dc=$(dlcs $DL_AC); _dx=; grep -q '^type *= *crypt' $MD/dlna.x 2>/dev/null && _dx=1
if [ "$_s" = on ] && [ "${_dc:+1}" = "$_dx" ] && dlup; then tfresh $DL_AC $MD/dlna.conf
else _rl=1; [ "$_s" = on ] && [ "${_dc:+1}" = "$_dx" ] && log "Server Multimediale · Cloud: In Diretta non attiva, riaccesa"; fi
elif [ "$_s" = on ]; then
_rl=1
fi
unlock dlna
if [ -n "$_op" ]; then
log "Server Multimediale: In Diretta fermata, account non più in uso"
[ -x $R/etc/init.d/wrtfreedom ] && $R/etc/init.d/wrtfreedom reload </dev/null >/dev/null 2>&1
_i=0; while [ $_i -lt 5 ] && anyup $_op; do sleep 1; _i=$((_i + 1)); done
for _p in $(dlorph); do kill -TERM "$_p" 2>/dev/null; done
return 0
fi
[ -n "$_rl" ] && [ -x $R/etc/init.d/wrtfreedom ] && { ( $R/etc/init.d/wrtfreedom reload ) </dev/null >/dev/null 2>&1 & }
true
}

cmd=$1; [ $# -gt 0 ] && shift
case "$cmd" in
start)
idok "$1" || { echo "uso: cloudmnt.sh start <id>"; exit 2; }
lock "$1" || exit 5; up "$1"; r=$?; unlock "$1"; exit $r ;;
boot)
idok "$1" || exit 2
id=$1; echo $$ > $MD/$id.bw
read -r bp b0 lo cc < $MD/$id.boot 2>/dev/null || exit 0
lg=$T/log/mnt-$id; last=$(date +%s); sg=
MNTMAX=1800
while :; do
sleep "${WF_MNTPOLL:-5}"
[ "$(cat $MD/$id.bw 2>/dev/null)" = $$ ] && [ "$(cut -d' ' -f1 $MD/$id.boot 2>/dev/null)" = "$bp" ] &&
[ "$(cat $MD/$id.pid 2>/dev/null)" = "$bp" ] || exit 0
now=$(date +%s)
if ! mounted $id && [ -d /proc/$bp ]; then
s=$(rsig $bp $lg); [ "$s" != "$sg" ] && { sg=$s; last=$now; }
[ $((now - last)) -lt "${WF_MNTIDLE:-120}" ] && [ $((now - b0)) -lt $MNTMAX ] && continue
fi
lock $id || continue
[ "$(cut -d' ' -f1 $MD/$id.boot 2>/dev/null)" = "$bp" ] && [ "$(cat $MD/$id.pid 2>/dev/null)" = "$bp" ] && bend $id "$b0" "$lo" "$cc"
unlock $id; exit 0
done ;;
push)
idok "$1" || exit 2
id=$1; q=$(cat $MD/$id.push 2>/dev/null); [ -n "$q" ] && [ "$q" != $$ ] && [ -d /proc/$q ] && exit 0
echo $$ > $MD/$id.push
cfg $id; nmof $id; CD=$(cdir $id); ACS=$(acids)
{ [ "$ON" = 1 ] && ! gone_ $id && cl_check "mnt-$id" '{"mode":"same"}' >/dev/null; } || { rm -f $MD/$id.push; exit 0; }
pc=$MD/$id.conf; [ -f $pc ] || { pc=$MD/$id.pc.conf; ccopy $id $pc; }
mkdir -p $T/log; pl=$T/log/push-$id; [ -f $pl ] && [ "$(wc -c < $pl)" -gt 65536 ] && : > $pl
_PP=; trap '[ -n "$_PP" ] && kill -TERM "$_PP" 2>/dev/null; rm -f $MD/$id.push $MD/.cp-$id.$$ $MD/.cf-$id.$$ $MD/.pw-$id.$$; exit 1' TERM INT
cold $id > $MD/.cp-$id.$$; up_=0 left=0 gone=0 t0=$(date +%s)
while IFS= read -r o; do
[ -n "$o" ] || continue
ccopies "$o"; g=$(corph "$o"); gone=$((gone + g))
cfull "$o" wf$id > $MD/.cf-$id.$$
while IFS= read -r r; do
grep -qsE '"Dirty": *true' "$CD/vfsMeta/$r" && continue
pcopy "$o" "$r" $id $pc $pl; case $? in 0) up_=$((up_ + 1)) ;; 3) gone=$((gone + 1)) ;; esac
done < $MD/.cf-$id.$$
rm -f $MD/.cf-$id.$$
if [ -d "$o/p/vfsMeta" ]; then
pr=wf${id}p; pd=$pr:; grep -qxF "[$pr]" $pc 2>/dev/null || pd="wf$id:Utenti/"
ccopies "$o/p"; g=$(corph "$o/p"); gone=$((gone + g)); cfull "$o/p" $pr > $MD/.cf-$id.$$
while IFS= read -r r; do
grep -qsE '"Dirty": *true' "$CD/p/vfsMeta/$r" && continue
pcopy "$o/p" "$r" $id $pc $pl $pr "$pd"; case $? in 0) up_=$((up_ + 1)) ;; 3) gone=$((gone + 1)) ;; esac
done < $MD/.cf-$id.$$
rm -f $MD/.cf-$id.$$
fi
n=$(dirtyn "$o"); if [ "$n" = 0 ]; then cdel "$o"; else left=$((left + n)); fi
done < $MD/.cp-$id.$$
rm -f $MD/.cp-$id.$$ $MD/$id.pc.conf $MD/$id.pc.tk
[ $up_ -gt 0 ] && log "$NAME: $up_ file di una cache di prima caricati nel cloud in $(( $(date +%s) - t0 )) s"
pgone $gone
if [ $left -gt 0 ]; then
log "$NAME: $left file non ancora nel cloud restano in una cache di prima"
if _cl_en; then _cl_ev cloud_xfer_err 86400 "⚠️ Cloud Folder ¦ $left files not yet in the cloud ¦ Kept on the previous disk"
else _cl_ev cloud_xfer_err 86400 "⚠️ Cartella Cloud ¦ $left file non ancora nel cloud ¦ Restano sul disco di prima"; fi
fi
rm -f $MD/$id.push ;;
stop)
idok "$1" || { echo "uso: cloudmnt.sh stop <id> [why]"; exit 2; }
cfg "$1"; nmof "$1"; { [ "$RW" = 1 ] || [ -f $MD/$1.port ]; } && { k=$(flush1 "$1" 120); [ "$k" -gt 0 ] && log "$NAME: $k file non ancora nel cloud"; }
lock "$1" || exit 5; cfg "$1"; down "$1"; put "$1" off "$2"; unlock "$1" ;;
gone)
idok "$1" && case "$2" in keep|lose) true ;; *) false ;; esac || { echo "uso: cloudmnt.sh gone <id> keep|lose [nome]"; exit 2; }
ACS=$(acids); gone_ "$1" || exit 0
cfg "$1"; NAME=${3:-$NAME}; nmof "$1"
smboff "$1"
[ -f $MD/$1.port ] && { k=$(gflush "$1" 120); [ "$k" -gt 0 ] && log "$NAME: $k file non ancora nel cloud prima di togliere l'account"; }
i=0; until lock "$1"; do i=$((i + 1)); [ $i -ge 10 ] && exit 5; sleep 1; done
gsave "$1"; down "$1"; drop "$1" "$2"; unlock "$1"
dlcheck ;;
check)
ACS=$(acids)
for id in $( { if [ -n "$1" ]; then echo "$1"; else ids; fi; } | tr ' ' '\n' | sort -u); do
idok "$id" || continue
if gone_ "$id"; then
NAME=; nmof "$id"
p=$(cat $MD/$id.pid 2>/dev/null)
[ -n "$p" ] && [ -d /proc/$p ] && [ -f $MD/$id.port ] && gflush $id 90 >/dev/null
lock $id || continue
log "$NAME: account tolto, fermata e stato tolto"
gsave $id; down $id; drop $id keep; unlock $id
continue
fi
lock $id || continue
cfg $id; s=$(stof $id)
if [ "$ON" != 1 ]; then
[ "$s" = off ] || [ -z "$s" ] && [ ! -f $MD/$id.pid ] || { down $id; put $id off; }
elif [ "$s" = err ] && case "$(sed -n 's/.*"why_code": *"\([a-z]*\)".*/\1/p' $MD/$id.json 2>/dev/null)" in warn|many|mem|pmany) true ;; *) false ;; esac; then
:
else
p=$(cat $MD/$id.pid 2>/dev/null)
if [ -n "$p" ] && ! pvl "$p" "$MR/$id"; then down $id; fi
CFGD=$id; up $id >/dev/null
[ "$RW" = 1 ] && ckx $id
fi
lg=$T/log/mnt-$id
[ -f $MD/$id.boot ] || { [ -f $lg ] && [ "$(wc -c < $lg)" -gt 262144 ] && : > $lg; }
[ -f $lg.p ] && [ "$(wc -c < $lg.p)" -gt 262144 ] && : > $lg.p
omig $id
unlock $id
done
smbtpl && ls $R/etc/rc.d/S*samba4 >/dev/null 2>&1 && smbreload samba4
[ -n "$1" ] || { idir >/dev/null; osweep; imig; dlcheck
q=$(cat $MD/purge.pid 2>/dev/null)
if { [ -z "$q" ] || [ ! -d /proc/$q ]; } && [ -n "$(tdirs | sed -n 1p)" ]; then
if command -v setsid >/dev/null 2>&1; then setsid sh "$D0/cloudmnt.sh" purge </dev/null >/dev/null 2>&1 &
else sh "$D0/cloudmnt.sh" purge </dev/null >/dev/null 2>&1 & fi
fi; } ;;
purge)
mkdir -p $MD; q=$(cat $MD/purge.pid 2>/dev/null); [ -n "$q" ] && [ "$q" != $$ ] && [ -d /proc/$q ] && exit 0
echo $$ > $MD/purge.pid
_PP=; trap '[ -n "$_PP" ] && kill -TERM "$_PP" 2>/dev/null; rm -f $MD/purge.pid $MD/.tp.$$ $MD/.tf.$$ $MD/.pw-*.$$; exit 1' TERM INT
now=$(date +%s); left=0 kept=0 gone=0
mkdir -p $T/log; pl=$T/log/purge; [ -f $pl ] && [ "$(wc -c < $pl)" -gt 65536 ] && : > $pl
tdirs > $MD/.tp.$$
while IFS= read -r o; do
[ -n "$o" ] && [ -d "$o" ] || continue
b=${o##*/}; id=${b%%.tolto-*}; age=$(( now - ${b#*.tolto-} )); pc=$MD/tolto/$b.conf; tr_=$MD/tolto/$b.try
cbusy "$o" && continue
NAME=$id; n=$(dirtyn "$o"); up_=0
if [ "$n" -gt 0 ] && [ -f "$pc" ] && command -v rclone >/dev/null 2>&1 &&
[ $(( now - $(cat "$tr_" 2>/dev/null || echo 0) )) -ge 3600 ] && cl_check "mnt-$id" '{"mode":"same"}' >/dev/null; then
echo "$now" > "$tr_"
ccopies "$o"; g=$(corph "$o"); gone=$((gone + g)); cfull "$o" wf$id > $MD/.tf.$$
while IFS= read -r r; do
pcopy "$o" "$r" $id "$pc" $pl
case $? in 0) up_=$((up_ + 1)) ;; 3) gone=$((gone + 1)) ;; 1|5) break ;; esac
done < $MD/.tf.$$
if [ -d "$o/p/vfsMeta" ]; then
pr=wf${id}p; pd=$pr:; grep -qxF "[$pr]" "$pc" 2>/dev/null || pd="wf$id:Utenti/"
ccopies "$o/p"; g=$(corph "$o/p"); gone=$((gone + g)); cfull "$o/p" $pr > $MD/.tf.$$
while IFS= read -r r; do
pcopy "$o/p" "$r" $id "$pc" $pl $pr "$pd"
case $? in 0) up_=$((up_ + 1)) ;; 3) gone=$((gone + 1)) ;; 1|5) break ;; esac
done < $MD/.tf.$$
fi
rm -f $MD/.tf.$$; n=$(dirtyn "$o")
[ $up_ -gt 0 ] && log "$id: $up_ file di un account tolto caricati nel cloud ($o)"
fi
if [ "$n" = 0 ]; then
if [ $up_ -gt 0 ] || [ $age -ge $((TOLTO_DAYS * 86400)) ]; then
case "$o" in */a*.tolto-*) rm -rf "$o" ;; esac
rm -f "$pc" "$tr_"; log "$id: cache di un account tolto tolta ($o)"
fi
else
left=$((left + n)); kept=$((kept + 1))
fi
done < $MD/.tp.$$
rm -f $MD/.tp.$$; NAME=; pgone $gone
td=$(tdirs)
for f in $MD/tolto/*.conf; do
[ -f "$f" ] || continue; g=${f##*/}; g=${g%.conf}
case "
$td
" in *"/$g
"*) ;; *) rm -f "$f" "$MD/tolto/$g.try" ;; esac
done
if [ $left -gt 0 ]; then
log "$left file non ancora nel cloud restano in $kept cache di account tolti"
if _cl_en; then _cl_ev cloud_tolto_left 604800 "⚠️ Cloud Folder ¦ $left files of a removed account not yet in the cloud ¦ Kept in the cache on the disk"
else _cl_ev cloud_tolto_left 604800 "⚠️ Cartella Cloud ¦ $left file di un account tolto non ancora nel cloud ¦ Restano nella cache sul disco"; fi
fi
rm -f $MD/purge.pid ;;
dlna)
_cl_dir; i=0; until lock dlna; do i=$((i + 1)); [ $i -ge 5 ] && exit 5; sleep 1; done
dlcfg; s=$(cut -d' ' -f1 $MD/dlna.st 2>/dev/null); r=1
if [ -n "$DL_AC" ] && [ "$DL_AC" = "$1" ] && dlok "$s" && dlx $DL_AC; then
ccopy $DL_AC $MD/dlna.conf; echo on > $MD/dlna.st; echo "$MD/dlna.conf"; r=0
else
rm -f $MD/dlna.conf $MD/dlna.tk $MD/dlna.x; echo "off ${DL_WHY:-off}" > $MD/dlna.st
fi
unlock dlna; exit $r ;;
pwait)
idok "$1" || exit 2
id=$1; echo $$ > $MD/$id.pw; pq=$(cat $MD/$id.ppid 2>/dev/null); i=0
while [ $i -lt "${WF_PWAIT:-300}" ]; do
_pn=$(cat $MD/$id.ppid 2>/dev/null); [ "$_pn" = "$pq" ] || { pq=$_pn; i=0; }
pvl "$pq" "$MR/$id.p" || break
if mntd "$MR/$id.p" && { dok "$MR/$id.p"; [ $? != 2 ]; }; then
SMBNEW=1; j=0; until lock $id; do j=$((j + 1)); [ $j -ge 30 ] && break; sleep 1; done
if [ $j -lt 30 ]; then
cfg $id; PL=$(cat $MD/$id.pl 2>/dev/null); rm -f $MD/$id.pw
[ "$ON" = 1 ] && mounted $id && ENG=$(eng) && { smbon $id $ENG; pbind $id; log "${NAME:-$id}: vista delle cartelle private pronta, sezioni rifatte"; }
unlock $id
fi
break
fi
sleep 1; i=$((i + 1))
done
[ "$(cat $MD/$id.pw 2>/dev/null)" = $$ ] && rm -f $MD/$id.pw
exit 0 ;;
refresh)
idok "$1" || exit 2
[ -f $MD/$1.pport ] || exit 0
f=$MD/$1.pport; shift; c=$#; n=0
for d; do n=$((n + 1)); k=dir; [ $n -gt 1 ] && k=dir$n; set -- "$@" "$k" "${d#/}"; done
shift $c
rcp "$f" vfs/forget "$@" >/dev/null 2>&1
exit 0 ;;
rc)
idok "$1" && case "$2" in main|view) true ;; *) false ;; esac && [ -n "$3" ] || { echo "uso: cloudmnt.sh rc <id> main|view <comando> [chiave valore]…"; exit 2; }
f=$MD/$1.port; [ "$2" = view ] && f=$MD/$1.pport; c=$3; shift 3
rcp "$f" "$c" "$@" || exit 1
exit 0 ;;
disk)
[ -n "$1" ] || { echo "uso: cloudmnt.sh disk <id del disco>"; exit 2; }
for id in $(ids | tr ' ' '\n' | sort -u); do
idok "$id" || continue; cfg $id; [ "$CACHE" = disk ] && [ "$DISK" = "$1" ] || continue
_i=0; until lock $id; do _i=$((_i + 1)); [ $_i -ge 30 ] && { log "$NAME: disco della cache in uscita, fermata senza il lucchetto"; break; }; sleep 1; done
down $id; put $id wait disk; unlock $id
done ;;
flush)
n=${1:-120}; case "$n" in *[!0-9]*) echo "uso: cloudmnt.sh flush [secondi]"; exit 2 ;; esac
[ "$n" -le 3600 ] || n=3600
end=$(( $(date +%s) + n )); tot=0
for id in $(ids | tr ' ' '\n' | sort -u); do
idok "$id" || continue; cfg $id; { [ "$RW" = 1 ] || [ -f $MD/$id.port ]; } || continue
left=$(( end - $(date +%s) )); [ $left -gt 0 ] || left=0
k=$(flush1 $id $left); tot=$((tot + k))
[ "$k" -gt 0 ] && log "$NAME: $k file non ancora nel cloud"
done
echo "pending=$tot"; [ $tot = 0 ]; exit $? ;;
uninstall)
for id in $(ids | tr ' ' '\n' | sort -u); do
idok "$id" || continue; cfg $id; down $id
q=$(cat $MD/$id.push 2>/dev/null); [ -n "$q" ] && [ -d /proc/$q ] && kill -TERM "$q" 2>/dev/null
done
q=$(cat $MD/purge.pid 2>/dev/null); [ -n "$q" ] && [ -d /proc/$q ] && kill -TERM "$q" 2>/dev/null
rm -f $PMG
rm -f $MD/a*.smb $MD/a*.se; smbtpl
for e in ksmbd samba4; do
for s in $(shares $e | cut -d'|' -f2 | grep '^wfcloud_'); do uci -q delete "$e.$s"; c=1; done
[ -n "$c" ] && { uci -q commit $e; smbreload $e; }; c=
done
now=$(date +%s)
{ { mnts; awk '$3 ~ /^(ext[234]|vfat|exfat|ntfs|ntfs3|fuseblk|btrfs|xfs|f2fs|hfsplus)$/ { gsub(/\\040/, " ", $2); print $2 }' $MOUNTS 2>/dev/null; } |
awk 'NF && !s[$0]++ { print $0 "/.wf-cloud-cache" }'
for c in /overlay /srv /opt /usr/share; do echo "$R$c/wf-cloud-cache"; done; echo "$OLDC"; } > /tmp/.wf-cu.$$
while IFS= read -r b; do
[ -d "$b" ] || continue
for d in "$b"/*; do
[ -d "$d" ] || continue
case "${d##*/}" in *.tolto-*) continue ;; esac
if [ "$(dirtyn "$d")" = 0 ]; then rm -rf "$d"; else mv "$d" "$d.tolto-$now" 2>/dev/null; log "cache ${d##*/} con file non ancora nel cloud tenuta in $d.tolto-$now"; fi
done
rmdir "$b" 2>/dev/null
done < /tmp/.wf-cu.$$
rm -f /tmp/.wf-cu.$$
rm -rf $MD $MR $T/log/mnt-* $T/dav.list $T/dav.list.t ;;
*) echo "uso: cloudmnt.sh start <id> | boot <id> | push <id> | stop <id> [why] | gone <id> keep|lose [nome] | check [<id>] | purge | dlna <acct> | pwait <id> | refresh <id> [cartella]… | rc <id> main|view <comando> | dfree [<cartella>] | disk <disco> | flush [secondi] | uninstall"; exit 2 ;;
esac
exit 0
