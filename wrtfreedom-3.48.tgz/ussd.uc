'use strict';
import { readfile, writefile, popen, stat, mkdir, rmdir } from 'fs';

const OUT = '/tmp/wf-ussd.json', LOCK = '/tmp/wf-ussd.lock', W = '/usr/share/wrtfreedom';
const M = loadfile(getenv('WF_MODEMUC') ?? W + '/modem.uc')();
function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function js(c) { try { return json(sh(c)); } catch (e) { return null; } }
function lock() {
if (mkdir(LOCK)) return true;
let s = stat(LOCK);
if (s && time() - s.mtime < 120) return false;
rmdir(LOCK); return !!mkdir(LOCK);
}
function prev() { try { return json(readfile(OUT) ?? 'null'); } catch (e) { return null; } }
function quoted(o, key) {
let i = index(o, key);
if (i < 0) return null;
let r = substr(o, i + length(key)), j = rindex(r, "'");
return j >= 0 ? substr(r, 0, j) : trim(r);
}

function mmstate() {
let u = js('mmcli -m any --3gpp-ussd-status -J 2>/dev/null')?.modem?.['3gpp']?.ussd ?? {};
return { state: u.status ?? '', req: u['network-request'] ?? '', note: u['network-notification'] ?? '' };
}
function mm(act, code) {
let o = '';
if (act == 'cancel') o = sh('mmcli -m any --3gpp-ussd-cancel 2>&1');
else {
let opt = act == 'send' ? '--3gpp-ussd-initiate=' : '--3gpp-ussd-respond=';
o = sh('mmcli -m any ' + q(opt + code) + ' 2>&1');
if (act == 'send' && match(o, /error/i) && match(o, /already|in progress|active/i)) { sh('mmcli -m any --3gpp-ussd-cancel >/dev/null 2>&1'); o = sh('mmcli -m any ' + q(opt + code) + ' 2>&1'); }
}
if (match(o, /error/i)) return { state: 'error', err: trim(replace(o, /^error: */, '')) };
if (act == 'cancel') return { state: 'idle', text: '' };
let txt = quoted(o, "new reply from network: '") ?? '', S = mmstate();
if (!length(txt)) txt = S.req || S.note;
return { state: S.state == 'user-response' ? 'user-response' : 'idle', text: txt };
}

function cusd(o) {
let m = match(o, /\+CUSD: *([0-9])(,"([^"]*)"(,([0-9]+))?)?/);
if (!m) return null;
return { state: m[1] == '1' ? 'user-response' : (m[1] == '4' ? 'error' : 'idle'), text: M.ucs2(m[3] ?? '', m[5] == '72') , err: m[1] == '4' ? 'operazione non supportata dalla rete' : '' };
}
function atport() { return trim(sh('sh ' + W + '/at.sh --port 2>/dev/null')); }
function atussd(act, code) {
let tool = trim(sh('sh ' + W + '/at.sh --tool 2>/dev/null'));
if (act == 'cancel') { sh('sh ' + W + '/at.sh ' + q('AT+CUSD=2') + ' >/dev/null 2>&1'); return { state: 'idle', text: '' }; }
if (tool == 'none' || !length(tool)) return { state: 'error', err: 'nessuno strumento per i comandi AT' };
if (tool == 'sms_tool') {
let o = sh('sms_tool -d ' + q(atport()) + ' ussd ' + q(code) + ' 2>&1');
let r = cusd(o);
if (r) return r;
if (match(o, /error|timeout/i) || !length(trim(o))) return { state: 'error', err: trim(o) || 'nessuna risposta dalla rete' };
return { state: 'idle', text: M.ucs2(trim(o)) };
}
let o = sh('sh ' + W + '/at.sh ' + q('AT+CUSD=1,"' + code + '",15') + ' 2>&1'), r = cusd(o);
if (r) return r;
return { state: 'error', err: match(o, /ERROR/) ? trim(o) : 'nessuna risposta dalla rete (il modem la manda dopo: serve il Gestore Del Modem o sms_tool)' };
}

let act = ARGV[0] ?? '', code = '' + (ARGV[1] ?? '');
if (index([ 'send', 'reply', 'cancel' ], act) < 0) { print('uso: ussd.uc send <codice> | reply <risposta> | cancel\n'); exit(1); }
if (act == 'send' && !match(code, /^[0-9*#+]{2,40}$/)) { print('codice non valido\n'); exit(1); }
if (act == 'reply' && !match(code, /^[0-9A-Za-z*#+ ]{1,40}$/)) { print('risposta non valida\n'); exit(1); }
if (!lock() && act != 'cancel') exit(0);
let P = prev() ?? {}, I = M.id(), via = (I.mm && length(trim(sh('mmcli -m any --3gpp-ussd-status 2>/dev/null')))) ? 'mm' : 'at';
writefile(OUT, sprintf('%J', { ...P, t: time(), act: act, code: act == 'send' ? code : (P.code ?? ''), via: via, busy: true }));
let r = via == 'mm' ? mm(act, code) : atussd(act, code);
if (via == 'mm' && r.state == 'error' && act != 'cancel' && match(r.err ?? '', /not supported|unsupported|unimplemented/i)) { via = 'at'; r = atussd(act, code); }
writefile(OUT, sprintf('%J', { t: time(), act: act, code: act == 'send' ? code : (P.code ?? ''), via: via, state: r.state, text: r.text ?? '', err: r.err ?? '' }));
rmdir(LOCK);
exit(0);
