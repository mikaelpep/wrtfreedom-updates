#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH
R=; [ -n "$WF_NASROOT" ] && [ ! -e /etc/openwrt_release ] && R=$WF_NASROOT
W=$R/usr/share/wrtfreedom; ETC=$R/etc/wrtfreedom; TMP=/tmp/wf-nas; NJ=$ETC/nas.json
V=${WF_NASRECUC:-$W/nasrec.uc}
mkdir -p $TMP
lock() {
if ! mkdir "$1" 2>/dev/null; then
p=$(cat "$1/pid" 2>/dev/null)
[ -n "$p" ] && kill -0 "$p" 2>/dev/null && return 1
[ -n "$p" ] || [ $(( $(date +%s) - $(date -r "$1" +%s 2>/dev/null || echo 0) )) -gt 60 ] || return 1
rm -rf "$1"; mkdir "$1" 2>/dev/null || return 1
fi
echo $$ > "$1/pid"
LK=$1; trap 'rm -rf "$LK"; [ -n "$CK" ] && rm -f "$CK"' EXIT
}
CK=
check() {
echo "$1" | grep -qE '^[a-z0-9._-]{1,28}$' || return 1
CK=$TMP/rec-check; echo "$1" > $CK
lock /tmp/wf-nasrec.lock || { rm -f $CK; return 0; }
job check "$1"
}
camdir() {
u=$1; d=$2
echo "$u" | grep -qE '^cam-[a-z0-9._-]{1,28}$' && [ -d "$d" ] && [ ! -L "$d" ] || return 1
grep -q "^$u:x:[0-9]*:[0-9]*:wf-nas:" $R/etc/passwd || return 1
chown "$u" "$d" 2>/dev/null; chmod 755 "$d"
}
davcam() {
f=$ETC/nas-dav.digest; [ -f $f ] || return 0
for u in $(nj 'for (let u, x in (N.users ?? {})) if (x?.cam) print(u, "\n");'); do
grep -q "^$u:" $f && sed -i "/^$u:/d" $f
done; true
}
job() { [ -f "$V" ] || return 0; J=$1 I=$2 ucode -e "loadfile('$V')().recjob(getenv('J'), getenv('I'));" </dev/null >/dev/null 2>&1; true; }
jobs2() { [ -f "$V" ] || return 0; ucode -e "let M = loadfile('$V')(); for (let j in [ 'tick', 'cloud' ]) try { M.recjob(j, ''); } catch (e) {}" </dev/null >/dev/null 2>&1; true; }
CU=${WF_CLOUDUC:-$W/cloud.uc}; LIBSH=${WF_LIBSH:-$W/lib.sh}
cryptset() {
PF=$TMP/.pw-rec
[ -f $PF ] || return 0
command -v rclone >/dev/null 2>&1 && [ -f "$CU" ] || return 0
AC=$(nj 'let C = N.rec?.cloud ?? {}; if (match(C.acct ?? "", /^a[0-9]{1,3}$/)) print(C.acct);')
[ -n "$AC" ] || return 0
REM=$(sh "$LIBSH" udir admin cams 2>/dev/null)
[ -n "$REM" ] || return 0
K2=$TMP/.pw-rec2; OUT=/tmp/wf-cloud/.w-rec
mkdir -p /tmp/wf-cloud && chmod 700 /tmp/wf-cloud
( umask 077; KEY=$(cat $PF); printf '%swf2' "$KEY" | sha256sum | cut -c1-64 > $K2 )
O1=$(rclone obscure - < $PF 2>/dev/null) && O2=$(rclone obscure - < $K2 2>/dev/null) || { rm -f $K2; O1=; return 0; }
rm -f $K2
( umask 077; A=$AC RM=$REM P1=$O1 P2=$O2 ucode -e 'printf("%J", { wfrecx: { type: "crypt", remote: "wf" + getenv("A") + ":" + getenv("RM"), password: getenv("P1"), password2: getenv("P2"), filename_encryption: "standard", directory_name_encryption: "true" } });' > $OUT )
O1=; O2=
ucode "$CU" rcput $OUT >/dev/null 2>&1 && rm -f $PF
rm -f $OUT; true
}
nj() { ucode -e "let N = {}; try { N = json(require(\"fs\").readfile(\"$NJ\") ?? \"{}\"); } catch (e) {} $1" 2>/dev/null; }

[ -f "$LIBSH" ] && . "$LIBSH"
ftpuser() {
u=$1; f=$2; d=$3
echo "$u" | grep -qE '^cam-[a-z0-9._-]{1,28}$' && [ -f "$f" ] && [ -d "$d" ] || { rm -f "$f"; return 1; }
P=$(cat "$f"); rm -f "$f"
[ -n "$P" ] || return 1
wf_pwlock || { P=; return 1; }
if ! grep -q "^$u:" $R/etc/passwd; then
id=$(wf_nextid $R/etc/passwd $ETC/nas-ids)
[ -n "$id" ] && wf_fadd $R/etc/passwd "$u:x:$id:65534:wf-nas:/var:/bin/false" && wf_fadd $R/etc/shadow "$u:!:0:0:99999:7:::"
fi
grep -q "^$u:x:[0-9]*:[0-9]*:wf-nas:" $R/etc/passwd || { P=; wf_pwunlock; return 1; }
chown "$u" "$d" 2>/dev/null; chmod 755 "$d" 2>/dev/null
if [ -n "$R" ]; then
sed -i "s|^$u:[^:]*:|$u:\$1\$prova\$finto:|" $R/etc/shadow && echo ok:ftp
else
printf '%s\n%s\n' "$P" "$P" | passwd "$u" >/dev/null 2>&1 && echo ok:ftp
fi
wf_pwunlock; P=
}

uninstall() {
I=$R/etc/init.d
[ -f $I/wf-nasftp ] && { $I/wf-nasftp stop; $I/wf-nasftp disable; rm -f $I/wf-nasftp; } >/dev/null 2>&1
[ "$(nj 'print(N.rec?.ftp_stock_off === true && N.rec?.ftp_mine !== true ? 1 : 0);')" = 1 ] && [ -f $I/vsftpd ] && { $I/vsftpd enable; $I/vsftpd start; } >/dev/null 2>&1
for m in $(nj 'for (let c in (N.rec?.cams ?? [])) if (c?.blk_mine === true) print(replace(lc("" + c.mac), /[^0-9a-f]/g, ""), "\n");'); do
uci -q delete firewall.x3kb_$m
done
for s in $(uci -q show firewall | sed -n "s/^firewall\.\(wf_nrec_[A-Za-z0-9_]*\)=rule$/\1/p"); do uci -q delete firewall.$s; done
uci -q commit firewall
o=$(nj 'let o = N.rec?.ntp_orig; if (type(o) == "object" && match("" + o.sec, /^[A-Za-z0-9_@]{1,64}$/)) print(o.sec, " ", o.o ?? "-", "\n");')
if [ -n "$o" ]; then
s=${o%% *}; v=${o#* }
if [ "$v" = - ]; then uci -q delete system.$s.enable_server; else uci -q set system.$s.enable_server="$v"; fi
uci -q commit system; [ -f $I/sysntpd ] && $I/sysntpd restart >/dev/null 2>&1
fi
for u in $(nj 'for (let u, x in (N.users ?? {})) if (x?.cam) print(u, "\n");'); do
[ -f $W/nasvc.sh ] && sh $W/nasvc.sh userdel "$u"
done
rm -rf $ETC/nas-ftp.conf $ETC/nas-ftp.users $ETC/nas-ftp.d $ETC/nas-cam.pw $TMP/rec.json $TMP/rec-idx.json $TMP/recscan.json $TMP/rec-check $TMP/rec-cloud.json $TMP/.pw-rec $TMP/camcloud
command -v fw4 >/dev/null 2>&1 && fw4 -q reload >/dev/null 2>&1; true
}

c=$1; [ $# -gt 0 ] && shift
case "$c" in
tick) lock /tmp/wf-nasrec.lock && { davcam; if [ -f $TMP/.pw-rec ]; then job tick; cryptset; job cloud; else jobs2; fi; } ;;
cryptset) lock /tmp/wf-nasrec-key.lock && cryptset ;;
stat) lock /tmp/wf-nasrec.lock && job stat ;;
clean) lock /tmp/wf-nasrec.lock && job clean ;;
follow) lock /tmp/wf-nasrec-follow.lock && job follow ;;
check) check "$1" ;;
scan) lock /tmp/wf-nasrec-scan.lock && job scan ;;
ftpuser) ftpuser "$@" ;;
camdir) camdir "$@" ;;
uninstall) uninstall ;;
*) echo "uso: nasrec.sh tick|cryptset|stat|clean|follow|check <id>|scan|ftpuser <utente> <file> <cartella>|camdir <utente> <cartella>|uninstall"; exit 2 ;;
esac
