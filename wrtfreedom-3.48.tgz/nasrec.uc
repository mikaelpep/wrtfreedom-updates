'use strict';
import { popen, readfile, writefile, unlink, stat, lstat, lsdir, mkdir, rmdir, rename, error as ferr } from 'fs';

const RT = getenv('WF_NASROOT'), R = (RT && stat('/etc/openwrt_release') == null) ? RT : '';
const ETC = R + '/etc/wrtfreedom', NJ = ETC + '/nas.json', TMP = '/tmp/wf-nas';
const SH = getenv('WF_NASSH') ?? '/usr/share/wrtfreedom/nasvc.sh', RSH = getenv('WF_NASRECSH') ?? '/usr/share/wrtfreedom/nasrec.sh';
const NVUC = getenv('WF_NASVCUC') ?? '/usr/share/wrtfreedom/nasvc.uc';
const CLOUDUC = getenv('WF_CLOUDUC') ?? '/usr/share/wrtfreedom/cloud.uc', CSH = getenv('WF_CLOUDSH') ?? '/usr/share/wrtfreedom/cloud.sh';
const CT = '/tmp/wf-cloud', RCQ = TMP + '/rec-cloud.json', RCPW = TMP + '/.pw-rec';
const MNTJ = TMP + '/mnt.json';
const ST = TMP + '/rec.json', IDX = TMP + '/rec-idx.json', SCAN = TMP + '/recscan.json', PWF = ETC + '/nas-cam.pw', CHK = TMP + '/rec-check';
const FTPC = ETC + '/nas-ftp.conf', FTPU = ETC + '/nas-ftp.users', FTPD = ETC + '/nas-ftp.d', FTPINIT = R + '/etc/init.d/wf-nasftp';
const PASV0 = 50000, PASV1 = 50019, GB = 1073741824, DAY = 86400, LEFTMAX = 366;
const STG = TMP + '/camcloud', MAINPJ = TMP + '/mainpause.json', FRESH = 600, KEEPD = 3;

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function has(p) { return stat(R + p) != null; }
function rjs(f) { let o = readfile(f); if (!length(o)) return null; try { return json(o); } catch (e) { return null; } }
const PID = split(readfile('/proc/self/stat') ?? '', ' ')[0] || '0';
function wput(f, s) { let t = f + '.' + PID + '.t'; if (writefile(t, s) === length(s) && rename(t, f)) return true; unlink(t); return false; }
function wjs(f, o) { return wput(f, sprintf('%J', o)); }
function wif(f, s) { if (readfile(f) == s) return false; return wput(f, s); }
function wpriv(f, s) {
let t = f + '.' + PID + '.t', p = popen('umask 077; cat > ' + q(t), 'w');
if (!p) return false;
p.write(s); p.close();
return rename(t, f);
}
function mkd(p) {
if (!p) return false;
mkdir(p, 0755);
let s = stat(p);
if (s?.type != 'directory') return false;
let m = (s.mode ?? 0) & 4095;
if ((m & 493) != 493) {
let f = null;
try { f = require('fs').chmod; } catch (e) { f = null; }
if (type(f) == 'function') f(p, m | 493); else sh('chmod a+rx,u+w ' + q(p) + ' 2>/dev/null');
}
return true;
}
function detach(c) { sh('( ' + c + ' ) </dev/null >/dev/null 2>&1 &'); }
function uniq(a) { let s = {}, r = []; for (let x in a) { x = '' + x; if (length(x) && !s[x]) { s[x] = 1; push(r, x); } } return r; }
function macok(x) { return match('' + x, /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/) != null; }
function ipok(x) { return match('' + x, /^([0-9]{1,3}\.){3}[0-9]{1,3}$/) != null; }
function arp() {
let A = {};
for (let l in split(readfile('/proc/net/arp') ?? '', '\n')) {
let p = split(trim(l), /[ \t]+/);
if (length(p) >= 4 && p[2] == '0x2' && macok(lc(p[3]))) A[p[0]] = lc(p[3]);
}
return A;
}
function rid() { return substr(replace(trim(readfile('/proc/sys/kernel/random/uuid') ?? ''), /-/g, ''), 0, 10) || ('' + time()); }
function r1(x) { return int(x * 10 + 0.5) / 10; }
function lcap(x) { return type(x) == 'int' ? (x > LEFTMAX ? LEFTMAX : x) : null; }

const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function cfg(name) { return UCFG.read((getenv('WF_CFGDIR') ?? '/etc/config/') + name, false); }
function first(C, t) { for (let k in C) if (C[k]['.type'] == t) return k; return null; }
function uset(c, s, o, v) { return 'uci -q set ' + q(c + '.' + s + '.' + o + '=' + v) + '; '; }
function ulist(c, s, o, L) { let r = 'uci -q delete ' + q(c + '.' + s + '.' + o) + '; '; for (let v in L) r += 'uci -q add_list ' + q(c + '.' + s + '.' + o + '=' + v) + '; '; return r; }
function leases() {
let D = cfg('dhcp'), L = {}, lf = '/tmp/dhcp.leases';
for (let k, s in D) if (s['.type'] == 'dnsmasq') { if (length(s.leasefile ?? '')) lf = s.leasefile; break; }
for (let l in split(readfile(lf) ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) >= 4) L[lc(p[1])] = { ip: p[2], name: p[3] != '*' ? p[3] : '' };
}
for (let k, s in D) if (s['.type'] == 'host')
for (let m in split(lc(join(' ', type(s.mac) == 'array' ? s.mac : [ s.mac ?? '' ])), /[ \t]+/)) if (macok(m)) {
let h = L[m] = L[m] ?? { ip: '', name: '' }, n = s.x3000_label || s.name || '';
if (length(n)) h.name = n;
if (!length(h.ip) && length(s.ip ?? '')) h.ip = s.ip;
}
return L;
}

let LG = 'it';
let NREG = [];
function L(it, en) { return LG == 'en' ? en : it; }
function err(code, it, en) { return { error: it, error_en: en, code: code }; }
function begin() { LG = cfg('wrtfreedom')?.ui?.lang == 'en' ? 'en' : 'it'; mkdir(TMP); mkdir(ETC); NREG = []; }
function ev(kind, it, en, who) { detach('sh ' + q(R + '/usr/share/wrtfreedom/event.sh') + ' cron ' + kind + ' nas ' + q(L(it, en)) + (who ? ' ' + q(who) : '')); }

const NJLK = UCFG.NJLK, NJPID = UCFG.NJPID;
function njlock() { return UCFG.njlock(); }
function njunlock() { UCFG.njunlock(); }
function nget() {
let N = UCFG.njget(NJ, NREG);
for (let k in [ 'remote', 'media', 'dl', 'rec', 'adv', 'users', 'trash' ]) if (type(N[k]) != 'object') N[k] = {};
for (let k in [ 'shares', 'backups' ]) if (type(N[k]) != 'array') N[k] = [];
if (type(N.rec.cams) != 'array') N.rec.cams = [];
return N;
}
function nput(N) { return UCFG.njput(N, NREG, NJ, (s) => { let t = NJ + '.' + PID + '.t'; writefile(t, s); rename(t, NJ); }); }
function busy() { return err('busy', 'Impostazioni occupate: riprova', 'Settings busy: try again'); }

const SYSMNT = /^\/(|overlay|rom|boot|tmp|proc|sys|dev)$/, SYS = getenv('WF_SYS') ?? '/sys';
function unoct(s) { return replace(s, /\\([0-7][0-7][0-7])/g, (a, o) => chr((ord(o, 0) - 48) * 64 + (ord(o, 1) - 48) * 8 + ord(o, 2) - 48)); }
function blkinfo(ML) { return UCFG.blkinfo(ML, { sys: SYS, run: TMP, sh, rj: rjs, wjr: wjs, mkdirp: mkdir }); }
function mounted(m, ro) { return UCFG.mounted(m, ro); }
function disks() {
let M = {}, ML = [], D = [], NS = rjs(NJ)?.disks, MA = {}, MJ = rjs(MNTJ);
if (type(NS) != 'object') NS = {};
if (type(MJ) != 'object') MJ = {};
for (let l in split(readfile(R + '/proc/mounts') ?? '', '\n')) {
let p = split(l, ' ');
if (length(p) < 4) continue;
push(ML, { dev: p[0], mnt: unoct(p[1]) });
if (substr(p[0], 0, 5) != '/dev/') continue;
MA[p[0] + ' ' + unoct(p[1])] = { mnt: unoct(p[1]), fs: p[2], ro: match(p[3], /^ro(,|$)/) != null };
if (!M[p[0]]) M[p[0]] = MA[p[0] + ' ' + unoct(p[1])];
}
let B = blkinfo(ML);
for (let dv in sort(keys(B))) {
let a = B[dv], k = '/dev/' + dv;
if (type(a) != 'object' || !M[k] || match(M[k].mnt, SYSMNT)) continue;
if (match(a.TYPE ?? '', /^(squashfs|ubifs|jffs2|swap)$/)) continue;
let dev = replace(dv, /^.*\//, ''), id = lc(a.UUID ?? '') || dev;
if (type(MJ[id]) == 'string' && MA[k + ' ' + MJ[id]]) M[k] = MA[k + ' ' + MJ[id]];
let fs = M[k].fs;
let st = NS[id]?.ro, lock = type(st) == 'bool' ? st : match(fs, /^(ntfs|ntfs3|ntfs-3g|fuseblk)$/) != null;
if (!mounted(M[k], M[k].ro || lock)) continue;
push(D, { id: id, dev: dev, name: a.LABEL || dev, mnt: M[k].mnt, fs: fs, ro: M[k].ro, lock: lock });
}
return D;
}
function rod(d) { return d.ro || d.lock === true; }
function diskof(D, id) { for (let d in D) if (d.id == id) return d; return null; }
function relok(p) {
p = '' + (p ?? '');
if (!length(p)) p = '/';
if (substr(p, 0, 1) != '/' || length(p) > 1024 || match(p, /[[:cntrl:]\\]/)) return null;
p = replace(p, /\/+/g, '/');
for (let s in split(p, '/')) if (s == '..' || s == '.') return null;
if (length(p) > 1 && substr(p, -1) == '/') p = substr(p, 0, length(p) - 1);
return p;
}
function rpath(p) { let f = require('fs').realpath, r = null; if (type(f) != 'function') return null; try { r = f(p); } catch (e) { r = null; } return r; }
function inside(root, p) {
if (type(require('fs').realpath) != 'function') return true;
let x = p;
while (length(x) > length(root) && !lstat(x)) x = replace(x, /\/[^\/]*$/, '');
let rp = rpath(x), rr = rpath(root) ?? root;
return rp != null && (rp == rr || index(rp, rr + '/') == 0);
}
function absof(D, id, rel) {
let d = diskof(D, id), r = relok(rel);
if (!d || r == null) return null;
let p = d.mnt + (r == '/' ? '' : r);
return inside(d.mnt, p) ? p : null;
}
function noown(d) { return match(d?.fs ?? '', /^(vfat|msdos|fat|exfat|ntfs|ntfs3|ntfs-3g|fuseblk|fuse)/) != null; }

function ramMb() { let m = match(readfile('/proc/meminfo') ?? '', /MemTotal:[ \t]*([0-9]+)/); return m ? int(+m[1] / 1024) : 0; }
const PK = {
ksmbd: [ [ 'ksmbd-server', '/usr/sbin/ksmbd.mountd' ] ],
samba4: [ [ 'samba4-server', '/usr/sbin/smbd' ] ],
ftp: [ [ 'vsftpd', '/usr/sbin/vsftpd' ] ]
};
function need(part) {
let r = [];
for (let p in PK[part]) { let ok = false; for (let i = 1; i < length(p); i++) if (has(p[i])) ok = true; if (!ok) push(r, p[0]); }
return r;
}
function pkgerr(P) {
return { ...err('pkg', 'Serve installare: ' + join(', ', P), 'Needs to be installed: ' + join(', ', P)), need: P };
}
function roShare(N, D) {
if (N.on !== true && !length(type(N.shares) == 'array' ? N.shares : [])) return false;
for (let d in D) if (d?.ro) return true;
return false;
}
function engine(N, D) { return UCFG.smbengine(N, { R: R, ro: roShare(N, D), admu: UCFG.smbadm(N) }); }

const VPNIF = /^wgo(ut|[0-9]+)$/;
function zarr(z) { return type(z.network) == 'array' ? z.network : split(z.network ?? '', ' '); }
function wgsrv(N, i) { return N[i]?.proto == 'wireguard' && !match(i, VPNIF) && length('' + (N[i].listen_port ?? '')) > 0; }
function wgcli(N, i) { return N[i]?.proto == 'wireguard' && !wgsrv(N, i); }
function zones() {
let F = cfg('firewall'), N = cfg('network'), home = null, alt = null, wan = null, Z = {}, fwd = {}, fromhome = {}, out = {}, mine = {};
for (let k in F) {
let z = F[k];
if (z['.type'] != 'zone' || !z.name || !match(z.name, /^[A-Za-z0-9_]{1,15}$/)) continue;
let masq = z.masq == '1' || z.masq == 'true';
Z[z.name] = { nets: zarr(z), input: uc(z.input ?? 'REJECT'), masq: masq };
for (let i in Z[z.name].nets) if (wgcli(N, i)) out[z.name] = 1;
if (z.wf == '1') mine[z.name] = 1;
if (out[z.name]) continue;
if (!home && index(Z[z.name].nets, 'lan') >= 0) home = z.name;
if (!alt && !masq && uc(z.input ?? '') == 'ACCEPT') alt = z.name;
if (!wan && masq) wan = z.name;
}
home = home ?? alt;
for (let k in F) if (F[k]['.type'] == 'forwarding') {
if (F[k].dest == wan) fwd[F[k].src] = 1;
if (F[k].src == home && F[k].dest != wan) fromhome[F[k].dest] = 1;
}
let guest = [], iot = null;
for (let n, z in Z) {
if (n == home || n == wan || out[n]) continue;
let wg = false;
for (let i in z.nets) if (wgsrv(N, i)) wg = true;
if (wg) continue;
if (!iot && (fromhome[n] || mine[n])) iot = n;
else if (fwd[n]) push(guest, n);
}
return { home: home, wan: wan, guest: guest, iot: iot, Z: Z };
}
function lanip() {
let Zs = zones(), N = cfg('network');
for (let n in [ ...(Zs.Z[Zs.home]?.nets ?? []), 'lan' ]) {
let a = N[n]?.ipaddr, ip = '' + (type(a) == 'array' ? a[0] : (a ?? ''));
let m = match(ip, /^([0-9]{1,3}(\.[0-9]{1,3}){3})/);
if (m) return m[1];
}
return '';
}
function ipn(ip) { let m = match('' + ip, /^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$/); return m ? ((+m[1] * 256 + +m[2]) * 256 + +m[3]) * 256 + +m[4] : null; }
function zoneof(Zs, ip) {
let x = ipn(ip), N = cfg('network');
if (x == null) return null;
for (let n, z in Zs.Z) {
if (n == Zs.wan) continue;
for (let i in z.nets) {
let A = N[i]?.ipaddr;
for (let v in (type(A) == 'array' ? A : [ A ])) {
let m = match('' + (v ?? ''), /^([0-9.]+)(\/([0-9]+))?$/), b = m ? ipn(m[1]) : null;
if (b == null) continue;
let pl = m[3] != null ? +m[3] : 24, nm = ipn(N[i].netmask ?? '');
if (m[3] == null && nm != null) { pl = 0; for (let k = 31; k >= 0 && (nm >> k) & 1; k--) pl++; }
let mk = pl <= 0 ? 0 : (0xffffffff << (32 - pl)) & 0xffffffff;
if ((x & mk) == (b & mk)) return n;
}
}
}
return null;
}

let OUI = null;
function ouiget(mac) {
if (OUI == null) {
OUI = {};
for (let l in split(readfile(R + '/usr/share/wrtfreedom/oui.txt') ?? '', '\n')) {
let p = split(l, '|');
if (substr(l, 0, 1) == '#' || length(p) < 3) continue;
for (let x in split(p[2], ' ')) if (length(x) == 6) OUI[uc(x)] = [ p[0], p[1] ];
}
}
return OUI[uc(replace(substr('' + mac, 0, 8), /:/g, ''))];
}
const VCAP = { hikvision: [ true, true, 'smb' ], dahua: [ true, true, 'smb' ], amcrest: [ true, true, 'smb' ], annke: [ true, true, 'smb' ],
axis: [ true, true, 'smb' ], uniview: [ true, true, 'smb' ], reolink: [ true, true, 'ftp' ], foscam: [ false, true, 'ftp' ],
tapo: [ false, false, '' ], 'tp-link': [ false, false, '' ], ezviz: [ false, false, '' ], imou: [ false, false, '' ],
wyze: [ false, false, '' ], ring: [ false, false, '' ], arlo: [ false, false, '' ], nest: [ false, false, '' ], blink: [ false, false, '' ] };
function vcap(v) {
let k = lc(split(trim('' + (v ?? '')), ' ')[0] ?? '');
return VCAP[k] ?? [ true, true, 'smb' ];
}
const CAMNAME = /camera|telecamera|cam-|ipcam|ipc|doorbell|nvr|dvr|hikvision|dahua|reolink|tapo|ezviz|imou/i;

const LIMDEF = { disk: { days: { on: true, n: 7 }, cap: { on: true, pct: 20 } }, cloud: { days: { on: true, n: 7 }, cap: { on: false, gb: 0 } } };
const LIMMAX = { disk: { days: 3650, cap: 90 }, cloud: { days: 365, cap: 100000 } };
function limof(r) {
let L0 = type(r.lim) == 'object' ? r.lim : {}, o = {};
for (let w in [ 'disk', 'cloud' ]) {
let x = type(L0[w]) == 'object' ? L0[w] : {}, d = type(x.days) == 'object' ? x.days : {}, c = type(x.cap) == 'object' ? x.cap : {};
let ck = w == 'disk' ? 'pct' : 'gb', D0 = LIMDEF[w];
o[w] = { days: { on: type(d.on) == 'bool' ? d.on : D0.days.on, n: type(d.n) == 'int' ? (d.n < KEEPD ? KEEPD : d.n) : D0.days.n },
cap: { on: type(c.on) == 'bool' ? c.on : D0.cap.on } };
o[w].cap[ck] = type(c[ck]) == 'int' ? c[ck] : D0.cap[ck];
}
return o;
}
function limset(r, a) {
let L1 = limof(r), E = () => err('lim', 'Limiti non validi', 'Invalid limits');
if (type(a) != 'object') return E();
for (let w, x in a) {
if (!LIMDEF[w] || type(x) != 'object') return E();
let ck = w == 'disk' ? 'pct' : 'gb';
for (let k, v in x) {
if (k != 'days' && k != 'cap' || type(v) != 'object') return E();
let nk = k == 'days' ? 'n' : ck, mx = LIMMAX[w][k];
for (let f, y in v) {
if (f == 'on') { if (type(y) != 'bool') return E(); }
else if (f == nk) { if (type(y) != 'int' || y < 1 || y > mx) return E(); if (k == 'days' && y < KEEPD) y = KEEPD; }
else return E();
L1[w][k][f] = y;
}
}
}
return { L: L1 };
}
function cbase() { return '/' + UCFG.udir('admin', 'cams'); }
function cdir(c) { let p = UCFG.udir('admin', 'cams', c?.name); return p == null ? null : '/' + p; }
function rdisk(N, D) {
let m = N.main;
if (type(m) != 'object' || !length('' + (m.id ?? '')) || stat(MAINPJ) != null) return '';
let u = lc('' + (m.uuid ?? ''));
for (let d in D) if ((d.id == '' + m.id || d.dev == '' + m.id || (length(u) && d.id == u)) && !rod(d)) return d.id;
return '';
}
function cloudon(N) { let C = N.rec.cloud; return N.rec.on === true && type(C) == 'object' && C.on === true && C.stf != 'setup'; }
function stgon(N, dk) { return !length(dk) && cloudon(N); }
function camram() { let m = ramMb(); m = m > 0 ? int(m * 1048576 / 10) : 33554432; return m > 67108864 ? 67108864 : m; }
function campath(N, D, dk, c) { return length(dk) ? absof(D, dk, cdir(c)) : (stgon(N, dk) && match(c.id, /^[a-z0-9._-]{1,28}$/) ? STG + '/' + c.id : null); }
function camsync(N, dk) {
let r = N.rec, ch = false;
for (let k in [ 'dir', 'disk', 'keep', 'max_gb', 'days' ]) if (exists(r, k)) { delete r[k]; ch = true; }
for (let c in r.cams) {
let p = cdir(c);
if (p == null) continue;
if (c.dir != p) { c.dir = p; ch = true; }
if (length(dk)) for (let s in N.shares) if (s?.cam == c.id && (s.disk != dk || s.path != p)) { s.disk = dk; s.path = p; ch = true; }
}
return ch;
}
function mkdp(root, rel) {
let p = root;
for (let x in filter(split(rel ?? '', '/'), (y) => length(y))) { p += '/' + x; if (!mkd(p)) return false; }
return true;
}
function camdirs(N, D, dk) {
let d = diskof(D, dk);
if (!d || !absof(D, dk, cbase()) || !mkdp(d.mnt, cbase())) return false;
for (let c in N.rec.cams) {
let p = absof(D, dk, cdir(c));
if (!p || !mkd(p) || c.how != 'ftp' || noown(d) || stat(p)?.uid != 0) continue;
sh('sh ' + q(RSH) + ' camdir ' + q(c.user) + ' ' + q(p) + ' >/dev/null 2>&1');
}
return true;
}
function advof(r) {
let a = type(r.adv) == 'object' ? r.adv : {};
return { onvif: a.onvif !== false, ftp: a.ftp !== false, smb1: a.smb1 === true, fixed: a.fixed !== false, outside: a.outside === true,
check_min: type(a.check_min) == 'int' ? a.check_min : 60 };
}
function authof(r) { return { mode: 'all', macs: [] }; }
function warnh(r) { return type(r.warn_h) == 'int' && r.warn_h > 0 ? r.warn_h : 6; }
function camof(N, id) { for (let c in N.rec.cams) if (c.id == id) return c; return null; }
function camstate(r, c, s, now) {
let wh = (type(c.warn_h) == 'int' && c.warn_h > 0 ? c.warn_h : warnh(r)) * 3600, last = s?.last ?? 0;
if ((c.pause_until ?? 0) > now) return 'pause';
if (last < (c.added ?? 0) && now - (c.added ?? 0) <= wh) return 'wait';
return now - (last || c.added || now) > wh ? 'warn' : 'ok';
}
function whynot(names) {
let n = length(names);
if (!n) return null;
if (n == 1) return [ names[0] + ' non salva', names[0] + ' is not saving' ];
if (n == 2) return [ names[0] + ' e ' + names[1] + ' non salvano', names[0] + ' and ' + names[1] + ' are not saving' ];
return [ n + ' telecamere non salvano', n + ' cameras are not saving' ];
}
function pwget() { return rjs(PWF) ?? {}; }
function pwput(P) { wpriv(PWF, sprintf('%J', P)); }
function newpass() {
const A = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
let b = readfile('/dev/urandom', 32) ?? '', p = '';
for (let i = 0; length(p) < 16 && i < length(b); i++) p += substr(A, ord(b, i) % length(A), 1);
while (length(p) < 16) p += substr(A, (time() + length(p) * 7) % length(A), 1);
return p;
}
function recwrite(N, dk) {
wif(ETC + '/nas-rec.sh', '# 3.11: registrazioni con nasrec.sh (per telecamera); la pulizia vecchia di nasvc.sh resta spenta\nREC_ON=0\nREC_DISK=' + q(dk ?? '') + '\nREC_DIR=' + q(cbase()) + '\nREC_GB=0\nREC_DAYS=0\n');
}

const MODC = {};
function modof(f) { return UCFG.modof(MODC, f); }
function smbapply(on) {
let M = modof(NVUC);
if (type(M?.nas_shares?.call) != 'function') return false;
let r = null;
try { r = M.nas_shares.call({ args: { act: 'on', on: on } }); } catch (e) { r = null; }
return r != null && r.error == null;
}

const FTPINITS = '#!/bin/sh /etc/rc.common\n# WrtFreedom: FTP Solo Da Casa per le telecamere del NAS, scritto da nasrec.uc e tolto da nasrec.sh uninstall\nSTART=99\nUSE_PROCD=1\n' +
'start_service() {\n\t[ -f /etc/wrtfreedom/nas-ftp.conf ] || return 0\n\tmkdir -p /var/run/vsftpd\n\tprocd_open_instance\n' +
'\tprocd_set_param command /usr/sbin/vsftpd /etc/wrtfreedom/nas-ftp.conf\n\tprocd_set_param respawn\n\tprocd_close_instance\n}\n';
function ftpcams(N, D) { let dk = rdisk(N, D); return filter(N.rec.cams, (c) => c.how == 'ftp' && campath(N, D, dk, c) != null); }
function ftpwant(N, D) { return N.rec.on === true && advof(N.rec).ftp && length(ftpcams(N, D)) > 0 && has('/usr/sbin/vsftpd'); }
function ftpwrite(N, D) {
let C = ftpcams(N, D), ch = false, dk = rdisk(N, D);
mkdir(FTPD);
if (stgon(N, dk)) { mkd(STG); for (let c in C) { let p = STG + '/' + c.id; if (mkd(p) && stat(p)?.uid == 0) sh('sh ' + q(RSH) + ' camdir ' + q(c.user) + ' ' + q(p) + ' >/dev/null 2>&1'); } }
let conf = 'listen=YES\nlisten_ipv6=NO\nlisten_port=21\nbackground=NO\nanonymous_enable=NO\nlocal_enable=YES\nwrite_enable=YES\nlocal_umask=022\n' +
'chroot_local_user=YES\nallow_writeable_chroot=YES\ncheck_shell=NO\nuserlist_enable=YES\nuserlist_deny=NO\nuserlist_file=' + FTPU + '\n' +
'user_config_dir=' + FTPD + '\npasv_enable=YES\npasv_min_port=' + PASV0 + '\npasv_max_port=' + PASV1 + '\nsecure_chroot_dir=/var/run/vsftpd\n' +
'seccomp_sandbox=NO\nxferlog_enable=NO\nsyslog_enable=NO\nhide_ids=YES\nmax_clients=16\nmax_per_ip=4\n';
ch = wif(FTPC, conf) || ch;
ch = wif(FTPU, join('', map(C, (c) => c.user + '\n'))) || ch;
let keep = {};
for (let c in C) { keep[c.user] = 1; ch = wif(FTPD + '/' + c.user, 'local_root=' + campath(N, D, dk, c) + '\n') || ch; }
for (let f in (lsdir(FTPD) ?? [])) if (!keep[f]) { unlink(FTPD + '/' + f); ch = true; }
if (wif(FTPINIT, FTPINITS)) { sh('chmod 755 ' + q(FTPINIT)); ch = true; }
return ch;
}
function ftpstock() { return has('/etc/init.d/vsftpd') && length(filter(lsdir(R + '/etc/rc.d') ?? [], (x) => match(x, /^S[0-9]+vsftpd$/))) > 0; }
function oursset(N, s, on) { let o = type(N.ours) == 'array' ? N.ours : []; N.ours = on ? uniq([ ...o, s ]) : filter(o, (x) => x != s); }

function m12(mac) { return replace(lc('' + mac), /:/g, ''); }
function recfw(N, D) {
let F = cfg('firewall'), Zs = zones(), c = '', r = N.rec, now = time();
for (let k in F) if (match(k, /^wf_nrec_/)) c += 'uci -q delete ' + q('firewall.' + k) + '; ';
let rule = (id, src, proto, ports, tgt, mac, ip) => 'uci -q set ' + q('firewall.' + id + '=rule') + '; ' + uset('firewall', id, 'name', replace(id, /_/g, '-')) +
uset('firewall', id, 'src', src) + (type(mac) == 'array' ? ulist('firewall', id, 'src_mac', mac) : (mac ? uset('firewall', id, 'src_mac', mac) : '')) +
(type(ip) == 'array' ? ulist('firewall', id, 'src_ip', ip) : '') + ulist('firewall', id, 'proto', proto) +
ulist('firewall', id, 'dest_port', ports) + uset('firewall', id, 'target', tgt) + uset('firewall', id, 'wf', '1');
let FP = [ '21', PASV0 + '-' + PASV1 ], AU = authof(r);
if (ftpwant(N, D)) {
let am = [], ai = [];
if (AU.mode == 'sel') for (let x in ftpcams(N, D)) { if (macok(x.mac)) push(am, x.mac); else if (ipok(x.ip)) push(ai, x.ip); }
am = uniq([ ...am, ...AU.macs ]); ai = uniq(ai);
let okz = (z, id) => {
if (AU.mode != 'sel') return Zs.Z[z].input != 'ACCEPT' ? rule(id, z, [ 'tcp' ], FP, 'ACCEPT') : '';
return rule(id, z, [ 'tcp' ], FP, 'ACCEPT', am) + (length(ai) ? rule(id + '_ip', z, [ 'tcp' ], FP, 'ACCEPT', null, ai) : '') + rule(id + '_no', z, [ 'tcp' ], FP, 'REJECT');
};
if (Zs.home) c += okz(Zs.home, 'wf_nrec_ftp_home');
if (Zs.iot && N.adv.nets?.iot === true && (AU.mode == 'sel' || Zs.Z[Zs.iot].input != 'ACCEPT')) c += okz(Zs.iot, 'wf_nrec_ftp_iot');
for (let z in [ ...Zs.guest, ...(Zs.iot && N.adv.nets?.iot !== true ? [ Zs.iot ] : []) ])
if (Zs.Z[z].input == 'ACCEPT') c += rule('wf_nrec_ftp_no_' + z, z, [ 'tcp' ], FP, 'REJECT');
if (Zs.wan) c += rule('wf_nrec_ftp_wan', Zs.wan, [ 'tcp' ], FP, 'REJECT');
}
for (let x in r.cams) if (macok(x.mac) && (x.pause_until ?? 0) > now)
for (let z in uniq([ Zs.home, ...(Zs.iot ? [ Zs.iot ] : []) ])) if (z)
c += rule('wf_nrec_p_' + m12(x.mac) + '_' + z, z, [ 'tcp', 'udp' ], [ '139', '445', ...FP ], 'REJECT', x.mac);
return c;
}
function blkcmd(c, on, name) {
let id = 'firewall.x3kb_' + m12(c.mac), Zs = zones(), ip = leases()[c.mac]?.ip || c.ip, zs = zoneof(Zs, ip) ?? Zs.home ?? '*', zd = Zs.wan ?? '*';
if (on) {
let F = cfg('firewall')['x3kb_' + m12(c.mac)];
if (F) {
if (F.enabled != '0') return '';
c.blk_mine = true;
return 'uci set ' + id + '.enabled=1; ';
}
c.blk_mine = true;
return 'uci set ' + id + '=rule; uci set ' + id + '.name=' + q('Blocco ' + replace(name, /[\n\r'"]/g, '')) + '; uci set ' + id + '.src=' + q(zs) +
'; uci set ' + id + '.dest=' + q(zd) + '; uci add_list ' + id + '.src_mac=' + c.mac + '; uci add_list ' + id + '.proto=all; uci set ' + id + '.target=REJECT; uci set ' + id + '.enabled=1; ';
}
if (c.blk_mine !== true) return '';
delete c.blk_mine;
return 'uci -q delete ' + id + '; ';
}
function ntpcmd(N) {
let S = cfg('system'), k = first(S, 'timeserver'), r = N.rec, want = length(filter(r.cams, (c) => c.noinet === true)) > 0;
if (!k) return '';
let cur = S[k].enable_server ?? null;
if (want && cur != '1') { r.ntp_orig = { sec: k, o: cur }; return uset('system', k, 'enable_server', '1') + 'uci -q commit system; /etc/init.d/sysntpd restart >/dev/null 2>&1 & '; }
if (!want && type(r.ntp_orig) == 'object') {
let o = r.ntp_orig; delete r.ntp_orig;
if (cur != '1') return '';
return (o.o == null ? 'uci -q delete ' + q('system.' + k + '.enable_server') + '; ' : uset('system', k, 'enable_server', o.o)) + 'uci -q commit system; /etc/init.d/sysntpd restart >/dev/null 2>&1 & ';
}
return '';
}
function camallow(N) {
let AU = authof(N.rec), ch = false;
for (let s in N.shares) {
if (!s.cam) continue;
let c = camof(N, s.cam), w = AU.mode == 'sel' && macok(c?.mac) ? { mode: 'sel', macs: uniq([ c.mac, ...AU.macs ]) } : null;
if (sprintf('%J', s.allow ?? null) == sprintf('%J', w)) continue;
if (w) s.allow = w; else delete s.allow;
ch = true;
}
return ch;
}
function recplan(N, D, extra) {
let c = (extra ?? '') + recfw(N, D) + ntpcmd(N), want = ftpwant(N, D), wasOn = index(N.ours ?? [], 'wf-nasftp') >= 0;
oursset(N, 'wf-nasftp', want);
return { c: c, want: want, wasOn: wasOn, N: N, D: D };
}
function recrun(P) {
let fw = length(P.c) > 0;
let fch = P.want || stat(FTPC) != null ? ftpwrite(P.N, P.D) : false;
if (fw) sh(P.c + 'uci -q commit firewall; true');
let bg = [];
if (P.want && (fch || !P.wasOn)) push(bg, 'sh ' + q(SH) + ' svc wf-nasftp:on');
if (!P.want && P.wasOn) push(bg, 'sh ' + q(SH) + ' svc wf-nasftp:off');
if (fw) push(bg, 'sh ' + q(SH) + ' fw');
if (length(bg)) detach(join('; ', bg));
}
function recsave(N, D, extra) {
let P = recplan(N, D, extra);
if (!nput(N)) return false;
recrun(P);
return true;
}

let RCX = null;
function rc() {
if (RCX == null) { RCX = false; if (stat(CLOUDUC)) try { RCX = loadfile(CLOUDUC)()?._rc ?? false; } catch (e) { RCX = false; } }
return RCX || null;
}
const CLST = { off: [ 'Spento', 'Off' ], setup: [ 'Da Completare', 'To Complete' ], relink: [ 'Da Ricollegare', 'Reconnect' ], pause: [ 'In Pausa', 'Paused' ],
run: [ 'In Corso', 'Running' ], wait: [ 'In Attesa', 'Waiting' ], err: [ 'Non Riuscito', 'Failed' ], ok: [ 'Riuscito', 'Succeeded' ], never: [ 'Mai Fatto', 'Never Run' ] };
const CLK = [ 'cams', 'what', 'how', 'from', 'to', 'all', 'acct', 'gb_day', 'net' ];
function hmok(s) { return type(s) == 'string' && match(s, /^([01][0-9]|2[0-3]):[0-5][0-9]$/) != null; }
function isnum(v) { return type(v) == 'int' || type(v) == 'double'; }
function today() { let t = localtime(time()); return sprintf('%04d%02d%02d', t.year, t.mon, t.mday); }
function cnet(n) {
if (type(n) != 'object' || !match('' + n.mode, /^(same|own|fixed)$/)) return null;
if (n.mode != 'own') return { mode: n.mode };
if (!isnum(n.gb) || !(n.gb == 0 || (n.gb >= 0.5 && n.gb <= 500)) || (n.all !== true && !(hmok(n.from) && hmok(n.to)))) return null;
return { mode: 'own', gb: n.gb, all: n.all === true, from: n.from ?? '', to: n.to ?? '' };
}
function cin(C, now) {
if (C.all === true) return true;
let t = localtime(now), m = t.hour * 60 + t.min, hm = (s) => +substr(s, 0, 2) * 60 + +substr(s, 3, 2), a = hm(C.from), b = hm(C.to);
return a == b ? true : (a < b ? m >= a && m < b : m >= a || m < b);
}
function cjobs(Q) { return filter(map(type(Q.jobs) == 'array' ? Q.jobs : [], (j) => rjs(CT + '/jobs/' + j + '.json')), (o) => type(o) == 'object'); }
function cloudout(N) {
let C = type(N.rec.cloud) == 'object' ? N.rec.cloud : { on: false }, Q = rjs(RCQ) ?? {};
let X = C.on === true ? rc() : null, A = X && C.acct ? X.acct(C.acct) : null, J = C.on === true ? cjobs(Q) : [];
let st = C.on !== true ? 'off' : C.stf == 'setup' ? 'setup' : (!A || A.state == 'relink') ? 'relink' : X.paused() ? 'pause' :
length(filter(J, (o) => o.state == 'run')) ? 'run' : length(filter(J, (o) => o.state == 'wait')) ? 'wait' :
Q.err === true ? 'err' : (Q.last ?? 0) > 0 ? 'ok' : 'never';
return { on: C.on === true, cams: type(C.cams) == 'array' ? C.cams : [], what: C.what ?? '', how: C.how ?? '', from: C.from ?? '', to: C.to ?? '',
all: C.all === true, acct: C.acct ?? '', remote: cbase(), gb_day: C.gb_day ?? 0, net: C.net ?? null,
today_bytes: Q.day == today() ? (Q.today ?? 0) : 0, last: Q.last ?? 0, st: st, st_t: CLST[st][0], st_t_en: CLST[st][1], bytes: Q.bytes ?? 0 };
}
function cloudset(N, a, S) {
let C0 = type(N.rec.cloud) == 'object' ? N.rec.cloud : { on: false }, E = (code) => err(code, 'Copia Fuori Casa non valida', 'Invalid Off-Site Copy');
if (type(a) != 'object') return E('cloud');
let C = { ...C0 };
for (let k in CLK) if (exists(a, k)) C[k] = a[k];
if (type(a.on) == 'bool') C.on = a.on;
if (C.on === true) {
let nd = [];
if (type(C.cams) != 'array' || !length(C.cams)) push(nd, 'cams');
if (!C.what) push(nd, 'what');
if (!C.how) push(nd, 'how');
if (C.all !== true && !(C.from && C.to)) push(nd, 'from');
for (let k in [ 'acct', 'gb_day', 'net' ]) if (!C[k]) push(nd, k);
if (length(nd)) return { ...err('need', 'Scegli tutte le voci della Copia Fuori Casa', 'Choose every Off-Site Copy option'), need: nd };
}
if (C.cams != null && (type(C.cams) != 'array' || length(C.cams) > 32 || length(filter(C.cams, (id) => !camof(N, '' + id))))) return E('cams');
if (C.cams != null) C.cams = uniq(C.cams);
if (C.what && !match('' + C.what, /^(motion|alarm|all)$/)) return E('what');
if (C.what && C.what != 'all' && length(filter(C.cams ?? [], (id) => S.cams?.[id]?.fixed === true)))
return err('what', 'Solo le telecamere con gli eventi salvano movimento o allarme', 'Only cameras with events save motion or alarm');
if (C.how && !match('' + C.how, /^(clips|cont)$/)) return E('how');
if ((C.from && !hmok(C.from)) || (C.to && !hmok(C.to))) return E('from');
C.all = C.all === true;
C.remote = cbase(); delete C.keep_days;
if (C.gb_day && !(isnum(C.gb_day) && C.gb_day >= 0.1 && C.gb_day <= 500)) return E('gb_day');
if (C.net) { let n = cnet(C.net); if (!n) return err('net', 'Rete Da Usare non valida', 'Invalid Network To Use'); C.net = n; }
if (C.acct || C.on === true) {
let X = rc();
if (!X) return err('pkg', 'Serve installare Cloud in Software', 'Install Cloud in Software first');
if (!X.acct(C.acct)) return err('acct', 'Scegli un account nel Cloud', 'Choose an account in Cloud');
}
return { C: C };
}
function newkey() {
let A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', f = require('fs').open('/dev/urandom', 'r'), b = f ? f.read(24) : null, k = '';
if (f) f.close();
if (length(b ?? '') < 24) return null;
for (let i = 0; i < 24; i++) k += (i && !(i % 4) ? '-' : '') + substr(A, ord(b, i) & 31, 1);
return k;
}
function cloudsecs(N) {
let X = rc(), C = N.rec.cloud;
if (!X || type(C) != 'object' || !C.acct) return true;
let W = {}, cr = X.rcsec('wfrecx'), rem = X.rcname(C.acct) + ':' + substr(cbase(), 1), n = 0;
if (cr?.password && cr.remote != rem) W.wfrecx = { ...cr, remote: rem };
for (let id in (C.cams ?? [])) {
let s = 'wfrc' + n + 'x', want = 'wfrecx:' + id, o = X.rcsec(s);
if (o?.type != 'alias' || o.remote != want) W[s] = { type: 'alias', remote: want };
n++;
}
for (let i = n; i < (C.nsec ?? 0); i++) W['wfrc' + i + 'x'] = null;
C.nsec = n;
return !length(W) || X.rcset(W);
}
function rcsecok(X) { return X.rcsec('wfrecx')?.password != null; }
function reccloud(N, now) {
let C = N.rec.cloud, Q = rjs(RCQ) ?? {}, day = today();
if (Q.day != day) { Q.day = day; Q.today = 0; }
let keep = [];
for (let j in (type(Q.jobs) == 'array' ? Q.jobs : [])) {
let o = rjs(CT + '/jobs/' + j + '.json');
if (type(o) != 'object') continue;
if (!match(o.state ?? '', /^(ok|err|stop)$/)) { push(keep, j); continue; }
let by = isnum(o.bytes) ? o.bytes : 0;
Q.today = (Q.today ?? 0) + by; Q.bytes = (Q.bytes ?? 0) + by;
if (o.state == 'ok') { Q.last = now; Q.err = false; } else if (o.state == 'err') Q.err = true;
}
Q.jobs = keep;
let X = cloudon(N) ? rc() : null, dk = rdisk(N, disks()), stg = stgon(N, dk), LC = limof(N.rec).cloud;
if (X) cloudsecs(N);
if (X && !length(keep) && (stg || cin(C, now)) && now - (Q.tq ?? 0) >= (stg ? 270 : 870) && !X.paused() && rcsecok(X)) {
let cap = int(C.gb_day * GB) - (Q.today ?? 0), CM = filter(map(C.cams ?? [], (id) => camof(N, id)), (c) => c && (!stg || stat(STG + '/' + c.id)?.type == 'directory'));
if (cap <= 0) {
if (trim(readfile(CT + '/camcap.day') ?? '') != day) {
writefile(CT + '/camcap.day', day + '\n');
detach('sh ' + q(R + '/usr/share/wrtfreedom/event.sh') + ' cron cloud_camcap cloud ' + q(L('🗄️ Copia Fuori Casa ¦ Tetto di oggi raggiunto ¦ ', '🗄️ Off-Site Copy ¦ Today\'s limit reached ¦ ') + int(C.gb_day * 1024) + ' MB'));
}
}
else if (length(CM)) {
let night = localtime(now).hour >= 3 && Q.nightday != day ? 1 : 0, per = int(cap / length(CM)) || 1, n = 0;
for (let d in [ CT, CT + '/jobs', CT + '/q' ]) mkdir(d, 0700);
for (let c in CM) {
let job = 'jr' + substr(rid(), 0, 10) + n, i = index(C.cams, c.id);
let o = { job: job, kind: 'camup', name: L('Copia Fuori Casa · ', 'Off-Site Copy · ') + c.name, from: c.name, to: cbase(), id: C.acct, acct: C.acct,
rem: 'wfrc' + i + 'x', cap: per, keep_days: LC.days.on ? LC.days.n : 0, max_gb: LC.cap.on ? LC.cap.gb : 0, night: night,
net: C.net ?? { mode: 'same' }, what: C.what ?? 'all', how: C.how ?? 'clips', t: now };
if (stg) { o.stage = STG + '/' + c.id; o.move = 1; } else { o.disk = dk; o.src = cdir(c); }
wpriv(CT + '/q/' + job + '.json', sprintf('%J', o));
wpriv(CT + '/jobs/' + job + '.q.json', sprintf('%J', o));
wpriv(CT + '/jobs/' + job + '.json', sprintf('%J', { ...o, state: 'wait', why: L('In coda', 'Queued'), why_en: 'Queued', pct: 0, speed: 0, bytes: 0, size: 0 }));
push(Q.jobs, job); n++;
}
if (night) Q.nightday = day;
Q.tq = now;
if (stat(CSH)) detach('sh ' + q(CSH) + ' tick');
}
}
wjs(RCQ, Q);
return { jobs: length(Q.jobs) };
}

function camout(N, c, S, now, LS, dk) {
let s = S.cams?.[c.id] ?? {}, k = (c.days ?? 0) > 0 ? c.days : 'auto', ld = lcap(S.left_days);
if (ld != null && k != 'auto' && k < ld) ld = k;
return { id: c.id, name: c.name, mac: c.mac ?? '', ip: (c.mac && LS[c.mac]?.ip) || c.ip || '', vendor: c.vendor ?? '', how: c.how, user: c.user, dir: cdir(c) ?? c.dir,
share: c.how == 'smb' ? c.name : '', disk: dk ?? '', left_days: ld,
used: s.used ?? 0, files: s.files ?? 0, last: s.last ?? 0, oldest: s.oldest ?? 0, fixed: s.fixed === true, keep: k, noinet: c.noinet === true,
seen: S.seen?.[c.mac] ?? 0, state: N.rec.on === true ? camstate(N.rec, c, s, now) : 'off', warn_h: c.warn_h ?? 0, pause_until: (c.pause_until ?? 0) > now ? c.pause_until : 0,
h24: s.h24 ?? [], added: c.added ?? 0 };
}
function vguess(nm) {
nm = lc('' + (nm ?? ''));
for (let k in keys(VCAP)) if (index(nm, k) >= 0) return k == 'tp-link' ? 'TP-Link' : uc(substr(k, 0, 1)) + substr(k, 1);
return '';
}
function found(N, LS, X) {
let mine = {}, r = [], seen = {};
for (let c in N.rec.cams) { if (c.mac) mine[c.mac] = 1; if (c.ip) mine[c.ip] = 1; }
let add = (mac, ip, vendor, via, at, name) => {
let k = mac || ip;
if (!length(k) || seen[k] || mine[mac] || mine[ip]) return;
seen[k] = 1;
let v = vendor || ouiget(mac)?.[0] || vguess(name || LS[mac]?.name);
let cp = vcap(v);
push(r, { mac: mac, ip: ip, name: name || LS[mac]?.name || v, vendor: v, via: via, at: at, smb: cp[0], ftp: cp[1], how: cp[2] });
};
for (let f in (type(X.found) == 'array' ? X.found : [])) if (type(f) == 'object') add(lc(f.mac ?? ''), f.ip ?? '', f.vendor ?? '', 'onvif', f.at ?? X.at ?? 0, f.name ?? '');
for (let mac, l in LS) {
let o = ouiget(mac);
if (o?.[1] == 'camera' || (!o?.[1] && match(l.name ?? '', CAMNAME))) add(mac, l.ip, o?.[0] ?? '', 'mac', 0, l.name);
}
return r;
}
function out(N, D) {
let r = N.rec, S = rjs(ST) ?? {}, now = time(), LS = leases(), A = advof(r), dk = rdisk(N, D);
let C = map(r.cams, (c) => camout(N, c, S, now, LS, dk)), warn = map(filter(C, (c) => c.state == 'warn'), (c) => c.name);
let state = 'ok', why = null, last = 0;
for (let c in C) if (c.last > last) last = c.last;
let where = !length(dk) ? (stgon(N, dk) ? 'cloud' : 'none') : 'disk';
if (r.on !== true) state = 'off';
else if (where == 'cloud') { state = 'warn'; why = [ 'Disco Principale non collegato: salvo sul cloud', 'Main Drive not connected: saving to the cloud' ]; }
else if (where == 'none') { state = 'warn'; why = [ 'Disco Principale non collegato', 'Main Drive not connected' ]; }
else if (length(warn)) { state = 'warn'; why = whynot(warn); }
else if (S.full === true) { state = 'warn'; why = [ 'Disco pieno', 'Disk full' ]; }
let h = type(S.h24) == 'array' && length(S.h24) == 24 ? S.h24 : map([ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ], (x) => x);
let sc = stat('/tmp/wf-nasrec-scan.lock'), scanning = sc != null && now - sc.mtime < 60, SC = rjs(SCAN) ?? {};
let ck = stat(CHK), checking = ck != null && now - ck.mtime < 60;
return { on: r.on === true, disk: dk, dir: cbase(), where: where, lim: limof(r), warn_h: warnh(r), motion_at: r.motion_at ?? '21:00', state: state, why: why ? L(why[0], why[1]) : null, why_en: why ? why[1] : null,
rec: length(filter(C, (c) => c.state == 'ok')), tot: length(C), used: S.used ?? 0, files: S.files ?? 0, oldest: S.oldest ?? 0, last: last || (S.last ?? 0),
left_days: lcap(S.left_days), free: S.free ?? null, total: S.total ?? null, h24: h, cams: C, found: found(N, LS, SC), scanning: scanning, checking: checking,
adv: A, auth: authof(r), cloud: cloudout(N), ip: lanip(), ftp_ok: has('/usr/sbin/vsftpd'), onvif_ok: SC.onvif_ok ?? null, engine: engine(N, D), t: S.t ?? 0 };
}

function t14(s) { return timelocal({ year: +substr(s, 0, 4), mon: +substr(s, 4, 2), mday: +substr(s, 6, 2), hour: +substr(s, 8, 2), min: +substr(s, 10, 2), sec: +substr(s, 12, 2) }); }
function hms(h, m, s) { return +h * 3600 + +m * 60 + +s; }
function durof(n) {
let d = null, m = match(n, /([0-9]{14})[^0-9]+([0-9]{14})/);
if (m) d = t14(m[2]) - t14(m[1]);
else if ((m = match(n, /_[0-9]{8}_([0-9]{2})([0-9]{2})([0-9]{2})_([0-9]{2})([0-9]{2})([0-9]{2})/))) d = hms(m[4], m[5], m[6]) - hms(m[1], m[2], m[3]);
else if ((m = match(n, /([0-9]{2})\.([0-9]{2})\.([0-9]{2})-([0-9]{2})\.([0-9]{2})\.([0-9]{2})/))) d = hms(m[4], m[5], m[6]) - hms(m[1], m[2], m[3]);
if (d != null && d < 0) d += DAY;
return d != null && d > 0 && d <= DAY ? d : null;
}
function codecof(n) {
n = lc(n);
if (match(n, /hevc|(^|[^0-9])265([^0-9]|$)/)) return 'h265';
if (match(n, /\.dav$/)) return 'dav';
if (match(n, /(^|[^0-9])264([^0-9]|$)/)) return 'h264';
return null;
}
const VIDEO = /\.(mp4|mkv|avi|mov|dav|264|265|h264|h265|ts|asf|m4v|3gp)$/i;
const CLEAN = /\.(mp4|mkv|avi|mov|dav|264|265|h264|h265|ts|asf|m4v|3gp|jpg|jpeg)$/i;
const DATEIN = /(20[0-9][0-9])[-_.]?([01][0-9])[-_.]?([0-3][0-9])/;
function dlist(W, p, dep) {
if (dep > 8 || W.n > 200000) return;
let s = stat(p), old = s != null && s.mtime < W.d0 - 21600;
for (let f in (lsdir(p) ?? [])) {
if (substr(f, 0, 1) == '.') continue;
let m = match(f, DATEIN);
if (m && !W.ok[m[1] + m[2] + m[3]]) continue;
if (old && match(f, CLEAN)) continue;
let fp = p + '/' + f, t = lstat(fp);
W.n++;
if (t?.type == 'directory') dlist(W, fp, dep + 1);
else if (t?.type == 'file' && t.mtime >= W.d0 && t.mtime < W.d1 && match(f, VIDEO)) push(W.F, [ t.mtime, t.size, fp ]);
}
}
function dayline(F, d0, fixed) {
let seg = [];
for (let f in sort(F, (a, b) => a.t - b.t)) {
let e = f.t - d0, s = e - (f.dur ?? 60);
if (s < 0) s = 0;
let l = length(seg) ? seg[length(seg) - 1] : null;
if (l && s - l[1] <= 180) { if (e > l[1]) l[1] = e; } else push(seg, [ s, e ]);
}
return { line: map(seg, (x) => [ r1(x[0] / 3600), r1(x[1] / 3600) ]), motion: fixed ? [] : map(seg, (x) => r1(x[0] / 3600)) };
}

function dfb(p) {
let m = match(sh('df -kP ' + q(p) + ' 2>/dev/null'), /\n[^\n]*[ \t]([0-9]+)[ \t]+([0-9]+)[ \t]+([0-9]+)[ \t]+[0-9]+%/);
return m ? [ +m[3] * 1024, +m[1] * 1024 ] : [ 0, 0 ];
}
function walk(p, C, NC, full, A, dep) {
if (dep > 8 || A.files > 200000) return;
let s = stat(p);
if (s?.type != 'directory') return;
let c = C[p], e = null;
if (!full && type(c) == 'object' && c.m == s.mtime && c.m < (c.t ?? 0) - 1) {
e = c; e.r = filter(c.r ?? [], (x) => x[0] > A.since);
}
else {
e = { m: s.mtime, t: time(), n: 0, b: 0, o: 0, l: 0, r: [], d: [], z: {} };
for (let f in (lsdir(p) ?? [])) {
if (substr(f, 0, 1) == '.') continue;
let fp = p + '/' + f, t = lstat(fp);
if (!t) continue;
if (t.type == 'directory') { if (!A.skip[fp]) push(e.d, f); continue; }
if (t.type != 'file') continue;
e.n++; e.b += t.size;
if (!e.o || t.mtime < e.o) e.o = t.mtime;
if (t.mtime > e.l) e.l = t.mtime;
if (t.mtime > A.since) push(e.r, [ t.mtime, t.size ]);
if (t.size >= 1048576) e.z['' + t.size] = (e.z['' + t.size] ?? 0) + 1;
}
let zk = keys(e.z);
if (length(zk) > 32) { let z = {}; for (let k in slice(sort(zk, (a, b) => e.z[b] - e.z[a]), 0, 32)) z[k] = e.z[k]; e.z = z; }
}
NC[p] = e;
A.files += e.n; A.used += e.b;
if (e.o && (!A.oldest || e.o < A.oldest)) A.oldest = e.o;
if (e.l > A.last) A.last = e.l;
for (let x in e.r) push(A.recent, x);
for (let k, v in e.z) A.z[k] = (A.z[k] ?? 0) + v;
for (let d in e.d) walk(p + '/' + d, C, NC, full, A, dep + 1);
}
function h24of(R2, now) {
let hs = now - now % 3600, h = [];
for (let i = 0; i < 24; i++) push(h, 0);
for (let x in R2) { let d = int((hs + 3599 - x[0]) / 3600), k = 23 - d; if (k >= 0 && k <= 23) h[k] += x[1]; }
return map(h, (b) => r1(b / GB));
}
function seenread(S) {
let now = time(), LS = leases();
if (type(S.seen) != 'object') S.seen = {};
for (let l in split(sh('ip -4 neigh show 2>/dev/null'), '\n')) {
let m = match(l, /^([0-9.]+) .*lladdr ([0-9a-fA-F:]+) (REACHABLE|DELAY|PROBE)/);
if (m) S.seen[lc(m[2])] = now;
}
return LS;
}
function recstat(N, full, S) {
let D = disks(), r = N.rec, now = time(), dk = rdisk(N, D), base = length(dk) ? absof(D, dk, cbase()) : null, C = rjs(IDX) ?? {}, NC = {}, A2 = advof(r), K = limof(r).disk;
S.cams = type(S.cams) == 'object' ? S.cams : {};
seenread(S);
if (!base) { S.t = now; return S; }
let skip = {}, all = { used: 0, files: 0, oldest: 0, last: 0 }, h = [], rate = 0, nf = 0;
for (let c in r.cams) { let p = absof(D, dk, cdir(c)); if (p) skip[p] = 1; }
let one = (id, p) => {
let old = S.cams[id] ?? {}, A = { files: 0, used: 0, oldest: 0, last: 0, recent: [], z: {}, since: now - 25 * 3600, skip: id == '_' ? skip : {} };
if (p) walk(p, C, NC, full || old.fixed === true, A, 0);
let zm = 0; for (let k, v in A.z) if (v > zm) zm = v;
let fixed = A2.fixed && zm >= 4 && zm * 10 >= A.files * 6, d24 = 0;
for (let x in A.recent) if (x[0] > now - DAY) d24 += x[1];
let rt = d24 > 0 ? d24 : (A.oldest && A.last > A.oldest ? int(A.used / ((A.last - A.oldest) / DAY + 1)) : 0);
S.cams[id] = { used: A.used, files: A.files, oldest: A.oldest, last: A.last, fixed: fixed, h24: h24of(A.recent, now), rate: rt };
all.used += A.used; all.files += A.files; if (A.last > all.last) all.last = A.last;
if (A.oldest && (!all.oldest || A.oldest < all.oldest)) all.oldest = A.oldest;
for (let x in A.recent) push(h, x);
if (!fixed) { rate += rt; nf += A.used; }
};
for (let c in r.cams) one(c.id, absof(D, dk, cdir(c)));
one('_', base);
for (let id in keys(S.cams)) if (id != '_' && !camof(N, id)) delete S.cams[id];
let fb = dfb(base);
S.used = all.used; S.files = all.files; S.oldest = all.oldest; S.last = all.last; S.h24 = h24of(h, now); S.free = fb[0]; S.total = fb[1]; S.rate = rate; S.t = now;
let left = null;
if (rate > 0) {
left = int((nf + fb[0]) / rate);
if (K.days.on && K.days.n < left) left = K.days.n;
if (K.cap.on) { let cp = int(int(fb[1] * K.cap.pct / 100) / rate); if (cp < left) left = cp; }
}
S.left_days = lcap(left);
wjs(IDX, NC);
return S;
}
const CTIME = R == '' || getenv('WF_RECCTIME') == '1';
function flist(F, id, p, sk, dep) {
if (dep > 8 || length(F) > 200000) return;
for (let f in (lsdir(p) ?? [])) {
if (substr(f, 0, 1) == '.') continue;
let fp = p + '/' + f, t = lstat(fp);
if (t?.type == 'directory') { if (!sk[fp]) flist(F, id, fp, sk, dep + 1); }
else if (t?.type == 'file') push(F, [ CTIME && (t.ctime ?? 0) > t.mtime ? t.ctime : t.mtime, t.size, fp, id ]);
}
}
function recclean(N, S) {
let D = disks(), r = N.rec, now = time(), dk = rdisk(N, D), stg = stgon(N, dk), K = limof(r).disk;
if (r.on !== true || (!length(dk) && !stg)) return 0;
let base = length(dk) ? absof(D, dk, cbase()) : STG;
if (!base) return 0;
let F = [], cut = {}, fresh = length(dk) ? now - KEEPD * DAY : now - FRESH;
for (let c in r.cams) {
if (length(dk) && S.cams?.[c.id]?.fixed === true) continue;
let p = campath(N, D, dk, c); if (!p) continue;
flist(F, c.id, p, {}, 0);
let dd = (c.days ?? 0) > 0 ? c.days : (K.days.on ? K.days.n : 0);
if (dd > 0 && length(dk)) cut[c.id] = now - dd * DAY;
}
F = sort(filter(F, (x) => match(x[2], CLEAN) != null), (a, b) => a[0] - b[0]);
let n = 0, fb = 0, tot = 0, rm = (x) => { if (unlink(x[2])) { n++; fb += x[1]; tot -= x[1]; x[1] = -1; } };
for (let x in F) tot += x[1];
for (let x in F) if (cut[x[3]] && x[0] < cut[x[3]] && x[0] < fresh) rm(x);
let df = length(dk) ? dfb(base) : [ 0, 0 ], need = 0;
if (!length(dk)) need = tot - camram();
else if (K.cap.on) need = tot - int(df[1] * K.cap.pct / 100);
for (let x in F) { if (need <= 0) break; if (x[1] < 0 || x[0] >= fresh) continue; let b = x[1]; rm(x); need -= b; }
S.full = length(dk) && df[1] > 0 && df[0] + fb < int(df[1] / 50);
if (n > 0) {
for (let c in r.cams) { let p = campath(N, D, dk, c); if (p) sh('find ' + q(p) + ' -mindepth 1 -type d -empty -delete 2>/dev/null'); }
let day = today();
if (!length(dk)) {
if (S.ramday != day) {
S.ramday = day;
ev('nas_cams_limit', '⚠️ Telecamere ¦ RAM Piena: Video Tolti ¦ ' + n + ' video · ' + r1(fb / 1048576) + ' MB non nel cloud',
'⚠️ Cameras ¦ RAM Full: Videos Removed ¦ ' + n + ' videos · ' + r1(fb / 1048576) + ' MB not in the cloud', 'admin');
}
}
else if (S.limday != day) {
S.limday = day;
ev('nas_cams_limit', '🗄️ Telecamere ¦ Al Limite: Tolte Le Vecchie ¦ ' + n + ' video · ' + r1(fb / GB) + ' GB',
'🗄️ Cameras ¦ At The Limit: Oldest Removed ¦ ' + n + ' videos · ' + r1(fb / GB) + ' GB', 'admin');
}
}
if (length(dk) && K.cap.on && need > 0) {
let day = today();
if (S.capday != day) {
S.capday = day;
if (KEEPD == 1) ev('nas_cams_limit', '🗄️ Telecamere ¦ Tenuto L\'Ultimo Giorno ¦ Alza il Tetto o libera spazio',
'🗄️ Cameras ¦ Last Day Kept ¦ Raise the cap or free up space', 'admin');
else ev('nas_cams_limit', '🗄️ Telecamere ¦ Tenuti Gli Ultimi ' + KEEPD + ' Giorni ¦ Alza il Tetto o libera spazio',
'🗄️ Cameras ¦ Last ' + KEEPD + ' Days Kept ¦ Raise the cap or free up space', 'admin');
}
}
S.clean = now;
return n;
}
function recevents(N, S) {
let r = N.rec, now = time(), lt = localtime(now), day = sprintf('%04d-%02d-%02d', lt.year, lt.mon, lt.mday);
if (type(S.muted) != 'object') S.muted = {};
for (let c in r.cams) {
let st = camstate(r, c, S.cams?.[c.id], now);
if (st == 'warn' && !S.muted[c.id]) {
S.muted[c.id] = now;
let h = type(c.warn_h) == 'int' && c.warn_h > 0 ? c.warn_h : warnh(r);
ev('nas_cam_mute', '⚠️ Telecamere ¦ ' + c.name + ' non salva da ' + h + (h == 1 ? ' ora' : ' ore') + ' ¦ Controlla la telecamera',
'⚠️ Cameras ¦ ' + c.name + ' has not saved for ' + h + (h == 1 ? ' hour' : ' hours') + ' ¦ Check the camera');
}
else if (st != 'warn') delete S.muted[c.id];
}
for (let id in keys(S.muted)) if (!camof(N, id)) delete S.muted[id];
let m = match(r.motion_at ?? '21:00', /^([0-9]{2}):([0-9]{2})$/);
if (m && S.motion_day != day && lt.hour * 60 + lt.min >= +m[1] * 60 + +m[2]) {
S.motion_day = day;
let d0 = timelocal({ year: lt.year, mon: lt.mon, mday: lt.mday, hour: 0, min: 0, sec: 0 }), parts = [], D = disks(), dk = rdisk(N, D), C = rjs(IDX) ?? {};
for (let c in r.cams) {
if (S.cams?.[c.id]?.fixed === true || !length(dk)) continue;
let p = absof(D, dk, cdir(c)), F = [];
if (!p) continue;
for (let k, e in C) if ((k == p || index(k, p + '/') == 0) && type(e?.r) == 'array') for (let x in e.r) if (x[0] >= d0) push(F, { t: x[0] });
let n = length(dayline(F, d0, false).motion);
if (n > 0) push(parts, c.name + ' ' + n);
}
if (length(parts)) ev('nas_cam_motion', '📹 Movimenti Di Oggi ¦ ' + join(' · ', parts), '📹 Today\'s Motion ¦ ' + join(' · ', parts));
}
}
function onvif() {
let so = null;
try { so = require('socket'); } catch (e) { so = null; }
if (!so) return null;
let r = [], A = {}, lip = lanip();
try {
let s = so.create(so.AF_INET, so.SOCK_DGRAM);
if (!length(lip) || !s.bind({ family: so.AF_INET, address: lip, port: 0 })) { s.close(); return r; }
let msg = '<?xml version="1.0" encoding="UTF-8"?><e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" ' +
'xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" xmlns:dn="http://www.onvif.org/ver10/network/wsdl"><e:Header><w:MessageID>uuid:' +
trim(readfile('/proc/sys/kernel/random/uuid') ?? '') + '</w:MessageID><w:To e:mustUnderstand="true">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>' +
'<w:Action e:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header><e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body></e:Envelope>';
s.send(msg, 0, { address: '239.255.255.250', port: 3702 });
let end = time() + 3;
while (time() < end) {
let p = so.poll(500, [ s, so.POLLIN ]);
if (!p || !length(p) || !(p[0][1] & so.POLLIN)) continue;
let from = {}, d = s.recv(65535, 0, from);
if (!d) continue;
let ip = from.address ?? '', x = match(d, /https?:\/\/([0-9.]+)[:\/]/);
if (x) ip = x[1];
if (!ipok(ip) || A[ip]) continue;
A[ip] = 1;
let nm = match(d, /onvif:\/\/www\.onvif\.org\/name\/([^ <]+)/), hw = match(d, /onvif:\/\/www\.onvif\.org\/hardware\/([^ <]+)/);
let mc = match(d, /onvif:\/\/www\.onvif\.org\/MAC\/([0-9A-Fa-f:-]+)/i), mh = mc ? lc(replace(mc[1], /[:-]/g, '')) : '';
mh = length(mh) == 12 ? join(':', map([ 0, 2, 4, 6, 8, 10 ], (i) => substr(mh, i, 2))) : '';
push(r, { ip: ip, name: nm ? replace(nm[1], /%20/g, ' ') : '', model: hw ? replace(hw[1], /%20/g, ' ') : '', mac: macok(mh) ? mh : '' });
}
s.close();
} catch (e) {}
return r;
}
function recscan(N) {
let now = time(), X = { at: now, found: [] }, A = arp(), LS = leases();
let O = advof(N.rec).onvif ? onvif() : [];
for (let f in (O ?? [])) {
let mac = A[f.ip] ?? '';
if (!length(mac)) for (let m, l in LS) if (l.ip == f.ip) mac = m;
if (!length(mac)) mac = f.mac ?? '';
let nm = f.name ?? '', md = f.model ?? '';
if (length(md) && index(lc(nm), lc(md)) < 0) nm = length(nm) ? nm + ' ' + md : md;
push(X.found, { mac: mac, ip: f.ip, vendor: ouiget(mac)?.[0] ?? vguess(f.name + ' ' + f.model), name: nm, at: now });
}
X.onvif_ok = O != null;
wjs(SCAN, X);
return X;
}
function recfollow(N, now) {
let r = N.rec;
if (r.on !== true) return false;
let ended = filter(r.cams, (c) => (c.pause_until ?? 0) > 0 && c.pause_until <= now);
let D = disks(), dk = rdisk(N, D), fw = ftpwant(N, D) != (index(N.ours ?? [], 'wf-nasftp') >= 0);
if (length(dk)) camdirs(N, D, dk);
let N0 = nget(), sy = camsync(N0, dk);
if (length(ended) || fw || sy) {
for (let c in N0.rec.cams) if ((c.pause_until ?? 0) > 0 && c.pause_until <= now) delete c.pause_until;
let ok = recsave(N0, D);
if (ok && sy && length(filter(N0.rec.cams, (c) => c.how == 'smb'))) smbapply(N0.smb_off !== true);
return ok;
}
if (ftpwant(N, D) && ftpwrite(N, D)) { detach('sh ' + q(SH) + ' svc wf-nasftp:on'); return true; }
return false;
}
function recjob(what, id) {
begin();
let N = nget(), S = rjs(ST) ?? {}, now = time(), r = N.rec;
if (what == 'scan') { let X = recscan(N); return { found: length(X.found) }; }
if (what == 'follow') return { did: recfollow(N, time()) };
if (what == 'cloud') return type(r.cloud) == 'object' && (r.cloud.on === true || type(rjs(RCQ)?.jobs) == 'array') ? reccloud(N, now) : { off: true };
if (r.on !== true && what != 'stat') return { off: true };
if (what == 'check' && camof(N, id)?.mac) {
let c = camof(N, id), ip = leases()[c.mac]?.ip ?? c.ip;
if (ipok(ip) && match(sh('ping -c 1 -W 2 ' + q(ip) + ' >/dev/null 2>&1 && echo si'), /si/)) { if (type(S.seen) != 'object') S.seen = {}; S.seen[c.mac] = now; }
}
let full = what == 'clean' || (what == 'tick' && (now - (S.clean ?? 0) >= advof(r).check_min * 60 || stgon(N, rdisk(N, disks()))));
if (full && r.on === true) recclean(N, S);
recstat(N, full, S);
if (what == 'tick' && r.on === true) {
recevents(N, S);
recfollow(N, now);
}
wjs(ST, S);
return { ok: true };
}

const NAMERE = /^[A-Za-z0-9][A-Za-z0-9 _.-]{0,31}$/;
function reserved(n) {
let t = readfile(getenv('WF_NASVCUC') ?? '/usr/share/wrtfreedom/nasvc.uc') ?? '', m = match(t, /\nconst RESV = (\{[^\n]*\});/), V = null;
try { V = m ? json(m[1]) : null; } catch (e) { V = null; }
if (type(V?.names) != 'array' || type(V?.starts) != 'array') return true;
let l = lc(trim(replace('' + (n ?? ''), /[ \t]+/g, ' ')));
if (index(V.names, l) >= 0) return true;
for (let s in V.starts) if (substr(l, 0, length(s)) == s) return true;
return false;
}
function slug(s) { return substr(trim(replace(lc('' + s), /[^a-z0-9._-]+/g, '-'), '-.'), 0, 28); }
function sysuser(u) {
for (let l in split(readfile(R + '/etc/passwd') ?? '', '\n')) { let p = split(l, ':'); if (p[0] == u) return p[4] != 'wf-nas'; }
return false;
}
function admerr(req) {
if (type(UCFG.who) != 'function') return null;
let O = {}, W = UCFG.who(req, O);
if (W?.adm === true) return null;
if (W) return err('admin', 'Solo l\'Amministratore', 'Administrator only');
return O.why == 'blocked' ? err('blocked', 'Accesso bloccato dall\'Amministratore', 'Access blocked by the Administrator') : err('who', 'Accesso scaduto: entra di nuovo', 'Access expired: sign in again');
}
function addr(c) { let ip = lanip(); return !length(ip) ? '' : (c.how == 'ftp' ? 'ftp://' + ip + ':21' : 'smb://' + ip + '/' + c.name); }

const M = {
nas_rec: {
args: { act: 'x', on: true, lim: {}, days: 0, warn_h: 0, motion_at: 'x', adv: {},
id: 'x', mac: 'x', ip: 'x', name: 'x', how: 'x', noinet: true, pause_min: 0, auth: {}, cloud: {} },
call: function(req) {
begin();
let ae = admerr(req);
if (ae) return ae;
let N = nget(), r = N.rec, a = req.args, D = disks(), now = time(), dk = rdisk(N, D);
let act = a.act ?? (length(filter([ 'on', 'lim', 'warn_h', 'motion_at', 'adv', 'auth', 'cloud' ], (k) => a[k] != null)) ? 'set' : 'get');
if (act == 'get') {
if (r.on === true && now - (stat(ST)?.mtime ?? 0) > 600) detach('sh ' + q(RSH) + ' stat');
if ((ftpwant(N, D) && length(filter(ftpcams(N, D), (c) => readfile(FTPD + '/' + c.user) != 'local_root=' + campath(N, D, dk, c) + '\n'))) ||
(r.on === true && camsync({ ...N, rec: { ...r, cams: map(r.cams, (c) => ({ ...c })) }, shares: map(N.shares, (s) => ({ ...s })) }, dk)))
detach('sh ' + q(RSH) + ' follow');
return out(N, D);
}
if (act == 'scan') {
let sl = stat('/tmp/wf-nasrec-scan.lock');
if (sl == null || now - sl.mtime >= 60) detach('sh ' + q(RSH) + ' scan');
return { ...out(N, D), scanning: true };
}
if (act == 'keyok') {
if (type(r.cloud) == 'object' && r.cloud.stf == 'setup') {
delete r.cloud.stf;
if (!nput(N)) return busy();
}
return { ...out(nget(), D), ok: true };
}
if (act == 'rekey') {
let C = r.cloud, Q = rjs(RCQ) ?? {};
if (type(C) != 'object' || C.on !== true || C.stf != 'setup' || length(Q.jobs ?? []) || (Q.last ?? 0) > 0 || (Q.bytes ?? 0) > 0)
return err('rekey', 'La chiave è già salvata: non si rifà', 'The key is already saved: it cannot be remade');
let ckey = newkey();
if (!ckey) return err('key', 'Chiave non creata: riprova', 'Key not created: try again');
wpriv(RCPW, ckey + '\n'); detach('sh ' + q(RSH) + ' cryptset');
return { ...out(nget(), D), ok: true, key: ckey };
}
if (act == 'set') {
let on = type(a.on) == 'bool' ? a.on : r.on === true;
let CS = null, ckey = null;
if (a.cloud != null) {
CS = cloudset(N, a.cloud, rjs(ST) ?? {});
if (CS.error) return CS;
if (CS.C.on === true && CS.C.keyed !== true) { ckey = newkey(); if (!ckey) return err('key', 'Chiave non creata: riprova', 'Key not created: try again'); CS.C.keyed = true; CS.C.stf = 'setup'; }
}
let K = limof(r), A = advof(r);
if (a.lim != null) { let LS2 = limset(r, a.lim); if (LS2.error) return LS2; K = LS2.L; }
if (a.warn_h != null && (type(a.warn_h) != 'int' || a.warn_h < 1 || a.warn_h > 168)) return err('warn_h', 'Ore non valide (1–168)', 'Invalid hours (1–168)');
if (a.motion_at != null && a.motion_at != '' && !match(a.motion_at, /^([01][0-9]|2[0-3]):[0-5][0-9]$/)) return err('motion_at', 'Orario non valido', 'Invalid time');
if (a.adv != null) {
if (type(a.adv) != 'object') return err('adv', 'Valori non validi', 'Invalid values');
for (let k in [ 'onvif', 'ftp', 'smb1', 'fixed', 'outside' ]) if (a.adv[k] != null && type(a.adv[k]) != 'bool') return err('adv', 'Valori non validi', 'Invalid values');
if (a.adv.check_min != null && index([ 15, 30, 60, 180 ], a.adv.check_min) < 0) return err('adv', 'Controllo Della Cartella: 15, 30, 60 o 180 minuti', 'Folder Check: 15, 30, 60 or 180 minutes');
if (a.adv.smb1 === true && !has('/usr/sbin/smbd')) return pkgerr([ 'samba4-server' ]);
for (let k in [ 'onvif', 'ftp', 'smb1', 'fixed', 'outside' ]) if (a.adv[k] != null) A[k] = a.adv[k];
if (a.adv.check_min != null) A.check_min = a.adv.check_min;
}
if (on && r.on !== true) {
let cl = CS ? CS.C : r.cloud;
if (!length(dk) && !(type(cl) == 'object' && cl.on === true && cl.stf != 'setup'))
return err('nomain', 'Manca il Disco Principale', 'Main Drive missing');
}
if (on && length(dk) && !camdirs(N, D, dk)) return err('path', 'Cartella delle telecamere non creata: il disco è pieno?', 'Cameras folder not created: is the disk full?');
camsync(N, dk);
r.on = on; r.lim = K; r.adv = A;
if (a.warn_h != null) r.warn_h = a.warn_h;
if (a.motion_at != null) r.motion_at = a.motion_at;
delete r.auth;
if (CS) { r.cloud = CS.C; cloudsecs(N); }
let sch = camallow(N);
if (!recsave(N, D)) return busy();
if (ckey) { wpriv(RCPW, ckey + '\n'); detach('sh ' + q(RSH) + ' cryptset'); }
recwrite(N, dk);
if (sch || length(filter(r.cams, (c) => c.how == 'smb'))) smbapply(N.smb_off !== true);
if (on) detach('sh ' + q(RSH) + ' stat');
return ckey ? { ...out(nget(), D), ok: true, key: ckey } : out(nget(), D);
}
if (act == 'add') {
let mac = lc('' + (a.mac ?? '')), ip = '' + (a.ip ?? ''), LS = leases(), AR = arp();
if (length(mac) && !macok(mac)) return err('mac', 'Dispositivo non valido', 'Invalid device');
if (length(ip) && !ipok(ip)) return err('ip', 'Indirizzo IP non valido', 'Invalid IP address');
if (!length(mac) && !length(ip)) return err('cam', 'Scegli la telecamera o scrivi il suo indirizzo IP', 'Choose the camera or type its IP address');
if (!length(mac)) { mac = AR[ip] ?? ''; if (!length(mac)) for (let m, l in LS) if (l.ip == ip) mac = m; }
if (!length(ip) && length(mac)) { ip = LS[mac]?.ip ?? ''; if (!length(ip)) for (let i, m in AR) if (m == mac) ip = i; }
for (let c in r.cams) if ((length(mac) && c.mac == mac) || (length(ip) && !length(mac) && c.ip == ip))
return err('dup', 'Telecamera già collegata: ' + c.name, 'Camera already connected: ' + c.name);
let fv = filter(rjs(SCAN)?.found ?? [], (f) => f?.ip == ip)[0], vendor = ouiget(mac)?.[0] ?? fv?.vendor ?? '';
let how = a.how ?? (vcap(vendor)[2] || 'smb');
if (how != 'smb' && how != 'ftp') return err('how', 'Scegli Samba (SMB) o FTP', 'Choose Samba (SMB) or FTP');
let nm = trim('' + (a.name ?? (vendor || L('Telecamera', 'Camera'))));
if (!match(nm, NAMERE)) return err('name', 'Nome della cartella non valido (lettere, cifre, spazi, fino a 32)', 'Invalid folder name (letters, digits, spaces, up to 32)');
if (reserved(nm)) return err('name', 'Nome riservato alle cartelle del NAS: scegline un altro', 'Name reserved for the NAS folders: choose another');
for (let c in r.cams) if (lc(c.name) == lc(nm)) return err('name', 'Nome già usato da un\'altra telecamera', 'Name already used by another camera');
for (let s in N.shares) if (lc(s.name) == lc(nm)) return err('name', 'Nome già usato da una cartella condivisa', 'Name already used by a shared folder');
let id = slug(nm) || rid(), u = 'cam-' + id;
if (camof(N, id) || N.users[u] || sysuser(u)) return err('name', 'Nome già usato: scegline un altro', 'Name already used: choose another');
let dd = a.days ?? 0;
if (type(dd) != 'int' || dd < 0 || dd > 3650) return err('val', 'Conservazione non valida', 'Invalid retention');
if (length(keys(N.users)) >= 32) return err('max', 'Al massimo 32 utenti (anche quelli delle telecamere)', 'At most 32 users (camera ones included)');
if (a.noinet === true && !length(mac)) return err('noinet', 'Per Blocca Accesso A Internet serve il dispositivo, non solo l\'IP', 'Block Internet Access needs the device, not just the IP');
let md = diskof(D, dk);
if (!md) return err('nomain', 'Manca il Disco Principale', 'Main Drive missing');
if (how == 'smb') {
if (N.smb_off === true) return err('smb_off', 'Cartelle Condivise spente: accendile per una telecamera Samba (SMB)', 'Shared Folders are off: turn them on for a Samba (SMB) camera');
let pk = need(engine(N, D)); if (length(pk)) return pkgerr(pk);
}
else {
if (!advof(r).ftp) return err('ftp', 'FTP Solo Da Casa è spento in Impostazioni Avanzate', 'Home-Only FTP is off in Advanced Settings');
if (noown(md)) return err('fs', 'Con FTP serve un disco ext4 (su NTFS o FAT l\'utente della telecamera non può scrivere): scegli Samba (SMB)', 'FTP needs an ext4 disk (on NTFS or FAT the camera user cannot write): choose Samba (SMB)');
let pk = need('ftp');
if (length(pk)) { r.ftp_req = true; if (!nput(N)) return busy(); return pkgerr(pk); }
if (ftpstock() && r.ftp_req !== true && r.ftp_stock_off !== true)
return err('ftp_busy', 'La porta FTP del router è già usata da vsftpd: usa Samba (SMB)', 'The router FTP port is already used by vsftpd: use Samba (SMB)');
}
let dir = cdir({ name: nm });
if (dir == null || !absof(D, dk, cbase()) || !mkdp(md.mnt, cbase())) return err('path', 'Cartella non valida', 'Invalid folder');
let ab = absof(D, dk, dir);
if (!ab) return err('path', 'Cartella non valida', 'Invalid folder');
if (!mkd(ab)) return err('path', 'Cartella non creata: il disco è pieno o in sola lettura?', 'Folder not created: is the disk full or read-only?');
let pw = newpass(), f = TMP + '/.u' + rid();
wpriv(f, pw);
let o = how == 'smb' ? sh('sh ' + q(SH) + ' userset ' + q(u) + ' ' + q(f) + ' smb 2>/dev/null') : sh('sh ' + q(RSH) + ' ftpuser ' + q(u) + ' ' + q(f) + ' ' + q(ab) + ' 2>/dev/null');
unlink(f);
let ok = uniq(map(filter(split(o, /[ \n]+/), (w) => match(w, /^ok:/)), (w) => substr(w, 3)));
if (!length(ok)) { if (how == 'ftp') sh('sh ' + q(SH) + ' userdel ' + q(u) + ' >/dev/null 2>&1'); return err('pass', 'Utente della telecamera non creato: riprova', 'Camera user not created: try again'); }
let c = { id: id, name: nm, mac: mac, ip: ip, vendor: vendor, how: how, user: u, dir: dir, days: dd, noinet: a.noinet === true, added: now };
push(r.cams, c);
N.users[u] = { label: nm, cam: id, pw: ok };
if (how == 'smb') push(N.shares, { name: nm, disk: dk, path: dir, read: [], write: [ u ], guest: false, cam: id });
let stock = how == 'ftp' && ftpstock() && r.ftp_stock_off !== true;
if (stock) r.ftp_stock_off = true;
if (how == 'ftp' && r.ftp_req === true) r.ftp_mine = true;
delete r.ftp_req;
if (r.on !== true) { r.on = true; r.lim = limof(r); }
camsync(N, dk);
camallow(N);
if (!recsave(N, D, c.noinet ? blkcmd(c, true, nm) : '')) { sh('sh ' + q(SH) + ' userdel ' + q(u) + ' >/dev/null 2>&1'); return busy(); }
let P = pwget(); P[id] = pw; pwput(P);
if (stock) detach(R + '/etc/init.d/vsftpd stop; ' + R + '/etc/init.d/vsftpd disable');
recwrite(N, dk);
if (how == 'smb' && !smbapply(true)) {
let ex = c.noinet ? blkcmd(c, false, nm) : '';
N = nget(); r = N.rec;
r.cams = filter(r.cams, (x) => x.id != id); delete N.users[u]; N.shares = filter(N.shares, (s) => s.cam != id);
if (recsave(N, D, ex)) {
P = pwget(); delete P[id]; pwput(P);
sh('sh ' + q(SH) + ' userdel ' + q(u) + ' >/dev/null 2>&1');
}
return err('smb', 'Cartelle Condivise non aggiornate: riprova', 'Shared Folders not updated: try again');
}
ev('nas_cam_add', '📹 Telecamere ¦ Collegata ¦ ' + nm, '📹 Cameras ¦ Connected ¦ ' + nm);
detach('sh ' + q(RSH) + ' stat');
return { cam: camout(N, c, rjs(ST) ?? {}, now, LS, dk), pass: pw, addr: addr(c) };
}
let c = camof(N, '' + (a.id ?? ''));
if (act == 'cam' || act == 'pass' || act == 'del' || act == 'check') { if (!c) return err('none', 'Telecamera non trovata', 'Camera not found'); }
else return err('act', 'Azione sconosciuta', 'Unknown action');
if (act == 'pass') {
let p = pwget()[c.id];
if (!p) return err('pass', 'Password non disponibile', 'Password not available');
return { id: c.id, user: c.user, pass: p, addr: addr(c) };
}
if (act == 'check') {
writefile(CHK, c.id);
detach('sh ' + q(RSH) + ' check ' + q(c.id));
return { ...out(N, D), checking: true };
}
if (act == 'cam') {
if (a.days != null && (type(a.days) != 'int' || a.days < 0 || a.days > 3650)) return err('val', 'Conservazione non valida', 'Invalid retention');
if (a.warn_h != null && (type(a.warn_h) != 'int' || a.warn_h < 0 || a.warn_h > 168)) return err('warn_h', 'Ore non valide (1–168)', 'Invalid hours (1–168)');
if (a.pause_min != null && (type(a.pause_min) != 'int' || a.pause_min < 0 || a.pause_min > 1440)) return err('pause', 'Pausa non valida (fino a 24 ore)', 'Invalid pause (up to 24 hours)');
if ((a.noinet === true || (a.pause_min ?? 0) > 0) && !macok(c.mac)) return err('mac', 'Serve il dispositivo della telecamera (MAC)', 'The camera device (MAC) is needed');
let ex = '';
if (a.days != null) c.days = a.days;
if (a.warn_h != null) c.warn_h = a.warn_h;
if (a.pause_min != null) { if (a.pause_min > 0) c.pause_until = now + a.pause_min * 60; else delete c.pause_until; }
if (type(a.noinet) == 'bool' && a.noinet != (c.noinet === true)) { c.noinet = a.noinet; ex = blkcmd(c, a.noinet, c.name); }
if (!recsave(N, D, ex)) return busy();
return { ...out(N, D), cam: camout(N, c, rjs(ST) ?? {}, now, leases(), dk) };
}
let ex = c.noinet ? blkcmd(c, false, c.name) : '';
r.cams = filter(r.cams, (x) => x.id != c.id);
delete N.users[c.user];
N.shares = filter(N.shares, (s) => s.cam != c.id);
let left = length(filter(r.cams, (x) => x.how == 'ftp')), drop = false, stock = false;
if (c.how == 'ftp' && !left) {
if (r.ftp_mine === true) drop = true;
else if (r.ftp_stock_off === true && has('/etc/init.d/vsftpd')) stock = true;
delete r.ftp_mine; delete r.ftp_stock_off;
}
if (!recsave(N, D, ex)) return busy();
let P = pwget(); delete P[c.id]; pwput(P);
sh('sh ' + q(SH) + ' userdel ' + q(c.user) + ' >/dev/null 2>&1');
if (stock) detach(R + '/etc/init.d/vsftpd enable; ' + R + '/etc/init.d/vsftpd start');
if (c.how == 'smb') smbapply(nget().smb_off !== true);
ev('nas_cam_del', '📹 Telecamere ¦ Eliminata ¦ ' + c.name, '📹 Cameras ¦ Removed ¦ ' + c.name);
return { ...out(nget(), D), ...(drop ? { drop: [ 'vsftpd' ] } : {}) };
}
},
nas_rec_day: {
args: { id: 'x', day: 'x', limit: 0 },
call: function(req) {
begin();
let ae = admerr(req);
if (ae) return ae;
let N = nget(), a = req.args, D = disks(), dk = rdisk(N, D), c = camof(N, '' + (a.id ?? ''));
if (!c) return err('none', 'Telecamera non trovata', 'Camera not found');
let m = match('' + (a.day ?? ''), /^([0-9]{4})-([0-9]{2})-([0-9]{2})$/);
if (!m) return err('day', 'Giorno non valido', 'Invalid day');
let d0 = timelocal({ year: +m[1], mon: +m[2], mday: +m[3], hour: 0, min: 0, sec: 0 }), d1 = d0 + DAY;
let p = length(dk) ? absof(D, dk, cdir(c)) : null, mnt = diskof(D, dk)?.mnt ?? '';
if (!p) return err('nomain', 'Manca il Disco Principale', 'Main Drive missing');
let lim = type(a.limit) == 'int' && a.limit > 0 && a.limit <= 5000 ? a.limit : 2000, F = [], more = false, OK = {};
for (let k = -1; k <= 1; k++) { let t = localtime(d0 + 43200 + k * DAY); OK[sprintf('%04d%02d%02d', t.year, t.mon, t.mday)] = 1; }
let W = { d0: d0, d1: d1, ok: OK, n: 0, F: [] };
dlist(W, p, 0);
for (let y in sort(W.F, (x, z) => x[0] - z[0])) {
let f = replace(y[2], /^.*\//, '');
if (length(F) >= lim) { more = true; continue; }
let du = durof(f), cd = codecof(f), x = { t: y[0], path: substr(y[2], length(mnt)), size: y[1] };
if (du) x.dur = du;
if (cd) x.codec = cd;
push(F, x);
}
let fixed = (rjs(ST)?.cams?.[c.id]?.fixed) === true, Ln = dayline(F, d0, fixed);
return { id: c.id, day: a.day, disk: dk, line: Ln.line, motion: Ln.motion, files: sort(F, (x, y) => x.t - y.t), more: more || W.n > 200000 };
}
},
recjob: recjob
};

return M;
