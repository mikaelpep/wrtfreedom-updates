#!/bin/sh
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
W=/usr/share/wrtfreedom; ST=/etc/wrtfreedom/slow; ON=/tmp/wf-slow.on; LK=/tmp/wf-slow.lock; IFB=wfslow0
for lb_f in "$W/lib.sh" "${0%/*}/lib.sh"; do [ -f "$lb_f" ] && { . "$lb_f"; break; }; done
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { sh $W/event.sh cron "$1" net "$2" >/dev/null 2>&1; }
num() { case "$1" in ''|*[!0-9]*) echo 0;; *) echo "$1";; esac; }
mb() { awk -v k="$1" 'BEGIN { v = k / 1000; s = sprintf(v < 10 ? "%.1f" : "%.0f", v); sub(/\.0$/, "", s); print s }'; }
lim() { o=; [ "$1" -gt 0 ] && o="↓ $(mb "$1")"; [ "$2" -gt 0 ] && o="${o:+$o / }↑ $(mb "$2")"; [ $EN = 0 ] && o=$(echo "$o" | tr . ,); echo "$o Mbit/s"; }
i=0
until mkdir $LK 2>/dev/null; do
read op < $LK/pid 2>/dev/null
if [ -n "$op" ] && ! kill -0 "$op" 2>/dev/null; then rm -rf $LK; continue; fi
i=$((i + 1)); [ $i -ge 60 ] && exit 0; sleep 2
done
echo $$ > $LK/pid
trap 'rm -rf $LK' EXIT
trap 'exit 1' INT TERM
MODE=; SEC=; OWN=0; PDL=; PUL=; AR=0; SEN=1; DEV=; SDL=; SUL=
if [ -f $ST ]; then while IFS='=' read -r k v; do v=${v#\"}; v=${v%\"}
case "$k" in
MODE) case "$v" in sqm|tc) MODE=$v;; esac ;;
SEC|DEV) case "$v" in *[!A-Za-z0-9_.@-]*|'') ;; *) eval "$k=\$v";; esac ;;
OWN|AR|SEN|PDL|PUL|SDL|SUL) case "$v" in *[!0-9]*) ;; *) eval "$k=\$v";; esac ;;
esac
done < $ST; fi
save() { mkdir -p /etc/wrtfreedom; for k in MODE SEC OWN PDL PUL AR SEN DEV SDL SUL; do eval "echo $k=\\\"\$$k\\\""; done > $ST.t && mv $ST.t $ST; }
low() { a=$(num "$1"); b=$(num "$2"); if [ "$a" = 0 ]; then echo "$b"; elif [ "$b" = 0 ] || [ "$a" -lt "$b" ]; then echo "$a"; else echo "$b"; fi; }
ar_running() { [ -x /etc/init.d/cake-autorate ] && { /etc/init.d/cake-autorate running >/dev/null 2>&1 || pgrep -f cake-autorate >/dev/null 2>&1; }; }
tcoff() { tc qdisc del dev "$1" root 2>/dev/null; tc qdisc del dev "$1" ingress 2>/dev/null; ip link del $IFB 2>/dev/null; }
tcon() {
[ -d "/sys/class/net/$1" ] || return 1
tc qdisc del dev "$1" root 2>/dev/null; tc qdisc del dev "$1" ingress 2>/dev/null
if [ "$2" -gt 0 ]; then tc qdisc replace dev "$1" root cake bandwidth "${2}kbit" besteffort || return 1; fi
if [ "$3" -gt 0 ]; then
ip link show $IFB >/dev/null 2>&1 || ip link add $IFB type ifb || return 1
ip link set $IFB up && tc qdisc add dev "$1" handle ffff: ingress &&
tc filter add dev "$1" parent ffff: matchall action mirred egress redirect dev $IFB &&
tc qdisc replace dev $IFB root cake bandwidth "${3}kbit" besteffort ingress || return 1
fi
return 0
}
slname() {
sn_=; [ -n "$HN_NET" ] && [ "$T" = "$H" ] && sn_=$HN_NET
[ -n "$sn_" ] || sn_=$(ubus call network.interface dump 2>/dev/null | jsonfilter -e "@.interface[@.l3_device='$T'].interface" 2>/dev/null | head -n 1)
[ -n "$sn_" ] && command -v wf_ifname >/dev/null 2>&1 && wf_ifname "$sn_"
}
sqmrestart() { /etc/init.d/sqm enable >/dev/null 2>&1; /etc/init.d/sqm restart >/dev/null 2>&1; }

case "$1" in
on)
DL=$(num "$2"); UL=$(num "$3"); LD=$4; MOB=$5
[ "$DL" -gt 0 ] || [ "$UL" -gt 0 ] || exit 0
first=0; [ -z "$MODE" ] && first=1
homenet >/dev/null; H=$HN_DEV	# vuoto = rete di casa non trovata: con la linea mobile il limite non si mette (evento d'errore)
T=$LD; [ "$MOB" = 1 ] && T=$H
[ -n "$MODE" ] && T=${DEV:-$T}	# limite già messo: stessa interfaccia di prima
if [ -z "$T" ]; then
[ "$(cat $ON 2>/dev/null)" = err ] || ev usage_slowerr "⚠️ $(t "Consumo Della SIM ¦ Giga finiti: limite non messo ¦ Rete di casa non trovata" "SIM Usage ¦ Data used up: no speed limit ¦ Home network not found")"
echo err > $ON; exit 0
fi
if [ -n "$H" ] && [ "$T" = "$H" ]; then EG=$DL; IN=$UL; else EG=$UL; IN=$DL; fi
ok=0
if [ -n "$MODE" ] && [ "$(cat $ON 2>/dev/null)" = ok ]; then
if [ "$MODE" = tc ] && [ "$SDL" = "$IN" ] && [ "$SUL" = "$EG" ] && tc qdisc show dev "$T" 2>/dev/null | grep -q '^qdisc cake'; then exit 0; fi
if [ "$MODE" = sqm ] && [ "$SDL" = "$(low "$PDL" "$IN")" ] && [ "$SUL" = "$(low "$PUL" "$EG")" ]; then exit 0; fi
fi
if [ -x /etc/init.d/sqm ] && [ "$MODE" != tc ]; then
if [ -z "$MODE" ]; then
SEC=; for s in $(uci -q show sqm | sed -n "s/^sqm\.\([^.]*\)=queue$/\1/p"); do
[ "$s" != wfslow ] && [ "$(uci -q get sqm.$s.enabled)" = 1 ] && [ "$(uci -q get sqm.$s.interface)" = "$T" ] && { SEC=$s; break; }
done
if [ -n "$SEC" ]; then OWN=0; PDL=$(uci -q get sqm.$SEC.download); PUL=$(uci -q get sqm.$SEC.upload)
else SEC=wfslow; OWN=1; PDL=; PUL=; fi
AR=0; ar_running && AR=1
SEN=0; /etc/init.d/sqm enabled && SEN=1
MODE=sqm; DEV=$T
fi
SDL=$(low "$PDL" "$IN"); SUL=$(low "$PUL" "$EG")
if [ "$OWN" = 1 ]; then
uci set sqm.wfslow=queue; uci set sqm.wfslow.enabled=1; uci set sqm.wfslow.interface="$T"
uci set sqm.wfslow.qdisc=cake; uci set sqm.wfslow.script=piece_of_cake.qos; uci set sqm.wfslow.linklayer=none
fi
uci set sqm.$SEC.download="$SDL"; uci set sqm.$SEC.upload="$SUL"; uci commit sqm
save
[ "$AR" = 1 ] && /etc/init.d/cake-autorate stop >/dev/null 2>&1
sqmrestart && ok=1
else
if [ -z "$MODE" ] && tc qdisc show dev "$T" 2>/dev/null | grep -qE '^qdisc (cake|htb|hfsc|tbf|ingress)'; then
echo "ERROR: $T ha già delle code: limite non messo" >&2
else
MODE=tc; DEV=$T; SDL=$IN; SUL=$EG; save
tcon "$T" "$EG" "$IN" && ok=1
fi
fi
if [ $ok = 1 ]; then echo ok > $ON
[ $first = 1 ] && ev usage_slow "📊 $(t "Consumo Della SIM ¦ Giga finiti: velocità ridotta" "SIM Usage ¦ Data used up: speed limited") ¦ $(lim "$DL" "$UL")"
else echo err > $ON
[ $first = 1 ] && { n_=$(slname); ev usage_slowerr "⚠️ $(t "Consumo Della SIM ¦ Giga finiti: limite non messo" "SIM Usage ¦ Data used up: no speed limit")${n_:+ ¦ $n_}"; }
fi ;;
off)
[ -n "$MODE" ] || { rm -f $ON; exit 0; }
if [ "$MODE" = sqm ]; then
if [ "$OWN" = 1 ]; then uci -q delete sqm.wfslow
else
if [ "$(uci -q get sqm.$SEC.download)" = "$SDL" ]; then
if [ -n "$PDL" ]; then uci set sqm.$SEC.download="$PDL"; else uci -q delete sqm.$SEC.download; fi
fi
if [ "$(uci -q get sqm.$SEC.upload)" = "$SUL" ]; then
if [ -n "$PUL" ]; then uci set sqm.$SEC.upload="$PUL"; else uci -q delete sqm.$SEC.upload; fi
fi
fi
uci commit sqm
if [ "$SEN" = 0 ]; then /etc/init.d/sqm stop >/dev/null 2>&1; /etc/init.d/sqm disable >/dev/null 2>&1; else /etc/init.d/sqm restart >/dev/null 2>&1; fi
[ "$AR" = 1 ] && /etc/init.d/cake-autorate start >/dev/null 2>&1
else tcoff "$DEV"; fi
rm -f $ST $ON
case "$2" in
renew) w=$(t "Nuovo periodo dell'offerta" "New plan period") ;;
app) w=$(t "Tolto dall'app" "Removed from the app") ;;
*) w=$(t "Impostazioni cambiate" "Settings changed") ;;
esac
ev usage_fast "📊 $(t "Consumo Della SIM ¦ Limite di velocità tolto" "SIM Usage ¦ Speed limit removed") ¦ $w" ;;
*) echo "uso: slow.sh on <download> <upload> <dispositivo> <mobile> | off [motivo]"; exit 1 ;;
esac
exit 0
