'use strict';
import { stat, readfile, writefile, rename, lsdir, popen } from 'fs';

const FST = '/tmp/wf-fastwd.json', FFP = '/tmp/wf-fastwd.fp', FMAXS = 120;
const FFILES = [ '/etc/config/wrtfreedom', '/etc/config/wireless', '/etc/config/firewall', '/etc/crontabs/root', '/etc/rc.d',
'/usr/share/wrtfreedom/custode/funzioni.json', '/etc/nftables.d', '/usr/share/nftables.d', '/sbin/fw4', '/etc/init.d/firewall',
'/etc/init.d/cron', '/tmp/wf-custode.fwok', '/tmp/wf-fw.lock', '/tmp/wf-custode.cron', '/tmp/wf-wifi.restart.lock',
'/tmp/wf-wifi.chan.lock', '/tmp/wf-wifi.wps.lock', '/tmp/wf-wifi.cac' ];

function fjs(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
let FMT = 0;
function fsig(f) { let s = stat(f); if (s && s.mtime > FMT) FMT = s.mtime; return s ? s.mtime + ':' + s.size + ':' + s.inode : '-'; }
function fpopen(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
let FU = null;
function fub(o, m, a) {
if (FU == null) { try { FU = require('ubus').connect() ?? false; } catch (e) { FU = false; } }
let r = null;
if (FU) { try { r = FU.call(o, m, a); } catch (e) { r = null; } }
if (r == null) { try { r = json(fpopen('ubus call ' + o + ' ' + m + " '" + sprintf('%J', a) + "' 2>/dev/null") || 'null'); } catch (e) { r = null; } }
return r;
}
function fclean(S) {
if (type(S) != 'object' || type(S.f) != 'object' || length(keys(S.f)) < 4) return false;
for (let k, n in S.f) {
if (type(n) != 'object' || n.pend != null || +(n.run ?? 0) > 0 || +(n.ko ?? 0) != 0) return false;
if (index([ 'ok', 'off', 'none', null ], n.s) < 0) return false;
}
return true;
}
const FNAS = [ 'ksmbd', 'smbd', 'nmbd', 'samba4', 'nfsd', 'minidlna', 'aria2', 'wf-nasdl', 'wf-nasdav', 'wf-nasftp', 'hd-idle' ];
function nasprint() {
let mt = filter(split(readfile('/proc/mounts') ?? '', '\n'), (l) => substr(l, 0, 5) == '/dev/');
let sv = [], rc = lsdir('/etc/rc.d') ?? [];
for (let n in FNAS) {
if (!length(filter(rc, (f) => match(f, regexp('^S[0-9]{1,3}' + n + '$'))))) continue;
let r = fub('service', 'list', { name: n });
if (r == null) return null;
push(sv, [ n, length(filter(values(r?.[n]?.instances ?? {}), (i) => i?.running === true)) > 0 ]);
}
return [ mt, sort(lsdir('/sys/class/block') ?? []), sort(lsdir('/tmp/wf-nas/ejected') ?? []), sort(lsdir('/tmp/wf-nas/jobs') ?? []), fsig('/tmp/wf-nas/smart'), sv, fsig('/tmp/wf-nas/dlna.scan'), fsig('/tmp/wf-nas/blk.json') ];
}
function memprint() {
let M = fjs('/tmp/wf-mem.json');
if (type(M) != 'object') return null;
let ko = [];
for (let k in sort(keys(type(M.serv) == 'object' ? M.serv : {}))) if (M.serv[k]?.ok === false) push(ko, k);
return [ M.st ?? null, M.seq ?? null, +(M.sotto ?? 0) > 0, ko ];
}
function fprint() {
let now = time(), up = int(+(split(trim(readfile('/proc/uptime') ?? '0'), ' ')[0]));
let w = fub('network.wireless', 'status', {}), b = fub('service', 'list', { name: 'wrtfreedom' }), c = fub('service', 'list', { name: 'cron' });
if (w == null || b == null || c == null) return null;
let tb = b?.wrtfreedom?.instances?.tgbot, cr = map(values(c?.cron?.instances ?? {}), (i) => i?.running === true);
let hb = +trim(readfile('/tmp/wf-batt/tgbot') ?? ''), k = +trim(readfile('/tmp/wf-tg.ok') ?? '');
let bot = [ hb > 0 && now - hb <= 180, k > 0 ? now - k <= 900 : up <= 1200 ], na = nasprint();
if (na == null) return null;
return sprintf('%J', [ map(FFILES, fsig), sort(lsdir('/sys/class/net') ?? []), w, [ tb?.running, tb?.pid ], cr, bot, na, memprint() ]);
}

let A0 = ARGV[0] ?? '';
if (A0 == 'pre') {
let S = fjs(FST), P = fjs(FFP), now = time(), skip = false, fp = null;
if (fclean(S) && type(P) == 'object' && P.t == S.t && now - +S.t < FMAXS && now >= +S.t) {
fp = fprint();
skip = fp != null && fp == P.fp && FMT < +S.t;
}
else if (fclean(S)) fp = fprint();
RES({ skip: skip, fp: fp });
}
else if (A0 == 'post') {
let S = fjs(FST), fp = ARGV[1];
if (fclean(S) && type(fp) == 'string') { writefile(FFP + '.t', sprintf('%J', { t: S.t, fp: fp })); rename(FFP + '.t', FFP); }
RES({ skip: false, fp: null });
}
