'use strict';
import { readfile, writefile, popen, rename, mkdir, stat, unlink, lsdir } from 'fs';

const W = '/usr/share/wrtfreedom', TMP = '/tmp/wf-wguse.json', ETC = '/etc/wrtfreedom/wguse.json', ST = '/tmp/wf-wgx.json';
const PRB = '/tmp/wf-wgprobe.json', PRBC = '/tmp/wf-wgprobe.chk.json', KEEP = 60, ON = 180, SAVET = 21600, SAVEB = 536870912;
const ONKA = 90, AGAIN = '/tmp/wf-wgx.again';

function sh(c) { let p = popen(c, 'r'); if (!p) return ''; let o = p.read('all'); p.close(); return o ?? ''; }
function q(s) { return "'" + replace('' + s, "'", "'\\''") + "'"; }
function rj(f) { let o = readfile(f); if (o == null) return null; try { return json(o); } catch (e) { return null; } }
function wj(f, o) { writefile(f + '.t', sprintf('%J', o)); rename(f + '.t', f); }
function day(t) { let n = localtime(t); return sprintf('%04d-%02d-%02d', n.year, n.mon, n.mday); }
function arr(v) { return type(v) == 'array' ? v : (v != null && v != '' ? [v] : []); }
const UCFG = global.WFUCFG ?? (global.WFUCFG = loadfile(getenv('WF_UCFGUC') ?? '/usr/share/wrtfreedom/ucfg.uc')());
function ucfile(name) { return UCFG.read((getenv('WF_CFGDIR') ?? '/etc/config/') + name, true); }
const WC = ucfile('wrtfreedom');
const EN = (WC.ui?.lang ?? '') == 'en';
function t(it, en) { return EN ? en : it; }
function fx(e, s, R) { return e + ' ' + join(' ¦ ', [ s, ...filter(R, (r) => length(r)) ]); }
function ev(tp, txt) { sh('sh ' + W + '/event.sh cron ' + q(tp) + ' net ' + q(txt) + ' >/dev/null 2>&1 </dev/null &'); }
function wgiface(N) {
let L = filter(keys(N), (k) => N[k]['.type'] == 'interface' && N[k].proto == 'wireguard' && !match(k, /^wgo(ut|[0-9]+)$/));
for (let i in L) if (length(N[i].listen_port ?? '')) return i;
return null;
}
function peers(N, ifc) {
let P = {};
for (let k in N) if (N[k]['.type'] == 'wireguard_' + ifc && length(N[k].public_key ?? ''))
P[N[k].public_key] = { id: k, name: N[k].description ?? k, al: (WC['peer_' + k] ?? {}).alert == '1', ka: length((WC['peer_' + k] ?? {}).priv ?? '') > 0 };
return P;
}
function dump(ifc) {
let r = [], o = sh('wg show ' + q(ifc) + ' dump 2>/dev/null; echo "@rc=$?"'), m = match(o, /@rc=([0-9]+)[ \t\n]*$/);
let L = split(trim(replace(o, /@rc=[0-9]+[ \t\n]*$/, '')), '\n');
for (let i = 1; i < length(L); i++) {
let f = split(L[i], '\t');
if (length(f) >= 7) push(r, { pub: f[0], ep: f[2], hs: +f[4], rx: +f[5], tx: +f[6] });
}
return { r: r, ok: m != null && (m[1] == '0' || m[1] == '127') };
}
const WDF = '/tmp/wf-vpnwd.json', WDLK = '/tmp/wf-vpnwd.lock', WDD = [ 30, 120, 600, 3600 ], WDUP = 60, WDP = 15;
const CRONSH = getenv('WF_CRONSH') ?? W + '/cron.sh';
function wdsh(a) { sh('( sh ' + CRONSH + ' vpnwd ' + a + ' ) >/dev/null 2>&1 </dev/null &'); }
function ifst(ifc) {
let r = null;
try { let c = require('ubus').connect(); if (c) r = c.call('network.interface.' + ifc, 'status'); } catch (e) {}
if (r == null) { try { r = json(sh('ifstatus ' + q(ifc) + ' 2>/dev/null') || 'null'); } catch (e) {} }
return type(r) == 'object' ? r : null;
}
const WDD5 = '/tmp/wf-vpnwd.d5';
function wdd5(N, ifc) {
if (length(WC.wgwd?.on ?? '') || !length(N[ifc]?.listen_port ?? '') || stat(WDD5)) return;
writefile(WDD5, '');
sh('( ubus -t 10 call wrtfreedom vpnwd ' + q('{"action":"align"}') + ' >/dev/null 2>&1 || rm -f ' + WDD5 + ' ) >/dev/null 2>&1 </dev/null &');
}
const WDFLG = (length(getenv('WF_CRONTEST') ?? '') && !stat('/etc/openwrt_release') ? getenv('WF_CRONTEST') : '') + '/tmp/wf-cron.vpn.f';
const HOWP = length(getenv('WF_CRONTEST') ?? '') && !stat('/etc/openwrt_release') ? getenv('WF_CRONTEST') : '';
function howf(k) { return '/tmp/wf-how.' + k + '.json'; }
let SM = null;
function same() { if (!SM) SM = loadfile(getenv('WF_SAMEUC') ?? W + '/same.uc')(); return SM; }
function howin(k) {
let C = getenv('WF_CFGDIR') ?? '/etc/config/', R = [ C + 'wrtfreedom', '/tmp/.uci/wrtfreedom', getenv('WF_CRONF') ?? '/etc/crontabs/root' ];
if (k == 'vpn') return [ ...R, C + 'network' ];
let S = same(), H = S.hpd + '/' + S.hp.ddns;
return [ ...R, C + 'ddns', '/tmp/.uci/ddns', H, S.hpd + '/.disabled/' + S.hp.ddns, getenv('WF_DDNSINIT') ?? '/etc/init.d/ddns' ];
}
function howtxt(f) { return same().file(f) ? readfile(f) ?? '' : null; }
function howsh(k, f) { let t = howtxt(f); return t != null && same().T[k](t); }
function howusr(k) {
let S = same();
for (let l in split(readfile(getenv('WF_CRONF') ?? '/etc/crontabs/root') ?? '', '
')) {
l = trim(l);
if (!length(l) || substr(l, 0, 1) == '#' || match(l, / # wf:[a-z0-9_]{1,40}$/)) continue;
if (match(l, S.re[k])) return true;
for (let f in S.paths(l)) if (howsh(k, f)) return true;
}
if (!S.hp[k]) return false;
let D = S.hpd + '/' + S.hp[k];
for (let n in lsdir(D) ?? []) {
if (!S.hpn(n)) continue;
let t = howtxt(D + '/' + n);
if (t == null) continue;
if (S.T[k](t)) return true;
for (let f in slice(filter(S.paths(t), (p) => !match(p, S.SYS)), 0, 12)) if (howsh(k, f)) return true;
}
return false;
}
function howget(m, N) {
let k = m == 'vpnwd' ? 'vpn' : 'ddns', i = '', t0 = 0, C = rj(HOWP + howf(k));
for (let f in howin(k)) {
let s = stat(f);
if (!s) { i += '-;'; continue; }
i += sprintf('%d.%d.%d;', s.inode, s.size, s.mtime);
if (s.mtime > t0) t0 = s.mtime;
}
if (type(C) == 'object' && C.i == i && +(C.t ?? 0) > t0) return C;
let G = null;
try { G = json(sh('ubus -t 10 call wrtfreedom ' + m + ' ' + q('{"action":"get"}') + ' 2>/dev/null') || 'null'); } catch (e) {}
if (type(G) == 'object' && exists(G, 'how')) {
C = { how: G.how, ifc: G.ifc, t: time(), i: i };
let tf = HOWP + howf(k) + '.' + (split(readfile('/proc/self/stat') ?? '0', ' ')[0] ?? '0');
writefile(tf, sprintf('%J', C)); rename(tf, HOWP + howf(k));
return C;
}
let on = (WC[k == 'vpn' ? 'wgwd' : 'ddnswd']?.on ?? '') == '1', usr = on && howusr(k);
sh('logger -t wrtfreedom ' + q('Controllo ' + k + ': rpcd non risponde, ' + (usr ? 'lo fa lo script dell\'utente (niente intervento)' :
'decide l\'impostazione (' + (on ? 'acceso' : 'spento') + ')')) + ' 2>/dev/null');
return { how: on && !usr ? (k == 'vpn' ? 'loop' : 'svc') : null, ifc: k == 'vpn' ? wgiface(N ?? ucfile('network')) : null };
}
const WDW = 300;
function wdcheck(N, ifc, wok) {
let S = rj(WDF), now = time();
wdd5(N, ifc);
if ((WC.wgwd?.on ?? '') != '1') {
if (S) { if (S.r || stat(WDFLG)) wdsh('clr'); unlink(WDF); }
return;
}
S = S ?? {};
let st = ifst(ifc);
if (!st) return;
if (N[ifc]?.disabled == '1' || st.autostart === false) { if (S.f || S.a || S.p || S.w) wj(WDF, S.r ? { r: 1 } : {}); return; }
if (st.up === true && wok) {
if (S.p) wdsh('fix');
else if (S.r || stat(WDFLG)) wdsh('ok');
if (length(keys(S))) unlink(WDF);
return;
}
let col = st.pending === true || (st.up === true && +(st.uptime ?? 0) < WDUP);
if (col && S.p) { if (now - S.p < WDP) { writefile(AGAIN, ''); return; } }
else if (col) {
if (!S.w || S.w > now) { S.w = now; wj(WDF, S); return; }
if (now - S.w < WDW) return;
}
else if (S.w) delete S.w;
if (S.p) { wdsh('fail'); S.p = 0; S.r = 1; }
S.f = (S.f ?? 0) + 1;
let lk = stat(WDLK);
if (S.f >= 2 && now >= +(S.nx ?? 0) && !(lk && now - lk.mtime < 120)) {
let G = howget('vpnwd', N);
if (G?.how == 'loop' && G.ifc == ifc) {
sh('( sh ' + CRONSH + ' vpnwd up ' + q(ifc) + ' ) >/dev/null 2>&1 </dev/null &');
S.a = (S.a ?? 0) + 1; S.p = now; S.nx = now + WDD[S.a < length(WDD) ? S.a - 1 : length(WDD) - 1] - 5;
}
else S.nx = now + 300;
}
wj(WDF, S);
if (S.f == 1 || S.p) writefile(AGAIN, '');
}
function save(U) {
U = U ?? rj(TMP);
if (!U) return;
U.st = time(); U.ch = 0; U.cb = 0;
mkdir('/etc/wrtfreedom');
wj(ETC, U); wj(TMP, U);
}
function tick() {
unlink(AGAIN);
let N = ucfile('network'), ifc = wgiface(N);
if (!ifc) return;
let now = time(), d = day(now), P = peers(N, ifc), S = rj(ST) ?? {}, U = rj(TMP) ?? rj(ETC) ?? {}, seen = {}, D = dump(ifc);
S.p = S.p ?? {}; U.d = U.d ?? {};
for (let x in D.r) {
let p = P[x.pub];
if (!p) continue;	/* dispositivo senza sezione in network: niente nome, non si conta */
seen[p.id] = true;
let o = S.p[p.id] ?? {}, lr = o.rx != null && x.rx > o.rx ? now : +(o.lr ?? 0), lc = x.hs > lr ? x.hs : lr;
let on = x.hs > 0 && now - lc < (p.ka ? ONKA : ON);
if (o.rx != null) {
let dr = x.rx >= o.rx ? x.rx - o.rx : x.rx, dt = x.tx >= o.tx ? x.tx - o.tx : x.tx;
if (dr || dt) { let g = U.d[d] = U.d[d] ?? {}, v = g[p.id] ?? [0, 0]; g[p.id] = [v[0] + dr, v[1] + dt]; U.ch = 1; U.cb = (U.cb ?? 0) + dr + dt; }
}
if (o.on != null && on != o.on && p.al) {
let ip = match(x.ep, /^[0-9.]+:[0-9]+$/) ? 'IP ' + replace(x.ep, /:[0-9]+$/, '') : null;
if (on) ev('wgpeer_on', fx('🔐', p.name, [ t('Entrato nella VPN', 'Joined the VPN'), ip ]));
else ev('wgpeer_off', fx('🔐', p.name, [ t('Uscito dalla VPN', 'Left the VPN') ]));
}
S.p[p.id] = { rx: x.rx, tx: x.tx, hs: x.hs, on: on, lr: lr };
}
for (let k in keys(S.p)) if (!seen[k]) delete S.p[k];
let ks = sort(keys(U.d));
while (length(ks) > KEEP) delete U.d[shift(ks)];
wj(ST, S);
if (U.ch && (now - (U.st ?? 0) >= SAVET || (U.cb ?? 0) >= SAVEB)) save(U);
else wj(TMP, U);
let R = rj(PRB);
if (R && R.id && !R.ok && now < (R.until ?? 0)) {
let x = S.p[R.id];
if (x && x.hs >= (R.t ?? 0)) sh('ubus -t 5 call wrtfreedom wgprobe ' + q('{"action":"get"}') + ' >/dev/null 2>&1');
}
let fl = readfile((getenv('WF_SYSNET') ?? '/sys/class/net') + '/' + ifc + '/flags'), fv = fl == null ? null : hex(trim(fl));
wdcheck(N, ifc, D.ok && (fl == null || fv != fv || (fv & 1) == 1));
}
function probe() {
let R = rj(PRB);
if (!R) return;
let C = { run: false, t: time() };
let pub = trim(sh('(curl -s -m 8 https://api.ipify.org || uclient-fetch -q -T 8 -O - https://api.ipify.org) 2>/dev/null'));
C.pub = match(pub, /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/) ? pub : '';
let host = '' + (R.host ?? '');
if (length(host) && match(host, /[A-Za-z]/) && match(host, /^[A-Za-z0-9.-]{1,253}$/)) {
let ips = [], after = false;
for (let l in split(sh('nslookup ' + q(host) + ' 1.1.1.1 2>/dev/null'), '\n')) {
if (match(l, /^Name:/)) after = true;
else if (after) { let m = match(l, /^Address( [0-9]+)?:[ \t]*([0-9]{1,3}(\.[0-9]{1,3}){3})[ \t]*$/); if (m) push(ips, m[2]); }
}
C.ddns = { host: host, ips: ips, ok: length(C.pub) && length(ips) ? index(ips, C.pub) >= 0 : null };
}
wj(PRBC, C);
}
function expire() {
let N = ucfile('network'), ifc = wgiface(N), now = time();
if (!ifc) return;
for (let k in N) {
if (N[k]['.type'] != 'wireguard_' + ifc) continue;
let e = +((WC['peer_' + k] ?? {}).exp ?? 0);
if (e <= 0 || e > now) continue;
sh('ubus call wrtfreedom wgpeer ' + q(sprintf('%J', { action: 'del', id: k })) + ' >/dev/null 2>&1');
ev('wgpeer_exp', fx('🔐', N[k].description ?? k, [ t('Accesso VPN scaduto', 'VPN access expired'), t('Dispositivo tolto', 'Device removed') ]));
}
}

let cmd = ARGV[0] ?? '';
if (cmd == 'tick') tick();
else if (cmd == 'probe') probe();
else if (cmd == 'exp') expire();
else if (cmd == 'save') save(null);
else if (cmd == 'how' && (ARGV[1] == 'vpn' || ARGV[1] == 'ddns')) print((howget(ARGV[1] + 'wd', null)?.how ?? '') + '\n');
else { print('uso: wgx.uc tick|probe|exp|save|how vpn|ddns\n'); exit(1); }
