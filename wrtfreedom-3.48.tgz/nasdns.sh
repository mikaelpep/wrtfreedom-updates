#!/bin/sh
W=${WF_NASDNS_W:-/usr/share/wrtfreedom}
ST=${WF_NASDNS_ST:-/etc/wrtfreedom/nasdns.json}
INITD=${WF_INITD:-/etc/init.d}
N=nas.home.arpa
NR='nas\.home\.arpa'	# lo stesso nome per grep (punti veri)
LK=/tmp/wf-nasdns.lock
ALK=/tmp/wf-adgmode.lock

lock() { i=0; while ! mkdir $LK 2>/dev/null; do
a=$(( $(date +%s) - $(date -r $LK +%s 2>/dev/null || date +%s) ))
[ $a -gt 120 ] && { rmdir $LK 2>/dev/null; continue; }
[ $i -ge 20 ] && exit 1; sleep 1; i=$((i+1)); done
trap 'rmdir $LK 2>/dev/null' EXIT; trap 'exit 1' HUP INT TERM; }
jget() { sed -n "s/.*\"$1\":\"\([^\"]*\)\".*/\1/p" "$ST" 2>/dev/null; }
jon() { grep -q '"on":true' "$ST" 2>/dev/null; }
save() {	# save <ip> <dm> <adg> <user 0|1> <ok 0|1>
u_=false; [ "$4" = 1 ] && u_=true
o_=false; [ "$5" = 1 ] && o_=true
mkdir -p "${ST%/*}" && printf '{"on":true,"ip":"%s","dm":"%s","adg":"%s","user":%s,"ok":%s}\n' "$1" "$2" "$3" "$u_" "$o_" > "$ST.t" && mv -f "$ST.t" "$ST"
}
hip() { if [ -n "$WF_NASDNS_IP" ]; then echo "$WF_NASDNS_IP"; else sh $W/lib.sh homenet 2>/dev/null | awk '{ print $3 }'; fi; }
okip() { echo "$1" | grep -qE '^[0-9]{1,3}(\.[0-9]{1,3}){3}$'; }

dsec() { uci -q show dhcp | sed -n "s/^dhcp\.\([^.=]*\)=dnsmasq$/\1/p" | sed -n 1p; }
daddr() { uci -q show "dhcp.$1.address" 2>/dev/null | sed "s/^[^=]*=//" | tr ' ' '\n' | tr -d "'" | sed '/^$/d'; }
duser() { daddr "$1" | grep -i "^/$NR/" | grep -vxF "/$N/$2" | grep . >/dev/null && return 0
uci -q show dhcp | grep -iE "^dhcp\.[^.=]+\.name='$NR'$" >/dev/null; }
dreload() { uci commit dhcp; [ -x $INITD/dnsmasq ] && $INITD/dnsmasq reload >/dev/null 2>&1; return 0; }

ainit() { for s in adguardhome AdGuardHome; do [ -x $INITD/$s ] && { echo $s; return; }; done; }
yfile() { if [ -n "$WF_NASDNS_YAML" ]; then echo "$WF_NASDNS_YAML"; else sh $W/lib.sh adgyaml 2>/dev/null; fi; }
yport() { awk '/^[^ #]/ { d = ($0 ~ /^dns:/) } d && /^  port:/ { sub(/^  port:[ \t]*/, ""); gsub(/[\042\047]/, ""); print; exit }' "$1" 2>/dev/null; }
adgdns() { [ -n "$Y" ] && [ -f "$Y" ] || return 1
[ "$(yport "$Y")" = 53 ] || return 1
p_=$(uci -q get "dhcp.$D.port"); [ "${p_:-53}" != 53 ]; }
yans() { awk -v n="$N" '
	/^[^ #]/ { top = ($0 ~ /^(filtering|dns):/); inb = 0; next }
	top && /^  rewrites:/ { inb = 1; next }
	inb && /^ ? ?[^ -]/ { inb = 0 }
	inb && /^ *- *domain:/ { v = $0; sub(/^ *- *domain:[ \t]*/, "", v); gsub(/[\042\047 \t]/, "", v); d = (tolower(v) == n); next }
	inb && d && /^ *answer:/ { v = $0; sub(/^ *answer:[ \t]*/, "", v); gsub(/[\042\047 \t]/, "", v); print v }' "$1" 2>/dev/null; }
yed() { awk -v op="$2" -v ip="$3" -v n="$N" '
	function strip(v) { gsub(/[\042\047 \t]/, "", v); return v }
	function endit() { if (ni) { if (!(op == "del" && idom == n && ians == ip)) { for (j = 1; j <= ni; j++) out[++no] = it[j] } ni = 0 } }
	function endblk() { endit()
		if (op == "add" && !have) { ind = iind != "" ? iind : "    "; out[++no] = ind "- domain: " n; out[++no] = ind "  answer: " ip; out[++no] = ind "  enabled: true" }
		if (no) { print "  rewrites:"; for (j = 1; j <= no; j++) print out[j] } else print "  rewrites: []"
		for (j = 1; j <= nt; j++) print tail[j]
		inb = 0; no = 0; nt = 0; done = 1 }
	# blocco filtering: senza la chiave rewrites (file scritto a mano): aggiunta in fondo al blocco
	function newblk() { if (!done && op == "add") { print "  rewrites:"; print "    - domain: " n; print "      answer: " ip; print "      enabled: true" } done = 1 }
	{ line = $0 }
	inb {
		if (line ~ /^[ \t]*$/ || line ~ /^[ \t]*#/) { if (ni) it[++ni] = line; else tail[++nt] = line; next }
		if (line ~ /^ *- / && match(line, /^ */) && (RLENGTH > 2 || (RLENGTH == 2 && iind == "  "))) {
			endit(); match(line, /^ */); iind = substr(line, 1, RLENGTH); ni = 1; it[1] = line; ians = ""
			v = line; sub(/^ *- */, "", v); idom = ""; if (v ~ /^domain:/) { sub(/^domain:/, "", v); idom = tolower(strip(v)) }
			next }
		if (ni && match(line, /^ */) && RLENGTH > length(iind)) {
			it[++ni] = line; v = line; sub(/^ */, "", v)
			if (v ~ /^answer:/) { sub(/^answer:/, "", v); ians = strip(v); if (idom == n && ians == ip) have = 1 }
			else if (v ~ /^domain:/) { sub(/^domain:/, "", v); idom = tolower(strip(v)) }
			next }
		endblk() }
	/^[^ \t#]/ { if (cur == "filtering") newblk(); cur = $0; sub(/:.*/, "", cur) }
	(cur == "filtering" || cur == "dns") && !done && line ~ /^  rewrites:/ {
		v = line; sub(/^  rewrites:[ \t]*/, "", v); sub(/[ \t]+#.*$/, "", v)
		if (v == "[]") { inb = 1; have = 0; next }
		if (v != "") { bad = 1; print; next }
		inb = 1; have = 0; next }
	{ print }
	END { if (inb) endblk(); else if (cur == "filtering") newblk(); if (bad) exit 3 }' "$1"; }
adgok() { i_=0; v_=0
while [ $i_ -lt "${WF_NASDNS_WAIT:-15}" ]; do sleep 1; i_=$((i_+1))
pidof AdGuardHome adguardhome >/dev/null 2>&1 || { v_=0; continue; }
if command -v netstat >/dev/null 2>&1; then netstat -lnu 2>/dev/null | grep -qE '[:.]53[[:space:]]' && return 0
else v_=$((v_+1)); [ $v_ -ge 3 ] && return 0; fi
done; return 1; }
EN=0; [ "$(uci -q get wrtfreedom.ui.lang)" = en ] && EN=1
t() { if [ $EN = 1 ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }
ev() { [ -f $W/event.sh ] && sh $W/event.sh cron "$1" net "$2" </dev/null >/dev/null 2>&1; true; }
YBAD=0
ywrite() {
mkdir $ALK 2>/dev/null || return 1
A=$(ainit); r_=1; run_=0
cp -p "$Y" "$Y.wf-prima" || { rmdir $ALK 2>/dev/null; return 1; }
if [ -n "$A" ] && pidof AdGuardHome adguardhome >/dev/null 2>&1; then run_=1; $INITD/$A stop >/dev/null 2>&1; fi
f_=$Y
if cp -p "$Y" "$Y.wf" && cp -p "$Y" "$Y.wf2"; then
{ [ -z "$1" ] || { yed "$Y" del "$1" > "$Y.wf2" && f_=$Y.wf2; }; } &&
if [ -n "$2" ]; then yed "$f_" add "$2" > "$Y.wf"; else cat "$f_" > "$Y.wf"; fi &&
mv -f "$Y.wf" "$Y" && r_=0
fi
rm -f "$Y.wf" "$Y.wf2"
if [ $run_ = 1 ]; then
$INITD/$A start >/dev/null 2>&1
if ! adgok; then
$INITD/$A stop >/dev/null 2>&1; cp -p "$Y.wf-prima" "$Y"; $INITD/$A start >/dev/null 2>&1
r_=4; YBAD=1
ev nasdns_adg "⚠️ AdGuard Home ¦ $(t "Non ripartiva col nome NAS" "Did not restart with NAS name") ¦ $(t "Rimesso come prima" "Put back as before")"
fi
[ -f $W/mem.uc ] && ucode $W/mem.uc apply </dev/null >/dev/null 2>&1
fi
rm -f "$Y.wf-prima"
rmdir $ALK 2>/dev/null
return $r_
}
nsans() { nslookup "$N" "$1" 2>/dev/null | awk '/^Name:/ { n = 1; next } n && /^Address/ { sub(/^Address[ 0-9]*:[ \t]*/, ""); sub(/[ \t].*$/, ""); print }'; }
nsok() { i_=0
command -v nslookup >/dev/null 2>&1 || return 0
while :; do
a_=$(nsans "$1")
if [ "$2" = 1 ]; then [ -n "$a_" ] && return 0; else echo "$a_" | grep -qxF "$1" && return 0; fi
i_=$((i_+1)); [ $i_ -ge "${WF_NASDNS_NSWAIT:-8}" ] && return 1; sleep 1
done; }

apply() {
IP=$(hip); okip "$IP" || return 1
OD=$(jget dm); OA=$(jget adg); D=$(dsec); U=0; DM=$OD; AA=$OA
if [ -n "$D" ]; then
ch_=0
if duser "$D" "$OD"; then
U=1; [ -n "$OD" ] && { uci -q del_list "dhcp.$D.address=/$N/$OD"; DM=; ch_=1; }
elif ! { [ "$OD" = "$IP" ] && daddr "$D" | grep -xF "/$N/$IP" >/dev/null; }; then
[ -n "$OD" ] && [ "$OD" != "$IP" ] && uci -q del_list "dhcp.$D.address=/$N/$OD"
daddr "$D" | grep -xF "/$N/$IP" >/dev/null || uci -q add_list "dhcp.$D.address=/$N/$IP"
DM=$IP; ch_=1
fi
[ $ch_ = 1 ] && dreload
fi
Y=$(yfile); [ -f "$Y" ] || Y=
ADG=0; adgdns && ADG=1
if [ $ADG = 1 ]; then
ANS=$(yans "$Y")
if echo "$ANS" | sed '/^$/d' | grep -vxF "${OA:-.}" | grep . >/dev/null; then
U=1; [ -n "$OA" ] && echo "$ANS" | grep -qxF "$OA" && ywrite "$OA" "" && AA=
elif ! { [ "$OA" = "$IP" ] && echo "$ANS" | grep -qxF "$IP"; }; then
o_=; [ -n "$OA" ] && [ "$OA" != "$IP" ] && o_=$OA
ywrite "$o_" "$IP" && AA=$IP
fi
elif [ -n "$OA" ]; then
if [ -z "$Y" ] || ! yans "$Y" | grep -xF "$OA" >/dev/null; then AA=; elif ywrite "$OA" ""; then AA=; fi
fi
OK=0
if [ $YBAD = 1 ]; then OK=0
elif [ $ADG = 1 ]; then { [ -n "$AA" ] || [ $U = 1 ]; } && OK=1; else { [ -n "$DM" ] || [ $U = 1 ]; } && OK=1; fi
[ $OK = 1 ] && { nsok "$IP" "$U" || OK=0; }
save "$IP" "$DM" "$AA" "$U" "$OK"
}
off() {
OD=$(jget dm); OA=$(jget adg); D=$(dsec)
[ -n "$OD" ] && [ -n "$D" ] && daddr "$D" | grep -xF "/$N/$OD" >/dev/null && { uci -q del_list "dhcp.$D.address=/$N/$OD"; dreload; }
Y=$(yfile)
[ -n "$OA" ] && [ -f "$Y" ] && yans "$Y" | grep -xF "$OA" >/dev/null && ywrite "$OA" ""
rm -f "$ST"
}

case "$1" in
on) lock; apply ;;
check) jon || exit 0; lock; apply ;;
off) [ -f "$ST" ] || exit 0; lock; off ;;
st) cat "$ST" 2>/dev/null || echo '{}' ;;
*) echo "uso: nasdns.sh on | off | check | st" >&2; exit 2 ;;
esac
